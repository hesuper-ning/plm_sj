Ext.define('PLM.view.PartExtendInfoSingle', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.PartExtendInfoSingle',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'PartExtendInfoSingle',
        in_objectDesc: '物料扩展视图单页面信息',
    },
    id: 'MockExample1',
    initComponent: function () {
        var me = this;

        var headPanel =  {
            xtype: 'fieldset',
            title: '基本视图',
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '物料编码',
                    id: 'att1',
                    name: 'att1',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '物料类型',
                    name: 'att2',
                    id: 'att2',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    labelWidth: 100,
                    fieldLabel: '物料描述(中文)',
                    name: 'att3',
                    id: 'att3',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                    }]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '研发物料描述',
                    id: 'att4',
                    name: 'att4',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '销售描述',
                    name: 'att5',
                    id: 'att5',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    labelWidth: 100,
                    fieldLabel: '基本单位',
                    name: 'att6',
                    id: 'att6',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                }]
            },{//第三行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '物料组',
                    id: 'att7',
                    name: 'att7',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '产品组',
                    name: 'att8',
                    id: 'att8',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    labelWidth: 100,
                    fieldLabel: 'PDT团队归属',
                    name: 'att9',
                    id: 'att9',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                }]
            },{//第四行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '器件库编码',
                    id: 'att10',
                    name: 'att10',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '控制器点数（点）',
                    name: 'att11',
                    id: 'att11',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    labelWidth: 100,
                    fieldLabel: '优先级',
                    name: 'att12',
                    id: 'att12',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                }]
            },{//第五行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '跨工厂物料状态',
                    id: 'att13',
                    name: 'att13',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '体积',
                    name: 'att14',
                    id: 'att14',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    labelWidth: 100,
                    fieldLabel: '财务税收分类编码',
                    name: 'att15',
                    id: 'att15',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                }]
            },{//第六行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '长文本',
                    id: 'att16',
                    name: 'att16',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }]
            }]
        };

        var groupInfoPanel =  {
            xtype: 'fieldset',
            title: '组织架构',
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '工厂\n',
                    id: 'att17',
                    name: 'att17',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '销售组织\n',
                    name: 'att18',
                    id: 'att18',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    labelWidth: 100,
                    fieldLabel: '分销渠道',
                    name: 'att19',
                    id: 'att19',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample1').getIn_objectKey(), Ext.getCmp('MockExample1').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                }]
            }]
        };
       

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [headPanel,groupInfoPanel]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('MockExample1').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

