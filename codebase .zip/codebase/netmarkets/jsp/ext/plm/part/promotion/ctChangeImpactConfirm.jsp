<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.maturity.PromotionNotice" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        String proOid="";
        String activityName="";
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Persistable object = rf.getReference(oid).getObject();
        if(object instanceof WorkItem){
            WorkItem workItem = (WorkItem)rf.getReference(oid).getObject();
            Persistable object2 = workItem.getPrimaryBusinessObject().getObject();
            if(object2 instanceof PromotionNotice){
                PromotionNotice promotionNotice = (PromotionNotice)object2;
                proOid = promotionNotice.getPersistInfo().getObjectIdentifier().getId() + "";
            }
        }else if(object instanceof PromotionNotice){
             proOid = oid.substring(oid.lastIndexOf(":")+1);
        }
    %>

    <SCRIPT type="text/javascript">
        var oid ='<%= oid %>';
        var id ='';
        var proOid ='<%= proOid %>';
        var activityName = "<%=activityName%>";
        var taskCompleted = true;
    </SCRIPT>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js\ctChangeImpactConfirmTable.js?_dc=<%System.currentTimeMillis();%>"></script>


</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {
                    region: 'center',
                    // items: [{
                    //     xtype: 'panel',
                    //     scrollable: true,
                    //     border: false,
                        items: [{
                            xtype: 'tabpanel',
                            activeTab: 0,
                            items: [
                                {
                                    scrollable: true,
                                    title: '<font style="font-size:12px">相关变更影响确认</font>',
                                    xtype: 'ctChangeImpactConfirmTable'
                                }
                            ]
                        }]
                   // }]
                }
            ]
        });
    });
</script>
</body>
</html>