<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.maturity.PromotionNotice" %>
<%@ page import="wt.workflow.engine.WfProcess" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.org.WTUser" %>
<%@ page import="wt.session.SessionHelper" %>
<%@ page import="ext.plm.part.config.CtPartConfig" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        String proOid="";
        boolean allowEdit=false;
        boolean allowEditCheck=false;
        boolean allowEditFollow=false;
        boolean allowEditPurchaseFollow=false;
        boolean allowEditCommercialDirector=false;
        boolean allowEditTreasurer=false;
        boolean allowEditIQCDirector=false;
        boolean allowEditCertificationDirector=false;
        boolean allowEditAllCheck=false;
        boolean allowEditCostAccounting=false;
        boolean allowEditPDTManager=false;
        boolean allowEditManager=false;
        boolean taskCompleted=false;
        boolean allowEditAll=false;
        boolean whetherBom=false;

        boolean partCertificationResponsibleEdit = false;
        boolean partMethodAndLink = false;

        String activityName="";
        System.out.println(">>>in ctRiskMgt.jsp oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();

        wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
        String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=VR:wt.doc.WTDocument:";

        WorkItem workItem =null;
        Persistable object = rf.getReference(oid).getObject();
        String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
         if(object instanceof WorkItem){
            workItem = (WorkItem)rf.getReference(oid).getObject();
            Persistable object2 = workItem.getPrimaryBusinessObject().getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            activityName=activity.getName();
            if(activityName.contains("BOM")){
                whetherBom=true;
            }
            if(activityName.contains("数据汇总审核")||activityName.contains("标准化审核")){
                allowEditAll=true;
            }
            if(activityName.contains("原材料物料申请流程_指定样品确认流程负责人") || activityName.contains("外购品物料申请流程_指定样品确认流程负责人")){
                partCertificationResponsibleEdit = true;
            }
             if(activityName.contains("原材料物料申请流程_样品确认人选择认证方式") || activityName.contains("外购品物料申请流程_样品确认人选择认证方式")){
                 partMethodAndLink = true;
             }

            if(object2 instanceof PromotionNotice){
                PromotionNotice promotionNotice = (PromotionNotice)object2;
                proOid = promotionNotice.getPersistInfo().getObjectIdentifier().getId() + "";
            }else if(object2 instanceof WTDocument){
                proOid= CtWTObjectUtil.getVid(object2);
            }
        }else if(object instanceof PromotionNotice){
             proOid = oid.substring(oid.lastIndexOf(":")+1);
         }


        //编辑权限判断
        if(null != workItem){
            allowEdit = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEdit_roles"));
            allowEditCheck = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditCheck_roles"));
            allowEditFollow = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditFollow_roles"));
            allowEditPurchaseFollow = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditPurchaseFollow_roles"));
            allowEditCommercialDirector = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditCommercialDirector_roles"));
            allowEditTreasurer = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditTreasurer_roles"));
            allowEditIQCDirector = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditIQCDirector_roles"));
            allowEditCertificationDirector = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditCertificationDirector_roles"));
            allowEditAllCheck = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditAllCheck_roles"));
            allowEditCostAccounting = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditCostAccounting_roles"));
            allowEditPDTManager = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditPDTManager_roles"));
            allowEditManager = CtWorkFlowUtil.hasEditAccess(workItem,
                    CtPartConfig.getProperty("part_allowEditCheck_roles").split(",")[1]);
            if(workItem.isComplete()){
                allowEdit=false;
                allowEditCheck=false;
                allowEditFollow=false;
                allowEditPurchaseFollow=false;
                allowEditCommercialDirector=false;
                allowEditTreasurer=false;
                allowEditIQCDirector=false;
                allowEditCertificationDirector=false;
                allowEditAllCheck=false;
                allowEditCostAccounting=false;
                allowEditAll=false;
                taskCompleted=true;

                partCertificationResponsibleEdit = false;
                partMethodAndLink = false;

            }
        }else{
            allowEdit=false;
            allowEditCheck=false;
            allowEditFollow=false;
            allowEditPurchaseFollow=false;
            allowEditCommercialDirector=false;
            allowEditTreasurer=false;
            allowEditIQCDirector=false;
            allowEditCertificationDirector=false;
            allowEditAllCheck=false;
            allowEditCostAccounting=false;
            allowEditAll=false;
            taskCompleted=true;

            partCertificationResponsibleEdit = false;
            partMethodAndLink = false;
        }

        boolean isAdmin = CtUserUtil.isInGroup(  CtUserUtil.getCurrentUser(), "Administrators");

    %>

    <SCRIPT type="text/javascript">
        //管理员
        var isAdmin = <%=isAdmin%>;
        var oid ='<%= oid %>';
        var id ='';
        var proOid ='<%= proOid %>';
        //当前用户全名
        var userName = "<%=userName%>";
        var activityName = "<%=activityName%>";
        var allowEdit = false;
        <%if(allowEdit){ %>
        allowEdit = true;
        <%}%>
        var whetherBom = false;
        <%if(whetherBom){ %>
        whetherBom = true;
        <%}%>
        var allowEditCheck = false;
        <%if(allowEditCheck){ %>
        allowEditCheck = true;
        <%}%>
        var allowEditFollow = false;
        <%if(allowEditFollow){ %>
        allowEditFollow = true;
        <%}%>
        var allowEditPurchaseFollow = false;
        <%if(allowEditPurchaseFollow){ %>
        allowEditPurchaseFollow = true;
        <%}%>
        var allowEditCommercialDirector = false;
        <%if(allowEditCommercialDirector){ %>
        allowEditCommercialDirector = true;
        <%}%>
        var allowEditTreasurer = false;
        <%if(allowEditTreasurer){ %>
        allowEditTreasurer = true;
        <%}%>
        var allowEditIQCDirector = false;
        <%if(allowEditIQCDirector){ %>
        allowEditIQCDirector = true;
        <%}%>
        var allowEditCertificationDirector = false;
        <%if(allowEditCertificationDirector){ %>
        allowEditCertificationDirector = true;
        <%}%>
        var allowEditAllCheck = false;
        <%if(allowEditAllCheck){ %>
        allowEditAllCheck = true;
        <%}%>
        var allowEditCostAccounting = false;
        <%if(allowEditCostAccounting){ %>
        allowEditCostAccounting = true;
        <%}%>
        var allowEditPDTManager = false;
        <%if(allowEditPDTManager){ %>
        allowEditPDTManager = true;
        <%}%>
        var allowEditManager = false;
        <%if(allowEditManager){ %>
        allowEditManager = true;
        <%}%>
        var selectPlan = false;

        var taskCompleted = false;
        <%if(taskCompleted){ %>
        taskCompleted = true;
        <%}%>
        var allowEditAll = false;
        <%if(allowEditAll){ %>
        allowEditAll = true;
        <%}%>


        var partCertificationResponsibleEdit = false;
        <%if(partCertificationResponsibleEdit){ %>
        partCertificationResponsibleEdit = true;
        <%}%>
        var partMethodAndLink = false;
        <%if(partMethodAndLink){ %>
        partMethodAndLink = true;
        <%}%>
        //url前缀
        var urlPathPrefix ="<%=urlPathPrefix%>";




    </SCRIPT>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctPartExtendInfoSingle.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctPartExtendInfo.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctPartExtendInfoFunction.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js\ctChangeImpactConfirmTable.js?_dc=<%System.currentTimeMillis();%>"></script>


</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {
                    region: 'center',
                    // items: [{
                    //     xtype: 'panel',
                    //     scrollable: true,
                    //     border: false,
                        items: [{
                            xtype: 'tabpanel',
                            activeTab: 0,
                            items: [
                                {
                                    title: '<font style="font-size:12px">业务属性收集与维护</font>',
                                    xtype: 'ctPartExtendInfo'
                                }
                                ,{
                                    scrollable: true,
                                    title: '<font style="font-size:12px">相关变更影响确认</font>',
                                    xtype: 'ctChangeImpactConfirmTable'
                                }
                            ]
                        }]
                   // }]
                }
            ]
        });
    });
</script>
</body>
</html>