/**
 * 保存表单中的一个属性(表单）
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveObjectData(id,dataKey,dataValue,callbackFn){
    var returnItemId = undefined;
    Ext.Ajax.request({
        url: '/Windchill/ptc1/ctPart/updatePartExtendSingle',
        params:{
            id:id,
            dataKey:dataKey,
            dataValue:dataValue,
            oid:oid
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success"){
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if(callbackFn){
                    callbackFn();
                }
            }else{
                alert(obj.message);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}

//修改
function updateProblem (tRecord,callbackFn,e) {
    for(var attr in tRecord){
        if (attr=='effectiveTime'&&tRecord['effectiveTime']!=undefined){

            tRecord[attr]=Ext.util.Format.date(new Date(tRecord[attr]),'Y-m-d H:i:s');
        }
    }
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/ctPart/updatePartExtend/'+oid,
        method:"POST",
        params:tRecord,
        // params:JSON.stringify(tRecord),
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success"){
               callbackFn();
            }else{
                alert(obj.message);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存项目度量信息失败，请检查网络！');
        }
    });
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion

/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    var column = e.column;//获取编辑列
    if (column.editAccess) {
        return true;
    } else {
        return false;
    }
}

//选定成功反写填写视图属性值
function  setViewFromValue(data){
    Ext.getCmp("id").setValue( data['id']);
    Ext.getCmp("oldPartNumber").setValue( data['oldPartNumber']);
    Ext.getCmp("sapPartNumber").setValue( data['sapPartNumber']);
    Ext.getCmp("partType").setValue( data['partType']);
    Ext.getCmp("partCnDescribe").setValue( data['partCnDescribe']);
    Ext.getCmp("developPartDescribe").setValue( data['developPartDescribe']);
    Ext.getCmp("saleDescribe").setValue( data['saleDescribe']);
    Ext.getCmp("unit").setValue( data['unit']);
    Ext.getCmp("partGroup").setValue( data['partGroup']);
    Ext.getCmp("productGroup").setValue( data['productGroup']);
    Ext.getCmp("pdtTeam").setValue( data['pdtTeam']);
    Ext.getCmp("partLibraryNumber").setValue( data['partLibraryNumber']);
    Ext.getCmp("controllerPoints").setValue( data['controllerPoints']);
    Ext.getCmp("priority").setValue( data['priority']);
    Ext.getCmp("otherFactoryPartStatus").setValue( data['otherFactoryPartStatus']);
    Ext.getCmp("volume").setValue( data['volume']);
    Ext.getCmp("taxTypeCode").setValue( data['taxTypeCode']);
    Ext.getCmp("longText").setValue( data['longText']);
    Ext.getCmp("factory").setValue( data['factory']);
    Ext.getCmp("saleOrganization").setValue( data['saleOrganization']);
    Ext.getCmp("channels").setValue( data['channels']);
    Ext.getCmp("deliveryFactory").setValue( data['deliveryFactory']);
    Ext.getCmp("taxType").setValue( data['taxType']);
    Ext.getCmp("subjectGroup").setValue( data['subjectGroup']);
    Ext.getCmp("projectTypeGroup").setValue( data['projectTypeGroup']);
    Ext.getCmp("loadGroup").setValue( data['loadGroup']);
    Ext.getCmp("purchaseGroup").setValue( data['purchaseGroup']);
    Ext.getCmp("autoBuyList").setValue( data['autoBuyList']);
    Ext.getCmp("sourceList").setValue( data['sourceList']);
    Ext.getCmp("checkType").setValue( data['checkType']);
    Ext.getCmp("stockLogo").setValue( data['stockLogo']);
    Ext.getCmp("mrpType").setValue( data['mrpType']);
    Ext.getCmp("mrpController").setValue( data['mrpController']);
    Ext.getCmp("lotSize").setValue( data['lotSize']);
    Ext.getCmp("miniLot").setValue( data['miniLot']);
    Ext.getCmp("assemblyScrap").setValue( data['assemblyScrap']);
    Ext.getCmp("rounding").setValue( data['rounding']);
    Ext.getCmp("acquisitionType").setValue( data['acquisitionType']);
    // Ext.getCmp("acquisitionTypeCombo").setValue( data['acquisitionTypeCombo']);
    Ext.getCmp("specialType").setValue( data['specialType']);
    Ext.getCmp("goLogo").setValue( data['goLogo']);
    Ext.getCmp("bulkPart").setValue( data['bulkPart']);
    Ext.getCmp("productionLocation").setValue( data['productionLocation']);
    Ext.getCmp("outBuyStorageLocation").setValue( data['outBuyStorageLocation']);
    Ext.getCmp("planMarginalCode").setValue( data['planMarginalCode']);
    Ext.getCmp("selfProductionTime").setValue( data['selfProductionTime']);
    Ext.getCmp("planDeliveryTime").setValue( data['planDeliveryTime']);
    Ext.getCmp("receiptTime").setValue( data['receiptTime']);
    Ext.getCmp("safeStock").setValue( data['safeStock']);
    Ext.getCmp("policyGroup").setValue( data['policyGroup']);
    Ext.getCmp("consumptionPattern").setValue( data['consumptionPattern']);
    Ext.getCmp("reverseConsumption").setValue( data['reverseConsumption']);
    Ext.getCmp("periodConsumption").setValue( data['periodConsumption']);
    Ext.getCmp("availabilityCheck").setValue( data['availabilityCheck']);
    Ext.getCmp("independentLogo").setValue( data['independentLogo']);
    Ext.getCmp("bomScrap").setValue( data['bomScrap']);
    Ext.getCmp("discontinueLogo").setValue( data['discontinueLogo']);
    Ext.getCmp("effectiveTime").setValue( data['effectiveTime']);
    Ext.getCmp("subsequentPart").setValue( data['subsequentPart']);
    Ext.getCmp("productionManager").setValue( data['productionManager']);
    Ext.getCmp("productionPlanList").setValue( data['productionPlanList']);
    Ext.getCmp("numberList").setValue( data['numberList']);
    Ext.getCmp("unitCode").setValue( data['unitCode']);
    Ext.getCmp("accessType").setValue( data['accessType']);
    Ext.getCmp("priceControl").setValue( data['priceControl']);
    Ext.getCmp("standardPrice").setValue( data['standardPrice']);
    Ext.getCmp("priceMoving").setValue( data['priceMoving']);
    Ext.getCmp("priceUnit").setValue( data['priceUnit']);
    Ext.getCmp("costEstimation").setValue( data['costEstimation']);
    Ext.getCmp("partSource").setValue( data['partSource']);
    Ext.getCmp("profitCenter").setValue( data['profitCenter']);
    //认证类型
    let certificationTypeValue = data['certificationType'];
    if(certificationTypeValue){
        let certificationTypeValueArray = certificationTypeValue.split(',');
        Ext.getCmp("certificationType").setValue(certificationTypeValueArray);
    }

}

