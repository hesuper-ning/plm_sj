Ext.define('PLM.view.PartExtendInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.PartExtendInfo',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'PartExtendInfo',
        in_objectDesc: '物料扩展视图',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            title: '物料视图',
            margin: '20 10 20 10',
            autoWidth: true,
            autoScroll: true,
            region: 'center',
            height: 400,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            selType: 'checkboxmodel',
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '物料编码', dataIndex: 'data1', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '物料类型', dataIndex: 'data2', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '物料描述', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '研发物料描述', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {
                    text: '基本视图',
                    columns:[
                        {text: '基本单位', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '物料组', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '产品组', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: 'PDT团队归属', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '器件库编码', dataIndex: 'data9', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '控制器点数', dataIndex: 'data10', width:   80, editor: 'textfield', menuDisabled: true},
                        {text: '优先级', dataIndex: 'data11', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '跨工厂物料状态', dataIndex: 'data12', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '体积', dataIndex: 'data13', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '财务税收分类编码', dataIndex: 'data14', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '长文本', dataIndex: 'data15', width: 80, editor: 'textfield', menuDisabled: true}
                    ]
                },
                {
                    text: '组织架构',
                    columns:[
                        {text: '工厂', dataIndex: 'data16', width: 60, editor: 'textfield', menuDisabled: true},
                        {text: '销售组织', dataIndex: 'data17', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '分销渠道', dataIndex: 'data18', width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: '销售视图',
                    columns:[
                        {text: '交货工厂', dataIndex: 'data19', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '税分类', dataIndex: 'data20', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '科目设置组', dataIndex: 'data21', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '项目类别组', dataIndex: 'data22', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '装载组', dataIndex: 'data23', width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: '采购视图',
                    columns:[
                        {text: '采购组', dataIndex: 'data24', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '自动采购订单', dataIndex: 'data25', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '源清单', dataIndex: 'data26', width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: '质量视图',
                    columns:[
                        {text: 'IQC主管填写', dataIndex: 'data27', width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: 'MRP1',
                    columns:[
                        {text: '库存ABC标示', dataIndex: 'data28', width: 80, editor: 'textfield', menuDisabled: true},
                        {text: 'MRP类型',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: 'MRP控制者',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '批量大小',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '最小批量大小',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '装配报废',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '舍入值',  width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: 'MRP2',
                    columns:[
                        {text: '获取类型',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '特殊获取类型',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '反冲标识',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '散装物料',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '生产仓储地点',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '外部采购仓储地点',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '计划边际码',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '自制生产时间',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '计划交货时间',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '收货处理时间',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '安全库存',  width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: 'MRP3',
                    columns:[
                        {text: '策略组',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '消耗模式',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '逆向消耗期间',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '向前消耗期间',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '可用性检查',  width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: 'MRP4',
                    columns:[
                        {text: '独立/集中标识',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '组件报废',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '非连续标识',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '生效日期',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '后续物料',  width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: '工作计划',
                    columns:[
                        {text: '生产管理员',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '生产计划参数文件',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '序列号参数文件',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '填写单位编码',  width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: '会计/成本视图',
                    columns:[
                        {text: '评估类',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '价格控制',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '标准价格',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '移动平均价',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '价格单位',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '成本估算',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '物料来源',  width: 80, editor: 'textfield', menuDisabled: true},
                        {text: '利润中心',  width: 80, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {text: '',  width: 20, menuDisabled: true},
            ],
            tbar:[{
                text:'查看',
                handler:function(){
                    var myWindow = Ext.create('Ext.Window', {
                        id: 'workReportWin',
                        title: '物料信息',
                        width: 1000,
                        height: 700,
                        closeAction: 'destroy',
                        autoScroll: true,
                        constrain: true,
                        modal: true,
                        items: [{xtype:'PartExtendInfoSingle'}]
                    });
                    myWindow.show();
                }
            }]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'textfield',
                fieldLabel: '标题1',
                padding: '20 15 10 20',
                id: 'att1',
                name: 'att1',
                width: 450,
                listeners: {
                    blur: function (e) {
                        saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    }
                }
            }, {
                xtype: 'textfield',
                fieldLabel: '标题2',
                padding: '0 15 20 20',
                id: 'att2',
                name: 'att2',
                width: 450,
                listeners: {
                    blur: function (e) {
                        saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    }
                }
            }, mockExampleGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

