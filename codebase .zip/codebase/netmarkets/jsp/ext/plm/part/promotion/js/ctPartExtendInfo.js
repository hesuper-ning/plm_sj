Ext.define('PLM.view.ctPartExtendInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctPartExtendInfo',
    border: false,
    collapsible: false,
    config: {
        in_objectKey: 'PartExtendInfo',
        in_objectDesc: '物料扩展视图',
    },
    // id: 'MockExample',
    initComponent: function () {
        var partAuthenticationMethodCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'partAuthenticationMethodCombo',
            id: 'partAuthenticationMethodCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '系列认证流程' },
                    { fullName: '样品确认流程' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName'
        });

        Ext.define('ctRiskAssessModel', {
            extend: 'Ext.data.Model',
            // oldPartNumber	 sapPartNumber	  partType	 partCnDescribe	  developPartDescribe	  saleDescribe	,  unit	, partGroup
            // , productGroup	, pdtTeam	, partLibraryNumber	,（点）controllerPoints	, priority	, otherFactoryPartStatus	, volume
            // , taxTypeCode	, longText	, factory	, saleOrganization	, channels	, deliveryFactory	税分类 taxType	, subjectGroup
            // , projectTypeGroup	, loadGroup	, purchaseGroup	, autoBuyList	, sourceList	, checkType	, stockLogo	,	mrpType
            // , mrpController	 lotSize	, miniLot	, assemblyScrap	, rounding	, acquisitionType	, specialType	, goLogo	, bulkPart
            // , productionLocation, outBuyStorageLocation	, planMarginalCode	, selfProductionTime	, planDeliveryTime	, receiptTime
            // , safeStock	, policyGroup	, consumptionPattern	, reverseConsumption	, periodConsumption	, availabilityCheck	, independentLogo
            // , bomScrap 	, discontinueLogo	, effectiveTime	,  subsequentPart	, productionManager	, productionPlanList 	,	numberList
            // , unitCode	, accessType	, priceControl	, standardPrice 	, priceMoving	, priceUnit	, costEstimation	, partSource	, profitCenter
            fields:['id' ,'oldPartNumber','sapPartNumber','partType','partCnDescribe','developPartDescribe','saleDescribe','unit','partGroup','productGroup',
                'pdtTeam','partLibraryNumber','controllerPoints','priority','otherFactoryPartStatus','volume','taxTypeCode','longText','factory', 'saleOrganization' ,
                'channels','deliveryFactory','taxType','subjectGroup','projectTypeGroup','loadGroup','purchaseGroup', 'autoBuyList','sourceList','checkType','stockLogo',
                'mrpType','mrpController','lotSize','miniLot','assemblyScrap','rounding','acquisitionType','specialType','goLogo','bulkPart','productionLocation',
                'outBuyStorageLocation','planMarginalCode','selfProductionTime','planDeliveryTime','receiptTime','safeStock','policyGroup','consumptionPattern',
                'reverseConsumption','periodConsumption','availabilityCheck','independentLogo','bomScrap','discontinueLogo','effectiveTime','subsequentPart',
                'productionManager','productionPlanList','numberList','unitCode','accessType', 'priceControl','standardPrice','priceMoving','priceUnit','costEstimation',
                'partSource','profitCenter','updateTime','certificationType'],
            idProperty: 'id'
        });
        var me = this;
        var ctPartExtendInfoStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctRiskAssessModel',
            id: 'ctPartExtendInfoStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ctPart/getDataByBranchId',
                method: 'GET',
                reader: {
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: true
        });
//旧物料编码 oldPartNumber	SAP物料编码 sapPartNumber	物料类型  partType	物料描述(中文)  partCnDescribe	研发物料描述  developPartDescribe	销售描述  saleDescribe	基本单位  unit	物料组 partGroup
// 产品组 productGroup	PDT团队归属 pdtTeam	器件库编码 partLibraryNumber	控制器点数（点）controllerPoints	优先级 priority	跨工厂物料状态 otherFactoryPartStatus	体积 volume
// 财务税收分类编码 taxTypeCode	长文本 longText	工厂 factory	销售组织 saleOrganization	分销渠道 channels	交货工厂 deliveryFactory	税分类 taxType	科目设置组 subjectGroup
// 项目类别组 projectTypeGroup	装载组 loadGroup	采购组 purchaseGroup	自动采购订单 autoBuyList	源清单 sourceList	检验类型 checkType	库存ABC标示 stockLogo	MRP类型	mrpType
// MRP控制者 mrpController	批量大小 lotSize	最小批量大小 miniLot	装配报废 assemblyScrap	舍入值 rounding	获取类型 acquisitionType	特殊获取类型 specialType	反冲标识 goLogo	散装物料 bulkPart
// 生产仓储地点 productionLocation	外部采购仓储地点 outBuyStorageLocation	计划边际码 planMarginalCode	自制生产时间 selfProductionTime	计划交货时间 planDeliveryTime	收货处理时 receiptTime
// 安全库存 safeStock	策略组 policyGroup	消耗模式 consumptionPattern	逆向消耗期间 reverseConsumption	向前消耗期间 periodConsumption	可用性检查 availabilityCheck	独立/集中标识 independentLogo
// 组件报废 bomScrap 	非连续标识 discontinueLogo	生效日期 effectiveTime	后续物料  subsequentPart	生产管理员 productionManager	生产计划参数文件 productionPlanList 	序列号参数文件	numberList
// 填写单位编码 unitCode	评估类 accessType	价格控制 priceControl	标准价格 standardPrice 	移动平均价 priceMoving	价格单位 priceUnit	成本估算 costEstimation	物料来源 partSource	利润中心 profitCenter

        Ext.define('mrpControllerTextModel', {
            extend: 'Ext.data.Model',
            fields: ['data'],
            idProperty: 'id'
        });

        var mrpControllerTextStore = Ext.create('Ext.data.Store', {
            id: 'mrpControllerTextStore',
            model: 'mrpControllerTextModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ctPart/getMrpListByFactory',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        Ext.define('certificationTypeModel', {
            extend: 'Ext.data.Model',
            fields: ['data'],
            idProperty: 'id'
        });

        var certificationTypeStore = Ext.create('Ext.data.Store', {
            id: 'certificationTypeStore',
            model: 'certificationTypeModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ext/plm/doc/certificate/certificateList/getTypeByPartNumber',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        Ext.define('outBuyStorageLocationModel', {
            extend: 'Ext.data.Model',
            fields: ['data'],
            idProperty: 'id'
        });

        var outBuyStorageLocationStore = Ext.create('Ext.data.Store', {
            id: 'outBuyStorageLocationStore',
            model: 'outBuyStorageLocationModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ctPart/getMrpListByFactory',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        Ext.define('channelsTextModel', {
            extend: 'Ext.data.Model',
            fields: ['data'],
            idProperty: 'id'
        });

        var channelsTextStore = Ext.create('Ext.data.Store', {
            id: 'channelsTextStore',
            model: 'channelsTextModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ctPart/getMrpListByFactory',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });



        //工厂选择框
        var factoryCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'factoryId',
            id: 'factoryId',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [ ["1001", "1001"], ["1003", "1003"], ["1100", "1100"], ["1200", "1200"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (combo) {
                    }
                    }
        });
        var saleOrganizationTextCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditCommercialDirector?false:true,
            name: 'saleOrganization1',
            id: 'saleOrganization1',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["1001-国内销售组织", "1001-国内销售组织"],["1002-国外销售组织", "1002-国外销售组织"], ["1003-电商销售组织", "1003-电商销售组织"], ["1100-科技销售组织", "1100-科技销售组织"], ["1200-数据销售组织", "1200-数据销售组织"], ["1300-检测销售组织", "1300-检测销售组织"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {


            }
        }});

        var channelsTextCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditCommercialDirector?false:true,
            name: 'channels1',
            id: 'channels1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            queryMode:'local',
            store:Ext.getStore('channelsTextStore'),
            valueField: 'formInfo',
            displayField: 'formInfo',
            listeners: {
                change: function (e) {
                }
            }
        });

        var deliveryFactoryTextCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'deliveryFactory1',
            id: 'deliveryFactory1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [ ["1001", "1001"], ["1003", "1003"], ["1100", "1100"], ["1200", "1200"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (combo) {
                }
            }
        });
        //税分类选择框
        var taxTypeCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditCommercialDirector?false:true,
            name: 'taxTypeId',
            id: 'taxTypeId',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [ ["0-零税率","0-零税率"], ["1-13%（物料、产品及软件销售）", "1-13%（物料、产品及软件销售）"], ["2-10%（工程服务）", "2-10%（工程服务）"],
                    ["3-6%（研发服务、技术服务、平台服务）", "3-6%（研发服务、技术服务、平台服务）"],["4-16%  （维修服务）", "4-16%  （维修服务）"], ["5-5%  （租赁服务）","5-5%  （租赁服务）"],
                        ["6-3%（各项业务）","6-3%（各项业务）"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });
        //源清单选择框
        var sourceListCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEdit?false:true,
            name: 'sourceList1',
            id: 'sourceList1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["无", "无"], ["X", "启用"]]

            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });
        //库存选择框
        var stockLogoCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'stockLogo1',
            id: 'stockLogo1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["无","无"],["A-高价值", "A-高价值"], ["B-中价值", "B-中价值"], ["C-低价值", "C-低价值"]]

            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });
        //mrp选择框
        var mrpTypeCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'mrpType1',
            id: 'mrpType1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data:[["PD-参与MRP运算", "PD-参与MRP运算"], ["ND-不参与MRP运算", "ND-不参与MRP运算"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });
        //MRP控制者选择框
        var mrpControllerCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'mrpController1',
            id: 'mrpController1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            queryMode:'local',
            store:Ext.getStore("mrpControllerTextStore"),
            valueField: 'formInfo',
            displayField: 'formInfo',
            listeners: {
                change: function (e) {
                }
            }
        });

        //批量大小选择
        var lotSizeCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'lotSize1',
            id: 'lotSize1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data:[["MB-月批量", "MB-月批量"], ["W2-2周批量", "W2-2周批量"], ["WB-周批量", "WB-周批量"],
                    ["TB-日合批", "TB-日合批"], ["2D-2天合批", "2D-2天合批"],["3D-3天合批", "3D-3天合批"],["4D-4天合批", "4D-4天合批"],
                    ["5D-5天合批", "5D-5天合批"],["TD-10天合批", "TD-10天合批"],["EX-逐批", "EX-逐批"],
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });
        //特殊获取类型选择框
        var specialTypeCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'specialType1',
            id: 'specialType1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["无","无"],["50-生产虚拟件(结合E-自制使用)", "50-生产虚拟件(结合E-自制使用)"], ["30-委外采购(结合F-外购使用)", "30-委外采购(结合F-外购使用)"], ["41-工厂间转储(结合F-外购使用)", "41-工厂间转储(结合F-外购使用)"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });
        //反冲标识选择框
        var goLogoCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'goLogo1',
            id: 'goLogo1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data:[["一直反冲", "一直反冲"], ["不反冲", "不反冲"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });
        var bulkPartCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'bulkPart1',
            id: 'bulkPart1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data:[["无", "无"], ["X-散装物料标识", "X-散装物料标识"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });

        var personLiableStore = new Ext.data.ArrayStore({
            id: 'personLiableStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            // proxy: {
            //     type: 'ajax',
            //     url: '/Windchill/ptc1/personLiableList',
            //     reader: {
            //         type: 'json',
            //         rootProperty: 'data'
            //     }
            // },
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/sampleConfirmation/searchPROPersonResponsible?proOid='+proOid+'&roleNames=B021器件工程师',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var personLiableCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'personLiableCom',
            id: 'personLiableCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: personLiableStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });

        var productionLocationCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'productionLocation1',
            id: 'productionLocation1',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["0001物控-质检仓", "0001物控-质检仓"], ["0002物控-原材料仓", "0002物控-原材料仓"],
                    ["0003物控-半成品仓", "0003物控-半成品仓"], ["0008物控-消防成品仓", "0008物控-消防成品仓"],
                    ["1001生产-大柜线边仓", "1001生产-大柜线边仓"], ["1002生产-壁挂线边仓(1, 2线)", "1002生产-壁挂线边仓(1, 2线)"],
                    ["1003生产-大板线边仓(3线)", "1003生产-大板线边仓(3线)"], ["1003生产-大板线边仓(3线)", "1003生产-大板线边仓(3线)"],
                    ["1004生产-四楼线边仓", "1004生产-四楼线边仓"], ["1005生产-五楼线边仓", "1005生产-五楼线边仓"],
                    ["1006生产-五楼贴片线边仓", "1006生产-五楼贴片线边仓"], ["1007生产-六楼底座线边仓", "1007生产-六楼底座线边仓"],
                    ["1008生产-六楼声光线边仓", "1008生产-六楼声光线边仓"], ["1009生产-二楼贴片二车边仓", "1009生产-二楼贴片二车边仓"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                }

            }
        });
        var outBuyStorageLocationCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'outBuyStorageLocationCombo',
            id: 'outBuyStorageLocationCombo',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["0001物控-质检仓", "0001物控-质检仓"], ["0002物控-原材料仓", "0002物控-原材料仓"],
                    ["0003物控-半成品仓", "0003物控-半成品仓"], ["0008物控-消防成品仓", "0008物控-消防成品仓"],
                    ["1001生产-大柜线边仓", "1001生产-大柜线边仓"], ["1002生产-壁挂线边仓(1, 2线)", "1002生产-壁挂线边仓(1, 2线)"],
                    ["1003生产-大板线边仓(3线)", "1003生产-大板线边仓(3线)"], ["1003生产-大板线边仓(3线)", "1003生产-大板线边仓(3线)"],
                    ["1004生产-四楼线边仓", "1004生产-四楼线边仓"], ["1005生产-五楼线边仓", "1005生产-五楼线边仓"],
                    ["1006生产-五楼贴片线边仓", "1006生产-五楼贴片线边仓"], ["1007生产-六楼底座线边仓", "1007生产-六楼底座线边仓"],
                    ["1008生产-六楼声光线边仓", "1008生产-六楼声光线边仓"], ["1009生产-二楼贴片二车边仓", "1009生产-二楼贴片二车边仓"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                }

            }
        });
        //非连续标识选择框
        var discontinueLogoCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow?false:true,
            name: 'discontinueLogo1',
            id: 'discontinueLogo1',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data:[["单一后续替代", "单一后续替代"], ["平行后续替代", "平行后续替代"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {

                }
            }
        });
        var acquisitionTypeCombo2 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow||allowEditAll?false:true,
            fieldLabel: acquisitionTypeText,
            name: 'acquisitionType2',
            id: 'acquisitionType2',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["E-自制","E-自制"],["F-外购", "F-外购"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {

                }
            }
        });
        var numberListCombo = new Ext.form.field.ComboBox({
            fieldLabel: numberListText,
            readOnly:allowEditFollow?false:true,
            name: 'numberList1',
            id: 'numberList1',
            // margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["空-无", "空-无"], ["Z001-序列号管理", "Z001-序列号管理"]
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });

        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var oldPartNumberText = '旧物料编码';
        var sapPartNumberText = 'SAP物料编码';
        var partTypeText = '物料类型';
        var partCnDescribeText='物料描述(中文)';
        var developPartDescribeText='研发物料描述';
        //基本视图
        var saleDescribeText='销售描述';
        var unitText='基本单位';
        var partGroupText='物料组';
        var productGroupText='产品组';
        var pdtTeamText='PDT团队归属';
        var partLibraryNumberText='器件库编码';
        var controllerPointsText='控制器点数（点）';
        var priorityText='优先级';
        var otherFactoryPartStatusText='跨工厂物料状态';
        var volumeText='体积';
        var taxTypeCodeText='财务税收分类编码';
        var longTextText='备注';
        //组织架构
        var factoryText='工厂';
        var saleOrganizationText='销售组织';
        var channelsText='分销渠道';
        //销售视图
        var deliveryFactoryText='交货工厂';
        var taxTypeText='税分类';
        var subjectGroupText='科目设置组';
        var projectTypeGroupText='项目类别组';
        var loadGroupText='装载组';
        //采购视图
        var purchaseGroupText='采购组';
        var autoBuyListText='自动采购订单';
        var sourceListText='源清单';
        //质量视图
        var checkTypeText='检验类型';
        //认证视图
        var certificationTypeText='认证类型';

        //MRP1
        var stockLogoText='库存ABC标示';
        var mrpTypeText='MRP类型';
        var mrpControllerText='MRP控制者';
        var lotSizeText='批量大小';
        var miniLotText='最小批量大小';
        var assemblyScrapText='装配报废';
        var roundingText='舍入值';
        //MRP2
        var acquisitionTypeText='获取类型';
        var specialTypeText='特殊获取类型';
        var goLogoText='反冲标识';
        var bulkPartText='散装物料';
        var productionLocationText='生产仓储地点';
        var outBuyStorageLocationText='外部采购仓储地点';
        var planMarginalCodeText='计划边际码';
        var selfProductionTimeText='自制生产时间(天)';
        var planDeliveryTimeText='计划交货时间(天)';
        var receiptTimeText='收货处理时间(天)';
        var safeStockText='安全库存';
        //MRP3
        var policyGroupText='策略组';
        var consumptionPatternText='消耗模式';
        var reverseConsumptionText='逆向消耗期间';
        var periodConsumptionText='向前消耗期间';
        var availabilityCheckText='可用性检查';
        //MRP4
        var independentLogoText='独立/集中标识';
        var bomScrapText='组件报废';
        var discontinueLogoText='非连续标识';
        var effectiveTimeText='生效日期';
        var subsequentPartText='后续物料';
        //工作计划
        var productionManagerText='生产管理员';
        var productionPlanListText='生产计划参数文件';
        var numberListText='序列号参数文件';
        var unitCodeText='填写单位编码';
        //会计/成本视图
        var accessTypeText='评估类';
        var priceControlText='价格控制';
        var standardPriceText='标准价格(元)';
        var priceMovingText='移动平均价(元)';
        var priceUnitText='价格单位(元)';
        var costEstimationText='成本估算';
        var partSourceText='物料来源';
        var profitCenterText='利润中心';
        var branchIdText='流程ID';
        //物料认证
        var partCertificationResponsible = '物料认证负责人';
        //物料认证
        var partAuthenticationMethod = '物料认证方式';
        //物料认证
        var certificationDocumentLink = '物料认证文档链接';
            //可编辑项
            if(allowEdit) {
                //基本视图
                oldPartNumberText= blueFlagStart+ oldPartNumberText +blueFlagEnd;
                sapPartNumberText= redStarFlag+blueFlagStart+ sapPartNumberText +blueFlagEnd;
                partTypeText= redStarFlag+blueFlagStart+ partTypeText +blueFlagEnd;
                partCnDescribeText= redStarFlag+blueFlagStart+ partCnDescribeText +blueFlagEnd;
                developPartDescribeText= blueFlagStart+ developPartDescribeText +blueFlagEnd;
                saleDescribeText=blueFlagStart+ saleDescribeText +blueFlagEnd;
                unitText = redStarFlag+blueFlagStart+ unitText +blueFlagEnd;
                partGroupText =redStarFlag+ blueFlagStart+ partGroupText +blueFlagEnd;
                productGroupText =redStarFlag+ blueFlagStart+ productGroupText +blueFlagEnd;
                pdtTeamText =redStarFlag+blueFlagStart+ pdtTeamText +blueFlagEnd;
                partLibraryNumberText =blueFlagStart+ partLibraryNumberText +blueFlagEnd;
                controllerPointsText =blueFlagStart+ controllerPointsText +blueFlagEnd;
                priorityText =blueFlagStart+ priorityText +blueFlagEnd;
                otherFactoryPartStatusText =blueFlagStart+ otherFactoryPartStatusText +blueFlagEnd;
                taxTypeCodeText =blueFlagStart+ taxTypeCodeText +blueFlagEnd;
                longTextText =blueFlagStart+ longTextText +blueFlagEnd;
            }
            if(allowEditCommercialDirector){
                volumeText =blueFlagStart+ volumeText +blueFlagEnd;
                taxTypeText =blueFlagStart+ taxTypeText +blueFlagEnd;
                subjectGroupText =blueFlagStart+ subjectGroupText +blueFlagEnd;
                projectTypeGroupText =blueFlagStart+ projectTypeGroupText +blueFlagEnd;
                loadGroupText =blueFlagStart+ loadGroupText +blueFlagEnd;

                saleOrganizationText = blueFlagStart+ saleOrganizationText +blueFlagEnd;
                channelsText = blueFlagStart+ channelsText +blueFlagEnd;
            }
            if(allowEditPurchaseFollow) {
                //采购视图
                purchaseGroupText =blueFlagStart+ purchaseGroupText +blueFlagEnd;
                autoBuyListText =blueFlagStart+ autoBuyListText +blueFlagEnd;
                sourceListText =blueFlagStart+ sourceListText +blueFlagEnd;
            }
            if(allowEditIQCDirector) {
                //质量视图
                checkTypeText = redStarFlag+blueFlagStart+ checkTypeText +blueFlagEnd;
            }
            if(allowEditCertificationDirector){
                certificationTypeText = redStarFlag+blueFlagStart+ certificationTypeText +blueFlagEnd;
            }
            if(allowEditFollow) {
                factoryText = redStarFlag+blueFlagStart+ factoryText +blueFlagEnd;
                deliveryFactoryText =blueFlagStart+ deliveryFactoryText +blueFlagEnd;
                //MRP1
                stockLogoText =blueFlagStart+ stockLogoText +blueFlagEnd;
                mrpTypeText = redStarFlag+blueFlagStart+ mrpTypeText +blueFlagEnd;
                mrpControllerText = redStarFlag+blueFlagStart+ mrpControllerText +blueFlagEnd;
                lotSizeText = redStarFlag+blueFlagStart+ lotSizeText +blueFlagEnd;
                miniLotText =blueFlagStart+ miniLotText +blueFlagEnd;
                assemblyScrapText = blueFlagStart+ assemblyScrapText +blueFlagEnd;
                roundingText =blueFlagStart+ roundingText +blueFlagEnd;
                //MRP2
                acquisitionTypeText = redStarFlag+blueFlagStart+ acquisitionTypeText +blueFlagEnd;
                specialTypeText = blueFlagStart+ specialTypeText +blueFlagEnd;
                goLogoText = blueFlagStart+ goLogoText +blueFlagEnd;
                bulkPartText = blueFlagStart+ bulkPartText +blueFlagEnd;
                productionLocationText = blueFlagStart+ productionLocationText +blueFlagEnd;
                outBuyStorageLocationText =blueFlagStart+ outBuyStorageLocationText +blueFlagEnd;
                planMarginalCodeText = redStarFlag+blueFlagStart+ planMarginalCodeText +blueFlagEnd;
                selfProductionTimeText = blueFlagStart+ selfProductionTimeText +blueFlagEnd;
                planDeliveryTimeText = blueFlagStart+ planDeliveryTimeText +blueFlagEnd;
                receiptTimeText = redStarFlag+blueFlagStart+ receiptTimeText +blueFlagEnd;
                safeStockText = blueFlagStart+ safeStockText +blueFlagEnd;
                //MRP3
                policyGroupText = blueFlagStart+ policyGroupText +blueFlagEnd;
                consumptionPatternText = blueFlagStart+ consumptionPatternText +blueFlagEnd;
                reverseConsumptionText = blueFlagStart+ reverseConsumptionText +blueFlagEnd;
                periodConsumptionText = blueFlagStart+ periodConsumptionText +blueFlagEnd;
                availabilityCheckText =blueFlagStart+ availabilityCheckText +blueFlagEnd;
                //MRP4
                independentLogoText =blueFlagStart+ independentLogoText +blueFlagEnd;
                bomScrapText = blueFlagStart+ bomScrapText +blueFlagEnd;
                discontinueLogoText = blueFlagStart+ discontinueLogoText +blueFlagEnd;
                effectiveTimeText = blueFlagStart+ effectiveTimeText +blueFlagEnd;
                subsequentPartText = blueFlagStart+ subsequentPartText +blueFlagEnd;
                //工作计划
                productionManagerText = blueFlagStart+ productionManagerText +blueFlagEnd;
                productionPlanListText = blueFlagStart+ productionPlanListText +blueFlagEnd;
                numberListText = blueFlagStart+ numberListText +blueFlagEnd;
                unitCodeText =blueFlagStart+ unitCodeText +blueFlagEnd;
            }
            if(allowEditTreasurer){
                //会计/成本视图
                accessTypeText =blueFlagStart+ accessTypeText +blueFlagEnd;
                priceControlText =blueFlagStart+ priceControlText +blueFlagEnd;
                standardPriceText =blueFlagStart+ standardPriceText +blueFlagEnd;
                priceMovingText =blueFlagStart+ priceMovingText +blueFlagEnd;
                priceUnitText =blueFlagStart+ priceUnitText +blueFlagEnd;
                costEstimationText =redStarFlag+blueFlagStart+ costEstimationText +blueFlagEnd;
                partSourceText =redStarFlag+blueFlagStart+ partSourceText +blueFlagEnd;
                profitCenterText =blueFlagStart+ profitCenterText +blueFlagEnd;
                branchIdText =redStarFlag+blueFlagStart+ branchIdText +blueFlagEnd;
            }

            if(partCertificationResponsibleEdit){
                partCertificationResponsible = redStarFlag + blueFlagStart+ partCertificationResponsible +blueFlagEnd;
            }
            if(partMethodAndLink){
                partAuthenticationMethod = redStarFlag + blueFlagStart+ partAuthenticationMethod +blueFlagEnd;
                certificationDocumentLink = blueFlagStart+ certificationDocumentLink +blueFlagEnd;
            }

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var partExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('ctPartExtendInfoStore'),
            id: 'partExampleGrid',
            title: '物料视图',
            margin: '20 10 20 10',
            // autoWidth: true,
            autoScroll: true,
            region: 'center',
            height: 500,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            // selType: 'checkboxmodel',
            listeners: {
                cellclick: function( grid, td, cellIndex, record, tr, rowIndex, e, eOpts ){
                    console.log(cellIndex);
                    if((cellIndex >0&&cellIndex<20)||(cellIndex>24&&cellIndex<30)||cellIndex==31||cellIndex==32||
                        (cellIndex>49&&cellIndex<56)||cellIndex==60||cellIndex==61||cellIndex==64||cellIndex==65||cellIndex==68||cellIndex==71) {
                         id =record.get("id");

                        let partNumber = record.get('sapPartNumber');
                        Ext.getStore("certificationTypeStore").load({
                            params:{
                                partNumber: partNumber
                            }
                        });

                        var myWindow = Ext.create('Ext.Window', {
                            id: 'workReportWin',
                            title: '物料信息',
                            width: 1030,
                            height: 500,
                            closeAction: 'destroy',
                            autoScroll: true,
                            constrain: true,
                            modal: true,
                            items: [{xtype:'ctPartExtendInfoSingle'}]
                        });
                        myWindow.show();
                        myWindow.on('close', function(){
                            Ext.getStore('ctPartExtendInfoStore').reload()
                        });
                    }
                },
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                // {text: '', dataIndex: 'masterId', menuDisabled: true, hidden:  true},
                {text: oldPartNumberText, dataIndex: 'oldPartNumber', width: 80, editor: null, menuDisabled: true,locked:true},
                {text: sapPartNumberText, dataIndex: 'sapPartNumber', width: 80, editor: null, menuDisabled: true,locked:true},
                {text: partTypeText, dataIndex: 'partType', width: 80, editor: null, menuDisabled: true,locked:true},
                {text: partCnDescribeText, dataIndex: 'partCnDescribe', width: 80, editor: null, menuDisabled: true,locked:true},
                {text: developPartDescribeText, dataIndex: 'developPartDescribe', width: 80, editor: null, menuDisabled: true,locked:true},
                {text: saleDescribeText, dataIndex: 'saleDescribe', width: 80, editor: null, menuDisabled: true,locked:true},
                {
                    text: '基本视图',
                    columns:[
                        //占列数，不可删除
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: unitText, dataIndex: 'unit', width: 80,  menuDisabled: true,locked:false},
                        {text: partGroupText, dataIndex: 'partGroup', width: 80, editor:null, menuDisabled: true,locked:false},
                        {text: productGroupText, dataIndex: 'productGroup', width: 80, editor:null, menuDisabled: true,locked:false},
                        {text: pdtTeamText, dataIndex: 'pdtTeam', width: 140, editor:null, menuDisabled: true,locked:false},
                        {text: partLibraryNumberText, dataIndex: 'partLibraryNumber', width: 140, editor:null, menuDisabled: true},
                        {text: controllerPointsText, dataIndex: 'controllerPoints', width:   140, editor:null, menuDisabled: true},
                        {text: priorityText, dataIndex: 'priority', width: 80,  editor:null, menuDisabled: true},
                        {text: otherFactoryPartStatusText, dataIndex: 'otherFactoryPartStatus', width: 140,  editor:null, menuDisabled: true},
                        {text: volumeText, dataIndex: 'volume', width: 80, editor:allowEditCommercialDirector?'textfield':null, menuDisabled: true},
                        {text: taxTypeCodeText, dataIndex: 'taxTypeCode', width: 140, editor:null, menuDisabled: true},
                        {text: longTextText, dataIndex: 'longText', width: 80,  editor:null, menuDisabled: true},
                    ]
                },
                {
                    text: '组织架构',
                    columns:[
                        {text: factoryText, dataIndex: 'factory', width: 60, editor:allowEditFollow? factoryCombo:null, menuDisabled: true},
                        {text: saleOrganizationText, dataIndex: 'saleOrganization', width: 80, editor:allowEditManager||allowEditCommercialDirector?saleOrganizationTextCombo:null, menuDisabled: true},
                        {text: channelsText, dataIndex: 'channels', width: 80,editor:allowEditManager||allowEditCommercialDirector?channelsTextCombo:null, menuDisabled: true},
                    ]
                },
                {
                    text: '销售视图',
                    columns:[
                        {text: deliveryFactoryText, dataIndex: 'deliveryFactory', width: 80, editor:allowEditFollow? deliveryFactoryTextCombo:null, menuDisabled: true},
                        {text: taxTypeText, dataIndex: 'taxType', width: 80, editor:allowEditCommercialDirector?taxTypeCombo:null, menuDisabled: true},
                        {text: subjectGroupText, dataIndex: 'subjectGroup', width: 130, editor:null, menuDisabled: true},
                        {text: projectTypeGroupText, dataIndex: 'projectTypeGroup', width: 130, editor:null, menuDisabled: true},
                        {text: loadGroupText, dataIndex: 'loadGroup', width: 80, editor: null, menuDisabled: true},
                    ]
                },
                {
                    text: '采购视图',
                    columns:[
                        {text: purchaseGroupText, dataIndex: 'purchaseGroup', width: 80, editor: allowEditPurchaseFollow?'textfield':null, menuDisabled: true},
                        {text: autoBuyListText, dataIndex: 'autoBuyList', width: 80, editor: allowEditPurchaseFollow?'textfield':null, menuDisabled: true},
                        {text: sourceListText, dataIndex: 'sourceList', width: 80, editor:allowEditPurchaseFollow?sourceListCombo:null, menuDisabled: true},
                    ]
                },
                {
                    text: '质量视图',
                    columns:[
                        {text: checkTypeText, dataIndex: 'checkType', width: 80, editor: allowEditIQCDirector?'textfield':null, menuDisabled: true},
                    ]
                },
                {
                    text: '认证视图',
                    columns:[
                        {text: certificationTypeText, dataIndex: 'certificationType', width: 80, editor: allowEditCertificationDirector?'textfield':null, menuDisabled: true},
                    ]
                },
                {
                    text: 'MRP1',
                    columns:[
                        {text: stockLogoText, dataIndex: 'stockLogo', width: 80, editor: allowEditFollow?stockLogoCombo:null, menuDisabled: true},
                        {text: mrpTypeText,dataIndex: 'mrpType',  width: 120, editor:allowEditFollow?mrpTypeCombo:null, menuDisabled: true},
                        {text: mrpControllerText, dataIndex: 'mrpController', width: 120, editor: allowEditFollow?mrpControllerCombo:null, menuDisabled: true},
                        {text: lotSizeText, dataIndex: 'lotSize', width: 80, editor: allowEditFollow?lotSizeCombo:null, menuDisabled: true},
                        {text: miniLotText, dataIndex: 'miniLot', width: 80, editor: allowEditFollow?'textfield':null, menuDisabled: true},
                        {text: assemblyScrapText, dataIndex: 'assemblyScrap', width: 80, editor: allowEditFollow?'textfield':null, menuDisabled: true},
                        {text: roundingText, dataIndex: 'rounding', width: 80, editor: allowEditFollow?'textfield':null, menuDisabled: true},
                    ]
                },
                { text: 'MRP2',
                    columns:[
                        {text: acquisitionTypeText, dataIndex: 'acquisitionType',  width: 80, editor:allowEditFollow?acquisitionTypeCombo2:null, menuDisabled: true},
                        {text: specialTypeText, dataIndex: 'specialType',  width: 140, editor: allowEditFollow?specialTypeCombo:null, menuDisabled: true},
                        {text:goLogoText, dataIndex: 'goLogo',  width: 80, editor: allowEditFollow?goLogoCombo:null, menuDisabled: true},
                        {text: bulkPartText, dataIndex: 'bulkPart',  width: 80, editor:allowEditFollow?bulkPartCombo:null, menuDisabled: true},
                        {text: productionLocationText, dataIndex: 'productionLocation',  width: 140, editor: allowEditFollow?productionLocationCombo:null, menuDisabled: true},
                        {text: outBuyStorageLocationText, dataIndex: 'outBuyStorageLocation',  width: 140, editor:allowEditFollow?outBuyStorageLocationCombo:null, menuDisabled: true},
                        {text: planMarginalCodeText, dataIndex: 'planMarginalCode',  width: 80, editor: null, menuDisabled: true},
                        {text: selfProductionTimeText, dataIndex: 'selfProductionTime',  width: 80, editor:allowEditFollow?'textfield':null, menuDisabled: true},
                        {text:planDeliveryTimeText, dataIndex: 'planDeliveryTime',  width: 80, editor: allowEditFollow?'textfield':null, menuDisabled: true},
                        {text: receiptTimeText, dataIndex: 'receiptTime',  width: 80, editor:allowEditFollow?'textfield':null, menuDisabled: true},
                        {text: safeStockText, dataIndex: 'safeStock',  width: 80, editor:allowEditFollow?'textfield':null, menuDisabled: true},
                    ]
                },
                {
                    text: 'MRP3',
                    columns:[
                        {text: policyGroupText, dataIndex: 'policyGroup',  width: 80, editor:null, menuDisabled: true},
                        {text: consumptionPatternText, dataIndex: 'consumptionPattern',  width: 80, editor:null, menuDisabled: true},
                        {text: reverseConsumptionText,dataIndex: 'reverseConsumption',   width: 80, editor:null, menuDisabled: true},
                        {text: periodConsumptionText, dataIndex: 'periodConsumption',  width: 80, editor:null, menuDisabled: true},
                        {text: availabilityCheckText, dataIndex: 'availabilityCheck',  width: 80, editor:null, menuDisabled: true},
                    ]
                },
                {
                    text: 'MRP4',
                    columns:[
                        {text: independentLogoText,  dataIndex: 'independentLogo', width: 80, editor:null, menuDisabled: true},
                        {text: bomScrapText,  dataIndex: 'bomScrap', width: 80, editor:allowEditFollow?'textfield':null, menuDisabled: true},
                        {text: discontinueLogoText,   dataIndex: 'discontinueLogo',width: 80, editor:allowEditFollow? discontinueLogoCombo:null, menuDisabled: true},
                        {text: effectiveTimeText,  dataIndex: 'effectiveTime', width: 80, editor: allowEditFollow?'datefield':null, menuDisabled: true,
                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                                return value;
                            }},
                        {text: subsequentPartText,   dataIndex: 'subsequentPart',width: 80, editor: allowEditFollow?'textfield':null, menuDisabled: true},
                    ]
                },
                {
                    text: '工作计划',
                    columns:[
                        {text: productionManagerText,  dataIndex: 'productionManager', width: 80, editor:null, menuDisabled: true},
                        {text: productionPlanListText,  dataIndex: 'productionPlanList', width: 80, editor:null, menuDisabled: true},
                        {text:numberListText,   dataIndex: 'numberList',width: 80, editor:allowEditFollow?numberListCombo:null, menuDisabled: true},
                        {text: unitCodeText, dataIndex: 'unitCode',  width: 80, editor:allowEditFollow?'textfield':null, menuDisabled: true},
                    ]
                },
                {
                    text: '会计/成本视图',
                    columns:[
                        {text: accessTypeText, dataIndex: 'accessType', width: 80, editor: null, menuDisabled: true},
                        {text: priceControlText, dataIndex: 'priceControl', width: 80, editor:null, menuDisabled: true},
                        {text: standardPriceText, dataIndex: 'standardPrice', width: 80, editor:allowEditTreasurer?'textfield':null, menuDisabled: true},
                        {text: priceMovingText,dataIndex: 'priceMoving',  width: 80, editor:allowEditTreasurer?'textfield':null, menuDisabled: true},
                        {text: priceUnitText, dataIndex: 'priceUnit', width: 80, editor:null, menuDisabled: true},
                        {text: costEstimationText, dataIndex: 'costEstimation', width: 80, editor:allowEditTreasurer?'textfield':null, menuDisabled: true},
                        {text: partSourceText, dataIndex: 'partSource', width: 80, editor:allowEditTreasurer?'textfield':null, menuDisabled: true},
                        {text: profitCenterText,  dataIndex: 'profitCenter',width: 80, editor:null, menuDisabled: true},
                    ]
                },
                {
                    text: '物料认证',
                    columns:[
                        {text: partCertificationResponsible, dataIndex: 'partCertificationResponsible', width: 130, editor: partCertificationResponsibleEdit?personLiableCom:false, menuDisabled: true},
                        {text: partAuthenticationMethod, dataIndex: 'partAuthenticationMethod', width: 130, editor: partMethodAndLink?partAuthenticationMethodCombo:false, menuDisabled: true},
                        {text: certificationDocumentLink, dataIndex: 'certificationDocumentLink', width: 130, editor: partMethodAndLink?true:false, menuDisabled: true,
                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';

                                if(value) {
                                    var docLink = "<a href='" + urlPathPrefix +record.get('docBranchId') +"' target='_blank' >"
                                        + value + "</a>";
                                    return docLink;
                                }else {
                                    return value;
                                }
                            }
                        }
                    ]
                },
                {text: '',  width: 20, menuDisabled: true},
            ],
            // tbar:[{
            //     text:'查看',
            //     handler:function(){
            //         let selectionArr = partExampleGrid.getSelectionModel().getSelection();
            //         if (selectionArr.length==0){
            //             Ext.Msg.alert("提示","请选择要查看的数据");
            //             return;
            //         }if (selectionArr.length<1){
            //             Ext.Msg.alert("提示","请选择要查看的数据");
            //             return;
            //         }
            //         var myWindow = Ext.create('Ext.Window', {
            //             id: 'workReportWin',
            //             title: '物料信息',
            //             width: 1000,
            //             height: 700,
            //             closeAction: 'destroy',
            //             autoScroll: true,
            //             constrain: true,
            //             modal: true,
            //             items: [{xtype:'ctPartExtendInfoSingle'}]
            //         });
            //         myWindow.show();
            //     }
            // }]
            tbar:[{
                text:'导出可用于导入到SAP物料接口的数据',
                hidden:!isAdmin,
                handler:function(){
                    exportData();
                }
            }]
        });
        partExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                if (tField=='factory'){
                    var eField='mrpController';
                    tRecord.set(eField, '');
                }else if (tField=='saleOrganization'){
                    var eField='channels';
                    tRecord.set(eField, '');
                }else if (tField=='productionLocation'){
                    var eField='outBuyStorageLocation';
                    tRecord.set(eField, '');
                }else if (tField=='acquisitionType'){
                    let value=e.value;
                    let partType=tRecord.data['partType'];
                    if(value=="E-自制"){
                        tRecord.data['priceControl']="S-标准价(成品/半成品)";
                        if(partType!="Z030"&&partType!="Z031"&&partType!="Z032"){
                            tRecord.data['checkType']="";
                        }
                    }else {
                        tRecord.data['priceControl']="V-移动平均价(其它物料)";
                        if(partType!="Z030"&&partType!="Z031"&&partType!="Z032"){
                            tRecord.data['checkType']="01-来料检验";
                        }
                    }
                }

                 var callbackFn = function () {
                            tRecord.commit();
                     if (tField=='partCertificationResponsible') {
                         Ext.getStore('ctPartExtendInfoStore').reload()
                     }
                     if (tField=='certificationDocumentLink') {
                         Ext.getStore('ctPartExtendInfoStore').reload()
                     }
                };

                updateProblem(tRecord.data,callbackFn);
            });
         partExampleGrid.on('beforeedit',
             function (editor, e) {
                 var tRecord = e.record; //得到当前行所有数据
                 id =tRecord.get("id");
                 var newVar = tRecord.get('factory');
                 var newChannels = tRecord.get('saleOrganization');
                 var newOutBuyStorageLocation = tRecord.get('productionLocation');
                 mrpControllerTextStore.load({
                     params: {
                         key:'factory',
                         data:newVar,
                     }
                 });
                 channelsTextStore.load({
                     params: {
                         key:'0',
                         data:newChannels,
                     }
                 });
                 outBuyStorageLocationStore.load({
                     params: {
                         key:'1',
                         data:newOutBuyStorageLocation,
                     }
                 });
                 var partAuthenticationMethod = tRecord.get('partAuthenticationMethod');
                 // 判断点击的是哪一列，列名
                 var columnName = e.column.dataIndex;
                 if (!(partAuthenticationMethod === "系列认证流程")&& columnName === 'certificationDocumentLink') {
                     return false; // 禁止编辑指定列
                 }
                 if(partAuthenticationMethod === "不适用"&&(columnName === 'partCertificationResponsible'||
                     columnName === 'partAuthenticationMethod'||
                     columnName === 'certificationDocumentLink')){
                     return false; // 禁止编辑指定列
                 }


             });


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [partExampleGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function (editor,e) {
            Ext.getStore('ctPartExtendInfoStore').load({
                params: {
                    proOid:proOid//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });


        }
    }
});

/**
 * 导出
 */
function exportData() {
    // 获取XMLHttpRequest
    var xmlHttpRequest = new XMLHttpRequest();
    //  发起请求
    xmlHttpRequest.open("POST", '/Windchill/ptc1/ctPart/exportData?proOid=' + proOid, true);
    // 设置请求头类型
    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
    xmlHttpRequest.responseType = "blob";
    //  返回
    xmlHttpRequest.onload = function (oEvent) {
        var content = xmlHttpRequest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).message)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            var fileNamePrefix = '物料主数据导入';
            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }
    };
    xmlHttpRequest.send();
}