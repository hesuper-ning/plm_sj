Ext.define('PLM.view.CtPartViewRefPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtPartViewRefPanel',
    border: false,
    autoScroll: false,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtPartViewRefPanel',
    initComponent: function () {
    	var showType = 0;
        Ext.define('CtPartViewRefModel', {
            extend: 'Ext.data.Model',
            fields: [
                'idA', 'partANumber', 'partAVersion', 'partAState', 'partANote', 'internalVersionA', 'createTimeA', 'modifyUserA',
                'modifyTimeA', 'idB', 'partBNumber', 'partBVersion', 'partBState', 'partBNote', 'internalVersionB', 'createTimeB',
                'modifyTimeB','modifyUserB','changeRecords','partABranchId','partBBranchId'
            ],
            idProperty: 'id'
        });

        Ext.create('Ext.data.Store', {
            model: 'CtPartViewRefModel',
            storeId: 'ctPartHistoryViewRefStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/view/queryPartHistoryLinkViewRef?partOid=' + oid,
                params: {showType: "0"},
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });

        let partColumns = [
            {text: '序号', width: 50, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
            {text: '物料编码', width: 110, dataIndex: 'partANumber', menuDisabled: false, align: 'center',
                renderer: function(value,metaData,record,row,col,store){
                    if(value) {
                        var docLink = "<a href='" + urlPathPrefix +record.get('partABranchId') +"' target='_blank' >"
                            + value + "</a>";
                        return docLink;
                    }else {
                        return value;
                    }
                }
            },
            {text: '版本', width: 150, dataIndex: 'partAVersion', menuDisabled: false, align: 'center'},
            {text: '状态', width: 85, dataIndex: 'partAState', menuDisabled: false, align: 'center'},
//            {text: '备注', width: 120, dataIndex: 'partANote', menuDisabled: false, align: 'center'},
//            {text: '内部版本', width: 120, dataIndex: 'internalVersionA', menuDisabled: false, align: 'center'},
//            {text: '创建时间', width: 120, dataIndex: 'createTimeA', menuDisabled: false, align: 'center'},
            {text: '上次修改时间', width: 120, dataIndex: 'modifyTimeA', menuDisabled: false, align: 'center'},
            {text: '修改者', width: 115, dataIndex: 'modifyUserA', menuDisabled: false, align: 'center'},
            {text: '物料编码', width: 110, dataIndex: 'partBNumber', menuDisabled: false, align: 'center',
            	renderer: function(value,metaData,record,row,col,store){
                    if(value) {
                        var docLink = "<a href='" + urlPathPrefix +record.get('partBBranchId') +"' target='_blank' >"
                            + value + "</a>";
                        return docLink;
                    }else {
                        return value;
                    }
                }	
            },
            {text: '版本', width: 150, dataIndex: 'partBVersion', menuDisabled: false, align: 'center'},
            {text: '状态', width: 85, dataIndex: 'partBState', menuDisabled: false, align: 'center'},
//            {text: '备注', width: 120, dataIndex: 'partBNote', menuDisabled: false, align: 'center'},
//            {text: '内部版本', width: 120, dataIndex: 'internalVersionB', menuDisabled: false, align: 'center'},
//            {text: '创建时间', width: 120, dataIndex: 'createTimeB', menuDisabled: false, align: 'center'},
            {text: '上次修改时间', width: 120, dataIndex: 'modifyTimeB', menuDisabled: false, align: 'center'},
            {text: '修改者', width: 115, dataIndex: 'modifyUserB', menuDisabled: false, align: 'center'},
            {text: '变动记录', width: 120, dataIndex: 'changeRecords', menuDisabled: false, align: 'center'}
        ];
        let CtPartViewRefGrid = Ext.create('Ext.grid.Panel', {
            store: Ext.data.StoreManager.lookup('ctPartHistoryViewRefStore'),
            forceFit: false,
            height: 630,
            //width: 2500,
            autoWidth: true,
            title: '',
            id: 'CtPartViewRefGrid',
            viewConfig: {
                enableTextSelection: true
            },
            autoScroll: false,
            columns: partColumns,
            listeners: {}
//            tbar: [{
//                text: '显示全部',
//                hidden:false,
//                iconCls : 'icon',
////                iconCls : 'icon icon-store-export',
//                scope: this,
//                highlight: true,
//                id: "showAllBtn",
//                handler : function(){
//                	Ext.getCmp('showAllBtn').el.setStyle('background-image','-webkit-linear-gradient(top,#add8e6,#add8e6 40%,#add8e6 30%,#add8e6)');
//                	Ext.getCmp('showChangesBtn').el.setStyle('background-image','');
//                	Ext.getCmp('showChangeBtn').el.setStyle('background-image','');
////                	Ext.getCmp('showAllBtn').el.setStyle('color','#4245ff');
//                	Ext.getStore('ctPartHistoryViewRefStore').reload({
//                        params: {
//                        	showType: "0"
//                        }
//                    });
//                }
//            },{
//                text: '显示变动',
//                hidden:false,
//                iconCls : 'icon',
////                iconCls : 'icon icon-store-export',
//                scope: this,
//                highlight: true,
//                id: "showChangeBtn",
//                handler : function(){
//                	Ext.getCmp('showChangeBtn').el.setStyle('background-image','-webkit-linear-gradient(top,#add8e6,#add8e6 40%,#add8e6 30%,#add8e6)');
//                	Ext.getCmp('showAllBtn').el.setStyle('background-image','');
//                	Ext.getCmp('showChangesBtn').el.setStyle('background-image','');
//                	//Ext.getCmp('showAllBtn').el.setStyle('color','#4245ff');
//                	Ext.getStore('ctPartHistoryViewRefStore').reload({
//                        params: {
//                        	showType: "1"
//                        }
//                    });
//                }
//            },{
////                iconCls: 'icon icon-store-export',
//                iconCls : 'icon',
//                xtype: 'button',
//                id: "showChangesBtn",
//                text: '显示最新',
//                scope: this,
//                handler:function () {
//                	Ext.getCmp('showChangesBtn').el.setStyle('background-image','-webkit-linear-gradient(top,#add8e6,#add8e6 40%,#add8e6 30%,#add8e6)');
//                	Ext.getCmp('showAllBtn').el.setStyle('background-image','');
//                	Ext.getCmp('showChangeBtn').el.setStyle('background-image','');
//                	Ext.getStore('ctPartHistoryViewRefStore').reload({
//                        params: {
//                        	showType: "2"
//                        }
//                    });
//                }
//            },{
//                text: '导出报表',
//                hidden:false,
////                iconCls : 'icon icon-store-export',
//                iconCls : 'icon',
//                scope: this,
//                handler : function(){
//                	alert(33);
//                    var gridSize = CtPartViewRefGrid.getStore().getTotalCount();
//                    if(gridSize == 0){
//                        alert("列表没数据,请不用导出！");
//                        return;
//                    }
//                    window.location.href="/Windchill/ptc1/ec/exportChangeItems?changeRequestId="+changeRequestId+"&type=mbom";
//                }
//            }
////            ,'&nbsp;',{
////                text: '下载模板',
////                hidden:false,
////                iconCls : 'icon icon-download',
////                scope: this,
////                handler : function(){
////                    window.location.href = '/Windchill/ptc1/ec/downLoadTemplate?templateName=MBOM变更内容导入模板';
////                }
////            }
//            ]
            
        });
        this.items = [CtPartViewRefGrid];
        this.callParent();
    },
    listeners: {
        'afterrender': function () {
            //loadCombobox();
            //loadPartStore();
        }
    }
});