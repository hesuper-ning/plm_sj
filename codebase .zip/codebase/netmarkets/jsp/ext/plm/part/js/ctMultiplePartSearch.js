Ext.define('PLM.view.MultiplePartSearchPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MultiplePartSearchPanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'MultiplePartSearchPanel',
    initComponent: function () {
        var me = this;
        //========== 开始  multiplePartGrid================
        Ext.define('multiplePartModel', {
            extend: 'Ext.data.Model',
            fields: [
                'partNumber', 'partVersion', 'partName', 'partState'
            ],
            idProperty: 'partNumber'
        });

        // create the Data Store
        this.multiplePartStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'multiplePartModel',
            id: 'multiplePartStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/view/searchPart',
                params: {},
                timeout: 60000,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        //选择的表格的Store
        var resultStore = new Ext.data.ArrayStore({
            model: 'multiplePartModel',
            id: 'resultStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/view/getSelectNumbers?selectNumbers=' + (window.opener.document.getElementById(attName).value==''?selectNumbers:window.opener.document.getElementById(attName).value),
                params: {},
                timeout: 60000,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });

        var multiplePartGrid = Ext.create('Ext.grid.Panel', {
            store: Ext.getStore('multiplePartStore'),
            id: 'multiplePartGrid',
            margin: '20 10 20 0',
            title: '搜索结果',
            //titleAlign: 'left',
            //forceFit: true,
            width: '100%',
            height: 245,
            autoScroll: true,
            viewConfig: {enableTextSelection: true},
            selModel: Ext.create('Ext.selection.CheckboxModel', {
                mode: 'SIMPLE',
                checkOnly: true,
                showHeaderCheckbox: true
            }),
            listeners: {
                select: function(combo, record, index){
                    let resultStore = Ext.getCmp('resultPartGrid').getStore();
                    resultStore.add(record.getData());
                }
            },
            columns: [
                {text: '编号', dataIndex: 'partNumber', flex: 1, menuDisabled: true},
                {text: '版本', dataIndex: 'partVersion', flex: 1, menuDisabled: true},
                {text: '名称', dataIndex: 'partName', flex: 1, menuDisabled: true},
                {text: '状态', dataIndex: 'partState', flex: 1, menuDisabled: true},

            ]//~end of tbar
        });

        var resultPartGrid = Ext.create('Ext.grid.Panel', {
            store: Ext.getStore('resultStore'),
            id: 'resultPartGrid',
            margin: '20 10 20 0',
            title: '选择的部件',
            //titleAlign: 'left',
            //forceFit: true,
            width: '100%',
            height: 247,
            autoScroll: true,
            viewConfig: {enableTextSelection: true},
            selModel: Ext.create('Ext.selection.CheckboxModel', {
                mode: 'SIMPLE',
                checkOnly: true,
                showHeaderCheckbox: true
            }),
            columns: [
                {text: '编号', dataIndex: 'partNumber', flex: 1, menuDisabled: true},
                {text: '版本', dataIndex: 'partVersion', flex: 1, menuDisabled: true},
                {text: '名称', dataIndex: 'partName', flex: 1, menuDisabled: true},
                {text: '状态', dataIndex: 'partState', flex: 1, menuDisabled: true},
            ],//~end of tbar
            tbar: [
                {
                    text: '删除行',
                    iconCls: 'icon icon-delete',
                    disabled:false,
                    handler: function () {
                        let selected = resultPartGrid.getSelectionModel().getSelection();
                        if (selected.length === 0) {
                            alert('请选择数据！');
                        } else {
                            resultPartGrid.getStore().remove(selected);
                            resultPartGrid.view.refresh();
                        }
                    },
                    scope: this
                }
            ]
        });

        var queryParameter = {
            title: '查询参数',
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [
                {
                    xtype: 'container',
                    layout: 'hbox',
                    defaultType: 'textfield',
                    margin: '10 0 10 10',
                    items: [
                        {
                            margin: '0 20 0 0',
                            fieldLabel: '编号或物料描述',
                            labelWidth: 90,
                            id: 'partNumber',
                            name: 'partNumber',
                            width: 300,
                        },
                        {
                            xtype: 'button',
                            margin: '0 20 0 0',
                            text: '查询',
                            name: 'search',
                            width: 70,
                            handler: function () {
                                doSearch();
                            }
                        },
                        {
                            xtype:'button',
                            margin: '0 20 0 0',
                            text: '确定',
                            hidden: hideFlag,
                            width: 70,
                            handler: function () {
                                var resultPartGrid = Ext.getCmp('resultPartGrid');
                                var tmpSm = resultPartGrid.getSelectionModel().getSelection();
                                if (!tmpSm || tmpSm == '') {
                                    Ext.Msg.alert('提示', '未选择数据！');
                                    return;
                                }
                                let partNumbers = "";
                                for(let i = 0;i < tmpSm.length;i++){
                                    if(i == 0){
                                        partNumbers = tmpSm[i]['id'];
                                    }else{
                                        partNumbers += ',' + tmpSm[i]['id'];
                                    }
                                }
                                window.opener.document.getElementById(attName).value = partNumbers;
                                window.close();
                            }
                        }
                    ]
                }
            ]
        };
/////////////////////////Main Panel items//////////////////////////////////
        this.items = [queryParameter, multiplePartGrid, resultPartGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {

        }
    }
});

/**
 * 查询制造商
 * @param params 参数参数
 */
function doSearch() {
    var multiplePartStore = Ext.getStore('multiplePartStore');
    var params = getParams();
    multiplePartStore.load({
        params: params,
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    alert('查询超时！请重试！')
                }
            } else {

            }
        }
    });
}

/**
 * 获取查询参数
 */
function getParams() {
    var params = {
        partNumber: Ext.getCmp('partNumber').getValue()
    };
    return params;
}




