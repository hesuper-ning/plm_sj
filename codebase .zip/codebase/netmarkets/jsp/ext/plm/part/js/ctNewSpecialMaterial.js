Ext.define('PLM.view.ctNewSpecialMaterialPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.ctNewSpecialMaterialPanel',
    border:false,
    layout: {
        type: 'border',
        //  padding: Ext.themeName === 'neptune' ? 8 : 5 // match padding to theme splitter size
    },
    defaults: {
        collapsible: true,
        split      : true
    },
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'ctNewSpecialMaterialPanel',
    initComponent:function() {

        var mainPanel = {
            xtype: 'form',
            height: 400,
            border: false,
            padding: 10,
            // margin: '20 20 20 20',
            items: [{
                border: false,
                html: '<div style="font-weight:bold ;font-size:22px;top:50px;left:50px;;text-align:center">新建试产专用料</div>'
                //margin: '50 50 50 120'
            }, {
                xtype: 'displayfield',
                // margin:'0 30 0 10',
                id: 'partDesc',
                fieldLabel: '原物料编码',
                width: 200,
                labelWidth: 70,
                value: orgPartNumber
            }, {
                xtype: 'displayfield',
                // margin:'0 30 0 10',
                fieldLabel: '原物料名称',
                width: 200,
                labelWidth: 70,
                value: orgPartName
            }, {
                xtype: 'displayfield',
                fieldLabel: '新编码',
                width: 200,
                labelWidth: 70,
                id: 'newPartNumber',
                name: 'newPartNumber'
            }, {
                xtype: 'textfield',
                fieldLabel: '新物料名称',
                width: 400,
                labelWidth: 70,
                id: 'newPartName',
                name: 'newPartName',
                value: orgPartName
            }, {
                xtype: 'panel',
                layout: 'hbox',
                border: false,
                margin: '30 50 50 20',
                items: [{
                    xtype: 'button',
                    text: '确定',
                    scale: 'medium',
                    id: 'confirmCreate',
                    name: 'confirmCreate',
                    handler: function () {
                        createNewPart();
                    }
                }, {
                    xtype: 'button',
                    text: '关闭',
                    scale: 'medium',
                    margin: '0 0 0 30',
                    handler: function () {
                        window.close();
                    }
                }]
            }]
        }

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                region: 'center',
                collapsible: false,
                height: '70%',
                items: [mainPanel],
                id: 'centerPanel'
            }
        ];
        this.callParent();//
    },//~End of initComponent
    listeners:{
        'afterrender':function () {
            //加载新编码
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ctPart/getNewSpecialMaterialNumber?orgPartNumber='+orgPartNumber,
                success:function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (!obj['success']) {
                        alert(obj['msg']);
                        Ext.getCmp('confirmCreate').setDisabled(true);
                        return;
                    }
                    //设置表单值
                    Ext.getCmp('newPartNumber').setValue(obj['newPartNumber']);
                },
                failure: function(response, opts) {
                    alert('错误：处理超时，请检查网络！');
                }


            });

        }
    }
    });

//=================Functions==================
//创建物料
function createNewPart() {

    const newPartName = Ext.getCmp("newPartName").getValue();
    const  newPartNumber  = Ext.getCmp("newPartNumber").getValue();

    Ext.Ajax.request({
        url: '/Windchill/ptc1/ctPart/createSpecialMaterial',
        params:{
            orgPartNumber:orgPartNumber,
            newPartName:newPartName,
            newPartNumber:newPartNumber
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);

            if(!obj['success']){
                alert(obj['msg']);
                return;
            }else{
                Ext.getCmp('confirmCreate').setDisabled(true);
                var part=obj['partOid'];
                // url=url+part;
                // Ext.getCmp("newPartLink").setValue("<span style='margin-right:10px'><a href="+url+" target='_Blank'>新建部件链接</a></span>");
                window.open("/Windchill/app/#ptc1/tcomp/infoPage?ContainerOid="+containerOid+"&oid="+part);
                window.close();
                // alert('创建成功！请关闭页面！');
            }
        },
        failure: function(response, opts) {
            alert('错误：处理超时，请检查网络！');
        }
    });
}