Ext.define('PLM.view.CtPartViewRefPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtPartViewRefPanel',
    border: false,
    autoScroll: false,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtPartViewRefPanel',
    initComponent: function () {

        Ext.define('CtPartViewRefModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'partNumber', 'partVersion', 'partState', 'modifyUser', 'createTime', 'modifyTime', 'partNote'
            ],
            idProperty: 'id'
        });

        Ext.create('Ext.data.Store', {
            model: 'CtPartViewRefModel',
            storeId: 'CtPartViewRefStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/view/queryPartViewRef?partOid=' + oid,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });

        let partColumns = [
            {text: '序号', width: 50, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
            {text: '编号', width: 120, dataIndex: 'partNumber', menuDisabled: false, align: 'center'},
            {text: '版本', width: 120, dataIndex: 'partVersion', menuDisabled: false, align: 'center'},
            {text: '状态', width: 120, dataIndex: 'partState', menuDisabled: false, align: 'center'},
            {text: '备注', width: 120, dataIndex: 'partNote', menuDisabled: false, align: 'center'},
            {text: '修改者', width: 120, dataIndex: 'modifyUser', menuDisabled: false, align: 'center'},
            {text: '创建时间', width: 120, dataIndex: 'createTime', menuDisabled: false, align: 'center'},
            {text: '上次修改时间', width: 120, dataIndex: 'modifyTime', menuDisabled: false, align: 'center'},
        ];

        let CtPartViewRefGrid = Ext.create('Ext.grid.Panel', {
            store: Ext.data.StoreManager.lookup('CtPartViewRefStore'),
            forceFit: false,
            height: 630,
            //width: 2500,
            autoWidth: true,
            title: '',
            id: 'CtPartViewRefGrid',
            viewConfig: {
                enableTextSelection: true
            },
            autoScroll: false,
            columns: partColumns,
            tbar: [],
            listeners: {}
        });
        this.items = [CtPartViewRefGrid];
        this.callParent();
    },
    listeners: {
        'afterrender': function () {
            //loadCombobox();
            //loadPartStore();
        }
    }
});