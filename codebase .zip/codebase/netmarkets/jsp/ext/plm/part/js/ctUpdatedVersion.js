Ext.define('PLM.view.ctUpdatedVersionPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.ctUpdatedVersionPanel',
    border:false,
    layout: {
        type: 'border',
        //  padding: Ext.themeName === 'neptune' ? 8 : 5 // match padding to theme splitter size
    },
    defaults: {
        collapsible: true,
        split      : true
    },
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'ctUpdatedVersionPanel',
    initComponent:function() {

        var mainPanel = {
            xtype: 'form',
            id: 'ctUpdatedVersionPanelForm',
            height: 400,
            border: false,
            padding: 10,
            // margin: '20 20 20 20',
            items: [{
                border: false,
                html: '<div style="font-weight:bold ;font-size:22px;top:50px;left:50px;;text-align:center">更新版本</div>'
                //margin: '50 50 50 120'
            }, {
                xtype: 'displayfield',
                // margin:'0 30 0 10',
                id: 'partDesc',
                fieldLabel: '详细信息',
                minWidth: 350,
                labelWidth: 70,
                value: partInfo['partName']
            }, {
                xtype: 'displayfield',
                // margin:'0 30 0 10',
                fieldLabel: '当前版本',
                width: 200,
                labelWidth: 70,
                value: partInfo['currentVersion']
            }, {
                xtype: 'textfield',
                fieldLabel: '新版本',
                width: 200,
                labelWidth: 70,
                id: 'newVersion',
                name: 'newVersion'
            }, {
                xtype: 'panel',
                layout: 'hbox',
                border: false,
                margin: '30 50 50 20',
                items: [{
                    xtype: 'button',
                    text: '提交',
                    scale: 'medium',
                    handler: function () {
                        // 校验新版本
                        var currentVersion = partInfo['currentVersion'];
                        var newVersion = Ext.getCmp('newVersion').getValue();
                        if (!newVersion) {
                            Ext.Msg.alert('提示', '请填写新版本！');
                            return;
                        }

                        if (currentVersion == undefined || !currentVersion) {
                            partInfo['newVersion'] = newVersion;
                            updatedVersion(partInfo);
                        } else {
                            if (currentVersion == newVersion) {
                                Ext.Msg.alert('提示', '新版本与当前版本一致，请重新填写！');
                                return;
                            }

                            // 获取第一个字符
                            var currentChar = currentVersion.substring(0, 1);
                            var newChar = newVersion.substring(0, 1);
                            if (currentChar.toLocaleUpperCase() == 'V' && newChar.toLocaleUpperCase() == 'V') {
                                // 校验新版本是否大于当前版本
                                try {
                                    var currentValue = parseFloat(currentVersion.substring(1));
                                    var newValue = parseFloat(newVersion.substring(1));
                                    if (newValue <= currentValue) {
                                        Ext.Msg.alert('提示', '新版本小于当前版本，请重新填写！');
                                        return;
                                    }
                                } catch (e) {
                                    console.log("当前版本或最新版本转成数值失败！");
                                }
                            }
                            partInfo['newVersion'] = newVersion;
                            updatedVersion(partInfo);
                        }
                    }
                }, {
                    xtype: 'button',
                    text: '重置',
                    scale: 'medium',
                    margin: '0 0 0 30',
                    handler: function () {
                        Ext.getCmp('ctUpdatedVersionPanelForm').getForm().reset();
                    }
                }]
            }]
        }

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                region: 'center',
                collapsible: false,
                height: '70%',
                items: [mainPanel],
                id: 'centerPanel'
            }
        ];
        this.callParent();//
    },//~End of initComponent
    listeners:{
        'afterrender':function () {
        }
    }
});

//=================Functions==================
//更新版本
function updatedVersion(params) {
    loadMask.show();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/adTool/updatedVersion',
        method: 'POST',
        params: params,
        success: function(response, opts) {
            loadMask.hide();
            var obj = Ext.decode(response.responseText);
            if(obj['status'] == 200){
                window.close();
                self.opener.location.reload();
            }else{
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            loadMask.hide();
            alert('错误：处理超时，请检查网络！');
        }
    });
}