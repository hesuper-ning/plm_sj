
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
%>

<iframe id="ctHumanResourceIframe" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"
        src="netmarkets/jsp/ext/plm/part/ctPartViewRef.jsp?oid=<%=oid%>" style="width:98%;height:900px" ></iframe>


<script type="text/javascript">
    var iframe = document.getElementById("ctPartFilterViewIframe");
    iframe.style.height = window.innerHeight*80/100 + 'px';
</script>