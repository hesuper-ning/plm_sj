<%@ page language="java" import="java.util.*"  contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
%>

<iframe id="example" src="netmarkets/jsp/ext/plm/problem/ctProblemShareInfo.jsp?oid=<%=oid%>" style="width:98%;height:730px" ></iframe>