
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>


<iframe id="ctProblemCollectReport" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"
        src="netmarkets/jsp/ext/plm/problem/ctProblemCollectReportPanel.jsp?" style="width:98%;height:600px" ></iframe>

<%--<script type="text/javascript">--%>
<%--    var iframe = document.getElementById("ctProblemCollectReport");--%>
<%--    iframe.style.height = window.innerHeight*80/100 + 'px';--%>
<%--</script>--%>