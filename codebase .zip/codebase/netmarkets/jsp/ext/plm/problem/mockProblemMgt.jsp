<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page import="wt.org.WTUser" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>oid="+oid);
        String userDisplayName = CtUserUtil.getCurrentUserDisplayName();


    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css" href="css/ablum.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctProblemMgtFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/mockProblemMgt.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/uploadImagePanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/showImageView.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
    //容器id
    var containerId = "<%=oid%>";
    //当前用户
    var userDisplayName = "<%=userDisplayName%>";
    //问题编号
    var problemId = "";
    //权限控制
    var allowEdit = true;
    //查询共享
    var share = '0';
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'MockExample'
            }]
        });
    });
</script>
</body>
</html>