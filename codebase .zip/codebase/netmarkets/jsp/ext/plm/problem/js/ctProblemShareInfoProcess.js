Ext.define('PLM.view.ProblemShareInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ProblemShareInfo',
    border: false,

    collapsible: false,
    id: 'ProblemShareInfo',
    initComponent: function () {
        Ext.define('ctProblemShareInfoModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'containerId', 'docBranchId', 'problemNumber', 'problemPhase', 'description', 'creator', 'problemTerritory', 'problemGrade',
                'optimizeStrategy', 'charger', 'targetSolveDate', 'startDate', 'processLink', 'projectPhase', 'analysis', 'imgs',
                'badProportion', 'problemSource', 'oaNumber', 'riskNumber', 'relatedProblemNumber', 'optimizeResult',
                'verifyReportOrNot', 'verifyReportLink', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'problemStatus',
                'confirmExplain', 'creatorDate', 'replenish','affirmCheck','pqaCheck'],
            idProperty: 'id'
        });

        Ext.define('ctProblemVerifyModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'problemTerritory', 'undertaker', 'optimizeStrategy', 'planFinishDate', 'optimizeResult',
                'verifyReportLink', 'verifyReportNumber', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'isAssign'],
            idProperty: 'id'
        });

        var me = this;


        var problemShareInfoStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemShareInfoModel',
            id: 'problemShareInfoStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/problemMgt/getItemByIsBranchId',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var problemVerifyStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemVerifyModel',
            id: 'problemVerifyStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1//problemMgt/getProblemVerifyInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ProblemVerifyGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('problemVerifyStore'),
            id: 'ProblemVerifyGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 400,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {
                    text: '子问题处理',
                    columns: [
                        {
                            text: '领域',
                            dataIndex: 'problemTerritory',
                            width: 90,
                            menuDisabled: true,
                        },
                        {text: '子问题承担者', dataIndex: 'undertaker', width: 100, menuDisabled: true,},
                        {
                            text: '初步对策',
                            dataIndex: 'optimizeStrategy',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '计划解决时间',
                            dataIndex: 'planFinishDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '改善结论',
                            dataIndex: 'optimizeResult',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '验证报告编号',
                            dataIndex: 'verifyReportNumber',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '检验报告链接',
                            dataIndex: 'verifyReportLink',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '实际解决时间',
                            dataIndex: 'realitySolveDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '不整改原因',
                            dataIndex: 'noChangeCause',
                            width: 100,
                            menuDisabled: true,
                        },
                    ],
                },
                {
                    text: '子问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'verifyExplain', width: 100, menuDisabled: true,},
                    ]
                },
                {text: '是否分配人', dataIndex: 'isAssign', width: 100, menuDisabled: true},

            ],
        });

        var followUp = Ext.create('Ext.Window', {
            id: 'followUp',
            title: '子问题跟进',
            width: 1250,
            height: 400,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [ProblemVerifyGrid],
        });

        //上传图片窗口
        var uploadImageWindow = Ext.create('Ext.Window', {
            title: '导入图片',
            width: 550,
            height: 350,
            //autoHeight : true,
            //autoWidth : true,
            closeAction: 'hide',
            id: 'uploadImageWindow',
            autoScroll: false,
            //closable:false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: {
                xtype: 'uploadImagePanel'
            }
        });

        //
        var editPanel = new Ext.create("Ext.form.Panel", {
            autoWidth: true,
            autoHeight: true,
            layout: 'form', // 最大表单
            margin: '0 20 0 0',
            autoScroll: true,
            border: false,
            buttonAlign: 'center',
            id: 'editPanel',
            items: [{
                xtype: "textfield",
                name: "id",
                hidden: true,
                id: "id",
                fieldLabel: "id"
            },
                { layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: "textarea",
                        margin: '10 0 10 0',
                        width: 350,
                        rows: 2,
                        maxLength:1200,
                        maxLengthText : "补充信息必须在1200字及以内!",
                        name: "replenish",
                        id: "replenish",
                        fieldLabel: "补充信息"
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        layout: 'hbox',
                        border: false,
                        margin: '5 5 10 30',
                        items: [{
                            xtype: 'button',
                            text: "图片上传",
                            margin: '0 20 0 0',
                            width: 260,
                            id: 'sctp',
                            name: 'sctp',
                            handler: function () {
                                var editRecords = Ext.getCmp('problemShareInfoGrid').getSelectionModel().getSelection();
                                problemId = editRecords[0].data['problemNumber']+'经验知识库';
                                containerId =  editRecords[0].data['containerId'];
                                uploadImageWindow.show();
                            }
                        }]
                    }]
                }]
        });
        var requireWin2 = Ext.create('Ext.Window', {
            id: 'requireWin2',
            title: '补充信息',
            width: 500,
            height: 250,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: editPanel,
            layout: "fit",
            bbar: {
                xtype: "toolbar",
                items: ['->', {
                    xtype: "button",
                    text: "保存",
                    width: 60,
                    listeners: {
                        "click": function (btn) {
                            save();
                            Ext.getCmp('requireWin2').close();
                        }
                    }
                }, {
                    xtype: "button",
                    width: 60,
                    text: "取消",
                    listeners: {
                        "click": function (btn) {
                            Ext.getCmp('requireWin2').close();
                        }
                    }
                }, '->']
            }
        });


        var problemShareInfoGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemShareInfoStore'),
            id: 'problemShareInfoGrid',
            margin: '10 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 200,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer',width:40},
                {
                    text: '问题提出',
                    columns: [
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'containerId', menuDisabled: true, hidden: true},
                        {text: '问题编号', dataIndex: 'problemNumber', width: 120,},

                        {text: '问题提出者', dataIndex: 'creator', width: 100, },
                        {text: '问题领域', dataIndex: 'problemTerritory', width: 100 ,renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        {text: '问题级别', dataIndex: 'problemGrade', width: 100, },
                        {text: '问题描述', dataIndex: 'description', width: 100,renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        {text: '初步原因分析', dataIndex: 'analysis', width: 100, renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        {text: '初步对策', dataIndex: 'optimizeStrategy', width: 100, renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        {text: '临时措施', dataIndex: 'temporaryMeasures', width: 100,renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        //{text: '问题承担者', dataIndex: 'charger', width: 100, editor: allUserCombo_projectPlan},
                        {
                            text: '计划完成时间',
                            dataIndex: 'planFinishDate',
                            width: 120,
                            menuDisabled: true,
                            align: 'center',
                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                            }
                        },
                        {text: '发起日期', dataIndex: 'startDate', width: 100,},
                        {text: '流程链接', dataIndex: 'processLink', width: 100, },
                        {text: '项目阶段', dataIndex: 'projectPhase', width: 100, },
                        {text: 'PQA', dataIndex: 'pqaCheck', width: 100, },
                        {text: '开发代表', dataIndex: 'affirmCheck', width: 100,},
                        {
                            text: '图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: [ {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    problemId = problemNumber;
                                    containerId = record.get('containerId');
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + container + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {
                            text: '不良比例（%）',
                            dataIndex: 'badProportion',
                            width: 120,
                            menuDisabled: true,
                        },
                        {text: '问题来源', dataIndex: 'problemSource', width: 100},

                        {text: '成品编号', dataIndex: 'endPartNumber', width: 100, },
                        {text: '产品编号', dataIndex: 'productNumber', width: 100, },
                        {text: 'OA编号', dataIndex: 'oaNumber', width: 100,},
                        {text: '风险编号', dataIndex: 'riskNumber', width: 100, },
                        {text: '相关问题编号', dataIndex: 'relatedProblemNumber', width: 100, },
                        {text: '软件领域问题承担者', dataIndex: 'softwareCharger', width: 140,},
                        {text: '硬件领域问题承担者', dataIndex: 'hardwareCharger', width: 140,},
                        {text: '工艺领域问题承担者', dataIndex: 'craftCharger', width: 140,},
                        {text: '结构领域问题承担者', dataIndex: 'fabricCharger', width: 140,},
                        {text: '测试领域问题承担者', dataIndex: 'testCharger', width: 140,},
                        {text: '质量领域问题承担者', dataIndex: 'qualityCharger', width: 140,},
                        {text: '采购领域问题承担者', dataIndex: 'purchaseCharger', width: 140,},
                        {text: '制造领域问题承担者', dataIndex: 'makeCharger', width: 140,},
                        {text: '市场领域问题承担者', dataIndex: 'bazaarCharger', width: 140,},
                        {text: '其他领域问题承担者', dataIndex: 'elseCharger', width: 140,},
                    ]
                },/* {
                    text: '问题处理',
                    columns: [
                        {text: '改善结论', dataIndex: 'optimizeResult', width: 100,},
                        {text: '验证报告链接', dataIndex: 'verifyReportLink', width: 100,},
                        {text: '实际解决时间', dataIndex: 'realitySolveDate', width: 100,},
                        {text: '不整改原因', dataIndex: 'noChangeCause', width: 100,},
                    ]
                }, {
                    text: '问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'verifyExplain', width: 100,},
                    ]
                },*/ {
                    text: '问题结论',
                    columns: [
                        {text: '问题状态', dataIndex: 'problemStatus', width: 100,},
                        {text: '确认说明', dataIndex: 'confirmExplain', width: 100,renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                    ]
                }, {
                    text: '知识库共享',
                    columns: [{
                        text: '共享', width: 100, dataIndex: 'isShare', menuDisabled: true, value: '已共享',
                        renderer: function (value) {
                            if (value == "1") {
                                value = '已共享'
                            } else {
                                value = "未共享"
                            }
                            return value;
                        }
                    },
                        {text: '补充信息', dataIndex: 'replenish', width: 100,renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        {
                            text: '补充信息图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: ['->', {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    containerId = record.get('containerId');
                                    problemId = problemNumber+'经验知识库';
                                    problemStatus = record.get('problemStatus');
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + containerId + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {text: '共享文档链接', dataIndex: 'shareLink', width: 100,}
                    ]
                },
            ],
            tbar: [
                {
                    hidden: actKey == "ActivityNode_ProblemShare_addDescription" ? false : true,
                    text: '补充问题背景及描述',
                    id: 'edit',
                    name: 'edit',
                    scope: this,
                    handler: function () {
                        var editRecords = Ext.getCmp('problemShareInfoGrid').getSelectionModel().getSelection();
                        if (editRecords.length == 0) {
                            alert("请选择要编辑的问题信息！")
                            return;
                        } else if (editRecords.length > 1) {
                            alert("只能编辑一个问题信息！")
                            return;
                        }
                        //ID
                        var id = editRecords[0].data['id'];

                        requireWin2.show();
                        getProblem(id);
                    }
                },
                {
                    text: '问题跟进信息',
                    scope: this,
                    handler: function () {
                        var newDocItems = new Array();
                        var removedRecords = problemShareInfoGrid.getSelectionModel().getSelection();

                        if (removedRecords == undefined || removedRecords == null || removedRecords.length == 0) {
                            alert("请选择对应的问题！");
                            return;
                        } else if (removedRecords.length > 1) {
                            alert("一次只能选择一个问题！");
                            return;
                        }
                        followUp.show();

                        getProblemVerifyInfo(removedRecords[0].get("docBranchId"));
                    }
                }]
        });


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [problemShareInfoGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('problemShareInfoStore').load({
                params: {
                    branchId: docBranchId,
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    }
});

function renderer(value, metaData, record, row, col, store) {

    //提示tip
    metaData.tdAttr = " data-qtip = '" + value + "'";
    return value;
}

/**
 * 按查询参数查询
 */
function doSearch() {

    Ext.getStore('problemShareInfoStore').reload({
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询共享信息失败，请联系管理员！');
            }
        }
    });
}

/**
 * 编辑
 */
function save() {

    var data = {
        id: Ext.getCmp('id').getValue(),
        replenish: Ext.getCmp('replenish').getValue(),
    }

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/editProblem',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                doSearch();
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

/**
 * 获取信息
 * @param id
 */
function getProblem(id) {
    if (id == undefined || id.length == 0) {
        return;
    }
    // 查询MockExample form表单数据
    Ext.Ajax.request({
        url: '/Windchill/ptc1/problemMgt/getItemById?id=' + id,
        method: 'GET',
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                var mainPanel = Ext.getCmp('editPanel');
                mainPanel.getForm().setValues(obj['data']);
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：查询信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//获取问题跟进信息
function getProblemVerifyInfo(branchId) {
    Ext.getStore('problemVerifyStore').load({
        params: {
            docBranchId: branchId,
        },
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    // alert('查询超时！请重试！')
                }
            }
        }
    });
}