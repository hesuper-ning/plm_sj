Ext.define('PLM.view.problemMgt', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.problemMgt',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'problemMgt',
    initComponent: function () {
        var me = this;

        /*//后台处理数据罩层
        var loadMarsk = new Ext.LoadMask(document.body, {
            msg : '正在处理，请稍候。。。。。。',
            removeMask : true// 完成后移除
        });
*/
        //问题数据模型
        Ext.define('ctProblemMgtModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'containerId', 'docBranchId', 'problemNumber', 'description', 'creator', 'problemTerritory', 'problemGrade',
                'optimizeStrategy', 'charger', 'planFinishDate', 'startDate', 'processLink', 'projectPhase', 'analysis', 'imgs','problemSourceTerritory',
                'badProportion', 'problemSource', 'oaNumber', 'riskNumber', 'relatedProblemNumber', 'optimizeResult',
                'verifyReportOrNot', 'verifyReportLink', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'problemStatus',
                'confirmExplain', 'creatorDate', 'isShare', "temporaryMeasures", "endPartNumber", "productNumber", 'shareLink', 'replenish',
                'softwareCharger', 'hardwareCharger', 'craftCharger', "fabricCharger", "testCharger", "qualityCharger", 'purchaseCharger', 'makeCharger',
                'bazaarCharger', 'elseCharger', 'pqaCheck', 'problemInput', 'affirmCheck'],
            idProperty: 'id'
        });

        //初始化加载数据
        var problemMgtStore = Ext.create('Ext.data.Store', {
            pageSize: 8,
            model: 'ctProblemMgtModel',
            id: 'problemMgtStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({

                url: '/Windchill/ptc1/problemMgt/getItems',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        problemMgtStore.on('beforeload', function (store, options) {
            var data = getSearchData();
            Ext.apply(problemMgtStore.proxy.extraParams, data);
        });

        Ext.define('ctProblemVerifyModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'problemTerritory', 'undertaker', 'optimizeStrategy', 'planFinishDate', 'optimizeResult',
                'verifyReportLink', 'verifyReportNumber', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'isAssign'],
            idProperty: 'id'
        });

        var problemVerifyStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemVerifyModel',
            id: 'problemVerifyStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1//problemMgt/getProblemVerifyInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectNumber', 'name'
            ],
            idProperty: 'projectNumber'
        });
        // 项目下拉
        var projectListStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectListStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/problemMgt/getProjectInfo',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });
        var allUserStore_projectPlan1 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan1'
        });
        var allUserStore_projectPlan2 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan2'
        });
        var allUserStore_projectPlan3 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan3'
        });
        var allUserStore_projectPlan4 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan4'
        });
        var allUserStore_projectPlan5 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan5'
        });
        var allUserStore_projectPlan6 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan6'
        });
        var allUserStore_projectPlan7 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan7'
        });
        var allUserStore_projectPlan8 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan8'
        });
        var allUserStore_projectPlan9 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan9'
        });
        var allUserStore_projectPlan10 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan10'
        });
        var allUserStore_projectPlan11 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan11'
        });
        var allUserStore_projectPlan12 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan12'
        });


        var problemTerritoryCombo = new Ext.form.ComboBox({
            name: 'problemTerritoryCombo',
            id: 'problemTerritoryCombo',
            multiSelect: true,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['软件', '软件'], ['硬件', '硬件'], ['工艺', '工艺'],
                ['结构', '结构'], ['测试', '测试'], ['质量', '质量'],
                ['采购', '采购'], ['制造', '制造'], ['市场', '市场'],
                ['其他', '其他']]
        });

        var allUserCombo_projectPlan = new Ext.form.ComboBox({
            name: 'allUserCombo_projectPlan',
            id: 'allUserCombo_projectPlan',
            valueField: 'userFullName',
            displayField: 'userFullName',
            queryMode: 'local',
            anyMatch: true,
            typeAhead: true,
            forceSelection: true,
            triggerAction: 'all',
            allowBlank: true,
            store: allUserStore_projectPlan,
        });

        var problemGradeCombo = new Ext.form.ComboBox({
            name: 'problemGradeCombo',
            id: 'problemGradeCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//严重，一般，轻微，N/A
            store: [['严重', '严重'], ['一般', '一般'], ['轻微', '轻微'],
                ['N/A', 'N/A']]
        });

        var problemSourceTerritoryCombo = new Ext.form.ComboBox({
            name: 'problemSourceTerritoryCombo',
            id: 'problemSourceTerritoryCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//非评审- 原理图及PCB评审- 结构评审- 软件评审- 总体方案评审- 需求规格评审- TR评审
            store: [['非评审', '非评审'], ['原理图及PCB评审', '原理图及PCB评审'], ['结构评审', '结构评审'],['软件评审', '软件评审']
                ,['总体方案评审', '总体方案评审'],['需求规格评审', '需求规格评审'],['TR评审', 'TR评审']]
        });

        var projectPhaseCombo = new Ext.form.ComboBox({
            name: 'projectPhaseCombo',
            id: 'projectPhaseCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//TR2， TR4，TR4A, TR5, TR6
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'groupName',
                    'groupName'
                ],
                data: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"], ["TR4-TR4A", "TR4-TR4A"],
                    ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"],['量产阶段','量产阶段']]
            }),
            /*store: [['TR2', 'TR2'],['TR4', 'TR4'],['TR4A', 'TR4A'],
                ['TR5', 'TR5'],['TR6','TR6']]*/
        });


        var problemSourceCombo = new Ext.form.ComboBox({
            name: 'problemSourceCombo',
            id: 'problemSourceCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//研发，质量，工艺，测试，生产、客诉，售后质量，制程异常，用户体验
            store: [['研发', '研发'], ['质量', '质量'], ['工艺', '工艺'], ['测试', '测试'],
                ['客诉', '客诉'], ['售后质量', '售后质量'], ['制程异常', '制程异常'], ['用户体验', '用户体验']]
        });


        //上传图片窗口
        var uploadImageWindow = Ext.create('Ext.Window', {
            title: '导入图片',
            width: 550,
            height: 350,
            //autoHeight : true,
            //autoWidth : true,
            closeAction: 'hide',
            id: 'uploadImageWindow',
            autoScroll: false,
            //closable:false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: {
                xtype: 'uploadImagePanel'
            }
        });


        //导入panel
        var uploadForm = new Ext.form.Panel({
            layout: 'form',
            id: 'uploadForm',
            name: 'uploadForm',
            width: 450,
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            border: 0,
            tbar: [{
                xtype: 'filefield',
                name: 'userfile',
                id: 'userfile',
                msgTarget: 'side',
                fieldLabel: '上传Excel文件',
                width: 280,
                anchor: '100%',
                buttonText: '选择文件..',
                buttonOnly: false,
                buttonMargin: '5 5 5 5'
            }, {
                xtype: 'button',
                padding: '5 5 5 5',
                id: 'technic_submit',
                //disabled: existManufacturingViewPart?false:true,
                text: '开始导入',
                handler: function () {
                    var mainForm = Ext.getCmp('uploadForm').getForm();
                    var furl = "";  //文件物理地址
                    var fname = ""; //文件名称
                    furl = Ext.getCmp("userfile").getValue();
                    //alert(furl);
                    if (furl == "") {
                        alert("请先选择文件！");
                        return false;
                    }

                    mainForm.submit({
                        scope: this,
                        url: '/Windchill/ptc1/problemMgt/importProblem?containerId=' + containerId,
                        waitMsg: '正在导入......',
                        waitTitle: '请等待',
                        //method : 'POST',
                        success: function (form, action) {
                            var obj = action.result;
                            if (obj.success) {
                                alert("导入成功");
                                // Ext.getCmp("uploadForm").hide();
                                // refreshProblem();
                                window.parent.location.reload();
                            } else {
                                alert(obj.msg);
                            }
                        },
                        failure: function (form, action) {
                            var obj = action.result;
                            alert(obj.msg);
                        },

                    });
                }
            }]
        });

        //导入窗口
        var uploadPlanWindow = new Ext.create('Ext.Window', {
            title: '导入问题',
            // width: 430,
            autoHeight: true,
            autoWidth: true,
            closeAction: 'hide',
            y: '10%',
            id: 'uploadProblemWindow',
            constrain: true,
            modal: true,
            layout: 'fit',
            //border : 0,
            items: uploadForm
        });

        var MRP1ViewPanel = {
            xtype: 'fieldset',
            title: 'MRP1',
            collapsed: true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'textfield',
                labelWidth: 100,
                fieldLabel: "fet",
                //readOnly:  true,
                name: 'mrpController',
                id: 'mrpController',
                width: 300,
                listeners: {}
            }]
        }

        //问题添加表单
        var addForm = new Ext.form.Panel({
            xtype: 'form',
            margin: '10 0 0 0',
            border: false,
            height: 600,
            autoScroll: true,
            items: [
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '所属产品库',
                            margin: '0 20 0 0',
                            queryMode: 'local',
                            enableRegEx: true,
                            width: 300,
                            id: 'PDMLinkProductName',
                            name: 'PDMLinkProductName',
                            labelWidth: 100,
                            value: PDMLinkProductName
                        },
                    ]
                },
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题领域',
                        margin: '0 20 0 0',
                        valueField: 'groupName',
                        displayField: 'groupName',
                        multiSelect: true,
                        anyMatch: true,
                        editable: false,
                        store: [['软件', '软件'], ['硬件', '硬件'], ['工艺', '工艺'],
                            ['结构', '结构'], ['测试', '测试'], ['质量', '质量'],
                            ['采购', '采购'], ['制造', '制造'], ['市场', '市场'],
                            ['其他', '其他']],
                        width: 300,
                        id: 'problemTerritory',
                        name: 'problemTerritory',
                        labelWidth: 100,
                        listeners: {
                            change: function (e) {
                                var territory = Ext.getCmp("problemTerritory").getValue();
                                territory.indexOf("软件") != -1 ? Ext.getCmp("softwareCharger").show() : Ext.getCmp("softwareCharger").hide();
                                territory.indexOf("硬件") != -1 ? Ext.getCmp("hardwareCharger").show() : Ext.getCmp("hardwareCharger").hide();
                                territory.indexOf("工艺") != -1 ? Ext.getCmp("craftCharger").show() : Ext.getCmp("craftCharger").hide();
                                territory.indexOf("结构") != -1 ? Ext.getCmp("fabricCharger").show() : Ext.getCmp("fabricCharger").hide();
                                territory.indexOf("测试") != -1 ? Ext.getCmp("testCharger").show() : Ext.getCmp("testCharger").hide();
                                territory.indexOf("质量") != -1 ? Ext.getCmp("qualityCharger").show() : Ext.getCmp("qualityCharger").hide();
                                territory.indexOf("采购") != -1 ? Ext.getCmp("purchaseCharger").show() : Ext.getCmp("purchaseCharger").hide();
                                territory.indexOf("制造") != -1 ? Ext.getCmp("makeCharger").show() : Ext.getCmp("makeCharger").hide();
                                territory.indexOf("市场") != -1 ? Ext.getCmp("bazaarCharger").show() : Ext.getCmp("bazaarCharger").hide();
                                territory.indexOf("其他") != -1 ? Ext.getCmp("elseCharger").show() : Ext.getCmp("elseCharger").hide();
                            }
                        }
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题来源（领域）',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [['研发', '研发'], ['质量', '质量'], ['工艺', '工艺'], ['测试', '测试'],
                            ['客诉', '客诉'], ['售后质量', '售后质量'], ['制程异常', '制程异常'], ['用户体验', '用户体验']],
                        width: 300,
                        id: 'problemSource',
                        name: 'problemSource',
                        labelWidth: 100
                    }
                    ]
                },

                , {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '项目名称',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'projectNumber',
                        displayField: 'name',
                        store: projectListStore,
                        anyMatch: true,
                        editable: false,
                        width: 300,
                        id: 'projectName',
                        name: 'projectName',
                        labelWidth: 100,
                        listeners: {
                            change: function (combo, newValue, oldValue) {
                                Ext.getCmp('projectNumber').setValue(newValue)
                            }
                        }
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '项目编号',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        width: 300,
                        id: 'projectNumber',
                        name: 'projectNumber',
                        labelWidth: 100,
                    }
                    ]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>项目阶段',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"], ["TR4-TR4A", "TR4-TR4A"],
                            ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"],['量产阶段','量产阶段']],
                        width: 300,
                        id: 'projectPhase',
                        name: 'projectPhase',
                        labelWidth: 100
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题级别',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [['严重', '严重'], ['一般', '一般'], ['轻微', '轻微'],
                            ['N/A', 'N/A']],
                        width: 300,
                        id: 'problemGrade',
                        name: 'problemGrade',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [/*{
                    xtype: 'combo',
                    fieldLabel: '<font color=red>*</font>问题承担者',
                    margin: '0 20 0 0',
                    multiSelect: false,
                    valueField: 'userFullName',
                    displayField: 'userFullName',
                    anyMatch: true,
                    editable: false,
                    store: allUserStore_projectPlan,
                    width: 300,
                    id: 'charger',
                    name: 'charger',
                    labelWidth: 100
                },*/ {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题提出者',
                        margin: '0 20 0 0',
                        valueField: 'userFullName',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        store: allUserStore_projectPlan,
                        width: 300,
                        id: 'creator',
                        name: 'creator',
                        labelWidth: 100
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题来源（评审）',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [['非评审', '非评审'], ['原理图及PCB评审', '原理图及PCB评审'], ['结构评审', '结构评审'],['软件评审', '软件评审']
                            ,['总体方案评审', '总体方案评审'],['需求规格评审', '需求规格评审'],['TR评审', 'TR评审']],
                        width: 300,
                        id: 'problemSourceTerritory',
                        name: 'problemSourceTerritory',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'datefield',
                        fieldLabel: '<font color=red>*</font>计划完成时间',
                        margin: '0 20 0 0',
                        width: 300,
                        minValue: new Date(),
                        format: 'Y-m-d',
                        id: 'planFinishDate',
                        name: 'planFinishDate',
                        labelWidth: 100
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '相关问题编号',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'relatedProblemNumber',
                        name: 'relatedProblemNumber',
                        labelWidth: 100,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('relatedProblemNumber').getValue();
                                //验证编号是否正确
                                if (value != "")
                                    var isCorrect = checkProblemNumber(value);
                                if (!isCorrect) {
                                    Ext.getCmp('relatedProblemNumber').setValue("");
                                }
                            }
                        }
                    }
                    ]
                },
                /* {
                     layout: 'hbox',
                     border: false,
                     margin: '5 5 10 30',
                     items: [{
                         xtype: 'textfield',
                         fieldLabel: '成品编号',
                         margin: '0 20 0 0',
                         width: 300,
                         id: 'endPartNumber',
                         name: 'endPartNumber',
                         labelWidth: 100,
                         listeners: {
                             blur: function (e) {
                                 var value = Ext.getCmp('endPartNumber').getValue();
                                 //验证编号是否正确
                                 var isCorrect = checkPartNumber(value);
                                 if (!isCorrect) {
                                     Ext.getCmp('endPartNumber').setValue("");
                                 } else {
                                     //产品型号获取
                                     var productNumber = getProductNumber(value);
                                     Ext.getCmp('productNumber').setValue(productNumber);
                                 }
                             }
                         }
                     }, {
                         xtype: 'displayfield',
                         fieldLabel: '产品型号',
                         margin: '0 20 0 0',
                         width: 300,
                         id: 'productNumber',
                         name: 'productNumber',
                         labelWidth: 100
                     }
                     ]
                 },*/
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'numberfield',
                        fieldLabel: '不良比例（%）',
                        margin: '0 20 0 0',
                        width: 300,
                        minValue: 0,
                        maxValue: 100,
                        id: 'badProportion',
                        name: 'badProportion',
                        labelWidth: 100
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '风险编号',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'riskNumber',
                        name: 'riskNumber',
                        labelWidth: 100,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('riskNumber').getValue();
                                //验证编号是否正确
                                if (value != "")
                                    var isCorrect = checkRiskNumber(value);
                                if (!isCorrect) {
                                    Ext.getCmp('riskNumber').setValue("");
                                }
                            }
                        }
                    },
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>PQA',
                        id: 'pqaCheck',
                        name: 'pqaCheck',
                        margin: '0 20 0 0',
                        valueField: 'userFullName',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        store: allUserStore_projectPlan11,
                        labelWidth: 100,
                        width: 300,
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>开发代表',
                        id: 'affirmCheck',
                        name: 'affirmCheck',
                        margin: '0 20 0 0',
                        valueField: 'userFullName',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        store: allUserStore_projectPlan12,
                        labelWidth: 100,
                        width: 300,
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        layout: 'hbox',
                        border: false,
                        margin: '5 5 10 30',
                        items: [{
                            xtype: 'button',
                            text: "图片上传",
                            margin: '0 20 0 0',
                            width: 260,
                            id: 'sctp',
                            name: 'sctp',
                            handler: function () {
                                uploadImageWindow.show();
                            }
                        }]
                    }]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>问题摘要',
                        maxLength: 1200,
                        maxLengthText: "问题描述必须在500字及以内!",
                        width: 620,
                        id: 'summaryOfIssues',
                        name: 'summaryOfIssues',
                        labelWidth: 100
                    }
                    ]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>问题描述',
                        maxLength: 1200,
                        maxLengthText: "问题描述必须在1200字及以内!",
                        width: 620,
                        id: 'description',
                        name: 'description',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>初步原因分析',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "初步原因分析必须在1200字及以内!",
                        id: 'analysis',
                        name: 'analysis',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '<font color=red>*</font>初步对策',
                        margin: '0 20 0 0',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "初步对策必须在1200字及以内!",
                        id: 'optimizeStrategy',
                        name: 'optimizeStrategy',
                        labelWidth: 100
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '临时措施',
                        margin: '0 20 0 0',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "临时措施必须在1200字及以内!",
                        id: 'temporaryMeasures',
                        name: 'temporaryMeasures',
                        labelWidth: 100
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'fieldset',
                        title: '领域问题责任人',
                        // hidden:allowEdit?false:true,
                        padding: '5',
                        collapsed: true,
                        collapsible: true,
                        titleCollapse: false,
                        hideCollapseTool: false,
                        anchor: '100%',
                        defaults: {
                            padding: '2 10 2 10',
                            labelWidth: 100,
                            border: false
                        },
                        items: [
                            {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>硬件领域问题承担者',
                                    id: 'hardwareCharger',
                                    name: 'hardwareCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan1,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>软件领域问题承担者',
                                    id: 'softwareCharger',
                                    name: 'softwareCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan2,
                                    labelWidth: 130,
                                    margin: '0 0 0 30',
                                    width: 280,

                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>结构领域问题承担者',
                                    id: 'fabricCharger',
                                    name: 'fabricCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan3,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>工艺领域问题承担者',
                                    id: 'craftCharger',
                                    name: 'craftCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan4,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,

                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>测试领域问题承担者',
                                    id: 'testCharger',
                                    name: 'testCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan5,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>质量领域问题承担者',
                                    id: 'qualityCharger',
                                    name: 'qualityCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan6,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>采购领域问题承担者',
                                    id: 'purchaseCharger',
                                    name: 'purchaseCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan7,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>制造领域问题承担者',
                                    id: 'makeCharger',
                                    name: 'makeCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan8,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>市场领域问题承担者',
                                    id: 'bazaarCharger',
                                    name: 'bazaarCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan9,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>其他领域问题承担者',
                                    id: 'elseCharger',
                                    name: 'elseCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan10,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            },]
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        margin: '0 10 0 0',
                        xtype: 'button',
                        id: 'save',
                        text: '保存',
                        handler: function () {
                            var data = {
                                containerId: containerId,
                                description: Ext.getCmp('description').getValue(),
                                problemTerritory: Ext.getCmp('problemTerritory').getValue(),
                                problemGrade: Ext.getCmp('problemGrade').getValue(),
                                projectPhase: Ext.getCmp('projectPhase').getValue(),
                                optimizeStrategy: Ext.getCmp('optimizeStrategy').getValue(),
                                pqaCheck: Ext.getCmp('pqaCheck').getValue(),
                                //charger: Ext.getCmp('charger').getValue(),
                                creator: Ext.getCmp('creator').getValue(),
                                planFinishDate: Ext.getCmp('planFinishDate').getValue(),
                                analysis: Ext.getCmp('analysis').getValue(),
                                badProportion: Ext.getCmp('badProportion').getValue(),
                                problemSource: Ext.getCmp('problemSource').getValue(),
                                riskNumber: Ext.getCmp('riskNumber').getValue(),
                                relatedProblemNumber: Ext.getCmp('relatedProblemNumber').getValue(),
                                temporaryMeasures: Ext.getCmp('temporaryMeasures').getValue(),
                                /*endPartNumber: Ext.getCmp('endPartNumber').getValue(),
                                productNumber: Ext.getCmp('productNumber').getValue(),*/
                                softwareCharger: Ext.getCmp('softwareCharger').getValue(),
                                hardwareCharger: Ext.getCmp('hardwareCharger').getValue(),
                                craftCharger: Ext.getCmp('craftCharger').getValue(),
                                fabricCharger: Ext.getCmp('fabricCharger').getValue(),
                                testCharger: Ext.getCmp('testCharger').getValue(),
                                qualityCharger: Ext.getCmp('qualityCharger').getValue(),
                                purchaseCharger: Ext.getCmp('purchaseCharger').getValue(),
                                makeCharger: Ext.getCmp('makeCharger').getValue(),
                                bazaarCharger: Ext.getCmp('bazaarCharger').getValue(),
                                elseCharger: Ext.getCmp('elseCharger').getValue(),
                                affirmCheck: Ext.getCmp('affirmCheck').getValue(),
                                problemSourceTerritory: Ext.getCmp('problemSourceTerritory').getValue(),
                                problemInput: userDisplayName,

                                projectNumber:Ext.getCmp('projectNumber').getValue(),
                                projectName:Ext.getCmp('projectName').getRawValue(),
                                summaryOfIssues:Ext.getCmp('summaryOfIssues').getValue()
                            }


                            if (data.summaryOfIssues == "" ||data.description == "" || data.problemTerritory == null || data.problemGrade == null || data.projectPhase == null || data.optimizeStrategy == ""
                                || data.planFinishDate == "" || data.analysis == "" || data.problemSource == null|| data.problemSourceTerritory == null ||/* data.productNumber == "" || */data.pqaCheck == null ||
                                data.creator == null || data.affirmCheck == null) {
                                alert("弹窗中*号标识为必填项，不允许为空");
                                return;
                            }

                            var split = data.problemTerritory.toString().split(',');
                            for (let i = 0; i < split.length; i++) {
                                if (split[i] == '软件') {
                                    var value = Ext.getCmp("softwareCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '硬件') {
                                    var value = Ext.getCmp("hardwareCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '工艺') {
                                    var value = Ext.getCmp("craftCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '结构') {
                                    var value = Ext.getCmp("fabricCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '测试') {
                                    var value = Ext.getCmp("testCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '质量') {
                                    var value = Ext.getCmp("qualityCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '采购') {
                                    var value = Ext.getCmp("purchaseCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '制造') {
                                    var value = Ext.getCmp("makeCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '市场') {
                                    var value = Ext.getCmp("bazaarCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '其他') {
                                    var value = Ext.getCmp("elseCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                }
                            }

                            var t = '软件,硬件,工艺,结构,测试,质量,采购,制造,市场,其他';
                            var ts = t.split(',')
                            let newArray = [];
                            for (let i = 0; i < ts.length; i++) {
                                if (!split.includes(ts[i])) {
                                    newArray.push(ts[i]);
                                }
                                ;
                            }
                            for (let i = 0; i < newArray.length; i++) {
                                if (newArray[i] == '软件') {
                                    data.softwareCharger = '';
                                } else if (newArray[i] == '硬件') {
                                    data.hardwareCharger = '';

                                } else if (newArray[i] == '工艺') {
                                    data.craftCharger = '';

                                } else if (newArray[i] == '结构') {
                                    data.fabricCharger = '';

                                } else if (newArray[i] == '测试') {
                                    data.testCharger = '';

                                } else if (newArray[i] == '质量') {
                                    data.qualityCharger = '';

                                } else if (newArray[i] == '采购') {
                                    data.purchaseCharger = '';

                                } else if (newArray[i] == '制造') {
                                    data.makeCharger = '';

                                } else if (newArray[i] == '市场') {
                                    data.bazaarCharger = '';

                                } else if (newArray[i] == '其他') {
                                    data.elseCharger = '';
                                }
                            }

                            save(data);
                            clear();
                            Ext.getCmp('requireWin2').close();
                        }
                    }, {
                        xtype: 'button',
                        id: 'close',
                        text: '取消',
                        handler: function () {
                            clear();
                            Ext.getCmp('requireWin2').close();
                        }
                    }]
                }]
        })

        var requireWin2 = Ext.create('Ext.Window', {
            id: 'requireWin2',
            title: '添加问题',
            width: 700,
            //height: 300,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [addForm],
        });


        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ProblemVerifyGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('problemVerifyStore'),
            id: 'ProblemVerifyGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 400,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {
                    text: '子问题处理',
                    columns: [
                        {
                            text: '领域',
                            dataIndex: 'problemTerritory',
                            width: 60,
                            menuDisabled: true,
                        },
                        {text: '子问题承担者', dataIndex: 'undertaker', width: 100, menuDisabled: true,},
                        {
                            text: '初步对策',
                            dataIndex: 'optimizeStrategy',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '计划解决时间',
                            dataIndex: 'planFinishDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '改善结论',
                            dataIndex: 'optimizeResult',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '验证报告编号',
                            dataIndex: 'verifyReportNumber',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '检验报告链接',
                            dataIndex: 'verifyReportLink',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '实际解决时间',
                            dataIndex: 'realitySolveDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '不整改原因',
                            dataIndex: 'noChangeCause',
                            width: 100,
                            menuDisabled: true,
                        },
                    ],
                },
                {
                    text: '子问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'verifyExplain', width: 100, menuDisabled: true,},
                    ]
                },
                {text: '是否分配人', dataIndex: 'isAssign', width: 100, menuDisabled: true},

            ],
        });


        var followUp = Ext.create('Ext.Window', {
            id: 'followUp',
            title: '子问题跟进',
            width: 1250,
            height: 400,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [ProblemVerifyGrid],
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var ProblemMgtGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemMgtStore'),
            id: 'ProblemMgtGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 400,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            tbar: [
                {

                    text: '新增',
                    id: 'add',
                    name: 'add',
                    scope: this,
                    handler: function () {
                        requireWin2.show();
                    }
                },
                {

                    text: '删除',
                    handler: function () {
                        let selectionArr = ProblemMgtGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }

                        var is = true;
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            if (record.data['problemInput'] != userDisplayName) {
                                Ext.Msg.alert("提示", "只有录入人才能删除该问题");
                                is = false;
                                return;
                            }

                            if (record.data['problemStatus'] != '已开启') {
                                Ext.Msg.alert("提示", "问题流程已开启无法删除");
                                is = false;
                                return;
                            }
                            obj.push(record.data['id'])
                        });
                        if (!is) {
                            return;
                        }

                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('problemMgtStore').reload()
                        };
                        Ext.Msg.confirm('提示', '确定要删除问题？',
                            function (btn) {
                                if (btn == 'yes') {
                                    deleteData(obj, callbackFn);
                                }
                            })
                    }
                }, {
                    text: '问题跟进信息',
                    scope: this,
                    handler: function () {
                        var newDocItems = new Array();
                        var removedRecords = ProblemMgtGrid.getSelectionModel().getSelection();

                        if (removedRecords == undefined || removedRecords == null || removedRecords.length == 0) {
                            alert("请选择对应的问题！");
                            return;
                        } else if (removedRecords.length > 1) {
                            alert("一次只能选择一个问题！");
                            return;
                        } else if (removedRecords[0].get('problemStatus') == '已开启') {
                            alert("问题未启动，请先启动问题！");
                            return;
                        }
                        followUp.show();
                        if (removedRecords[0].get("oaNumber") != undefined) {
                            getProblemVerifyInfo(removedRecords[0].get("problemNumber"));
                        } else {
                            getProblemVerifyInfo(removedRecords[0].get("docBranchId"));
                        }
                    }
                }, {

                    text: '导出当前问题报表',
                    iconCls: 'icon icon-download',
                    handler: function () {
                        this.doExportGridData();
                    },
                    scope: this
                }, {

                    text: '启动问题流程',
                    iconCls: 'icon icon-startProcess',
                    scope: this,
                    handler: function () {
                        var newDocItems = new Array();
                        var removedRecords = ProblemMgtGrid.getSelectionModel().getSelection();

                        if (removedRecords == undefined || removedRecords == null || removedRecords.length == 0) {
                            alert("请选择对应的问题！");
                            return;
                        } else if (removedRecords.length > 1) {
                            alert("一次只能启动一个问题！");
                            return;
                        }
                        var errorMsg = "";
                        Ext.each(removedRecords, function (record) {
                            var row = record.index

                            //alert(record.data['docBranchId']+'---'+row)
                            if (record.data['docBranchId'] != undefined || record.data['docBranchId'] != null) {
                                errorMsg += "第" + row + "行：问题已创建！\r\n";
                            }
                            /* if (record.data['creator']!=userDisplayName){
                                 errorMsg+="第"+row+"行：问题不是您创建，不能启动！\r\n";
                             }*/

                            newDocItems.push(record.data['id']);
                        });
                        if (errorMsg != "") {
                            alert(errorMsg);
                            return;
                        }
                        createProblemSolve(newDocItems);
                    }
                }, {

                    text: '导入',
                    handler: function () {
                        uploadPlanWindow.show();
                    },
                }, {

                    iconCls: 'icon-download ',
                    xtype: 'button',
                    id: "downTemplate",
                    text: '下载模板',
                    handler: function () {
                        window.open('/Windchill/template/问题导入模板.xlsx', '', 'width=300,height=200');
                    }
                }, {

                    text: '启动经验知识库流程',
                    id: 'setShare',
                    handler: function () {
                        var isShareItems = new Array();
                        //这一句是获取选中的集合
                        var setShareRecords = ProblemMgtGrid.getSelectionModel().getSelection();
                        if (setShareRecords == undefined || setShareRecords == null || setShareRecords.length == 0) {
                            alert("请选择对应要修改状态的问题！");
                            return
                        }

                        var is = 0;
                        //判断页面元内容再赋值
                        Ext.each(setShareRecords, function (record) {
                            if (record.data['isShare'] == 1) {
                                alert("所选问题已经是共享问题！")
                                is = 1;
                            }
                            if (record.data['problemStatus'] != '已解决') {
                                alert("只有已解决的问题才能进行共享！")
                                is = 1;
                            }
                            var isShare = '1';
                            var urlIsShare = record.data['id'];
                            isShareItems.push(urlIsShare);
                        });
                        if (is == 0) {
                            setShare(isShareItems, problemMgtStore);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    hidden: true,
                    id: 'saveStatus',
                    name: 'saveStatus'
                }
            ],
            columns: [{xtype: 'rownumberer', width: 40},
                {
                    text: '问题提出',
                    columns: [
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'containerId', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'problemInput', menuDisabled: true, hidden: true},
                        {text: '所属产品库', dataIndex: 'productName', width: 120,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {text: '产品线', dataIndex: 'productLine', width: 120,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {text: '项目名称', dataIndex: 'projectName', width: 120,},
                        {text: '项目编号', dataIndex: 'projectNumber', width: 120,},
                        {text: '问题编号', dataIndex: 'problemNumber', width: 120,},
                        {text: '问题提出者', dataIndex: 'creator', width: 100, editor: allUserCombo_projectPlan},
                        {
                            text: '问题领域', dataIndex: 'problemTerritory', width: 100, editor: problemTerritoryCombo,
                            renderer: function (value, metaData, record, row, col, store) {
                                var temp = new Array();
                                if (value == '' || value == undefined || value == null) {
                                    return '';
                                }
                                if (!Array.isArray(value)) {
                                    value += ",";
                                    var start = 0;
                                    var pos = value.indexOf(',');
                                    while (pos > -1) {
                                        temp.push(value.substr(start, pos - start));
                                        start = pos + 1;
                                        pos = value.indexOf(',', pos + 1);
                                    }
                                    record.set("problemTerritory", temp);
                                    record.commit();
                                } else {
                                    temp = value;
                                }
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + temp + "'";
                                return temp;
                            }
                        },
                        {text: '问题级别', dataIndex: 'problemGrade', width: 100, editor: problemGradeCombo},
                        {text: '问题来源（评审）', dataIndex: 'problemSourceTerritory', width: 100, editor: problemSourceTerritoryCombo},
                        {
                            text: '问题描述',
                            dataIndex: 'description',
                            width: 100,
                            editor: 'textfield',
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value.toString().replace(/,/g,'</br>') + "'";
                                return value;
                            }
                        },
                        {
                            text: '初步原因分析',
                            dataIndex: 'analysis',
                            width: 100,
                            editor: 'textfield',
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '初步对策', dataIndex: 'optimizeStrategy', width: 100, editor: 'textfield',
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '临时措施',
                            dataIndex: 'temporaryMeasures',
                            width: 100,
                            editor: 'textfield',
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        //{text: '问题承担者', dataIndex: 'charger', width: 100, editor: allUserCombo_projectPlan},
                        {
                            text: '计划完成时间',
                            dataIndex: 'planFinishDate',
                            width: 120,
                            editor: new Ext.form.DateField({format: 'Y-m-d', minValue: new Date(),}),
                            menuDisabled: true,
                            align: 'center',
                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                            }
                        },
                        {text: '发起日期', dataIndex: 'startDate', width: 100,},
                        {text: '流程链接', dataIndex: 'processLink', width: 100, editor: 'textfield'},
                        {text: '项目阶段', dataIndex: 'projectPhase', width: 100, editor: projectPhaseCombo},
                        {text: 'PQA', dataIndex: 'pqaCheck', width: 100, editor: allUserCombo_projectPlan},
                        {text: '开发代表', dataIndex: 'affirmCheck', width: 100, editor: allUserCombo_projectPlan},
                        {
                            text: '图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: ['->', {
                                iconCls: 'icon-uploadImage',
                                // icon: '',
                                tooltip: '添加图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    if (record.get('problemStatus') != '已开启') {
                                        return;
                                    }
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    problemId = problemNumber;
                                    uploadImageWindow.show();
                                }
                            }, '->', {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    problemId = problemNumber;
                                    var container = record.get('containerId');
                                    problemStatus = record.get('problemStatus');
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + container + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {
                            text: '不良比例（%）',
                            dataIndex: 'badProportion',
                            width: 120,
                            editor: 'numberfield',
                            menuDisabled: true,
                            minValue: 0
                        },
                        {text: '问题来源（领域）', dataIndex: 'problemSource', width: 100, editor: problemSourceCombo},
                        {text: '成品代码', dataIndex: 'endPartNumber', width: 100, editor: 'textfield'},
                        {text: '产品型号', dataIndex: 'productNumber', width: 100, editor: 'textfield'},
                        {text: 'OA编号', dataIndex: 'oaNumber', width: 100,},
                        {text: '风险编号', dataIndex: 'riskNumber', width: 100, editor: 'textfield'},
                        {text: '相关问题编号', dataIndex: 'relatedProblemNumber', width: 100, editor: 'textfield'},
                        {text: '软件领域问题承担者', dataIndex: 'softwareCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '硬件领域问题承担者', dataIndex: 'hardwareCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '工艺领域问题承担者', dataIndex: 'craftCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '结构领域问题承担者', dataIndex: 'fabricCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '测试领域问题承担者', dataIndex: 'testCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '质量领域问题承担者', dataIndex: 'qualityCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '采购领域问题承担者', dataIndex: 'purchaseCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '制造领域问题承担者', dataIndex: 'makeCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '市场领域问题承担者', dataIndex: 'bazaarCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '其他领域问题承担者', dataIndex: 'elseCharger', width: 140, editor: allUserCombo_projectPlan},
                    ]
                },
                /* {
                    text: '问题处理',
                    columns: [
                        {text: '改善结论', dataIndex: 'optimizeResult', width: 100,},
                        {text: '验证报告链接', dataIndex: 'verifyReportLink', width: 100,},
                        {text: '实际解决时间', dataIndex: 'realitySolveDate', width: 100,},
                        {text: '不整改原因', dataIndex: 'noChangeCause', width: 100,},
                    ]
                }, {
                    text: '问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'verifyExplain', width: 100,},
                    ]
                },*/ {
                    text: '问题结论',
                    columns: [
                        {text: '问题状态', dataIndex: 'problemStatus', width: 100,},
                        {
                            text: '确认说明',
                            dataIndex: 'confirmExplain',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                    ]
                }, {
                    text: '知识库共享',
                    columns: [{
                        text: '共享', width: 100, dataIndex: 'isShare', menuDisabled: true, value: '已共享',
                        renderer: function (value) {
                            if (value == "1") {
                                value = '已共享'
                            } else {
                                value = "未共享"
                            }
                            return value;
                        }
                    },
                        {
                            text: '补充信息',
                            dataIndex: 'replenish',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '补充信息图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: ['->', {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    problemId = problemNumber + '经验知识库';
                                    problemStatus = record.get('problemStatus');
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + containerId + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {text: '共享文档链接', dataIndex: 'shareLink', width: 100,}
                    ]
                },
            ],
            bbar: Ext.create('Ext.PagingToolbar', {
                store: problemMgtStore,
                style: {
                    float: 'right'
                },
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空"
            }),
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.record;

                    if (tField.get('problemStatus') != '已开启') {
                        return false;
                    }

                },
            }
        });

        ProblemMgtGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                if (tValue != null) {
                    if (tValue.toString().length > 1200) {
                        alert("内容信息长度不能大于1200！！！");
                    }
                }

                if (tField == 'badProportion') {
                    if (tValue != '') {
                        if (tValue < 0 || tValue > 100) {
                            alert('不良比例不能低于1或高于100！')
                            return;
                        }
                    }
                }
                if (tField == 'riskNumber') {
                    if (tValue != '') {
                        var isCorrect = checkRiskNumber(tValue);
                        if (!isCorrect) {
                            return;
                        }
                    }
                }
                if (tField == 'relatedProblemNumber') {
                    if (tValue != '') {
                        var isCorrect = checkProblemNumber(tValue);
                        if (!isCorrect) {
                            return;
                        }
                    }
                }
                if(tField == "endPartNumber"){
                    Ext.getStore('problemMgtStore').reload();
                }

                var callbackFn = function () {
                    tRecord.commit();
                };
                updateProblem(tField, tValue, itemId, tRecord, callbackFn);
            });

        var problemForm = {
            title: '问题报表',
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            border: 0,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '15 0 10 10',

                items: [{
                    fieldLabel: '问题编号',
                    name: 'cProblemNumber',
                    id: 'cProblemNumber',
                    allowBlank: false,
                    width: 200,
                }, {
                    fieldLabel: '问题状态',
                    labelWidth: 100,
                    name: 'cStatus',
                    id: 'cStatus',
                    width: 200,
                }, {
                    fieldLabel: '提交人',
                    labelWidth: 100,
                    id: 'cCreatorVerify',
                    name: 'cCreatorVerify',
                    width: 200,
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '0 0 0 10',
                items: [{
                    fieldLabel: '问题描述',
                    id: 'cDescription',
                    name: 'cDescription',
                    allowBlank: false,
                    width: 200,
                }, {
                    fieldLabel: '责任人',
                    labelWidth: 100,
                    id: 'cCharger',
                    name: 'cCharger',
                    width: 200,
                }, {
                    fieldLabel: '项目阶段',
                    hidden: share == "1" ? false : true,
                    labelWidth: 100,
                    id: 'cProjectPhase',
                    name: 'cProjectPhase',
                    width: 200,
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                hidden: share == "1" ? false : true,
                margin: '10 0 0 10',
                items: [{
                    xtype: 'datefield',
                    name: 'cStartDate',
                    id: 'cStartDate',
                    fieldLabel: '发起时间从',
                    margin: '0 5 0 0',
                    allowBlank: false
                },
                    {
                        xtype: 'datefield',
                        name: 'cEndDate',
                        id: 'cEndDate',
                        fieldLabel: '到',
                        allowBlank: false
                    }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'button',
                margin: '10 0 0 10',
                items: [{
                    text: '查询',
                    name: 'phone',
                    width: 50,
                    handler: function () {
                        doSearch()
                    }
                }]
            }, ProblemMgtGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [problemForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            doSearch();
        }
    },

    doExportGridData: function () {
        var data = getSearchData();
        window.location.href = '/Windchill/ptc1/problemMgt/exportProblems?data=' + Ext.encode(data);
    }

});

//创建问题解决文档
function createProblemSolve(newDocItems) {

    Ext.Msg.confirm('提示', '确定要为选中的问题启动流程吗？',
        function (btn) {
            if (btn == 'yes') {
                Ext.Ajax.request({
                    scope: this,
                    url: '/Windchill/ptc1/problemMgt/createProblemSolve',
                    params: {
                        data: Ext.encode(newDocItems),
                        containerId: Ext.encode(containerId),
                    },
                    success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if (!obj['success']) {
                            alert(obj['msg']);
                        } else {
                            Ext.getStore('problemMgtStore').reload();
                            alert("启动成功！");
                        }

                    },
                    failure: function (response, opts) {
                        alert('错误：创建问题解决文档失败，请检查网络！');
                    }

                });
            } else {
                return;
            }
        }, this);
}

//获取查询条件参数
function getSearchData() {
    var isShare = null;
    if (share == "1") {
        isShare = "1";
    }

    var data = {
        containerId: containerId,
        isShare: isShare,
        problemStatus: Ext.getCmp('cStatus').getValue(),
        problemNumber: Ext.getCmp('cProblemNumber').getValue(),
        description: Ext.getCmp('cDescription').getValue(),
        creator: Ext.getCmp('cCreatorVerify').getValue(),
        charger: Ext.getCmp('cCharger').getValue(),
    };

    return data;
}

/**
 * 按查询参数查询
 */
function doSearch() {
    var data = getSearchData();
    Ext.getStore('problemMgtStore').load({
        params: {
            data: data
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询问题信息失败，请联系管理员！');
            }
        }
    });
}


/**
 * 添加
 */
function save(data) {


    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/addProblem',
        params: {
            data: Ext.encode(data),
            imgs: imgs
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                doSearch();

                Ext.getStore('problemMgtStore').reload();
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

//修改或新增数据
function updateProblem(tField, tValue, id, tRecord, callbackFn) {
    var data = {
        key: tField,
        value: tValue,
        id: id,
        containerId: containerId
    }
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/updateProblem',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                if (id != "" && id != null) {
                    tRecord.commit();
                    if (callbackFn) {
                        callbackFn();
                    }
                } else {
                    doSearch();
                }
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存项目度量信息失败，请检查网络！');
        }
    });
}

/**
 * 获取产品型号
 * @param value
 * @returns {string}
 */
function getProductNumber(value) {
    var number = ''
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/getProduct',
        method: "POST",
        params: {
            partNumber: value
        },
        async: false,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                number = obj['product'];
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：获取失败，请检查网络！');
        }
    });
    return number;
}

//设置共享
function setShare(data, problemStore) {

    Ext.Msg.confirm('提示', '确定要改变共享状态？',
        function (btn) {
            if (btn == 'yes') {
                Ext.Ajax.request({
                    scope: this,
                    url: '/Windchill/ptc1/problemMgt/setShare',
                    method: "POST",
                    params: {
                        data: Ext.encode(data),
                        containerId: containerId
                    },
                    success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if (obj['success']) {
                            doSearch();
                        } else {
                            alert(obj['msg']);
                            Ext.getStore('problemStore').reload();
                        }
                    },
                    failure: function (response, opts) {
                        alert('错误：共享问题失败，请检查网络！');
                    }
                });
            } else {
                return;
            }
        }, this);


}

/*
清空表单的值
 */
function clear() {
    Ext.getCmp('description').setValue(""),
        Ext.getCmp('problemTerritory').setValue(""),
        Ext.getCmp('problemGrade').setValue(""),
        Ext.getCmp('projectPhase').setValue(""),
        Ext.getCmp('optimizeStrategy').setValue(""),
        Ext.getCmp('planFinishDate').setValue(""),
        Ext.getCmp('analysis').setValue(""),
        Ext.getCmp('badProportion').setValue(""),
        Ext.getCmp('problemSource').setValue(""),
        Ext.getCmp('relatedProblemNumber').setValue(""),
        Ext.getCmp('temporaryMeasures').setValue(""),
        Ext.getCmp('creator').setValue(""),
        Ext.getCmp('softwareCharger').setValue(""),
        Ext.getCmp('hardwareCharger').setValue(""),
        Ext.getCmp('craftCharger').setValue(""),
        Ext.getCmp('fabricCharger').setValue(""),
        Ext.getCmp('testCharger').setValue(""),
        Ext.getCmp('qualityCharger').setValue(""),
        Ext.getCmp('purchaseCharger').setValue(""),
        Ext.getCmp('makeCharger').setValue(""),
        Ext.getCmp('bazaarCharger').setValue(""),
        Ext.getCmp('elseCharger').setValue("")
    Ext.getCmp('affirmCheck').setValue("")
    Ext.getCmp('pqaCheck').setValue("")
}

//获取问题跟进信息
function getProblemVerifyInfo(branchId) {
    Ext.getStore('problemVerifyStore').load({
        params: {
            docBranchId: branchId,
        },
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    // alert('查询超时！请重试！')
                }
            }
        }
    });
}