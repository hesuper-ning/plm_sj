Ext.define('PLM.view.uploadImagePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.uploadImagePanel',
    border: false,
    height: 300,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //文件提交表单
        var formUpload = new Ext.form.FormPanel({
            fileUpload: true,
            autoHeight: true,
            autoWidth: true,
            //frame:true,
            id: "uploadFormPannel",
            border: false,
            items: []
        });
        addPanel("pannel_1");
        //为附件panelID赋值
        var n = 1;
        //文件提交表单最外层form
        var uploadPanel = new Ext.form.FormPanel({
            setZIndex: Ext.emptyFn,
            //title: '图片上传',
            closeAction: 'hide',
            // modal : true,
            buttonAlign: 'center',
            //bodyStyle : 'overflow-x:hidden; overflow-y:scroll',
            width: 530,
            height: 300,
            layout: 'fit',
            plain: true,
            border: 0,
            defaults: {autoScroll: true},// 设置滚动条
            id: 'uploadPanel',
            items: formUpload,
            name: 'userfile',
            tbar: ['->', {
                text: '继续添加文件',
                iconCls: 'btn-add',
                handler: function () {
                    n++;
                    var newPannelId = "pannel_" + n;
                    addPanel(newPannelId);
                }
            }],
            buttons: [{
                text: '上 传',
                id: 'uploadBtn',
                handler: function () {

                    /*for(var i=1;i<=n;i++){
                        if(typeof(Ext.getCmp("pannel_"+i)) != "undefined"){

                        }
                    }*/
                    if (formUpload.form.isValid()) {
                        formUpload.getForm().submit({
                            method: 'POST',
                            url: problemId == '' ? '/Windchill/ptc1/problem/noComUploadImage?containerId=' + containerId + '&userName=' + userDisplayName : '/Windchill/ptc1/problem/uploadImage?containerId=' + containerId + '&problemId=' + problemId,
                            waitMsg: '正在导入......',
                            waitTitle: '请等待',
                            success: function ( form, action) {
                                problemId='';
                                alert('导入成功');
                                var obj = action.result;
								imgs = action.result.imgs;

                                for (var i = n; i > 0; i--) {
                                    pannelId = "pannel_" + i;
                                    Ext.getCmp('uploadFormPannel').remove(Ext.getCmp(pannelId));
                                }

                                addPanel(pannelId);
                                Ext.getCmp('uploadPanel').ownerCt.ownerCt.hide();
                            },
                            failure: function (form, action) {
                                problemId='';
                                alert('导入失败，请检查网络');
                            }
                        });
                    }
                }
            }, {
                text: '取 消',
                handler: function () {
                    problemId = "";
                    var pannelId = "";
                    for (var i = n; i > 0; i--) {
                        pannelId = "pannel_" + i;
                        Ext.getCmp('uploadFormPannel').remove(Ext.getCmp(pannelId));
                    }
                    addPanel(pannelId);
                    Ext.getCmp('uploadPanel').ownerCt.ownerCt.hide();
                }
            }]
        });


        function addPanel(pannelId) { // 添加一个组件面板
            try {
                Ext.getCmp('uploadFormPannel').add(createPanel(pannelId));
                Ext.getCmp('uploadFormPannel').updateLayout();
            } catch (e) {
                alert(e.name + " -- " + e.message);
            }
        }

        function createPanel(pannelId) { // 创建一个panel
            var newPannel = new Ext.Panel({
                //frame:true,
                height: 40,
                width: 500,
                id: pannelId,
                border: false,
                style: {
                    borderColor: 'white',
                    borderStyle: 'solid'
                },
                items: [{
                    autoHeight: true,
                    layout: 'column',
                    border: false,
                    style: 'font-size:13px;',
                    items: [{
                        xtype: 'filefield',
                        fieldLabel: '附件',
                        labelWidth: 50,
                        name: 'uploadName',
                        allowBlank: false,
                        buttonText:'上传',
                        blankText: '请上传文件',
                        listeners: {
                            //t代表本身对象，n和o为前后的value
                            change: function (t, n, o, e) {
                                var arrType = n.split('.');
                                var docType = arrType[arrType.length - 1].toLowerCase();
                                if (docType != 'jpg' && docType != 'jpeg' && docType != 'gif'
                                    && docType != 'png' && docType != 'bmp' && docType != '') {
                                    alert('请上传jpg .jpeg .gif .png .bmp格式文件');
                                    Ext.getCmp('uploadBtn').setDisabled(true);
                                } else {
                                    Ext.getCmp('uploadBtn').setDisabled(false);
                                }

                            }
                        }
                        /*	validator: function(value){
                                // 文件类型判断
                                var arrType = value.split('.');
                                var docType = arrType[arrType.length-1].toLowerCase();
                                if(docType != 'jpg'&&docType != ""&&docType !=null){
                                    alert('请上传jpg格式图片');
                                }
                            }*/
                    }, {
                        margin: '0 0 0 10',
                        xtype: "button",
                        text: "删除",
                        handler: function () {
                            Ext.getCmp('uploadFormPannel').remove(Ext.getCmp(pannelId));
                        }
                    }]
                }]
            });
            return newPannel;
        }


        this.items = [
            uploadPanel
        ];

        this.callParent();


    }
});