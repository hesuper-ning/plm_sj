Ext.define('PLM.view.ProblemProcessSave', {
    extend: 'Ext.Window',
    alias: 'widget.ProblemProcessSave',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    width: 500,
    height: 250,
    autoHeight: true,
    closeAction: 'destroy',
    config: {
        param_id: undefined,
        param_oid: undefined,
    },
    id: 'ProblemProcessSave',
    initComponent: function () {
        var me = this;

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        // 创建者编辑panel
        var editPanel =new Ext.create("Ext.form.Panel", {
            autoWidth: true,
            autoHeight: true,
            layout: 'form', // 最大表单
            margin: '0 20 0 0',
            autoScroll: true,
            border: false,
            buttonAlign: 'center',
            id: 'editPanel',
            items : [{
                xtype : "textfield",
                name : "id",
                hidden : true,
                id : "id",
                fieldLabel : "id"
            },{
                xtype : "textarea",
                margin : '10 0 10 0',
                width : 350,
                rows : 2,
                name : "optimizeStrategy",
                id : "optimizeStrategy",
                fieldLabel : "改善策略"
            },{
                xtype : "textarea",
                margin : '10 0 10 0',
                width : 350,
                rows : 2,
                name : "optimizeResult",
                id : "optimizeResult",
                fieldLabel : "改善结论"
            }, {
                xtype : "textfield",
                name : "verifyReportLink",
                id : "verifyReportLink",
                width : 350,
                fieldLabel : "验证报告编码",
                emptyText : '有则填文档编码'
            }]
        });



        var requireWin2 = Ext.create('Ext.Window', {
            id: 'requireWin2',
            title: '编辑问题',
            width: 500,
            height: 250,
            autoHeight: true,
            closeAction: 'destroy',
            //closable:false,
            constrain: true,
            modal: true,
            items: editPanel,
            layout: "fit",
            bbar: {
                xtype: "toolbar",
                items: ['->', {
                    xtype: "button",
                    text: "保存",
                    width: 60,
                    listeners: {
                        "click": function (btn) {
                            save();
                            Ext.getCmp('requireWin2').close();
                        }
                    }
                }, {
                    xtype: "button",
                    width: 60,
                    text: "取消",
                    listeners: {
                        "click": function (btn) {
                            btn.ownerCt.ownerCt.close();
                        }
                    }
                }, '->']
            }
        });

/*        var mockExampleForm = {
            xtype: 'form',
            width: 200,
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [requireWin2.show()]
        };*/

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [editPanel],
        this.bbar = {
            xtype: "toolbar",
            items: ['->', {
                xtype: "button",
                text: "保存",
                width: 60,
                listeners: {
                    "click": function (btn) {
                        save();
                        btn.ownerCt.ownerCt.close();
                    }
                }
            }, {
                xtype: "button",
                width: 60,
                text: "取消",
                listeners: {
                    "click": function (btn) {
                        btn.ownerCt.ownerCt.close();
                    }
                }
            }, '->']
        },

        this.callParent();

    },//~End of initComponent

    listeners: {
        'afterrender': function () {
            // 取出id
            var id = Ext.getCmp('ProblemProcessSave').param_id;
            console.log(id);
            if(id == undefined || id.length == 0){
                return;
            }
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/problemMgt/getItemById?id=' + id,
                method: 'GET',
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('editPanel');
                        mainPanel.getForm().setValues(obj['data']);
                    } else {
                        alert(obj['msg']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }

    }
});
/**
 * 编辑
 */
function save() {
    var id = Ext.getCmp('ProblemProcessSave').param_oid;
    console.log(id);
    if(id == undefined || id.length == 0){
        return;
    }

    var data = {
        containerId:id,
        id:Ext.getCmp('id').getValue(),
        optimizeStrategy:Ext.getCmp('optimizeStrategy').getValue(),
        optimizeResult:Ext.getCmp('optimizeResult').getValue(),
        verifyReportLink:Ext.getCmp('verifyReportLink').getValue(),
    }

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/editProblem',
        params:{
            data:Ext.encode(data)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']){
                window.parent.location.reload();
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

