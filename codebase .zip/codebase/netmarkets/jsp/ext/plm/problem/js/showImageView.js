var photoViewer = Ext.create('Ext.Component', {
    draggable: {
        delegate: 'div.thumb-viewer-title'
    },
    /*resizable : {
        handles : 'all',
        minWidth : 500,
        minHeight : 430,
        pinned : true,
        transparent:true
    },*/
    //draggable : false,//禁止拖动
    resizable: false,//禁止缩放
    wrapWidth: 200,
    wrapHeight: 450,
    floating: true,
    constrain: true,
    hidden: true,
    maximized: false,
    cls: 'thumb-viewer',
    html: '<div class="thumb-viewer-title">' +
        '<div class="thumb-viewer-title-text"></div>' +
        '<div class="thumb-viewer-title-tools">' +
        '<div class="thumb-viewer-close-item"></div>' +
        '</div>' +
        '</div>' +
        '<div class="thumb-viewer-wrap">' +
        '<img />' +
        '</div>' +
        '<div class="thumb-viewer-info">' +
        '</div>' +
        '<div class="thumb-viewer-toolbar"></div>',
    listeners: {
        show: function () {
            photoViewer.navPrevBtn.setDisabled(photoViewer.viewIndex == 0);
            photoViewer.navNextBtn
                .setDisabled(photoViewer.viewIndex == store.getCount()
                    - 1);
            Ext.getBody().mask();
            //win.hide();
        },
        hide: function () {
            Ext.getBody().unmask();
            //win.show();
        },
        resize: function () {
            photoViewer.wrapWidth = photoViewer.el.getWidth() - 400 - 2;
            photoViewer.wrapHeight = photoViewer.el.getHeight() - 188;
            photoViewer.el.down('div.thumb-viewer-wrap').setStyle({
                width: photoViewer.wrapWidth,
                height: photoViewer.wrapHeight
            });
            photoViewer.el.down('div.thumb-viewer-info').setStyle({
                height: photoViewer.wrapHeight
            });
            //var img = photoViewer.el.down('img');photoViewer.viewIndex
            positionImage(store.getAt(0), null, null, false, true);
            if (photoViewer.toolbar) {
                photoViewer.toolbar.el.setWidth(photoViewer.el.getWidth());
                photoViewer.toolbar.updateLayout();
            }
        },
        afterrender: function (c) {
            c.el.down('div.thumb-viewer-close-item').on('click', function () {
                photoViewer.hide();
            });
            c.el.on('click', function () {
                c.toFront();
            });
            c.el.down('div.thumb-viewer-title').on('dblclick', function () {
                if (photoViewer.maximized === true) {
                    photoViewer.el.setStyle(photoViewer.state.position);
                    photoViewer.setSize(photoViewer.state.size);
                    photoViewer.maximized = false;
                    delete photoViewer.state;
                } else {
                    var parent = c.el.parent();
                    photoViewer.state = {
                        position: {
                            left: photoViewer.el.getLeft(),
                            top: photoViewer.el.getTop()
                        },
                        size: {
                            width: photoViewer.el.getWidth(),
                            height: photoViewer.el.getHeight()
                        }
                    };
                    photoViewer.setSize({
                        width: parent.getWidth(),
                        height: parent.getHeight()
                    });
                    photoViewer.el.setStyle({
                        left: 0,
                        top: 0
                    });
                    photoViewer.maximized = true;
                }
            });
            photoViewer.toolbar = Ext.create('Ext.container.Container', {
                renderTo: c.el.down('div.thumb-viewer-toolbar'),
                layout: {
                    type: 'hbox',
                    pack: 'center',
                    align: 'middle'
                }
            });

            photoViewer.navPrevBtn = Ext.create('Ext.Component', {
                cls: 'toolbar-item toolbar-nav toolbar-nav-prev',
                overCls: 'toolbar-nav-over',
                title: '上一张',
                html: '<img  />',
                listeners: {
                    render: function () {
                        this.el.addClsOnClick('toolbar-nav-prev-click');
                        this.el.on('click', function () {
                            viewPhoto(store.getAt(photoViewer.viewIndex - 1));
                        });
                    }
                }
            });
            photoViewer.toolbar.add(photoViewer.navPrevBtn);

            photoViewer.zoomInBtn = Ext.create('Ext.Component', {
                cls: 'toolbar-item toolbar-item-zoom-in',
                overCls: 'toolbar-item-over',
                title: '放大',
                html: '<img  />',
                listeners: {
                    render: function () {
                        this.el.addClsOnClick('toolbar-item-zoom-in-click');
                        this.el.on('click', zoomIn);
                    }
                }
            });
            photoViewer.toolbar.add(photoViewer.zoomInBtn);

            photoViewer.zoomOutBtn = Ext.create('Ext.Component', {
                cls: 'toolbar-item toolbar-item-zoom-out',
                overCls: 'toolbar-item-over',
                title: '缩小',
                html: '<img  />',
                listeners: {
                    render: function () {
                        this.el.addClsOnClick('toolbar-item-zoom-out-click');
                        this.el.on('click', zoomOut);
                    }
                }
            });
            photoViewer.toolbar.add(photoViewer.zoomOutBtn);
            photoViewer.deleteBtn = Ext.create('Ext.Component', {
                cls: 'toolbar-item toolbar-item-delete',
                overCls: 'toolbar-item-over',
                title: '删除',
                html: '<img  />',
                listeners: {
                    render: function () {
                        this.el.addClsOnClick('toolbar-item-delete-click');
                        this.el.on('click', deleteImage);
                    }
                }
            });
            photoViewer.toolbar.add(photoViewer.deleteBtn);

            photoViewer.navNextBtn = Ext.create('Ext.Component', {
                cls: 'toolbar-item toolbar-nav toolbar-nav-next',
                overCls: 'toolbar-nav-over',
                title: '下一张',
                html: '<img  />',
                listeners: {
                    render: function () {
                        this.el.addClsOnClick('toolbar-nav-next-click');
                        this.el.on('click', function () {
                            viewPhoto(store.getAt(photoViewer.viewIndex + 1));
                        });
                    }
                }
            });
            photoViewer.toolbar.add(photoViewer.navNextBtn);
        }
    }
});

//创建图片数据模型 ，数据源需要
var PhotoModel = Ext.define('ImageModel', {
    extend: 'Ext.data.Model',
    fields: ['name', 'type', 'size', 'lastmod', 'file', 'src', 'width',
        'height', 'trueWidth', 'trueHeight', 'display', 'uploaded',
        'absolute', 'top', 'left'
    ]
});

//创建数据源
var store = Ext.create("Ext.data.Store", {
    model: PhotoModel

});


//图片提示模板
var tiptpl = '名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：{0}<br/>' +
    '类&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;型：{1}<br/>' +
    '大&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;小：{2}<br/>' +
    '尺&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;寸：{3}<br/>' +
    '修改时间：{4}<br/>';

//显示图片窗口
function viewPhoto(photo) {
    if (photo) {
        clearRotate();
        photoViewer.viewIndex = store.indexOf(photo);
        if (photoViewer.navNextBtn) {
            photoViewer.navPrevBtn.setDisabled(photoViewer.viewIndex == 0);
            photoViewer.navNextBtn
                .setDisabled(photoViewer.viewIndex == store.getCount()
                    - 1);
        }
        photoViewer.show();
        var img = photoViewer.el.down('img');

        img.dom.src = photo.data.src;

        //alert(photo.data.src);

        positionImage(photo);
        //var body = Ext.getBody();
        var title = photoViewer.el.down('div.thumb-viewer-title-text');
        title.update("查看相片：" + photo.data.name);
        var info = photoViewer.el.down('div.thumb-viewer-info');
        info.update('<h1>文件信息:</h1><p>' + Ext.String.format(tiptpl, photo.get('name'), photo
            .get('type'), photo.get('size'), photo.get('trueWidth')
            + "×" + photo.get('trueHeight'), photo.get('lastmod')) + '</p>');
    } else {
        photoViewer.show();
    }
}

function zoomIn() {
    var img = photoViewer.el.down('img');
    var width = img.getWidth();
    var height = img.getHeight();
    width += width * 0.25;
    height += height * 0.25;
    positionImage(store.getAt(photoViewer.viewIndex), width, height, true);
}

function zoomOut() {
    var img = photoViewer.el.down('img');
    var width = img.getWidth();
    var height = img.getHeight();
    width -= width * 0.25;
    height -= height * 0.25;
    positionImage(store.getAt(photoViewer.viewIndex), width, height, true);
}

function clearRotate() {
    if (photoViewer.rotated === true) {
        photoViewer.el.down('img').setStyle({
            '-webkit-transform': 'none'
        });
        delete photoViewer.rotate;
    }
}

function isRotate() {
    var rotate = photoViewer.rotate;
    return ((rotate == 90 || rotate == 270 || rotate == -90
        || rotate == -270) && photoViewer.rotated === true);
}

function positionImage(photo, width, height, fit, notClearRotate) {
    width = width || (!isRotate() ? photo.data.trueWidth : photo.data.trueHeight);
    height = height || (!isRotate() ? photo.data.trueHeight : photo.data.trueWidth);
    var wrapWidth = photoViewer.wrapWidth;
    var wrapHeight = photoViewer.wrapHeight;
    if (!fit) {
        if (height > wrapHeight) {
            var scale = wrapHeight / height;
            height = wrapHeight;
            width = width * scale;
        }

        if (width > wrapWidth) {
            var scale = wrapWidth / width;
            width = wrapWidth;
            height = height * scale;
        }
    }
    var img = photoViewer.el.down('img');
    var wrap = photoViewer.el.down('div.thumb-viewer-wrap');

    img.setStyle({
        width: width + 'px',
        height: height + 'px'
    });
    if (width <= wrapWidth) {
        img.setStyle({
            marginLeft: (wrapWidth - width) / 2 + 'px'
        });
    } else {
        img.setStyle({
            marginLeft: 0 + 'px'
        });
        wrap.dom.scrollLeft = wrap.dom.scrollWidth;
        wrap.dom.scrollLeft = (wrap.dom.scrollLeft / 2) + 'px';
    }
    if (height <= wrapHeight) {
        img.setStyle({
            marginTop: (wrapHeight - height) / 2 + 'px'
        });
    } else {
        img.setStyle({
            marginTop: 0 + 'px'
        });
        wrap.dom.scrollTop = wrap.dom.scrollHeight;
        wrap.dom.scrollTop = (wrap.dom.scrollTop / 2) + 'px';
    }
}

function deleteImage() {

    if (problemStatus !='' && problemStatus != '已开启') {
		alert("无法删除")
		return
    }

    if (problemStatus != '已开启') {
        if (actKey != 'ActivityNode_Problem_Submit') {
            alert("无法删除")
            return
        }
    }

    if (window.confirm('你确定要删除该图片吗？')) {
        var r = store.getAt(photoViewer.viewIndex);
        var record = {
            containerId: containerId,
            problemId: problemId,
            path: r.get('src')
        };
        Ext.Ajax.request({
            scope: this,
            url: '/Windchill/ptc1/problem/deleteImage',//?projectId='+PROJECTOID+'&problemId='+problemId+'&path='+Ext.encode(r.get('src'))
            params: {
                param: Ext.encode(record)
            },
            success: function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if (obj['success']) {
                    //photoViewer.hide();
                    //alert(obj['msg']);
                    store.remove(store.getAt(photoViewer.viewIndex));
                    if (store.getCount() != 0) {
                        viewPhoto(store.getAt(0));
                    } else {
                        photoViewer.hide();
                    }
                } else {
                    alert(obj['msg']);
                    return;
                }
            },
            failure: function (response, opts) {
                loadMarsk.hide();
                alert('错误：删除图片失败，请检查网络！');
                return;
            }
        }); //~End of Ajax request
    }
}

/*//判断IE8版本
function UseIE8()
{
    if (Ext.isIE6){
    	return true;
    }
    if (Ext.isIE7){
    	return true;
    }
    if (Ext.isIE8){
    	return true;
    }
    return false;
}

function rotateImg(rotateVal) {
    if(rotateVal%360==-90||rotateVal%360==270){
    	alert("rotateVal%360="+(rotateVal%360));
    	ro3();
    }else if(rotateVal%360==-180||rotateVal%360==180){
    	alert("rotateVal%360="+(rotateVal%360));
    	ro2();
    }
    else if(rotateVal%360==90||rotateVal%360==-270){
    	alert("rotateVal%360="+(rotateVal%360));
    	ro1();
    }
    else if(rotateVal%360==0){
    	alert("rotateVal%360="+(rotateVal%360));
    	ro0();
    }
    
}

function ro0() {
	photoViewer.el.down('img').setStyle({
		 'filter': 'progid:DXImageTransform.Microsoft.BasicImage(rotation=0)' 
	});
	positionImage(store.getAt(photoViewer.viewIndex),null,null,false,true);				
}
//90度
function ro1() {
    $('#img').css({ filter: 'progid:DXImageTransform.Microsoft.BasicImage(rotation=1)' });
}
//180度
function ro2() {
    $('#img').css({ filter: 'progid:DXImageTransform.Microsoft.BasicImage(rotation=2)' });
}
//270度
function ro3() {
	alert(photoViewer.el.down('img').id);
	var gIE = getIE();
	alert("version="+gIE.version);
	imageId = photoViewer.el.down('img').id;
	document.getElementById(imageId).style.filter = 'progid:DXImageTransform.Microsoft.BasicImage(rotation=3)';
	positionImage(store.getAt(photoViewer.viewIndex),null,null,false,true);
}
//获取IE版本
function getIE() {

  var rmsie = /(msie) ([\w.]+)/;

  var ua = navigator.userAgent.toLowerCase();

  var match = rmsie.exec(ua);

  var result = {};

  if (match && match.length > 0) {

    result = { browser: match[1] || "", version: match[2] || "0" };

  }

  return result;

}*/