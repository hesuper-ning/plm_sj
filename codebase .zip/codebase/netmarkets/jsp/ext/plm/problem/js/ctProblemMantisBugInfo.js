Ext.define('PLM.view.mantis', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.mantis',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'mantis',


    initComponent: function () {
        var me = this;


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var states = Ext.create('Ext.data.Store', {
            fields: ['abbr', 'name'],
            data : [
                {"abbr":"新建", "name":"新建"},
                {"abbr":"反馈", "name":"反馈"},
                {"abbr":"推迟", "name":"推迟"},
                {"abbr":"认可", "name":"认可"},
                {"abbr":"已确认", "name":"已确认"},
                {"abbr":"已分派", "name":"已分派"},
                {"abbr":"已解决", "name":"已解决"},
                {"abbr":"验证成功", "name":"验证成功"},
                {"abbr":"验证失败", "name":"验证失败"},
                {"abbr":"关闭", "name":"关闭"},
            ]
        });
        var severity = Ext.create('Ext.data.Store', {
             fields: ['abbr', 'name'],
             data : [
                 {"abbr":"新功能", "name":"新功能"},
                 {"abbr":"建议", "name":"建议"},
                 {"abbr":"一般", "name":"一般"},
                 {"abbr":"严重", "name":"严重"},
                 {"abbr":"致命", "name":"致命"},
             ]
              });

        var testType = Ext.create('Ext.data.Store', {
            fields: ['abbr', 'name'],
            data : [
                {"abbr":"原型机测试", "name":"原型机测试"},
                {"abbr":"原型机测试(TR4A评审前)", "name":"原型机测试(TR4A评审前)"},
                {"abbr":"初始产品测试(TR5评审前)", "name":"初始产品测试(TR5评审前)"},
                {"abbr":"产品测试(TR6评审前)", "name":"产品测试(TR6评审前)"},
                {"abbr":"平台软件(如云平台)", "name":"平台软件(如云平台)"},
                {"abbr":"平台软件", "name":"平台软件"},
                {"abbr":"其他(软件、硬件等非独立产品以及无法归入前面几类的委托测试)", "name":"其他(软件、硬件等非独立产品以及无法归入前面几类的委托测试)"},
                {"abbr":"其他", "name":"其他"},
                ]
        });


        var bugCategory = Ext.create('Ext.data.Store', {
             fields: ['abbr', 'name'],
             data : [
                 {"abbr":"通用", "name":"通用"},
                 {"abbr":"APIServer", "name":"APIServer"},
                 {"abbr":"APP", "name":"APP"},
                 {"abbr":"APP功能", "name":"APP功能"},
                 {"abbr":"App和微信", "name":"App和微信"},
                 {"abbr":"EMC", "name":"EMC"},
                 {"abbr":"PC Mantis", "name":"PC Mantis"},
                 {"abbr":"RJ45网口", "name":"RJ45网口"},
                 {"abbr":"SJ-BLJC-I 1LE3W/DZ1湘华245单向面板", "name":"SJ-BLJC-I 1LE3W/DZ1湘华245单向面板"},
                 {"abbr":"SJ-BLJC-I 1LE3W/DZ2湘华150单向面板", "name":"SJ-BLJC-I 1LE3W/DZ2湘华150单向面板"},
                 {"abbr":"SJ-BLJC-I 1LRE3W/DS1浩丰245双向面板", "name":"SJ-BLJC-I 1LRE3W/DS1浩丰245双向面板"},
                 {"abbr":"UI界面", "name":"UI界面"},
                 {"abbr":"USB接口", "name":"USB接口"},
                 {"abbr":"V1.1beta01", "name":"V1.1beta01"},
                 {"abbr":"其他", "name":"其他"},
                 {"abbr":"兼容性", "name":"兼容性"},
                 {"abbr":"功能", "name":"功能"},
                 {"abbr":"包装", "name":"包装"},
                 {"abbr":"后台", "name":"后台"},
                 {"abbr":"国标", "name":"国标"},
                 {"abbr":"基本功能", "name":"基本功能"},
                 {"abbr":"外观", "name":"外观"},
                 {"abbr":"多股线", "name":"多股线"},
                 {"abbr":"天线", "name":"天线"},
                 {"abbr":"对接云平台", "name":"对接云平台"},
                 {"abbr":"工艺", "name":"工艺"},
                 {"abbr":"平台", "name":"平台"},
                 {"abbr":"平台软件", "name":"平台软件"},
                 {"abbr":"平面图", "name":"平面图"},
                 {"abbr":"性能", "name":"性能"},
                 {"abbr":"手机Mantis", "name":"手机Mantis"},
                 {"abbr":"控制器或集中电", "name":"控制器或集中电"},
                 {"abbr":"数据配置", "name":"数据配置"},
                 {"abbr":"文档", "name":"文档"},
                 {"abbr":"显示器", "name":"显示器"},
                 {"abbr":"环境", "name":"环境"},
                 {"abbr":"界面", "name":"界面"},
                 {"abbr":"硬件", "name":"硬件"},
                 {"abbr":"端子", "name":"端子"},
                 {"abbr":"终端", "name":"终端"},
                 {"abbr":"结构", "name":"结构"},
                 {"abbr":"结构/外观", "name":"结构/外观"},
                 {"abbr":"编码器", "name":"编码器"},
                 {"abbr":"网站", "name":"网站"},
                 {"abbr":"联网功能", "name":"联网功能"},
                 {"abbr":"蜂鸣器", "name":"蜂鸣器"},
                 {"abbr":"说明书", "name":"说明书"},
                 {"abbr":"软件", "name":"软件"},
                 {"abbr":"软件功能", "name":"软件功能"},
                 {"abbr":"软件性能", "name":"软件性能"},
                 {"abbr":"运营", "name":"运营"},
                 {"abbr":"连接线（带端子）", "name":"连接线（带端子）"},
                 {"abbr":"需求", "name":"需求"},
             ]
              });



        Ext.define('ctMantisModel', {
            extend: 'Ext.data.Model',
            fields: ['bugId','projectNumber','submitDate','summary','projectName','bugCategory','testType',
                'reportUser','chargeUser','status','resolution','priority','severity',
                'reproducibility','productVersion','osVersion','targetVersion','fixedVersion',
                'lastUpdateDate','closeDate','restoreDate','tagName'],
            idProperty: 'id'
        });
        var mantisStore = Ext.create('Ext.data.Store', {
            extend:'Ext.data.Store',
            model: 'ctMantisModel',
            id: 'mantisStore',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/Mantis/getBugItems',
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty:'totalCount',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad:false
        });

        mantisStore.on('beforeload', function(store, options) {
            var data =getSearchData();
            Ext.apply(mantisStore.proxy.extraParams, data);
        });


        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mantisStore'),
            id: 'mockExampleGrid',
            margin: '10 0 0 0',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 800,
            title:'Mantis问题报表（每天同步一次)',
            titleAlign:'center',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            tbar: [

                {
                    width: 100,
                    xtype: 'textfield',
                    emptyText: '项目编号',
                    id: 'search_number',
                }, {
                    width: 100,
                    xtype: 'textfield',
                    emptyText: '项目名称',
                    id: 'search_name',
                },{
                    width: 100,
                    xtype: 'combobox',
                    emptyText: '状态',
                    id: 'states',
                    store: states,
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'abbr',
                },
                {
                    width: 100,
                    xtype: 'combobox',
                    emptyText: '严重性',
                    id: 'search_severity',
                    store: severity,
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'abbr',
                }, {
                    width: 100,
                    xtype: 'combobox',
                    emptyText: '测试类型',
                    id: 'search_testType',
                    store: testType,
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'abbr',
                }, {
                    width: 100,
                    xtype: 'combobox',
                    emptyText: '分类',
                    id: 'search_bugCategory',
                    store: bugCategory,
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'abbr',
                }, {
                    width: 100,
                    xtype: 'button',
                    text: '查询',
                    iconCls: 'icon icon-search',
                    handler: function() {
                        var data =getSearchData();
                        Ext.getStore('mantisStore').load({
                            params:{
                                data:Ext.encode(data)
                            },
                            callback: function(records, operation, success) {
                                if(!success){
                                    alert('查询信息失败，请联系管理员！');
                                }
                            }
                        });
                    }


                },{
                    text : '导出',
                    iconCls: 'icon icon-download',
                    handler : function () {
                        exportReport();
                    },
                    scope : this
                }
            ],
            columns: [{xtype: 'rownumberer', width: 40},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'bugId', menuDisabled: true, hidden: true},
                {text: '项目名称', dataIndex: 'projectName', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '项目编号', dataIndex: 'projectNumber',width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '摘要', dataIndex: 'summary', width: 600, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '状态', dataIndex: 'status', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '严重性', dataIndex: 'severity', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '出现频率', dataIndex: 'reproducibility', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '分类', dataIndex: 'bugCategory', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '测试类型', dataIndex: 'testType', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '报告员', dataIndex: 'reportUser', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '报告日期', dataIndex: 'submitDate', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '分派给', dataIndex: 'chargeUser', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '处理状况', dataIndex: 'resolution', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '最后更新', dataIndex: 'lastUpdateDate', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '优先级', dataIndex: 'priority', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '产品版本', dataIndex: 'productVersion', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '修正版本', dataIndex: 'fixedVersion', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }},
                {text: '最近关闭时间', dataIndex: 'closeDate', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '操作系统版本', dataIndex: 'osVersion', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '目标版本', dataIndex: 'targetVersion', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '重启日期', dataIndex: 'restoreDate', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '标签名称', dataIndex: 'tagName', width: 160, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
            ],
            bbar: Ext.create('Ext.PagingToolbar', {
                store: mantisStore,
                style: {
                    float: 'right'
                },
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空"
            }),



        });


        var  riskReportForm = {
            title: 'bug查询报表',
            xtype: 'fieldset',
            region: 'center',
            align: 'center',
            id: 'mainForm',
            //width: '98%',
            hidden: false,
            hideLabel: true,
            frame: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [mockExampleGrid]
        };

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [riskReportForm];

        this.callParent();


    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mantisStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    },


     /*   Ext.Ajax.request({
            url: '/Windchill/ptc1/Mantis/exportMantis',
            params:{
                updateRecord:Ext.encode(data)
            },
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj['success']){

                }else{
                    alert(obj['message']);
                }
            },
            failure: function(response, opts) {
                alert('错误：保存信息失败，请检查网络！!');
            }
        }); //~End of Ajax request*/



});

//获取查询条件参数
function getSearchData() {

    var data = {
        projectNumber:Ext.getCmp('search_number').getValue(),
        projectName:Ext.getCmp('search_name').getValue(),
        status:Ext.getCmp('states').getValue(),
        severity:Ext.getCmp('search_severity').getValue(),
        testType:Ext.getCmp('search_testType').getValue(),
        bugCategory:Ext.getCmp('search_bugCategory').getValue(),
    };

    return data;
}


function exportReport() {
        var data = getSearchData();

        // 获取XMLHttpRequest
        var xmlResquest = new XMLHttpRequest();
        //  发起请求
        xmlResquest.open("POST", '/Windchill/ptc1/Mantis/exportMantis', true);
        // 设置请求头类型
        xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
        xmlResquest.responseType = "blob";
        //  返回
        xmlResquest.onload = function (oEvent) {
            var content = xmlResquest.response;
            if (content.type == 'application/json') {
                content.text().then(res => {
                    alert(Ext.decode(res).error)
                })
            } else {
                var timestamp =new Date().getTime();
                // 组装a标签
                var elink = document.createElement("a");
                // 设置下载文件名
                elink.download = "bug查询报表"+timestamp+".xlsx";
                elink.style.display = "none";
                var blob = new Blob([content]);
                elink.href = URL.createObjectURL(blob);
                document.body.appendChild(elink);
                elink.click();
                document.body.removeChild(elink);
            }

        };
        //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
        xmlResquest.send(
            "data=" + Ext.encode(data)+"&type=departmentManager"
        );}

