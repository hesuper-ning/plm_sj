Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'mockProblemMgtReadOnly',
        in_objectDesc: '定制的Form表单',
    },
    id: 'MockExample',


    initComponent: function () {
        var me = this;
        var problemStore = Ext.create('PLM.store.MockItemStore', {
            id: 'problemStore'
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });



        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemStore'),
            id: 'mockExampleGrid',
            margin: '10 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            //autoScroll: true,
            region: 'center',
            height: 400,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {
                    text: '问题提出',
                    columns: [
                        {text: '问题编号', dataIndex: 'data1', width: 100, editor: 'textfield',},
                        {text: '问题阶段', dataIndex: 'data2', width: 100, editor: 'textfield',},
                        {text: '问题描述', dataIndex: 'data3', width: 100, editor: 'textfield'},
                        {text: '问题来源', dataIndex: 'data4', width: 100, editor: 'textfield',},
                        {text: '问题分类', dataIndex: 'data5', width: 100, editor: 'textfield',},
                        {text: '初步分析', dataIndex: 'data6', width: 100, editor: 'textfield',},
                        {text: '不良比例(%)', dataIndex: 'data7', width: 100, editor: 'textfield',},
                        {text: '创建人', dataIndex: 'data8', width: 100,editor: 'textfield'}
                    ]
                },{
                    text: '问题确认',
                    columns: [
                        {text: '负责人', dataIndex: 'data9', width: 100,editor: 'textfield'},
                        {text: '问题等级', dataIndex: 'data10', width: 100,editor: 'textfield'},
                        {text: '目标解决时间', dataIndex: 'data11', width: 100,editor: 'textfield'},
                        {text: '改善对策', dataIndex: 'data12', width: 100,editor: 'textfield'},
                        {text: '发起时间', dataIndex: 'data13', width: 100,editor: 'textfield'},
                        {text: '流程链接', dataIndex: 'data14', width: 100,editor: 'textfield'},
                    ]
                },{
                    text: '问题处理',
                    columns: [
                        {text: '改善结论', dataIndex: 'data15', width: 100,editor: 'textfield'},
                        {text: '是否有验证报告', dataIndex: 'data16', width: 100,editor: 'textfield'},
                        {text: '验证报告链接', dataIndex: 'data17', width: 100,editor: 'textfield'},
                    ]
                },
            ]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('problemStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('problemStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('problemStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
        }
    }
});

