/*Ext.define('PLM.store.MockItemStore',{
    extend:'Ext.data.Store',
    alias:'widget.MockItemStore',
    param_objectKey:'',//传入参数objectKey,（不成功）
    fields:['id','masterId','data1','data2','data3','data4','data5','data6','data7','data8','data9'
        ,'data10','data11','data12','data13','data14','data15','data16','data17','data18','data19'
        ,'data20','data21','data22','data23','data24','data25','data26','data27','data28','data29'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/Mantis/getBugItems',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'items',
            idProperty: 'id',
            messageProperty: 'error'
        }
    }),
    autoLoad:false
});*/

Ext.define('PLM.mock.ContextMenu',{
    extend:'Ext.menu.Menu',
    alias:'widget.MockGridMenu',
    config:{
        param_grid: undefined,//传入参数，操作的Grid对象
        param_objectKey:undefined,//传入参数，Grid对象的表key
        param_objectDesc:undefined,//传入参数，Grid对象的表描述
    },
    initComponent:function(){

        if(!this.param_grid.getStore()){
            //通过getStore 判断传入的是否是grid对象
            alert('列表对象没有正确传入！无法生成右键菜单！');
            return;
        }
        // alert('inner param_objectKey='+this.param_objectKey+">>>param_objectDesc="+this.param_objectDesc);

        this.addAction = Ext.create('Ext.Action', {
            iconCls   : 'icon-add',  // Use a URL in the icon config
            text: '添加',
            scope:this,
            handler: function(widget, event) {
                var recordCount = this.param_grid.getStore().getCount();
                //用回调刷新列表
                var cStore = this.param_grid.getStore();
                var callbackFn = function(){
                    cStore.reload();//刷新列表
                }
                var returnItemId = createMockItemData(this.param_objectKey,this.param_objectDesc,callbackFn);
            }
        });


        this.deleteAction = Ext.create('Ext.Action', {
            iconCls: 'icon-delete',
            text: '删除',
            disabled: false,
            scope:this,
            handler: function(widget, event) {
                var deleteItems = new Array();
                var removedRecords = this.param_grid.getSelectionModel().getSelection();

                Ext.each(removedRecords,function(record){
                    deleteItems.push(record.data['id']);
                });
                //用回调刷新列表
                var cStore = this.param_grid.getStore();
                var callbackFn = function(){
                    cStore.reload();//刷新列表
                }
                deleteMockItem(deleteItems,callbackFn);
            }
        });

        this.items=[this.addAction,this.deleteAction];

        this.callParent();

    }//~End of initComponent
});

/**
 *
 * @param objectKey 表头key
 * @param objectDesc 表描述
 * @param callbackFn 回调函数
function createMockItemData(objectKey,objectDesc,callbackFn) {
    saveMockItemData(objectKey,objectDesc
        ,undefined,undefined,undefined,callbackFn);
}*/

/**
 * 保存列表中的一个属性(单元格）
 * @param objectKey 表头key
 * @param objectDesc 表描述
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(objectKey,objectDesc,itemId,dataKey,dataValue,callbackFn){

    var returnItemId = undefined;
    var mockRec = {
        objectKey:objectKey,
        objectDesc:objectDesc,
        itemId:itemId,
        dataKey:dataKey,
        dataValue:dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/mock/saveMockItemData',
        params:{
            updateRecord:Ext.encode(mockRec)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']){
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if(callbackFn){
                    callbackFn();
                }
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}

/**
 * 删除一行数据
 * @param itemId
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 */
function deleteMockItem(deleteItems,callbackFn){

    //包装成array,以适应
    if(!(deleteItems instanceof Array)){
        alert('删除传入参数有错，请包装成Array对象后传入！');
        return;
    }

    Ext.Ajax.request({
        url: '/Windchill/ptc1/mock/deleteMockItems',
        params:{
            deleteItems:Ext.encode(deleteItems)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']){
                //回调函数，一般用于后台操作成功后刷新列表
                if(callbackFn){
                    callbackFn();
                }
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


/**
 * 保存表单中的一个属性(表单）
 * @param objectKey 表头key
 * @param objectDesc 表描述
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveObjectData(objectKey,objectDesc,dataKey,dataValue,callbackFn){

    var returnItemId = undefined;
    var mockRec = {
        objectKey:objectKey,
        objectDesc:objectDesc,
        dataKey:dataKey,
        dataValue:dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/mock/saveObjectData',
        params:{
            updateRecord:Ext.encode(mockRec)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']){
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if(callbackFn){
                    callbackFn();
                }
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}