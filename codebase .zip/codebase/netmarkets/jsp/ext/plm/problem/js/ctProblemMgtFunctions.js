//删除
function deleteData(dataArray,callback) {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/deleteProblem',
        method: "POST",
        params: {
            data:Ext.encode(dataArray),
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("数据删除失败",obj['msg']);
            }else{
                alert("数据删除成功");
                callback();
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'数据删除失败，请检查网络！')
        }
    });
}

//检查物料编号是否正确
function checkPartNumber(number) {
    var isCorrect = true;
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/checkPartNumber',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
                isCorrect = false;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return isCorrect;
}

//检查文档编号是否正确
function checkDocNumber(number) {
    var isCorrect = true;
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/checkPartNumber',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
                isCorrect = false;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return isCorrect;
}

//检查风险编号是否正确
function checkRiskNumber(number) {
    var isCorrect = true;
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/checkRiskNumber',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
                isCorrect = false;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return isCorrect;
}

//检查问题编号是否正确
function checkProblemNumber(number) {
    var isCorrect = true;
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/checkProblemNumber',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
                isCorrect = false;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return isCorrect;
}

//检查编号是否正确
function getVerifyReportLink(number) {
    var url = "";
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/getVerifyReportLink',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
            }else {
                url = obj["url"]
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return url;
}




/*

/!**
 * 获取产品型号
 * @param value
 * @returns {string}
 *!/
function getProductNumber(value){
    var productNumber = ''
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/getProduct',
        method:"POST",
        params:{
            partNumber:value
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']){
                productNumber = obj['product'];
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：获取失败，请检查网络！');
        }
    });
    return productNumber;
}

*/









