Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'ctProblemMantisBugInfo',
        in_objectDesc: '定制的Form表单',
    },
    id: 'MockExample',


    initComponent: function () {
        var me = this;
        var problemStore = Ext.create('PLM.store.MockItemStore', {
            id: 'problemStore'
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var states = Ext.create('Ext.data.Store', {
            fields: ['abbr', 'name'],
            data : [
                {"abbr":"AL", "name":"开启"},
                {"abbr":"AK", "name":"关闭"},
            ]
        });




        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemStore'),
            id: 'mockExampleGrid',
            margin: '10 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '98%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            tbar: [

                {
                    width: 100,
                    xtype: 'combobox',
                    emptyText: '问题状态',
                    id: 'states',
                    store: states,
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'abbr',
                },
                {
                    width: 100,
                    xtype: 'combobox',
                    emptyText: '严重等级',
                    id: 'adfw',
                }, {
                    width: 100,
                    xtype: 'combobox',
                    emptyText: '问题类型',
                    id: 'gwgea',
                }, {
                    width: 100,
                    xtype: 'combobox',
                    emptyText: 'BugSort',
                    id: 'qers',
                }, {
                    width: 100,
                    xtype: 'button',
                    text: '查询',
                    id: 'addDshseata',
                }
            ],
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '出现频率', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '产品版本', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '操作系统版本', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '目标版本', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '报告日期', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '最后更新日期', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '摘要', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '状态', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '处理状况', dataIndex: 'data9', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '修正版本', dataIndex: 'data10', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '最近关闭日期', dataIndex: 'data11', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '标签', dataIndex: 'data11', width: 80, editor: 'textfield', menuDisabled: true}
            ],
        });


        var mockExampleForm = {};

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('problemStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('problemStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('problemStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
        }
    }
});

