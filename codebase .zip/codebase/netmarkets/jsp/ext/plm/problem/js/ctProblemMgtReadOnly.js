
Ext.define('PLM.view.problemMgtReadOnly', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.problemMgtReadOnly',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    initComponent: function () {
        var me = this;
        Ext.define('ctProblemMgtModel', {
            extend: 'Ext.data.Model',
            fields:['id' ,'containerId','docBranchId','problemPhase','description','reasonAnalyse','objectCount','creator','creatorDate','charger'
                ,'grade', 'targetSolveDate','startDate','processLink','status','optimizeStrategy','optimizeResult','verifyReportOrNot'
                ,'verifyReportLink','realitySolveDate','creatorVerify','chargerVerify','PMVerify','departmentVerify'],
            idProperty: 'id'
        });

        var problemMgtStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemMgtModel',
            id: 'problemMgtStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/problemMgt/getItemsByDocBranchId?docBranchId='+docBranchId,
                method: 'GET',
                reader: {
                    type:'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var problemMgtReadOnlyGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemMgtStore'),
            id: 'problemMgtReadOnlyGrid',
            margin: '20 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            columns: [{xtype: 'rownumberer'},
                {
                    text: '问题提出',
                    columns: [
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                        {text: '问题阶段', dataIndex: 'problemPhase', width: 100, editor: 'textfield',menuDisabled: true},
                        {text: '问题描述', dataIndex: 'description', width: 100, editor: 'textfield',menuDisabled: true},
                        {text: '原因分析', dataIndex: 'reasonAnalyse', width: 100, editor: 'textfield',menuDisabled: true},
                        {text: '台数', dataIndex: 'objectCount', width: 100,editor: 'textfield',menuDisabled: true},
                        {text: '创建人', dataIndex: 'creator', width: 100,editor: 'textfield',menuDisabled:true,},
                        {text: '创建时间', dataIndex: 'creatorDate', width: 100,editor: 'textfield',menuDisabled: false}
                ],
                },{
                    text: '问题确认',
                    columns: [
                        {text: '负责人', dataIndex: 'charger', width: 100,editor: 'textfield'},
                        {text: '等级', dataIndex: 'grade', width: 100,editor: 'textfield'},
                        {text: '目标解决时间', dataIndex: 'targetSolveDate', width: 100,editor: 'textfield'},
                        {text: '发起日期', dataIndex: 'startDate', width: 100,editor: 'textfield'},
                        {text: '流程链接', dataIndex: 'processLink', width: 100,editor: 'textfield'},
                        {text: '状态', dataIndex: 'status', width: 100,editor: 'textfield'},
                    ]
                },],
            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    var tField = e.record;

                    if(!allowEdit) {
                        return false;
                    }
                },
            }
        });


        var problemMgtReadOnlyForm = {
            title:'问题报表',
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '15 0 10 10',
            }, problemMgtReadOnlyGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [problemMgtReadOnlyForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('problemMgtStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            // alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    },
});
