Ext.define('PLM.view.ProblemShareInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ProblemShareInfo',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ProblemShareInfo',
    initComponent: function () {
        Ext.define('ctProblemShareInfoModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'containerId', 'docBranchId', 'problemNumber', 'problemPhase', 'description', 'creator', 'problemTerritory', 'problemGrade',
                'optimizeStrategy', 'charger', 'targetSolveDate', 'startDate', 'processLink', 'projectPhase', 'analysis', 'imgs',
                'badProportion', 'problemSource', 'oaNumber', 'riskNumber', 'relatedProblemNumber', 'optimizeResult',
                'verifyReportOrNot', 'verifyReportLink', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'problemStatus',
                'confirmExplain', 'creatorDate', 'replenish', 'shareLink','affirmCheck'],
            idProperty: 'id'
        });

        Ext.define('ctProblemVerifyModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'problemTerritory', 'undertaker', 'optimizeStrategy', 'planFinishDate', 'optimizeResult',
                'verifyReportLink', 'verifyReportNumber', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'isAssign'],
            idProperty: 'id'
        });


        var me = this;

        var problemShareInfoStore = Ext.create('Ext.data.Store', {
            //pageSize: 1,
            model: 'ctProblemShareInfoModel',
            id: 'problemShareInfoStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/problemMgt/getItemByIsShare',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var problemVerifyStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemVerifyModel',
            id: 'problemVerifyStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1//problemMgt/getProblemVerifyInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ProblemVerifyGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('problemVerifyStore'),
            id: 'ProblemVerifyGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 400,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {
                    text: '子问题处理',
                    columns: [
                        {
                            text: '领域',
                            dataIndex: 'problemTerritory',
                            width: 60,
                            menuDisabled: true,
                        },
                        {text: '子问题承担者', dataIndex: 'undertaker', width: 100, menuDisabled: true,},
                        {
                            text: '初步对策',
                            dataIndex: 'optimizeStrategy',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '计划解决时间',
                            dataIndex: 'planFinishDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '改善结论',
                            dataIndex: 'optimizeResult',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '验证报告编号',
                            dataIndex: 'verifyReportNumber',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '检验报告链接',
                            dataIndex: 'verifyReportLink',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '实际解决时间',
                            dataIndex: 'realitySolveDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '不整改原因',
                            dataIndex: 'noChangeCause',
                            width: 100,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                    ],
                },
                {
                    text: '子问题验证',
                    columns: [
                        {text: '验证结果', dataIndex: 'verifyResult', width: 100, menuDisabled: true,},
                        {
                            text: '验证说明',
                            dataIndex: 'verifyExplain',
                            width: 100,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                    ]
                },
                {text: '是否分配人', dataIndex: 'isAssign', width: 100, menuDisabled: true},

            ],
        });

        var followUp = Ext.create('Ext.Window', {
            id: 'followUp',
            title: '子问题跟进',
            width: 1250,
            height: 400,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [ProblemVerifyGrid],
        });


        var problemShareInfoGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemShareInfoStore'),
            id: 'problemShareInfoGrid',
            margin: '10 0 0 0',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 500,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer', width: 40},
                {
                    text: '问题提出',
                    columns: [
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'containerId', menuDisabled: true, hidden: true},
                        {text: '问题编号', dataIndex: 'problemNumber', width: 120,},

                        {text: '问题提出者', dataIndex: 'creator', width: 100,},
                        {
                            text: '问题领域',
                            dataIndex: 'problemTerritory',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {text: '问题级别', dataIndex: 'problemGrade', width: 100,},
                        {
                            text: '问题描述',
                            dataIndex: 'description',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '初步原因分析',
                            dataIndex: 'analysis',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },{
                            text: '初步对策',
                            dataIndex: 'optimizeStrategy',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '临时措施',
                            dataIndex: 'temporaryMeasures',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        //{text: '问题承担者', dataIndex: 'charger', width: 100, editor: allUserCombo_projectPlan},
                        {
                            text: '计划完成时间',
                            dataIndex: 'planFinishDate',
                            width: 120,
                            menuDisabled: true,
                            align: 'center',
                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                            }
                        },
                        {text: '发起日期', dataIndex: 'startDate', width: 100,},
                        {text: '流程链接', dataIndex: 'processLink', width: 100,},
                        {text: '项目阶段', dataIndex: 'projectPhase', width: 100,},
                        {text: 'PQA', dataIndex: 'pqaCheck', width: 100,},
                        {text: '开发代表', dataIndex: 'affirmCheck', width: 100,},
                        {
                            text: '图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: [{
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    containerId = record.get('containerId');
                                    problemId = problemNumber;
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + containerId + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {
                            text: '不良比例（%）',
                            dataIndex: 'badProportion',
                            width: 120,
                            menuDisabled: true,
                        },
                        {text: '问题来源', dataIndex: 'problemSource', width: 100},

                        {text: '成品代码', dataIndex: 'endPartNumber', width: 100,},
                        {text: '产品型号', dataIndex: 'productNumber', width: 100,},
                        {text: 'OA编号', dataIndex: 'oaNumber', width: 100,},
                        {text: '风险编号', dataIndex: 'riskNumber', width: 100,},
                        {text: '相关问题编号', dataIndex: 'relatedProblemNumber', width: 100,},
                        {text: '软件领域问题承担者', dataIndex: 'softwareCharger', width: 140,},
                        {text: '硬件领域问题承担者', dataIndex: 'hardwareCharger', width: 140,},
                        {text: '工艺领域问题承担者', dataIndex: 'craftCharger', width: 140,},
                        {text: '结构领域问题承担者', dataIndex: 'fabricCharger', width: 140,},
                        {text: '测试领域问题承担者', dataIndex: 'testCharger', width: 140,},
                        {text: '质量领域问题承担者', dataIndex: 'qualityCharger', width: 140,},
                        {text: '采购领域问题承担者', dataIndex: 'purchaseCharger', width: 140,},
                        {text: '制造领域问题承担者', dataIndex: 'makeCharger', width: 140,},
                        {text: '市场领域问题承担者', dataIndex: 'bazaarCharger', width: 140,},
                        {text: '其他领域问题承担者', dataIndex: 'elseCharger', width: 140,},
                    ]
                },/* {
                    text: '问题处理',
                    columns: [
                        {text: '改善结论', dataIndex: 'optimizeResult', width: 100,},
                        {text: '验证报告链接', dataIndex: 'verifyReportLink', width: 100,},
                        {text: '实际解决时间', dataIndex: 'realitySolveDate', width: 100,},
                        {text: '不整改原因', dataIndex: 'noChangeCause', width: 100,},
                    ]
                }, {
                    text: '问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'verifyExplain', width: 100,},
                    ]
                },*/ {
                    text: '问题结论',
                    columns: [
                        {text: '问题状态', dataIndex: 'problemStatus', width: 100,},
                        {
                            text: '确认说明',
                            dataIndex: 'confirmExplain',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                    ]
                }, {
                    text: '知识库共享',
                    columns: [{
                        text: '共享', width: 100, dataIndex: 'isShare', menuDisabled: true, value: '已共享',
                        renderer: function (value) {
                            if (value == "1") {
                                value = '已共享'
                            } else {
                                value = "未共享"
                            }
                            return value;
                        }
                    },
                        {
                            text: '补充信息',
                            dataIndex: 'replenish',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '补充信息图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: ['->', {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    containerId = record.get('containerId');
                                    problemId = problemNumber + '经验知识库';
                                    problemStatus = record.get('problemStatus');
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + containerId + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {text: '共享文档链接', dataIndex: 'shareLink', width: 100,}
                    ]
                },
            ],
            tbar: [
                {
                    text: '问题跟进信息',
                    scope: this,
                    handler: function () {
                        var newDocItems = new Array();
                        var removedRecords = problemShareInfoGrid.getSelectionModel().getSelection();

                        if (removedRecords == undefined || removedRecords == null || removedRecords.length == 0) {
                            alert("请选择对应的问题！");
                            return;
                        } else if (removedRecords.length > 1) {
                            alert("一次只能选择一个问题！");
                            return;
                        }
                        followUp.show();

                        getProblemVerifyInfo(removedRecords[0].get("docBranchId"));
                    }
                }
            ]
        });


        var problemShareInfoForm = {
            title: '查询参数',
            xtype: 'fieldset',
            region: 'center',
            align: 'center',
            id: 'mainForm',
            width: '98%',
            hidden: false,
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '15 0 10 10',

                items: [{
                    margin: '0 10 0 0',
                    fieldLabel: '问题编号',
                    id: 'cProblemNumber',
                    allowBlank: false,
                    width: 200,
                }, {
                    margin: '0 10 0 0',
                    xtype: 'combo',
                    fieldLabel: '问题状态',
                    labelWidth: 100,
                    id: 'cStatus',
                    multiSelect: false,
                    valueField: 'groupName',
                    displayField: 'groupName',
                    anyMatch: true,
                    editable: false,
                    store: [["开启","开启"],["已开始","已开始"],["待验证", "待验证"], ["已验证", "已验证"], ["已解决", "已解决"], ["返工", "返工"],
                       ],
                    allowBlank: false,
                    width: 200,
                }, {
                    xtype: 'combo',
                    fieldLabel: '创建人',
                    labelWidth: 100,
                    id: 'cCreator',
                    width: 200,
                    valueField: 'userFullName',
                    displayField: 'userFullName',
                    queryMode: 'local',
                    anyMatch: true,
                    typeAhead: true,
                    forceSelection: true,
                    triggerAction: 'all',
                    allowBlank: true,
                    store: allUserStore_projectPlan,
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '0 0 0 10',
                items: [{
                    margin: '0 10 0 0',
                    fieldLabel: '问题描述',
                    id: 'cDescription',
                    allowBlank: false,
                    width: 200,
                }, {
                    margin: '0 10 0 0',
                    xtype: 'combo',
                    fieldLabel: '项目阶段',
                    multiSelect: false,
                    valueField: 'groupName',
                    displayField: 'groupName',
                    anyMatch: true,
                    editable: false,
                    store: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"], ["TR4-TR4A", "TR4-TR4A"],
                        ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"]],
                    id: 'cProjectPhase',
                    allowBlank: false,
                    labelWidth: 100,
                    width: 200,
                }, {
                    xtype: 'combo',
                    fieldLabel: '责任人',
                    labelWidth: 100,
                    id: 'cCharger',
                    width: 200,
                    valueField: 'userFullName',
                    displayField: 'userFullName',
                    queryMode: 'local',
                    anyMatch: true,
                    typeAhead: true,
                    forceSelection: true,
                    triggerAction: 'all',
                    allowBlank: true,
                    store: allUserStore_projectPlan,
                }]
            },{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '10 0 0 10',
                items: [{
                    xtype: 'combo',
                    fieldLabel: '问题领域',
                    //multiSelect: true,
                    valueField: 'groupName',
                    displayField: 'groupName',
                    anyMatch: true,
                    editable: false,
                    store: [['软件', '软件'], ['硬件', '硬件'], ['工艺', '工艺'],
                        ['结构', '结构'], ['测试', '测试'], ['质量', '质量'],
                        ['采购', '采购'], ['制造', '制造'], ['市场', '市场'],
                        ['其他', '其他']],
                    labelWidth: 100,
                    fieldLabel: '问题领域',
                    id: 'cProblemTerritory',
                    allowBlank: false,
                    width: 200,
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                margin: '10 0 0 10',
                items: [{
                    xtype: 'datefield',
                    id: 'startDate',
                    fieldLabel: '发起时间从',
                    margin: '0 5 0 0',
                    allowBlank: false
                },
                {
                    xtype: 'datefield',
                    id: 'endDate',
                    fieldLabel: '到',
                    allowBlank: false
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'button',
                margin: '10 0 0 10',
                items: [{
                    text: '查询',
                    name: 'phone',
                    width: 50,
                    handler: function () {
                        doSearch()
                    }
                }]
            }, problemShareInfoGrid],
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [problemShareInfoForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('problemShareInfoStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    }
});


function getDate() {
    var data = {
        problemStatus: Ext.getCmp('cStatus').getValue(),
        problemNumber: Ext.getCmp('cProblemNumber').getValue(),
        description: Ext.getCmp('cDescription').getValue(),
        creator: Ext.getCmp('cCreator').getValue(),
        charger: Ext.getCmp('cCharger').getValue(),
        projectPhase: Ext.getCmp('cProjectPhase').getValue(),
        problemTerritory: Ext.getCmp('cProblemTerritory').getValue(),
    };
    return data;
}

/**
 * 按查询参数查询
 */
function doSearch() {
    var data = getDate();
    Ext.getStore('problemShareInfoStore').load({
        params: {
            data: Ext.encode(data),
            startDate: Ext.getCmp('startDate').getValue(),
            endDate: Ext.getCmp('endDate').getValue()
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询共享信息失败，请联系管理员！');
            }
        }
    });
}

/**
 * 编辑
 */
function save() {

    var data = {
        id: Ext.getCmp('id').getValue(),
        description: Ext.getCmp('description').getValue(),
    }

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/editProblem',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                doSearch();
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

//获取问题跟进信息
function getProblemVerifyInfo(branchId) {
    Ext.getStore('problemVerifyStore').load({
        params: {
            docBranchId: branchId,
        },
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    // alert('查询超时！请重试！')
                }
            }
        }
    });
}