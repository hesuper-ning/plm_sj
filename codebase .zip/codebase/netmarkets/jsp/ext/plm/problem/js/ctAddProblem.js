Ext.define('PLM.view.ctAddProblem',{
    extend:'Ext.panel.Panel',
    alias:'widget.ctAddProblem',
    border:false,
    layout:'anchor',
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    param_weekNumber:'',
    param_workReportId: '',
    // id: 'workReportDetailForm',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent:function(){


        //问题描述、问题来源、初步原因分析、期望完成时间
        //***********表单*************
        var headPanel = Ext.create('Ext.panel.Panel', {
            xtype:'form',
            margin: '10 0 0 0',
            border:false,
            items:[{
                layout:'hbox',
                border:false,
                margin:'5 5 10 30',
                items:[{
                    xtype:'textfield',
                    width:330,
                    fieldLabel: '<font color=red>*</font>问题来源',
                    id:'problemSource',
                    name:'problemSource',
                    labelWidth:90
                },{
                    xtype:'textfield',
                    margin:'0 0 0 20',
                    fieldLabel:'<font color=red>*</font>问题描述',
                    width:330,
                    id:'problemDesc',
                    name:'problemDesc',
                    labelWidth:110
                }
                ]
            },{
                layout:'hbox',
                border:false,
                margin:'5 5 10 30',
                items:[{
                    xtype:'textfield',
                    fieldLabel:'<font color=red>*</font>初步原因分析',
                    margin:'0 20 0 0',
                    width:330,
                    id:'preliminaryCauseAnalysis',
                    name:'preliminaryCauseAnalysis',
                    labelWidth:90
                },{
                    xtype:'datefield',
                    width:330,
                    fieldLabel: '<font color=red>*</font>期望完成时间',
                    minValue:new Date(),
                    id:'expectCompleteTime',
                    name:'expectCompleteTime',
                    labelWidth:110
                }
                ]
            },{
                layout:'hbox',
                border:false,
                margin:'5 5 10 30',
                items:[{
                    xtype:'combo',
                    fieldLabel:'<font color=red>*</font>问题等级',
                    margin:'0 20 0 0',
                    store:[['高','高'],['中','中'],['低','低']],
                    width:330,
                    id:'problemLevel',
                    name:'problemLevel',
                    labelWidth:90
                }
                ]
            }]
        });



/////////////////////////Main Panel items//////////////////////////////////
        this.items=[
            headPanel,
            {
                xtype:'panel',
                layout:'hbox',
                margin:'10 5 10 120',
                border:false,
                items:[{
                    xtype:'panel',
                    border:false,
                    html:'&nbsp;',
                    width:10
                },{
                    margin:'5 5 20 10',
                    xtype:'button',
                    text:'&nbsp;添加&nbsp;',
                    scale : 'medium',
                    handler: function() {
                        var problemDesc=Ext.getCmp('problemDesc').getValue();
                        var preliminaryCauseAnalysis=Ext.getCmp('preliminaryCauseAnalysis').getValue();
                        var expectCompleteTime=Ext.getCmp('expectCompleteTime').getValue();
                        var problemSource=Ext.getCmp('problemSource').getValue();
                        var problemLevel = Ext.getCmp('problemLevel').getValue();
                        if(problemDesc==""||preliminaryCauseAnalysis=="" ||
                            expectCompleteTime==""||problemSource==""||problemLevel=="") {
                            alert("弹窗中字段为必填项，不允许为空");
                            return;
                        }
                        saveAtt();
                        Ext.getCmp('requireWin2').close();
                    }
                },{
                    margin:'5 5 20 40',
                    xtype:'button',
                    text:'&nbsp;取消&nbsp;',
                    scale : 'medium',
                    handler: function() {
                        Ext.getCmp('requireWin2').close();
                    }

                }]


            }];

        this.callParent();
    },//~End of initComponent
    listeners:{
        'afterrender':function(){

        }
    }

});
////////////////////////Function area//////////////////////////



/**
 * 保存
 */
function saveAtt() {
    var tempRec = {
        libraryId: libraryId,
        problemDesc:Ext.getCmp('problemDesc').getValue(),
        preliminaryCauseAnalysis:Ext.getCmp('preliminaryCauseAnalysis').getValue(),
        expectCompleteTime:Ext.getCmp('expectCompleteTime').getValue(),
        problemSource:Ext.getCmp('problemSource').getValue(),
        problemLevel: Ext.getCmp('problemLevel').getValue(),
        libraryOid:libraryOid,
    };

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemManage/addProblem',
        params:{
            data:Ext.encode(tempRec)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']){
                doSearch();
                Ext.getCmp("problemGrid").store.currentPage = 1;
                Ext.getCmp('workReportWin2').close();

                Ext.getStore('problemStore').reload();
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}
