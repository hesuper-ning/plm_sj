Ext.define('PLM.view.ProblemProcess', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ProblemProcess',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        param_id: undefined,
    },
    id: 'ProblemProcess',
    initComponent: function () {
        var me = this;
        Ext.define('ctProblemMgtModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'containerId', 'docBranchId', 'problemNumber', 'description', 'creator', 'problemTerritory','problemSourceTerritory', 'problemGrade',
                'optimizeStrategy', 'charger', 'planFinishDate', 'startDate', 'processLink', 'projectPhase', 'analysis', 'imgs',
                'badProportion', 'problemSource', 'oaNumber', 'riskNumber', 'relatedProblemNumber', 'optimizeResult',
                'verifyReportOrNot', 'verifyReportLink', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'problemStatus',
                'confirmExplain', 'creatorDate', 'replenish', 'shareLink','pqaCheck','affirmCheck'],
            idProperty: 'id'
        });

        Ext.define('ctProblemVerifyModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'problemTerritory', 'undertaker', 'optimizeStrategy', 'planFinishDate', 'optimizeResult',
                'verifyReportLink', 'verifyReportNumber', 'realitySolveDate', 'noChangeCause', 'verifyExplain','verifyResult', 'isAssign'],
            idProperty: 'id'
        });

        var problemVerifyStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemVerifyModel',
            id: 'problemVerifyStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1//problemMgt/getProblemVerifyInfo?docBranchId=' + docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var problemMgtStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemMgtModel',
            id: 'problemMgtStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/problemMgt/getItemsByDocBranchId?docBranchId=' + docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        //========可编辑列头显示控制============
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        //提交
        var descriptionText = '问题描述';
        var creatorText = '问题提出者';
        var problemTerritoryText = '问题领域';
        var problemSourceTerritoryText = '问题来源（评审）';
        var problemGradeText = '问题等级';
        var optimizeStrategyText = '初步对策';
        var chargerText = '问题承担者';
        var planFinishDateText = '计划完成时间';
        var projectPhaseText = '项目阶段';
        var analysisText = '初步原因分析';
        var PQAText = 'PQA';
        var affirmCheckText = '开发代表';
        var badProportionText = '不良比例';
        var problemSourceText = '问题来源（领域）';
        var OANumberText = 'OA编号';
        var riskNumberText = '风险编号';
        var relatedProblemNumberText = '相关问题编号';
        var temporaryMeasuresText = '临时措施';
        var endPartNumberText = '成品代码';
        var productNumberText = '产品型号';

        //处理
        var planFinishDateText1 = '计划完成时间';
        var optimizeStrategyText1 = '改善对策';
        var optimizeResultText = '改善结论';
        var verifyReportLinkText = '验证报告编号';
        var noChangeCauseText = '不整改原因';

        //验证
        var verifyExplainText = '验证说明';
        var verifyResultText = '验证结果';

        //确认
        var confirmExplainText = '确认说明';


        if (allowEdit) {
            //提交时可填与必填项提示
            if ("ActivityNode_Problem_Submit" == actKey) {
                descriptionText = redStarFlag + blueFlagStart + descriptionText + blueFlagEnd;
                affirmCheckText = redStarFlag + blueFlagStart + affirmCheckText + blueFlagEnd;
                creatorText = redStarFlag + blueFlagStart + creatorText + blueFlagEnd;
                problemTerritoryText = redStarFlag + blueFlagStart + problemTerritoryText + blueFlagEnd;
                problemSourceTerritoryText = redStarFlag + blueFlagStart + problemSourceTerritoryText + blueFlagEnd;
                problemGradeText = redStarFlag + blueFlagStart + problemGradeText + blueFlagEnd;
                optimizeStrategyText = redStarFlag + blueFlagStart + optimizeStrategyText + blueFlagEnd;
                chargerText = redStarFlag + blueFlagStart + chargerText + blueFlagEnd;
                planFinishDateText = redStarFlag + blueFlagStart + planFinishDateText + blueFlagEnd;
                projectPhaseText = redStarFlag + blueFlagStart + projectPhaseText + blueFlagEnd;
                analysisText = redStarFlag + blueFlagStart + analysisText + blueFlagEnd;
                PQAText = redStarFlag + blueFlagStart + PQAText + blueFlagEnd;
                badProportionText = blueFlagStart + badProportionText + blueFlagEnd;
                problemSourceText = redStarFlag + blueFlagStart + problemSourceText + blueFlagEnd;
                OANumberText = blueFlagStart + OANumberText + blueFlagEnd
                riskNumberText = blueFlagStart + riskNumberText + blueFlagEnd
                relatedProblemNumberText = blueFlagStart + relatedProblemNumberText + blueFlagEnd
                temporaryMeasuresText = blueFlagStart + temporaryMeasuresText + blueFlagEnd
                endPartNumberText = blueFlagStart + endPartNumberText + blueFlagEnd
                productNumberText = blueFlagStart + productNumberText + blueFlagEnd
            }
            //编辑问题处理时可填与必填项提示
            else if ("ActivityNode_Problem_Dispose" == actKey) {
                optimizeResultText = redStarFlag + blueFlagStart + optimizeResultText + blueFlagEnd;
                planFinishDateText1 = redStarFlag + blueFlagStart + planFinishDateText1 + blueFlagEnd;
                optimizeStrategyText1 = redStarFlag + blueFlagStart + optimizeStrategyText1 + blueFlagEnd;
                verifyReportLinkText = blueFlagStart + verifyReportLinkText + blueFlagEnd;
                noChangeCauseText =  blueFlagStart + noChangeCauseText + blueFlagEnd;
            }
            //编辑问题验证时可填与必填提示
            else if ("ActivityNode_Problem_Verify" == actKey) {
                verifyExplainText = redStarFlag + blueFlagStart + verifyExplainText + blueFlagEnd;
                verifyResultText = redStarFlag + blueFlagStart + verifyResultText + blueFlagEnd;
            }
            //编辑问题确认时可填与必填提示
            else if ("ActivityNode_Problem_Confirm" == actKey) {
                confirmExplainText = redStarFlag + blueFlagStart + confirmExplainText + blueFlagEnd;
            }
        }

        //上传图片窗口
        var uploadImageWindow = Ext.create('Ext.Window', {
            title: '导入图片',
            width: 550,
            height: 350,
            //autoHeight : true,
            //autoWidth : true,
            closeAction: 'hide',
            id: 'uploadImageWindow',
            autoScroll: false,
            //closable:false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: {
                xtype: 'uploadImagePanel'
            }
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });
        var allUserCombo_projectPlan = new Ext.form.ComboBox({
            name: 'allUserCombo_projectPlan',
            id: 'allUserCombo_projectPlan',
            valueField: 'userFullName',
            displayField: 'userFullName',
            queryMode: 'local',
            anyMatch: true,
            typeAhead: true,
            forceSelection: true,
            triggerAction: 'all',
            allowBlank: true,
            store: allUserStore_projectPlan,
        });

        var problemTerritoryCombo = new Ext.form.ComboBox({
            name: 'problemTerritoryCombo',
            id: 'problemTerritoryCombo',
            multiSelect: true,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['软件', '软件'], ['硬件', '硬件'], ['工艺', '工艺'],
                ['结构', '结构'], ['测试', '测试'], ['质量', '质量'],
                ['采购', '采购'], ['制造', '制造'], ['市场', '市场'],
                ['其他', '其他']]
        });

        var problemGradeCombo = new Ext.form.ComboBox({
            name: 'problemGradeCombo',
            id: 'problemGradeCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//严重，一般，轻微，N/A
            store: [['严重', '严重'], ['一般', '一般'], ['轻微', '轻微'],
                ['N/A', 'N/A']]
        });

        var problemSourceTerritoryCombo = new Ext.form.ComboBox({
            name: 'problemSourceTerritoryCombo',
            id: 'problemSourceTerritoryCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//非评审- 原理图及PCB评审- 结构评审- 软件评审- 总体方案评审- 需求规格评审- TR评审
            store: [['非评审', '非评审'], ['原理图及PCB评审', '原理图及PCB评审'], ['结构评审', '结构评审'],['软件评审', '软件评审']
                ,['总体方案评审', '总体方案评审'],['需求规格评审', '需求规格评审'],['TR评审', 'TR评审']]
        });

        var projectPhaseCombo = new Ext.form.ComboBox({
            name: 'projectPhaseCombo',
            id: 'projectPhaseCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//TR2， TR4，TR4A, TR5, TR6
            store: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"], ["TR4-TR4A", "TR4-TR4A"],
                ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"]]
        });


        var problemSourceCombo = new Ext.form.ComboBox({
            name: 'problemSourceCombo',
            id: 'problemSourceCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//研发，质量，工艺，测试，生产、客诉，售后质量，制程异常，用户体验
            store: [['研发', '研发'], ['质量', '质量'], ['工艺', '工艺'], ['测试', '测试'],
                ['客诉', '客诉'], ['售后质量', '售后质量'], ['制程异常', '制程异常'], ['用户体验', '用户体验']]
        });

        var isVerifyRejectCombo = new Ext.form.ComboBox({
            name: 'isVerifyRejectCombo',
            id: 'isVerifyRejectCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['通过', '通过'], ['驳回', '驳回']]
        });


        // 创建者编辑panel
        var editPanel = new Ext.create("Ext.form.Panel", {
            autoWidth: true,
            autoHeight: true,
            layout: 'form', // 最大表单
            margin: '0 20 0 0',
            autoScroll: true,
            border: false,
            buttonAlign: 'center',
            id: 'editPanel',
            items: [{
                xtype: "textfield",
                name: "id",
                hidden: true,
                id: "id",
                fieldLabel: "id"
            },
                {
                    xtype: "textarea",
                    margin: '10 0 10 0',
                    width: 350,
                    rows: 2,
                    name: "optimizeResult",
                    id: "optimizeResult",
                    fieldLabel: "改善结论"
                }, {
                    xtype: "textfield",
                    name: "verifyReportLink",
                    id: "verifyReportLink",
                    width: 350,
                    fieldLabel: "验证报告编码",
                    emptyText: '有则填文档编码',
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('verifyReportLink').getValue();
                            //验证编号是否正确
                            if (value != "") {
                                var url = getVerifyReportLink(value);
                                Ext.getCmp('verifyReportLink').setValue(url);
                            }
                        }
                    }
                }, {
                    xtype: "textfield",
                    margin: '10 0 10 0',
                    width: 350,
                    rows: 2,
                    name: "noChangeCause",
                    id: "noChangeCause",
                    fieldLabel: "不整改原因"
                }]
        });


        var requireWin2 = Ext.create('Ext.Window', {
            id: 'requireWin2',
            title: '编辑问题',
            width: 500,
            height: 250,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: editPanel,
            layout: "fit",
            bbar: {
                xtype: "toolbar",
                items: ['->', {
                    xtype: "button",
                    text: "保存",
                    width: 60,
                    listeners: {
                        "click": function (btn) {
                            save();
                            Ext.getCmp('requireWin2').close();
                        }
                    }
                }, {
                    xtype: "button",
                    width: 60,
                    text: "取消",
                    listeners: {
                        "click": function (btn) {
                            Ext.getCmp('requireWin2').close();
                        }
                    }
                }, '->']
            }
        });

        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var ProblemVerifyGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('problemVerifyStore'),
            id: 'ProblemVerifyGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 400,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            columns: [{xtype: 'rownumberer'},
                {
                    text: '子问题处理',
                    columns: [
                        {
                            text: '领域',
                            dataIndex: 'problemTerritory',
                            width: 60,
                            menuDisabled: true,
                        },
                        {text: '子问题承担者', dataIndex: 'undertaker', width: 100, menuDisabled: true},
                        {
                            text: optimizeStrategyText1,
                            dataIndex: 'optimizeStrategy',
                            width: 100,
                            menuDisabled: true,
                            editor: 'textarea',
                            renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }
                        },
                        {
                            text: planFinishDateText1,
                            dataIndex: 'planFinishDate',
                            width: 120,
                            editor: new Ext.form.DateField({format: 'Y-m-d',minValue: new Date(),}),
                            menuDisabled: true,
                            align: 'center',
                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                            }
                        },
                        {
                            text: optimizeResultText,
                            dataIndex: 'optimizeResult',
                            width: 100,
                            menuDisabled: true,
                            editor: 'textarea',
                            renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }
                        },
                        {
                            text: verifyReportLinkText,
                            dataIndex: 'verifyReportNumber',
                            width: 100,
                            menuDisabled: true,
                            editor: 'textfield'
                        },
                        {
                            text: '检验报告链接',
                            dataIndex: 'verifyReportLink',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '实际解决时间',
                            dataIndex: 'realitySolveDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: noChangeCauseText,
                            dataIndex: 'noChangeCause',
                            width: 100,
                            menuDisabled: true,
                            editor: 'textarea',
                            renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }
                        },
                    ],
                },
                {
                    text: '子问题验证',
                    columns: [
                        {text: verifyResultText, dataIndex: 'verifyResult', width: 100, menuDisabled: true, editor:isVerifyRejectCombo},
                        {text: verifyExplainText, dataIndex: 'verifyExplain', width: 100, menuDisabled: true, editor: 'textarea',
                            renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }
                        },
                    ]
                },
                {text: '是否分配人', dataIndex: 'isAssign', width: 120, menuDisabled: true},

            ],
            listeners: {
                change: 'onAllCircuitsChecked',
                beforeedit: function (editor, e, eOpts) {
                    var tRecord = e.record; //得到当前行所有数据
                    if (tRecord.get('isAssign') == 'NA') {
                        return false;
                    }

                    if ("ActivityNode_Problem_Dispose" == actKey) {
                        if (tRecord.get('undertaker') != userDisplayName) {
                            return false;
                        }
                        if ("verifyExplain" != e.field && "verifyResult" != e.field ) {
                            return true;
                        } else {
                            //Ext.getCmp('saveStatus2').setText('只能编辑自己负责的行！');
                            return false;
                        }
                    } else if ("ActivityNode_Problem_Verify" == actKey) {
                        if ("verifyExplain" != e.field&&"verifyResult" != e.field) {
                            //Ext.getCmp('saveStatus2').setText('只能编辑自己负责的行！');
                            return false;
                        } else {
                            return true;
                        }
                    }

                    return false;
                }
            }
        });

        ProblemVerifyGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                if (tValue.toString().length>1200){
                    alert("内容信息长度不能大于1200！！！");
                    return;
                }

                if (tField == "verifyReportNumber") {
                    Ext.getStore('problemVerifyStore').reload()
                }
                var callbackFn = function () {
                    tRecord.commit();
                };
                updateVerify(tField, tValue, itemId, tRecord, callbackFn);
            });


        var followUp = Ext.create('Ext.Window', {
            id: 'followUp',
            title: '子问题跟进',
            width: 1250,
            height: 400,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [ProblemVerifyGrid],
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var ProblemMgtGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemMgtStore'),
            id: 'ProblemMgtGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            tbar: [
                {
                    hidden: true,//allowEdit ? (actKey == "ActivityNode_Problem_Dispose" ? false : true) : true,
                    text: '编辑问题',
                    id: 'edit',
                    name: 'edit',
                    scope: this,
                    handler: function () {
                        var editRecords = Ext.getCmp('ProblemMgtGrid').getSelectionModel().getSelection();
                        if (editRecords.length == 0) {
                            alert("请选择要编辑的产品信息！")
                            return;
                        } else if (editRecords.length > 1) {
                            alert("只能编辑一个产品信息！")
                            return;
                        }
                        //ID
                        var id = editRecords[0].data['id'];

                        requireWin2.show();
                        getProblem(id);
                    }
                }, {
                    text: '子问题跟进',
                    id: 'verify',
                    name: 'verify',
                    //hidden: allowEdit ? (actKey == "ActivityNode_Problem_Dispose" ? false : (actKey=="ActivityNode_Problem_Verify"?false:true)) : true,
                    scope: this,
                    handler: function () {
                        followUp.show();
                        getProblemVerifyInfo();
                    }
                }, {
                    xtype: 'tbtext',
                    text: '',
                    id: 'saveStatus2',
                    disabled: true
                }
            ],
            columns: [{xtype: 'rownumberer'},
                {
                    text: '问题提出',
                    columns: [
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                        {text: '问题编号', dataIndex: 'problemNumber', width: 100,},

                        {text: creatorText, dataIndex: 'creator', width: 100, editor: allUserCombo_projectPlan},
                        {text: problemTerritoryText,dataIndex: 'problemTerritory',width: 100,editor: problemTerritoryCombo,
                            renderer: function(value,metaData,record,row,col,store){
                                var temp = new Array();
                                if (value=='' || value == undefined || value == null){
                                    return '';
                                }
                                if(!Array.isArray(value)){
                                    value += ",";
                                    var start = 0;
                                    var pos = value.indexOf(',');
                                    while (pos > -1) {
                                        temp.push(value.substr(start, pos-start));
                                        start = pos + 1;
                                        pos = value.indexOf(',', pos + 1);
                                    }
                                    record.set("problemTerritory",temp);
                                    record.commit();
                                }else{
                                    temp = value;
                                }
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+temp+"'";
                                return temp;
                            }
                        },
                        {text: problemGradeText, dataIndex: 'problemGrade', width: 100, editor: problemGradeCombo},
                        {text: problemSourceTerritoryText, dataIndex: 'problemSourceTerritory', width: 100, editor: problemSourceTerritoryCombo},
                        {text: descriptionText, dataIndex: 'description', width: 100, editor: 'textfield',renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        {text: analysisText, dataIndex: 'analysis', width: 100, editor: 'textfield',renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        {text: optimizeStrategyText, dataIndex: 'optimizeStrategy', width: 100, editor: 'textfield',renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }},
                        {text: temporaryMeasuresText, dataIndex: 'temporaryMeasures', width: 100, editor: 'textfield'},
                        //{text: chargerText, dataIndex: 'charger', width: 100, editor: allUserCombo_projectPlan},
                        {text: planFinishDateText, dataIndex: 'planFinishDate', width: 100,editor: new Ext.form.DateField({format: 'Y-m-d',minValue: new Date(),}),
                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                            }},
                        {text: '发起日期', dataIndex: 'startDate', width: 100,},
                        {text: '流程链接', dataIndex: 'processLink', width: 100,},
                        {text: projectPhaseText, dataIndex: 'projectPhase', width: 100, editor: projectPhaseCombo},
                        {text: PQAText, dataIndex: 'pqaCheck', width: 100, editor: allUserCombo_projectPlan},
                        {text: affirmCheckText, dataIndex: 'affirmCheck', width: 100, editor: allUserCombo_projectPlan},
                        {
                            text: '图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            getClass: function (v, meta, rec) {
                                if (actKey != "ActivityNode_Problem_Submit") {
                                    return this.disabledCls;
                                }
                            },
                            items: ['->', {
                                iconCls: 'icon-uploadImage',
                                // icon: '',
                                tooltip: '添加图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    problemId = problemNumber;
                                    if (actKey == "ActivityNode_Problem_Submit") {
                                        uploadImageWindow.show();
                                    }
                                }
                            }, '->', {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    containerId = record.get('containerId');
                                    problemId = problemNumber;
                                    var list = null;
                                    var flag = false;

                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + containerId + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {

                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));

                                            } else {
                                                alert(obj['msg']);

                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');

                                        }
                                    });//~End of request
                                }
                            }, '->']
                        },
                        {
                            text: badProportionText,
                            dataIndex: 'badProportion',
                            width: 100,
                            editor: 'textfield',
                            menuDisabled: true,
                        },
                        {text: problemSourceText, dataIndex: 'problemSource', width: 100, editor: problemSourceCombo},
                        {text: endPartNumberText, dataIndex: 'endPartNumber', width: 100, editor: 'textfield'},
                        {text: productNumberText, dataIndex: 'productNumber', width: 100, editor: 'textfield'},
                        {text: 'OA编号', dataIndex: 'oaNumber', width: 100,},
                        {text: riskNumberText, dataIndex: 'riskNumber', width: 100, editor: 'textfield'},
                        {
                            text: relatedProblemNumberText,
                            dataIndex: 'relatedProblemNumber',
                            width: 100,
                            editor: 'textfield'
                        },
                        {text: '软件领域问题承担者', dataIndex: 'softwareCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '硬件领域问题承担者', dataIndex: 'hardwareCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '工艺领域问题承担者', dataIndex: 'craftCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '结构领域问题承担者', dataIndex: 'fabricCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '测试领域问题承担者', dataIndex: 'testCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '质量领域问题承担者', dataIndex: 'qualityCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '采购领域问题承担者', dataIndex: 'purchaseCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '制造领域问题承担者', dataIndex: 'makeCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '市场领域问题承担者', dataIndex: 'bazaarCharger', width: 140, editor: allUserCombo_projectPlan},
                        {text: '其他领域问题承担者', dataIndex: 'elseCharger', width: 140, editor: allUserCombo_projectPlan},
                    ]
                },/* {
                    text: '问题处理',
                    columns: [
                        {text: optimizeResultText, dataIndex: 'optimizeResult', width: 100, menuDisabled: true,},
                        {text: verifyReportLinkText, dataIndex: 'verifyReportLink', width: 100, menuDisabled: true,},
                        {text: noChangeCauseText, dataIndex: 'noChangeCause', width: 100, menuDisabled: true,},
                        {text: '实际解决时间', dataIndex: 'realitySolveDate', width: 100, menuDisabled: true,},
                    ]
                }, {
                    text: '问题验证',
                    columns: [
                        {
                            text: verifyExplainText,
                            dataIndex: 'verifyExplain',
                            width: 100,
                            editor: 'textfield',
                            menuDisabled: true,
                        },
                    ]
                }, */{
                    text: '问题结论',
                    columns: [
                        {
                            text: '问题状态',
                            dataIndex: 'problemStatus',
                            width: 100,
                            editor: 'textfield',
                            menuDisabled: true,
                        },
                        {
                            text: confirmExplainText,
                            dataIndex: 'confirmExplain',
                            width: 100,
                            editor: 'textfield',
                            menuDisabled: true,renderer: function(value,metaData,record,row,col,store){
                                //提示tip
                                metaData.tdAttr = " data-qtip = '"+value+"'";
                                return value;
                            }
                        },
                    ]
                }, {
                    text: '知识库共享',
                    columns: [{
                        text: '共享', width: 100, dataIndex: 'isShare', menuDisabled: true, value: '已共享',
                        renderer: function (value) {
                            if (value == '1') {
                                value = '已共享'
                            } else {
                                value = "未共享"
                            }
                            return value;
                        }
                    }, {text: '补充信息', dataIndex: 'replenish', width: 100,renderer: function(value,metaData,record,row,col,store){
                            //提示tip
                            metaData.tdAttr = " data-qtip = '"+value+"'";
                            return value;
                        }},
                        {text: '共享文档链接', dataIndex: 'shareLink', width: 100,}
                    ]
                },
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    if (allowEdit) {
                        if ("ActivityNode_Problem_Submit" == actKey) {
                            if ("optimizeResult" == e.field || "verifyReportLink" == e.field || "realitySolveDate" == e.field || "noChangeCause" == e.field
                                || "verifyExplain" == e.field || "confirmExplain" == e.field) {
                                Ext.getCmp('saveStatus2').setText('只能编辑自己负责的行！');
                                return false;
                            }
                        } else if ("ActivityNode_Problem_Dispose" == actKey) {
                            if ("optimizeResult" == e.field || "verifyReportLink" == e.field || "realitySolveDate" == e.field
                                || "noChangeCause" == e.field) {
                                //alert(e.field);

                                return true;
                            } else {
                                Ext.getCmp('saveStatus2').setText('只能编辑自己负责的行！');
                                return false;
                            }
                        } else if ("ActivityNode_Problem_Verify" == actKey) {
                            if ("verifyExplain" != e.field) {
                                Ext.getCmp('saveStatus2').setText('只能编辑自己负责的行！');
                                return false;
                            }
                        } else if ("ActivityNode_Problem_Confirm" == actKey) {
                            if ("confirmExplain" != e.field) {
                                Ext.getCmp('saveStatus2').setText('只能编辑自己负责的行！');
                                return false;
                            }
                        } else if ("ActivityNode_ProblemShare_addDescription" == actKey) {
                            if ("description" != e.field) {
                                Ext.getCmp('saveStatus2').setText('只能编辑自己负责的行！');
                                return false;
                            }
                        } else {
                            Ext.getCmp('saveStatus2').setText('不允许编辑！');
                            return false;
                        }
                    } else {
                        Ext.getCmp('saveStatus2').setText('不允许编辑！');
                        return false;
                    }
                }
            },
            bbar: Ext.create('Ext.PagingToolbar', {
                store: problemMgtStore,
                style: {
                    float: 'right'
                },
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空"
            }),

        });


        ProblemMgtGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                if (tValue != null) {
                    if (tValue.toString().length > 1200) {
                        alert("内容信息长度不能大于1200！！！");
                    }
                }

                if (tField =='riskNumber'){
                    var isCorrect = checkRiskNumber(tValue);
                    if (!isCorrect){
                        return;
                    }
                }else if (tField =='relatedProblemNumber'){
                    var isCorrect = checkProblemNumber(tValue);
                    if (!isCorrect){
                        return;
                    }
                }else if(tField == "endPartNumber"){
                    Ext.getStore('problemMgtStore').reload();
                }



                var callbackFn = function () {
                    tRecord.commit();
                };
                updateProblem(tField, tValue, itemId, tRecord, callbackFn);
            });


        var mockExampleForm = {
            title: '问题报表',
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [ProblemMgtGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('problemMgtStore').load({

                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            // alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    },
});

/**
 * 问题审批节点 获取信息
 * @param id
 */
function getProblem(id) {
    if (id == undefined || id.length == 0) {
        return;
    }
    // 查询MockExample form表单数据
    Ext.Ajax.request({
        url: '/Windchill/ptc1/problemMgt/getItemById?id=' + id,
        method: 'GET',
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                var mainPanel = Ext.getCmp('editPanel');
                mainPanel.getForm().setValues(obj['data']);
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：查询信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

/**
 * 问题审批节点 编辑
 */
function save() {

    var data = {
        id: Ext.getCmp('id').getValue(),
        optimizeResult: Ext.getCmp('optimizeResult').getValue(),
        verifyReportLink: Ext.getCmp('verifyReportLink').getValue(),
        noChangeCause: Ext.getCmp('noChangeCause').getValue()
    }

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/editProblem',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                doSearch();
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

//修改
function updateProblem(tField, tValue, id, tRecord, callbackFn) {
    var data = {
        key: tField,
        value: tValue,
        id: id,
        containerId: containerId
    }
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/updateProblem',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                if (id != "" && id != null) {
                    tRecord.commit();
                    if (callbackFn) {
                        callbackFn();
                    }
                } else {
                    doSearch();
                }
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存问题信息失败，请检查网络！');
        }
    });
}

/**
 * 按查询参数查询
 */
function doSearch() {
    Ext.getStore('problemMgtStore').load({
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询用户任务信息失败，请联系管理员！');
            }
        }
    });
}

//获取问题跟进信息
function getProblemVerifyInfo() {
    Ext.getStore('problemVerifyStore').load({

        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    // alert('查询超时！请重试！')
                }
            }
        }
    });
}


//修改
function updateVerify(tField, tValue, id, tRecord, callbackFn) {
    var data = {
        key: tField,
        value: tValue,
        id: id,
    }
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/updateVerify',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                if (id != "" && id != null) {
                    tRecord.commit();
                    if (callbackFn) {
                        callbackFn();
                    }
                } else {
                    getProblemVerifyInfo();
                }
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存问题信息失败，请检查网络！');
        }
    });
}