Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    //autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'ProblemMgtMock',
        in_objectDesc: '定制的Form表单',
    },
    id: 'MockExample',


    initComponent: function () {
        var me = this;
        var problemStore = Ext.create('PLM.store.MockItemStore', {
            id: 'problemStore'
        });

        this.title = '问题管理';

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });



        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemStore'),
            id: 'mockExampleGrid',
            margin: '10 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            tbar: [
                {
                    iconCls : 'icon-add',
                    xtype: 'button',
                    text: '添加',
                    id:'addData',
                },
                {
                    iconCls : 'icon-delete',
                    xtype: 'button',
                    text: '删除',
                    id:'removeData',
                },{
                    text : '保存数据',
                },{
                    text: '导出当前问题报表',
                }, {
                    text: '关闭问题',
                }, {
                    text: '启动问题流程',
                }, {
                    text: '导入',
                }, {
                    text: '模板下载',
                }
            ],

            columns: [{xtype: 'rownumberer'},
                {
                    text: '问题提出',
                    columns: [
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                        {text: '问题编号', dataIndex: 'data1', width: 100, editor: 'textfield',},
                        {text: '问题描述', dataIndex: 'data2', width: 100, editor: 'textfield'},
                        {text: '问题提出者', dataIndex: 'data4', width: 100,editor: 'textfield'},
                        {text: '问题领域', dataIndex: 'data3', width: 100, editor: 'textfield',},
                        {text: '问题级别', dataIndex: 'data5', width: 100,editor: 'textfield'},
                        {text: '改善对策', dataIndex: 'data6', width: 100,editor: 'textfield'},
                        {text: '问题承担者', dataIndex: 'data7', width: 100,editor: 'textfield'},
                        {text: '计划完成时间', dataIndex: 'data8', width: 100,editor: 'textfield'},
                        {text: '临时措施', dataIndex: 'data25', width: 100,editor: 'textfield'},
                        {text: '成品编号', dataIndex: 'data26', width: 100,editor: 'textfield'},
                        {text: '产品编号', dataIndex: 'data27', width: 100,editor: 'textfield'},
                        {text: '发起日期', dataIndex: 'data9', width: 100,editor: 'textfield'},
                        {text: '流程链接', dataIndex: 'data10', width: 100,editor: 'textfield'},
                        {text: '项目阶段', dataIndex: 'data11', width: 100,editor: 'textfield'},
                        {text: '初步原因分析', dataIndex: 'data12', width: 100,editor: 'textfield'},
                        {text: '图片', dataIndex: 'data13', width: 100,editor: 'textfield',menuDisabled:true,},
                        {text: '不良比例（%）', dataIndex: 'data14', width: 100,editor: 'textfield',menuDisabled:true,},
                        {text: '问题来源', dataIndex: 'data15', width: 100,editor: 'textfield'},
                        {text: 'OA编号', dataIndex: 'data16', width: 100,editor: 'textfield'},
                        {text: '风险编号', dataIndex: 'data17', width: 100,editor: 'textfield'},
                        {text: '相关问题编号', dataIndex: 'data18', width: 100,editor: 'textfield'},
                        ]
                },{
                    text: '问题处理',
                    columns: [
                        {text: '改善结论', dataIndex: 'data19', width: 100,editor: 'textfield',menuDisabled:true,},
                        {text: '是否有验证报告', dataIndex: 'data20', width: 100,editor: 'textfield',menuDisabled:true,},
                        {text: '验证报告链接', dataIndex: 'data21', width: 100,editor: 'textfield',menuDisabled:true,},
                        {text: '实际解决时间', dataIndex: 'data22', width: 100,editor: 'textfield',menuDisabled:true,},
                        {text: '不整改原因', dataIndex: 'data23', width: 100,editor: 'textfield',menuDisabled:true,},
                    ]
                },{
                    text: '问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'data24', width: 100,editor: 'textfield',menuDisabled:true,},
                    ]
                },{
                    text:'问题结论',
                    columns:[
                        {text: '问题状态', dataIndex: 'data25', width: 100,editor: 'textfield',menuDisabled:true,},
                        {text: '确认说明', dataIndex: 'data26', width: 100,editor: 'textfield',menuDisabled:true,},
                    ]
                }
            ]
        });



        var mockExampleForm = {
            title:'查询参数',
            xtype: 'fieldset',
            id: 'mainForm',
            width: '98%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '15 0 10 10',

                items: [{
                    margin: '0 10 0 0',
                    fieldLabel: '问题编号',
                    name: 'email',
                    allowBlank: false,
                    width: 200,
                }, {
                    margin: '0 10 0 0',
                    fieldLabel: '问题状态',
                    labelWidth: 100,
                    name: 'phone',
                    width: 200,
                },{
                    fieldLabel: '提交人',
                    labelWidth: 100,
                    name: 'phone',
                    width: 200,
                }]
            },{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '0 0 0 10',
                items: [{
                    margin: '0 10 0 0',
                    fieldLabel: '问题描述',
                    name: 'email',
                    allowBlank: false,
                    width: 200,
                }, {
                    margin: '0 10 0 0',
                    fieldLabel: '责任人',
                    labelWidth: 100,
                    name: 'phone',
                    width: 200,
                }]
            },{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'button',
                margin: '10 0 0 10',
                items: [{
                    text: '查询',
                    name: 'phone',
                    width: 50,
                }]
            }]
        };

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm, mockExampleGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('problemStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('problemStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('problemStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
        }
    }
});

