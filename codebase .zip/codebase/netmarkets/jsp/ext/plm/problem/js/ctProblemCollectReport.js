Ext.define('PLM.view.problemMgt', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.problemMgt',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'problemMgt',
    initComponent: function () {
        var me = this;

        Ext.define('ctProblemVerifyModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'problemTerritory', 'undertaker', 'optimizeStrategy', 'planFinishDate', 'optimizeResult',
                'verifyReportLink', 'verifyReportNumber', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'isAssign'],
            idProperty: 'id'
        });

        var problemVerifyStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemVerifyModel',
            id: 'problemVerifyStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1//problemMgt/getProblemVerifyInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        //问题数据模型
        Ext.define('ctProblemMgtModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'containerId', 'docBranchId', 'problemNumber', 'description', 'creator', 'problemTerritory', 'problemGrade',
                'optimizeStrategy', 'charger', 'planFinishDate', 'startDate', 'processLink', 'projectPhase', 'analysis', 'imgs','problemSourceTerritory',
                'badProportion', 'problemSource', 'oaNumber', 'riskNumber', 'relatedProblemNumber', 'optimizeResult',
                'verifyReportOrNot', 'verifyReportLink', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'problemStatus',
                'confirmExplain', 'creatorDate', 'isShare', "temporaryMeasures", "endPartNumber", "productNumber", 'shareLink', 'replenish',
                'softwareCharger', 'hardwareCharger', 'craftCharger', "fabricCharger", "testCharger", "qualityCharger", 'purchaseCharger', 'makeCharger',
                'bazaarCharger', 'elseCharger', 'pqaCheck', 'problemInput', 'affirmCheck'],
            idProperty: 'id'
        });

        //初始化加载数据
        var problemMgtStore = Ext.create('Ext.data.Store', {
            pageSize: 50,
            model: 'ctProblemMgtModel',
            id: 'problemMgtStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({

                url: '/Windchill/ptc1/problemMgt/getItems',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        problemMgtStore.on('beforeload', function (store, options) {
            var data = getSearchData();
            Ext.apply(problemMgtStore.proxy.extraParams, data);
        });



        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ProblemVerifyGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('problemVerifyStore'),
            id: 'ProblemVerifyGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 400,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {
                    text: '子问题处理',
                    columns: [
                        {
                            text: '领域',
                            dataIndex: 'problemTerritory',
                            width: 60,
                            menuDisabled: true,
                        },
                        {text: '子问题承担者', dataIndex: 'undertaker', width: 100, menuDisabled: true,},
                        {
                            text: '初步对策',
                            dataIndex: 'optimizeStrategy',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '计划解决时间',
                            dataIndex: 'planFinishDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '改善结论',
                            dataIndex: 'optimizeResult',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '验证报告编号',
                            dataIndex: 'verifyReportNumber',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '检验报告链接',
                            dataIndex: 'verifyReportLink',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '实际解决时间',
                            dataIndex: 'realitySolveDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '不整改原因',
                            dataIndex: 'noChangeCause',
                            width: 100,
                            menuDisabled: true,
                        },
                    ],
                },
                {
                    text: '子问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'verifyExplain', width: 100, menuDisabled: true,},
                    ]
                },
                {text: '是否分配人', dataIndex: 'isAssign', width: 100, menuDisabled: true},

            ],
        });


        var followUp = Ext.create('Ext.Window', {
            id: 'followUp',
            title: '子问题跟进',
            width: 1250,
            height: 400,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [ProblemVerifyGrid],
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var ProblemMgtGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemMgtStore'),
            id: 'ProblemMgtGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            // height: 600,
            maxHeight: 420, // 设置最大高度为 800 像素
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            tbar: [
                {
                    text: '问题跟进信息',
                    scope: this,
                    handler: function () {
                        var newDocItems = new Array();
                        var removedRecords = ProblemMgtGrid.getSelectionModel().getSelection();

                        if (removedRecords == undefined || removedRecords == null || removedRecords.length == 0) {
                            alert("请选择对应的问题！");
                            return;
                        } else if (removedRecords.length > 1) {
                            alert("一次只能选择一个问题！");
                            return;
                        } else if (removedRecords[0].get('problemStatus') == '已开启') {
                            alert("问题未启动，请先启动问题！");
                            return;
                        }
                        followUp.show();
                        if (removedRecords[0].get("oaNumber") != undefined) {
                            getProblemVerifyInfo(removedRecords[0].get("problemNumber"));
                        } else {
                            getProblemVerifyInfo(removedRecords[0].get("docBranchId"));
                        }
                    }
                }, {

                    text: '导出当前问题报表',
                    iconCls: 'icon icon-download',
                    handler: function () {
                        this.doExportGridData();
                    },
                    scope: this
                },{

                    text: '启动经验知识库流程',
                    id: 'setShare',
                    handler: function () {
                        var isShareItems = new Array();
                        //这一句是获取选中的集合
                        var setShareRecords = ProblemMgtGrid.getSelectionModel().getSelection();
                        if (setShareRecords == undefined || setShareRecords == null || setShareRecords.length == 0) {
                            alert("请选择对应要修改状态的问题！");
                            return
                        }

                        var is = 0;
                        //判断页面元内容再赋值
                        Ext.each(setShareRecords, function (record) {
                            if (record.data['isShare'] == 1) {
                                alert("所选问题已经是共享问题！")
                                is = 1;
                            }
                            if (record.data['problemStatus'] != '已解决') {
                                alert("只有已解决的问题才能进行共享！")
                                is = 1;
                            }
                            var isShare = '1';
                            var urlIsShare = record.data['id'];
                            isShareItems.push(urlIsShare);
                        });
                        if (is == 0) {
                            setShare(isShareItems, problemMgtStore);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    hidden: true,
                    id: 'saveStatus',
                    name: 'saveStatus'
                }
            ],
            columns: [{xtype: 'rownumberer', width: 40},
                {
                    text: '问题提出',
                    columns: [
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'containerId', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'problemInput', menuDisabled: true, hidden: true},
                        {text: '所属产品库', dataIndex: 'productName', width: 120,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {text: '产品线', dataIndex: 'productLine', width: 120,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {text: '项目名称', dataIndex: 'projectName', width: 120,},
                        {text: '项目编号', dataIndex: 'projectNumber', width: 120,},
                        {text: '问题编号', dataIndex: 'problemNumber', width: 120,},
                        {text: '问题提出者', dataIndex: 'creator', width: 100, editor: false},
                        {
                            text: '问题领域', dataIndex: 'problemTerritory', width: 100, editor: false,
                            renderer: function (value, metaData, record, row, col, store) {
                                var temp = new Array();
                                if (value == '' || value == undefined || value == null) {
                                    return '';
                                }
                                if (!Array.isArray(value)) {
                                    value += ",";
                                    var start = 0;
                                    var pos = value.indexOf(',');
                                    while (pos > -1) {
                                        temp.push(value.substr(start, pos - start));
                                        start = pos + 1;
                                        pos = value.indexOf(',', pos + 1);
                                    }
                                    record.set("problemTerritory", temp);
                                    record.commit();
                                } else {
                                    temp = value;
                                }
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + temp + "'";
                                return temp;
                            }
                        },
                        {text: '问题级别', dataIndex: 'problemGrade', width: 100, editor: false},
                        {text: '问题来源（评审）', dataIndex: 'problemSourceTerritory', width: 100, editor: false},
                        {
                            text: '问题描述',
                            dataIndex: 'description',
                            width: 100,
                            editor: false,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value.toString().replace(/,/g,'</br>') + "'";
                                return value;
                            }
                        },
                        {
                            text: '初步原因分析',
                            dataIndex: 'analysis',
                            width: 100,
                            editor: false,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '初步对策', dataIndex: 'optimizeStrategy', width: 100, editor: false,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '临时措施',
                            dataIndex: 'temporaryMeasures',
                            width: 100,
                            editor: false,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        //{text: '问题承担者', dataIndex: 'charger', width: 100, editor: allUserCombo_projectPlan},
                        {
                            text: '计划完成时间',
                            dataIndex: 'planFinishDate',
                            width: 120,
                            editor: false,
                            menuDisabled: true,
                            align: 'center',
                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                            }
                        },
                        {text: '发起日期', dataIndex: 'startDate', width: 100,},
                        {text: '流程链接', dataIndex: 'processLink', width: 100, editor: false},
                        {text: '项目阶段', dataIndex: 'projectPhase', width: 100, editor: false},
                        {text: 'PQA', dataIndex: 'pqaCheck', width: 100, editor: false},
                        {text: '开发代表', dataIndex: 'affirmCheck', width: 100, editor: false},
                        {
                            text: '图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: [ '->', {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    problemId = problemNumber;
                                    var container = record.get('containerId');
                                    problemStatus = record.get('problemStatus');
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + container + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {
                            text: '不良比例（%）',
                            dataIndex: 'badProportion',
                            width: 120,
                            editor: false,
                            menuDisabled: true,
                            minValue: 0
                        },
                        {text: '问题来源（领域）', dataIndex: 'problemSource', width: 100, editor: false},
                        {text: '成品代码', dataIndex: 'endPartNumber', width: 100, editor: false},
                        {text: '产品型号', dataIndex: 'productNumber', width: 100, editor: false},
                        {text: 'OA编号', dataIndex: 'oaNumber', width: 100,},
                        {text: '风险编号', dataIndex: 'riskNumber', width: 100, editor: false},
                        {text: '相关问题编号', dataIndex: 'relatedProblemNumber', width: 100, editor: false},
                        {text: '软件领域问题承担者', dataIndex: 'softwareCharger', width: 140, editor: false},
                        {text: '硬件领域问题承担者', dataIndex: 'hardwareCharger', width: 140, editor: false},
                        {text: '工艺领域问题承担者', dataIndex: 'craftCharger', width: 140, editor: false},
                        {text: '结构领域问题承担者', dataIndex: 'fabricCharger', width: 140, editor: false},
                        {text: '测试领域问题承担者', dataIndex: 'testCharger', width: 140, editor: false},
                        {text: '质量领域问题承担者', dataIndex: 'qualityCharger', width: 140, editor: false},
                        {text: '采购领域问题承担者', dataIndex: 'purchaseCharger', width: 140, editor: false},
                        {text: '制造领域问题承担者', dataIndex: 'makeCharger', width: 140, editor: false},
                        {text: '市场领域问题承担者', dataIndex: 'bazaarCharger', width: 140, editor: false},
                        {text: '其他领域问题承担者', dataIndex: 'elseCharger', width: 140, editor: false},
                    ]
                },
                 {
                    text: '问题结论',
                    columns: [
                        {text: '问题状态', dataIndex: 'problemStatus', width: 100,},
                        {
                            text: '确认说明',
                            dataIndex: 'confirmExplain',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                    ]
                }, {
                    text: '知识库共享',
                    columns: [{
                        text: '共享', width: 100, dataIndex: 'isShare', menuDisabled: true, value: '已共享',
                        renderer: function (value) {
                            if (value == "1") {
                                value = '已共享'
                            } else {
                                value = "未共享"
                            }
                            return value;
                        }
                    },
                        {
                            text: '补充信息',
                            dataIndex: 'replenish',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '补充信息图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: ['->', {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    problemId = problemNumber + '经验知识库';
                                    problemStatus = record.get('problemStatus');
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + containerId + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {text: '共享文档链接', dataIndex: 'shareLink', width: 100,}
                    ]
                },
            ],
            bbar: Ext.create('Ext.PagingToolbar', {
                store: problemMgtStore,
                style: {
                    float: 'right'
                },
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空"
            }),
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.record;

                    if (tField.get('problemStatus') != '已开启') {
                        return false;
                    }

                },
            }
        });

        ProblemMgtGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                if (tValue != null) {
                    if (tValue.toString().length > 1200) {
                        alert("内容信息长度不能大于1200！！！");
                    }
                }

                if (tField == 'badProportion') {
                    if (tValue != '') {
                        if (tValue < 0 || tValue > 100) {
                            alert('不良比例不能低于1或高于100！')
                            return;
                        }
                    }
                }
                if (tField == 'riskNumber') {
                    if (tValue != '') {
                        var isCorrect = checkRiskNumber(tValue);
                        if (!isCorrect) {
                            return;
                        }
                    }
                }
                if (tField == 'relatedProblemNumber') {
                    if (tValue != '') {
                        var isCorrect = checkProblemNumber(tValue);
                        if (!isCorrect) {
                            return;
                        }
                    }
                }
                if(tField == "endPartNumber"){
                    Ext.getStore('problemMgtStore').reload();
                }

                var callbackFn = function () {
                    tRecord.commit();
                };
                updateProblem(tField, tValue, itemId, tRecord, callbackFn);
            });

        var problemSourceTerritoryCombo = new Ext.form.ComboBox({
            name: 'problemSourceTerritoryCombo',
            id: 'problemSourceTerritoryCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//非评审- 原理图及PCB评审- 结构评审- 软件评审- 总体方案评审- 需求规格评审- TR评审
            store: [['非评审', '非评审'], ['原理图及PCB评审', '原理图及PCB评审'], ['结构评审', '结构评审'],['软件评审', '软件评审']
                ,['总体方案评审', '总体方案评审'],['需求规格评审', '需求规格评审'],['TR评审', 'TR评审']]
        });

        Ext.define('productLineModel', {
            extend: 'Ext.data.Model',
            fields: [
                'fullName', 'name'
            ],
            idProperty: 'projectNumber'
        });
        // 产品线下拉
        var productLineStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'productLineModel',
            id: 'productLineStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/problemMgt/getProductNameOrProductLine?type=productLine',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: true
        });

        Ext.define('productNameModel', {
            extend: 'Ext.data.Model',
            fields: [
                'fullName', 'name'
            ],
            idProperty: 'projectNumber'
        });
        // 产品线下拉
        var productNameStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'productNameModel',
            id: 'productNameStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/problemMgt/getProductNameOrProductLine?type=productName',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: true
        });

        var problemForm = {
            title: '问题报表',
            xtype: 'form',
            id: 'mainForm',
            autoWidth: true,
            // width: '100%',
            // height: 800,
            // autoHeight:true,
            maxHeight: 800, // 设置最大高度为 800 像素
            hideLabel: true,
            border: 0,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                // margin: '15 50 10 50',
                defaults:{ margin:'10 50 10 10',labelWidth:60},
                items: [{
                    fieldLabel: '问题编号',
                    // labelWidth: 70,
                    name: 'cProblemNumber',
                    id: 'cProblemNumber',
                    allowBlank: false,
                    width: 200,
                }, {
                    fieldLabel: '问题状态',
                    // labelWidth: 70,
                    name: 'cStatus',
                    id: 'cStatus',
                    width: 200,
                },
                    {
                        xtype: 'combobox',
                        fieldLabel: '问题来源',
                        id: 'problemSourceTerritory',
                        name: 'problemSourceTerritory',
                        width: 245,
                        store: [['非评审', '非评审'], ['原理图及PCB评审', '原理图及PCB评审'], ['结构评审', '结构评审'],['软件评审', '软件评审']
                            ,['总体方案评审', '总体方案评审'],['需求规格评审', '需求规格评审'],['TR评审', 'TR评审']],
                        queryMode: 'local',
                        displayField: 'text',
                        valueField: 'value',
                        allowBlank: false,
                    },
                    {
                        fieldLabel: '问题描述',
                        // labelWidth: 70,
                        // margin: '10 0 0 55',
                        id: 'cDescription',
                        name: 'cDescription',
                        allowBlank: false,
                        width: 400,
                    }
                ]
            }, {
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                // margin: '0 0 0 10',
                defaults:{ margin:'10 50 10 10',labelWidth:60},
                items: [
                    {
                        fieldLabel: '提交人',
                        // labelWidth: 70,
                        id: 'cCreatorVerify',
                        name: 'cCreatorVerify',
                        width: 200,
                    }
                    , {
                        fieldLabel: '责任人',
                        // labelWidth: 70,
                        id: 'cCharger',
                        name: 'cCharger',
                        width: 200,
                    },{
                        xtype: 'datefield',
                        name: 'startQueryDate',
                        id: 'startQueryDate',
                        fieldLabel: '发起时间从',
                        format: 'Y-m-d',
                        labelWidth: 70,
                        // margin: '10 5 0 0',
                        allowBlank: false
                    },
                    {
                        xtype: 'datefield',
                        name: 'endQueryDate',
                        id: 'endQueryDate',
                        format: 'Y-m-d',
                        labelWidth: 10,
                        // margin: '10 45 0 0',
                        fieldLabel: '到',
                        allowBlank: false
                    },
                ]
            }
                , {
                    xtype: 'container',
                    layout: 'hbox',
                    defaultType: 'textfield',
                    // margin: '0 0 0 10',
                    defaults:{ margin:'10 50 10 10',labelWidth:60},
                    items: [
                        {
                            fieldLabel: '项目编号',
                            id: 'projectNumber',
                            name: 'projectNumber',
                            allowBlank: false,
                            width: 200,
                        },
                        {
                            xtype: 'combo',
                            fieldLabel: '所属产品库',
                            multiSelect: false,
                            valueField: 'fullName',
                            displayField: 'name',
                            store: productNameStore,
                            anyMatch: true,
                            typeAhead: true,       // 开启输入时自动补全
                            queryMode: 'local',    // 本地查询模式
                            editable: true,
                            width: 400,
                            id: 'productName',
                            name: 'productName',
                            labelWidth: 70,
                        },
                        // , {
                        //     fieldLabel: '所属产品库',
                        //     labelWidth: 70,
                        //     // margin:'10 0 0 0',
                        //     id: 'productName',
                        //     name: 'productName',
                        //     width: 200,
                        // },

                        {
                            xtype: 'combo',
                            fieldLabel: '产品线',
                            multiSelect: false,
                            valueField: 'fullName',
                            displayField: 'name',
                            store: productLineStore,
                            anyMatch: true,
                            typeAhead: true,       // 开启输入时自动补全
                            queryMode: 'local',    // 本地查询模式
                            editable: true,
                            width: 400,
                            id: 'productLine',
                            name: 'productLine',
                            labelWidth: 70,
                        },

                        // {
                        //     xtype: 'combobox',
                        //     fieldLabel: '产品线',
                        //     id: 'productLine',
                        //     name: 'productLine',
                        //     width: 400,
                        //         store: [['01-火灾报警系统产品', '01-火灾报警系统产品'], ['02-电气火灾监控&消防设备电源监控系统产品', '02-电气火灾监控&消防设备电源监控系统产品'],
                        //             ['03-防火门监控系统产品', '03-防火门监控系统产品'],['04-消防应急照明和疏散指示系统产品', '04-消防应急照明和疏散指示系统产品']
                        //             ,['05-物联网家用报警系统产品', '05-物联网家用报警系统产品'],['06-海外火灾报警系统产品', '06-海外火灾报警系统产品']
                        //             ,['09-城市更新SDT产品', '09-城市更新SDT产品'],['09-其他', '09-其他']
                        //         ],
                        //     queryMode: 'local',
                        //     displayField: 'text',
                        //     valueField: 'value',
                        //     allowBlank: false,
                        // },
                        // {
                        //     fieldLabel: '产品线',
                        //     // labelWidth: 10,
                        //     id: 'productLine',
                        //     name: 'productLine',
                        //     store: [['01-火灾报警系统产品', '01-火灾报警系统产品'], ['02-电气火灾监控&消防设备电源监控系统产品', '02-电气火灾监控&消防设备电源监控系统产品'],
                        //         ['03-防火门监控系统产品', '03-防火门监控系统产品'],['04-消防应急照明和疏散指示系统产品', '04-消防应急照明和疏散指示系统产品']
                        //         ,['05-物联网家用报警系统产品', '05-物联网家用报警系统产品'],['06-海外火灾报警系统产品', '06-海外火灾报警系统产品']
                        //         ,['09-城市更新SDT产品', '09-城市更新SDT产品'],['09-其他', '09-其他']
                        //     ],
                        //     width: 200,
                        // }
                    ]
                }


            , {
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'button',
                margin: '10 0 0 10',
                items: [{
                    text: '查询',
                    name: 'phone',
                    width: 50,
                    handler: function () {
                        doSearch()
                    }
                }]
            }, ProblemMgtGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [problemForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            doSearch();
        }
    },

    doExportGridData: function () {
        var data = getSearchData();
        window.location.href = '/Windchill/ptc1/problemMgt/exportProblems?data=' + Ext.encode(data);
    }

});

//创建问题解决文档
function createProblemSolve(newDocItems) {

    Ext.Msg.confirm('提示', '确定要为选中的问题启动流程吗？',
        function (btn) {
            if (btn == 'yes') {
                Ext.Ajax.request({
                    scope: this,
                    url: '/Windchill/ptc1/problemMgt/createProblemSolve',
                    params: {
                        data: Ext.encode(newDocItems),
                        containerId: Ext.encode(containerId),
                    },
                    success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if (!obj['success']) {
                            alert(obj['msg']);
                        } else {
                            Ext.getStore('problemMgtStore').reload();
                            alert("启动成功！");
                        }

                    },
                    failure: function (response, opts) {
                        alert('错误：创建问题解决文档失败，请检查网络！');
                    }

                });
            } else {
                return;
            }
        }, this);
}

//获取查询条件参数
function getSearchData() {
    var isShare = null;
    if (share == "1") {
        isShare = "1";
    }

    var data = {
        containerId: '',
        isShare: isShare,
        problemStatus: Ext.getCmp('cStatus').getValue(),
        problemNumber: Ext.getCmp('cProblemNumber').getValue(),
        description: Ext.getCmp('cDescription').getValue(),
        creator: Ext.getCmp('cCreatorVerify').getValue(),
        charger: Ext.getCmp('cCharger').getValue(),

        startQueryDate:Ext.getCmp('startQueryDate').getValue(),
        endQueryDate:Ext.getCmp('endQueryDate').getValue(),
        productName:Ext.getCmp('productName').getValue(),
        projectNumber:Ext.getCmp('projectNumber').getValue(),
        problemSourceTerritory:Ext.getCmp('problemSourceTerritory').getValue(),
        productLine:Ext.getCmp('productLine').getValue(),
    };

    return data;
}

/**
 * 按查询参数查询
 */
function doSearch() {
    var data = getSearchData();
    Ext.getStore('problemMgtStore').load({
        params: {
            data: data
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询问题信息失败，请联系管理员！');
            }
        }
    });
}



/**
 * 获取产品型号
 * @param value
 * @returns {string}
 */
function getProductNumber(value) {
    var number = ''
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/getProduct',
        method: "POST",
        params: {
            partNumber: value
        },
        async: false,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                number = obj['product'];
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：获取失败，请检查网络！');
        }
    });
    return number;
}

//设置共享
function setShare(data, problemStore) {

    Ext.Msg.confirm('提示', '确定要改变共享状态？',
        function (btn) {
            if (btn == 'yes') {
                Ext.Ajax.request({
                    scope: this,
                    url: '/Windchill/ptc1/problemMgt/setShare',
                    method: "POST",
                    params: {
                        data: Ext.encode(data),
                        containerId: containerId
                    },
                    success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if (obj['success']) {
                            doSearch();
                        } else {
                            alert(obj['msg']);
                            Ext.getStore('problemStore').reload();
                        }
                    },
                    failure: function (response, opts) {
                        alert('错误：共享问题失败，请检查网络！');
                    }
                });
            } else {
                return;
            }
        }, this);


}



//获取问题跟进信息
function getProblemVerifyInfo(branchId) {
    Ext.getStore('problemVerifyStore').load({
        params: {
            docBranchId: branchId,
        },
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    // alert('查询超时！请重试！')
                }
            }
        }
    });
}