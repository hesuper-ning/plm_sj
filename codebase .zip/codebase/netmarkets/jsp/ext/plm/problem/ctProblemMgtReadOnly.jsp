<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>oid="+oid);

        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WTDocument document = (WTDocument) CtWTObjectUtil.getObjectByOid(oid);
        String docBranchId = document.getBranchIdentifier()+"";
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css" href="css/ablum.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctProblemMgtFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctProblemProcess.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/uploadImagePanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/showImageView.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
    var containerId = "<%=oid%>";
    var docBranchId = "<%=docBranchId%>";
    var allowEdit = false;
    //用于判断图片是否可以删除
    var problemStatus = '';
    var actKey = '';
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ProblemProcess'
            }]
        });
    });
</script>
</body>
</html>