<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.services.ServiceFactory" %>
<%@ page import="java.io.BufferedReader" %>
<%@ page import="java.io.FileReader" %>
<%@ page import="wt.query.QuerySpec" %>
<%@ page import="wt.inf.container.WTContainer" %>
<%@ page import="wt.query.SearchCondition" %>
<%@ page import="wt.project.Role" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page import="wt.org.WTUser" %>
<%@ page import="cn.hutool.core.util.ObjectUtil" %>
<%@ page import="wt.inf.team.ContainerTeam" %>
<%@ page import="wt.pdmlink.PDMLinkProduct" %>
<%@ page import="wt.org.WTPrincipalReference" %>
<%@ page import="java.util.*" %>
<%@ page import="wt.org.WTPrincipal" %>
<%@ page import="wt.inf.team.ContainerTeamHelper" %>
<%@ page import="wt.fc.*" %>
<%@ page import="wt.inf.team.ContainerTeamManaged" %>
<%@ page import="ext.plm.common.CtConstant" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>刷新产品角色用户</title>
</head>
<body>
<div class="container">
<%
    String userName = "tian.lv";
    WTUser wtuUser = CtUserUtil.getUserByAccountName(userName);
    List<WTPrincipal> users = Arrays.asList(wtuUser);

    List<String> projectNameList = Arrays.asList("J-SAP-M-A62S手动火灾报警按钮30184800", "JT-BM-928T家用可燃气体探测器30187100");
    WTContainer projectTemp = null;
    List<WTContainer> projects = new ArrayList<>();
    for (String projectName : projectNameList) {
        QuerySpec qs = new QuerySpec(WTContainer.class);
        SearchCondition sc = new SearchCondition(WTContainer.class, WTContainer.NAME, "=", projectName);
        qs.appendWhere(sc);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        while (qr.hasMoreElements()) {
            WTContainer container = (WTContainer) qr.nextElement();
            projectTemp =  container;
            if (ObjectUtil.isNotEmpty(projectTemp)) {
                projects.add(projectTemp);
            }
        }
    }
    String roleDisplayName = "A008开发代表";
    String roleInnerName = "DevelopmentRepresentative";

    System.out.println("lvtian测试代码");
    for (WTContainer container : projects) {
        System.out.println("projectName=:"+container.getName());
        PDMLinkProduct pdmLinkProduct = (PDMLinkProduct) container;
        ContainerTeam containerTeam = (ContainerTeam)pdmLinkProduct.getContainerTeamReference().getObject();
        if (containerTeam == null) {
            return;
        }
        // 获取上下文团队指定角色用户集合采用递归读取 containerTeam.getPrincipalTarget()

        containerTeam = (ContainerTeam) PersistenceHelper.manager.refresh(containerTeam);
        containerTeam = (ContainerTeam) PersistenceHelper.manager.save(containerTeam);
//        containerTeam.addPrincipals(Role.toRole(roleInnerName), users);
        HashMap removeMap = new HashMap();
        removeMap.put(Role.toRole(roleInnerName), users);
        containerTeam.removeMembersFromRoles(removeMap);
        PersistenceServerHelper.manager.update(container);
//        System.out.println("添加完成："+container.getName());
        System.out.println("删除完成："+container.getName());
    }

%>
</div>
</body>
</html>
