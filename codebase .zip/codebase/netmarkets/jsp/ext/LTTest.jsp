<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.services.ServiceFactory" %>
<%@ page import="wt.query.QuerySpec" %>
<%@ page import="wt.inf.container.WTContainer" %>
<%@ page import="wt.query.SearchCondition" %>
<%@ page import="wt.project.Role" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page import="wt.org.WTUser" %>
<%@ page import="cn.hutool.core.util.ObjectUtil" %>
<%@ page import="wt.inf.team.ContainerTeam" %>
<%@ page import="wt.pdmlink.PDMLinkProduct" %>
<%@ page import="wt.org.WTPrincipalReference" %>
<%@ page import="java.util.*" %>
<%@ page import="wt.org.WTPrincipal" %>
<%@ page import="wt.inf.team.ContainerTeamHelper" %>
<%@ page import="wt.fc.*" %>
<%@ page import="wt.inf.team.ContainerTeamManaged" %>
<%@ page import="ext.plm.common.CtConstant" %>
<%@ page import="wt.content.ApplicationData" %>
<%@ page import="wt.content.ContentHelper" %>
<%@ page import="wt.content.ContentRoleType" %>
<%@ page import="ext.plm.adTool.CtAdToolLogic" %>
<%@ page import="wt.content.ContentServerHelper" %>
<%@ page import="java.io.*" %>
<%@ page import="ext.plm.sjworkflow.SjStandardWorkflowMethod" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>lvtian测试用jsp</title>
    <style>
        .log-box {
            font-family: Consolas, monospace;
            background-color: #f4f4f4;
            padding: 30px;
            border-radius: 10px;
            line-height: 1.6;
        }
    </style>
</head>
<body>
<div class="container">
    <%
        System.out.println("下载文档主要内容和附件测试");
        String wtdocOR = "VR:wt.doc.WTDocument:168172825";
        ReferenceFactory rf = new ReferenceFactory();
        WTDocument wtdoc = (WTDocument) rf.getReference(wtdocOR).getObject();
        SjStandardWorkflowMethod.sjWTDocPrimaryToNetFolder(wtdoc);


//        List<ApplicationData> primaryDate = new ArrayList<>();
//        List<ApplicationData> secondaryDate = new ArrayList<>();
//
//        // 1. 获取主要内容
//        QueryResult priqueryResult = ContentHelper.service.getContentsByRole(wtdoc, ContentRoleType.PRIMARY);
//        if (priqueryResult != null && priqueryResult.hasMoreElements()) {
//            while (priqueryResult.hasMoreElements()) {
//                Object object = priqueryResult.nextElement();
//                if (object instanceof ApplicationData) {
//                    primaryDate.add((ApplicationData) object);
//                }
//            }
//        } else {
//            out.println("文档没有主要内容<br>");
//        }
//
//        // 2. 获取附件内容
//        QueryResult secqueryResult = ContentHelper.service.getContentsByRole(wtdoc, ContentRoleType.SECONDARY);
//        if (secqueryResult != null && secqueryResult.hasMoreElements()) {
//            while (secqueryResult.hasMoreElements()) {
//                Object object = secqueryResult.nextElement();
//                if (object instanceof ApplicationData) {
//                    secondaryDate.add((ApplicationData) object);
//                }
//            }
//        } else {
//            out.println("文档没有附件<br>");
//        }
//
//        // 3. 定义本地保存目录
//        String localSaveDir = "/home/";
//
//        out.println("文档编号：" + wtdoc.getNumber() + "<br>");
//        out.println("主要内容信息：" + wtdoc.getNumber() + "<br>");
//
//        // 4. 下载主要内容到本地服务器
//        for (ApplicationData app : primaryDate) {
//            InputStream inputStream = null;
//            OutputStream outputStream = null;
//            try {
//                // 获取 Windchill 文件流
//                inputStream = ContentServerHelper.service.findContentStream(app);
//
//                // 构建本地保存路径：localSaveDir路径 + 原文件名
//                File localFile = new File(localSaveDir, app.getFileName());
//                outputStream = new FileOutputStream(localFile);
//
//                // 核心替换：使用标准 Java IO 流将文件写入本地磁盘
//                byte[] buffer = new byte[4096];
//                int bytesRead;
//                while ((bytesRead = inputStream.read(buffer)) != -1) {
//                    outputStream.write(buffer, 0, bytesRead);
//                }
//                outputStream.flush();
//
//                out.println("主要内容下载完成: " + app.getFileName() + "<br>");
//            } catch (Exception e) {
//                out.println("主要内容下载失败: " + e.getMessage() + "<br>");
//            } finally {
//                // 5. 核心修复：必须在 finally 中关闭流，防止 Windchill 内存/文件句柄泄漏
//                if (inputStream != null) {
//                    try { inputStream.close(); } catch (Exception ignored) {}
//                }
//                if (outputStream != null) {
//                    try { outputStream.close(); } catch (Exception ignored) {}
//                }
//            }
//        }
//
//        out.println("附件信息：" + wtdoc.getNumber() + "<br>");
//        out.println("----------------<br>");
//
//        // 6. 下载附件到本地服务器
//        for (ApplicationData app : secondaryDate) {
//            InputStream inputStream = null;
//            OutputStream outputStream = null;
//            try {
//                inputStream = ContentServerHelper.service.findContentStream(app);
//
//                File localFile = new File(localSaveDir, app.getFileName());
//                outputStream = new FileOutputStream(localFile);
//
//                byte[] buffer = new byte[4096];
//                int bytesRead;
//                while ((bytesRead = inputStream.read(buffer)) != -1) {
//                    outputStream.write(buffer, 0, bytesRead);
//                }
//                outputStream.flush();
//
//                out.println("附件下载完成: " + app.getFileName() + "<br>");
//            } catch (Exception e) {
//                out.println("附件下载失败: " + e.getMessage() + "<br>");
//            } finally {
//                if (inputStream != null) {
//                    try { inputStream.close(); } catch (Exception ignored) {}
//                }
//                if (outputStream != null) {
//                    try { outputStream.close(); } catch (Exception ignored) {}
//                }
//            }
//        }
    %>
</div>
</body>
</html>