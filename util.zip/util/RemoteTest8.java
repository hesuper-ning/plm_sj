package ext.ait.util;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ext.ait.util.CommonUtil;
import ext.ait.util.PartUtil;
import ext.ait.util.PersistenceUtil;
import ext.ait.util.VersionUtil;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.LineNumber;
import wt.part.Quantity;
import wt.part.QuantityUnit;
import wt.part.SubstituteQuantity;
import wt.part.SubstitutesReplacementType;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.pom.PersistenceException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.VersionControlHelper;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * 
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * 
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * 
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * 
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 * 
 * @author dz
 *
 */
public class RemoteTest8 implements RemoteAccess, Serializable {

	private static final long serialVersionUID = 1L;

	public static void main(String[] args) throws Exception {
		System.out.println("=======5");
		invoke("ImportData", RemoteTest8.class.getName(), null, new Class[] {}, new Object[] {});

	}
	
	public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("plm");
		rms.setPassword("222");
		try {
			return rms.invoke(methodName, className, instance, cla, obj);
		} catch (RemoteException e) {
			e.printStackTrace();
			return null;
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static WTPartUsageLink createWtpartToLink(WTPart parent, WTPart son, Long number, Double amount, String unit)
			throws Exception {
		System.out.println("======创建子件======" + "父：" + parent.getNumber() + " 子:" + son.getNumber());
		try {
			// parent = PartUtil.getWTPartByNumber(parent.getNumber());
			// parent = (WTPart) VersionUtil.getLastBigOne(parent);

			// parent = checkGc(parent.getNumber(), parent.getViewName());
			parent = PartUtil.getWTPartByNumberAndView(parent.getNumber(), parent.getViewName());

			WTPartUsageLink link = new WTPartUsageLink();

			if (number != null) {
				LineNumber lineNumber = new LineNumber();
				lineNumber.setValue(number);
				link.setLineNumber(lineNumber);
			}
			Quantity quantity = new Quantity();
			if (amount != null) {
				quantity.setAmount(amount);
			}
			if (StringUtils.isNotBlank(unit)) {
				QuantityUnit quantityUnit = QuantityUnit.toQuantityUnit(unit);
				quantity.setUnit(quantityUnit);
			}

			link.setQuantity(quantity);
			if (!PersistenceUtil.isCheckOut(parent)) {
				parent = (WTPart) PersistenceUtil.checkoutObj(parent);
			}
			link.setUsedBy(parent);
			link.setUses(son.getMaster());
			link = (WTPartUsageLink) wt.fc.PersistenceHelper.manager.save(link);
			return link;
		} catch (Exception e) {
			throw e;
		}
	}

	public static void ImportData() throws PersistenceException {
		File file = new File("/data/log/warningPart.txt");
		if (file.exists()) {
			file.delete();
		}
		// 查询数据库内容
		List<Map<String, String>> resultList = excuteSql();
		// Transaction t = new Transaction();
		try {
			// t.start();
			if (resultList == null || resultList.isEmpty()) {
				System.out.println("数据库数据为空");
				return;
			}
			// 根据父编号分组
			Map<String, List<Map<String, String>>> dataMap = resultList.stream()
					.collect(Collectors.groupingBy(obj -> obj.get("WLH") + "|" + obj.get("GC")));
			for (String key : dataMap.keySet()) {
				String[] keys = key.split("\\|");
				// 获取该附件下的子件列表
				List<Map<String, String>> sonList = dataMap.get(key);

				// 如果找不到父件就跳过处理逻辑
				WTPart part = checkGc(keys[0], keys[1]);
				if (part == null || sonList == null || sonList.isEmpty()) {
					appendLog("（父）系统中没有此组件:" + key);
					System.out.println("系统中无此编号||视图中无此编号:" + key);
				} else {
					System.out.println("是否检出：" + PersistenceUtil.isCheckOut(part));
					// 查询该组件下的子件
					List<Map<String, String>> sonList100 = sonList.stream().filter(obj -> "100".equals(obj.get("KNX")))
							.collect(Collectors.toList());
					if (sonList100 == null || sonList100.isEmpty()) {
						System.out.println("此父件下面无编号" + key);
					} else {
						System.out.println("开始创建需要替代的子件======" + keys[0] + " size:" + sonList100.size());
						for (int i = 0; i < sonList100.size(); i++) {
							Map<String, String> obj = sonList100.get(i);
							// 判断子件是否存在
							WTPart bomZj = checkGc(obj.get("BOMZJ"), keys[1]);
							if (bomZj == null) {
								appendLog("（父）:" + key + " （子）:" + obj.get("BOMZJ"));
								System.out.println("子件不存在，不做处理");
							} else {
								System.out.println("100的子件：" + bomZj.getNumber());
								// 查询是否存在关联关系
								WTPartUsageLink uLink = PartUtil.getLinkByPart(part, bomZj);
								System.out.println("是否有连接：" + (uLink == null));

								Double yl = StringUtils.isBlank(obj.get("YL")) ? null
										: Double.parseDouble(obj.get("YL"));
								Long hhLong = StringUtils.isBlank(obj.get("BOMXM")) ? null
										: Long.parseLong(obj.get("BOMXM"));
								String unit = obj.get("DW");
								if (uLink == null) {
									uLink = createWtpartToLink(part, bomZj, hhLong, yl, unit);
								} else {
									UpdateLink(part, uLink, hhLong, yl, unit);
								}

								// 查询是否有替代项
								List<Map<String, String>> tdxList = sonList.stream()
										.filter(tdx -> StringUtils.equals(tdx.get("DTX"), obj.get("DTX"))
												&& "0".equals(tdx.get("KNX")))
										.collect(Collectors.toList());
								System.out.println("是否有代替项：" + tdxList.size());

								if (tdxList != null && !tdxList.isEmpty()) {
									for (int j = 0; j < tdxList.size(); j++) {
										Map<String, String> objDtx = tdxList.get(j);
										WTPart bomZj1 = checkGc(objDtx.get("BOMZJ"), keys[1]);
										if (bomZj1 != null) {
											List<WTPartSubstituteLink> dtLink = PartUtil
													.getWTPartSubstituteLinks(uLink);
											System.out.println("是否有替换连接：" + dtLink.isEmpty());

											Double ylTd = StringUtils.isBlank(objDtx.get("YL")) ? null
													: Double.parseDouble(objDtx.get("YL"));
											String hhLongTd = objDtx.get("BOMXM");
											String unitTd = objDtx.get("DW");
											if (dtLink == null || dtLink.isEmpty()) {
												System.out.println("============f:" + keys[0]);
												System.out.println("=============s:" + objDtx.get("BOMZJ"));
												createWTPartAlternateLink(uLink, bomZj1, ylTd, unitTd, hhLongTd);
											} else {
												// 判断替换件是否有当前物料
												List<WTPartSubstituteLink> count = dtLink.stream().filter(objLink -> {
													WTPartMaster master = (WTPartMaster) objLink.getRoleBObject();
													System.out.println("==1:" + master.getNumber());
													System.out.println("==2:" + objDtx.get("BOMZJ"));
													return StringUtils.equals(master.getNumber(), bomZj1.getNumber());
												}).collect(Collectors.toList());
												if (count != null && count.size() > 0) {
													// 存在更新逻辑
													UpdateSubstituteLink(count.get(0), hhLongTd, ylTd, unitTd);

												} else {
													// 不存在创建逻辑
													createWTPartAlternateLink(uLink, bomZj1, ylTd, unitTd, hhLongTd);
												}

											}
										} else {
											appendLog("（父）:" + key + " （子）:" + objDtx.get("BOMZJ"));
										}
									}
								}
							}

						}
					}

					List<Map<String, String>> sonListNull = sonList.stream()
							.filter(obj -> StringUtils.isBlank(obj.get("KNX"))).collect(Collectors.toList());
					if (sonListNull != null && !sonListNull.isEmpty()) {
						System.out.println("开始创建无需替代的子件======" + keys[0]);

						for (int i = 0; i < sonListNull.size(); i++) {
							Map<String, String> obj = sonListNull.get(i);
							// 判断子件是否存在
							WTPart bomZj = checkGc(obj.get("BOMZJ"), keys[1]);
							if (bomZj == null) {
								appendLog("（父）:" + key + " （子）:" + obj.get("BOMZJ"));
								System.out.println("子件不存在，不做处理");
							} else {
								// 查询是否存在关联关系
								WTPartUsageLink uLink = PartUtil.getLinkByPart(part, bomZj);
								Double yl = StringUtils.isBlank(obj.get("YL")) ? null
										: Double.parseDouble(obj.get("YL"));
								Long hhLong = StringUtils.isBlank(obj.get("BOMXM")) ? null
										: Long.parseLong(obj.get("BOMXM"));
								String unit = obj.get("DW");
								if (uLink == null) {
									createWtpartToLink(part, bomZj, hhLong, yl, unit);
								} else {
									UpdateLink(part, uLink, hhLong, yl, unit);
								}
							}

						}
					}
					PersistenceUtil.checkinObj(part);
				}

			}

			System.out.println("执行完毕，清查看日志是否有错误信息");
			appendLog("===================success===================");
		} catch (Exception e) {
			// t.rollback();
			e.printStackTrace();
			System.out.println("程序异常:" + e);
		} finally {
			// t.commit();
		}
	}

	public static WTPart checkGc(String number, String gc) {
		// List<WTPart> partList = PartUtil.getWTPartListByNumber(number);
        System.out.println("----test==================dafadsfasdfasd======================================");
		List<WTPart> partList = new ArrayList<WTPart>();
		QueryResult qr = null;
		try {
			QuerySpec qs = new QuerySpec(WTPart.class);
			SearchCondition scnumber = new SearchCondition(WTPart.class, wt.part.WTPart.NUMBER, SearchCondition.EQUAL,
					number.toUpperCase());
			qs.appendSearchCondition(scnumber);
			qs.appendAnd();
			SearchCondition sclatest = VersionControlHelper.getSearchCondition(wt.part.WTPart.class, true);
			qs.appendSearchCondition(sclatest);
			qr = PersistenceHelper.manager.find(qs);
			while (qr != null && qr.hasMoreElements()) {
				partList.add((WTPart) qr.nextElement());
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		appendLog("----数量" + partList.size());
        for(int i=0;i<partList.size();i++){
		 appendLog("----" + partList.get(i).getViewName());
        }

		List<WTPart> gcList = partList.stream().filter(part -> part.getViewName().equals(gc))
				.collect(Collectors.toList());
		if (gcList == null || gcList.isEmpty()) {
			appendLog("视图中无此编号:" + number + " view:" + gc);
			return null;
		}
		return gcList.get(0);
	}

	public static List<Map<String, String>> excuteSql() {
		// 查询数据库内容
		String sql = "SELECT GC,WLH,BOMXM,BOMZJ,YL,DW,DTX,KNX from BOMDATAINFO";
		ResultSet resultSet = CommonUtil.excuteSelect(sql);
		List<Map<String, String>> resultList = new ArrayList<>();
		try {
			while (resultSet.next()) {
				Map<String, String> result = new HashMap<String, String>();
				result.put("GC", resultSet.getString("GC"));
				result.put("WLH", resultSet.getString("WLH"));
				result.put("BOMXM", resultSet.getString("BOMXM"));
				result.put("BOMZJ", resultSet.getString("BOMZJ"));
				result.put("YL", resultSet.getString("YL"));
				result.put("DW", resultSet.getString("DW"));
				result.put("DTX", resultSet.getString("DTX"));
				result.put("KNX", resultSet.getString("KNX"));
				resultList.add(result);
			}
			resultSet.close();
		} catch (Exception e) {
			return null;
		}
		return resultList;
	}

	public static void createWTPartAlternateLink(WTPartUsageLink usageLink, WTPart part, Double amout, String unit,
			String wh) throws Exception {
		System.out.println("======创建子件======" + "父：" + usageLink.getFindNumber() + " 子:" + part.getNumber());

		try {
			WTPartSubstituteLink link = new WTPartSubstituteLink();
			link.setRoleAObject(usageLink);
			link.setRoleBObject(part.getMaster());
			SubstitutesReplacementType defaultType = link.getReplacementType().getSubstitutesReplacementTypeDefault();
			link.setReplacementType(defaultType);
			if (amout != null || StringUtils.isNotBlank(unit)) {
				SubstituteQuantity quantity = new SubstituteQuantity();
				if (amout != null) {
					quantity.setAmount(amout);
				}
				if (StringUtils.isNotBlank(unit)) {
					QuantityUnit quantityUnit = QuantityUnit.toQuantityUnit(unit);
					quantity.setUnit(quantityUnit);
				}

				link.setQuantity(quantity);
			}
			if (StringUtils.isNotBlank(wh)) {
				link.setReferenceDesignator(wh);
			}

			PersistenceHelper.manager.save(link);
		} catch (Exception e) {
			throw e;
		}
	}

	public static void UpdateLink(WTPart parent, WTPartUsageLink usageLink, Long number, Double amount, String dw)
			throws Exception {
		try {
			System.out.println("修改单位：" + dw);
			if (number != null) {
				LineNumber lineNumber = new LineNumber();
				lineNumber.setValue(number);
				usageLink.setLineNumber(lineNumber);
			}
			if (amount != null || StringUtils.isNotBlank(dw)) {
				Quantity quantity = new Quantity();
				if (amount != null) {
					quantity.setAmount(amount);
				}
				if (StringUtils.isNotBlank(dw)) {
					QuantityUnit quantityUnit = QuantityUnit.toQuantityUnit(dw);
					quantity.setUnit(quantityUnit);
				}

				usageLink.setQuantity(quantity);
			}

			PersistenceServerHelper.update(usageLink);
		} catch (Exception e) {
			throw e;
		}
	}

	public static void UpdateSubstituteLink(WTPartSubstituteLink link, String number, Double amount, String dw)
			throws Exception {
		try {
			System.out.println("修改替换link:" + dw);
			if (amount != null || StringUtils.isNotBlank(dw)) {
				SubstituteQuantity quantity = new SubstituteQuantity();
				quantity.setAmount(amount);
				QuantityUnit quantityUnit = QuantityUnit.toQuantityUnit(dw);
				quantity.setUnit(quantityUnit);
				link.setQuantity(quantity);
			}
			if (StringUtils.isNotBlank(number)) {
				link.setReferenceDesignator(number);
			}
			PersistenceServerHelper.update(link);
		} catch (Exception e) {
			throw e;
		}
	}

	public static void appendLog(String log) {
		SimpleDateFormat si = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String path = "/data/log/warningPart.txt";
		FileWriter writer = null;
		try {
			File file = new File(path);
			if (!file.exists()) {
				file.createNewFile();
			}
			writer = new FileWriter(path, true);
			writer.write(si.format(new Date()) + log + "\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
}
