package ext.alphai.wf.listener;

import ext.alphai.wf.util.IBAUtil;
import ext.alphai.wf.util.PropertiesUtil;
import wt.epm.EPMDocument;
import wt.events.KeyedEvent;
import wt.events.KeyedEventListener;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.vc.VersionControlServiceEvent;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EPMListenerService extends StandardManager implements EPMListener, Serializable {
    private  static final String[] clear_state = {"PRODUCTIONCHANGE","DESIGN"} ;
    private  static final List<String> clear_state_list = new ArrayList<>(Arrays.asList(clear_state));
    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = EPMListenerService.class.getName();
    private KeyedEventListener listener;

    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public EPMListenerService() {
    }

    public static EPMListenerService newEPMListenerService() throws WTException {
        EPMListenerService instance = new EPMListenerService();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new WCListenerEventListener(getConceptualClassname());
        //版本控制的检入监听事件
        getManagerService().addEventListener(listener,
                VersionControlServiceEvent.generateEventKey(VersionControlServiceEvent.NEW_VERSION));//新版本
    }

    // 内部类里面进行监听的逻辑操作
    class WCListenerEventListener extends ServiceEventListenerAdapter {
        public WCListenerEventListener(String manager_name) {
            super(manager_name);
        }

        @Override
        public void notifyVetoableEvent(Object event) throws Exception {
            System.out.println("监听");
            if (!(event instanceof VersionControlServiceEvent)) {

                return;
            }
//            Object eventTarget = ((KeyedEvent) event).getEventTarget();
            VersionControlServiceEvent pmEvent = (VersionControlServiceEvent) event;
            Object target =  pmEvent.getEventTarget();


//            如果返回 TRUE 则表示对象是升小版本因为它需要一个检入操作
//            如果返回 FALSE 则表示对象是升大版本因为它不需要一个检出-检入操作

            //监听EPM对象升级大版本
            if (target instanceof EPMDocument && !WorkInProgressHelper.isCheckedOut((Workable) target)){
                EPMDocument epm = (EPMDocument)target;
                String EPMState = epm.getLifeCycleState().toString();
                System.out.println("cad状态为:"+EPMState);
                //如果状态为生产变更  设计变更 清空一些IBA属性
                if (clear_state_list.contains(EPMState))
                System.out.println("epm新版为:"+epm.getVersionIdentifier().getValue());
                IBAUtil ibaUtil = new IBAUtil(epm);

                //清空状态
                ibaUtil.deleteIBAAttribute(epm, PropertiesUtil.getValueByKey("ext.alphai.check_by")); // 审批人
                ibaUtil.deleteIBAAttribute(epm, PropertiesUtil.getValueByKey("ext.alphai.check_date")); // 审批时间
                ibaUtil.deleteIBAAttribute(epm, PropertiesUtil.getValueByKey("ext.alphai.approved_by")); // 批准人
                ibaUtil.deleteIBAAttribute(epm, PropertiesUtil.getValueByKey("ext.alphai.approved_date"));//批准时间
                ibaUtil.deleteIBAAttribute(epm, PropertiesUtil.getValueByKey("ext.alphai.cdrawn_by")); // 设计人
                ibaUtil.deleteIBAAttribute(epm, PropertiesUtil.getValueByKey("ext.alphai.cdrawn_date")); // 设计时间

            }

        }
    }
}
