package ext.alphai.lightWeight;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;
@RBUUID("ext.alphai.lightWeight.CustomActionsRB")
public class CustomActionsRB extends WTListResourceBundle {

    @RBEntry("LightWeight")
    public static final String PRIVATE_CONSTANT_1 ="LightWeight.open.description";

    @RBEntry("LightWeight")
    public static final String PRIVATE_CONSTANT_2 ="LightWeight.open.tooltip";





}
