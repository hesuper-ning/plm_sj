package ext.alphai.lightWeight;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.lightWeight.CustomActionsRB_zh_CN")
public class CustomActionsRB_zh_CN extends WTListResourceBundle {


    @RBEntry("打开轻量化文件")
    public static final String PRIVATE_CONSTANT_1 ="LightWeight.open.description";

    @RBEntry("打开轻量化文件")
    public static final String PRIVATE_CONSTANT_2 ="LightWeight.open.tooltip";

//    @RBEntry("deliverable.gif")
//    public static final String CONSTANT_1 = "xplz.createRFQ.icon";





}
