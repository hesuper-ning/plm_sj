package ext.alphai.doBot.util;

import wt.content.*;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentHelper;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentMasterIdentity;
import wt.epm.structure.EPMMemberLink;
import wt.epm.structure.EPMStructureHelper;
import wt.fc.Identified;
import wt.fc.IdentityHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.series.HarvardSeries;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.config.LatestConfigSpec;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class EPMUtils {

    public static List<EPMDocument> getAllChildByEpm(EPMDocument epm) {
        List<EPMDocument> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        EPMDocument epmDoc = null;
        QueryResult qr2 = null;
        try {
            QueryResult qc = EPMStructureHelper.service.navigateUses(epm, null, false);
            while (qc.hasMoreElements()) {
                EPMMemberLink link = (EPMMemberLink) qc.nextElement();
                //epm连接获取epm对象
                qr2 = VersionControlHelper.service.allVersionsOf(link.getUses());
                if (qr2.hasMoreElements()) {

                    epmDoc = (EPMDocument) qr2.nextElement();
                    localList.add(epmDoc);

                    // 递归调用，将结果合并到局部列表
                    localList.addAll(getAllChildByEpm(epmDoc));
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }

    /**
     * 修改EPM生命周期状态
     *
     * @param   epm
     * @param   state
     * @return String
     * @throws WTPropertyVetoException
     * @throws WTException
     */
    public static String changEPMState(EPMDocument epm, String state) throws WTPropertyVetoException, WTException {
        String message = "";
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();

            epm = (EPMDocument) LifeCycleHelper.service.setLifeCycleState((wt.lifecycle.LifeCycleManaged) epm,
                    State.toState(state));


            PersistenceHelper.manager.refresh(epm);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return message;
    }




    /**
     * 更改CAD部件编号
     *
     * @param epm
     * @param newNumber
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPMNumber(EPMDocument epm, String newNumber) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified) epm.getMaster();
        EPMDocumentMasterIdentity iden = (EPMDocumentMasterIdentity) icp.getIdentificationObject();
        iden.setNumber(newNumber);
        IdentityHelper.service.changeIdentity(icp, iden);
        PersistenceHelper.manager.refresh(epm);
    }

    /**
     * 修改EPM名称
     *
     * @param epm
     * @param newName
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPMName(EPMDocument epm, String newName) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified) epm.getMaster();
        EPMDocumentMasterIdentity iden = (EPMDocumentMasterIdentity) icp.getIdentificationObject();
        iden.setName(newName);
        IdentityHelper.service.changeIdentity(icp, iden);
        PersistenceHelper.manager.refresh(epm);
    }


    /**
     * 更改CAD部件文件名,注意cadName必须含有后缀asm,或者prt
     *
     * @param epm
     * @param newCADName
     * @throws WTException
     */
    public static void updateEPMFileName(EPMDocument epm, String newCADName) throws WTException {
        EPMDocumentMaster epmdocumentmaster = (EPMDocumentMaster) epm.getMaster();
        WTKeyedMap map = new WTKeyedHashMap(1);
        map.put(epmdocumentmaster, newCADName);
        EPMDocumentHelper.service.changeCADName(map);
    }

    /**
     * 修改cad部件的编号,名称,文件名
     *
     * @param epm
     * @param newNumber
     * @param newName
     * @param newCADName
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPM(EPMDocument epm, String newNumber, String newName, String newCADName) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified) epm.getMaster();
        EPMDocumentMasterIdentity iden = (EPMDocumentMasterIdentity) icp.getIdentificationObject();
        //设置编号
        iden.setNumber(newNumber);
        //设置名称
        iden.setName(newName);
        IdentityHelper.service.changeIdentity(icp, iden);
        PersistenceHelper.manager.refresh(epm);

        //修改CADName 文件名
        EPMDocumentMaster epmdocumentmaster = (EPMDocumentMaster) epm.getMaster();
        WTKeyedMap map = new WTKeyedHashMap(1);
        map.put(epmdocumentmaster, newCADName);
        //修改文件名
        EPMDocumentHelper.service.changeCADName(map);
    }


    /**
     * 根据编号获取对象
     *
     * @param number
     * @param queryClass
     * @return Object
     */
    @SuppressWarnings("deprecation")
    public static Object getObjByNumber(String number, Class queryClass) {
        try {
            if (number.isEmpty()) {
                return null;
            }
            QuerySpec qs = new QuerySpec(queryClass);
            qs.appendWhere(new SearchCondition(queryClass, "master>number", SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                return qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 根据EPMDocument对象获取ApplicationData
     *
     * @param EPMDoc
     * @return
     * @throws WTException
     * @throws PropertyVetoException
     */
    public static ApplicationData findPrimary(EPMDocument EPMDoc) throws WTException, PropertyVetoException {
        System.out.println("Starting findPrimary");
        System.out.println("==========");
        ApplicationData primaryNotFound = null;
        FormatContentHolder documentWithContents = (EPMDocument) ContentHelper.service.getContents(EPMDoc);
        @SuppressWarnings("unchecked")
        Vector<ContentItem> vector = ContentHelper.getContentList(documentWithContents);
        vector.addElement(ContentHelper.getPrimary(documentWithContents));
        for (int i = 0; i < vector.size(); i++) {
            if (vector.elementAt(i) instanceof ApplicationData) {
                ApplicationData appData = (ApplicationData) vector.elementAt(i);
                if (appData.getFileName().equals("{$CAD_NAME}")) {
                    System.out.println("found primary content");
                    appData.setFileName(EPMDoc.getCADName());
                    System.out.println("Renamed file: " + appData.getFileName());
                    System.out.println("pass back to createZipList");
                    return appData;
                }
            }
        }
        return primaryNotFound;
    }

    /**
     * 检查是否存在同名的旧文件
     *
     * @param file
     * @return
     */
    public static void checkExcelExists(File file, ApplicationData data) throws Exception {
        if (file.isFile()) {
            file.deleteOnExit();
        }
        // 输入流
        InputStream is = ContentServerHelper.service.findContentStream(data);
        // 输出流到文件
        OutputStream os = new FileOutputStream(file);
        byte[] buffer = new byte[1024];
        int length;

        while ((length = is.read(buffer)) > 0) {
            os.write(buffer, 0, length);
        }
        // 关闭流
        os.close();
        is.close();
    }

    /**
     * 获取指定版本的最新小版本
     */
    public static EPMDocument getLastEPMByVersion(EPMDocument epm, String version) throws WTException {

//        EPMDocument epm = (EPMDocument)getObjByNumber(number,EPMDocument.class);
        System.out.println("查询的版本"+version);
        EPMDocument currentPart = null;
        QueryResult qr = VersionControlHelper.service.allVersionsOf(epm);
        while (qr != null && qr.hasMoreElements()) {
            EPMDocument epmLast = (EPMDocument) qr.nextElement();
            if (epmLast.getVersionIdentifier().getValue().equals(version))
                currentPart = epmLast;
        }
        return currentPart;
    }


    /**
     * 通过部件编号修订到指定的大版本
     *
     * @param epm
     * @return
     */
    public static EPMDocument reviseEPMDocumentByEPM(EPMDocument epm,String version) throws WTException, WTPropertyVetoException {
        // 修订后的部件对象
        EPMDocument afterReviseEPMDocument = null;
        // 获取当前版本
        RevisionControlled latestObjectByMaster = VersionUtil.getLatestObjectByMaster(epm.getMaster());

        String bigVersion = latestObjectByMaster.getVersionIdentifier().getValue();
        System.out.println("当前部件的大版本为=" + bigVersion);

//        MultilevelSeries mls = MultilevelSeries.newMultilevelSeries("wt.vc.VersionIdentifier", version);

        //自定模板 AIStateBased为模板的name
        HarvardSeries hds = HarvardSeries.newHarvardSeries("AIStateBased", version);

        // 小版本设定
        VersionIdentifier vid = VersionIdentifier.newVersionIdentifier(hds);
        IterationIdentifier iid = IterationIdentifier.newIterationIdentifier("1");

        afterReviseEPMDocument = (EPMDocument) VersionControlHelper.service.newVersion(epm, vid, iid);
        afterReviseEPMDocument = (EPMDocument) PersistenceHelper.manager.save(afterReviseEPMDocument);

        return afterReviseEPMDocument;
    }


    /**
     * 传入一个版本字母 如A 返回下一版本如B
     *
     * @param letter
     * @return
     */
    public static String getNextLetter(char letter) {

        char nextChar = (char) (letter + 1);

        return String.valueOf(nextChar);
    }

    //获取.前的数据
    public static String removeExtension(String fileName) {
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1) {
            return fileName; // 如果没有找到点号，直接返回原始文件名
        } else {
            return fileName.substring(0, lastDotIndex); // 截取点号之前的部分
        }
    }

    // 方法：获取文件后缀名
    public static String getFileExtension(String fileName) {
        if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
            //返回.后缀
            return fileName.substring(fileName.lastIndexOf(".") );
        } else {
            return "";
        }
    }

    /**
     *
     * @param number 新的文件名编号
     * @param suffix 旧文件名后缀
     * @return
     */
    public static String getNewSuffixFileName(String number , String suffix){
        return removeExtension(number) + "."  + getFileExtension(suffix);
    }

}
