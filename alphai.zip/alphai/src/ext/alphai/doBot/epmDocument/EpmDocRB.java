package ext.alphai.doBot.epmDocument;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.doBot.epmDocument.EpmDocRB")
public class EpmDocRB extends WTListResourceBundle {

    @RBEntry("Synchronize engineering drawings")
    public static final String SYNC_CAD_DES= "EpmDoc.syncCAD.description";
    @RBEntry("Synchronize engineering drawings")
    public static final String SYNC_CAD_TOOLTIP = "EpmDoc.syncCAD.tooltip";

    @RBEntry("Download the design drawings")
    public static final String BATCH_DOWN_DES= "EpmDoc.batchDown.description";
    @RBEntry("Download the design drawings")
    public static final String BATCH_DOWN_TOOLTIP = "EpmDoc.batchDown.tooltip";
    @RBEntry("file_zip.gif")
    public static final String SYNC_DOWN_ICON = "EpmDoc.batchDown.icon";
}
