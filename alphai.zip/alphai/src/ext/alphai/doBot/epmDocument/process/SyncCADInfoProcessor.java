package ext.alphai.doBot.epmDocument.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.doBot.epmDocument.service.SyncCADService;
import ext.alphai.doBot.epmDocument.util.PropertiesUtil;
import wt.epm.EPMDocument;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SyncCADInfoProcessor extends DefaultObjectFormProcessor {

    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("开始同步CAD部件信息");
    final String isCheckState = PropertiesUtil.getValueByKey("ext.alphai.cad.isCheckState");
    final String[] SYNC_CAD_STATE =PropertiesUtil.getValueByKey("ext.alphai.cad.syncCadState").split(",");
    final List<String> SYNC_CAD_STATE_LIST = new ArrayList(Arrays.asList(SYNC_CAD_STATE));

        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
            try {
                if (content instanceof EPMDocument) {
                    EPMDocument epmDocument = (EPMDocument) content;
                    //内部名
                    String epmDocumentState = epmDocument.getLifeCycleState().toString();
                    //非设计状态不同步CAD信息
                    if ("True".equals(isCheckState) && !SyncCADService.checkState(SYNC_CAD_STATE_LIST,epmDocumentState)) {
                        throw new WTException(epmDocument.getNumber()+"部件，状态为：" + epmDocumentState +"。只有"+SYNC_CAD_STATE_LIST+"状态，才可同步CAD部件信息！");
                    }
                    //同步CAD信息
                    SyncCADService.syncCADInfo(epmDocument);
                }
            } catch (Exception e) {
                e.printStackTrace();
                FormResult result = new FormResult(FormProcessingStatus.FAILURE);
                result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), (String)null, (ArrayList)null, new String[]{"同步CAD信息失败：" + e.getMessage()}));
                return result;
            }
        System.out.println("同步cad信息结束，返回显示信息！");
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null, new String[] { "同步CAD信息成功!" }));
        return result;

    }



}
