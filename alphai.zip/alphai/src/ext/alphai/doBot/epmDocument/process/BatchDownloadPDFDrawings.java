package ext.alphai.doBot.epmDocument.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.wvs.common.ui.VisualizationHelper;
import ext.alphai.doBot.epmDocument.util.PropertiesUtil;
import ext.alphai.doBot.util.FileUtil;
import java.beans.PropertyVetoException;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.dom4j.DocumentException;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.epm.EPMDocument;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.pom.Transaction;
import wt.representation.Representation;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BatchDownloadPDFDrawings extends DefaultObjectFormProcessor {
    private static String zipName = "";
    public static String PDF_TEMP = "";
    public static List<ApplicationData> dataList = new ArrayList();

    public BatchDownloadPDFDrawings() {
    }

    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> paramList) throws WTException {
        dataList.clear();
        StringBuffer sb = new StringBuffer();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        String timeStamp = simpleDateFormat.format(new Date());
//        List<EPMDocument> selectedEPM = getSelectedEPM(nmCommandBean);
        List<EPMDocument> selectedEPM = new ArrayList<>();
        //用request获取
        HttpServletRequest request = nmCommandBean.getRequest();
        Map<String, String[]> paramMap = request.getParameterMap();
        String[] soids = new String[] {};
        for (Map.Entry<String, String[]> entry : paramMap.entrySet()) {
            String key = entry.getKey();
            String[] values = entry.getValue();
            if(key.equals("soid")){
                soids = values;
            }
        }

        for (String soid : soids) {
            String or = getOR(soid);
            ReferenceFactory rf = new ReferenceFactory();
            WTReference reference =  rf.getReference(or);
            EPMDocument epm = (EPMDocument)reference.getObject();
            selectedEPM.add(epm);
        }
            try {
//                String number = doc.getNumber();
//                String name = doc.getName();
                zipName = "drawing_"+ timeStamp + ".zip";
                System.out.println("zipName:" + zipName);
                //获取cad的pdf
                for (EPMDocument epmDocument : selectedEPM) {
                    System.out.println("选择的epm编号"+epmDocument.getNumber());
                    getRepresentationPDF(epmDocument);
                }
                if (!dataList.isEmpty()) {
                    File zipFile = this.createZipFile(dataList);
                    System.out.println("zipFile:" + zipFile.toString().length());
                    this.uploadZipToBrowser(nmCommandBean, zipFile);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        FeedbackMessage fm = new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), (String)null, (ArrayList)null, new String[]{""});
        fm.addMessage("批量下载pdf图纸成功!!" + sb.toString(), false);
        result.addFeedbackMessage(fm);
        return result;
    }

    public static void getRepresentationPDF(EPMDocument doc) throws WTException, DocumentException, IOException {
        Transaction trx = new Transaction();

        try {
            trx.start();
            VisualizationHelper vizHelper = new VisualizationHelper();
            QueryResult result = vizHelper.getRepresentations(doc);
            Representation rep = null;
            ContentHolder ch = null;
            Vector<?> appDatas = null;
            ApplicationData appData = null;
            ApplicationData foundPDF = null;
            ApplicationData foundDXF = null;
            String fileName = null;

            while(result.hasMoreElements()) {
                rep = (Representation)result.nextElement();
                ch = ContentHelper.service.getContents(rep);
                String name = rep.getName();
                Boolean defaultRepresentation = rep.getDefaultRepresentation();
                if (defaultRepresentation) {
                    appDatas = ContentHelper.getContentListAll(ch);

                    for(int i = 0; i < appDatas.size(); ++i) {
                        appData = (ApplicationData)appDatas.get(i);
                        fileName = appData.getFileName();
                        ContentRoleType role = appData.getRole();
                        String[] split = PropertiesUtil.getValueByKey("ext.alphai.cad.downFileExtension").split(",");
                        // 将允许的扩展名转换为小写Set方便检查
                        Set<String> allowedExtensions = Arrays.stream(split)
                                .map(String::trim)
                                .map(String::toLowerCase)
                                .collect(Collectors.toSet());
                        //文件后缀变为小写
                        String fileExtension = FileUtil.getExtension(fileName).toLowerCase();

                        if ((role.equals(ContentRoleType.ADDITIONAL_FILES) || role.equals(ContentRoleType.SECONDARY))
                                && allowedExtensions.contains(fileExtension)) {
                            dataList.add(appData);
                        }
                    }
                }
            }

            trx.commit();
            trx = null;
        } catch (PropertyVetoException e) {
            throw new WTException(e);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        } finally {
            if (trx != null) {
                trx.rollback();
                Transaction var22 = null;
            }

        }

    }

    private File createZipFile(List<ApplicationData> dataList) throws IOException, WTException {
        String zipFilePath = PDF_TEMP + File.separator + zipName;
        File zipFile = new File(zipFilePath);
        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
        InputStream is = null;

        for(ApplicationData applicationData : dataList) {
            is = ContentServerHelper.service.findContentStream(applicationData);
            String fileName = applicationData.getFileName();
            ZipEntry entry = new ZipEntry(fileName);
            zos.putNextEntry(entry);
            byte[] buffer = new byte[1024];

            int len;
            while((len = is.read(buffer)) != -1) {
                zos.write(buffer, 0, len);
            }
        }

        if (zos != null) {
            zos.close();
        }

        if (is != null) {
            is.close();
        }

        return zipFile;
    }

    private void uploadZipToBrowser(NmCommandBean nmCommandBean, File zipFile) throws IOException {
        try {
            HttpServletResponse response = nmCommandBean.getResponse();
            System.out.println("response===start");
            response.reset();
            response.setContentType("application/zip");
            String encodedZipName = URLEncoder.encode(zipName, "UTF-8").replaceAll("\\+", "%20");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + encodedZipName + "\"");
            ServletOutputStream outputStream = response.getOutputStream();
            InputStream inputStream = new FileInputStream(zipFile);

            try {
                byte[] buffer = new byte[4096];

                int bytesRead;
                while((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            } catch (IOException e) {
                e.printStackTrace();
                response.setContentType("text/plain");
                response.getWriter().write("An error occurred while downloading the ZIP file.");
            } finally {
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException var30) {
                    }
                }

                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException var29) {
                    }
                }

            }
        } finally {
            if (zipFile != null && zipFile.exists()) {
                zipFile.delete();
            }

        }

        System.out.println("response===end");
    }


    public List<EPMDocument>  getSelectedEPM(NmCommandBean nmCommandBean){
        List<EPMDocument> selectedEpm = new ArrayList<>();
        try {
            ArrayList<NmOid> nmOidSelected = nmCommandBean.getNmOidSelected();
            for (NmOid nmOid : nmOidSelected) {
                Object refObject = nmOid.getRefObject();
                if (refObject instanceof EPMDocument){
                    EPMDocument epm = (EPMDocument)refObject;
                    System.out.println("getSelected获取oid转为获取选中对象"+epm.getNumber());
                    selectedEpm.add(epm);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }

        return selectedEpm;
    }


    public static String getOR(String soid) {
        String pattern =null;
        if(soid.contains("VR:wt.doc.WTDocument:")){
            pattern = "VR:wt.doc.WTDocument:\\d+"; // 正则表达式匹配模式
        } else if(soid.contains("OR:wt.doc.WTDocument:")){
            pattern = "OR:wt.doc.WTDocument:\\d+"; // 正则表达式匹配模式
        } else if (soid.contains("VR:wt.epm.EPMDocument:")) {
            pattern = "VR:wt.epm.EPMDocument:\\d+"; // 正则表达式匹配模式
        } else if(soid.contains("OR:wt.epm.EPMDocument:")){
            pattern = "OR:wt.epm.EPMDocument:\\d+"; // 正则表达式匹配模式
        } else {
            return "";
        }
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(soid);
        if (m.find()) {
            return  m.group(0);
        }
        return "";
    }







    static {
        String wtHome = null;

        try {
            WTProperties props = WTProperties.getLocalProperties();
            wtHome = props.getProperty("wt.temp");
            System.out.println("wtHome:" + wtHome);
            PDF_TEMP = wtHome + File.separator + "pdf";
            File pdfFolder = new File(PDF_TEMP);
            if (!pdfFolder.exists()) {
                pdfFolder.mkdir();
            }

            System.out.println("PDF Temp Folder: " + PDF_TEMP);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
