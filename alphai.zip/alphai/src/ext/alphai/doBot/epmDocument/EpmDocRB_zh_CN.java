package ext.alphai.doBot.epmDocument;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.doBot.epmDocument.EpmDocRB_zh_CN")
public class EpmDocRB_zh_CN extends WTListResourceBundle {


    @RBEntry("同步工程图")
    public static final String SYNC_CAD_DES= "EpmDoc.syncCAD.description";
    @RBEntry("同步工程图")
    public static final String SYNC_CAD_TOOLTIP = "EpmDoc.syncCAD.tooltip";

    @RBEntry("下载设计图纸")
    public static final String BATCH_DOWN_DES= "EpmDoc.batchDown.description";
    @RBEntry("下载设计图纸")
    public static final String BATCH_DOWN_TOOLTIP = "EpmDoc.batchDown.tooltip";
    @RBEntry("file_zip.gif")
    public static final String SYNC_DOWN_ICON = "EpmDoc.batchDown.icon";

}
