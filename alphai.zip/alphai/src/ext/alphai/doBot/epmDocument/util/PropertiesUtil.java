package ext.alphai.doBot.epmDocument.util;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Properties;

public class PropertiesUtil {

	static String PROPERTIESPATH;

	public PropertiesUtil() {
	}

	public static String getValueByKey(String key) {
		String strinfo = "";
		try {
			String propertiefile = (new StringBuilder(String.valueOf(PROPERTIESPATH))).append("config.properties")
					.toString();
			Properties p = new Properties();
			p.load(new InputStreamReader(new FileInputStream(propertiefile.substring(6, propertiefile.length())),
					"UTF-8"));
			strinfo = p.getProperty(key);
			if (strinfo != null)
			strinfo = strinfo.trim();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strinfo;
	}

	static {
		try {
			PROPERTIESPATH = PropertiesUtil.class.getResource("").toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	/**
//	 * 读取properties文件中对应的value值 并直接获取对应对象的IBA属性对应值
//	 *
//	 * @param ibaHolder 承载IBA属性的对象
//	 * @param key       properties文件中的key
//	 * @return
//	 */
//	public static String getValueByKeys(IBAHolder ibaHolder, String key) {
//		String IBAKey = getValueByKey(key);
//		String IBAValue = "";
//		try {
//			IBAUtil ibaUtil = new IBAUtil(ibaHolder);
//			Hashtable hashtable = ibaUtil.getAllIBAValues();
//			Set set = hashtable.keySet();
//			if (set.contains(IBAKey)) {
//				IBAValue = ibaUtil.getIBAValue(IBAKey);
//			} else {
//				IBAValue = "";
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return IBAValue;
//	}
//
//	/**
//	 * 读取properties文件中对应的value值 并直接设置对应对象的IBA属性对应值
//	 *
//	 * @param ibaHolder
//	 * @param key
//	 * @param IBAValue
//	 */
//	public void setValueByKey(IBAHolder ibaHolder, String key, String IBAValue) {
//		String IBAKey = getValueByKey(key);
//		try {
//			IBAUtil ibaUtil = new IBAUtil(ibaHolder);
//			ibaUtil.setIBAAttribute4AllType(ibaHolder, IBAKey, IBAValue);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

}
