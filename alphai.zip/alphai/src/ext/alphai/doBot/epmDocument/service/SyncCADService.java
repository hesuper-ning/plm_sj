package ext.alphai.doBot.epmDocument.service;

import ext.alphai.doBot.epmDocument.util.PropertiesUtil;
import ext.alphai.doBot.util.EPMUtils;
import ext.alphai.doBot.util.IBAUtil;
import ext.alphai.doBot.util.PartUtil;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.structure.RelatedDrawings;
import wt.part.WTPart;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class SyncCADService {
     
    public static void syncCADInfo(WTPart part) throws Exception {
        final String[] UPDATE_IBA_KEY = PropertiesUtil.getValueByKey("ext.alphai.cad.iba.updateIBA").split(",");
        final String[] UNIT_IBA_KEY = PropertiesUtil.getValueByKey("ext.alphai.cad.iba.containUnit").split(",");
        final List<String> UNIT_IBA_KEY_LIST = new ArrayList<>(Arrays.asList(UNIT_IBA_KEY));
        String partNumber = part.getNumber();//编号
        String partName = part.getName();//中文名

        //获取部件的cad值
        IBAUtil ibaUtilPart = new IBAUtil(part);
        List<String> partIBAValues = new ArrayList<>();
        for (String ibaKey : UPDATE_IBA_KEY) {
            //获取的显示值，但是 kg单位覆盖成g  获取的是g为单位的值
            String ibaValue = ibaUtilPart.getIBAValue(ibaKey);
            //带单位的iba集合
           if (UNIT_IBA_KEY_LIST.contains(ibaKey) &&  !ibaValue.isEmpty()){
               //更改为内部值,且去掉前后的空格
               ibaValue = IBAUtil.getIBAInterValue(part,ibaKey).trim();
               ibaValue = ibaValue.split("\\s+")[0];//以空格为分割，取下标0 实数部分
               // ibaValue = getNum(ibaValue); // 替换掉所有非数字字符
            }
            System.out.println(ibaKey+":"+ibaValue);
            partIBAValues.add(ibaValue);
        }
        List<EPMDocument> allCADByPart = PartUtil.getAllCADByPart(part);
        //获取其中2D部件的数量
        int epm2DNum = SyncCADService.get2DNum(allCADByPart);
        int count=0;
        System.out.println("打印value集合"+partIBAValues);
        for (EPMDocument epm : allCADByPart) {
            System.out.println("打印cad部件名称"+epm.getName());
            //修改编号, 2d+_D
            String oldCADNumber = epm.getNumber();
            String fileExtension = EPMUtils.getFileExtension(oldCADNumber);//旧编号后缀，没有.就返回空
//            fileExtension = fileExtension==""?"":"."+fileExtension;//判断编号有没有后缀，有就返回.+后缀，否则返回空已经修改了方法，返回.后缀
             if (!oldCADNumber.split("_")[0].equals(partNumber)) {
            if ("CADDRAWING".equals(epm.getDocType().toString())) {//判断是否为2d部件
                //数量大于1，
                if (epm2DNum>1){
                    count++;
                    EPMUtils.updateEPMNumber(epm,partNumber+"_D"+count+fileExtension);
                }else{
                    EPMUtils.updateEPMNumber(epm,partNumber+"_D"+fileExtension);
                }

            }else{
                EPMUtils.updateEPMNumber(epm,partNumber);
            }}

            //修改名称
            EPMUtils.updateEPMName(epm,partName);

            //修改IBA属性
            IBAUtil ibaUtilEPM = new IBAUtil(epm);
            for (int i = 0; i < UPDATE_IBA_KEY.length; i++) {
                //值为空，跳过
                // if (partIBAValues.get(i).isEmpty()){
                //     continue;
                // }
                ibaUtilEPM.setIBAAttribute4AllType(epm,UPDATE_IBA_KEY[i],partIBAValues.get(i));
            }

            //修改文件名
             String oldFileName = epm.getCADName();// 旧cad文件名
             setFileName(partNumber, epm, oldFileName);
        }

    }

    private static void setFileName(String partNumber, EPMDocument epm, String oldFileName) throws WTException {
        String fileExtension;
        if ("true".equals(PropertiesUtil.getValueByKey("ext.alphai.cad.isUpdateFileName"))&&!oldFileName.split("_")[0].equals(partNumber)) {
            String newCADNumber = EPMUtils.removeExtension(epm.getNumber()).toLowerCase() ;//修改后的cad编号.前数据变成小写
            fileExtension = EPMUtils.getFileExtension(oldFileName);//旧文件名后缀
            String newFileName = newCADNumber+fileExtension;//新cad编号+旧cad文件名后缀

            EPMUtils.updateEPMFileName(epm,newFileName);
        }
    }


    public static void syncCADInfo(EPMDocument epmDocument) throws Exception {
        final String[] UPDATE_IBA_KEY = PropertiesUtil.getValueByKey("ext.alphai.cad.iba.updateIBA").split(",");
        final String[] UNIT_IBA_KEY = PropertiesUtil.getValueByKey("ext.alphai.cad.iba.containUnit").split(",");
        final List<String> UNIT_IBA_KEY_LIST = new ArrayList<>(Arrays.asList(UNIT_IBA_KEY));
        String epmNumber =EPMUtils.removeExtension(epmDocument.getNumber()) ;//epm编号获取最后.前
        String epmName = epmDocument.getName();//中文名
        String cadName = EPMUtils.removeExtension(epmDocument.getCADName());//epm文件名获取最后.前

        //获取部件的cad值
        IBAUtil ibaUtilPart = new IBAUtil(epmDocument);
        List<String> epmIBAValues = new ArrayList<>();
        for (String ibaKey : UPDATE_IBA_KEY) {
            //获取的显示值，但是 kg单位覆盖成g  获取的是g为单位的值
            String ibaValue = ibaUtilPart.getIBAValue(ibaKey);
            //带单位的iba集合
            if (UNIT_IBA_KEY_LIST.contains(ibaKey) &&  !ibaValue.isEmpty()){
                //更改为内部值,且去掉前后的空格
                ibaValue = IBAUtil.getIBAInterValue(epmDocument,ibaKey).trim();
                ibaValue = ibaValue.split("\\s+")[0];//以空格为分割，取下标0 实数部分
            }
            //获取3D的需要同步的值
            System.out.println(ibaKey+":"+ibaValue);
            epmIBAValues.add(ibaValue);
        }
        //获取所有的
        List<EPMDocument> epm2dList = get2DBy3D(epmDocument);
        //获取其中2D部件的数量
        int epm2DNum = epm2dList.size();
        int count=0;
        System.out.println("打印value集合"+epmIBAValues);
        //3D同步2D的信息
        for (EPMDocument epm : epm2dList) {
            System.out.println("打印cad部件名称"+epm.getName());
            //修改编号, 2d+_D
            String oldCADNumber = epm.getNumber();
            String fileExtension = EPMUtils.getFileExtension(oldCADNumber);//旧编号后缀，没有.就返回空
//            fileExtension = fileExtension==""?"":"."+fileExtension;//判断编号有没有后缀，有就返回.+后缀，否则返回空
            if (!oldCADNumber.split("_")[0].equals(epmNumber)) {
//                if ("CADDRAWING".equals(epm.getDocType().toString())) {//判断是否为2d部件
                    //数量大于1，
                    if (epm2DNum>1){
                        count++;
                        EPMUtils.updateEPMNumber(epm,epmNumber+"_D"+count+fileExtension);
                    }else{
                        EPMUtils.updateEPMNumber(epm,epmNumber+"_D"+fileExtension);
                    }

                }
//            else{
//                    EPMUtils.updateEPMNumber(epm,partNumber);
//            }}

            //修改名称
            EPMUtils.updateEPMName(epm,epmName);

            //修改IBA属性
            IBAUtil ibaUtilEPM = new IBAUtil(epm);
            for (int i = 0; i < UPDATE_IBA_KEY.length; i++) {
                //值为空，跳过
                // if (partIBAValues.get(i).isEmpty()){
                //     continue;
                // }
                ibaUtilEPM.setIBAAttribute4AllType(epm,UPDATE_IBA_KEY[i],epmIBAValues.get(i));
            }

            //修改文件名
            String oldFileName = epm.getCADName();// 旧cad文件名
            setFileName(epmNumber, epm, oldFileName);
        }

    }


    /**
     *
     * @param syncStateList
     * @param partState
     * @return  true  部件状态允许同步cad
     */
    public static boolean checkState(List<String> syncStateList, String partState){
        boolean flag = false;
        for (String syncState : syncStateList) {
            if (syncState.equals(partState)) {
                flag = true;
            }
        }
        return flag;

    }


    /**
     * 获取part获取cad动态文档中2D部件的数量
     * @param allCADByPart
     * @return
     */
    public static int get2DNum(List<EPMDocument> allCADByPart){
        int num = 0;
        for (EPMDocument epm : allCADByPart) {
            //判断2D数量
            if ("CADDRAWING".equals(epm.getDocType().toString())) {
                num++;
            }
        }

        return num;

    }
    /**
     * 去掉非数字部分
     * @param ibaValue
     * @return
     */
    public static String getNum(String ibaValue){
        return ibaValue.replaceAll("[^\\d.]", ""); // 替换掉所有非数字字符和小数点部分
    }


    /**
     *  通过3D获取2D
     * @param epm3D
     * @return
     * @throws WTException
     */
//    public static List<EPMDocument> get2DBy3D(EPMDocument epm3D) throws WTException {
//        List<EPMDocument> epm2Ds = new ArrayList<>();
//
//        EPMDocumentMaster dm = (EPMDocumentMaster) epm3D.getMaster();
//        QueryResult qr = EPMStructureHelper.service.navigateReferencedBy(dm, null, false);
//        while (qr.hasMoreElements()) {
//            EPMReferenceLink rl = (EPMReferenceLink) qr.nextElement();
//            if (rl.getDepType() == PROEDependency.DEP_T_DRAW) {
//                EPMDocument epm2D = rl.getReferencedBy();
//                epm2Ds.add(epm2D);
//            }
//        }
//        return epm2Ds;
//    }


    public static List<EPMDocument> get2DBy3D(EPMDocument epm) throws WTException {
        List<EPMDocument> drawingDocList = new ArrayList<EPMDocument>();
        RelatedDrawings relatedDrawings = new RelatedDrawings(RelatedDrawings.Rule.AS_STORED_CONFIG);
        drawingDocList = relatedDrawings.find(Arrays.asList(new EPMDocument[]{epm}));
//        System.out.println("查询的绘图个数是：" + drawings.size());
//        EPMDocument drawingDoc = null;
////        if (drawings.size() != 1) {
////            return drawingDocList;
////        }
//        if (drawings.get(0) instanceof EPMDocumentMaster) {
//            EPMDocumentMaster drawingDocMaster = (EPMDocumentMaster) drawings.get(0);
//            drawingDoc = (EPMDocument) VersionControlHelper.service.allIterationsOf(drawingDocMaster).nextElement();
//        } else {
//            drawingDoc = (EPMDocument) drawings.get(0);
//        }
//        drawingDocList.add(drawingDoc);
        return drawingDocList;
    }
}
