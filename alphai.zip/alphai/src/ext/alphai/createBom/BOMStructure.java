package ext.alphai.createBom;

public class BOMStructure {
    // 工厂视图
    private String factort;
    // BOM头编号
    private String BOMNumber;
    // 行号
    private Long lineNumber;
    // master编号
    private String childNumber;
    // 数量
    private Double amount;
    // 单位
    private String unit;

    public String getFactort() {
        return factort;
    }

    public void setFactort(String factort) {
        this.factort = factort;
    }

    public String getBOMNumber() {
        return BOMNumber;
    }

    public void setBOMNumber(String BOMNumber) {
        this.BOMNumber = BOMNumber;
    }

    public Long getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(Long lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getChildNumber() {
        return childNumber;
    }

    public void setChildNumber(String childNumber) {
        this.childNumber = childNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "BOMStructure{" +
                "factort='" + factort + '\'' +
                ", BOMNumber='" + BOMNumber + '\'' +
                ", lineNumber=" + lineNumber +
                ", childNumber='" + childNumber + '\'' +
                ", amount=" + amount +
                ", unit='" + unit + '\'' +
                '}';
    }
}
