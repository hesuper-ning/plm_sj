package ext.alphai.createBom;

import com.fasterxml.jackson.core.JsonProcessingException;
import ext.util.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.occurrence.OccurrenceHelper;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.*;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.*;
import java.util.stream.Collectors;

public class ZTLoadCreateBOM implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;


    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", ZTLoadCreateBOM.class.getName(), null, new Class[]{}, new Object[]{});
    }


    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Java 8 兼容的扩展名列表
    private static final List<String> EXCEL_EXTS = Arrays.asList(
            ".xlsx", ".xls", ".xlsm", ".xlsb"
    );

    /**
     * 获取文件夹下所有Excel文件名
     */
    public static List<String> getExcelFileNames(String folderPath) {
        List<String> excelFiles = new ArrayList<>();
        File folder = new File(folderPath);

        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        String name = file.getName().toLowerCase();
                        if (isExcelFile(name)) {
                            excelFiles.add(file.getName());
                        }
                    }
                }
            }
        }

        return excelFiles;
    }

    /**
     * 判断是否是Excel文件
     */
    private static boolean isExcelFile(String fileName) {
        for (String ext : EXCEL_EXTS) {
            if (fileName.endsWith(ext)) {
                return true;
            }
        }
        return false;
    }

    public static String process() throws Exception {
        WTProperties wtProperties = WTProperties.getLocalProperties();
        String property = wtProperties.getProperty("wt.home") + File.separator + "ztBOM";
        List<String> excelFileNames = getExcelFileNames(property);
        System.out.println("Excel文件列表:");
        for (String file : excelFileNames) {
            String filePath = property + File.separator + file;
            System.out.println("- " + file);
            List<BOMStructure> structures = readExcel(filePath);
            HashMap<String, List<BOMStructure>> map = groupByCompositeKey(structures);
            System.out.println("最后的map是：" + map);
            createBOM(map, file);
        }
        System.out.println("总计: " + excelFileNames.size() + " 个文件");

        return null;
    }


    // 分组方法
    public static HashMap<String, List<BOMStructure>> groupByCompositeKey(List<BOMStructure> dataList) {
        return dataList.stream()
                .collect(Collectors.groupingBy(
                        bom -> createCompositeKey(bom.getFactort(), bom.getBOMNumber()),
                        HashMap::new,  // 明确指定Map类型
                        Collectors.toList()
                ));

    }

    // 构建复合键
    private static String createCompositeKey(String factort, String bomNumber) {
        return factort + "-" + bomNumber;
    }


    /**
     * 创建BOM
     */
    public static void createBOM(HashMap<String, List<BOMStructure>> map, String file) throws Exception {
        try {

            Set<Map.Entry<String, List<BOMStructure>>> entries = map.entrySet();
            for (Map.Entry<String, List<BOMStructure>> entry : entries) {

                HashMap<String, String> partMap = new HashMap<>();
                HashMap<String, String> subPartMap = new HashMap<>();
                String key = entry.getKey();
                if (StringUtils.equals("-", key)) {
                    continue;
                }
                String[] split = key.split("-", 2);
                String factory = split[0];
                String BOMNumber = split[1];

                WTPart latestWTPart = getLatestWTPart(BOMNumber, null, null, factory);

                List<BOMStructure> value = entry.getValue();
                if (latestWTPart != null) {
                    for (BOMStructure bomStructure : value) {
                        String childNumber = bomStructure.getChildNumber();
                        // 获取master
                        WTPartMaster wtPartMasterByNumber = getWTPartMasterByNumber(childNumber);
                        if (wtPartMasterByNumber == null) {
                            throw new WTException("BOM头：" + key + "子部件编号：" + childNumber + "不存在");
                        }
                    }
                    System.out.println("一共存在 " + partMap.size() + " 个子项物料！");
                    Transaction trx = null;
                    try {
                        trx = new Transaction();
                        trx.start();
                        // 判断是否工作副本如果不是 检出
                        if (!isCheckOut(latestWTPart)) {
                            latestWTPart = (WTPart) WorkInProgressHelper.service.checkout(latestWTPart, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
                        }
                        for (BOMStructure bomStructure : value) {
                            String childNumber = bomStructure.getChildNumber();
                            Long lineNumber = bomStructure.getLineNumber();
                            if (endsWithZero(lineNumber)) {
                                partMap.put(lineNumber.toString() + "!" + bomStructure.getAI_Placement_Side(), childNumber);
                            } else {
                                subPartMap.put(lineNumber.toString(), childNumber + "!" + bomStructure.getAI_Placement_Side());
                                continue;
                            }
                            // 获取master
                            WTPartMaster wtPartMasterByNumber = getWTPartMasterByNumber(childNumber);
                            if (wtPartMasterByNumber == null) {
                                System.out.println("BOM头：" + key + "子部件编号：" + childNumber + "不存在");
                                continue;
                            } else {
                                WTPartUsageLink link = newUsgeLink(latestWTPart, wtPartMasterByNumber, bomStructure.getAmount(), bomStructure.getLineNumber(), bomStructure.getUnit(), bomStructure.getAI_LossRate(), bomStructure.getAI_Placement_Side(), bomStructure.getReferenceDesignatorRange());
                                createOccurrence(bomStructure.getLineNumber(), link, bomStructure.getReferenceDesignatorRange());
                                IBAUtil ibaUtil = new IBAUtil(link);
                                if (bomStructure.getLineNumber() == null || bomStructure.getLineNumber() == 0) {

                                } else {
                                    ibaUtil.setIBAAttribute4AllType(link, "AI_LineNumber", bomStructure.getLineNumber().toString());
                                }

                                ibaUtil.setIBAAttribute4AllType(link, "AI_LossRate", bomStructure.getAI_LossRate());
                                ibaUtil.setIBAAttribute4AllType(link, "AI_Placement_Side", bomStructure.getAI_Placement_Side());
                            }
                        }
                        for (String line : subPartMap.keySet()) {
                            String subPartNumberAI = subPartMap.get(line);
                            String[] split1 = subPartNumberAI.split("!", 2);
                            String subPartNumber = split1[0];
                            String AI_Placement_Side = split1[1];
                            Long aLong = setLastDigitToZero(Long.parseLong(line));
                            String partNumber = partMap.get(aLong.toString() + "!" + AI_Placement_Side);
                            WTPart subPart = getLatestWTPart(subPartNumber, null, null, factory);
                            WTPart part = getLatestWTPart(partNumber, null, null, factory);

                            WTPartUsageLink link = getLinkByPart(latestWTPart, part);
                            WTPartSubstituteLink substituteLink = createSubstituteLink(link, subPart.getMaster());
                            String AI_Priority = "0" + String.valueOf(getLastDigit(Long.parseLong(line)) + 1);
                            System.out.println(partNumber + " 的替代料是：" + subPartNumber + "，优先级为：" + AI_Priority);
                            IBAUtil ibaUtil = new IBAUtil(substituteLink);
                            ibaUtil.setIBAAttribute4AllType(substituteLink, "AI_Priority", AI_Priority);
                        }
                        trx.commit();
                        trx = null;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    {
                        if (trx != null) {
                            try {
                                trx.rollback();
                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }
                        }
                    }
                    // 检入父部件
                    WorkInProgressHelper.service.checkin(latestWTPart, "checkedin");


                } else {
                    System.out.println("BOM头：" + key + "不存在");
                }


            }

        } catch (Exception e) {
            System.out.println("在执行" + file + "产生异常！");
        }

    }

    public static WTPartSubstituteLink createSubstituteLink(WTPartUsageLink link, WTPartMaster master) throws WTException {
        if (link != null && master != null) {
            WTPartSubstituteLink substLink = WTPartSubstituteLink.newWTPartSubstituteLink(link, master);
            PersistenceServerHelper.manager.insert(substLink);
            return (WTPartSubstituteLink) PersistenceHelper.manager.refresh(substLink);
        } else {
            return null;
        }
    }

    public static int getLastDigit(Long number) {
        if (number == null) {
            throw new IllegalArgumentException("输入不能为null");
        }
        // 直接取模10，结果范围是0-9或-9到0（对于负数）
        return (int) (number % 10);
    }

    /**
     * @param fatherPart, WTPart sonPart 根据父部件和子部件获取 link
     * @return WTPart
     * @throws Exception
     */
    public static WTPartUsageLink getLinkByPart(WTPart fatherPart, WTPart sonPart) {
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                WTPart part = getBomPartBylink(link);
                if (part.getNumber().equals(sonPart.getNumber())) {
                    return link;
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @param link 得到link对应的bom子部件
     * @return WTPart
     * @throws Exception
     */
    public static WTPart getBomPartBylink(WTPartUsageLink link) {
        try {
            QueryResult qr = VersionControlHelper.service.allVersionsOf(link.getUses());
            //System.out.println("getBomPartBylink----->"+ qr.size());
            if (qr.hasMoreElements()) {
                WTPart part = (WTPart) qr.nextElement();
                //System.out.println("part----->"+ part.getNumber());
                return part;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static boolean endsWithZero(Long number) {
        if (number == null) return false;
        return number % 10 == 0;
    }

    public static Long setLastDigitToZero(Long number) {
        if (number == null) return null;
        return number - (number % 10);
    }

    public static WTPartMaster getWTPartMasterByNumber(String paramString)
            throws WTException {
        WTPartMaster localWTPartMaster = null;
        QuerySpec localQuerySpec = null;
        QueryResult localQueryResult = null;
        localQuerySpec = new QuerySpec(WTPartMaster.class);

        SearchCondition localSearchCondition = new SearchCondition(WTPartMaster.class, WTPartMaster.NUMBER, SearchCondition.EQUAL, paramString);
        localQuerySpec.appendSearchCondition(localSearchCondition);
        localQueryResult = PersistenceHelper.manager.find(localQuerySpec);
        if (localQueryResult.hasMoreElements()) {
            localWTPartMaster = (WTPartMaster) localQueryResult.nextElement();
        }

        return localWTPartMaster;
    }


    /**
     * 读取excel中BOM结构
     *
     * @return
     */
    public static List<BOMStructure> readExcel(String path) {
        List<BOMStructure> structures = new ArrayList<>();
        try (InputStream inputStream = new FileInputStream(new File(path))) {
            Workbook workbook = WorkbookFactory.create(inputStream);
            Sheet sheet = workbook.getSheetAt(0);
            DataFormatter formatter = new DataFormatter();

            // 从第二行开始遍历（跳过标题行）
            for (int rowIndex = 2; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) continue; // 跳过空行

                BOMStructure bom = new BOMStructure();
                // 遍历前6列（对应Excel的6个字段）
                for (int colIndex = 0; colIndex < 9; colIndex++) {
                    Cell cell = row.getCell(colIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    String cellValue = formatter.formatCellValue(cell).trim();

                    switch (colIndex) {
                        case 0:
                            bom.setFactort(cellValue);
                            break;
                        case 1:
                            bom.setBOMNumber(cellValue);
                            break;
                        case 2:
                            bom.setLineNumber(parseLongSafe(cellValue));
                            break;
                        case 3:
                            bom.setChildNumber(cellValue);
                            break;
                        case 4:
                            bom.setAmount(parseDoubleSafe(cellValue));
                            break;
                        case 5:
                            bom.setUnit(cellValue);
                            break;
                        case 6:
                            bom.setAI_LossRate(cellValue);
                            break;
                        case 7:
                            bom.setAI_Placement_Side(cellValue);
                            break;
                        case 8:
                            bom.setReferenceDesignatorRange(cellValue);
                            break;
                    }
                }
                System.out.println("当前存储的信息是：" + bom.getChildNumber() + "：：：" + bom.toString());
                structures.add(bom);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return structures;
    }

    // 安全转换Long
    private static Long parseLongSafe(String value) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return 0L; // 或根据业务需求处理
        }
    }

    // 安全转换Double
    private static Double parseDoubleSafe(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }


    /**
     * 根据部件编号、版本、视图获取最新版本部件
     */
    public static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName) throws WTException {
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        if (StringUtils.isNotBlank(partNumber)) {
            partNumber = partNumber.trim();

            qs = new QuerySpec(WTPart.class);
            int[] index = new int[]{0};
            qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);

            if (StringUtils.isNotBlank(version)) {
                version = version.trim();
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

                if (StringUtils.isNotBlank(iteration)) {
                    iteration = iteration.trim();
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
                } else {
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
                }
            }

            if (StringUtils.isNotBlank(viewName)) {
                viewName = viewName.trim();
                View viewObj = ViewHelper.service.getView(viewName);
                if (viewObj == null)
                    return null;
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
            }

            configSpec = new LatestConfigSpec();
            configSpec.appendSearchCriteria(qs);
            qr = PersistenceHelper.manager.find((StatementSpec) qs);
            qr = configSpec.process(qr);
            if (qr.hasMoreElements()) {
                part = (WTPart) qr.nextElement();
            }
        }
        return part;
    }


    /**
     * 创建父子部件的连接关系
     * tarNum 工号
     *
     * @return
     * @throws WTException
     */
    public static WTPartUsageLink newUsgeLink(WTPart parentPart, WTPartMaster sonPart, Double amout, Long lineNumber, String unit, String AI_LossRate, String AI_Placement_Side, String referenceDesignatorRange) throws Exception {
        WTPartUsageLink part_UsageLink = WTPartUsageLink.newWTPartUsageLink(parentPart, sonPart);

        QuantityUnit qu = QuantityUnit.EA;
        if (StringUtils.isNotBlank(unit)) {
            if (StringUtils.equalsIgnoreCase("EA", unit)) {
                qu = QuantityUnit.toQuantityUnit("ea");
            } else {
                qu = QuantityUnit.toQuantityUnit(unit);
            }
        }
        Quantity qa = Quantity.newQuantity(amout, qu);// 设置数量 和单位


        part_UsageLink.setQuantity(qa);

        // 修改工号IBA属性
        return part_UsageLink = (WTPartUsageLink) PersistenceHelper.manager.save(part_UsageLink);
    }


    public static void createOccurrence(Long line, WTPartUsageLink usagelink, String occurrences) throws WTException {
        try {
            OccurrenceHelper.service.setSkipValidation(true);
            if (occurrences != null && !"".equals(occurrences)) {
                StringTokenizer occstrs = new StringTokenizer(occurrences, ",");
                String curoccstr = null;

                while (occstrs.hasMoreTokens()) {
                    curoccstr = occstrs.nextToken();
                    if (curoccstr != null && curoccstr.length() > 0) {
                        PartUsesOccurrence newOccurrence = PartUsesOccurrence.newPartUsesOccurrence(usagelink);
                        newOccurrence.setName(curoccstr);
                        OccurrenceHelper.service.saveUsesOccurrenceAndData(newOccurrence, (Vector) null);
                    }
                }
            }
        } catch (Exception var8) {
            System.out.println("创建位号时异常：第" + line + "行产生异常：" + occurrences);
            throw new WTException(var8);
        } finally {
            OccurrenceHelper.service.setSkipValidation(false);
        }

    }

    /**
     * 判断对象是否处于检出状态
     *
     * @param
     * @return boolean
     */
    public static boolean isCheckOut(Workable workable) {
        try {
            return WorkInProgressHelper.isCheckedOut(workable);
        } catch (WTException e) {

        }
        return false;
    }


    /**
     * 检出对象
     *
     * @param
     * @return Workable
     */
    public static Workable checkoutObj(Workable workable) {
        if (workable == null) {
            return null;
        }
        if (WorkInProgressHelper.isWorkingCopy(workable)) {
            return workable;
        }
        try {
            Folder folder = WorkInProgressHelper.service.getCheckoutFolder();
            CheckoutLink checkoutLink = WorkInProgressHelper.service.checkout(workable, folder, "AutoCheckOut");
            workable = checkoutLink.getWorkingCopy();
            if (!WorkInProgressHelper.isWorkingCopy(workable)) {
                workable = WorkInProgressHelper.service.workingCopyOf(workable);
            }
        } catch (WTException e) {
            e.printStackTrace();
        } catch (WTPropertyVetoException e) {
            e.printStackTrace();
        }
        return workable;
    }
}
