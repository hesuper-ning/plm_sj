package ext.alphai.createBom;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.Iterated;
import wt.vc.IterationInfo;
import wt.vc.VersionInfo;
import wt.vc.Versioned;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;

import wt.pom.Transaction;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.*;
import java.util.stream.Collectors;

public class JCExcelCreateBOM implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;


    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", JCExcelCreateBOM.class.getName(), null, new Class[]{}, new Object[]{});
    }


    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("JieCang@002");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static String process() throws Exception {
        String filePath = "D:\\ptc\\Windchill_13.1\\Windchill\\codebase\\ext\\properties\\windchillBOM1.xlsx";
        List<BOMStructure> structures = readExcel(filePath);
        HashMap<String, List<BOMStructure>> stringListHashMap = groupByCompositeKey(structures);
        for (Map.Entry<String, List<BOMStructure>> stringListEntry : stringListHashMap.entrySet()) {
            System.out.println("BOM头："+stringListEntry.getKey());
        }
        System.out.println("共有BOM个数："+stringListHashMap.keySet().size());
        createBOM(stringListHashMap);
        return null;
    }





    // 分组方法
    public static HashMap<String, List<BOMStructure>> groupByCompositeKey(List<BOMStructure> dataList) {
        return dataList.stream()
                .collect(Collectors.groupingBy(
                        bom -> createCompositeKey(bom.getFactort(), bom.getBOMNumber()),
                        HashMap::new,  // 明确指定Map类型
                        Collectors.toList()
                ));
    }

    // 构建复合键
    private static String createCompositeKey(String factort, String bomNumber) {
        return factort + "-" + bomNumber;
    }


    /**
     * 创建BOM
     */
    public static void createBOM(HashMap<String, List<BOMStructure>> map) throws Exception {
        Set<Map.Entry<String, List<BOMStructure>>> entries = map.entrySet();
        for (Map.Entry<String, List<BOMStructure>> entry : entries) {
            String key = entry.getKey();
            if(StringUtils.equals("-",key)){
                continue;
            }
            String[] split = key.split("-");
            String factory = split[0];
            String BOMNumber = split[1];

            WTPart latestWTPart = getLatestWTPart(BOMNumber, null, null, factory);

            List<BOMStructure> value = entry.getValue();
            if(latestWTPart != null){
                // 判断是否工作副本如果不是 检出
                if (!isCheckOut(latestWTPart)) {
                    latestWTPart = (WTPart) WorkInProgressHelper.service.checkout(latestWTPart,WorkInProgressHelper.service.getCheckoutFolder(),"").getWorkingCopy();
                }
                Transaction deleteTrx= new Transaction();
                deleteTrx.start();

                // 删除旧链接
                List<WTPartUsageLink> linksByPart = getLinksByPart(latestWTPart);
                linksByPart.forEach(link->{
                    try {
                        PersistenceHelper.manager.delete( link );
                    } catch (WTException e) {
                        e.printStackTrace();
                        System.out.println("删除旧有链接时BOM头："+key+"旧子项 编号："+link.getUses().getNumber()+"出现异常");
                    }
                });
                deleteTrx.commit();

                Transaction trx = null;
                try {
                    trx= new Transaction();
                    trx.start();
                    for (BOMStructure bomStructure : value) {
                        String childNumber = bomStructure.getChildNumber();
                        // 获取master
                        WTPartMaster wtPartMasterByNumber = getWTPartMasterByNumber(childNumber);
                        if(wtPartMasterByNumber == null){
                            System.out.println("BOM头："+key+"子部件编号："+childNumber+"不存在");
                            continue;
                        }else {
                            newUsgeLink(latestWTPart, wtPartMasterByNumber, bomStructure.getAmount(), bomStructure.getLineNumber(), bomStructure.getUnit());
                        }
                    }

                    trx.commit();
                    trx = null;
                } catch (Exception e){
                    e.printStackTrace();
                }{
                    if(trx!=null){
                        try {
                            trx.rollback();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                }
                // 检入父部件
                WorkInProgressHelper.service.checkin(latestWTPart ,"checkedin");


            }else {
                System.out.println("BOM头："+key+"不存在");
            }

            System.out.println("BOM:"+key+"创建完成");

        }


        System.out.println("excel 创建BOM导入完成");
    }

    public static WTPartMaster getWTPartMasterByNumber(String paramString)
            throws WTException
    {
        WTPartMaster localWTPartMaster = null;
        QuerySpec localQuerySpec = null;
        QueryResult localQueryResult = null;
        localQuerySpec = new QuerySpec(WTPartMaster.class);

        SearchCondition localSearchCondition = new SearchCondition(WTPartMaster.class, WTPartMaster.NUMBER, SearchCondition.EQUAL, paramString);
        localQuerySpec.appendSearchCondition(localSearchCondition);
        localQueryResult = PersistenceHelper.manager.find(localQuerySpec);
        if (localQueryResult.hasMoreElements())
        {
            localWTPartMaster = (WTPartMaster)localQueryResult.nextElement();
        }

        return localWTPartMaster;
    }



    /**
     * 读取excel中BOM结构
     * @return
     */
    public static List<BOMStructure> readExcel(String path) {
        List<BOMStructure> structures = new ArrayList<>();
        try (InputStream inputStream = new FileInputStream(new File(path))) {
            Workbook workbook = WorkbookFactory.create(inputStream);
            Sheet sheet = workbook.getSheetAt(0);
            DataFormatter formatter = new DataFormatter();

            // 从第二行开始遍历（跳过标题行）
            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) continue; // 跳过空行

                BOMStructure bom = new BOMStructure();
                // 遍历前6列（对应Excel的6个字段）
                for (int colIndex = 0; colIndex < 6; colIndex++) {
                    Cell cell = row.getCell(colIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    String cellValue = formatter.formatCellValue(cell).trim();

                    switch (colIndex) {
                        case 0:
                            bom.setFactort(cellValue);
                            break;
                        case 1:
                            bom.setBOMNumber(cellValue);
                            break;
                        case 2:
                            bom.setLineNumber(parseLongSafe(cellValue));
                            break;
                        case 3:
                            bom.setChildNumber(cellValue);
                            break;
                        case 4:
                            bom.setAmount(parseDoubleSafe(cellValue));
                            break;
                        case 5:
                            bom.setUnit(cellValue);
                            break;
                    }
                }
                structures.add(bom);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return structures;
    }

    // 安全转换Long
    private static Long parseLongSafe(String value) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return 0L; // 或根据业务需求处理
        }
    }

    // 安全转换Double
    private static Double parseDoubleSafe(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }



    /**
     * 根据部件编号、版本、视图获取最新版本部件
     */
    public static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName) throws WTException {
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        if (StringUtils.isNotBlank(partNumber)) {
            partNumber = partNumber.trim();

            qs = new QuerySpec(WTPart.class);
            int[] index = new int[] { 0 };
            qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);

            if (StringUtils.isNotBlank(version)) {
                version = version.trim();
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

                if (StringUtils.isNotBlank(iteration)) {
                    iteration = iteration.trim();
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
                } else {
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
                }
            }

            if (StringUtils.isNotBlank(viewName)) {
                viewName = viewName.trim();
                View viewObj = ViewHelper.service.getView(viewName);
                if (viewObj == null)
                    return null;
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
            }

            configSpec = new LatestConfigSpec();
            configSpec.appendSearchCriteria(qs);
            qr = PersistenceHelper.manager.find((StatementSpec) qs);
            qr = configSpec.process(qr);
            if (qr.hasMoreElements()) {
                part = (WTPart) qr.nextElement();
            }
        }
        return part;
    }





    /**
     * 创建父子部件的连接关系
     * tarNum 工号
     * @return
     * @throws WTException
     */
    public static WTPartUsageLink newUsgeLink(WTPart parentPart, WTPartMaster sonPart, Double amout, Long lineNumber, String unit) throws Exception {
        WTPartUsageLink part_UsageLink = WTPartUsageLink.newWTPartUsageLink( parentPart ,sonPart );

        QuantityUnit qu = QuantityUnit.toQuantityUnit( unit );

        Quantity qa = Quantity.newQuantity( amout, qu );// 设置数量 和单位

        if(lineNumber ==0){

        }else {
            part_UsageLink.setLineNumber(LineNumber.newLineNumber(lineNumber));
        }
        part_UsageLink.setQuantity( qa );

        // 修改工号IBA属性
        return part_UsageLink = (WTPartUsageLink)PersistenceHelper.manager.save( part_UsageLink );
    }



    /**
     * 判断对象是否处于检出状态
     *
     * @param Workable
     * @return boolean
     */
    public static boolean isCheckOut(Workable workable) {
        try {
            return WorkInProgressHelper.isCheckedOut(workable);
        } catch (WTException e) {

        }
        return false;
    }


    /**
     * 检出对象
     *
     * @param Workable
     * @return Workable
     */
    public static Workable checkoutObj(Workable workable) {
        if (workable == null) {
            return null;
        }
        if (WorkInProgressHelper.isWorkingCopy(workable)) {
            return workable;
        }
        try {
            Folder folder = WorkInProgressHelper.service.getCheckoutFolder();
            CheckoutLink checkoutLink = WorkInProgressHelper.service.checkout(workable, folder, "AutoCheckOut");
            workable = checkoutLink.getWorkingCopy();
            if (!WorkInProgressHelper.isWorkingCopy(workable)) {
                workable = WorkInProgressHelper.service.workingCopyOf(workable);
            }
        } catch (WTException e) {
            e.printStackTrace();
        } catch (WTPropertyVetoException e) {
            e.printStackTrace();
        }
        return workable;
    }



    /**
     * 获取部件与其所有子部件间的关联关系
     *
     * @param WTPart
     * @return List<WTPartUsageLink>
     */
    public static List<WTPartUsageLink> getLinksByPart(WTPart fatherPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                list.add(link);
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

}
