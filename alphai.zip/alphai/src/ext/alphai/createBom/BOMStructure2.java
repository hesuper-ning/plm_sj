package ext.alphai.createBom;

public class BOMStructure2 {
    // 工厂视图
    private String factort;
    // BOM头编号
    private String BOMNumber;
    // 行号
    private String lineNumber;
    // master编号
    private String childNumber;
    // 数量
    private Double amount;
    // 单位
    private String unit;
    // 损耗率
    private String AI_LossRate;
    // 安装面
    private String AI_Placement_Side;
    // 位号
    private String referenceDesignatorRange;

    public String getAI_LossRate() {
        return AI_LossRate;
    }

    public void setAI_LossRate(String AI_LossRate) {
        this.AI_LossRate = AI_LossRate;
    }

    public String getAI_Placement_Side() {
        return AI_Placement_Side;
    }

    public void setAI_Placement_Side(String AI_Placement_Side) {
        this.AI_Placement_Side = AI_Placement_Side;
    }

    public String getReferenceDesignatorRange() {
        return referenceDesignatorRange;
    }

    public void setReferenceDesignatorRange(String referenceDesignatorRange) {
        this.referenceDesignatorRange = referenceDesignatorRange;
    }

    public String getFactort() {
        return factort;
    }

    public void setFactort(String factort) {
        this.factort = factort;
    }

    public String getBOMNumber() {
        return BOMNumber;
    }

    public void setBOMNumber(String BOMNumber) {
        this.BOMNumber = BOMNumber;
    }

    public String getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getChildNumber() {
        return childNumber;
    }

    public void setChildNumber(String childNumber) {
        this.childNumber = childNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "BOMStructure{" +
                "factort='" + factort + '\'' +
                ", BOMNumber='" + BOMNumber + '\'' +
                ", lineNumber=" + lineNumber +
                ", childNumber='" + childNumber + '\'' +
                ", amount=" + amount +
                ", unit='" + unit + '\'' +
                ", AI_LossRate='" + AI_LossRate + '\'' +
                ", AI_Placement_Side='" + AI_Placement_Side + '\'' +
                ", referenceDesignatorRange='" + referenceDesignatorRange + '\'' +
                '}';
    }
}
