package ext.alphai.bom.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.fc.Persistable;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.part.*;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.config.ConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 自动生成行号信息
 * 
 * @version: 2018年10月11日
 * @author Hou Jiansong
 */

public class BOMLineNumberHelper {

	private static final Logger logger = LogManager.getLogger(BOMLineNumberHelper.class.getName());

	/**
	 * 
	 * 自动生成行号
	 *
	 * @param part
	 * @param numberList
	 * @param flag
	 * @throws WTException
	 * @throws WTPropertyVetoException
	 */
	public void autoGenLineNumber(WTPart part, List<String> numberList, boolean flag)
			throws WTException, WTPropertyVetoException {
		if (part != null) {
			if (numberList == null) {
				numberList = new ArrayList<String>();
			}
			if (numberList.contains(part.getNumber())) {
				return;
			} else {
				numberList.add(part.getNumber());
			}
			// 获取当中BOM中最大的行号
			Long ln = 0l;
			LineNumber lineNumber = LineNumberHelper.service.getLatestLineNumber(part);
			if (lineNumber != null) {
				ln = lineNumber.getValue();
			}
			if (logger.isDebugEnabled()) {
				logger.debug("ln : " + ln);
			}
			if (ln > 0) {
				ln = ln - ln % 10;
			}

			Map<WTPartUsageLink, String> linkMap = new HashMap<WTPartUsageLink, String>();
			QueryResult childNodes = WTPartHelper.service.getUsesWTParts(part, getViewConfig(part.getViewName()));
			List<WTPart> childList = new ArrayList<WTPart>();
			while (childNodes.hasMoreElements()) {
				Persistable aSubNodePair[] = (Persistable[]) childNodes.nextElement();
				WTPartUsageLink link = (WTPartUsageLink) aSubNodePair[0];

				// -----------自动分配组号
//				WTCollection collection = WTPartHelper.service.getSubstituteLinks(link);
//				if (collection.size() > 0) {
//					IBAUtils ibahelper = new IBAUtils(link);
//					String ALPGR = ibahelper.getIBAValue("Alpgr");
//					if (ALPGR == null || "".contentEquals(ALPGR)) {
//						ALPGR = 1 + "";
//					}
//					linkMap.put(link, ALPGR);
//				}
				// --------------自动分配组号 END
				if (link.getLineNumber() == null) {
					ln = ln + 10;
					LineNumber linenumber = LineNumber.newLineNumber(ln);
					link.setLineNumber(linenumber);
					PersistenceServerHelper.manager.update(link);
				}
				Persistable childp = aSubNodePair[1];
				if(childp instanceof WTPart){
				    WTPart child = (WTPart) childp;
	                if (!childList.contains(child)) {
	                    childList.add(child);
	                }
				}else{
				    logger.error(".........."+childp);
				}
			}
			// 开始分配组号 -------------------------
//			int allALPGR = 1;
//			List<String> list = new ArrayList<String>();
//			for (WTPartUsageLink link : linkMap.keySet()) {
//				list.add(linkMap.get(link));
//			}
//			allALPGR = getMaxALPGR(list);
//			for (WTPartUsageLink link : linkMap.keySet()) {
//				IBAUtils ibahelper = new IBAUtils(link);
//				String ALPGR = ibahelper.getIBAValue("Alpgr");
//				if (ALPGR == null || "".equals(ALPGR)) {
//					IBATool.setIBAValue(link, "Alpgr", allALPGR + "");
//					allALPGR++;
//				}
//			}
			// end-----------------------------------
			if (flag) {
				for (WTPart child : childList) {
					autoGenLineNumber(child, numberList, flag);
				}
			}
		}
	}

	/**
	 * 获取最大值
	 * 
	 * @param list
	 * @return
	 */
	private static int getMaxALPGR(List<String> list) {
		int max = 0;
		for (int i = 0; i < list.size(); i++) {
			int number = Integer.parseInt(list.get(i));
			if (number > max) {
				max = number;
			}
		}
		return max;
	}

	/**
	 * 获取视图过滤条件
	 * 
	 * @return
	 * @throws WTException
	 */
	public ConfigSpec getViewConfig(String viewname) {
		ConfigSpec configSpec = null;
		try {
			// 这个是设计视图
			if (viewname != null) {
				View view = ViewHelper.service.getView(viewname);
				configSpec = WTPartConfigSpec
						.newWTPartConfigSpec(WTPartStandardConfigSpec.newWTPartStandardConfigSpec(view, null));
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return configSpec;
	}
}