package ext.alphai.bom;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.bom.BomRB")
public class BomRB extends WTListResourceBundle {
    @RBEntry("AutoSetLineNumber")
    public static final String AUTO_SETlINEnUMBER_1 = "CusBOM.autoSetLineNumber.title";

    @RBEntry("AutoSetLineNumber")
    public static final String AUTO_SETlINEnUMBER_2 = "CusBOM.autoSetLineNumber.tooltip";

    @RBEntry("AutoSetLineNumber")
    public static final String AUTO_SETlINEnUMBER_3 = "CusBOM.autoSetLineNumber.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String AUTO_SETlINEnUMBER_4 = "CusBOM.autoSetLineNumber.icon";

    @RBEntry("Setting Line Number OK!")
    public static final String AUTO_SETlINEnUMBER_5 = "AUTO_SETlINEnUMBER_5";

    @RBEntry("Setting Line Number ERROE，Please contact the administrator!")
    public static final String AUTO_SETlINEnUMBER_6 = "AUTO_SETlINEnUMBER_6";
}
