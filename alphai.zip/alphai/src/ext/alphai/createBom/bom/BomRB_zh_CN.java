package ext.alphai.bom;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.bom.BomRB_zh_CN")
public class BomRB_zh_CN extends WTListResourceBundle {
    @RBEntry("自动分配行号")
    public static final String AUTO_SETlINEnUMBER_1 = "CusBOM.autoSetLineNumber.title";

    @RBEntry("自动分配行号")
    public static final String AUTO_SETlINEnUMBER_2 = "CusBOM.autoSetLineNumber.tooltip";

    @RBEntry("自动分配行号")
    public static final String AUTO_SETlINEnUMBER_3 = "CusBOM.autoSetLineNumber.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String AUTO_SETlINEnUMBER_4 = "CusBOM.autoSetLineNumber.icon";

    @RBEntry("分配完成!")
    public static final String AUTO_SETlINEnUMBER_5 = "AUTO_SETlINEnUMBER_5";
    @RBEntry("分配失败，请联系管理员!")
    public static final String AUTO_SETlINEnUMBER_6 = "AUTO_SETlINEnUMBER_6";
}
