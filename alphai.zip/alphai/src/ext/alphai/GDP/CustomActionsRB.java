package ext.alphai.GDP;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;


@RBUUID("ext.alphai.GDP.CustomActionsRB")
public class CustomActionsRB extends WTListResourceBundle {

    @RBEntry("sync to GDP")
    public static final String PRIVATE_CONSTANT_1 = "GDP.syncToGDP.description";
    @RBEntry("sync to GDP")
    public static final String PRIVATE_CONSTANT_2 = "GDP.syncToGDP.tooltip";

    @RBEntry("paste_24.png")
    public static final String PRIVATE_CONSTANT_3 = "GDP.syncToGDP.icon";


    @RBEntry("sync multiple to GDP")
    public static final String PRIVATE_CONSTANT_4 = "GDP.syncMultipleToGDP.description";
    @RBEntry("sync multiple to GDP")
    public static final String PRIVATE_CONSTANT_5 = "GDP.syncMultipleToGDP.tooltip";

    @RBEntry("paste_24.png")
    public static final String PRIVATE_CONSTANT_6 = "GDP.syncMultipleToGDP.icon";



     @RBEntry("GDP Manage")
    public static final String PRIVATE_CONSTANT_7 = "navigation.GDPManage.description";

    @RBEntry("GDP Manage")
    public static final String PRIVATE_CONSTANT_8 = "navigation.GDPManage.tooltip";

    @RBEntry("GDP.svg")
    public static final String PRIVATE_CONSTANT_9 = "navigation.GDPManage.icon";


     @RBEntry("GDP Main")
    public static final String PRIVATE_CONSTANT_10 = "GDPManage.GDPMain.description";

    @RBEntry("GDP Main")
    public static final String PRIVATE_CONSTANT_11 = "GDPManage.GDPMain.tooltip";

    @RBEntry("GDP.svg")
    public static final String PRIVATE_CONSTANT_12 = "GDPManage.GDPMain.icon";


    @RBEntry("GDP Supplier")
    public static final String PRIVATE_CONSTANT_21 = "GDPManage.GDPSupplier.description";

    @RBEntry("GDP Supplier")
    public static final String PRIVATE_CONSTANT_22 = "GDPManage.GDPSupplier.tooltip";

    @RBEntry("supplierManger.svg")
    public static final String PRIVATE_CONSTANT_23 = "GDPManage.GDPSupplier.icon";


    @RBEntry("paste QR")
    public static final String PRIVATE_CONSTANT_13 = "GDP.pasteQR.description";
    @RBEntry("paste QR")
    public static final String PRIVATE_CONSTANT_14 = "GDP.pasteQR.tooltip";


    @RBEntry("sync supplier to GDP")
    public static final String PRIVATE_CONSTANT_15 = "GDP.addSingleSupplier.description";
    @RBEntry("sync supplier to GDP")
    public static final String PRIVATE_CONSTANT_16 = "GDP.addSingleSupplier.tooltip";
    @RBEntry("supplierManger.svg")
    public static final String PRIVATE_CONSTANT_20 = "GDP.addSingleSupplier.icon";

    @RBEntry("sync suppliers to GDP")
    public static final String PRIVATE_CONSTANT_17 = "GDP.addMultipleSupplier.description";
    @RBEntry("sync suppliers to GDP")
    public static final String PRIVATE_CONSTANT_18 = "GDP.addMultipleSupplier.tooltip";
    @RBEntry("supplierManger.svg")
    public static final String PRIVATE_CONSTANT_19 = "GDP.addMultipleSupplier.icon";

}
