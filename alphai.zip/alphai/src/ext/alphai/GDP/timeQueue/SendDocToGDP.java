package ext.alphai.GDP.timeQueue;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.GDP.domain.AIDrawing;
import ext.alphai.GDP.domain.AISupplier;
import ext.alphai.GDP.domain.ResponseVo;
import ext.alphai.GDP.service.AIDrawingService;
import ext.alphai.GDP.service.AISupplierService;
import ext.alphai.GDP.util.CommonUtil;
import ext.alphai.GDP.util.PropertiesUtil;
import ext.alphai.GDP.vo.SyncReqVo;
import ext.alphai.GDP.vo.SyncSupplierVo;

import java.util.Date;
import java.util.List;

public class SendDocToGDP {
    static final ObjectMapper objectMapper = new ObjectMapper();

    public static void queueTest() {
        Date date = new Date();
        System.out.println("======发送图纸信息到GDP队列正在执行======" + date);
        ResponseVo responseVo = null;
        String loginGDPToken =null;
        try {
            List<AIDrawing> drawingsLists = AIDrawingService.getDrawingsLists(AIDrawingService.GDP_STATUE_UNSEND);
            if(!drawingsLists.isEmpty()){
                // 调用同步接口后的返回json
                SyncReqVo syncReqVo = AIDrawingService.sendAIDrawingToGDP(drawingsLists);
                String reqJson = objectMapper.writeValueAsString(syncReqVo);

                // 登录
                loginGDPToken = CommonUtil.loginGDP();

//                System.out.println("GDP同步数据库的请求json:"+reqJson);
                String respJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("GDP.url"), loginGDPToken, reqJson, "POST");

                System.out.println("GDP同步返回数据："+respJson);
                // 解析后修改状态
                responseVo = AIDrawingService.updateAIDrawingStatus(drawingsLists, respJson);
            }else {
                System.out.println("暂无待同步图纸文档条目");
            }

            // 同步供应商
            List<AISupplier> aiSuppliers = AISupplierService.selectByName(null, AISupplierService.GDP_STATUE_UNSEND);

            if (!aiSuppliers.isEmpty()) {
                SyncSupplierVo syncSupplierVo = new SyncSupplierVo(Long.parseLong(PropertiesUtil.getValueByKey("GDP.deptId")), aiSuppliers, AISupplierService.nowTimeToDate());

                String reqJson = objectMapper.writeValueAsString(syncSupplierVo);
                String respJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("GDP.supplier.url"), loginGDPToken, reqJson, "POST");
                responseVo = AISupplierService.updateAISupplierStatus(aiSuppliers, respJson);
            }else {
                System.out.println("暂无待同步供应商");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("发送后的返回结果："+responseVo);
        System.out.println("==============发送图纸信息到GDP执行完毕==================");
    }
}
