package ext.alphai.GDP.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
//import com.ptc.windchill.suma.supplier.Manufacturer;
import com.ptc.windchill.suma.supplier.Vendor;
import ext.alphai.GDP.service.AISupplierService;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;

public class AddSingleSupplier extends DefaultObjectFormProcessor {

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        try{
            if(content instanceof Vendor){
                Vendor manufacturer = (Vendor) content;
                List<Vendor> manus = new ArrayList<>();
                manus.add(manufacturer);
                AISupplierService.insertAISupplier(manus);
            }
        }catch (Exception e) {
            FormResult result = new FormResult(FormProcessingStatus.FAILURE);
            result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(),null,null,new String[]{e.getMessage()}));
            return result;
        }
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS,SessionHelper.getLocale(),null,null,new String[]{"已将供应商添加到待发送列表"}));
        return result;
    }
}
