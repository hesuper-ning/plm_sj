package ext.alphai.GDP.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.suma.supplier.Manufacturer;
import com.ptc.windchill.suma.supplier.Vendor;
import ext.alphai.GDP.service.AISupplierService;
import ext.alphai.GDP.util.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.WTObject;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddMultipleSupplier extends DefaultObjectFormProcessor {

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult result = null;
        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();
        String[] soids = new String[]{};
        List<String> ors = new ArrayList<>();
        for (String key: parameterMap.keySet()) {
            Object value = parameterMap.get(key);
//            String[] values = (String[]) value;
//            for (String a : values) {
//                System.out.println("key=" + key + "value=" + a);
//            }
            if("soid".equals(key)){
                soids = (String[]) value;
            }

        }

        for (String oid : soids) {
            String or = getOR(oid);
            if(!StringUtils.isBlank(or)){
                ors.add(or);
            }
        }

        List<Vendor> manus=new ArrayList<>();

        for (String or : ors) {
            WTObject object = CommonUtil.oid2Object(or);
            if(object instanceof Vendor){
                Vendor manufacturer = (Vendor) object;
                manus.add(manufacturer);
            }
        }

        try {
            AISupplierService.insertAISupplier(manus);
        } catch (SQLException e) {
            e.printStackTrace();
            result = new FormResult(FormProcessingStatus.FAILURE);
            result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(),null,null,new String[]{e.getMessage()}));
            return result;
        }
        result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(),null,null,new String[]{"已将文档添加到待发送列表"}));
        return result;


    }


    /**
     *
     * 在返回的String soid中得到部件OR
     * @param soid
     * @return
     */
    public static String getOR(String soid) {
        String pattern ="OR:com.ptc.windchill.suma.supplier.Manufacturer:\\d+";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(soid);
        if (m.find()) {
            String partVROrOR = m.group(0);
            if(partVROrOR.contains("OR")){
                return partVROrOR;
            }
        }
        return "";
    }
}
