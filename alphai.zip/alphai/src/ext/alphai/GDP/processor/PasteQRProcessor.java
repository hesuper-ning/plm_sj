package ext.alphai.GDP.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.wvs.common.ui.VisualizationHelper;
import ext.alphai.GDP.QRCode.PDFWithQRCode;
import ext.alphai.GDP.QRCode.QRCodeGenerator;
import ext.alphai.GDP.util.CommonUtil;
import ext.alphai.GDP.util.PropertiesUtil;
import wt.content.*;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.QueryResult;
import wt.pom.Transaction;
import wt.representation.Representation;
import wt.session.SessionHelper;
import wt.util.FileUtil;
import wt.util.WTException;
import wt.util.WTProperties;

import java.io.*;
import java.util.List;
import java.util.UUID;
import java.util.Vector;

/**
 * 粘贴二维码到图纸
 */
public class PasteQRProcessor extends DefaultObjectFormProcessor {
    public static String PDF_TEMP = "";
    static {
        String wtHome = null;
        try {
            WTProperties props = WTProperties.getLocalProperties();
            wtHome = props.getProperty("wt.temp");
            PDF_TEMP = wtHome + File.separator + "pdf";
            File pdfFolder = new File(PDF_TEMP);
            if (!pdfFolder.exists()) {
                pdfFolder.mkdir();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        try{
            String deptId = PropertiesUtil.getValueByKey("GDP.deptId");
            String url = PropertiesUtil.getValueByKey("GDP.QR.url");
            if(content instanceof EPMDocument){
                EPMDocument epm = (EPMDocument) content;
                if (CommonUtil.isCheckOut(epm)) {
                    throw new WTException("请检入后再操作");
                }
                String epmOr = CommonUtil.object2Oid(epm);
                // 粘贴二维码到PDF上
                String replaceUrl = url.replace("OR", epmOr).replace("TENANT", deptId);
                System.out.println("URL为："+replaceUrl);

                ByteArrayInputStream byteArrayInputStream = QRCodeGenerator.generateQRCode(replaceUrl);
                addQRToPDF(byteArrayInputStream, epm);
            } else if (content instanceof WTDocument) {
                WTDocument doc = (WTDocument) content;
                if (CommonUtil.isCheckOut(doc)) {
                    throw new WTException("请检入后再操作");
                }
                // 获取主要内容中的PDF
                String docOr = CommonUtil.object2Oid(doc);
                // 粘贴二维码到PDF上
                String replaceUrl = url.replace("OR", docOr).replace("TENANT", deptId);
                ByteArrayInputStream byteArrayInputStream = QRCodeGenerator.generateQRCode(replaceUrl);

                // 将二维码粘贴到主要内容中

                addQRToWTDocPDF(byteArrayInputStream, doc);
            }


        }catch (Exception e) {
            FormResult result = new FormResult(FormProcessingStatus.FAILURE);
            result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(),null,null,new String[]{e.getMessage()}));
            return result;
        }
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS,SessionHelper.getLocale(),null,null,new String[]{"PDF添加二维码成功！"}));
        return result;
    }





    public static void addQRToPDF(InputStream isQS, EPMDocument epm) {
        Transaction trx = new Transaction();
        try {
            trx.start();

            VisualizationHelper vizHelper = new VisualizationHelper();
            QueryResult result = vizHelper.getRepresentations(epm);

            Representation rep = null;
            ContentHolder ch = null;
            Vector<?> appDatas = null;

            ApplicationData appData = null;
            ApplicationData foundPDF = null;
            String fileName = null;

            while (result.hasMoreElements()) {
                rep = (Representation) result.nextElement();
                ch = ContentHelper.service.getContents(rep);
                String name = rep.getName();
                Boolean defaultRepresentation = rep.getDefaultRepresentation();
                System.out.println("002-Representation : " + name);
                System.out.println("002-Representation defaultRepresentation: " + defaultRepresentation);
                // 必须从默认表示法中获取pdf
                if (!defaultRepresentation) {
                    continue;
                }
                appDatas = ContentHelper.getContentListAll(ch);
                for (int i = 0; i < appDatas.size(); i++) {
                    appData = (ApplicationData) appDatas.get(i);
                    fileName = appData.getFileName();
                    System.out.println("002-Representation FileName: " + fileName);
                    ContentRoleType role = appData.getRole();
                    System.out.println("002-Representation ContentRoleType: " + role.toString());
                    // 检查表示法中是否包含pdf
                    if ((role.equals(ContentRoleType.ADDITIONAL_FILES) || role.equals(ContentRoleType.SECONDARY))
                            && FileUtil.getExtension(fileName).equalsIgnoreCase("pdf")) {
                        foundPDF = appData;
                        break;
                    }
                }
                if (foundPDF != null) {
                    break;
                }
            }

            if (foundPDF != null) {
                String pdfFileName = foundPDF.getFileName();
                String signatureFilePath = PDF_TEMP + File.separator + pdfFileName;
                String newPdfName = UUID.randomUUID().toString()+ ".pdf";
                String tempPath = PDF_TEMP + File.separator+ newPdfName;

                // 确保临时目录存在且有写入权限
                File tempDir = new File(PDF_TEMP);
                if (!tempDir.exists()) {
                    if (!tempDir.mkdirs()) {
                        throw new IOException("无法创建临时目录: " + PDF_TEMP);
                    }
                }
                if (!tempDir.canWrite()) {
                    throw new IOException("临时目录无写入权限: " + PDF_TEMP);
                }

                // 将变量 is 输出为 signatureFilePath 路径的文件
                try (InputStream is = ContentServerHelper.service.findContentStream(foundPDF);
                     FileOutputStream fos = new FileOutputStream(tempPath)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = is.read(buffer)) != -1) {
                        fos.write(buffer, 0, bytesRead);
                    }
                    fos.flush(); // 确保所有数据都被写入文件
                } catch (IOException e) {
                    System.err.println("文件写入失败: " + e.getMessage());
                    e.printStackTrace();
                    throw e;
                }

                // 检查文件是否写入成功
                File tempFile = new File(tempPath);
                if (!tempFile.exists() || tempFile.length() == 0) {
                    throw new IOException("文件写入失败或为空: " + tempPath);
                }

                System.out.println("粘贴二维码开始 : " + tempPath);

                // 检查二维码输入流是否有效
                if (isQS == null || isQS.available() <= 0) {
                    throw new IOException("二维码输入流无效");
                }
                // 假设 确定PDF所在位置的类型由EPM文档类型可得
                String pdfType = "GDP.def.X.Y";

                // 调用工具类添加二维码
                try {
                    PDFWithQRCode.addQRCodeToPDF(isQS, tempPath, signatureFilePath,pdfType);
                } catch (Exception e) {
                    System.err.println("添加二维码失败: " + e.getMessage());
                    e.printStackTrace();
                    throw e;
                }

                System.out.println("粘贴结束后更新到表示法 : " + fileName);
                try (FileInputStream fis = new FileInputStream(signatureFilePath)) {
                    foundPDF = ContentServerHelper.service.updateContent(ch, foundPDF, fis);
                }

                if (!tempFile.delete()) {
                    System.err.println("删除临时文件失败: " + newPdfName);
                }
                // 删除临时文件
                File signatureFilePathFile = new File(signatureFilePath);
                if (!signatureFilePathFile.delete()) {
                    System.err.println("删除临时文件失败: " + signatureFilePath);
                }


            } else {
                throw new WTException("没有PDF");
            }

            trx.commit();
            trx = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (trx != null) {
                trx.rollback();
                trx = null;
            }
        }
    }


    /**
     * 粘贴二维码到文档主要内容
     * @param isQS
     * @param doc
     */
    public static void addQRToWTDocPDF(InputStream isQS, WTDocument doc) throws Exception {
        String oid = CommonUtil.object2Oid(doc);
        ContentItem primary = CommonUtil.findPrimary(oid);
        if(primary == null){
            return;
        }
        ApplicationData foundPDF = (ApplicationData) primary;
        String fileName = foundPDF.getFileName();
        if(!FileUtil.getExtension(fileName).equalsIgnoreCase("pdf")){
            return;
        }
        // 下载
        String signatureFilePath = PDF_TEMP + File.separator + fileName;
        String newPdfName = UUID.randomUUID().toString()+ ".pdf";
        String tempPath = PDF_TEMP + File.separator+ newPdfName;
        // 确保临时目录存在且有写入权限
        File tempDir = new File(PDF_TEMP);
        if (!tempDir.exists()) {
            if (!tempDir.mkdirs()) {
                throw new IOException("无法创建临时目录: " + PDF_TEMP);
            }
        }
        if (!tempDir.canWrite()) {
            throw new IOException("临时目录无写入权限: " + PDF_TEMP);
        }

        // 将变量 is 输出为 signatureFilePath 路径的文件
        try (InputStream is = ContentServerHelper.service.findContentStream(foundPDF);
             FileOutputStream fos = new FileOutputStream(tempPath)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
            fos.flush(); // 确保所有数据都被写入文件
        } catch (IOException e) {
            System.err.println("文件写入失败: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }

        // 检查文件是否写入成功
        File tempFile = new File(tempPath);
        if (!tempFile.exists() || tempFile.length() == 0) {
            throw new IOException("文件写入失败或为空: " + tempPath);
        }

        System.out.println("粘贴二维码开始 : " + tempPath);

        // 检查二维码输入流是否有效
        if (isQS == null || isQS.available() <= 0) {
            throw new IOException("二维码输入流无效");
        }
        // 假设 确定PDF所在位置的类型由EPM文档类型可得
        String pdfType = "GDP.def.X.Y";

        // 调用工具类添加二维码
        try {
            PDFWithQRCode.addQRCodeToPDF(isQS, tempPath, signatureFilePath,pdfType);
        } catch (Exception e) {
            System.err.println("添加二维码失败: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }


        try (FileInputStream fis = new FileInputStream(signatureFilePath)) {
            // 更新文档主要内容
            foundPDF = ContentServerHelper.service.updatePrimary((FormatContentHolder)doc, (ApplicationData)foundPDF, fis);
        }

        if (!tempFile.delete()) {
            System.err.println("删除临时文件失败: " + newPdfName);
        }
        // 删除临时文件
        File signatureFilePathFile = new File(signatureFilePath);
        if (!signatureFilePathFile.delete()) {
            System.err.println("删除临时文件失败: " + signatureFilePath);
        }

    }



}
