package ext.alphai.GDP.vo;

import ext.alphai.GDP.domain.SysSupplier;

import java.lang.reflect.Field;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 文档历史版本 返回数据类
 */
public class DocVo {
    private Long AIDrawingId;

    private Long docId;

    private Long docMasterId;

    private String docOr;

    private Date releaseTime;

    private String versionIdentifier;

    private String iterationIdentifier;

    private String ibaJson;

    private Boolean isExist;

    private Date updateTime;

    // EPM文档状态
    private String epmDocStatus;

    List<DocDrawVo> docDraws;

    // 改版本文档所选中的供应商集合id
    List<Long> supplierIds;

    public List<Long> getSupplierIds() {
        return supplierIds;
    }

    public void setSupplierIds(List<Long> supplierIds) {
        this.supplierIds = supplierIds;
    }

    public Long getAIDrawingId() {
        return AIDrawingId;
    }

    public void setAIDrawingId(Long AIDrawingId) {
        this.AIDrawingId = AIDrawingId;
    }

    public String getEpmDocStatus() {
        return epmDocStatus;
    }

    public void setEpmDocStatus(String epmDocStatus) {
        this.epmDocStatus = epmDocStatus;
    }

    public Long getDocId() {
        return docId;
    }

    public void setDocId(Long docId) {
        this.docId = docId;
    }

    public Long getDocMasterId() {
        return docMasterId;
    }

    public void setDocMasterId(Long docMasterId) {
        this.docMasterId = docMasterId;
    }

    public String getDocOr() {
        return docOr;
    }

    public void setDocOr(String docOr) {
        this.docOr = docOr;
    }

    public Date getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(Date releaseTime) {
        this.releaseTime = releaseTime;
    }

    public String getVersionIdentifier() {
        return versionIdentifier;
    }

    public void setVersionIdentifier(String versionIdentifier) {
        this.versionIdentifier = versionIdentifier;
    }

    public String getIterationIdentifier() {
        return iterationIdentifier;
    }

    public void setIterationIdentifier(String iterationIdentifier) {
        this.iterationIdentifier = iterationIdentifier;
    }

    public String getIbaJson() {
        return ibaJson;
    }

    public void setIbaJson(String ibaJson) {
        this.ibaJson = ibaJson;
    }

    public Boolean getExist() {
        return isExist;
    }

    public void setExist(Boolean exist) {
        isExist = exist;
    }

    public List<DocDrawVo> getDocDraws() {
        return docDraws;
    }

    public void setDocDraws(List<DocDrawVo> docDraws) {
        this.docDraws = docDraws;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "DocRespVo{" +
                "docId=" + docId +
                ", docMasterId=" + docMasterId +
                ", docOr='" + docOr + '\'' +
                ", releaseTime=" + releaseTime +
                ", versionIdentifier='" + versionIdentifier + '\'' +
                ", iterationIdentifier='" + iterationIdentifier + '\'' +
                ", ibaJson='" + ibaJson + '\'' +
                ", isExist=" + isExist +
                ", upTimestampTime=" + updateTime +
                ", docDraws=" + docDraws +
                '}';
    }



    public static <T> Map<T, DocVo> getFieldValuesAsMap(List<DocVo> list, String fieldName, Class<T> targetType) {
        Map<T, DocVo> result = new HashMap<>();
        try {
            for (DocVo doc : list) {
                Field field = DocVo.class.getDeclaredField(fieldName);
                field.setAccessible(true);
                @SuppressWarnings("unchecked")
                T value = (T) field.get(doc);
                result.put(value, doc);
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();  // 异常处理，根据需要调整
        }
        return result;
    }
}
