package ext.alphai.GDP.vo;

import java.lang.reflect.Field;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 图纸文档相关信息
 */
public class DocDrawVo {

    private Long drawId;

    private Long docId;

    private String drawName;

    // 最后修改者 display name
    private String personResponsible;

    private String pictureFormat;

    private String sourceFormat;
    // 是否存在
    private Boolean isExist;
    private Date updateTime;
    private Object byteFile;

    public Object getByteFile() {
        return byteFile;
    }

    public void setByteFile(Object byteFile) {
        this.byteFile = byteFile;
    }

    public Long getDrawId() {
        return drawId;
    }

    public void setDrawId(Long drawId) {
        this.drawId = drawId;
    }

    public Long getDocId() {
        return docId;
    }

    public void setDocId(Long docId) {
        this.docId = docId;
    }

    public String getDrawName() {
        return drawName;
    }

    public void setDrawName(String drawName) {
        this.drawName = drawName;
    }

    public String getPersonResponsible() {
        return personResponsible;
    }

    public void setPersonResponsible(String personResponsible) {
        this.personResponsible = personResponsible;
    }

    public String getPictureFormat() {
        return pictureFormat;
    }

    public void setPictureFormat(String pictureFormat) {
        this.pictureFormat = pictureFormat;
    }

    public String getSourceFormat() {
        return sourceFormat;
    }

    public void setSourceFormat(String sourceFormat) {
        this.sourceFormat = sourceFormat;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getExist() {
        return isExist;
    }

    public void setExist(Boolean exist) {
        isExist = exist;
    }

    @Override
    public String toString() {
        return "DocDrawRespVo{" +
                "drawId=" + drawId +
                ", docId=" + docId +
                ", drawName='" + drawName + '\'' +
                ", personResponsible='" + personResponsible + '\'' +
                ", pictureFormat='" + pictureFormat + '\'' +
                ", sourceFormat='" + sourceFormat + '\'' +
                ", isExist=" + isExist +
                ", updateTime=" + updateTime +
                '}';
    }



    public static <T> Map<T, DocDrawVo> getFieldValuesAsMap(List<DocDrawVo> list, String fieldName, Class<T> targetType) {
        Map<T, DocDrawVo> result = new HashMap<>();
        try {
            for (DocDrawVo doc : list) {
                Field field = DocDrawVo.class.getDeclaredField(fieldName);
                field.setAccessible(true);
                @SuppressWarnings("unchecked")
                T value = (T) field.get(doc);
                result.put(value, doc);
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();  // 异常处理，根据需要调整
        }
        return result;
    }
}
