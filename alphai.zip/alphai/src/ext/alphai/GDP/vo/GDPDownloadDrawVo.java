package ext.alphai.GDP.vo;

/**
 * GDP 请求下载文档请求参数
 */
public class GDPDownloadDrawVo {
    // 图纸名称
    private String drawName;

    // 文档OR
    private String docOr;

    public String getDrawName() {
        return drawName;
    }

    public void setDrawName(String drawName) {
        this.drawName = drawName;
    }

    public String getDocOr() {
        return docOr;
    }

    public void setDocOr(String docOr) {
        this.docOr = docOr;
    }
}
