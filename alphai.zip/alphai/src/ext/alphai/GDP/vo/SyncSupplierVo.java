package ext.alphai.GDP.vo;

import ext.alphai.GDP.domain.AISupplier;

import java.util.Date;
import java.util.List;

public class SyncSupplierVo {

    private Long deptId;

    private List<AISupplier> supplierList;
    private Date requestDate;

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public List<AISupplier> getSupplierList() {
        return supplierList;
    }

    public void setSupplierList(List<AISupplier> supplierList) {
        this.supplierList = supplierList;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public SyncSupplierVo() {
    }


    public SyncSupplierVo(Long deptId, List<AISupplier> supplierList, Date requestDate) {
        this.deptId = deptId;
        this.supplierList = supplierList;
        this.requestDate = requestDate;
    }
}
