package ext.alphai.GDP.vo;
import java.util.Date;
import java.util.List;
public class SyncReqVo {

    private Long deptId;

    private List<DocMasterVo> docMasters;

    // 发送同步请求的用户id
    private String userId;

    private Date requestDate;



    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public List<DocMasterVo> getDocMasters() {
        return docMasters;
    }

    public void setDocMasters(List<DocMasterVo> docMasters) {
        this.docMasters = docMasters;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }


}
