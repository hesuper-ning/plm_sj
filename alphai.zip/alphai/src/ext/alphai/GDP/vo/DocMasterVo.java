package ext.alphai.GDP.vo;

import java.lang.reflect.Field;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 同步文档返回对象
 */
public class DocMasterVo {
    private Long deptId;

    private String docMasterOr;

    private Long docMasterId;

    private String docName;

    private String docNumber;

    // 是否存在
    private Boolean isExist;

    private Date updateTime;



    private List<DocVo> docs;

    private String supplierJson;
    public String getSupplierJson() {
        return supplierJson;
    }

    public void setSupplierJson(String supplierJson) {
        this.supplierJson = supplierJson;
    }

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public String getDocMasterOr() {
        return docMasterOr;
    }

    public void setDocMasterOr(String docMasterOr) {
        this.docMasterOr = docMasterOr;
    }

    public Long getDocMasterId() {
        return docMasterId;
    }

    public void setDocMasterId(Long docMasterId) {
        this.docMasterId = docMasterId;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public Boolean getExist() {
        return isExist;
    }

    public void setExist(Boolean exist) {
        isExist = exist;
    }

    public List<DocVo> getDocs() {
        return docs;
    }

    public void setDocs(List<DocVo> docs) {
        this.docs = docs;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }


    @Override
    public String toString() {
        return "DocMasterRespVo{" +
                "deptId='" + deptId + '\'' +
                ", docMasterOr='" + docMasterOr + '\'' +
                ", docMasterId=" + docMasterId +
                ", docName='" + docName + '\'' +
                ", docNumber='" + docNumber + '\'' +
                ", isExist=" + isExist +
                ", updateTime=" + updateTime +
                ", docs=" + docs +
                '}';
    }


    /**
     * 获取List<DocMasterVo>中指定属性名的所有值
     *
     * @param list       输入的List集合
     * @param fieldName  要获取的属性名
     * @param <T>        返回值的类型
     * @return List<T>   指定属性的值集合
     */
    public static <T> Map<T, DocMasterVo> getFieldValuesAsMap(List<DocMasterVo> list, String fieldName, Class<T> targetType) {
        Map<T, DocMasterVo> result = new HashMap<>();
        try {
            for (DocMasterVo doc : list) {
                Field field = DocMasterVo.class.getDeclaredField(fieldName);
                field.setAccessible(true);
                @SuppressWarnings("unchecked")
                T value = (T) field.get(doc);
                result.put(value, doc);
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();  // 异常处理，根据需要调整
        }
        return result;
    }
}

