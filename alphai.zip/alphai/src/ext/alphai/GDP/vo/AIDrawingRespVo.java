package ext.alphai.GDP.vo;

public class AIDrawingRespVo {
    private Long AIDrawingId;

    private Boolean status;

    private Object object;

    public Long getAIDrawingId() {
        return AIDrawingId;
    }

    public void setAIDrawingId(Long AIDrawingId) {
        this.AIDrawingId = AIDrawingId;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public AIDrawingRespVo(Long AIDrawingId, Boolean status, Object object) {
        this.AIDrawingId = AIDrawingId;
        this.status = status;
        this.object = object;
    }

    public AIDrawingRespVo() {
    }
}
