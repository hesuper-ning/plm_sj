package ext.alphai.GDP.listen;

public interface GDPDeleteListen {
}
