package ext.alphai.GDP.listen;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.suma.supplier.Manufacturer;
import ext.alphai.GDP.domain.AISupplier;
import ext.alphai.GDP.service.AISupplierService;
import ext.alphai.GDP.util.CommonUtil;
import ext.alphai.GDP.util.PropertiesUtil;
import ext.alphai.GDP.vo.SyncSupplierVo;
import wt.fc.PersistenceManagerEvent;
import wt.events.KeyedEventListener;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class GDPDeleteListenService extends StandardManager implements GDPDeleteListen, Serializable {

    static final ObjectMapper objectMapper = new ObjectMapper();
    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = GDPDeleteListenService.class.getName();
    private KeyedEventListener listener;

    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public GDPDeleteListenService() {
    }

    public static GDPDeleteListenService newGDPDeleteListenService() throws WTException {
        GDPDeleteListenService instance = new GDPDeleteListenService();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new GDPDeleteListenService.WCListenerEventListener(getConceptualClassname());
        getManagerService().addEventListener(listener,
                PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_DELETE));




    }


    class WCListenerEventListener extends ServiceEventListenerAdapter {
        public WCListenerEventListener(String s) {
            super(s);
        }



        @Override
        public void notifyVetoableEvent(Object event) throws Exception {
            System.out.println("-----------GDP删除监听器----------");
            if (event instanceof PersistenceManagerEvent){

                PersistenceManagerEvent eve = (PersistenceManagerEvent) event;
                Object target = eve.getEventTarget();
                deleteGDPSupplier(target);
            }




        }
    }


    /**
     * windchill删除供应商GDP同步删除
     * @param target
     */
    public static void deleteGDPSupplier(Object target){
        if(target instanceof Manufacturer){
            Manufacturer manu = (Manufacturer) target;
            List<AISupplier> list = new ArrayList<>();
            String name = manu.getName();
            AISupplier aiSupplier = new AISupplier();
            aiSupplier.setSupplierOR(CommonUtil.object2Oid(manu));
            aiSupplier.setSupplierName(name);
            list.add(aiSupplier);
            SyncSupplierVo syncSupplierVo = new SyncSupplierVo(Long.parseLong(PropertiesUtil.getValueByKey("GDP.deptId")), list, AISupplierService.nowTimeToDate());
            String respJson = null;
            try {
                String reqJson = objectMapper.writeValueAsString(syncSupplierVo);
                String loginGDPToken = CommonUtil.loginGDP();
                respJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("GDP.supplier.delete.url"), loginGDPToken, reqJson, "POST");
                HashMap<String, Object> map = objectMapper.readValue(respJson, new TypeReference<HashMap<String, Object>>() {});
                Integer code = (Integer) map.get("code");
                if(code == 200){
                    System.out.println("同步删除成功供应商名称为："+name);
                }else {
                    System.out.println("删除失败原因为："+map.get("msg"));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


        }
    }
}
