package ext.alphai.GDP.domain;

import java.util.List;

public class AIDrawingResp {


    private Long AIDrawingId;

    private String DOCMASTERCLASS;

    private Long DOCMASTERIDA2A2;

    private String docOr;

    private String docStatus;

    private String addTime;

    private String CADName;

    private String EPMNumber;
    // 大版本
    private String version;
    // 小版本
    private String iteration;
    //  EPM文档状态
    private String EPMStatus;


    private String EPMDocUrl;

    public String getSupplierJson() {
        return supplierJson;
    }

    public void setSupplierJson(String supplierJson) {
        this.supplierJson = supplierJson;
    }

    private String supplierJson;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getIteration() {
        return iteration;
    }

    public void setIteration(String iteration) {
        this.iteration = iteration;
    }

    public String getEPMStatus() {
        return EPMStatus;
    }

    public void setEPMStatus(String EPMStatus) {
        this.EPMStatus = EPMStatus;
    }

    public Long getAIDrawingId() {
        return AIDrawingId;
    }

    public void setAIDrawingId(Long AIDrawingId) {
        this.AIDrawingId = AIDrawingId;
    }

    public String getDOCMASTERCLASS() {
        return DOCMASTERCLASS;
    }

    public void setDOCMASTERCLASS(String DOCMASTERCLASS) {
        this.DOCMASTERCLASS = DOCMASTERCLASS;
    }

    public Long getDOCMASTERIDA2A2() {
        return DOCMASTERIDA2A2;
    }

    public void setDOCMASTERIDA2A2(Long DOCMASTERIDA2A2) {
        this.DOCMASTERIDA2A2 = DOCMASTERIDA2A2;
    }

    public String getDocOr() {
        return docOr;
    }

    public void setDocOr(String docOr) {
        this.docOr = docOr;
    }

    public String getDocStatus() {
        return docStatus;
    }

    public void setDocStatus(String docStatus) {
        this.docStatus = docStatus;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getCADName() {
        return CADName;
    }

    public void setCADName(String CADName) {
        this.CADName = CADName;
    }

    public String getEPMNumber() {
        return EPMNumber;
    }

    public void setEPMNumber(String EPMNumber) {
        this.EPMNumber = EPMNumber;
    }

    public String getEPMDocUrl() {
        return EPMDocUrl;
    }

    public void setEPMDocUrl(String EPMDocUrl) {
        this.EPMDocUrl = EPMDocUrl;
    }

    public AIDrawingResp(Long AIDrawingId, String DOCMASTERCLASS, Long DOCMASTERIDA2A2, String docOr, String docStatus, String addTime, String CADName, String EPMNumber,String EPMDocUrl, String supplierJson) {
        this.AIDrawingId = AIDrawingId;
        this.DOCMASTERCLASS = DOCMASTERCLASS;
        this.DOCMASTERIDA2A2 = DOCMASTERIDA2A2;
        this.docOr = docOr;
        this.docStatus = docStatus;
        this.addTime = addTime;
        this.CADName = CADName;
        this.EPMNumber = EPMNumber;
        this.EPMDocUrl = EPMDocUrl;
        this.supplierJson = supplierJson;
    }

    public AIDrawingResp() {
    }
}
