package ext.alphai.GDP.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 组织供应商对象 sys_supplier
 * 
 * @author lvtian
 * @date 2025-04-02
 */
public class SysSupplier
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long supplierId;


    private Long parentDeptId;


    private String supplierOr;


    private String supplierName;


    private String supplierAbbreviation;


    private String supplierType;


    private String supplierLifeStatus;


    private String supplierSocialCreditCode;


    private String supplierRemarks;
    private String supplierMail;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    private String createBy;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    private String updateBy;

    private String remark;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public void setSupplierId(Long supplierId)
    {
        this.supplierId = supplierId;
    }

    public Long getSupplierId() 
    {
        return supplierId;
    }
    public void setParentDeptId(Long parentDeptId)
    {
        this.parentDeptId = parentDeptId;
    }

    public Long getParentDeptId()
    {
        return parentDeptId;
    }
    public void setSupplierOr(String supplierOr) 
    {
        this.supplierOr = supplierOr;
    }

    public String getSupplierOr() 
    {
        return supplierOr;
    }
    public void setSupplierName(String supplierName) 
    {
        this.supplierName = supplierName;
    }

    public String getSupplierName() 
    {
        return supplierName;
    }

    public String getSupplierAbbreviation() {
        return supplierAbbreviation;
    }

    public void setSupplierAbbreviation(String supplierAbbreviation) {
        this.supplierAbbreviation = supplierAbbreviation;
    }

    public String getSupplierType() {
        return supplierType;
    }

    public void setSupplierType(String supplierType) {
        this.supplierType = supplierType;
    }

    public String getSupplierLifeStatus() {
        return supplierLifeStatus;
    }

    public void setSupplierLifeStatus(String supplierLifeStatus) {
        this.supplierLifeStatus = supplierLifeStatus;
    }

    public String getSupplierSocialCreditCode() {
        return supplierSocialCreditCode;
    }

    public void setSupplierSocialCreditCode(String supplierSocialCreditCode) {
        this.supplierSocialCreditCode = supplierSocialCreditCode;
    }

    public String getSupplierRemarks() {
        return supplierRemarks;
    }

    public void setSupplierRemarks(String supplierRemarks) {
        this.supplierRemarks = supplierRemarks;
    }

    public String getSupplierMail() {
        return supplierMail;
    }

    public void setSupplierMail(String supplierMail) {
        this.supplierMail = supplierMail;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("supplierId", getSupplierId())
            .append("ParentDeptId", getParentDeptId())
            .append("supplierOr", getSupplierOr())
            .append("supplierName", getSupplierName())
            .append("supplierAbbreviation", getSupplierAbbreviation())
            .append("supplierType", getSupplierType())
            .append("supplierLifeStatus", getSupplierLifeStatus())
            .append("supplierSocialCreditCode", getSupplierSocialCreditCode())
            .append("supplierRemarks", getSupplierRemarks())
            .toString();
    }
}
