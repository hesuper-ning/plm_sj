package ext.alphai.GDP.domain;

/**
 * 供应商中间表
 */
public class AISupplier {
    private Long AISupplierId;

    private String supplierOr;
    // 供应商简称
    private String supplierAbbreviation;
    // 供应商名称
    private String supplierName;
    // 供应商类型
    private String supplierType;

    // 供应商状态 来自生命周期状态
    private String supplierLifeStatus;

    private String addTime;
    // 邮政地址
    private String supplierMail;
    // 供应商社会信用码
    private String supplierSocialCreditCode;
    // 备注
    private String supplierRemarks;
    // 0代表未发送  代表已发送
    private String supplierStatus;

    public AISupplier(Long AISupplierId, String supplierOr, String supplierName, String supplierAbbreviation, String supplierType, String supplierStatus, String addTime, String supplierMail, String supplierLifeStatus, String supplierRemarks, String supplierSocialCreditCode) {
        this.AISupplierId = AISupplierId;
        this.supplierOr = supplierOr;
        this.supplierName = supplierName;
        this.supplierAbbreviation = supplierAbbreviation;
        this.supplierType = supplierType;
        this.supplierStatus = supplierStatus;
        this.addTime = addTime;
        this.supplierMail = supplierMail;
        this.supplierLifeStatus = supplierLifeStatus;
        this.supplierRemarks = supplierRemarks;
        this.supplierSocialCreditCode = supplierSocialCreditCode;
    }

    public AISupplier() {
    }

    public Long getAISupplierId() {
        return AISupplierId;
    }

    public void setAISupplierId(Long AISupplierId) {
        this.AISupplierId = AISupplierId;
    }

    public String getSupplierOr() {
        return supplierOr;
    }

    public void setSupplierOR(String supplierOr) {
        this.supplierOr = supplierOr;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierType() {
        return supplierType;
    }

    public void setSupplierType(String supplierType) {
        this.supplierType = supplierType;
    }

    public String getSupplierStatus() {
        return supplierStatus;
    }

    public void setSupplierStatus(String supplierStatus) {
        this.supplierStatus = supplierStatus;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getSupplierMail() {
        return supplierMail;
    }

    public void setSupplierMail(String supplierMail) {
        this.supplierMail = supplierMail;
    }

    public void setSupplierOr(String supplierOr) {
        this.supplierOr = supplierOr;
    }

    public String getSupplierAbbreviation() {
        return supplierAbbreviation;
    }

    public void setSupplierAbbreviation(String supplierAbbreviation) {
        this.supplierAbbreviation = supplierAbbreviation;
    }

    public String getSupplierLifeStatus() {
        return supplierLifeStatus;
    }

    public void setSupplierLifeStatus(String supplierLifeStatus) {
        this.supplierLifeStatus = supplierLifeStatus;
    }

    public String getSupplierSocialCreditCode() {
        return supplierSocialCreditCode;
    }

    public void setSupplierSocialCreditCode(String supplierSocialCreditCode) {
        this.supplierSocialCreditCode = supplierSocialCreditCode;
    }

    public String getSupplierRemarks() {
        return supplierRemarks;
    }

    public void setSupplierRemarks(String supplierRemarks) {
        this.supplierRemarks = supplierRemarks;
    }
}
