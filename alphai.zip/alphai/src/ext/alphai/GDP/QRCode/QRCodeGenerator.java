package ext.alphai.GDP.QRCode;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import ext.alphai.GDP.util.PropertiesUtil;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * 生成二维码的PNG
 */
public class QRCodeGenerator {


    // 生成二维码并返回图片流
    public static ByteArrayInputStream generateQRCode(String data) throws Exception {
        int size = Integer.parseInt(PropertiesUtil.getValueByKey("GDP.QR.Size"));  // 二维码的长宽
        String fileType = "PNG";

        // 设置二维码的错误修正级别和边距
        Map<EncodeHintType, Object> hintMap = new HashMap<>();
        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
        hintMap.put(EncodeHintType.MARGIN, 1);

        MultiFormatWriter qrCodeWriter = new MultiFormatWriter();
        BitMatrix bitMatrix = qrCodeWriter.encode(data, BarcodeFormat.QR_CODE, size, size, hintMap);

        // 创建二维码图像
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                image.setRGB(i, j, bitMatrix.get(i, j) ? 0x000000 : 0xFFFFFF);
            }
        }

        // 将 BufferedImage 转为 ByteArrayInputStream
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ImageIO.write(image, fileType, byteArrayOutputStream);
        byte[] imageBytes = byteArrayOutputStream.toByteArray();
        return new ByteArrayInputStream(imageBytes);  // 返回图片流
    }
}