package ext.alphai.GDP;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;

import com.ptc.windchill.suma.supplier.Manufacturer;
import ext.alphai.GDP.listen.GDPDeleteListenService;
import ext.alphai.GDP.util.CommonUtil;

import ext.alphai.GDP.util.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.Iterated;
import wt.vc.IterationInfo;
import wt.vc.VersionInfo;
import wt.vc.Versioned;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.rmi.RemoteException;


/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * 
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * 
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * 
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * 
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 * 
 * @author dz
 *
 */
public class RemoteTest18 implements RemoteAccess, Serializable {

	private static final long serialVersionUID = 1L;


	public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

		String str = (String) invoke("process", RemoteTest18.class.getName(), null, new Class[]{}, new Object[]{});
	}

	public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");
		try {
			return rms.invoke(methodName, className, instance, cla, obj);
		} catch (RemoteException e) {
			e.printStackTrace();
			return null;
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String process() {
		try {
//			AIDrawingReq aiDrawingReq = new AIDrawingReq();
//			aiDrawingReq.setDocStatus("0");
//			ObjectMapper objectMapper = new ObjectMapper();
//			List<AIDrawingResp> aiDrawingRespList = AIDrawingService.getAIDrawingRespList(aiDrawingReq);
//			ResponseVo responseVo = new ResponseVo(200, "success", aiDrawingRespList);
//			System.out.println("默认返回值："+objectMapper.writeValueAsString(responseVo));


//		String docOr = "OR:wt.epm.EPMDocument:312041";
//        ByteArrayInputStream holleLvTian = QRCodeGenerator.generateQRCode("http://139.186.154.114:9999/system/docdraw/checkDrawVersion?docOr="+docOr+"&deptId=101");
//        addQRCodeToPDF(holleLvTian, "D:\\PDF_604000049_D.pdf", "D:\\123.pdf");

//			String OR = "OR:com.ptc.windchill.suma.supplier.Manufacturer:396186";
//			WTObject object = CommonUtil.oid2Object(OR);
//			Manufacturer manufacturer = (Manufacturer) object;
//			GDPDeleteListenService.deleteGDPSupplier(manufacturer);


//			String ibakey =  "AI_reusingLevel";
//			String OR = "OR:wt.part.WTPart:252352";
//			WTObject object = CommonUtil.oid2Object(OR);
//			WTPart part = (WTPart) object;
//			WTPartMaster master = part.getMaster();
//			IBAUtil ibaUtil = new IBAUtil(master);
////			ibaUtil.setIBAAttribute4AllType(master, ibakey, "C");
//			String ibaValue = ibaUtil.getIBAValue(ibakey);
//			System.out.println("值为："+ibaValue);





		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	// 将二维码流添加到现有 PDF 的右上角
	public static void addQRCodeToPDF(InputStream qrCodeImageStream, String inputPdfPath, String outputPdfPath) throws Exception {
		int size = 105;
		// 检查输入参数
		if (qrCodeImageStream == null) {
			throw new IllegalArgumentException("二维码输入流不能为空");
		}
		if (inputPdfPath == null || outputPdfPath == null) {
			throw new IllegalArgumentException("输入或输出文件路径不能为空");
		}

		// 检查输入 PDF 文件
		File inputFile = new File(inputPdfPath);
		if (!inputFile.exists() || inputFile.length() == 0) {
			throw new IOException("输入 PDF 文件不存在或为空: " + inputPdfPath);
		}

		// 检查输出文件路径
		File outputFile = new File(outputPdfPath);
		File outputDir = outputFile.getParentFile();
		if (!outputDir.exists()) {
			if (!outputDir.mkdirs()) {
				throw new IOException("无法创建输出目录: " + outputDir.getAbsolutePath());
			}
		}
		if (!outputDir.canWrite()) {
			throw new IOException("输出目录无写入权限: " + outputDir.getAbsolutePath());
		}

		PdfReader reader = null;
		FileOutputStream outputStream = null;
		PdfStamper stamper = null;

		try {
			// 初始化 PdfReader 和 FileOutputStream
			reader = new PdfReader(inputPdfPath);
			outputStream = new FileOutputStream(outputFile);

			// 初始化 PdfStamper
			stamper = new PdfStamper(reader, outputStream);

			// 获取第一个页面
			PdfContentByte canvas = stamper.getOverContent(1);

			// 将 InputStream 转换为字节数组
			byte[] imageBytes = inputStreamToByteArray(qrCodeImageStream);
			if (imageBytes == null || imageBytes.length == 0) {
				throw new IOException("二维码图片流无效");
			}

			// 加载二维码图片
			Image qrCodeImage = Image.getInstance(imageBytes);

			// 设置二维码的大小
			qrCodeImage.scaleAbsolute(size, size);

			// 获取页面的宽度和高度
//            float pageWidth = reader.getPageSize(1).getWidth();
//            float pageHeight = reader.getPageSize(1).getHeight();
//
//            // 计算二维码的位置（右上角）
//            float x = pageWidth - qrCodeImage.getScaledWidth() - 40;  // 右边距 40 像素
//            float y = pageHeight - qrCodeImage.getScaledHeight() - 40;  // 上边距 40 像素
			// 配置文件中的XY 轴
//			String xyStr = PropertiesUtil.getValueByKey(pdfType);
//			String[] split = xyStr.split(",");

//			qrCodeImage.setAbsolutePosition(Integer.parseInt(split[0]), Integer.parseInt(split[1]));

			qrCodeImage.setAbsolutePosition(2940-size, 2350-size);
			// 将二维码添加到页面
			canvas.addImage(qrCodeImage);

			System.out.println("二维码贴到图纸PDF成功!");
		} catch (IOException | DocumentException e) {
			System.err.println("操作 PDF 失败: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			// 手动关闭资源
			try {
				if (stamper != null) {
					stamper.close(); // 关闭 PdfStamper
				}
			} catch (Exception e) {
				System.err.println("关闭 PdfStamper 失败: " + e.getMessage());
				e.printStackTrace();
			} finally {
				try {
					if (reader != null) {
						reader.close(); // 关闭 PdfReader
					}
				} catch (Exception e) {
					System.err.println("关闭 PdfReader 失败: " + e.getMessage());
				} finally {
					try {
						if (outputStream != null) {
							outputStream.close(); // 关闭 FileOutputStream
						}
					} catch (IOException e) {
						System.err.println("关闭 FileOutputStream 失败: " + e.getMessage());
					}
				}
			}
		}
	}

	// 将 InputStream 转换为字节数组
	private static byte[] inputStreamToByteArray(InputStream inputStream) throws IOException {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		int length;
		while ((length = inputStream.read(buffer)) != -1) {
			byteArrayOutputStream.write(buffer, 0, length);
		}
		return byteArrayOutputStream.toByteArray();
	}












	/*
	找 不属于项目下的某一视图 编号的部件版本
	 */
	public static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName) throws WTException {
		WTPart part = null;
		LatestConfigSpec configSpec = null;
		QuerySpec qs = null;
		QueryResult qr = null;
		if (StringUtils.isNotBlank(partNumber)) {
			partNumber = partNumber.trim();

			qs = new QuerySpec(WTPart.class);
			int[] index = new int[] { 0 };
			qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);

			if (StringUtils.isNotBlank(version)) {
				version = version.trim();
				qs.appendAnd();
				qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

				if (StringUtils.isNotBlank(iteration)) {
					iteration = iteration.trim();
					qs.appendAnd();
					qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
				} else {
					qs.appendAnd();
					qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
				}
			}

			if (StringUtils.isNotBlank(viewName)) {
				viewName = viewName.trim();
				View viewObj = ViewHelper.service.getView(viewName);
				if (viewObj == null)
					return null;
				qs.appendAnd();
				qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
			}

			// 查询条件里加上 上下文不等于项目
			qs.appendAnd();
			qs.appendWhere(new SearchCondition(WTPart.class, "containerReference.key.classname", SearchCondition.NOT_EQUAL, "wt.projmgmt.admin.Project2", false), index);


			configSpec = new LatestConfigSpec();
			configSpec.appendSearchCriteria(qs);
			qr = PersistenceHelper.manager.find((StatementSpec) qs);
			qr = configSpec.process(qr);
			if (qr.hasMoreElements()) {
				part = (WTPart) qr.nextElement();
			}
		}
		return part;
	}












}
