package ext.alphai.GDP.service;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.suma.supplier.Contact;
import com.ptc.windchill.suma.supplier.Manufacturer;
import com.ptc.windchill.suma.supplier.SupplierContactLink;
import com.ptc.windchill.suma.supplier.Vendor;
import ext.alphai.GDP.domain.AISupplier;
import ext.alphai.GDP.domain.ResponseVo;
import ext.alphai.GDP.domain.SysSupplier;
import ext.alphai.GDP.util.CommonUtil;
import ext.alphai.GDP.util.IBAUtil;
import ext.alphai.GDP.util.PropertiesUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class AISupplierService {
    // 已发送过后状态为 1
    public static final String GDP_STATUE_SENDED = "1";
    // 未发 DOCSTATUE 为 0
    public static final String GDP_STATUE_UNSEND = "0";

    public static final String STRING_BLANK= "";

    public static final String STRING_COMMA = ",";


    public static final String single_quotes = "'";
    static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     *  根据供应商名称和状态查询
     * @param supplierName
     * @param supplierStatus
     * @return
     */
    public static List<AISupplier> selectByName(String supplierName, String supplierStatus) throws SQLException {
        List<AISupplier> result = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM AISUPPLIER ");
        if(StringUtils.isNotBlank(supplierName)){
            sql.append(" WHERE SUPPLIERNAME LIKE ").append(single_quotes).append("%").append(supplierName).append("%").append(single_quotes);
            sql.append(" AND SUPPLIERSTATUS = ?");
        }else {
            sql.append(" WHERE SUPPLIERSTATUS = ?");
        }
        sql.append(" ORDER BY ADDTIME DESC");

        ResultSet resultSet = CommonUtil.excuteSelect(sql.toString(), supplierStatus);
        while (resultSet.next()) {

            AISupplier aiSupplier = new AISupplier(Long.parseLong(resultSet.getString("AISUPPLIERID")), resultSet.getString("SUPPLIEROR"),resultSet.getString("SUPPLIERNAME"),
                    resultSet.getString("SUPPLIERABBREVIATION"),resultSet.getString("SUPPLIERTYPE"),resultSet.getString("SUPPLIERSTATUS"), resultSet.getString("ADDTIME"),
                    resultSet.getString("SUPPLIERMAIL"),resultSet.getString("SUPPLIERLIFESTATUS"),resultSet.getString("SUPPLIERREMARKS"),resultSet.getString("SUPPLIERSOCIALCREDITCODE"));
            result.add(aiSupplier);
        }


        return result;
    }

    /**
     * 删除 待发供应商
     * @param ids
     */
    public static void delete(List<Long> ids){
        Transaction trx = null;
        try {
            trx= new Transaction();
            trx.start();
            for (Long id : ids) {
                String sql = "DELETE FROM AISUPPLIER WHERE AISUPPLIERID = TO_NUMBER(?)";
                CommonUtil.excuteUpdate(sql, String.valueOf(id));
            }

            trx.commit();
            trx = null;
        }catch (Exception e){
            e.printStackTrace();
        } finally {
            if(trx!=null){
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }


    /**
     * 插入或者修改供应商中间表
     * @param manufacturers
     */
    public static void insertAISupplier(List<Vendor> manufacturers) throws SQLException, WTException {

        List<AISupplier> inserts = new ArrayList<>();
        List<AISupplier> updates = new ArrayList<>();
        for (Vendor manufacturer : manufacturers) {
            String supplierName = manufacturer.getName();
            AISupplier aiSupplier = selectAISupplierBySupplierName(supplierName, GDP_STATUE_UNSEND);
            if(aiSupplier == null){
                inserts.add(getAISupplierByManufacturer(null, manufacturer));
            }else {
                updates.add(getAISupplierByManufacturer(aiSupplier.getAISupplierId(), manufacturer));
            }
        }

        Transaction trx = null;
        try {
            trx= new Transaction();
            trx.start();

            // 执行修改或者插入

            for (AISupplier insert : inserts) {
                insert(insert);
            }

            for (AISupplier update : updates) {
                update(update);
            }


            trx.commit();
            trx = null;
        }catch (Exception e){
            e.printStackTrace();
        } finally {
            if(trx!=null){
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    /**
     * 插入
     * @param aiSupplier
     */
    public static void insert(AISupplier aiSupplier){
        String sql = "INSERT INTO AISUPPLIER (SUPPLIEROR, SUPPLIERNAME, SUPPLIERABBREVIATION,SUPPLIERTYPE,SUPPLIERSTATUS,SUPPLIERMAIL,SUPPLIERLIFESTATUS,SUPPLIERSOCIALCREDITCODE,SUPPLIERREMARKS,ADDTIME) VALUES (?,?,?,?,?,?,?,?,?, TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'))";

        CommonUtil.excuteUpdate(sql,replaceNullToBlank(aiSupplier.getSupplierOr()),replaceNullToBlank(aiSupplier.getSupplierName()), replaceNullToBlank(aiSupplier.getSupplierAbbreviation()),
                replaceNullToBlank(aiSupplier.getSupplierType()), aiSupplier.getSupplierStatus(), replaceNullToBlank(aiSupplier.getSupplierMail()), replaceNullToBlank(aiSupplier.getSupplierLifeStatus()),
                replaceNullToBlank(aiSupplier.getSupplierSocialCreditCode()), replaceNullToBlank(aiSupplier.getSupplierRemarks()),nowTime());
    }

    /**
     * 将字符串的null 转换成blank
     * @param value
     * @return
     */
    private static String replaceNullToBlank(String value){
        value = value == null ? STRING_BLANK : value;
        return value;
    }

    /**
     * 修改
     * @param aiSupplier
     */
    public static void update(AISupplier aiSupplier){
        String supplierOR = aiSupplier.getSupplierOr();
        String supplierName = aiSupplier.getSupplierName();
        String supplierAbbreviation = aiSupplier.getSupplierAbbreviation();
        String supplierType = aiSupplier.getSupplierType();
        String supplierMail = aiSupplier.getSupplierMail();
        String supplierLifeStatus = aiSupplier.getSupplierLifeStatus();
        String supplierSocialCreditCode = aiSupplier.getSupplierSocialCreditCode();
        String supplierRemarks = aiSupplier.getSupplierRemarks();


        StringBuilder sqlBuilder = new StringBuilder("UPDATE AISUPPLIER SET ADDTIME = TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS') , SUPPLIERSTATUS = ? ");
        if(supplierOR !=null){
            sqlBuilder.append(STRING_COMMA).append("SUPPLIEROR = ").append(single_quotes).append(supplierOR).append(single_quotes);
        }

        if(supplierName !=null){
            sqlBuilder.append(STRING_COMMA).append("SUPPLIERNAME = ").append(single_quotes).append(supplierName).append(single_quotes);
        }


        if(supplierAbbreviation !=null){
            sqlBuilder.append(STRING_COMMA).append("SUPPLIERABBREVIATION = ").append(single_quotes).append(supplierAbbreviation).append(single_quotes);
        }

        if(supplierType !=null){
            sqlBuilder.append(STRING_COMMA).append("SUPPLIERTYPE = ").append(single_quotes).append(supplierType).append(single_quotes);
        }

        if(supplierMail !=null){
            sqlBuilder.append(STRING_COMMA).append("SUPPLIERMAIL = ").append(single_quotes).append(supplierMail).append(single_quotes);
        }

        if(supplierLifeStatus !=null){
            sqlBuilder.append(STRING_COMMA).append("SUPPLIERLIFESTATUS = ").append(single_quotes).append(supplierLifeStatus).append(single_quotes);
        }

        if(supplierSocialCreditCode !=null){
            sqlBuilder.append(STRING_COMMA).append("SUPPLIERSOCIALCREDITCODE = ").append(single_quotes).append(supplierSocialCreditCode).append(single_quotes);
        }

        if(supplierRemarks !=null){
            sqlBuilder.append(STRING_COMMA).append("SUPPLIERREMARKS = ").append(single_quotes).append(supplierRemarks).append(single_quotes);
        }

        sqlBuilder.append("WHERE AISUPPLIERID = TO_NUMBER(?)");

        CommonUtil.excuteUpdate(sqlBuilder.toString(), nowTime(), aiSupplier.getSupplierStatus(), String.valueOf(aiSupplier.getAISupplierId()));
    }


    /**
     * 将Manufacturer对象转成数据库表的AISupplier对象
     * @param aiSupplierId
     * @param manufacturer
     * @return
     */
    public static AISupplier getAISupplierByManufacturer(Long aiSupplierId, Vendor manufacturer) throws WTException {
        AISupplier aiSupplier = new AISupplier();

        if(aiSupplierId == null){

        }else {
            aiSupplier.setAISupplierId(aiSupplierId);
        }
        IBAUtil iba = new IBAUtil(manufacturer);
        aiSupplier.setSupplierOR(CommonUtil.object2Oid(manufacturer));//oid
        aiSupplier.setSupplierName(manufacturer.getName());//名称

        aiSupplier.setSupplierAbbreviation(iba.getIBAValue(PropertiesUtil.getValueByKey("GDP.iba.sup.abbreviation")));//简称

        aiSupplier.setSupplierType(manufacturer.getType());
        aiSupplier.setSupplierStatus(GDP_STATUE_UNSEND);
        aiSupplier.setAddTime(nowTime());
        aiSupplier.setSupplierLifeStatus(manufacturer.getLifeCycleState().getDisplay());

//        WTOrganization org = manufacturer.getOrganization();
//        if(org != null){
//            aiSupplier.setSupplierMail(org.getLocation());
//        }

        aiSupplier.setSupplierMail(iba.getIBAValue(PropertiesUtil.getValueByKey("GDP.iba.sup.mail")));

//        Contact contact = getContact(manufacturer);
//        if(contact !=null){
//            aiSupplier.setSupplierContactName(contact.getName());
//            aiSupplier.setSupplierContactEMail(contact.getEmail());
//            aiSupplier.setSupplierContactPhone(contact.getTelephone());
//        }
        aiSupplier.setSupplierSocialCreditCode(iba.getIBAValue(PropertiesUtil.getValueByKey("GDP.iba.sup.social.code")));
        return aiSupplier;

    }


    /**
     * 获取第一个供应商联系人
     * @param manufacturer
     * @return
     * @throws WTException
     */
    private static Contact getContact(Vendor manufacturer) throws WTException {
        Contact result = null;
        QuerySpec queryspec = new QuerySpec(SupplierContactLink.class);
        queryspec.appendWhere(new SearchCondition(SupplierContactLink.class, "roleAObjectRef.key", "=", PersistenceHelper.getObjectIdentifier(manufacturer)), new int[] { 0 });
        QueryResult qr = PersistenceServerHelper.manager.query(queryspec);
        while (qr.hasMoreElements()) {
            SupplierContactLink link = (SupplierContactLink) qr.nextElement();
            Contact contact = (Contact) link.getRoleBObject();
            if(contact !=null){
                result = contact;
                break;
            }
            System.out.println("contact==========>" + contact.getName() + "||" + contact.getEmail() + "||" + contact.getTelephone() + "||" + contact.getDescription());
        }
        return result;
    }

/*
String state = manufacturer.getState().toString();
WTOrganization org = manufacturer.getOrganization();
String codingSystem = org.getCodingSystem();
String orgIDType = OrganizationServicesHelper.parseCodingSystem().get(codingSystem);
String orgID = OrganizationServicesHelper.getWTOrganizationIdentifierDisplay(org);
String postalAddress = org.getLocation();
String confURL = org.getConferencingURL().toString();
String confID = org.getConferencingIdentifier();
String webSite = org.getWebSite().toString();
System.out.println("state==========>" + state);
System.out.println("orgID==========>" + orgID);
System.out.println("orgIDType==========>" + orgIDType);
System.out.println("postalAddress==========>" + postalAddress);
System.out.println("confURL==========>" + confURL);
System.out.println("confID==========>" + confID);
System.out.println("webSite==========>" + webSite);
QuerySpec queryspec = new QuerySpec(SupplierContactLink.class);
queryspec.appendWhere(new SearchCondition(SupplierContactLink.class, "roleAObjectRef.key", "=", PersistenceHelper.getObjectIdentifier(manufacturer)), new int[] { 0 });
QueryResult qr = PersistenceServerHelper.manager.query(queryspec);
while (qr.hasMoreElements()) {
    SupplierContactLink link = (SupplierContactLink) qr.nextElement();
    Contact contact = (Contact) link.getRoleBObject();
    System.out.println("contact==========>" + contact.getName() + "||" + contact.getEmail() + "||" + contact.getTelephone() + "||" + contact.getDescription());
}
 */




    /**
     * 通过供应商名称 和 GDP发送状态 判断是否存在
     *     AISUPPLIERID          NUMBER PRIMARY KEY,
     *     SUPPLIEROR            VARCHAR2(100),
     *     SUPPLIERNAME          VARCHAR2(30) NOT NULL,
     *     SUPPLIERDISPLAYNAME   VARCHAR2(30) NOT NULL,
     *     SUPPLIERTYPE          VARCHAR2(30),
     *     SUPPLIERSTATUS        VARCHAR2(10) DEFAULT '0' NOT NULL,
     *     ADDTIME               DATE DEFAULT SYSDATE NOT NULL,
     *     SUPPLIERMAIL          VARCHAR2(100),
     *     SUPPLIERCONTACTNAME   VARCHAR2(100),
     *     SUPPLIERCONTACTEMAIL  VARCHAR2(100),
     *     SUPPLIERCONTACTPHONE  VARCHAR2(100),
     * @param supplierName
     * @param supplierStatus
     * @return
     */
    public static AISupplier selectAISupplierBySupplierName(String supplierName, String supplierStatus) throws SQLException {
        AISupplier result = null;
        String sql = "SELECT * FROM AISUPPLIER WHERE SUPPLIERNAME = ? ";
        ResultSet resultSet = CommonUtil.excuteSelect(sql, supplierName);
        while (resultSet.next()) {
            String aiSupplierId = resultSet.getString("AISUPPLIERID");
            if(!StringUtils.isBlank(aiSupplierId)){
                result = getAISupplierByResultSet(resultSet);
            }
        }

        return result;
    }


    /**
     * 将查询结果映射到对象中
     * @param resultSet
     * @return
     * @throws SQLException
     */
    private static AISupplier getAISupplierByResultSet(ResultSet resultSet) throws SQLException {
        AISupplier aiSupplier = new AISupplier();
        aiSupplier.setAISupplierId(Long.parseLong(resultSet.getString("AISUPPLIERID")));
        aiSupplier.setSupplierOR(resultSet.getString("SUPPLIEROR"));
        aiSupplier.setSupplierName(resultSet.getString("SUPPLIERNAME"));

        aiSupplier.setSupplierAbbreviation(resultSet.getString("SUPPLIERABBREVIATION"));
        aiSupplier.setSupplierType(resultSet.getString("SUPPLIERTYPE"));
        aiSupplier.setSupplierStatus(resultSet.getString("SUPPLIERSTATUS"));
        aiSupplier.setAddTime(resultSet.getString("ADDTIME"));
        aiSupplier.setSupplierMail(resultSet.getString("SUPPLIERMAIL"));
        aiSupplier.setSupplierLifeStatus(resultSet.getString("SUPPLIERLIFESTATUS"));
        aiSupplier.setSupplierSocialCreditCode(resultSet.getString("SUPPLIERSOCIALCREDITCODE"));
        aiSupplier.setSupplierRemarks(resultSet.getString("SUPPLIERREMARKS"));
        return aiSupplier;
    }
    private static String nowTime(){
        // 获取当前时间
        LocalDateTime now = LocalDateTime.now();

        // 在当前时间上加8小时
        LocalDateTime nowPlus8Hours = now.plusHours(8);

        // 定义日期时间格式，匹配 Oracle 的 DATE 字段格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // 格式化当前时间
        return nowPlus8Hours.format(formatter);
    }


    /**
     * 同步完成后修改状态
     * @param list
     * @param respJson
     * @return
     */
    public static ResponseVo  updateAISupplierStatus(List<AISupplier> list, String respJson){
        ResponseVo responseVo = new ResponseVo();
        Transaction trx = null;
        try {
            trx= new Transaction();
            trx.start();
            HashMap<String, Object> map = objectMapper.readValue(respJson, new TypeReference<HashMap<String, Object>>() {});

            Integer code = (Integer) map.get("code");
            if(code == 200){
                responseVo.setCode(code);
                responseVo.setMsg("发送成功");
                String sql = "UPDATE AISUPPLIER SET SUPPLIERSTATUS = ? WHERE AISUPPLIERID = TO_NUMBER(?)";
                for (AISupplier aiSupplier : list) {
                    Long aiSupplierId = aiSupplier.getAISupplierId();
                    CommonUtil.excuteUpdate(sql, GDP_STATUE_SENDED, String.valueOf(aiSupplierId));
                }
            }

            trx.commit();
            trx = null;
        }catch (Exception e){
            e.printStackTrace();
        } finally {
            if(trx!=null){
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }

        return responseVo;
    }







    /**
     * 通过Id获取待发送供应商集合
     * @param ids
     * @return
     * @throws SQLException
     */
    public static List<AISupplier> selectAISupplierByIds(List<Long> ids) throws SQLException {
        List<AISupplier> result = new ArrayList<>();
        String sql = "SELECT * FROM AISUPPLIER WHERE AISUPPLIERID = TO_NUMBER(?) ";
        for (Long id : ids) {
            ResultSet resultSet = CommonUtil.excuteSelect(sql, String.valueOf(id));
            while (resultSet.next()) {
                String aiSupplierId = resultSet.getString("AISUPPLIERID");
                if(!StringUtils.isBlank(aiSupplierId)){
                    result.add(getAISupplierByResultSet(resultSet));
                }
            }
        }
        return result;
    }

    public static Date nowTimeToDate() {
        // 获取当前时间
        LocalDateTime now = LocalDateTime.now();

        // 在当前时间上加8小时
//        LocalDateTime nowPlus8Hours = now.plusHours(8);

        // 将 LocalDateTime 转换为 java.util.Date
        return Date.from(now.atZone(ZoneId.systemDefault()).toInstant());
    }


    /**
     * 根据当前租户获取GDP管理端  当前可用的供应商集合json
     * @return
     */
    public static String getGDPSupplierJson(){
        // 租户ID
        long tenant = Long.parseLong(PropertiesUtil.getValueByKey("GDP.deptId"));
        String supplierJson="";
        try {
            String loginGDPToken = CommonUtil.loginGDP();
            String respJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("GDP.tenant.supplier.url")+tenant, loginGDPToken, null, "GET");
//            System.out.println("respJson:"+respJson);
            HashMap<String, Object> map = objectMapper.readValue(respJson, new TypeReference<HashMap<String, Object>>() {});
            Integer code = (Integer) map.get("code");
            if(code == 200){
                List<SysSupplier> suppliers = (List<SysSupplier>) map.get("data");
                supplierJson = objectMapper.writeValueAsString(suppliers);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return supplierJson;
    }








}
