package ext.alphai.GDP.service;

import com.ptc.wvs.common.ui.VisualizationHelper;
import ext.alphai.GDP.util.CommonUtil;
import ext.alphai.GDP.vo.DocDrawVo;
import ext.alphai.GDP.vo.DocMasterVo;
import ext.alphai.GDP.vo.DocVo;
import ext.alphai.GDP.vo.SyncReqVo;
import org.apache.commons.io.FilenameUtils;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.representation.Representation;
import wt.util.WTException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.beans.PropertyVetoException;
import java.sql.Timestamp;

import java.util.*;

/**
 * 文档图纸同步相关服务类  GDP调用windchill
 */
public class SyncDocDrawService {

    public static Long deptId=null;

    /**
     * 同步指定或全部文档图纸信息
     * @param syncReqVo
     * @return
     */
    public static List<DocMasterVo> syncDocDrawRespVoList(SyncReqVo syncReqVo) throws PropertyVetoException, WTException {
        deptId = syncReqVo.getDeptId();
        System.out.println("------同步请求发送时间："+syncReqVo.getRequestDate());
        System.out.println("------同步请求发送用户编号："+syncReqVo.getUserId());
        List<DocMasterVo> docMasters = syncReqVo.getDocMasters();

        // 获取全部EPMDocMaster 集合
        List<EPMDocumentMaster> allEPMMaster = getAllMaster(EPMDocumentMaster.class);
        return getDocMasterVoLists(docMasters, allEPMMaster);
    }


    private static List<DocMasterVo> getDocMasterVoLists(List<DocMasterVo> docMasters, List<EPMDocumentMaster> epmMasterLists) throws PropertyVetoException, WTException {
        // ruoyi里 or为key
        Map<String, DocMasterVo> ruoyiDocMasterMap = DocMasterVo.getFieldValuesAsMap(docMasters, "docMasterOr", String.class);

        // windchill 里OR为key
        Map<String, EPMDocumentMaster> wcEPMMasterMap = new HashMap<>();

        for (EPMDocumentMaster epmDocumentMaster : epmMasterLists) {
            wcEPMMasterMap.put(CommonUtil.object2Oid(epmDocumentMaster), epmDocumentMaster);
        }

        // ruoyi中master的OR
        Set<String> ruoyiMasterORs = ruoyiDocMasterMap.keySet();
        // windchill 里所有master的OR
        Set<String> wcEPMMasterORs = wcEPMMasterMap.keySet();
        // 交集OR
        Set<String> commonAndUpdate = findCommonAndUpdate(ruoyiMasterORs, wcEPMMasterORs);

        // 更新


        // 循环全部ruoyi中的Master
        for (DocMasterVo docMaster : docMasters) {
            List<DocVo> docs = docMaster.getDocs();
            removeDocMasterVo(docMaster, ruoyiMasterORs);
        }




        // 插入windchill新增的master
        return insertDocMasterVo(docMasters, wcEPMMasterORs, wcEPMMasterMap);
    }

    /**
     *
     * @param docMasters ruoyi里有的
     * @param wcEPMMasterORs windchill 里有的 但ruoyi里没有的master
     * @return
     */
    private static List<DocMasterVo> insertDocMasterVo(List<DocMasterVo> docMasters, Set<String> wcEPMMasterORs, Map<String, EPMDocumentMaster> wcEPMMasterMap) throws PropertyVetoException, WTException {
        for (String key : wcEPMMasterORs) {
            EPMDocumentMaster master = wcEPMMasterMap.get(key);
            DocMasterVo docMasterVo = new DocMasterVo();
            docMasterVo.setDocMasterOr(CommonUtil.object2Oid(master));
            docMasterVo.setDocName(master.getCADName());
            docMasterVo.setDocNumber(master.getNumber());
            docMasterVo.setExist(true);
            docMasterVo.setDeptId(deptId);
            docMasterVo.setUpdateTime(syncTimestamp(master.getModifyTimestamp()));
            // 获取新epm master 下面的epmDoc 信息
            docMasterVo.setDocs(getDocVoByEPMDocumentMaster(master));

            docMasters.add(docMasterVo);
        }

        return docMasters;
    }


    /**
     *
     * @param master
     * @return
     */
    private static List<DocVo> getDocVoByEPMDocumentMaster(EPMDocumentMaster master) throws PropertyVetoException, WTException {
        List<DocVo> vos = new ArrayList<>();
        List<EPMDocument> documents = CommonUtil.getEPMDocumentByMaster(master);

        for (EPMDocument doc : documents) {
            DocVo vo = new DocVo();
            vo.setDocOr(CommonUtil.object2Oid(doc));
            vo.setExist(true);
            vo.setReleaseTime(syncTimestamp(doc.getModifyTimestamp()));
            vo.setVersionIdentifier(doc.getVersionIdentifier().getValue());
            vo.setIterationIdentifier(doc.getIterationIdentifier().getValue());
            // 获取默认表示法中附件
            vo.setDocDraws(getDocDrawVoByEPMDoc(doc));
            vos.add(vo);
        }
        return vos;
    }


    private static List<DocDrawVo> getDocDrawVoByEPMDoc(EPMDocument document) throws PropertyVetoException, WTException {
        List<DocDrawVo> vos = new ArrayList<>();
        List<ApplicationData> dataList = getEPMApplicationData(document);
        for (ApplicationData data : dataList) {
            DocDrawVo vo = new DocDrawVo();
            String fileName = data.getFileName();
            vo.setDrawName(fileName);
            vo.setExist(true);
            vo.setPersonResponsible(data.getModifiedBy().getDisplayName());
            vo.setPictureFormat(FilenameUtils.getExtension(fileName));
            vo.setSourceFormat("DRW");
            vos.add(vo);
        }
        return vos;
    }



    /**
     * 只有ruoyi中有的master
     * @param docMaster
     * @param ruoyiMasterORs
     * @return
     */
    private static DocMasterVo removeDocMasterVo(DocMasterVo docMaster, Set<String> ruoyiMasterORs){
        String docMasterOr = docMaster.getDocMasterOr();
        for (String ruoyiMasterOR : ruoyiMasterORs) {
            // 说明该Master 在ruoyi里有但在 windchill里没有
            if(docMasterOr.equals(ruoyiMasterOR)){
                // 标识后标识这个对象在ruoyi里是需要删除的
                docMaster.setExist(false);
                docMaster.setDocs(null);
            }
        }
        return docMaster;
    }



    private static List<DocVo> getDocVoLists(List<DocVo> docs){
        for (DocVo doc : docs) {
            List<DocDrawVo> docDraws = doc.getDocDraws();
        }
        return docs;
    }



    private static List<DocDrawVo> getDocDrawVoLists(List<DocDrawVo> docDraws){

        return docDraws;
    }


    /**
     * 获取系统所有EPM
     * @return
     */
    public static <T> List<T> getAllMaster(Class<T> targetType) {
        List<T> result = new ArrayList<>();
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(targetType);
            qr = PersistenceHelper.manager.find(qs);

            // 如果 QueryResult 为空则不执行后续代码
            if (qr != null) {
                while (qr.hasMoreElements()) {
                    try {
                        // 通过类型转换获取元素
                        T element = (T) qr.nextElement();
                        result.add(element);
                    } catch (ClassCastException e) {
                        // 记录类型转换异常
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
            // 记录错误日志
            e.printStackTrace();
        }

        return result;
    }



//    /**
//     * windchill数据库中时区采用的是UTC 需要加8小时才是中国时间 为对照上ruoyi数据库的东八区时间
//     * @param timestamp
//     * @return
//     */
//    public static Timestamp syncTimestamp(Timestamp timestamp){
//        Instant instant = timestamp.toInstant();
//
//        // 在时间上加 8 小时
//        Instant newInstant = instant.plus(Duration.ofHours(8));
//
//        // 将新的 Instant 转换回 Timestamp
//        return Timestamp.from(newInstant);
//    }

    /**
     * 排除重复 将相同的OR收集起来  传入的集合中只剩自己独有的
     * @param firstList
     * @param secondList
     * @return
     */
    public static Set<String> findCommonAndUpdate(Collection<String> firstList, Collection<String> secondList) {
        // 找到交集
        Set<String> common = new HashSet<>(firstList);
        common.retainAll(secondList);

        // 更新两个集合，移除交集中的元素
        firstList.removeAll(common);
        secondList.removeAll(common);

        // 返回交集
        return common;
    }





    /**
     * 获取EPM文档默认表示法的附件
     * @param epm
     * @return
     */
    public static List<ApplicationData> getEPMApplicationData(EPMDocument epm) throws PropertyVetoException, WTException {
        List<ApplicationData> dataLists = new ArrayList<ApplicationData>();
        VisualizationHelper vizHelper = new VisualizationHelper();
        QueryResult result = vizHelper.getRepresentations(epm);
        Representation rep = null;
        ContentHolder ch = null;
        Vector<?> appDatas = null;
        ApplicationData appData = null;

        while (result.hasMoreElements()) {
            rep = (Representation) result.nextElement();
            ch = ContentHelper.service.getContents(rep);
            String name = rep.getName();

            Boolean defaultRepresentation = rep.getDefaultRepresentation();
            //必须从默认表示法中获取pdf
            if(!defaultRepresentation){
                continue;
            }
            appDatas = ContentHelper.getContentListAll(ch);
            for (int i = 0; i < appDatas.size(); i++) {
                appData = (ApplicationData) appDatas.get(i);
                ContentRoleType role = appData.getRole();
                // 检查表示法中是否包含pdf
                if ((role.equals(ContentRoleType.ADDITIONAL_FILES) || role.equals(ContentRoleType.SECONDARY))) {
                    dataLists.add(appData);
                }
            }
        }

        return dataLists;
    }



    public static Date syncTimestamp(Timestamp timestamp) {
        // 将 Timestamp 转换为 Instant
        Instant instant = timestamp.toInstant();

        // 在时间上加 8 小时
        Instant newInstant = instant.plus(Duration.ofHours(8));

        // 将 Instant 转换为 LocalDateTime
        LocalDateTime localDateTime = LocalDateTime.ofInstant(newInstant, ZoneId.systemDefault());

        // 将 LocalDateTime 转换为 java.util.Date
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }
}
