package ext.alphai.GDP.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.GDP.domain.AISupplier;
import ext.alphai.GDP.domain.ResponseVo;
import ext.alphai.GDP.service.AISupplierService;
import ext.alphai.GDP.util.CommonUtil;
import ext.alphai.GDP.util.PropertiesUtil;
import ext.alphai.GDP.vo.SyncSupplierVo;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

/**
 * 供应商相关控制器
 */
@Controller
@RequestMapping({ "/syncSupplier" })
public class SyncSupplierController {
    static final ObjectMapper objectMapper = new ObjectMapper();


    /**
     * 查询待发送供应商集合
     * @param supplierName
     * @param supplierStatus
     * @param request
     * @param response
     */
    @RequestMapping(value = "/getAISupplierLists", method = RequestMethod.GET)
    public void getAISupplierLists(@RequestParam String supplierName , @RequestParam String supplierStatus, HttpServletRequest request,
                                   HttpServletResponse response) throws IOException {

        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo responseVo = null;
        try {
            List<AISupplier> aiSuppliers = AISupplierService.selectByName(supplierName, supplierStatus);
            responseVo = new ResponseVo(200, "ok", aiSuppliers);
        } catch (SQLException e) {
            e.printStackTrace();
            responseVo = new ResponseVo(500, "false", null);
        }
        String respJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response, respJson);

    }


    /**
     * 修改供应商信息
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/updateSupplierInfo", method = RequestMethod.POST)
    public void updateSupplierInfo(@RequestParam String json , HttpServletRequest request,
                                   HttpServletResponse response) throws IOException {

        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo responseVo = null;
        try {
            AISupplier aiSupplier = objectMapper.readValue(json, AISupplier.class);

            AISupplierService.update(aiSupplier);
            responseVo = new ResponseVo(200, "修改成功", null);
        } catch (Exception e) {
            e.printStackTrace();
            responseVo = new ResponseVo(500, "修改失败", null);
        }
        String respJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response, respJson);

    }













    /**
     * 删除
     * @param json
     * @param request
     * @param response
     * @throws IOException
     * @throws SQLException
     * @throws WTException
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public void deleteAIDrawingByIds(@RequestBody String json , HttpServletRequest request,
                                     HttpServletResponse response) throws IOException, SQLException, WTException {


        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        List<Long> drawings = objectMapper.readValue(json, new TypeReference<List<Long>>(){});
        // 发送
        ResponseVo responseVo = null;
        try {
            AISupplierService.delete(drawings);
            responseVo = new ResponseVo(200, "success", "");
        } catch (Exception e) {
            responseVo = new ResponseVo(500, "false", "");
            e.printStackTrace();
        }
        String respJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response, respJson);
    }


    /**
     *  发送供应商到GDP
     * @param json
     * @param request
     * @param response
     * @throws IOException
     * @throws SQLException
     * @throws WTException
     */
    @RequestMapping(value = "/sendAISupplierByIds", method = RequestMethod.POST)
    public void sendAISupplierByIds(@RequestBody String json , HttpServletRequest request,
                                   HttpServletResponse response) throws IOException, SQLException, WTException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        List<Long> supplierIds = objectMapper.readValue(json, new TypeReference<List<Long>>(){});
        List<AISupplier> aiSuppliers = AISupplierService.selectAISupplierByIds(supplierIds);

        // 是否需要判断必填供应商联系方式？ 暂时不需要 直接发送
        SyncSupplierVo syncSupplierVo = new SyncSupplierVo(Long.parseLong(PropertiesUtil.getValueByKey("GDP.deptId")), aiSuppliers, AISupplierService.nowTimeToDate());

        String reqJson = objectMapper.writeValueAsString(syncSupplierVo);
        ResponseVo responseVo = null;
        // 登录
        try {
            String loginGDPToken = CommonUtil.loginGDP();
            System.out.println("GDP同步供应商的请求json:"+reqJson);
            String respJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("GDP.supplier.url"), loginGDPToken, reqJson, "POST");
            responseVo = AISupplierService.updateAISupplierStatus(aiSuppliers, respJson);

        } catch (Exception e) {
            e.printStackTrace();
            responseVo.setCode(500);
            responseVo.setMsg("服务器内部异常请联系管理员");
        }

        String respJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response, respJson);
    }


    public void outResponse(HttpServletResponse response, String json) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }
}
