package ext.alphai.GDP.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import ext.alphai.GDP.domain.AIDrawing;
import ext.alphai.GDP.domain.AIDrawingReq;
import ext.alphai.GDP.domain.AIDrawingResp;
import ext.alphai.GDP.domain.ResponseVo;
import ext.alphai.GDP.service.AIDrawingService;
import ext.alphai.GDP.service.SyncDocDrawService;
import ext.alphai.GDP.util.CommonUtil;
import ext.alphai.GDP.util.PropertiesUtil;
import ext.alphai.GDP.vo.DocMasterVo;
import ext.alphai.GDP.vo.GDPDownloadDrawVo;
import ext.alphai.GDP.vo.SyncReqVo;
import org.apache.commons.codec.binary.Base64;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.beans.PropertyVetoException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.List;

/**
 * 同步文档图纸
 */

@Controller
@RequestMapping({ "/syncDocDraw" })
public class SyncDocDrawController {


    static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 获取所有待更新的文档信息
     * @param json
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/syncDocDrawReq", method = RequestMethod.POST)
    public void syncDocDrawReq(@RequestBody String json , HttpServletRequest request,
                                 HttpServletResponse response) throws IOException, PropertyVetoException, WTException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("接收文档信息同步请求接口");

//        SyncReqVo syncReqVo = objectMapper.readValue(json, new TypeReference<SyncReqVo>(){});
        SyncReqVo syncReqVo = objectMapper.readValue(json,SyncReqVo.class);
        List<DocMasterVo> syncDocDrawRespVos = SyncDocDrawService.syncDocDrawRespVoList(syncReqVo);
    }


    @RequestMapping(value = "/getAIDrawingLists", method = RequestMethod.POST)
    public void getAIDrawingLists(@RequestBody String json , HttpServletRequest request,
                               HttpServletResponse response) throws IOException, SQLException, WTException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        AIDrawingReq aiDrawingReq = objectMapper.readValue(json, AIDrawingReq.class);

        // 查询数据库 获取相关信息
        List<AIDrawingResp> aiDrawingRespList = AIDrawingService.getAIDrawingRespList(aiDrawingReq);

        ResponseVo responseVo = new ResponseVo(200, "success", aiDrawingRespList);

        String respJson = objectMapper.writeValueAsString(responseVo);

        outResponse(response, respJson);
    }

    @RequestMapping(value = "/sendAIDrawingByIds", method = RequestMethod.POST)
    public void sendAIDrawingByIds(@RequestBody String json , HttpServletRequest request,
                                  HttpServletResponse response) throws IOException, SQLException, WTException {


        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        List<Long> drawings = objectMapper.readValue(json, new TypeReference<List<Long>>(){});

        List<AIDrawing> aiDrawingsByIds = AIDrawingService.getAIDrawingsByIds(drawings);

        ResponseVo responseVo =null;
        // 发送
        try {
            SyncReqVo syncReqVo = AIDrawingService.sendAIDrawingToGDP(aiDrawingsByIds);

            String reqJson = objectMapper.writeValueAsString(syncReqVo);

            // 登录
            String loginGDPToken = CommonUtil.loginGDP();
//            System.out.println("GDP同步数据库的请求json:"+reqJson);
            String respJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("GDP.draw.url"), loginGDPToken, reqJson, "POST");
            responseVo = AIDrawingService.updateAIDrawingStatus(aiDrawingsByIds, respJson);

        } catch (Exception e) {
            responseVo = new ResponseVo(500, "false", "发送失败稍后重试");
            e.printStackTrace();
        }
        String respJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response, respJson);
    }


    /**
     * 删除
     * @param json
     * @param request
     * @param response
     * @throws IOException
     * @throws SQLException
     * @throws WTException
     */
    @RequestMapping(value = "/deleteAIDrawingByIds", method = RequestMethod.POST)
    public void deleteAIDrawingByIds(@RequestBody String json , HttpServletRequest request,
                                   HttpServletResponse response) throws IOException, SQLException, WTException {


        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        List<Long> drawings = objectMapper.readValue(json, new TypeReference<List<Long>>(){});
        // 发送
        ResponseVo responseVo = null;
        try {
            AIDrawingService.deleteAIDrawing(drawings);
            responseVo = new ResponseVo(200, "success", "");
        } catch (Exception e) {
            responseVo = new ResponseVo(500, "false", "");
            e.printStackTrace();
        }
        String respJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response, respJson);
    }


    @RequestMapping(value = "/uploadDraw", method = RequestMethod.POST)
    public void uploadDraw(@RequestBody String json , HttpServletRequest request,
                                     HttpServletResponse response) throws IOException, SQLException, WTException {
        GDPDownloadDrawVo downloadDrawVo = objectMapper.readValue(json, GDPDownloadDrawVo.class);
        ResponseVo vo = AIDrawingService.uploadDraw(downloadDrawVo);
        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response, respJson);
    }


    @RequestMapping(value = "/QRCode", method = RequestMethod.GET )
    public void getQRCode(@RequestParam String content, HttpServletRequest request,
                          HttpServletResponse response)throws Exception {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("获取二维码");
        // 生成二维码  要求扫描二维码能显示 一句holloworld
        // 生成二维码的内容
//        String content = "Hello, World!";

        try {
            // 调用二维码生成方法
            String base64QRCode = generateQRCode(content);
            // 返回二维码图片的Base64编码
            response.getWriter().write("{\"qrCode\":\"" + base64QRCode + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("{\"error\":\"生成二维码失败\"}");
        }
    }



    // 生成二维码并返回Base64编码
    private String generateQRCode(String content) throws Exception {
        // 设置二维码的参数
        Hashtable<EncodeHintType, Object> hints = new Hashtable<>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");

        // 生成二维码的BitMatrix
        MultiFormatWriter writer = new MultiFormatWriter();
        BitMatrix matrix = writer.encode(content, BarcodeFormat.QR_CODE, 200, 200, hints);

        // 转换为BufferedImage
        BufferedImage image = toBufferedImage(matrix);

        // 将图片转换为Base64
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        javax.imageio.ImageIO.write(image, "PNG", baos);
        byte[] bytes = baos.toByteArray();
        return "data:image/png;base64," + Base64.encodeBase64String(bytes);
    }

    // 将BitMatrix转换为BufferedImage
    private BufferedImage toBufferedImage(BitMatrix matrix) {
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        image.createGraphics();

        Graphics2D graphics = (Graphics2D) image.getGraphics();
        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, width, height);
        graphics.setColor(Color.BLACK);

        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                if (matrix.get(i, j)) {
                    graphics.fillRect(i, j, 1, 1);
                }
            }
        }
        return image;
    }


    public void outResponse(HttpServletResponse response, String json) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }

}
