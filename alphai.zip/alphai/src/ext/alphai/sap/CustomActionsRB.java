package ext.alphai.sap;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.sap.CustomActionsRB")
public class CustomActionsRB extends WTListResourceBundle {

    @RBEntry("Show Send Result")
    public static final String PRIVATE_CONSTANT_0 ="部件到匈牙利SAP发送结果";


    @RBEntry("MBOM Part Error Factory")
    public static final String PRIVATE_CONSTANT_01 ="MBOM相关部件工厂错误";

    @RBEntry("MBOM Send Part Error")
    public static final String PRIVATE_CONSTANT_001 ="MBOM发送相关部件异常信息";


    @RBEntry("Show Send MBOM Result")
    public static final String PRIVATE_CONSTANT_00 ="MBOM到匈牙利SAP发送结果";

    @RBEntry("Send Part To Hu SAP")
    public static final String PRIVATE_CONSTANT_1 ="huSendToSAP.sendPart.description";

    @RBEntry("Send Part To Hu SAP")
    public static final String PRIVATE_CONSTANT_2 ="huSendToSAP.sendPart.tooltip";


    @RBEntry("Send Part Show Result")
    public static final String PRIVATE_CONSTANT_3 ="huSendToSAP.sendPartResult.description";

    @RBEntry("Send Part Show Result")
    public static final String PRIVATE_CONSTANT_4 ="huSendToSAP.sendPartResult.tooltip";



    @RBEntry("Send MBOM To Hu SAP")
    public static final String PRIVATE_CONSTANT_5 ="huSendToSAP.sendMBOM.description";

    @RBEntry("Send MBOM To Hu SAP")
    public static final String PRIVATE_CONSTANT_6 ="huSendToSAP.sendMBOM.tooltip";



    @RBEntry("Send MBOM Show Result")
    public static final String PRIVATE_CONSTANT_7 ="huSendToSAP.sendMBOMResult.description";

    @RBEntry("Send MBOM Show Result")
    public static final String PRIVATE_CONSTANT_8 ="huSendToSAP.sendMBOMResult.tooltip";



    @RBEntry("Send MBOM Check Part Factory")
    public static final String PRIVATE_CONSTANT_9 ="huSendToSAP.sendMBOMCheckFac.description";

    @RBEntry("Send MBOM Check Part Factory")
    public static final String PRIVATE_CONSTANT_10 ="huSendToSAP.sendMBOMCheckFac.tooltip";


    @RBEntry("Send MBOM Part Result")
    public static final String PRIVATE_CONSTANT_11 ="huSendToSAP.sendMBOMPart.description";

    @RBEntry("Send MBOM Part Result")
    public static final String PRIVATE_CONSTANT_12 ="huSendToSAP.sendMBOMPart.tooltip";



    @RBEntry("Downhill Part Send To HU SAP Report Forms")
    public static final String PRIVATE_CONSTANT_13 ="huSendToSAP.downhillResult.description";

    @RBEntry("Downhill Part Send To HU SAP Report Forms")
    public static final String PRIVATE_CONSTANT_14 ="huSendToSAP.downhillResult.tooltip";



    @RBEntry("Repeat False EOP Part To HU SAP")
    public static final String PRIVATE_CONSTANT_15 ="huSendToSAP.EOPRepeat.description";

    @RBEntry("Repeat False EOP Part To HU SAP")
    public static final String PRIVATE_CONSTANT_16 ="huSendToSAP.EOPRepeat.tooltip";

    @RBEntry("attribute.png")
    public static final String PRIVATE_CONSTANT_17 ="huSendToSAP.EOPRepeat.icon";



    @RBEntry("Repeat False EOP Part To HU SAP")
    public static final String PRIVATE_CONSTANT_18 ="huSendToSAP.EOLRepeat.description";

    @RBEntry("Repeat False EOP Part To HU SAP")
    public static final String PRIVATE_CONSTANT_19 ="huSendToSAP.EOLRepeat.tooltip";

    @RBEntry("attribute.png")
    public static final String PRIVATE_CONSTANT_20 ="huSendToSAP.EOLRepeat.icon";



    @RBEntry("EOP Part Send To HU SAP Report Forms")
    public static final String EOPPartSendToHUSAPReportForms ="EOPPartSendToHUSAPReportForms";


    @RBEntry("EOL Part Send To HU SAP Report Forms")
    public static final String EOLPartSendToHUSAPReportForms ="EOLPartSendToHUSAPReportForms";

    @RBEntry("Are you sure you want to manually send the downhill start material to Hungary SAP?")
    public static final String HandMoveEOPToHUSAP = "HandMoveEOPToHUSAP";
    @RBEntry("Are you sure you want to manually send the downhill end material to Hungary SAP?")
    public static final String HandMoveEOLToHUSAP = "HandMoveEOLToHUSAP";

}
