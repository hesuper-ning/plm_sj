package ext.alphai.sap;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.alphai.sap.util.ChangeSession;
import org.apache.commons.lang3.StringUtils;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.org.WTGroup;
import wt.org.WTUser;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;

public class HuSendGroupFilter extends DefaultSimpleValidationFilter {
    @Override
    public UIValidationStatus preValidateAction(UIValidationKey uiValidationKey, UIValidationCriteria uiValidationCriteria) {
        UIValidationStatus status = UIValidationStatus.HIDDEN;

        try {
            // 获取当前登录用户
            WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
            // 判断当前用户是否属于采购领导组
            boolean inGroup = getGroupHaveUser(Config.get("sap.Hu.send.group"), user);
            if(inGroup) {
                status = UIValidationStatus.ENABLED;
            }
        }catch (Exception e) {
            e.printStackTrace();
            status = UIValidationStatus.HIDDEN;
        }
        return status;


    }



    public static boolean getGroupHaveUser(String groupName, WTUser user){
        boolean result = false;
        String[] groups = groupName.split(",");

        try {
            for (String group : groups) {
                WTGroup wtGroup = queryGroupByName(group);
                if(wtGroup !=null){
                    result = wtGroup.isMember(user);
                    if(result){
                        return result;
                    }
                }
            }

        } catch (WTException e){
            e.printStackTrace();
            result = false;
        }

        return result;
    }


    /**
     * 根据组名获取组对象
     *
     * @param String
     * @return WTGroup
     */
    public static WTGroup queryGroupByName(String groupName) {
        try {
            ChangeSession.administratorSession();
            if (StringUtils.isBlank(groupName)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(WTGroup.class);
            SearchCondition sc = new SearchCondition(WTGroup.class, WTGroup.NAME, SearchCondition.EQUAL,
                    groupName.trim());
            int[] index = { 0 };
            qs.appendWhere(sc, index);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            while (qr.hasMoreElements()) {
                WTGroup group = (WTGroup) qr.nextElement();
                return group;
            }
        } catch (WTException e) {
            e.printStackTrace();
        } finally {
            ChangeSession.goPreviousSession();
        }
        return null;
    }
}
