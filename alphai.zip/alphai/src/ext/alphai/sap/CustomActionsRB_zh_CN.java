package ext.alphai.sap;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.sap.CustomActionsRB_zh_CN")
public class CustomActionsRB_zh_CN extends WTListResourceBundle {

    @RBEntry("部件到匈牙利SAP发送结果")
    public static final String PRIVATE_CONSTANT_0 ="部件到匈牙利SAP发送结果";

    @RBEntry("MBOM相关部件工厂异常信息")
    public static final String PRIVATE_CONSTANT_01 ="MBOM相关部件工厂错误";

    @RBEntry("MBOM发送相关部件异常信息")
    public static final String PRIVATE_CONSTANT_001 ="MBOM发送相关部件异常信息";



    @RBEntry("MBOM到匈牙利SAP发送结果")
    public static final String PRIVATE_CONSTANT_00 ="MBOM到匈牙利SAP发送结果";

    @RBEntry("发送部件到HU SAP")
    public static final String PRIVATE_CONSTANT_1 = "huSendToSAP.sendPart.description";

    @RBEntry("发送部件到HU SAP")
    public static final String PRIVATE_CONSTANT_2 = "huSendToSAP.sendPart.tooltip";


    @RBEntry("发送部件结果展示")
    public static final String PRIVATE_CONSTANT_3 ="huSendToSAP.sendPartResult.description";

    @RBEntry("发送部件结果展示")
    public static final String PRIVATE_CONSTANT_4 ="huSendToSAP.sendPartResult.tooltip";



    @RBEntry("发送BOM到HU SAP")
    public static final String PRIVATE_CONSTANT_5 ="huSendToSAP.sendMBOM.description";

    @RBEntry("发送BOM到HU SAP")
    public static final String PRIVATE_CONSTANT_6 ="huSendToSAP.sendMBOM.tooltip";



    @RBEntry("发送MBOM结果展示")
    public static final String PRIVATE_CONSTANT_7 ="huSendToSAP.sendMBOMResult.description";

    @RBEntry("发送MBOM结果展示")
    public static final String PRIVATE_CONSTANT_8 ="huSendToSAP.sendMBOMResult.tooltip";


    @RBEntry("MBOM 相关部件工厂异常反馈")
    public static final String PRIVATE_CONSTANT_9 ="huSendToSAP.sendMBOMCheckFac.description";

    @RBEntry("MBOM 相关部件工厂异常反馈")
    public static final String PRIVATE_CONSTANT_10 ="huSendToSAP.sendMBOMCheckFac.tooltip";



    @RBEntry("MBOM 发送相关部件返回信息")
    public static final String PRIVATE_CONSTANT_11 ="huSendToSAP.sendMBOMPart.description";

    @RBEntry("MBOM 发送相关部件返回信息")
    public static final String PRIVATE_CONSTANT_12 ="huSendToSAP.sendMBOMPart.tooltip";
    @RBEntry("下坡物料发送匈牙利SAP报表")
    public static final String PRIVATE_CONSTANT_13 ="huSendToSAP.downhillResult.description";

    @RBEntry("下坡物料发送匈牙利SAP报表")
    public static final String PRIVATE_CONSTANT_14 ="huSendToSAP.downhillResult.tooltip";


    @RBEntry("重发EOP")
    public static final String PRIVATE_CONSTANT_15 ="huSendToSAP.EOPRepeat.description";

    @RBEntry("重发下坡开始物料")
    public static final String PRIVATE_CONSTANT_16 ="huSendToSAP.EOPRepeat.tooltip";

    @RBEntry("attribute.png")
    public static final String PRIVATE_CONSTANT_17 ="huSendToSAP.EOPRepeat.icon";

    @RBEntry("重发EOL")
    public static final String PRIVATE_CONSTANT_18 ="huSendToSAP.EOLRepeat.description";

    @RBEntry("重发下坡结束物料")
    public static final String PRIVATE_CONSTANT_19 ="huSendToSAP.EOLRepeat.tooltip";

    @RBEntry("attribute.png")
    public static final String PRIVATE_CONSTANT_20 ="huSendToSAP.EOLRepeat.icon";

    @RBEntry("下坡开始物料")
    public static final String EOPPartSendToHUSAPReportForms ="EOPPartSendToHUSAPReportForms";
    @RBEntry("下坡结束物料")
    public static final String EOLPartSendToHUSAPReportForms ="EOLPartSendToHUSAPReportForms";

    @RBEntry("确认手动发送下坡开始物料到匈牙利SAP?")
    public static final String HandMoveEOPToHUSAP = "HandMoveEOPToHUSAP";
    @RBEntry("确认手动发送下坡结束物料到匈牙利SAP?")
    public static final String HandMoveEOLToHUSAP = "HandMoveEOLToHUSAP";
}
