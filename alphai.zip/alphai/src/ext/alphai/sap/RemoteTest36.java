package ext.alphai.sap;

import com.fasterxml.jackson.core.JsonProcessingException;


import com.ptc.core.lwc.client.util.EnumerationConstraintHelper;
import com.ptc.core.lwc.common.view.EnumerationDefinitionReadView;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.server.LWCMasterEnumerationDefinition;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import ext.alphai.sap.downhill.timeQueue.UpdateDownhillPartWorker;
import ext.alphai.sap.util.CommonUtil;
import ext.alphai.sap.util.IBAUtil;
import ext.alphai.sap.util.PartUtil;
import ext.alphai.sap.util.PersistenceUtil;
import wt.epm.EPMDocumentMaster;
import wt.fc.ObjectIdentifier;
import wt.fc.PersistenceHelper;
import wt.fc.WTObject;
import wt.inf.library.WTLibrary;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;

import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTRuntimeException;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Map;


/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * 
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * 
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * 
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * 
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 * 
 * @author dz
 *
 */
public class RemoteTest36 implements RemoteAccess, Serializable {

	private static final long serialVersionUID = 1L;


	public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

		String str = (String) invoke("process", RemoteTest36.class.getName(), null, new Class[]{}, new Object[]{});
	}

	public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");
		try {
			return rms.invoke(methodName, className, instance, cla, obj);
		} catch (RemoteException e) {
			e.printStackTrace();
			return null;
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String process() {
		try {
//			UpdateDownhillPartWorker.updateDownhillPartStatus();
//			LWCMasterEnumerationDefinition corrugation = selectEnum("Corrugation");
//			if(corrugation != null) {
//				System.out.println("全局枚举NAME："+corrugation.getName());
//			}else {
//				System.out.println("没有找到这个全局枚举");
//			}


			String OR = "wt.epm.EPMDocumentMaster:312252";
			ObjectIdentifier oid =  ObjectIdentifier.newObjectIdentifier(OR);
			EPMDocumentMaster epm = (EPMDocumentMaster) PersistenceHelper.manager.refresh(oid);

			String identity = epm.getIdentificationObject().toString();
			System.out.println("identity:"+identity);

//			Timestamp timestamp = epm.getModifyTimestamp();
//			Instant instant = timestamp.toInstant();
//
//			// 将 Instant 转换为目标时区的时间
//			ZoneId targetZone = ZoneId.of("Asia/Shanghai"); // 东八区
//			ZonedDateTime zonedDateTime = instant.atZone(targetZone);
//
//			System.out.println("数据库时间："+timestamp);
//
//			System.out.println("东八时间："+zonedDateTime);


		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 根据全局分类内部值获取
	 * @param internalName LWCMASTERENUMERATIONDEFINITION
	 */
	public static LWCMasterEnumerationDefinition selectEnum(String internalName){
		LWCMasterEnumerationDefinition lwc = null;
		String sql = "SELECT IDA2A2 FROM \"LWCMASTERENUMERATIONDEFINITION\" WHERE NAME = ?";
		ResultSet resultSet = CommonUtil.excuteSelect(sql, internalName);
		try {
			while (resultSet.next()) {
				String oid = resultSet.getString("IDA2A2");
				WTObject object = PersistenceUtil.oid2Object("OR:com.ptc.core.lwc.server.LWCMasterEnumerationDefinition:" + oid);
				if(object != null) {
					lwc = (LWCMasterEnumerationDefinition)object;
				}
			}
		} catch (SQLException e){
			e.printStackTrace();
		}
		return lwc;
	}

	public static void addEntry(LWCMasterEnumerationDefinition lwc,String enumKey, String enumValue){

	}





}
