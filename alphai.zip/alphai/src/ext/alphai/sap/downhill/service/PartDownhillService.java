package ext.alphai.sap.downhill.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sap.util.CommonUtil;
import ext.alphai.sap.util.PersistenceUtil;
import ext.alphai.sap.util.IBAUtil;
import ext.alphai.sap.util.PartUtil;
import org.apache.commons.lang3.StringUtils;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.util.WTException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 物料下坡相关服务方法
 */
public class PartDownhillService {
    static final ObjectMapper objectMapper = new ObjectMapper();

    private static final String S = "S";
    private static final String E = "E";

    private static final String Resp_Type = "Resp_Type";

    private static final String Resp_MSG = "Resp_MSG";

    private static final String Part_Num="Part_Num";

    // 停止量产
    private static final String EOP_DATE = "AI_EOP_DATE";

    // 完全停产
    private static final String EOL_DATE="AI_EOL_DATE";

    // JSON 默认属性列表
    private static List<String> defParams = new ArrayList<String>(Arrays.asList(Part_Num, EOP_DATE, EOL_DATE, Resp_Type, Resp_MSG));


    private static final DateFormat dateFormatFile = new SimpleDateFormat("yyyy-MM-dd");


    private static final String Obsolescence_CN="废弃";

    private static final String Obsolescence="OBSOLESCENCE";


    /**
     * 修改部件IBA属性调用
     * @param json
     * @return
     */
//    public static HashMap<String,String> setPartIBA(String json){
//        HashMap<String, String> map = null;
//        List<WTPart> parts = new ArrayList<>();
//        try {
//            map = objectMapper.readValue(json, HashMap.class);
//        } catch (Exception e) {
//            HashMap<String, String> errMap = new HashMap<>();
//            errMap.put(Resp_Type,E);
//            errMap.put(Resp_MSG,"JSON 格式错误");
//            return errMap;
//        }
//        if (!map.containsKey(Part_Num)) {
//            map.put(Resp_Type,E);
//            map.put(Resp_MSG,"部件编号节点缺失");
//        }
//
//        String partNum = map.get(Part_Num);
//        List<String> viewsStr = new ArrayList<>();
//
//        ResultSet resultSet = CommonUtil.excuteSelect("Select NAME from WTView");
//        try {
//            while (resultSet.next()) {
//                viewsStr.add(resultSet.getString("NAME"));
//            }
//        } catch (SQLException e){
//            map.put(Resp_Type,E);
//            map.put(Resp_MSG,"服务器异常");
//            return map;
//        }
//
//        for (String view : viewsStr) {
//            WTPart part = PartUtil.getLatestWTPart(partNum, null, null, view);
//            if(part != null){
//                parts.add(part);
//            }
//        }
//        if(parts.isEmpty()){
//            map.put(Resp_Type,E);
//            map.put(Resp_MSG,"未能找到编号为 "+partNum+" 的部件");
//            return map;
//        }
//        System.out.println("当前修改IBA属性的部件编号为："+partNum);
//
//
//        String eop = map.get(EOP_DATE);
//        String eol = map.get(EOL_DATE);
//        Date eopDate = null;
//        Date eolDate = null;
//        if(StringUtils.isBlank(eop) && StringUtils.isBlank(eol)){
//            System.out.println("没有物料下坡时间的相关参数");
//        }else {
//            try {
//                eopDate = dateFormatFile.parse(eop);
//                eolDate = dateFormatFile.parse(eol);
//            } catch (ParseException e) {
//                map.put(Resp_Type,E);
//                map.put(Resp_MSG,"停产量产 、 完全停产时间格式异常 请修改为 yyyy-MM-dd 格式");
//                return map;
//            }
//        }
//
//
//        for (WTPart part : parts) {
//            try {
//                IBAUtil iba = new IBAUtil(part);
//
//                if(!StringUtils.isBlank(eop) && !StringUtils.isBlank(eol)){
//                    iba.setIBAAttribute4AllType(part,EOP_DATE, eop);
//                    iba.setIBAAttribute4AllType(part,EOL_DATE, eol);
//                }
//                for (Map.Entry<String, String> entry : map.entrySet()) {
//                    String key = entry.getKey();
//                    if(defParams.contains(key)){
//                        continue;
//                    }
//                    String value = entry.getValue();
//                    iba.setIBAAttribute4AllType(part,key, value);
//                }
//            } catch (Exception e) {
//                continue;
//            }
//        }
//        map.put(Resp_Type,S);
//        map.put(Resp_MSG,"修改成功");
//        return map;
//    }


    /**
     * 修改满足完全停产时间部件的生命周期
     */
    public static void changePartLiftCycleByEOL_DATE() throws WTException {
        List<WTPart> partList = new ArrayList<>();
        String sql = "SELECT DISTINCT IDA3A4 FROM STRINGVALUE SV WHERE SV.IDA3A4 IN (SELECT DISTINCT IDA3A4 FROM STRINGVALUE SV2 WHERE SV2.IDA3A6 = (SELECT SD2.IDA2A2 FROM STRINGDEFINITION SD2 WHERE SD2.NAME = 'AI_EOL_DATE') AND TO_DATE(SV2.VALUE2, 'YYYY-MM-DD') <= SYSDATE)";
        try {
            ResultSet resultSet = CommonUtil.excuteSelect(sql);
            while (resultSet.next()) {
                String oid = resultSet.getString("IDA3A4");
                WTPart part = (WTPart) PersistenceUtil.oid2Object("OR:wt.part.WTPart:" + oid);
                if(part != null) {
                    partList.add(part);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (WTPart part : partList) {
            String liveDisplay = part.getLifeCycleState().getDisplay();
            if(Obsolescence_CN.equals(liveDisplay)){

            }else {
                LifeCycleHelper.service.setLifeCycleState(part, State.toState(Obsolescence));
            }
        }
    }
}
