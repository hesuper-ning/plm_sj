package ext.alphai.sap.downhill.repeat;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import ext.alphai.sap.entity.HuSendPartRecord;
import ext.alphai.sap.util.IBAUtil;
import ext.alphai.sap.util.PersistenceUtil;
import wt.part.WTPart;
import wt.util.WTException;

/**
 * 下坡物料结果展示utility
 */
public class DownhillUtility extends AbstractDataUtility {

    public DownhillUtility() {
    }

    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {

        Object result = null;
        if(o instanceof HuSendPartRecord){
            HuSendPartRecord record = (HuSendPartRecord) o;
            String partOid = record.getPartOid();
            boolean reu = record.isResult();
            WTPart part = (WTPart) PersistenceUtil.oid2Object(partOid);
            if(part == null){
                return result;
            }
            IBAUtil iba = new IBAUtil(part);
            switch (s) {
                case "partNumber":
                    result = DownhillResultService.getPartUrlByPartNumber(part);
                    break;
                case "partName":
                    result = part.getName();
                    break;
                case "partFactory":
                    result = part.getView().getName();
                    break;

                case "EOPDate":
                    result = iba.getIBAValue(DownhillResultService.EOP_DATE);
                    break;

                case "EOLDate":
                    result = iba.getIBAValue(DownhillResultService.EOL_DATE);
                    break;

                case "sendResult":
                    if(reu){
                        result = "成功";
                    }else {
                        result = "失败";
                    }
                    break;
                case "resultMsg":
                    result = record.getErrMessage();
                    break;
            }
        }

        return result;
    }

}
