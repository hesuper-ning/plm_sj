package ext.alphai.sap.downhill.repeat;

import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.wvs.common.ui.VisualizationHelper;
import ext.alphai.sap.entity.HuSendPartRecord;
import ext.alphai.sap.util.IBAUtil;
import ext.alphai.sap.util.PersistenceUtil;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.representation.Representation;
import wt.util.WTException;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

/**
 * 下坡物料结果展示相关服务类
 */
public class DownhillResultService {
    // 停止量产
    public static final String EOP_DATE = "AI_EOP_DATE";

    // 完全停产
    public static final String EOL_DATE="AI_EOL_DATE";
    private static final String OK="OK";

    private static final String AI_SAPCAT1="AI_SAPCAT1";
    private static final String AI_SAPCAT2="AI_SAPCAT2";
    /**
     * 获取
     * @param name
     * @return
     */
    public static String getYesterdayWithName(String name) {
        // 获取昨天的日期
        LocalDate yesterday = LocalDate.now().minusDays(1);

        // 定义日期格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 格式化日期
        String formattedDate = yesterday.format(formatter);

        // 拼接日期和name，形成最终的字符串
        return formattedDate + "_" + name + ".txt";
    }



    public static String readFileContent(String path) {
        Path filePath = Paths.get(path);  // 使用Paths.get()来创建Path对象

        // 检查文件路径是否有效并读取文件内容
        try {
            if (Files.exists(filePath)) {
                // 使用Files.readAllLines()读取文件内容，并将其拼接为一个字符串
                return String.join("\n", Files.readAllLines(filePath));
            }
        } catch (IOException e) {
            // 捕获异常，返回空字符串
            e.printStackTrace();
        }

        // 如果路径无效或者读取出错，返回空字符串
        return "";
    }



    /**
     * 传入一个父部件返回在table上可以点击的物料编号连接
     * @param part
     * @return
     * @throws WTException
     */
    public static UrlDisplayComponent getPartUrlByPartNumber(WTPart part) throws WTException {
        NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();

        urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);

        NmOid contentOid = NmOid.newNmOid(part.getPersistInfo().getObjectIdentifier());

        String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null, true);

        UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent("", part.getNumber(), link);
        return urlDisplayComponent;
    }


    /**
     * 将重发写道昨天的文件中
     * @param content
     * @param basePath
     */
    public static void yesterdayWriteToEOLFile(String content, String basePath) {
        // 获取昨天的日期
        LocalDate yesterday = LocalDate.now().minusDays(1);

        // 定义日期格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 格式化日期
        String formattedDate = yesterday.format(formatter);

        // 拼接文件路径，最终文件名为 yyyy-MM-dd.txt
        Path filePath = Paths.get(basePath, formattedDate + "_EOL.txt");

        // 创建文件并写入内容，使用 TRUNCATE_EXISTING 选项确保覆盖
        try (BufferedWriter writer = Files.newBufferedWriter(filePath,
                StandardOpenOption.CREATE,        // 如果文件不存在则创建文件
                StandardOpenOption.TRUNCATE_EXISTING, // 如果文件存在，则清空文件并覆盖
                StandardOpenOption.WRITE)) {       // 打开文件进行写入
            // 将传入的内容写入到文件中
            writer.write(content);
            System.out.println("EOL物料下坡日志记录完成：" + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * 将重发写道昨天的文件中
     * @param content
     * @param basePath
     */

    public static void yesterdayWriteToEOPFile(String content, String basePath) {

        // 获取昨天的日期
        LocalDate yesterday = LocalDate.now().minusDays(1);

        // 定义日期格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 格式化日期
        String formattedDate = yesterday.format(formatter);

        // 拼接文件路径，最终文件名为 yyyy-MM-dd.txt
        Path filePath = Paths.get(basePath, formattedDate + "_EOP.txt");


        // 创建文件并写入内容，使用 TRUNCATE_EXISTING 选项确保覆盖
        try (BufferedWriter writer = Files.newBufferedWriter(filePath,
                StandardOpenOption.CREATE,        // 如果文件不存在则创建文件
                StandardOpenOption.TRUNCATE_EXISTING, // 如果文件存在，则清空文件并覆盖
                StandardOpenOption.WRITE)) {       // 打开文件进行写入
            // 将传入的内容写入到文件中
            writer.write(content);
            System.out.println("EOP物料下坡日志记录完成：" + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void setSAPCAT(List<HuSendPartRecord> records, String ibaName) throws Exception {
        for (HuSendPartRecord record : records) {
            WTObject object = PersistenceUtil.oid2Object(record.getPartOid());
            if (record.isResult()) {
                if(object != null){
                    WTPart part = (WTPart) object;
                    IBAUtil iba = new IBAUtil();
                    iba.setIBAAttribute4AllType(part, ibaName,OK);
                }

            }else {
                if(object != null){
                    WTPart part = (WTPart) object;
                    IBAUtil iba = new IBAUtil();
                    iba.setIBAAttribute4AllType(part, ibaName,record.getErrMessage());
                }
            }
        }
    }

}
