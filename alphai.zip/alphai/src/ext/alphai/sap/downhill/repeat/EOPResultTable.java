package ext.alphai.sap.downhill.repeat;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.htmlcomp.components.AbstractConfigurableTableBuilder;
import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.jca.mvc.components.JcaTableConfig;
import com.ptc.mvc.components.*;
import ext.alphai.sap.CustomActionsRB;
import ext.alphai.sap.entity.HuSendPartRecord;
import org.apache.commons.lang3.StringUtils;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 下坡开始物料发送结果展示页
 */

@ComponentBuilder("ext.alphai.sap.downhill.repeat.EOPResultTable")
public class EOPResultTable extends AbstractConfigurableTableBuilder {

    static final String RESOURCE = CustomActionsRB.class.getName();
    static final ObjectMapper objectMapper = new ObjectMapper();
    private static String EOP = "EOP";
    private static String CLASS_PATH;
    static {
        WTProperties wtProperties = null;
        try {
            wtProperties = WTProperties.getLocalProperties();
        } catch (IOException e) {

        }
        CLASS_PATH =wtProperties.getProperty("wt.codebase.location") + "\\"+"ext\\alphai\\sap\\saplog";

    }



    @Override
    public ConfigurableTable buildConfigurableTable(String s) throws WTException {
        return null;
    }

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {

        final ComponentConfigFactory factory = getComponentConfigFactory();
        final JcaTableConfig table;
        {
            table = (JcaTableConfig) factory.newTableConfig();
            table.setComponentMode(ComponentMode.VIEW);
            table.setAutoGenerateRowId(true);
            table.setType(WTPart.class.getName());
            table.setLabel(WTMessage.getLocalizedMessage(RESOURCE,
                    CustomActionsRB.EOPPartSendToHUSAPReportForms, null));
            // 重发失败 下坡开始物料model
            table.setActionModel("JCEOPRepeat");
            table.setSelectable(true);
            table.setShowCount(true);
//            table.setShowCustomViewLink(false);
            table.setConfigurable(true);

            ColumnConfig partNumber = factory.newColumnConfig("partNumber", true);
            partNumber.setLabel("部件编号");
            partNumber.setDataUtilityId("DownhillUtility");
            table.addComponent(partNumber);

            ColumnConfig partName = factory.newColumnConfig("partName", true);
            partName.setLabel("部件名称");
            partName.setDataUtilityId("DownhillUtility");
            table.addComponent(partName);

            ColumnConfig partFactory = factory.newColumnConfig("partFactory", true);
            partFactory.setLabel("工厂");
            partFactory.setDataUtilityId("DownhillUtility");
            table.addComponent(partFactory);

            ColumnConfig EOPDate = factory.newColumnConfig("EOPDate", true);
            EOPDate.setLabel("下坡开始时间");
            EOPDate.setDataUtilityId("DownhillUtility");
            table.addComponent(EOPDate);

            ColumnConfig sendResult = factory.newColumnConfig("sendResult", true);
            sendResult.setLabel("发送结果");
            sendResult.setDataUtilityId("DownhillUtility");
            table.addComponent(sendResult);


            ColumnConfig resultMsg = factory.newColumnConfig("resultMsg", true);
            resultMsg.setLabel("错误信息");
            resultMsg.setDataUtilityId("DownhillUtility");
            table.addComponent(resultMsg);

        }


        return table;
    }

    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        List<HuSendPartRecord> records =null;

        // 昨天的下坡开始物料日志文件路径
        String logTxtPath = DownhillResultService.getYesterdayWithName(EOP);
        // 日志内容JSON
        String json = DownhillResultService.readFileContent(CLASS_PATH+"\\"+logTxtPath);

//        String json = DownhillResultService.readFileContent(CLASS_PATH+"\\"+"2025-01-23_EOP.txt");

        if(StringUtils.isBlank(json)){
            records = new ArrayList<>();
        }else {
            try {
                records = objectMapper.readValue(json, new TypeReference<List<HuSendPartRecord>>() {});
                // 过滤集合 只保留失败条目

                records = records.stream()
                        .filter(record -> !record.isResult())  // 只保留 isResult() 为 false 的记录
                        .collect(Collectors.toList());
            } catch (Exception e){
                e.printStackTrace();
            }
        }

        return records;
    }
}
