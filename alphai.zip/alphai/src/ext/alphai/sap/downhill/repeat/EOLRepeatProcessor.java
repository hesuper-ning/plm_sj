package ext.alphai.sap.downhill.repeat;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.forms.FormResultAction;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sap.Config;
import ext.alphai.sap.entity.HuSendPartRecord;
import ext.alphai.sap.part.HUSendPartHelper;
import ext.alphai.sap.util.PersistenceUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.HTMLEncoder;
import wt.util.WTException;
import wt.util.WTProperties;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * EOL重发处理
 */
public class EOLRepeatProcessor extends DefaultObjectFormProcessor {
    static final ObjectMapper objectMapper = new ObjectMapper();
    private static String EOL = "EOL";
    private static String CLASS_PATH;

    private static final String AI_SAPCAT2="AI_SAPCAT2";
    static {
        WTProperties wtProperties = null;
        try {
            wtProperties = WTProperties.getLocalProperties();
        } catch (IOException e) {

        }
        CLASS_PATH =wtProperties.getProperty("wt.codebase.location") + "\\"+"ext\\alphai\\sap\\saplog";

    }
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {


        List<HuSendPartRecord> records =new ArrayList<>();

        // 昨天的下坡开始物料日志文件路径
        String logTxtPath = DownhillResultService.getYesterdayWithName(EOL);
        // 日志内容JSON
        String json = DownhillResultService.readFileContent(CLASS_PATH+"\\"+logTxtPath);

//        String json = DownhillResultService.readFileContent(CLASS_PATH+"\\"+"2025-01-23_EOL.txt");

        if(!StringUtils.isBlank(json)){
            try {
                records = objectMapper.readValue(json, new TypeReference<List<HuSendPartRecord>>() {});
            } catch (Exception e){
                e.printStackTrace();
            }
        }




        List<WTPart> eolLists = new ArrayList<>();
        for (HuSendPartRecord record : records) {
            if (!record.isResult()) {
                String partOid = record.getPartOid();

                WTObject object = PersistenceUtil.oid2Object(partOid);
                if(object ==null ){
                    continue;
                }
                if(object instanceof WTPart){
                    eolLists.add((WTPart) object);
                }
            }
        }

        List<HuSendPartRecord> sendAgainRecord = new ArrayList<>();
        // 重发
        String resultJson ="";
        try {
            // 重发的结果
            sendAgainRecord = HUSendPartHelper.sendPartToSAP(eolLists, Config.BUTTON);
            resultJson = objectMapper.writeValueAsString(sendAgainRecord);
        } catch (Exception e) {
            e.printStackTrace();
        }



        // 将重发结果储存到昨天的日志文件中
        DownhillResultService.yesterdayWriteToEOLFile(resultJson, CLASS_PATH);
        // 修改成功的IBA属性
        try {
            DownhillResultService.setSAPCAT(sendAgainRecord, AI_SAPCAT2);
        } catch (Exception e) {
            e.printStackTrace();
        }




        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null, new String[] { "下坡结束物料发送完成!" }));
        String refreshAction = "window.opener.PTC.jca.table.Utils.reload('ext.alphai.sap.downhill.repeat.EOLResultTable');";//xxx 为 table id

        refreshAction = HTMLEncoder.encodeForJavascript(refreshAction);

        String jString = "window.close();" + refreshAction;

        result.setNextAction(FormResultAction.JAVASCRIPT);

        result.setJavascript(jString);

        result.setSkipPageRefresh(true);
        return result;
    }
}
