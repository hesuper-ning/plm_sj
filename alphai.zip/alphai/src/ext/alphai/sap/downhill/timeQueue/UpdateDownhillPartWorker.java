package ext.alphai.sap.downhill.timeQueue;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sap.Config;
import ext.alphai.sap.entity.HuSendPartRecord;
import ext.alphai.sap.part.HUSendPartHelper;
import ext.alphai.sap.util.CommonUtil;
import ext.alphai.sap.util.IBAUtil;
import ext.alphai.sap.util.PartUtil;
import ext.alphai.sap.util.PersistenceUtil;
import wt.fc.PersistenceHelper;
import wt.fc.WTObject;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTProperties;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 物料下坡 工作队列执行任务类
 */
public class UpdateDownhillPartWorker {
    static final ObjectMapper objectMapper = new ObjectMapper();
    private static String CLASS_PATH;
    static {
        WTProperties wtProperties = null;
        try {
            wtProperties = WTProperties.getLocalProperties();
        } catch (IOException e) {

        }
        CLASS_PATH =wtProperties.getProperty("wt.codebase.location") + "\\"+"ext\\alphai\\sap\\saplog";

    }

    private static final String OK="OK";

    private static final String AI_SAPCAT1="AI_SAPCAT1";
    private static final String AI_SAPCAT2="AI_SAPCAT2";

    private static final String Frozen_CN="已冻结";

    private static final String Frozen="Frozen";

    private static final String Obsolescence_CN="废弃";

    private static final String Obsolescence="OBSOLESCENCE";
    public static void updateDownhillPartStatus() {
        Date date = new Date();
        System.out.println("======修改下坡物料生命周期任务开始执行======" + date);

        try {
            changePartLiftCycleByEOL_DATE();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("==============修改下坡物料生命周期任始执行完毕==================");
    }


    /**
     * 修改满足完全停产时间部件的生命周期
     */
    public static void changePartLiftCycleByEOL_DATE() throws WTException {


        // 获取开始下坡物料
        List<WTPart> eopPartList = new ArrayList<>();
        String eopsql = "SELECT DISTINCT IDA3A4 FROM STRINGVALUE SV WHERE SV.IDA3A4 IN (SELECT DISTINCT IDA3A4 FROM STRINGVALUE SV2 WHERE SV2.IDA3A6 = (SELECT SD2.IDA2A2 FROM STRINGDEFINITION SD2 WHERE SD2.NAME = 'AI_EOP_DATE') AND TO_DATE(SV2.VALUE2, 'YYYY-MM-DD') <= SYSDATE)";
        try {
            ResultSet resultSet = CommonUtil.excuteSelect(eopsql);
            while (resultSet.next()) {
                String oid = resultSet.getString("IDA3A4");
                WTPart part = (WTPart) PersistenceUtil.oid2Object("OR:wt.part.WTPart:" + oid);
                if(part != null) {
                    IBAUtil iba = new IBAUtil(part);
                    String name = part.getView().getName();
                    if("3101".equals(name) || "3188".equals(name)) {
                        String sapCat1 = iba.getIBAValue(AI_SAPCAT1);
                        String sapCat2 = iba.getIBAValue(AI_SAPCAT2);
                        if(!OK.equals(sapCat2) && !OK.equals(sapCat1)){
                            eopPartList.add(part);
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        eopPartList = getMaxVersionParts(eopPartList,null);



        List<WTPart> partList = new ArrayList<>();
        // 获取停止下坡物料
        String sql = "SELECT DISTINCT IDA3A4 FROM STRINGVALUE SV WHERE SV.IDA3A4 IN (SELECT DISTINCT IDA3A4 FROM STRINGVALUE SV2 WHERE SV2.IDA3A6 = (SELECT SD2.IDA2A2 FROM STRINGDEFINITION SD2 WHERE SD2.NAME = 'AI_EOL_DATE') AND TO_DATE(SV2.VALUE2, 'YYYY-MM-DD') < SYSDATE)";
        try {
            ResultSet resultSet = CommonUtil.excuteSelect(sql);
            while (resultSet.next()) {
                String oid = resultSet.getString("IDA3A4");
                WTPart part = (WTPart) PersistenceUtil.oid2Object("OR:wt.part.WTPart:" + oid);
                if(part != null) {
                    IBAUtil iba = new IBAUtil(part);
                    String name = part.getView().getName();
                    if("3101".equals(name) || "3188".equals(name)) {
                        String sapCat2 = iba.getIBAValue(AI_SAPCAT2);
                        if(!OK.equals(sapCat2)) {
                            partList.add(part);
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        partList = getMaxVersionParts(partList,null);

        // 即将废弃的就不用设置冻结
        eopPartList.removeAll(partList);
//        System.out.println("预备冻结的部件个数为："+eopPartList.size());
//        for (WTPart part : eopPartList) {
//            System.out.println("---冻结："+part.getPersistInfo().getObjectIdentifier().getId());
//        }
//
//
//        System.out.println("预备废弃的部件个数为："+partList.size());
//        for (WTPart part : partList) {
//            System.out.println("---废弃："+part.getPersistInfo().getObjectIdentifier().getId());
//        }


        for (WTPart part : eopPartList) {
            String liveDisplay = part.getLifeCycleState().getDisplay();
            if(Frozen_CN.equals(liveDisplay)){

            }else {
                LifeCycleHelper.service.setLifeCycleState(part, State.toState(Frozen));
            }
            PersistenceHelper.manager.refresh(part);
        }
        for (WTPart part : partList) {
            String liveDisplay = part.getLifeCycleState().getDisplay();
            if(Obsolescence_CN.equals(liveDisplay)){

            }else {
                LifeCycleHelper.service.setLifeCycleState(part, State.toState(Obsolescence));
            }
            PersistenceHelper.manager.refresh(part);
        }


        // 发送物料到SAP
        List<WTPart> FrozenMaxVersionParts = getMaxVersionParts(eopPartList, Frozen_CN);
        List<WTPart> ObsolescenceMaxVersionParts = getMaxVersionParts(partList, Obsolescence_CN);

//        System.out.println("发送冻结部件的个数为："+FrozenMaxVersionParts.size());
//        for (WTPart part : FrozenMaxVersionParts) {
//            System.out.println("---发送冻结："+part.getPersistInfo().getObjectIdentifier().getId());
//        }
//
//        System.out.println("发送废弃部件的个数为："+ObsolescenceMaxVersionParts.size());
//        for (WTPart part : ObsolescenceMaxVersionParts) {
//            System.out.println("---发送废弃："+part.getPersistInfo().getObjectIdentifier().getId());
//        }


        // 创建一个saplog文件夹
        ensureSaplogFolderExists(CLASS_PATH);

        try {

            // 为防止修改状态后内存中的WTPart对象状态不产生变化 选则往数据库中再读一次
            FrozenMaxVersionParts = getDBWTPart(FrozenMaxVersionParts);
            ObsolescenceMaxVersionParts = getDBWTPart(ObsolescenceMaxVersionParts);
            List<HuSendPartRecord> recordsEOP = HUSendPartHelper.sendPartToSAP(FrozenMaxVersionParts, Config.BUTTON);
            List<HuSendPartRecord> recordsEOL = HUSendPartHelper.sendPartToSAP(ObsolescenceMaxVersionParts, Config.BUTTON);



            String eolJson = objectMapper.writeValueAsString(recordsEOL);
            String eopJson = objectMapper.writeValueAsString(recordsEOP);
            writeToEOLFile(eolJson, CLASS_PATH);

            writeToEOPFile(eopJson, CLASS_PATH);



            setSAPCAT(recordsEOP, AI_SAPCAT1);

            setSAPCAT(recordsEOL, AI_SAPCAT2);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private static List<WTPart> getDBWTPart(List<WTPart> parts){
        List<WTPart> results = new ArrayList<>();
        for (WTPart part : parts) {
            String or = PersistenceUtil.object2Oid(part);
            WTObject object = PersistenceUtil.oid2Object(or);

            if(object !=null){
                results.add((WTPart)object);
            }
        }


        return results;

    }





    public static void setSAPCAT(List<HuSendPartRecord> records, String ibaName) throws Exception {
        for (HuSendPartRecord record : records) {
            WTObject object = PersistenceUtil.oid2Object(record.getPartOid());
            if (record.isResult()) {
                if(object != null){
                    WTPart part = (WTPart) object;
                    IBAUtil iba = new IBAUtil();
                    iba.setIBAAttribute4AllType(part, ibaName,OK);
                }

            }else {
                if(object != null){
                    WTPart part = (WTPart) object;
                    IBAUtil iba = new IBAUtil();
                    iba.setIBAAttribute4AllType(part, ibaName,record.getErrMessage());
                }
            }
        }
    }







    public static void writeToEOLFile(String content, String basePath) {
        // 获取当前日期，格式化为yyyy-MM-dd
        String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        // 拼接文件路径，最终文件名为 yyyy-MM-dd.txt
        Path filePath = Paths.get(basePath, currentDate + "_EOL.txt");

        // 创建文件并写入内容，使用 TRUNCATE_EXISTING 选项确保覆盖
        try (BufferedWriter writer = Files.newBufferedWriter(filePath,
                StandardOpenOption.CREATE,        // 如果文件不存在则创建文件
                StandardOpenOption.TRUNCATE_EXISTING, // 如果文件存在，则清空文件并覆盖
                StandardOpenOption.WRITE)) {       // 打开文件进行写入
            // 将传入的内容写入到文件中
            writer.write(content);
            System.out.println("EOL物料下坡日志记录完成：" + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void writeToEOPFile(String content, String basePath) {
        // 获取当前日期，格式化为yyyy-MM-dd
        String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        // 拼接文件路径，最终文件名为 yyyy-MM-dd_EOP.txt
        // 使用Paths.get来兼容JDK 1.8
        Path filePath = Paths.get(basePath, currentDate + "_EOP.txt");

        // 创建文件并写入内容，使用 TRUNCATE_EXISTING 选项确保覆盖
        try (BufferedWriter writer = Files.newBufferedWriter(filePath,
                StandardOpenOption.CREATE,        // 如果文件不存在则创建文件
                StandardOpenOption.TRUNCATE_EXISTING, // 如果文件存在，则清空文件并覆盖
                StandardOpenOption.WRITE)) {       // 打开文件进行写入
            // 将传入的内容写入到文件中
            writer.write(content);
            System.out.println("EOP物料下坡日志记录完成：" + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public static void ensureSaplogFolderExists(String fullPath) {
        // 将传入路径转化为Path对象
        Path targetPath = Paths.get(fullPath);

        // 判断路径是否存在，并且是一个文件夹
        if (Files.exists(targetPath) && Files.isDirectory(targetPath)) {
            // 如果文件夹已存在，不做任何操作
            System.out.println("文件夹 'saplog' 已经存在，无需创建。");
        } else {
            // 如果路径不存在或者是文件，创建文件夹
            try {
                Files.createDirectories(targetPath);
                System.out.println("文件夹 'saplog' 已创建： " + targetPath);
            } catch (IOException e) {
                System.out.println("创建文件夹时出错：" + e.getMessage());
            }
        }
    }




    public static List<WTPart> getMaxVersionParts(List<WTPart> classPart, String type) {
        // 使用 Map 存储每个编号和视图名称对应的最大版本
        Map<String, WTPart> maxVersionMap = new HashMap<>();

        for (WTPart part : classPart) {
            String number = part.getNumber();
//            String display = part.getLifeCycleState().getDisplay();
//
//            if(!type.equals(display)){
//                continue;
//            }

            // 获取部件的视图名称
            String viewName = part.getView().getName();

            // 检查部件是否符合生命周期状态和视图名称

            String key = number + "-" + viewName; // 用编号和视图名称组合成唯一的键

            // 如果当前 Map 中没有该编号和视图名称组合的部件，或者当前部件版本更大，则更新
            if (!maxVersionMap.containsKey(key) ||
                    compareVersion(part, maxVersionMap.get(key)) > 0) {
                maxVersionMap.put(key, part);
            }

        }

        // 返回每个编号和视图名称最大版本的部件列表
        return new ArrayList<>(maxVersionMap.values());
    }

    // 用于比较版本大小
    private static int compareVersion(WTPart part1, WTPart part2) {
        String majorVersion1 = part1.getVersionIdentifier().getValue();
        String majorVersion2 = part2.getVersionIdentifier().getValue();

        // 比较大版本（字母）
        int compareMajor = majorVersion1.compareTo(majorVersion2);
        if (compareMajor != 0) {
            return compareMajor;  // 大版本不同则直接返回比较结果
        }

        // 如果大版本相同，比较小版本（数字）
        String minorVersion1 = part1.getIterationIdentifier().getValue();
        String minorVersion2 = part2.getIterationIdentifier().getValue();

        // 将小版本的字符串转换为整数进行比较
        int minor1 = Integer.parseInt(minorVersion1);
        int minor2 = Integer.parseInt(minorVersion2);

        return Integer.compare(minor1, minor2);
    }
}
