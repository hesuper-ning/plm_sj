package ext.alphai.sap.util;

import com.ptc.core.lwc.client.commands.LWCCommands;
import com.ptc.core.lwc.common.view.*;
import com.ptc.core.lwc.server.LWCStructEnumAttTemplate;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.DiscreteSet;
import com.ptc.core.meta.common.impl.InstanceBasedAssociationIdentifier;
import com.ptc.core.meta.common.impl.InstanceBasedAttributeIdentifier;
import com.ptc.core.meta.common.impl.InstanceBasedAttributeTypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.meta.server.IBAModel;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.meta.type.common.TypeInstanceFactory;
import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.core.meta.type.server.TypeInstanceUtility;
import ext.jiecang.erp.util.IBAUtilCache;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.csm.navigation.ClassificationNode;
import wt.csm.navigation.ClassificationNodeLoader;
import wt.csm.navigation.litenavigation.ClassificationNodeDefaultView;
import wt.csm.navigation.service.ClassificationHelper;
import wt.doc.WTDocument;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.*;
import wt.iba.definition.*;
import wt.iba.definition.litedefinition.*;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.*;
import wt.iba.value.litevalue.*;
import wt.iba.value.service.IBAValueDBService;
import wt.iba.value.service.IBAValueHelper;
import wt.iba.value.service.LoadValue;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.*;
import wt.session.SessionHelper;
import wt.type.TypeDefinitionReference;
import wt.type.Typed;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.*;

public class IBAUtil {
	public Hashtable ibaContainer;   
	DefaultAttributeContainer defaultAttributeContainer;
	IBAUtilCache definitionCache = new IBAUtilCache();
	private static final Logger logger = LogR.getLogger(IBAUtil.class.getName());
	private Map<String,Map<String,Object>> enumMap = new HashMap<String, Map<String,Object>>();
	public IBAUtil() {
		ibaContainer = new Hashtable();
	}
	public IBAUtil(IBAHolder ibaholder) {
		initializeIBAPart(ibaholder);
		if(ibaholder instanceof WTPart || ibaholder instanceof WTDocument){
			String typeName = getTypeName((WTObject)ibaholder);
			enumMap = getIbaEnumConstraint(typeName);
		}
	}

	public IBAUtil(IBAHolder ibaholder, String classificationKey) {
		initializeIBAPart(ibaholder);
		if(ibaholder instanceof WTPart || ibaholder instanceof WTDocument){
			String typeName = getTypeName((WTObject)ibaholder);
			enumMap = getIbaEnumConstraint(typeName);
		}
		try {
			//获取分类属性值
			String clsName = getIBAValue(classificationKey);
//			clsName = "dg";
			if(StringUtils.isNotBlank(clsName)){
				Map<String, Map<String, Object>> csmEnumConstraints = getCSMEnumConstraints(clsName);
				if(enumMap == null){
					enumMap = new HashMap<String, Map<String,Object>>();
				}
				enumMap.putAll(csmEnumConstraints);
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
	}
	public IBAUtil(IBAHolder ibaholder, IBAUtilCache cache) { 
		initializeIBAPart(ibaholder);

		definitionCache = cache;
	}

	public String toString() {
		StringBuffer stringbuffer = new StringBuffer();
		Enumeration enumeration = ibaContainer.keys(); 
		try {
			while (enumeration.hasMoreElements()) {
				String s = (String) enumeration.nextElement();
				AbstractValueView abstractvalueview = (AbstractValueView) ((Object[]) ibaContainer
						.get(s))[1];
				stringbuffer.append(s
						+ " - "
						+ IBAValueUtility.getLocalizedIBAValueDisplayString(
								abstractvalueview, SessionHelper.manager
										.getLocale()));
				stringbuffer.append('\n');
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return stringbuffer.toString();
	}

	public String getIBAValue(String s) {
		try {
			String ibaValue = getIBAValue(s, SessionHelper.manager.getLocale());
			if(StringUtils.isBlank(ibaValue)){
				return "";
			}else {
				boolean containsKey = enumMap.containsKey(s);
				if(containsKey){
					return String.valueOf(enumMap.get(s).get(ibaValue) != null ?enumMap.get(s).get(ibaValue).toString():"" );
				}
				return ibaValue;
			}
		} catch (WTException wte) {
			wte.printStackTrace();
		}
		return "";
	}

	/**
	 * return multiple IBA values
	 *
	 * @param name String
	 * @return Vector
	 */
	public Vector getIBAValues(String name) {
		Vector vector = new Vector();
		try {
			if (ibaContainer.get(name) != null) {
				Object[] objs = (Object[]) ibaContainer.get(name);
				for (int i = 1; i < objs.length; i++) {
					AbstractValueView theValue = (AbstractValueView) objs[i];
					vector.addElement(IBAValueUtility.getLocalizedIBAValueDisplayString(theValue,
							SessionHelper.manager.getLocale()));
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return vector;
	}

	public String getIBAValue(String s, Locale locale) {   
		
		try {
			if(StringUtils.isBlank(s)){
				return null;
			}
			Object[] obj = (Object[]) ibaContainer.get(s);
			if (obj == null)
				return null;
			AbstractValueView abstractvalueview = (AbstractValueView) obj[1];				
			logger.debug("ext.bitland.util.IBAUtil>>>abstractvalueview"
					+ abstractvalueview.getDefinition().getName() 
					+ "-----------------------");			
			return IBAValueUtility.getLocalizedIBAValueDisplayString(
					abstractvalueview, locale);
		} catch (WTException wte) {
			wte.printStackTrace();
		}
		return ""; 
	}

	
	public String getIBADisplayName(String s) throws WTException { 		
		Object[] obj = (Object[]) ibaContainer.get(s);
		if (obj == null)
			return null;
		AbstractValueView abstractvalueview = (AbstractValueView) obj[1];						
		return abstractvalueview.getDefinition().getDisplayName();		
	}

	private void initializeIBAPart(IBAHolder ibaholder) {
		ibaContainer = new Hashtable();
		try {
			ibaholder = IBAValueHelper.service.refreshAttributeContainer(
					ibaholder, null, SessionHelper.manager.getLocale(), null);
			DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer) ibaholder
					.getAttributeContainer();
			
			
			
			if (defaultattributecontainer != null) {
				AttributeDefDefaultView aattributedefdefaultview[] = defaultattributecontainer
						.getAttributeDefinitions();
				for (int i = 0; i < aattributedefdefaultview.length; i++) {
					AbstractValueView aabstractvalueview[] = defaultattributecontainer
							.getAttributeValues(aattributedefdefaultview[i]);
					if (aabstractvalueview != null) {
						Object aobj[] = new Object[2];
						aobj[0] = aattributedefdefaultview[i];
						aobj[1] = aabstractvalueview[0];
						ibaContainer.put(aattributedefdefaultview[i].getName(),
								((Object) (aobj)));
					}
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	
	
	/**
	 * 获取某个分类所有属性的枚举值列表
	 * @param classificationKey
	 * @return
	 * @throws WTException
	 * @throws ClassNotFoundException 
	 */
	 public  Map<String,Map<String,Object>> getCSMEnumConstraints(String classificationKey) throws WTException{
		 
		 Map<String,Map<String,Object>> result = new HashMap<String,Map<String,Object>>();
		 if(StringUtils.isBlank(classificationKey)){
			 return result;
		 }
		 //根据iba key 获取分类节点对象
		 LWCStructEnumAttTemplate structureEum = getStructureEum(classificationKey);
		 if(structureEum == null){
			 return result;
		 }
		 //获取分类节点的所有属性
		 ArrayList<AttributeDefinitionReadView> typeAttributes = LWCCommands.getTypeAttributes("OR:"+structureEum.getPersistInfo().getObjectIdentifier().toString());
			for (AttributeDefinitionReadView attributeDefinitionReadView2 : typeAttributes) {
				//遍历每个IBA属性
				AttributeDefDefaultView ibaRefView = attributeDefinitionReadView2.getIBARefView();
				if(ibaRefView == null){
					continue;
				}
				//获取全局属性内部名称
				String name = attributeDefinitionReadView2.getIBARefView().getName();
				Collection collection = attributeDefinitionReadView2.getAllConstraints();
				//获取每个属性的全部约束
				for (Object object : collection) {
					if(object instanceof ConstraintDefinitionReadView){
						ConstraintDefinitionReadView cdr = (ConstraintDefinitionReadView)object;
						ConstraintRuleDefinitionReadView rule = cdr.getRule();
						String ruleClassname = rule.getRuleClassname();
						//是否合法值列表或枚举值
						if( StringUtils.containsIgnoreCase(ruleClassname,"DiscreteSetConstraint")){
//							System.out.println("===============iba key:"+name);
							//是否有枚举值
							EnumerationDefinitionReadView enumDef = cdr.getEnumDef();
							if(enumDef != null){
								Map<String, EnumerationEntryReadView> allEnumerationEntries = enumDef.getAllEnumerationEntries();
								Set<String> keySet = allEnumerationEntries.keySet();
								//保存所有枚举值的内部名称和显示名称map
								Map<String,Object> enumMap = new HashMap<String, Object>();
								for(String key : keySet){
									EnumerationEntryReadView enumerationEntryReadView = allEnumerationEntries.get(key);
									PropertyValueReadView displayName = enumerationEntryReadView.getPropertyValueByName("displayName");
									Object value = displayName.getValue();
									enumMap.put(key, value);
								}
								result.put(name, enumMap);
//								System.out.println("===============enum values:"+enumMap);
							}
						}
					}
				}
			}
		 
		 return result;
	 }
	
	/**
	  * 获取指定类型TypeName的所有属性ibaKey的枚举值列表
	  * @param typeName
	  * @param ibaKey
	  * @return  Map<String,Map<String,Object>>
	  */
	 public static Map<String,Map<String,Object>> getIbaEnumConstraint(String typeName){
		 Map<String,Map<String,Object>> result = new HashMap<String,Map<String,Object>>();
		if(StringUtils.isBlank(typeName)){
			return result;
		}
		try {
			TypeDefinitionReadView typeDefView = TypeDefinitionServiceHelper.service.getTypeDefView(typeName);
			ArrayList<AttributeDefinitionReadView> typeAttributes = LWCCommands.getTypeAttributes("OR:"+typeDefView.getOid().getStringValue());
			//找到所有IBA属性
			for (AttributeDefinitionReadView attributeDefinitionReadView2 : typeAttributes) {
				//遍历每个IBA属性
				AttributeDefDefaultView ibaRefView = attributeDefinitionReadView2.getIBARefView();
				if(ibaRefView == null){
					continue;
				}
				//获取全局属性内部名称
				String name = attributeDefinitionReadView2.getIBARefView().getName();
				Collection collection = attributeDefinitionReadView2.getAllConstraints();
				//获取每个属性的全部约束
				for (Object object : collection) {
					if(object instanceof ConstraintDefinitionReadView){
						ConstraintDefinitionReadView cdr = (ConstraintDefinitionReadView)object;
						ConstraintRuleDefinitionReadView rule = cdr.getRule();
						String ruleClassname = rule.getRuleClassname();
						//是否合法值列表或枚举值
						if( StringUtils.containsIgnoreCase(ruleClassname,"DiscreteSetConstraint")){
//							System.out.println("===============iba key:"+name);
							//是否有枚举值
							EnumerationDefinitionReadView enumDef = cdr.getEnumDef();
							if(enumDef != null){
								Map<String, EnumerationEntryReadView> allEnumerationEntries = enumDef.getAllEnumerationEntries();
								Set<String> keySet = allEnumerationEntries.keySet();
								//保存所有枚举值的内部名称和显示名称map
								Map<String,Object> enumMap = new HashMap<String, Object>();
								for(String key : keySet){
									EnumerationEntryReadView enumerationEntryReadView = allEnumerationEntries.get(key);
									PropertyValueReadView displayName = enumerationEntryReadView.getPropertyValueByName("displayName");
									Object value = displayName.getValue();
									enumMap.put(key, value);
								}
								result.put(name, enumMap);
//								System.out.println("===============enum values:"+enumMap);
							}
						}
					}
				}
			}
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println("===============Show enums:"+result);
		return result;
	 }

	/**
	  * 获取指定类型TypeName的某属性ibaKey的合法值列表，返回为字符串List
	  * @param typeName
	  * @param ibaKey
	  * @return List<String>
	  */
	 public static List<String> getIbaDiscreteSetConstraint(String typeName, String ibaKey){
		List<String> result = new ArrayList<String>();
		if(StringUtils.isBlank(typeName)||StringUtils.isBlank(ibaKey)){
			return result;
		}
		try {
			TypeDefinitionReadView typeDefView = TypeDefinitionServiceHelper.service.getTypeDefView(typeName);
			ArrayList<AttributeDefinitionReadView> typeAttributes = LWCCommands.getTypeAttributes("OR:"+typeDefView.getOid().getStringValue());
			for (AttributeDefinitionReadView attributeDefinitionReadView2 : typeAttributes) {
				String name = attributeDefinitionReadView2.getName();
				if(!StringUtils.equalsIgnoreCase(ibaKey, name)){
					continue;
				}
				Collection collection = attributeDefinitionReadView2.getAllConstraints();
				for (Object object : collection) {
					if(object instanceof ConstraintDefinitionReadView){
						ConstraintDefinitionReadView cdr = (ConstraintDefinitionReadView)object;
						ConstraintRuleDefinitionReadView rule = cdr.getRule();
						String ruleClassname = rule.getRuleClassname();
						if( StringUtils.containsIgnoreCase(ruleClassname,"DiscreteSetConstraint")){//是否合法值列表
							Serializable ruleData = cdr.getRuleData();
							if(ruleData instanceof DiscreteSet){
								DiscreteSet ds = (DiscreteSet)ruleData;
								Object[] elements = ds.getElements();
								if(elements != null && elements.length > 0){
									for(Object obj : elements){
										result.add(String.valueOf(obj));
									}
								}
							}
							break;
						}
					}
				}
				break;
			}
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	 }
	
	public IBAHolder updateIBAPart(IBAHolder ibaholder) throws Exception {

		ibaholder = IBAValueHelper.service.refreshAttributeContainer(ibaholder,
				null, SessionHelper.manager.getLocale(), null);
		DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer) (IBAValueHelper.service
				.refreshAttributeContainerWithoutConstraints(ibaholder))
				.getAttributeContainer();
		for (Enumeration enumeration = ibaContainer.elements(); enumeration
				.hasMoreElements();) {
			try {
				Object aobj[] = (Object[]) enumeration.nextElement();
				AbstractValueView abstractvalueview = (AbstractValueView) aobj[1];
				AttributeDefDefaultView attributedefdefaultview = (AttributeDefDefaultView) aobj[0];
				if (abstractvalueview.getState() == 1) {
					defaultAttributeContainer
							.deleteAttributeValues(attributedefdefaultview);
					abstractvalueview.setState(3);
					defaultAttributeContainer
							.addAttributeValue(abstractvalueview);
				}
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		defaultAttributeContainer.setConstraintParameter(new String("CSM"));
		ibaholder.setAttributeContainer(defaultAttributeContainer);
		return ibaholder;
	}

	public void setIBAValue(String s, String s1) throws Exception {
		AbstractValueView abstractvalueview = null;
		AttributeDefDefaultView attributedefdefaultview = null;
		Object aobj[] = (Object[]) ibaContainer.get(s);
		if (aobj != null) {
			abstractvalueview = (AbstractValueView) aobj[1];
			attributedefdefaultview = (AttributeDefDefaultView) aobj[0];
		}
		if (abstractvalueview == null)
			attributedefdefaultview = getAttributeDefinition(s);
		if (attributedefdefaultview == null) {
			logger.debug("ext.facri2.util.IBAUtil>>>definition is null ...");
			return;
		}
		abstractvalueview = internalCreateValue(attributedefdefaultview, s1);
		if (abstractvalueview == null) {
			logger.debug("ext.pax.util.IBAUtil>>>after creation, iba value is null ..");
			return;
		} else {
			abstractvalueview.setState(1);
			Object aobj1[] = new Object[2];
			aobj1[0] = attributedefdefaultview;
			aobj1[1] = abstractvalueview;
			ibaContainer.put(attributedefdefaultview.getName(),
					((Object) (aobj1)));
			return;
		}
	}

	 public IBAHolder store(IBAHolder ibaholder) throws Exception {
		    ibaholder = IBAValueHelper.service.refreshAttributeContainer(ibaholder, null,
		        SessionHelper.manager.getLocale(), null);
		    DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer)ibaholder
		        .getAttributeContainer();
		    Iterator iter = ibaContainer.values().iterator();
		    while(iter.hasNext())
		      try{
		        Object aobj[] = (Object[])iter.next();
		        AbstractValueView abstractvalueview = (AbstractValueView)aobj[1];
		        AttributeDefDefaultView attributedefdefaultview = (AttributeDefDefaultView)aobj[0];
		        if(abstractvalueview.getState()==1){
		          defaultattributecontainer.deleteAttributeValues(attributedefdefaultview);
		          abstractvalueview.setState(3);
		          defaultattributecontainer.addAttributeValue(abstractvalueview);
		        }
		      }catch(Exception exception){
		        exception.printStackTrace();
		      }
		    ibaholder.setAttributeContainer(defaultattributecontainer);
		    return ibaholder;
		  }
	 
	 
	private AttributeDefDefaultView getAttributeDefinition(String s) {
		AttributeDefDefaultView attributedefdefaultview = null;
		try {
			attributedefdefaultview = IBADefinitionHelper.service
					.getAttributeDefDefaultViewByPath(s);
			if (attributedefdefaultview == null) {
				AbstractAttributeDefinizerView abstractattributedefinizerview = DefinitionLoader
						.getAttributeDefinition(s);
				if (abstractattributedefinizerview != null)
					attributedefdefaultview = IBADefinitionHelper.service
							.getAttributeDefDefaultView((AttributeDefNodeView) abstractattributedefinizerview);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return attributedefdefaultview;
	}

	private AbstractValueView internalCreateValue(
			AbstractAttributeDefinizerView abstractattributedefinizerview,
			String s) throws Exception {
		AbstractValueView abstractvalueview = null;
		try {
			if (abstractattributedefinizerview instanceof FloatDefView)
				abstractvalueview = LoadValue.newFloatValue(
						abstractattributedefinizerview, s, null);
			else if (abstractattributedefinizerview instanceof StringDefView)
				abstractvalueview = LoadValue.newStringValue(
						abstractattributedefinizerview, s);
			else if (abstractattributedefinizerview instanceof IntegerDefView)
				abstractvalueview = LoadValue.newIntegerValue(
						abstractattributedefinizerview, s);
			else if (abstractattributedefinizerview instanceof RatioDefView)
				abstractvalueview = LoadValue.newRatioValue(
						abstractattributedefinizerview, s, null);
			else if (abstractattributedefinizerview instanceof TimestampDefView)
				abstractvalueview = LoadValue.newTimestampValue(
						abstractattributedefinizerview, s);
			else if (abstractattributedefinizerview instanceof BooleanDefView)
				abstractvalueview = LoadValue.newBooleanValue(
						abstractattributedefinizerview, s);
			else if (abstractattributedefinizerview instanceof URLDefView)
				abstractvalueview = LoadValue.newURLValue(
						abstractattributedefinizerview, s, null);
			else if (abstractattributedefinizerview instanceof ReferenceDefView)
				abstractvalueview = LoadValue.newReferenceValue(
						abstractattributedefinizerview, "ClassificationNode", s);
			else if (abstractattributedefinizerview instanceof UnitDefView)
				abstractvalueview = LoadValue.newUnitValue(
						abstractattributedefinizerview, s, null);
		} catch (Exception exception) {
			throw exception;
		}
		return abstractvalueview;
	}

	public boolean createIBAValue(String definition, String value1,
			String value2, String dependency_id) {
		boolean flag = true;
		if (definition == null || definition == "")
			flag = false;

		if (defaultAttributeContainer == null)
			defaultAttributeContainer = new DefaultAttributeContainer();

		if (defaultAttributeContainer == null) {
			logger.debug("ext.pax.util.IBAUtil>>>Can't initinalize defaultAttributeContainer ..");
			flag = false;
		}

		AbstractAttributeDefinizerView abstractattributedefinizerview = null;
		if (flag) {
			abstractattributedefinizerview = definitionCache
					.getCachedAttributeDefinition(definition);
			if (abstractattributedefinizerview == null) {
				logger.debug("ext.pax.util.IBAUtil>>>Could not find definition for :"+ definition);
				flag = false;
			}
		}
		String s4 = null;
		AbstractValueView abstractvalueview = null;
		if (flag) {
			s4 = "Attribute <" + definition + ">=<" + value1 + "><" + value2
					+ "> dep_id=" + dependency_id;
			if (abstractattributedefinizerview instanceof UnitDefView)
				value2 = parseMultiUnits(abstractattributedefinizerview, value2);

			try {
				abstractvalueview = internalCreateValue(
						abstractattributedefinizerview, value2);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (abstractvalueview == null) {
				logger.debug("ext.pax.util.IBAUtil>>>Error Creating value " + s4);
				flag = false;
			}
		}
		if (flag)
			try {
				if (flag) {
					((DefaultAttributeContainer) defaultAttributeContainer)
							.addAttributeValue(abstractvalueview);
					// System.out.println("--> Attribute added.");
				}
			} catch (Exception exception) {
				// Exception.printStackTrace();
				flag = false;
			}
		if (!flag)
			logger.debug("ext.pax.util.IBAUtil>>>Unknown reason stopped to add :" + definition+ " with value:" + value2);
		return flag;
	}

	public boolean removeCSMConstraint() {
		// AttributeContainer attributecontainer = getCurrentCachedContainer();
		if (defaultAttributeContainer == null) {
			// System.out.println("ERROR(removeCSMConstraint): the Container is
			// null!");
			return false;
		}

		// System.out.println("Start
		// ClassificationNodeLoader.printAttributeContainer(defaultAttributeContainer);");

		ClassificationNodeLoader
				.printAttributeContainer(defaultAttributeContainer);
		Object obj = ((DefaultAttributeContainer) defaultAttributeContainer)
				.getConstraintParameter();
		if (obj == null) {
			// System.out.println("((DefaultAttributeContainer)defaultAttributeContainer).getConstraintParameter()
			// is null");
			obj = new String("CSM");
		} else if (obj instanceof Vector) {
			// System.out.println("((DefaultAttributeContainer)defaultAttributeContainer).getConstraintParameter()
			// is vector !");
			((Vector) obj).addElement(new String("CSM"));
		} else {
			Vector vector1 = new Vector();
			vector1.addElement(obj);
			obj = vector1;
			((Vector) obj).addElement(new String("CSM"));
		}
		try {
			((DefaultAttributeContainer) defaultAttributeContainer)
					.setConstraintParameter(obj);
			// System.out.println("After
			// set"+((DefaultAttributeContainer)defaultAttributeContainer).getConstraintParameter().toString());
		} catch (WTPropertyVetoException wtpropertyvetoexception) {
			// System.out.println("Cannot set ConstraintParameter!");
			wtpropertyvetoexception.printStackTrace();
			return false;
		}
		return true;
	}

	public IBAHolder applySoftAttributes(IBAHolder ibaholder)
			throws WTException {
		try {
			// endIBAContainer();
			// DefaultAttributeContainer defaultattributecontainer =
			// (DefaultAttributeContainer)extractDefaultIBAContainer();
			AttributeDefDefaultView aattributedefdefaultview[] = defaultAttributeContainer != null ? defaultAttributeContainer
					.getAttributeDefinitions()
					: null;
			if (aattributedefdefaultview != null
					&& aattributedefdefaultview.length > 0) {
				ibaholder = refreshSoftAttributes(ibaholder);
				DefaultAttributeContainer defaultattributecontainer1 = (DefaultAttributeContainer) ibaholder
						.getAttributeContainer();
				if (defaultattributecontainer1 == null) {
					// System.out.println("OOTB container is null");
					ibaholder.setAttributeContainer(defaultAttributeContainer);
				} else {
					// System.out.println("OOTB already have container");
					for (int i = 0; i < aattributedefdefaultview.length; i++) {
						AbstractValueView aabstractvalueview[] = defaultattributecontainer1
								.getAttributeValues(aattributedefdefaultview[i]);
						if (aabstractvalueview != null
								&& aabstractvalueview.length > 0) {
							for (int j = 0; j < aabstractvalueview.length; j++)
								defaultattributecontainer1
										.deleteAttributeValue(aabstractvalueview[j]);

						}
					}

					AbstractValueView aabstractvalueview1[] = defaultAttributeContainer
							.getAttributeValues();
					if (aabstractvalueview1 != null
							&& aabstractvalueview1.length > 0) {
						for (int k = 0; k < aabstractvalueview1.length; k++)
							defaultattributecontainer1
									.addAttributeValue(aabstractvalueview1[k]);

					}
					if (defaultAttributeContainer.getConstraintParameter() == null)
						// System.out.println("defaultAttributeContainer.getConstraintParameter()
						// is null!");

						defaultattributecontainer1
								.setConstraintParameter(defaultAttributeContainer
										.getConstraintParameter());
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			throw new WTException(exception.getMessage());
		}
		if (ibaholder instanceof Typed) {
			// System.out.println("it is a typed object!");
			ibaholder = applyTypeAttributeDefaults((Typed) ibaholder);
		}
		// ibaholder = storeSoftAttributes(ibaholder);
		return ibaholder;
	}
	
	/**	
	 * 根据名称获取分类节点
	 * @param name
	 * @return
	 * @throws WTException
	 */
	public static LWCStructEnumAttTemplate getStructureEum(String name)throws WTException {
		LWCStructEnumAttTemplate result = null;
		QuerySpec queryspec = new QuerySpec(LWCStructEnumAttTemplate.class);
		queryspec.appendWhere(new SearchCondition(LWCStructEnumAttTemplate.class,
				LWCStructEnumAttTemplate.NAME, "=", name), new int[] {});
//		queryspec.appendAnd();
//		queryspec.appendWhere(new SearchCondition(LWCStructEnumAttTemplate.class,
//				LWCStructEnumAttTemplate.DELETED_ID, SearchCondition.IS_NULL), new int[] {});
		QueryResult qr = PersistenceServerHelper.manager.query(queryspec);
		while (qr.hasMoreElements()) {
			result = (LWCStructEnumAttTemplate) qr.nextElement();
			if(StringUtils.isBlank(result.getDeletedId())){
				return result;
			}
		}
		return result;
	}

	
	 /**
	 * @author kanson
	 * 2010-01-10
	 * @param ibaholder　对象
	 * 查询分类　 软属性值
	 * @param ibaName　软属性名
	 * @return
	 */
	public  String  getSyncIBAValue(IBAHolder ibaholder,String ibaName)
	  {
		  String ibavalue=null;
	    try
	    {
	      ibaholder = IBAValueHelper.service.refreshAttributeContainer(ibaholder, null, SessionHelper.manager.getLocale(), null);
	      DefaultAttributeContainer dac = (DefaultAttributeContainer)ibaholder.getAttributeContainer();
	      if (dac == null) return null;
	      AttributeDefDefaultView[] attrdefdefaultview = dac.getAttributeDefinitions();
	      for (int i = 0; i < attrdefdefaultview.length; ++i)
	      {
	        AbstractValueView[] abstractvalueview = dac.getAttributeValues(attrdefdefaultview[i]);
	        if (abstractvalueview != null) {
	          String columnName = attrdefdefaultview[i].getName();
	          String columnValue = abstractvalueview[0].getLocalizedDisplayString();
	          
	          if (abstractvalueview[0] instanceof ReferenceValueDefaultView) {
	            ReferenceValueDefaultView rvdv = (ReferenceValueDefaultView)abstractvalueview[0];
	            ClassificationNodeDefaultView cndv = ClassificationHelper.service.getClassificationNodeDefaultView(rvdv.getLiteIBAReferenceable());
//	             String classPath = getClassificationPath(cndv.getHierarchyID());//分类路径
//	            System.out.println("columnName===" + columnName);
//	            System.out.println("columnValue===" + columnValue);
//	            System.out.println("classPath===" + classPath);
	          }else{
	        	  System.out.println("columnName===" + columnName);
		          System.out.println("columnValue===" + columnValue);
	            if(columnName!=null&&columnName.equals(ibaName)){
	        	  ibavalue=columnValue;
	        	  break;
	            }
	          }
	        }
	      }
	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	    }
	    return ibavalue;
	  }

	    /**
		 * 获取分类路径
		 *
		 * @param hierarchyID
		 * @return
		 */
		  private static String getClassificationPath(String hierarchyID)
		  {
		    StringTokenizer st = new StringTokenizer(hierarchyID, "/");
		    ArrayList al = new ArrayList();
		    String hID = "";
		    while (st.hasMoreTokens()) {
		      String str = st.nextToken();
		      if (hID.equals(""))
		        hID = str;
		      else {
		        hID = hID + "/" + str;
		      }
		      al.add(hID);
		    }
		    try {
		      QuerySpec queryspec = new QuerySpec();
		      queryspec.setAdvancedQueryEnabled(true);
		      int i = queryspec.appendClassList(ClassificationNode.class, false);
		      ClassAttribute nameAttr = new ClassAttribute(ClassificationNode.class, "name");
		      ClassAttribute hIDAttr = new ClassAttribute(ClassificationNode.class, "hierarchyID");
		      queryspec.appendSelect(nameAttr, false);
		      queryspec.appendSelect(hIDAttr, false);
		      ArrayExpression arrayexpression = new ArrayExpression(al.toArray());
		      queryspec.appendWhere(new SearchCondition(hIDAttr, "IN", arrayexpression), new int[] { i });
		      queryspec.appendOrderBy(new OrderBy(hIDAttr, false), new int[] { i });
		      QueryResult qr = PersistenceServerHelper.manager.query(queryspec);
		      String classPath = "";
		      while (qr.hasMoreElements()) {
		        Object[] obj = (Object[])qr.nextElement();
		        if (classPath.equals(""))
		          classPath = (String)obj[0];
		        else {
		          classPath = classPath + "/" + ((String)obj[0]);
		        }
		      }
		      return classPath;
		    } catch (QueryException e) {
		      e.printStackTrace();
		    } catch (WTException e) {
		      e.printStackTrace();
		    }
		    return null;
		  }
	
	public IBAHolder insertIBAHolder(IBAHolder ibaholder) throws Exception {
		ibaholder = IBAValueHelper.service.refreshAttributeContainer(ibaholder,
				null, SessionHelper.manager.getLocale(), null);
		DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer) (IBAValueHelper.service
				.refreshAttributeContainerWithoutConstraints(ibaholder))
				.getAttributeContainer();
		for (Enumeration enumeration = ibaContainer.elements(); enumeration
				.hasMoreElements();) {
			try {
				Object aobj[] = (Object[]) enumeration.nextElement();
				AbstractValueView abstractvalueview = (AbstractValueView) aobj[1];
				AttributeDefDefaultView attributedefdefaultview = (AttributeDefDefaultView) aobj[0];
				if (abstractvalueview.getState() == 1) {
					defaultAttributeContainer
							.deleteAttributeValues(attributedefdefaultview);
					abstractvalueview.setState(3);
					defaultAttributeContainer
							.addAttributeValue(abstractvalueview);
				}
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		defaultAttributeContainer.setConstraintParameter(new String("CSM"));
		ibaholder.setAttributeContainer(defaultAttributeContainer);

		IBAValueDBService ibavaluedbservice = new IBAValueDBService();
		ibaholder.setAttributeContainer(ibavaluedbservice.updateAttributeContainer(ibaholder, defaultAttributeContainer
						.getConstraintParameter(), null, null));
		return ibaholder;
	}
	
	public IBAHolder updateIBAHolder(IBAHolder ibaholder) throws Exception {
		ibaholder = IBAValueHelper.service.refreshAttributeContainer(ibaholder,
				null, SessionHelper.manager.getLocale(), null);
		DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer) (IBAValueHelper.service
				.refreshAttributeContainerWithoutConstraints(ibaholder))
				.getAttributeContainer();
		for (Enumeration enumeration = ibaContainer.elements(); enumeration
				.hasMoreElements();) {
			try {
				Object aobj[] = (Object[]) enumeration.nextElement();
				AbstractValueView abstractvalueview = (AbstractValueView) aobj[1];
				AttributeDefDefaultView attributedefdefaultview = (AttributeDefDefaultView) aobj[0];
				if (abstractvalueview.getState() == 1) {
					defaultAttributeContainer.deleteAttributeValues(attributedefdefaultview);
					abstractvalueview.setState(3);
					defaultAttributeContainer.addAttributeValue(abstractvalueview);
				}
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		defaultAttributeContainer.setConstraintParameter(new String("CSM"));
		ibaholder.setAttributeContainer(defaultAttributeContainer);

		IBAValueDBService ibavaluedbservice = new IBAValueDBService();
		ibaholder.setAttributeContainer(ibavaluedbservice.updateAttributeContainer(ibaholder, defaultAttributeContainer
						.getConstraintParameter(), null, null));

		return ibaholder;
	}
	
	private IBAHolder applyTypeAttributeDefaults(IBAHolder ibaholder)
			throws WTException {
		if (ibaholder instanceof Typed) {
			com.ptc.core.meta.common.TypeInstanceIdentifier typeinstanceidentifier = TypeIdentifierUtility
					.getTypeInstanceIdentifier(ibaholder);
			com.ptc.core.meta.type.common.TypeInstance typeinstance = TypeInstanceFactory
					.newTypeInstance(typeinstanceidentifier);
			TypeInstanceUtility.populateMissingTypeContent(typeinstance, null);
			boolean flag = false;
			com.ptc.core.meta.common.AttributeIdentifier aattributeidentifier[] = typeinstance
					.getAttributeIdentifiers();
			for (int i = 0; !flag && i < aattributeidentifier.length; i++)
				flag = (aattributeidentifier[i] instanceof InstanceBasedAttributeIdentifier)
						|| (aattributeidentifier[i] instanceof InstanceBasedAssociationIdentifier);

			if (flag) {
				if (ibaholder.getAttributeContainer() == null)
					ibaholder = refreshSoftAttributes(ibaholder);
				com.ptc.core.meta.common.TypeInstanceIdentifier typeinstanceidentifier1 = TypeIdentifierUtility
						.getTypeInstanceIdentifier(ibaholder);
				if (!typeinstanceidentifier1.equals(typeinstanceidentifier)) {
					typeinstance = TypeInstanceFactory
							.newTypeInstance(typeinstanceidentifier1);
					TypeInstanceUtility.populateMissingTypeContent(
							typeinstance, null);
				}
				DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer) ibaholder
						.getAttributeContainer();
				if (defaultattributecontainer != null) {
					AttributeDefDefaultView aattributedefdefaultview[] = defaultattributecontainer
							.getAttributeDefinitions();
					for (int j = 0; j < aattributedefdefaultview.length; j++) {
						String s = IBAModel
								.getExternalHid(aattributedefdefaultview[j]
										.getHierarchyID());
						typeinstance
								.purge(new InstanceBasedAttributeTypeIdentifier(
										s, new WCTypeIdentifier(ibaholder
												.getClass().getName())));
					}

				}
				TypeInstanceUtility.updateIBAValues(ibaholder, typeinstance);
			}
		}
		return ibaholder;
	}

	private IBAHolder refreshSoftAttributes(IBAHolder ibaholder)
			throws WTException {
		try {
			return IBAValueHelper.service.refreshAttributeContainer(ibaholder,
					"CSM", null, null);
		} catch (Exception exception) {
			exception.printStackTrace();
			throw new WTException(exception.getMessage());
		}
	}

	private String parseMultiUnits(
			AbstractAttributeDefinizerView abstractattributedefinizerview,
			String value) {
		if (value != null)
			value = value.trim();

		if (value == null || value.equals("") || value.length() < 1)
			return "0.0";

		try {
			double d = Double.valueOf(value).doubleValue();
		} catch (Exception e) {
			return value;
		}

		if (value.indexOf(".") < 0)
			value = value + ".0";

		value = value
				+ "\t"
				+ definitionCache
						.getCachedDefaultUnit(abstractattributedefinizerview
								.getName());

		return value;
	}
	
	
	/**
	 * 根据软属性(字符串类型)的名称获取其显示名称
	 * @param String key
	 * @return String name
	 * @author zhongwenchang 2012-08-30
	 */
	public static String getDisNameByKey(String key){
		QueryResult qr = null;
		String name = "";
		if(key==null || "".equals(key.trim())){
			return name;
		}
		try {
			QuerySpec qs = new QuerySpec(StringDefinition.class);
			SearchCondition sc = new SearchCondition(StringDefinition.class,
					StringDefinition.NAME, SearchCondition.EQUAL, key.trim());
			qs.appendSearchCondition(sc);
			qr = PersistenceHelper.manager.find(qs);
			if (qr != null && qr.hasMoreElements()) {
				StringDefinition definition = (StringDefinition)qr.nextElement();
				name = definition.getDisplayName();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return name;
	}
	
	public static String getObjectType(Object obj) {
		String type = "";
		try {
			type = TypedUtilityServiceHelper.service.getExternalTypeIdentifier(obj);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return type;
	}
	/**
	 * 
	 * @param ibaholder
	 * @return
	 */
	public static Map<String, String> getIBAValue(IBAHolder ibaholder) {
		Map<String, String> map = new HashMap<String, String>();
		try {
			ibaholder = IBAValueHelper.service.refreshAttributeContainer(
					ibaholder, null, SessionHelper.manager.getLocale(), null);
			DefaultAttributeContainer dac = (DefaultAttributeContainer) ibaholder.getAttributeContainer();// 得到软属性容器
			
			System.out.println("dac------>"+ dac);
			
			if (dac != null) {
				AttributeDefDefaultView[] attrdefdefaultview = dac.getAttributeDefinitions();
				
				System.out.println("attrdefdefaultview----->"+ attrdefdefaultview.length);
				
				for (int i = 0; i < attrdefdefaultview.length; ++i) {
					AbstractValueView[] abstractvalueview = dac.getAttributeValues(attrdefdefaultview[i]);
					System.out.println("abstractvalueview----------->"+ abstractvalueview);
					if (abstractvalueview != null) {
						String attributeName = attrdefdefaultview[i].getName();// 得到软属性的名字
						// 得到软属性的值
						String attributeValue = abstractvalueview[0].getLocalizedDisplayString();
						System.out.println(abstractvalueview[0]+ "---attributeValue---->"+ attributeValue);
						// 判断是否是最后一阶分类
						if (abstractvalueview[0] instanceof ReferenceValueDefaultView) {
							
						} else {
							System.out.println(attributeName + "="+ attributeValue);
							map.put(attributeName, attributeValue);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}
	
	public static DefaultAttributeContainer getContainer(IBAHolder ibaHolder)
	throws WTException, RemoteException
{
	ibaHolder = IBAValueHelper.service.refreshAttributeContainerWithoutConstraints(ibaHolder);
	DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer)ibaHolder.getAttributeContainer();
	return defaultattributecontainer;
}
		 
	/**
	 * @description 得到对象的自定义类型
	 * @param obj  
	 * @return String  
	 * @throws WTException
	 */
	public static String getTypeName(WTObject obj) {
		String typeDisplayName = null;
		TypeDefinitionReference ref = null;
		WTTypeDefinition definition = null;
		if (obj instanceof WTPart) {
			ref = ((WTPart) obj).getTypeDefinitionReference();
			try {
				@SuppressWarnings("deprecation")
				TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities
						.getTypeDefinition(ref);
				definition = (WTTypeDefinition) PersistenceHelper.manager
						.refresh(view.getObjectID());
				typeDisplayName = definition.getName(); //类型内部名称
				// System.out.println(typeDisplayName+"-------------");
			} catch (WTException e) {
				e.printStackTrace();
			}
		}
		if (obj instanceof WTDocument) {
			ref = ((WTDocument) obj).getTypeDefinitionReference();
			try {
				@SuppressWarnings("deprecation")
				TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities
						.getTypeDefinition(ref);
				definition = (WTTypeDefinition) PersistenceHelper.manager
						.refresh(view.getObjectID());
				typeDisplayName = definition.getName(); //类型内部名称
				// System.out.println(typeDisplayName+"-------------");
			} catch (WTException e) {
				e.printStackTrace();
			}
		}
	
		return typeDisplayName;
	}
	public void setIBAAttribute4AllType(IBAHolder holder, String typeName, Object value) throws Exception {

		AttributeDefDefaultView view = getAttributeDefinition(typeName);
		if (view == null) {
			//			throw new Exception("属性[" + typeName + "]不存在");
			return;
		}
		if (view instanceof FloatDefView) {
			if (value != null) {
				if (value instanceof Double) {
					IBAUtil.newIBAFloatAttribute(holder, typeName, (double) value);
				} else {
					double d = Double.parseDouble(value.toString());
					IBAUtil.newIBAFloatAttribute(holder, typeName, d);
				}
			}
		} else if (view instanceof StringDefView) {
			if (value != null) {
				if (value instanceof String) {
					IBAUtil.newIBAAttribute(holder, typeName, (String) value);
				} else {
					IBAUtil.newIBAAttribute(holder, typeName, value.toString());
				}
			}
		} else if (view instanceof URLDefView) {
			if (value != null) {
				IBAUtil.newIBAURLAttribute(holder, typeName, value.toString(), value.toString());
			} else {
				IBAUtil.newIBAURLAttribute(holder, typeName, "", "");
			}
		} else if (view instanceof IntegerDefView) {
			if (value != null) {
				if (value instanceof Integer) {
					IBAUtil.newIBAIntAttribute(holder, typeName, (Integer) value);
				} else {
					int it = Integer.parseInt(value.toString());
					IBAUtil.newIBAIntAttribute(holder, typeName, it);
				}
			}
		} else if (view instanceof TimestampDefView) {
			if (value != null) {
				if (value instanceof Date) {
					Date date = (Date) value;
					Timestamp ts = new Timestamp(date.getTime());
					IBAUtil.newIBATimeAttribute(holder, typeName, ts);
				} else {
				}
			}
		} else if (view instanceof BooleanDefView) {
			if (value != null) {
				if (value instanceof Boolean) {
					IBAUtil.newIBABooleanAttribute(holder, typeName, (Boolean) value);
				} else {
					IBAUtil.newIBABooleanAttribute(holder, typeName, Boolean.parseBoolean((String) value));
				}
			}
		} else {
		}
	}



	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 *
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static BooleanDefinition findBooleanDefinition(String attributeName) throws WTException {
		BooleanDefinition sDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(BooleanDefinition.class, true);
		WhereExpression where = new SearchCondition(BooleanDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof BooleanDefinition) {
					sDef = (BooleanDefinition) obj;
				}
			}
		}
		return sDef;
	}


	/**
	 * 获取软属性对象
	 *
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public BooleanValue getBooleanValueByName(String attributeName) throws WTException {
		BooleanValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			BooleanValueDefaultView intvalue = (BooleanValueDefaultView) view;

			ObjectIdentifier objectidentifier = intvalue.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (BooleanValue) persistable;
		}
		return value;
	}
	/**
	 * 设置对象软属性的值，但不检出对象
	 *
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBABooleanAttribute(IBAHolder holder, String typeName, boolean value) throws WTException {
		try {
			IBAUtil util = new IBAUtil(holder);
			BooleanDefinition fd = findBooleanDefinition(typeName);
			if (fd != null) {
				BooleanValue iv = util.getBooleanValueByName(typeName);
				if (iv != null) {
					iv.setValue(value);
					PersistenceServerHelper.manager.update(iv);
					// PersistenceHelper.manager.save(sv);
				} else {
					iv = BooleanValue.newBooleanValue(fd, holder, value);
					PersistenceServerHelper.manager.insert(iv);
				}
			} else {
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 *
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static TimestampDefinition findTimestampDefinition(String attributeName) throws WTException {
		TimestampDefinition fDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(TimestampDefinition.class, true);
		WhereExpression where = new SearchCondition(TimestampDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof TimestampDefinition) {
					fDef = (TimestampDefinition) obj;
				}
			}
		}
		return fDef;
	}
	
	
	
	/**
	 * 设置对象软属性的值，但不检出对象
	 *
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBATimeAttribute(IBAHolder holder, String typeName, Object value) throws WTException {
		try {
			if (value instanceof Timestamp) {
				Timestamp ts = (Timestamp) value;
				IBAUtil util = new IBAUtil(holder);
				TimestampDefinition sd = findTimestampDefinition(typeName);
				if (sd != null) {
					TimestampValue sv = util.getTimestampValue(typeName);
					if (sv != null) {
						if (value == null) {
							PersistenceHelper.manager.delete(sv);
						} else {
							sv.setValue(ts);
							PersistenceServerHelper.manager.update(sv);
						}
					} else {
						sv = TimestampValue.newTimestampValue(sd, holder, ts);
						PersistenceServerHelper.manager.insert(sv);
					}
				}

			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 获取时间格式的数据
	 *
	 * @param attributeName
	 * @return
	 * @throws WTException
	 */
	public TimestampValue getTimestampValue(String attributeName) throws WTException {
		TimestampValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {
			AbstractValueView view = (AbstractValueView) objs[1];
			if (view instanceof TimestampValueDefaultView) {
				TimestampValueDefaultView tsvaluedefaultview = (TimestampValueDefaultView) view;
				ObjectIdentifier objectidentifier = tsvaluedefaultview.getObjectID();
				Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
				if (persistable instanceof TimestampValue) {
					value = (TimestampValue) persistable;
				}
			}
		}
		return value;
	}

	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 *
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static IntegerDefinition findIntDefinition(String attributeName) throws WTException {
		IntegerDefinition sDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(IntegerDefinition.class, true);
		WhereExpression where = new SearchCondition(IntegerDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof IntegerDefinition) {
					sDef = (IntegerDefinition) obj;
				}
			}
		}
		return sDef;
	}


	/**
	 * 获取软属性对象
	 *
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public IntegerValue getIntValueByName(String attributeName) throws WTException {
		IntegerValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			IntegerValueDefaultView intvalue = (IntegerValueDefaultView) view;

			ObjectIdentifier objectidentifier = intvalue.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (IntegerValue) persistable;
		}
		return value;
	}
	/**
	 * 设置对象软属性的值，但不检出对象
	 *
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAIntAttribute(IBAHolder holder, String typeName, long value) throws WTException {
		try {
			IBAUtil util = new IBAUtil(holder);
			IntegerDefinition fd = findIntDefinition(typeName);
			if (fd != null) {
				IntegerValue iv = util.getIntValueByName(typeName);
				if (iv != null) {
					iv.setValue(value);
					PersistenceServerHelper.manager.update(iv);
					// PersistenceHelper.manager.save(sv);
				} else {
					iv = IntegerValue.newIntegerValue(fd, holder, value);
					PersistenceServerHelper.manager.insert(iv);
				}
			} else {
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}
	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 *
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static URLDefinition findURLDefinition(String attributeName) throws WTException {
		URLDefinition fDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(URLDefinition.class, true);
		WhereExpression where = new SearchCondition(URLDefinition.class, "name", SearchCondition.EQUAL, attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof URLDefinition) {
					fDef = (URLDefinition) obj;
				}
			}
		}
		return fDef;
	}


	/**
	 * 获取软属性对象
	 *
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public URLValue getURLValueByName(String attributeName) throws WTException {
		URLValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			URLValueDefaultView urlValuedefaultview = (URLValueDefaultView) view;

			ObjectIdentifier objectidentifier = urlValuedefaultview.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (URLValue) persistable;

		}
		return value;
	}


	/**
	 * 设置对象软属性的值，但不检出对象
	 *
	 * @param holder
	 * @param typeName
	 * @param value
	 * @param des      : 连接描述
	 * @throws WTException
	 */
	public static void newIBAURLAttribute(IBAHolder holder, String typeName, String value, String des)
			throws WTException {
		try {
			IBAUtil util = new IBAUtil(holder);
			URLDefinition fd = findURLDefinition(typeName);
			if (fd != null) {

				URLValue fv = util.getURLValueByName(typeName);
				if (fv != null) {
					if (value == null || value.trim().length() == 0) {
						PersistenceHelper.manager.delete(fv);
					} else {
						fv.setDescription(des);
						fv.setValue(value);
						PersistenceServerHelper.manager.update(fv);
					}
				} else {
					fv = URLValue.newURLValue(fd, holder, value, des);
					PersistenceServerHelper.manager.insert(fv);
				}
			} else {
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 获取软属性对象
	 *
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public FloatValue getFloatValueByName(String attributeName) throws WTException {
		FloatValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			FloatValueDefaultView floatvaluedefaultview = (FloatValueDefaultView) view;

			ObjectIdentifier objectidentifier = floatvaluedefaultview.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (FloatValue) persistable;
		}
		return value;
	}




	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 *
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static FloatDefinition findFloatDefinition(String attributeName) throws WTException {
		FloatDefinition fDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(FloatDefinition.class, true);
		WhereExpression where = new SearchCondition(FloatDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof FloatDefinition) {
					fDef = (FloatDefinition) obj;
				}
			}
		}
		return fDef;
	}
	
	public static void newIBAFloatAttribute(IBAHolder holder, String typeName, double value) throws WTException {
		try {
			IBAUtil util = new IBAUtil(holder);
			FloatDefinition fd = findFloatDefinition(typeName);
			if (fd != null) {
				// 默认保留三位小数
				int paramInt = 3;
				if (value == 0 || value == 1) {
					paramInt = 0;
				} else {
					String t = Double.toString(value);
					if (t.indexOf(".") > -1) {
						t = t.substring(t.indexOf(".") + 1, t.length());
						while (t.startsWith("0")) {
							t = t.replaceFirst("0", "");
						}
						paramInt = t.length();
					} else {
						// 没有小数点，则保留0位
						paramInt = 0;
					}
				}
				FloatValue fv = util.getFloatValueByName(typeName);
				if (fv != null) {
					fv.setValue(value);
					fv.setPrecision(paramInt);
					PersistenceServerHelper.manager.update(fv);
					// PersistenceHelper.manager.save(sv);
				} else {
					fv = FloatValue.newFloatValue(fd, holder, value, paramInt);
					PersistenceServerHelper.manager.insert(fv);
				}
			} else {
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}



	/**
	 * 获取软属性对象
	 *
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public StringValue getStringValueByName(String attributeName) throws WTException {
		StringValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			StringValueDefaultView stringvaluedefaultview = (StringValueDefaultView) view;
			ObjectIdentifier objectidentifier = stringvaluedefaultview.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (StringValue) persistable;
		}
		return value;
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 *
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAAttribute(IBAHolder holder, String typeName, String value) throws WTException {
		try {
			IBAUtil util = new IBAUtil(holder);
			StringDefinition sd = findStringDefinition(typeName);
			if (sd != null) {
				StringValue sv = util.getStringValueByName(typeName);
				if (sv != null) {
					//					LOGGER.debug("对象["+holder.toString()+"]属性["+sd.getName()+"]旧值为["+sv.getValue()+"]");
					if (value == null || value.trim().length() == 0) {
						PersistenceHelper.manager.delete(sv);
					} else {
						sv.setValue(value);
						PersistenceServerHelper.manager.update(sv);
					}
				} else {
					sv = StringValue.newStringValue(sd, holder, value);
					PersistenceServerHelper.manager.insert(sv);
				}
			} else {
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}





	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 *
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static StringDefinition findStringDefinition(String attributeName) throws WTException {
		StringDefinition sDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(StringDefinition.class, true);
		WhereExpression where = new SearchCondition(StringDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof StringDefinition) {
					sDef = (StringDefinition) obj;
				}
			}
		}
		return sDef;
	}
}
