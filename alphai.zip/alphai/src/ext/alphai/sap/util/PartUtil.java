package ext.alphai.sap.util;

import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.lwc.client.commands.LWCCommands;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.server.*;
import com.ptc.core.meta.common.IdentifierFactory;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.windchill.enterprise.part.commands.AssociationLinkObject;
import com.ptc.windchill.enterprise.part.commands.PartDocServiceCommand;
import com.ptc.windchill.enterprise.workflow.WorkflowCommands;
import ext.jiecang.erp.Config;
import ext.jiecang.erp.util.DocUtil;
import ext.jiecang.erp.util.GenericUtil;
import ext.jiecang.erp.util.IBAUtil;
import ext.jiecang.erp.util.PartView;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.configuration.TraceCode;
//import wt.csm.navigation.CSMClassificationNavigationException;
//import wt.csm.navigation.ClassificationNode;
//import wt.csm.navigation.litenavigation.ClassificationNodeDefaultView;
//import wt.csm.navigation.service.ClassificationHelper;
//import wt.csm.navigation.service.ClassificationObjectsFactory;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.epm.EPMAuthoringAppType;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentType;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.*;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.folder.CabinetBased;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.StringValue;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.litevalue.StringValueDefaultView;
import wt.iba.value.service.IBAValueHelper;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.*;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.org.WTPrincipal;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.query.*;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.TypeDefinitionReference;
import wt.util.WTException;
import wt.util.WTInvalidParameterException;
import wt.util.WTPropertyVetoException;
import wt.vc.*;
import wt.vc.baseline.ManagedBaseline;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfState;

import java.io.File;
import java.rmi.RemoteException;
import java.util.*;
import java.util.Map.Entry;

public class PartUtil {
	private static final Logger log = Logger.getLogger(PartUtil.class);
	public static String PART_CLASSIFICATION_IBA = Config.get("sap.mm.function.classfication.iba");
	public static String CLASSIFICATION_SEPRATOR = "/";
	private static EPMDocumentType CADCOMPONENT = EPMDocumentType.toEPMDocumentType("CADCOMPONENT");//Proe图或autocad图
	private static EPMDocumentType CADASSEMBLY = EPMDocumentType.toEPMDocumentType("CADASSEMBLY");//proe图纸的asm
	private static EPMAuthoringAppType PROE = EPMAuthoringAppType.toEPMAuthoringAppType("PROE");//PROE工具，用于区分proe图和autocad图
	private static EPMDocumentType SCHEMATIC = EPMDocumentType.toEPMDocumentType("ECAD-SCHEMATIC");//原理图
	private static EPMDocumentType BOARD = EPMDocumentType.toEPMDocumentType("ECAD-BOARD");//pcb
	
	
	private static final IdentifierFactory IDENTIFIER_FACTORY = (IdentifierFactory) DefaultServiceProvider.getService(IdentifierFactory.class,"logical");
	// public static void main(String[] args) throws Exception {
	// WTPart part = getWTPartByNumber("0000009526");
	// part = (WTPart) PersistenceHelper.manager.refresh(part);
	// // System.out.println(getTypeName(part));
	// // WTDocument doc = DocUtil.getWTDocument("0000000781");
	// // List<WTPart> list = getPartByRefrenceDoc(doc);
	// // for(int i=0;i<list.size();i++){
	// // System.out.println(list.get(i).getNumber());
	// // }
	// }
	public static String rootPath = GenericUtil.CODEBASE_LOCATION +File.separator + "temp" + File.separator ;
	public static String tempPartSign = Config.get("tempPartSign", "L");
	
	
	
	/**
	 * @description 得到对象的自定义类型
	 * @param obj  
	 * @return String  
	 * @throws WTException
	 */
	public static String getTypeName(WTObject obj) {
		String typeDisplayName = null;
		TypeDefinitionReference ref = null;
		WTTypeDefinition definition = null;
		if (obj instanceof WTPart) {
			ref = ((WTPart) obj).getTypeDefinitionReference();
			try {
				@SuppressWarnings("deprecation")
				TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities
						.getTypeDefinition(ref);
				definition = (WTTypeDefinition) PersistenceHelper.manager
						.refresh(view.getObjectID());
				typeDisplayName = definition.getDisplayNameKey(); // 类型的key
				// System.out.println(typeDisplayName+"-------------");
			} catch (WTException e) {
				e.printStackTrace();
			}
		}
	
		return typeDisplayName;
	}

	/**
	 * @param part
	 *            部件对象 查找part的引用关系
	 * @return　QueryResult
	 * @throws WTException
	 */
	@SuppressWarnings("deprecation")
	public static QueryResult findWTPartUsageLinkBom(WTPart part)
			throws WTException {
		QueryResult rfdm1 = new QueryResult();
		if (part != null) {
			QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
			queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class,
					"roleAObjectRef.key", "=", PersistenceHelper
							.getObjectIdentifier(part)));
			queryspec.appendOrderBy(WTPartUsageLink.class,
					"thePersistInfo.theObjectIdentifier.id", false);
			rfdm1 = PersistenceHelper.manager.find((StatementSpec) queryspec);
		}
		return rfdm1;
	}

	/**
	 * 取得所有子部件的关联
	 * 
	 * @param parentPart
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Vector getSubPartUsagelinks(WTPart parentPart)
			throws WTException {
		Vector partlist = new Vector();
		QueryResult subParts = WTPartHelper.service
				.getUsesWTPartMasters(parentPart);
		while (subParts.hasMoreElements()) {
			WTPartUsageLink usagelink = (WTPartUsageLink) subParts
					.nextElement();
			WTPartMaster master = (WTPartMaster) usagelink.getUses();
			partlist.addElement(usagelink);
		}
		return partlist;
	}

	/**
	 * 根据编号查询part
	 * 
	 * @param number
	 * @return part
	 */
	public static WTPart getWTPartByNumber(String number) {
		WTPart result = null;
		QueryResult qr = null;
		try {
			QuerySpec qs = new QuerySpec(WTPart.class);
			SearchCondition scnumber = new SearchCondition(WTPart.class,
					WTPart.NUMBER, SearchCondition.EQUAL, number
							.toUpperCase());
			qs.appendSearchCondition(scnumber);
			qs.appendAnd();
			SearchCondition sclatest = VersionControlHelper.getSearchCondition(
					WTPart.class, true);
			qs.appendSearchCondition(sclatest);
			qr = PersistenceHelper.manager.find(qs);
			LatestConfigSpec cfg = new LatestConfigSpec();
			QueryResult qr1 = cfg.process(qr);
			if (qr1 != null && qr1.hasMoreElements()) {
				result = (WTPart) qr1.nextElement();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	
	// public static List getBomByPart(WTPart part){
	// try {
	// QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
	// List list = new ArrayList();
	// while (qr.hasMoreElements()) {
	// WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
	// QueryResult qr2 =
	// VersionControlHelper.service.allVersionsOf(usageLink.getUses());
	// if (qr2.hasMoreElements()) {
	// WTPart subPart = (WTPart) qr2.nextElement();
	// // System.out.println("subPart======="+subPart.getName());
	// list.add(subPart);
	// }
	// }
	// return list;
	// }catch (Exception e){
	// e.printStackTrace();
	// }
	// return null;
	// }
	
	/**
	 * @param WTPart
	 *            根据part获取所属分类的ERP种类代码
	 * @return WTPart
	 * @throws WTException 
	 * @throws Exception
	 */
	public static String getERPClassNumberByPart(WTPart part) throws WTException{
		if(part == null){
			return "";
		}
		
		StringValue classNode = getClassNodeByPart(part);
		try{
		
			if (classNode == null)
				return "";
			System.out.println(part.getNumber() + "---classNode------>" + classNode.getValue());
			//内部名称
			String value = classNode.getValue();
			//根据内部名称获取分类节点对象
			
			String defaultValueFromCls = "";
			return defaultValueFromCls;
		}catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e.getMessage());
		}
		
		//return "";
	}
	

	/**
	 * @param WTPart
	 *            根据part获取所属分类的属性列表，key->显示名称
	 * @return WTPart
	 * @throws WTException 
	 * @throws Exception
	 */
	public static List<String[]> getClassificationIBAByPart(WTPart part) throws WTException{
		List<String[]> list = new ArrayList<String[]>();
		if(part == null){
			return list;
		}
		
		StringValue classNode = getClassNodeByPart(part);
		try{
		
			if (classNode == null)
				return list;
			System.out.println(part.getNumber() + "---classNode------>" + classNode.getValue());
			//内部名称
			String value = classNode.getValue();
			//根据内部名称获取分类节点对象
			LWCStructEnumAttTemplate structureEum = getStructureEum(value);
			
			if (structureEum == null)
				return list;
						
			ArrayList<AttributeDefinitionReadView> typeAttributes = LWCCommands.getTypeAttributes("OR:"+structureEum.getPersistInfo().getObjectIdentifier().toString());
			
			for (AttributeDefinitionReadView attributeDefinitionReadView2 : typeAttributes) {
				String name = attributeDefinitionReadView2.getName();
				String displayName = attributeDefinitionReadView2.getDisplayName();
				list.add(new String[]{name,displayName});
			}
		
		}catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e.getMessage());
		}
		
		return list;
	}

	/**
	 * 根据part得到其子部件
	 */
	public static List<WTPart> getBomByPart(WTPart ProductPart) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		List<WTPart> list = new ArrayList<WTPart>();
		try {
			QueryResult qr = WTPartHelper.service
					.getUsesWTPartMasters(ProductPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink
						.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					list.add(sPart);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 更改part状态
	 */
	public static void setPartSate(List partList, String state) {
		try {
			for (int i = 0; i < partList.size(); i++) {
				WTPart wtpart = (WTPart) partList.get(i);
				SessionHelper.manager.setAdministrator();
				wtpart = (WTPart) LifeCycleHelper.service.setLifeCycleState(
						(LifeCycleManaged) wtpart, State
								.toState(state));
				PersistenceHelper.manager.refresh(wtpart);
			}
		} catch (WTInvalidParameterException e) {
			e.printStackTrace();
		} catch (LifeCycleException e) {
			e.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param part
	 *            根据part对象得到part分类路径
	 * @return
	 * @throws WTException
	 */
	public static String getClassificationFullPathByPart(WTPart part) throws WTException {
		
		WTPrincipal currentUser = null;
		try{
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			StringValue classNode = getClassNodeByPart(part);
			
			//System.out.println(part + "---classNode------>" + classNode);
			
			if (classNode == null)
				return "";
			//内部名称
			String value = classNode.getValue();
			//根据内部名称获取分类节点对象
			LWCStructEnumAttTemplate structureEum = getStructureEum(value);
			//向上递归，获取分类路径
			String path = "";
			//StringBuffer sb = new StringBuffer();
			//System.out.println("structureEum---->" + structureEum);
			if(structureEum != null){
				path = getClassificationFullPath(structureEum);
				//System.out.println("path---getClassificationFullPathByPart------->" + path);
				for (structureEum = getParentStructEnum(structureEum); structureEum != null; structureEum = getParentStructEnum(structureEum)){
					String classificationFullPath = getClassificationFullPath(structureEum);
					path = classificationFullPath + CLASSIFICATION_SEPRATOR + path;
				}
			}
			return path;
		}catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return "";
	}
	
	/**
	 * 获取电子元器件的最大分类，用于CIS库同步，
	 * 如：电子元器件--电连接器--线缆连接器，返回的是“电连接器”
	 * @param part
	 * @return
	 * @throws WTException
	 */
	public static String getClassificationDisplayNameByPart(WTPart part) throws WTException{
		ext.jiecang.erp.util.IBAUtil ibaUtil = new ext.jiecang.erp.util.IBAUtil(part);
		String value = ibaUtil.getIBAValue(PART_CLASSIFICATION_IBA);
		if(StringUtils.isBlank(value)){
			return "";
		}
		List<LWCStructEnumAttTemplate> list = getClassificationListByPart(value,part);
		if(list.size() < 3){
			return "";
		}
		//System.out.println("CIS classification =="+list.get(list.size()-4).getName()+"==="+list.get(list.size()-4));
		String displayName = getClassificationFullPath(list.get(list.size()-3));
		//System.out.println("Diplay---name->" + displayName);
		return displayName;
	}
	
	/**
	 * 返回部件的分类路径的每个对象，以倒序返回，如“线缆连接器--电连接器--电子元器件”
	 * @param value
	 * @param part
	 * @return
	 * @throws WTException
	 */
	public static List<LWCStructEnumAttTemplate> getClassificationListByPart(String value , WTPart part) throws WTException{
		//System.out.println(part + "---classNode------>" + value);
		
		List<LWCStructEnumAttTemplate> list = new ArrayList<LWCStructEnumAttTemplate>();
		
		if (StringUtils.isBlank(value))
			throw new WTException("Part --"+part.getNumber()+" --分类--"+PART_CLASSIFICATION_IBA+" 不存在或者没有选择值");
		//内部名称
//		String value = classNode.getValue();
		//根据内部名称获取分类节点对象
		LWCStructEnumAttTemplate structureEum = getStructureEum(value);
		list.add(structureEum);
		//System.out.println("structureEum---->" + structureEum.getName());
		if(structureEum != null){
			for (structureEum = getParentStructEnum(structureEum); structureEum != null; structureEum = getParentStructEnum(structureEum)){
				//System.out.println("structureEum---->" + structureEum.getName());
				list.add(structureEum);
			}
		}
		return list;
	}
	
	/**
	 * @param part
	 *            根据part对象获取第四级分类的内部名称的tablename,倒数第三个
	 * @return
	 * @throws WTException
	 */
	public static String getClassificationInnerNameByPart(WTPart part) throws WTException {
		ext.jiecang.erp.util.IBAUtil ibaUtil = new IBAUtil(part);
		String value = ibaUtil.getIBAValue(PART_CLASSIFICATION_IBA);
		List<LWCStructEnumAttTemplate> list = getClassificationListByPart(value,part);
		if(list.size() < 3){
			return "";
		}
		String name = list.get(list.size()-3).getName();
		//System.out.println("structureEum---name->" + name);
		/*if(StringUtils.contains(name, ".")){
			String[] split = name.split(".");
			return split[split.length-1];
		}else {
			return name;
		}*/
		return name;
	}
	
	public static String getClassificationFullPath(LWCStructEnumAttTemplate structureEum){
		String part = "";
		try {
			QuerySpec queryspec = new QuerySpec();
			int a = queryspec.appendClassList(LWCLocalizablePropertyValue.class, true);
			int b = queryspec.appendClassList(LWCPropertyDefinition.class, false);
			queryspec.setAdvancedQueryEnabled(true);
			String[] aliases = new String[2];
			aliases[0] = queryspec.getFromClause().getAliasAt(a);
			aliases[1] = queryspec.getFromClause().getAliasAt(b);
			TableColumn tc1 = new TableColumn(aliases[0], "IDA3C4");
			TableColumn tc3 = new TableColumn(aliases[0], "CLASSNAMEKEYC4");
			TableColumn tc11 = new TableColumn(aliases[0], "IDA3B4");
			TableColumn tc33 = new TableColumn(aliases[0], "CLASSNAMEKEYB4");
			TableColumn tc2 = new TableColumn(aliases[0], "IDA3A4");
			TableColumn tc4 = new TableColumn(aliases[1], "IDA2A2");
			TableColumn tc5 = new TableColumn(aliases[1], "NAME");
			TableColumn tc6 = new TableColumn(aliases[1], "CLASSNAME");
			CompositeWhereExpression andExpression = new CompositeWhereExpression(LogicalOperator.AND);
			andExpression.append(new SearchCondition(tc1, "=",new ConstantExpression(structureEum.getPersistInfo().getObjectIdentifier().getId())));
			andExpression.append(new SearchCondition(tc3, "=",new ConstantExpression("com.ptc.core.lwc.server.LWCStructEnumAttTemplate")));
			andExpression.append(new SearchCondition(tc11, "=",new ConstantExpression(structureEum.getPersistInfo().getObjectIdentifier().getId())));
			andExpression.append(new SearchCondition(tc33, "=",new ConstantExpression("com.ptc.core.lwc.server.LWCStructEnumAttTemplate")));
			andExpression.append(new SearchCondition(tc2, "=",tc4));
			andExpression.append(new SearchCondition(tc5, "=",new ConstantExpression("displayName")));
			andExpression.append(new SearchCondition(tc6, "=",new ConstantExpression("com.ptc.core.lwc.server.LWCAbstractAttributeTemplate")));
			queryspec.appendWhere(andExpression, null);	
			//System.out.println("Get part classification Path SQL ==="+queryspec.toString());
			QueryResult qr = PersistenceHelper.manager.find(queryspec);
			if (qr.hasMoreElements()) {
				Object[] nextElement = (Object[]) qr.nextElement();
				LWCLocalizablePropertyValue value = (LWCLocalizablePropertyValue) nextElement[0];
				String zh = value.getValue(Locale.CHINA);
				if(StringUtils.isBlank(zh)){
					return value.getValue();
				}else {
					return zh;
				}
			}
		} catch (QueryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return part;
		
	}
		
	/**
	 * 获取父节点
	 * @param structureEum
	 * @return
	 * @throws WTException
	 */
	private static LWCStructEnumAttTemplate getParentStructEnum(LWCStructEnumAttTemplate structureEum)throws WTException {
		boolean setAccessEnforced = SessionServerHelper.manager.setAccessEnforced(false);
		LWCStructEnumAttTemplate result = null;
		try{
			if(structureEum.getParent() == null){
				return result;
			}
			QuerySpec queryspec = new QuerySpec(LWCStructEnumAttTemplate.class);
			queryspec.appendWhere(new SearchCondition(LWCStructEnumAttTemplate.class,
					"thePersistInfo.theObjectIdentifier", "=", structureEum.getParentReference().getObjectId()), new int[] {});
			QueryResult qr = PersistenceServerHelper.manager.query(queryspec);
			if (qr.hasMoreElements()) {
				result = (LWCStructEnumAttTemplate) qr.nextElement();
			}
		}catch (WTException e) {
			throw e;
		}finally{
			SessionServerHelper.manager.setAccessEnforced(setAccessEnforced);
		}
		return result;
	}
	
	/**	
	 * 根据名称获取分类节点
	 * @param name
	 * @return
	 * @throws WTException
	 */
	public static LWCStructEnumAttTemplate getStructureEum(String name)throws WTException {
		LWCStructEnumAttTemplate result = null;
		QuerySpec queryspec = new QuerySpec(LWCStructEnumAttTemplate.class);
		queryspec.appendWhere(new SearchCondition(LWCStructEnumAttTemplate.class,
				LWCStructEnumAttTemplate.NAME, "=", name), new int[] {});
//		queryspec.appendAnd();
//		queryspec.appendWhere(new SearchCondition(LWCStructEnumAttTemplate.class,
//				LWCStructEnumAttTemplate.DELETED_ID, SearchCondition.IS_NULL), new int[] {});
		QueryResult qr = PersistenceServerHelper.manager.query(queryspec);
		while (qr.hasMoreElements()) {
			result = (LWCStructEnumAttTemplate) qr.nextElement();
			if(StringUtils.isBlank(result.getDeletedId())){
				return result;
			}
		}
		return result;
	}

	public static StringValue getClassNodeByPart(WTPart wtpart)
			throws WTException {
		
		IBAHolder ibaHolder = null;
		StringValue clsNode = null;
		try {
			if (wtpart == null) {
				return clsNode;
			}
			ibaHolder = IBAValueHelper.service
					.refreshAttributeContainerWithoutConstraints(wtpart);
			DefaultAttributeContainer theContainer = (DefaultAttributeContainer) ibaHolder
					.getAttributeContainer();
			//System.out.println("theContainer---------->"+ theContainer.getFromServer());
			if (theContainer != null) {
				AttributeDefDefaultView[] theAtts = theContainer
						.getAttributeDefinitions();
				
				for (int i = 0; i < theAtts.length; ++i) {
					AbstractValueView[] theValues = theContainer.getAttributeValues(theAtts[i]);
					if (theValues != null) {
						Object[] temp = new Object[2];
						temp[0] = theAtts[i];
						temp[1] = theValues[0];
						
						if (temp[1] instanceof StringValueDefaultView) {
							String clsRefDef = PartUtil.PART_CLASSIFICATION_IBA;
							if (StringUtils.equalsIgnoreCase(theAtts[i].getName(),clsRefDef)) {
								String sNodeId = (theValues[0]).getObjectID().getStringValue();
								ObjectIdentifier nodeOID = ObjectIdentifier.newObjectIdentifier(sNodeId);
								//System.out.println( "nodeOID--------->"+ nodeOID);
								
								clsNode = (StringValue) PersistenceHelper.manager.refresh(nodeOID);
								break;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return clsNode;
	}

//	public static String getClassificationFullPath(
//			ClassificationNodeDefaultView clsNodeDftView) {
//		if (clsNodeDftView == null)
//			return "";
//		String clsPath = clsNodeDftView.getName();
//		ClassificationNodeDefaultView tmpNodeView = null;
//		try {
//			for (tmpNodeView = ClassificationHelper.service
//					.getParentNodeDefaultView(clsNodeDftView); tmpNodeView != null; tmpNodeView = ClassificationHelper.service
//					.getParentNodeDefaultView(tmpNodeView))
//				clsPath = tmpNodeView.getName() + CLASSIFICATION_SEPRATOR + clsPath;
//		} catch (RemoteException rme2) {
//			rme2.printStackTrace();
//		} catch (CSMClassificationNavigationException csmclassificationnavigationexception2) {
//			csmclassificationnavigationexception2.printStackTrace();
//		} catch (WTException wte2) {
//			wte2.printStackTrace();
//		}
//		return clsPath;
//	}
//
//	public static ClassificationNodeDefaultView getClassificationNodeDefaultView(
//			ClassificationNode clsNode) {
//		ClassificationNodeDefaultView cndv = null;
//		if (clsNode != null) {
//			try {
//				cndv = ClassificationObjectsFactory
//						.newClassificationNodeDefaultView(clsNode);
//			} catch (CSMClassificationNavigationException cne) {
//				return null;
//			}
//		}
//		return cndv;
//	}

	/**
	 * 更改部件编号
	 * @throws Exception 
	 */
	public static boolean changePartNumber(WTPart part, String newPartNumber) throws Exception {
		try {
			part = (WTPart) PersistenceHelper.manager.refresh(part);
			Identified identified = (Identified) part.getMaster();
			WTPartMasterIdentity partIdentity = (WTPartMasterIdentity) identified
					.getIdentificationObject();
			partIdentity.setNumber(newPartNumber);
			identified = wt.fc.IdentityHelper.service.changeIdentity(
					identified, partIdentity);
			part = (WTPart) PersistenceHelper.manager.refresh(part);
			return true;
		} catch (Exception e) {
			// System.out.println("'"+part.getNumber()+"'部件编码修改失败……请检查新编码是否在系统中存在……");
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * 更改部件编号
	 * @throws WTException 
	 */
	public static WTPart changePartName(WTPart part, String newName) throws WTException {
		try {
			part = (WTPart) PersistenceHelper.manager.refresh(part);
			Identified identified = (Identified) part.getMaster();
			WTPartMasterIdentity partIdentity = (WTPartMasterIdentity) identified
					.getIdentificationObject();
			partIdentity.setName(newName);
			identified = wt.fc.IdentityHelper.service.changeIdentity(
					identified, partIdentity);
			part = (WTPart) PersistenceHelper.manager.refresh(part);
			return part;
		} catch (Exception e) {
			// System.out.println("'"+part.getNumber()+"'部件编码修改失败……请检查新编码是否在系统中存在……");
			e.printStackTrace();
			throw new WTException(e.getMessage());
		}
	}

	/**
	 * 获取原样位号
	 * 
	 * @param WTPartUsageLink
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public static String getPartUsesOccurrence(WTPartUsageLink useagelink)
			throws WTException {
		List listWTPart2 = new ArrayList();
		long linkid = PersistenceHelper.getObjectIdentifier(useagelink).getId();
		QuerySpec qs = new QuerySpec(PartUsesOccurrence.class);
		qs.appendWhere(new SearchCondition(PartUsesOccurrence.class,
				"linkReference.key.id", SearchCondition.EQUAL, linkid)); 
		QueryResult qr = PersistenceHelper.manager.find(qs);
		String occurrenceStr = "";
		while (qr.hasMoreElements()) {
			PartUsesOccurrence occurrence = (PartUsesOccurrence) qr
					.nextElement();
			listWTPart2.add(occurrence.getName());
		}
		for (int i = 0; i < listWTPart2.size(); i++) {
			if (listWTPart2.get(i) != null) {
				String ocName = listWTPart2.get(i).toString();
				if (i == 0) {
					occurrenceStr = ocName;
				} else {
					occurrenceStr = occurrenceStr + "," + ocName;
				}
			}
		}
		String numberStr = sortPlaceNumber(occurrenceStr);// 对位号排序
		return numberStr;
	}

	// 对位号排序
	public static String sortPlaceNumber(String numberStr) {
		TreeMap tm = new TreeMap();
		String[] s = numberStr.split(",");
		for (int i = 0; i < s.length; i++) {
			tm.put(s[i], s[i]);
		}
		Iterator it = tm.keySet().iterator();
		String number = "";
		int a = 0;
		while (it.hasNext()) {
			if (a == 0) {
				number = (String) it.next();
			} else {
				number = number + "," + (String) it.next();
			}
			a++;
		}
		return number;
	}

	/**
	 * 查找替代料
	 * 
	 * @param useagelink
	 * @return List<WTPart>
	 * @throws WTException
	 */
	public static List<WTPart> getSubstituteParts(WTPartUsageLink useagelink)
			throws WTException {
		if (useagelink == null) {
			return null;
		}
		List<WTPart> list = new ArrayList<WTPart>();
		long linkid = PersistenceHelper.getObjectIdentifier(useagelink).getId();
		int[] index = { 0 };
		QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
		qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class,
				"roleAObjectRef.key.id", SearchCondition.EQUAL, linkid), index);
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		while (qr.hasMoreElements()) {
			WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr
					.nextElement();
			WTPartMaster partmast = sLink.getSubstitutes();
			WTPart part = getWTPartByNumber(partmast.getNumber());
			list.add(part);
		}
		return list;
	}
	/**
	 * 查找替代料
	 * 
	 * @param useagelink
	 * @return List<WTPartSubstituteLink>
	 * @throws WTException
	 */
	public static List<WTPartSubstituteLink> getSubstitutePartsLink(WTPartUsageLink useagelink)
			throws WTException {
		if (useagelink == null) {
			return null;
		}
		List<WTPartSubstituteLink> list = new ArrayList<WTPartSubstituteLink>();
		long linkid = PersistenceHelper.getObjectIdentifier(useagelink).getId();
		int[] index = { 0 };
		QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
		qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class,
				"roleAObjectRef.key.id", SearchCondition.EQUAL, linkid), index);
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		while (qr.hasMoreElements()) {
			WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr
					.nextElement();
			list.add(sLink);
		}
		return list;
	}
	
	/**
	 * 查找替代料
	 * 
	 * @param useagelink
	 * @return String
	 * @throws WTException
	 */
	public static String getSubstitutePart(WTPartUsageLink useagelink)
			throws WTException {
		if (useagelink == null) {
			return null;
		}
		String nums = "";
		// List<String> list = new ArrayList<String>();
		long linkid = PersistenceHelper.getObjectIdentifier(useagelink).getId();
		int[] index = { 0 };
		QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
		qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class,
				"roleAObjectRef.key.id", SearchCondition.EQUAL, linkid), index);
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		while (qr.hasMoreElements()) {
			WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr
					.nextElement();
			WTPartMaster part = sLink.getSubstitutes();
			String s = part.getNumber();
			if (nums == "") {
				nums = s;
			} else {
				nums = nums + "|" + s;
			}
			// System.out.println("替代料===="+nums);
			// list.add(s);
		}
		return nums;
	}
	
	/**
	 * 查找主料的全局替代料
	 * @param wtpart
	 * @return
	 * @throws WTException
	 */
	public static List<WTPartAlternateLink> getWTPartAlternateLinks(WTPart wtpart) throws WTException{
		if (wtpart == null) {
			return null;
		}
		List<WTPartAlternateLink> list = new ArrayList<WTPartAlternateLink>();
		long masterId = PersistenceHelper.getObjectIdentifier(wtpart.getMaster()).getId();
		int[] index = { 0 };
		QuerySpec qs = new QuerySpec(WTPartAlternateLink.class);
		qs.appendWhere(new SearchCondition(WTPartAlternateLink.class,
				"roleAObjectRef.key.id", SearchCondition.EQUAL, masterId), index);
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		while (qr.hasMoreElements()) {
			WTPartAlternateLink sLink = (WTPartAlternateLink) qr
					.nextElement();
			list.add(sLink);
		}
		return list;
	}
	
	/**
	 * @param WTPart
	 *            , String state 设置WTPart的状态
	 * @return void
	 * @throws Exception
	 */
	public static String changePartState(WTPart part, String state)  throws WTPropertyVetoException, WTException{
		String message = "";
		WTPrincipal currentUser = null;
		try{
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();

			part = (WTPart) LifeCycleHelper.service
			.setLifeCycleState((LifeCycleManaged) part,
					State.toState(state));
			
			PersistenceHelper.manager.refresh(part);
		}catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return message;
	}

	public static String changePartState(WTPart part, State state)  throws WTPropertyVetoException, WTException{
		String message = "";
		WTPrincipal currentUser = null;
		try{
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();

			part = (WTPart) LifeCycleHelper.service
			.setLifeCycleState((LifeCycleManaged) part,state);
			
			PersistenceHelper.manager.refresh(part);
		}catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return message;
	}
	
	/***
	 * 修改WTPart EPMDocument或者基线 状态
	 * @description 
	 * @param
	 * @return
	 * @throws
	 */
	public static String changeObjectState(Object obj, Object objState)  throws WTPropertyVetoException, WTException{
		String message = "";
		State newState = null;
		WTPrincipal currentUser = null;
		try{
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			if(objState instanceof State){
				newState = (State)objState;
			}else if(objState instanceof String){
				newState = State.toState(objState+"");
			}
			//System.out.println(newState.getDisplay() + " : "+ newState.getComment() +"<----changeObjectState------>" + newState.getStringValue());
			
			if(obj instanceof WTPart){
				WTPart part = (WTPart)obj ;
				
				part = (WTPart) LifeCycleHelper.service
						.setLifeCycleState((LifeCycleManaged) part,newState);
				
				PersistenceHelper.manager.refresh(part);
						
			}else if(obj instanceof EPMDocument){
				EPMDocument epmDocument = (EPMDocument)obj ;
				
				epmDocument = (EPMDocument) LifeCycleHelper.service
						.setLifeCycleState((LifeCycleManaged) epmDocument,newState);
				
				PersistenceHelper.manager.refresh(epmDocument);
				
			}else if(obj instanceof WTDocument){
				WTDocument wtDocument = (WTDocument)obj ;
				
				wtDocument = (WTDocument) LifeCycleHelper.service
						.setLifeCycleState((LifeCycleManaged) wtDocument,newState);
				
				PersistenceHelper.manager.refresh(wtDocument);
				
			}else if(obj instanceof ManagedBaseline){
				ManagedBaseline managedBaseline = (ManagedBaseline)obj ;
				
				managedBaseline = (ManagedBaseline) LifeCycleHelper.service
						.setLifeCycleState((LifeCycleManaged) managedBaseline,newState);
				
				PersistenceHelper.manager.refresh(managedBaseline);
			}else if(obj instanceof LifeCycleManaged){
				LifeCycleManaged lifeCycleManaged = (LifeCycleManaged)obj ;
				
				lifeCycleManaged = (LifeCycleManaged) LifeCycleHelper.service
						.setLifeCycleState((LifeCycleManaged) lifeCycleManaged,newState);
				
				PersistenceHelper.manager.refresh(lifeCycleManaged);
			}
		}catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return message;
	}
	
	/***
	 * 设置文档及关联文档状态
	 * @description 
	 * @param
	 * @return
	 * @throws
	 */
	public static String changeDocumentLinksState(Object obj, Object objState)  throws WTPropertyVetoException, WTException{
		String message = "";
		State newState = null;
		WTPrincipal currentUser = null;
		try{
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			if(objState instanceof State){
				newState = (State)objState;
			}else if(objState instanceof String){
				newState = State.toState(objState+"");
			}
			
			if(obj instanceof WTDocument){
				WTDocument wtDocument = (WTDocument)obj ;
				
				List<WTDocument> list = DocUtil.getLinkDocuments(wtDocument);
				for (int i = 0; i < list.size(); i++) {
					WTDocument subDocument = (WTDocument)list.get(i);
					subDocument = (WTDocument) LifeCycleHelper.service
						.setLifeCycleState((LifeCycleManaged) subDocument,newState);
			
					PersistenceHelper.manager.refresh(subDocument);
				}				
				wtDocument = (WTDocument) LifeCycleHelper.service
					.setLifeCycleState((LifeCycleManaged) wtDocument,newState);
				PersistenceHelper.manager.refresh(wtDocument);
			}
		}catch (Exception e) {
			e.printStackTrace();			
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return message;
	}
	
	/**
	 * 部件与文档是 说明关系 通过文档 获取部件
	 * 
	 * @param doc
	 */
	public static List<WTPart> getPartByDescribesDoc(WTDocument doc) {
		QueryResult qr = null;
		WTPart part = null;
		List<WTPart> list = new ArrayList<WTPart>();
		try {
			qr = WTPartHelper.service.getDescribesWTParts(doc);// 说明文档
			while (qr.hasMoreElements()) {
				Object obj = qr.nextElement();
				if (obj instanceof WTPart) {
					part = (WTPart) obj;
					// System.out.println("part number=" + part.getNumber());
					list.add(part);
				}
			}

		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 * 获取部件的结构图prt或asm
	 * 
	 * @param part
	 * @throws Exception 
	 */
	public static EPMDocument getProECADByPart(WTPart part) throws Exception {
		EPMDocument doc = null;
		WTPrincipal currentUser = null;
		try {
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			Collection cadDocumentsAndLinks = PartDocServiceCommand.getAssociatedCADDocumentsAndLinks(part);
			String typeName = PartUtil.getTypeName(part);
			for (Object object : cadDocumentsAndLinks) {
				if (object instanceof AssociationLinkObject) {
					AssociationLinkObject alo = (AssociationLinkObject)object;
					doc = alo.getCadObject();
					EPMDocumentType docType = doc.getDocType();
					EPMAuthoringAppType appType = doc.getAuthoringApplication();
					if((StringUtils.equals("部件", typeName )//结构件
							|| StringUtils.equals("Part", typeName))
						&& 	(CADCOMPONENT.equals(docType)||CADASSEMBLY.equals(docType))//prt或者asm 
						&& PROE.equals(appType)
						&& (StringUtils.endsWithIgnoreCase(doc.getCADName(), ".prt")
						||StringUtils.endsWithIgnoreCase(doc.getCADName(), ".asm"))){
						return doc;
					}
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
			throw new Exception("No 3D CAD Document on Part :" + part.getName());
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return null;
	}
	
	/**
	 * 获取部件的ECAD图纸原理图或PCB
	 * 
	 * @param part
	 * @throws Exception 
	 */
	public static EPMDocument getECADByPart(WTPart part) throws Exception {
		EPMDocument doc = null;
		WTPrincipal currentUser = null;
		try {
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			Collection cadDocumentsAndLinks = PartDocServiceCommand.getAssociatedCADDocumentsAndLinks(part);
			//String typeName = PartUtil.getTypeName(part);
			for (Object object : cadDocumentsAndLinks) {
				if (object instanceof AssociationLinkObject) {
					AssociationLinkObject alo = (AssociationLinkObject)object;
					doc = alo.getCadObject();
					EPMDocumentType docType = doc.getDocType();
					//EPMAuthoringAppType appType = doc.getAuthoringApplication();
					if(SCHEMATIC.equals(docType)||BOARD.equals(docType)){//原理图或PCB图
						return doc;
					}
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
			throw new Exception("No ECAD Document on Part :" + part.getName());
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return null;
	}
	
	
	/**
	 * 获取部件的2d图纸
	 * 
	 * @param part
	 * @throws Exception 
	 */
	public static EPMDocument get2DByPart(WTPart part) throws Exception {
		EPMDocument doc = null;
		WTPrincipal currentUser = null;
		try {
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			Collection cadDocumentsAndLinks = PartDocServiceCommand.getAssociatedCADDocumentsAndLinks(part);
			System.out.println("EPMDocument from Part : size = "+cadDocumentsAndLinks.size());
			for (Object object : cadDocumentsAndLinks) {
				System.out.println("EPMDocument from Part :"+object.toString());
				if (object instanceof AssociationLinkObject) {
					AssociationLinkObject alo = (AssociationLinkObject)object;
					doc = alo.getCadObject();
					EPMAuthoringAppType appType = doc.getAuthoringApplication();
					System.out.println("EPMDocument from Part :appType ="+appType);
					System.out.println("EPMDocument from Part :cadName ="+doc.getCADName());
					System.out.println("EPMDocument from Part :Name ="+doc.getName());
					System.out.println("EPMDocument from Part :number ="+doc.getNumber());
					if(StringUtils.endsWithIgnoreCase(doc.getCADName(),".drw")){//2d drw
						return doc;
					}
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
			throw new Exception("No ECAD Document on Part :" + part.getName());
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return null;
	}
	
	/**
	 * 部件与CAD文档， 说明关系 通过部件获取CAD文档，可能包含3D和2D
	 * 1）如果是结构部件，找结构3D图纸 CADCOMPONENT & PROE
	 * 2）如果是PCBA，找ECAD图纸
	 * 3）如果是软件部件，找autocad图纸
	 * 
	 * @param part
	 * @throws Exception 
	 */
	public static List<EPMDocument> getAllCADByPart(WTPart part) throws Exception {
		QueryResult qr = null;
		List<EPMDocument> docs = new ArrayList<EPMDocument>();
		WTPrincipal currentUser = null;
		try {
			currentUser = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			//qr = WTPartHelper.service.getDescribedByDocuments(part);// CAD文档
			Collection cadDocumentsAndLinks = PartDocServiceCommand.getAssociatedCADDocumentsAndLinks(part);
			String typeName = PartUtil.getTypeName(part);
			for (Object object : cadDocumentsAndLinks) {
			//}
			//while (qr.hasMoreElements()) {
			//	Object obj = qr.nextElement();
				if (object instanceof AssociationLinkObject) {
					AssociationLinkObject alo = (AssociationLinkObject)object;
					EPMDocument doc = alo.getCadObject();
			//while (qr.hasMoreElements()) {
			//	Object obj = qr.nextElement();
			//	if (obj instanceof EPMDocument) {
			//		EPMDocument doc = (EPMDocument) obj;
					docs.add(doc);
				}
			}

		} catch (WTException e) {
			e.printStackTrace();
			throw new Exception("No 3D CAD Document on Part :" + part.getName());
		}finally{
			if(currentUser != null){
				SessionHelper.manager.setPrincipal(currentUser.getName());
			}
		}
		return docs;
	}
	
	
	
	
	/**
	 * 获取部件的说明文档
	 * 
	 * @param part
	 * @throws Exception 
	 */
	public static List<WTDocument> getDescribedDocumentsFromPart(WTPart part) throws WTException {
		QueryResult qr = null;
		List<WTDocument> list = new ArrayList<WTDocument>();
		try {
			qr = WTPartHelper.service.getDescribedByDocuments(part);// 普通说明文档
			while (qr.hasMoreElements()) {
				Object obj = qr.nextElement();
				if (obj instanceof WTDocument) {
					WTDocument doc = (WTDocument) obj;
					list.add(doc);
				}
			}

		} catch (WTException e) {
			e.printStackTrace();
			throw new WTException("No Described Document on Part :" + part.getName());
		}
		return list;
	}
	
	/*获取部件的参考文档*/
	public static List<WTDocument> getReferenceDocumentsFromPart(WTPart part) throws WTException {
		QueryResult qr = null;
		List<WTDocument> list = new ArrayList<WTDocument>();
		try {
			qr = WTPartHelper.service.getReferencesWTDocumentMasters(part);//根据part获取关联的参考文档
			while (qr.hasMoreElements()) {
				Object obj = qr.nextElement();
				if (obj instanceof WTDocumentMaster) {
					WTDocumentMaster docmaster = (WTDocumentMaster) obj;
					QueryResult qs = VersionControlHelper.service.allVersionsOf(docmaster);
					 WTDocument doc=(WTDocument)qs.nextElement();
					list.add(doc);
				}
			}

		} catch (WTException e) {
			e.printStackTrace();
			throw new WTException("No Described Document on Part :" + part.getName());
		}
		return list;
	}
	
	
	
	
	/**
	 * 部件与文档是参考关系 通过文档 获取部件
	 * 
	 * @param doc
	 */
	public static List<WTPart> getPartByRefrenceDoc(WTDocument doc) {
		QueryResult qr = null;
		WTPart part = null;
		List<WTPart> list = new ArrayList<WTPart>();
		try {
			qr = StructHelper.service.navigateReferencedBy(doc.getMaster());// 参考关系
			while (qr.hasMoreElements()) {
				Object obj = qr.nextElement();
				if (obj instanceof WTPart) {
					part = (WTPart) obj;
					// System.out.println("part number=" + part.getNumber());
					list.add(part);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * @param WTPart
	 *            fatherPart, WTPart sonPart 根据父部件和子部件获取 link
	 * @return WTPart
	 * @throws Exception
	 */
	public static WTPartUsageLink getLinkByPart(WTPart fatherPart,WTPart sonPart) {
		try {
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
				WTPart part = getBomPartBylink(link);
				if (part.getNumber().equals(sonPart.getNumber())) {
					return link;
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @param WTPart
	 *            得到link对应的bom子部件
	 * @return WTPart
	 * @throws Exception
	 */
	public static WTPart getBomPartBylink(WTPartUsageLink link) {
		try {
			QueryResult qr = VersionControlHelper.service.allVersionsOf(link.getUses());
			//System.out.println("getBomPartBylink----->"+ qr.size());
			if (qr.hasMoreElements()) {
				WTPart part = (WTPart) qr.nextElement();
				//System.out.println("part----->"+ part.getNumber());
				return part;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * 根据part得到其包含子部件 的所有部件(包括其本身)
	 * 
	 * @param WTPart
	 * @param Set
	 *            <WTPart>
	 * @return Set<WTPart>
	 */
	public static Set<WTPart> getHasBomPartsByPart(WTPart productPart,
			Set<WTPart> set) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service
					.getUsesWTPartMasters(productPart);
			while (qr.hasMoreElements()) {
				set.add(productPart);
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink
						.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					getHasBomPartsByPart(sPart, set);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return set;
	}

	/**
	 * @param WTPart
	 *            fatherPart 根据父部件获取 link
	 * @return WTPart
	 * @throws Exception
	 */
	public static List<WTPartUsageLink> getLinksByPart(WTPart fatherPart) {
		List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
		try {
			QueryResult qr = WTPartHelper.service
					.getUsesWTPartMasters(fatherPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
				list.add(link);
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 * 根据part得到其所有子部件,包含数量,自动合并同物料号的单机数量
	 */
	public static List<Object[]> getAllBomByParentPart(WTPart parentPart,	List<Object[]> list) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(parentPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					boolean found = false;
					for(Object[] old : list){
						WTPart object = (WTPart)old[0];
						String number = object.getNumber();
						if( sPart.getNumber().equalsIgnoreCase(number)){
							old[1] = (Double)old[1] + usageLink.getQuantity().getAmount();
							found  =  true;
							break;
						}
					}
					if(!found){
						list.add(new Object[]{sPart,usageLink.getQuantity().getAmount()});
					}
					getAllBomByParentPart(sPart, list);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 * 根据part得到其所有子部件
	 */
	public static List<WTPart> getAllBomByPart(WTPart ProductPart,
			List<WTPart> list) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(ProductPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					list.add(sPart);
					getAllBomByPart(sPart, list);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}

	
	/**
	 * 发ERP时，当事业部为MPD时作处理 如果成品或者半成品 的分类是原材料*系统部件，并且事业部是MPD的时候 bom结构不发ERP
	 * 根据part得到其所有子部件
	 */
	public static List<WTPart> getAllBomByPart2(WTPart ProductPart,
			List<WTPart> list, String operation) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service
					.getUsesWTPartMasters(ProductPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink
						.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					list.add(sPart);
					if ("MPD".equals(operation)) {
						String cate = PartUtil
								.getClassificationFullPathByPart(sPart);
						if (cate != null && cate.startsWith("原材料/系统部件")) {
							continue;
						}
					}
					getAllBomByPart2(sPart, list, operation);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 1、 PLM发ERP时，31和30开头的BOM及下面的子件不需要发往F02/F12/F22 2、 PLM发ERP时
	 * 所有BOM不需要发往F01/F11 3、 当PLM物料分类为“虚拟件/虚拟件类/普通虚拟件/SMT正反面”发物料时无需发F开头的组织
	 * 根据part得到其所有子部件 * 2012-04-25 4、在BOM发布F32组织时，只有31和30开头的半成品发到F32组织下
	 */
	public static List<WTPart> getAllBomByPartOfOrganizationF(WTPart ProductPart,
			List<WTPart> list, List<String> type_list) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		boolean add_flag;
		try {
			QueryResult qr = WTPartHelper.service
					.getUsesWTPartMasters(ProductPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink
						.getUses());
				if (qr2.hasMoreElements()) {
					add_flag = true;
					sPart = (WTPart) qr2.nextElement();
					String partCate = getClassificationFullPathByPart(sPart);
					// 2012-04-25
					// 因为增加了30、31的物料BOM需要发送到F32组织，所以不能将30、31开头的物料直接屏蔽掉
					// if(sPart.getNumber().startsWith("30") ||
					// sPart.getNumber().startsWith("31")){
					// continue;
					// }else
					if (partCate.equals("虚拟件/虚拟件类/普通虚拟件/SMT正反面")) {
						add_flag = false;
						continue;
					} else {
						// 筛选掉参数中 传入的不发送的物料类别
						// update by Jane Zhang ,2012-05-03,加上在文件定义中不发送到XX事业部的物料类别筛选
						for (String type : type_list) {
							if (partCate != null && partCate.startsWith(type) == true) {
								add_flag = false;
								break;
							}
						}
					}

					if (add_flag) {
						list.add(sPart);
						getAllBomByPartOfOrganizationF(sPart, list, type_list);
					}
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 判断对象是否处于检出状态
	 * 
	 * @param workable
	 *            被检测的对象
	 * @return boolean
	 */
	public static boolean isCheckOut(Workable workable) {
		try {
			return WorkInProgressHelper.isCheckedOut(workable);
		} catch (WTException e) {

		}
		return false;
	}

	/**
	 * 检出部件
	 * 
	 * @param part
	 * @return
	 * @throws WTException
	 */
	public static WTPart checkoutPart(WTPart part) throws WTException {
		if (part == null) {
			return null;
		}
		if (WorkInProgressHelper.isWorkingCopy((Workable) part)) {
			return part;
		}
		Folder folder = WorkInProgressHelper.service.getCheckoutFolder();
		try {
			CheckoutLink checkoutLink = WorkInProgressHelper.service.checkout(
					(Workable) part, folder, "AutoCheckOut");
			part = (WTPart) checkoutLink.getWorkingCopy();
		} catch (WTPropertyVetoException ex) {
			ex.printStackTrace();
		}
		if (!WorkInProgressHelper.isWorkingCopy((Workable) part)) {
			part = (WTPart) WorkInProgressHelper.service
					.workingCopyOf((Workable) part);
		}
		return part;
	}

	/**
	 * 检入部件
	 * 
	 * @param partParentPrevious
	 * @param comment
	 * @return
	 * @throws WTException
	 */
	public static WTPart checkinPart(WTPart partParentPrevious, String comment)
			throws WTException {
		WTPart part = null;
		if (partParentPrevious != null) {
			try {
				WTPrincipal wtprincipal = SessionHelper.manager
						.getPrincipal();
				if (WorkInProgressHelper.isCheckedOut(
						(Workable) partParentPrevious, wtprincipal)) {
					if (!WorkInProgressHelper
							.isWorkingCopy((Workable) partParentPrevious)) {
						partParentPrevious = (WTPart) WorkInProgressHelper.service
								.workingCopyOf((Workable) partParentPrevious);
					}
					part = (WTPart) WorkInProgressHelper.service.checkin(
							(Workable) partParentPrevious, comment);
				}
			} catch (WTPropertyVetoException ex) {
				ex.printStackTrace();
			}
		}
		return part;
	}

	/**
	 * 得到两个部件之间的链接关系
	 * 
	 * @param part
	 *            父部件
	 * @param subMaster
	 *            子部件Master
	 * @return
	 * @throws WTException
	 */
	public static WTPartUsageLink findWTPartUsageLink(WTPart part,
			WTPartMaster subMaster) throws WTException {

		WTPartUsageLink link = null;
		if (part == null || subMaster == null) {
			return link;
		}
		QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
		queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class,
				"roleAObjectRef.key", "=", PersistenceHelper
						.getObjectIdentifier(part)), new int[] {});
		queryspec.appendAnd();
		queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class,
				"roleBObjectRef.key", "=", PersistenceHelper
						.getObjectIdentifier(subMaster)), new int[] {});
		QueryResult qr = PersistenceServerHelper.manager.query(queryspec);
		if (qr.hasMoreElements()) {
			link = (WTPartUsageLink) qr.nextElement();
		}
		return link;
	}

	/**
	 * 根据替代料 获取其主料
	 * 
	 * @param part
	 * @throws WTException
	 */
	public static List<WTPart> getPart(WTPart part) throws WTException {
		List<WTPart> list = new ArrayList<WTPart>();
		if (part == null) {
			return list;
		}
		long linkid = PersistenceHelper.getObjectIdentifier(part.getMaster()).getId();
		
		int[] index = { 0 };
		QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
		qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class,
				"roleBObjectRef.key.id", SearchCondition.EQUAL, linkid), index);
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		while (qr.hasMoreElements()) {
			WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr
					.nextElement();
			WTPartUsageLink ulink = sLink.getSubstituteFor();
			QueryResult qr2 = VersionControlHelper.service.allVersionsOf(ulink
					.getUses());
			if (qr2.hasMoreElements()) {
				WTPart part2 = (WTPart) qr2.nextElement();
				// System.out.println("????>>>>>"+part2.getNumber());
				list.add(part2);
			}
		}
		return list;
	}

	/**
	 * 根据part得到其子部件
	 */
	public static List<WTPartUsageLink> getBomLinkByPart(WTPart ProductPart) {
		List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
		try {
			QueryResult qr = WTPartHelper.service
					.getUsesWTPartMasters(ProductPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				list.add(usageLink);
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 * 根据part得到其所有父部件link
	 */
	public static List<WTPartUsageLink> getBomLinkByChildPart(WTPart childPart) {
		List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
		try {
			if (childPart != null) {
				QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
				queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class,
						"roleBObjectRef.key", "=", PersistenceHelper
								.getObjectIdentifier((WTPartMaster)childPart.getMaster())));
				QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
				while (qr.hasMoreElements()) {
					WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
					list.add(usageLink);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/***
	 * 复制part
	 * @description 
	 * @param
	 * @return WTPart
	 * @throws
	 */
	public static WTPart copyPart(WTPart part,String partName){
		WTPart newPart = null;
		try{			
			String number = part.getNumber();
			//String name = part.getName();
			LifeCycleState state = part.getState();
			Source source = part.getSource();	
			PartType partType = part.getPartType();          //装配模式
			boolean endItem = part.isEndItem();              //成品
			QuantityUnit defaultUnit = part.getDefaultUnit();//单位
			boolean hidePartInStructure = part.getHidePartInStructure();//收集部件
			TraceCode defaultTraceCode = part.getDefaultTraceCode();    //默认追踪代码
			String location = FolderHelper.getLocation((CabinetBased)part);
			WTContainer container2 = WTContainerHelper.getContainer((WTContained)part);
			WTContainerRef containerRef = WTContainerRef.newWTContainerRef(container2);
						
			String newNumber = number.substring(0,number.length()-1);
			String suffix = number.substring(number.length()-1);
			
			if("0".equals(suffix)){
				newNumber+="1";
			}else if("1".equals(suffix)){
				newNumber+="0";
			}
				
			newPart =  WTPart.newWTPart();
			newPart.setName(partName);
			newPart.setNumber(newNumber);
			newPart.setState(state);
			newPart.setSource(source);
			newPart.setPartType(partType);
			newPart.setEndItem(endItem);
			newPart.setHidePartInStructure(hidePartInStructure);
			newPart.setDefaultUnit(defaultUnit);
			newPart.setDefaultTraceCode(defaultTraceCode);
			newPart.setView(part.getView());
			FolderHelper.assignLocation((FolderEntry)newPart,location,containerRef);						
			PersistenceHelper.manager.save(newPart);
			//IBAUtil ibaUtil = new IBAUtil(newPart);
			//ibaUtil.setIBAValues(this.getIba());
		}catch (Exception e) {
			e.printStackTrace();
		}
		return newPart;
	}
	
	
	/***
	 * 根据编号或者名称查询部件
	 * @Title: findWTPartByPart
	 * @Description: TODO
	 * @author elvis
	 * @date Jun 25, 2014 12:02:55 PM
	 * @return WTPart
	 * @throws
	 */
	public static List findAllWTPartByPart(){
		QueryResult qr = null;
		List list = new ArrayList();
		try {
			QuerySpec querySpec = new QuerySpec(WTPart.class);
						
			/*if(!"".equals(partName) && partName != null){
			WhereExpression where = new SearchCondition(WTPart.class,
				WTPart.NAME, SearchCondition.EQUAL, partName);
				querySpec.appendWhere(where);
			}
			if(!"".equals(partNumber) && partNumber != null){
				WhereExpression where = new SearchCondition(WTPart.class,
						WTPart.NUMBER, SearchCondition.EQUAL, partNumber);
				querySpec.appendWhere(where);
			}*/
			
			qr = PersistenceHelper.manager.find((StatementSpec) querySpec);
			
			
			while (qr.hasMoreElements()){
				WTPart part = (WTPart) qr.nextElement();
				list.add(part);
			}
		} catch (WTException e) {
		e.printStackTrace();
		}
		return list;
	}
	
	
	/***
	 * 根据编号或者名称查询部件
	 * @Title: findWTPartByPart
	 * @Description: TODO
	 * @author elvis
	 * @date Jun 25, 2014 12:02:55 PM
	 * @return WTPart
	 * @throws
	 */
	public static List<WTPart> findAllWTPartByNumber(String partNumber){
		QueryResult qr = null;
		List<WTPart> list = new ArrayList<WTPart>();
		try {
			QuerySpec querySpec = new QuerySpec(WTPart.class);
						
			/*if(!"".equals(partName) && partName != null){
			WhereExpression where = new SearchCondition(WTPart.class,
				WTPart.NAME, SearchCondition.EQUAL, partName);
				querySpec.appendWhere(where);
			}*/
			if(StringUtils.isNotBlank(partNumber)){
				WhereExpression where = new SearchCondition(WTPart.class,
						WTPart.NUMBER, SearchCondition.EQUAL, partNumber);
				querySpec.appendWhere(where);
				qr = PersistenceHelper.manager.find((StatementSpec) querySpec);
				while (qr.hasMoreElements()){
					WTPart part = (WTPart) qr.nextElement();
					list.add(part);
				}
			}
			
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public static Map getQuantityAmount(WTPart part){
		Map mapData = new HashMap();
		try{
			Map<String,WTPart> map = new IdentityHashMap<String,WTPart>();

			int i = 0;
			map = PartUtil.getAllBomTableByPart(part, map,i);

			Set set = map.entrySet();
			Iterator iterator = set.iterator();
			while(iterator.hasNext()){
				Entry entry = (Entry)iterator.next();
				String level = entry.getKey()+"";
				WTPart part2 = (WTPart)entry.getValue();
				String pName = part2.getName();
				String number = part2.getNumber();
							
			//System.out.println(level + "<------>"+ pName);
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part2);
			
			 //遍历每个part，得到子part单位和数量
				 while (qr.hasMoreElements()) {
				 	WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
				 	//WTPart part2 = link.getUsedBy();
				    System.out.println("LineNumber------->"+ link);
				 
				 	WTPartMaster master = (WTPartMaster)link.getAllObjects()[1];
				 	String pName2 = master.getName();
				 	String number2 = master.getNumber();
				 	
				 	String tempunit = link.getQuantity().getUnit().toString();
				 	String tempquantity = String.valueOf(link.getQuantity().getAmount());
					 
					 mapData.put(number2+"Quantity",tempquantity);
					 mapData.put(number2+"Amount",tempunit);
				}
			}
		 }catch (Exception e) {
			e.printStackTrace();
		}
		 //System.out.println("mapData-------->"+ mapData);
		 return mapData;
	}
	
	
	/**
	 * 根据part得到其所有子部件
	 * @Title: getAllBomByPart
	 * @Description: TODO
	 * @author peijun
	 * @date May 20, 2014 10:26:23 AM
	 * @param @param ProductPart
	 * @param @param list
	 * @param @return
	 * @return List<WTPart>
	 * @throws
	 */
	public static Map<String,WTPart> getAllBomTableByPart(WTPart ProductPart,Map<String,WTPart> map,int i) {
		try {
			QueryResult qr = findWTPartUsageLink(ProductPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				WTPart subPart = getWTPartByNumber(usageLink.getUses().getNumber());
				System.out.println("subpart="+subPart.getNumber()+"="+subPart.getName());
				getAllBomTableByPart(subPart, map,i+1);
				map.put(i+"", subPart);
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return map;
	}
	
	
	public static WTPart setBomLink(WTPart parent)throws Exception {
		try {
			
			parent = PartView.getManufacturingPart(parent);
			
			parent = (WTPart)PartUtil.checkoutPart(parent);
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(parent);
						
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				
				WTPart subPart = getWTPartByNumber(usageLink.getUses().getNumber());
				
				String number = subPart.getNumber();
				
				if(number.startsWith(tempPartSign)){  //是temp开头的，移除link，设置子part和parent part关联
					
					subPart = checkoutPart(subPart);
					QueryResult qr1 = WTPartHelper.service.getUsesWTPartMasters(subPart); //findWTPartUsageLink
					
					while (qr1.hasMoreElements()) {
						WTPartUsageLink usageLink1 = (WTPartUsageLink) qr1.nextElement();
						
						WTPart subPart1 = getWTPartByNumber(usageLink1.getUses().getNumber());
						String number1 = subPart1.getNumber();
						
						if(!number1.startsWith(tempPartSign)){
							//当前part直接和爷爷part关联
							WTPartUsageLink partUsageLink = WTPartUsageLink.newWTPartUsageLink(parent, (WTPartMaster)subPart1.getMaster());
							PersistenceHelper.manager.save(partUsageLink);
						}
						//删除之前查询Manufacturing part和父part的usageLink再删除
						//PersistenceHelper.manager.delete(usageLink1);//父part是temp开头，就移除父层级所有的子link					
					}
					
					String version_no = VersionControlHelper.getVersionIdentifier(subPart).getValue();
			    	version_no += subPart.getIterationInfo().getIdentifier().getValue();
			    				    	
					System.out.println(subPart.getViewName() + "  "+version_no + "--delete usageLink --" + usageLink.getUses().getName());
					PersistenceHelper.manager.delete(usageLink);
					
					subPart = checkinPart(subPart,"");
					
					setBomLink(subPart);
					
				}else{ //不是temp开头的 继续循环找
					setBomLink(subPart);
				}
			}
			parent = (WTPart)PartUtil.checkinPart(parent, "AUTO CHECK");
			System.out.println("---- checkinPart parent----");
		} catch (WTException e) {
			e.printStackTrace();
		}
		return parent;
	}
		
	
	
	@SuppressWarnings("deprecation")
	public static QueryResult findWTPartUsageLink(WTPart part)
			throws WTException {
		if (part == null)
			return new QueryResult();
		QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
		queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class,
				"roleAObjectRef.key", "=", PersistenceHelper
						.getObjectIdentifier(part)), new int[] {});
		queryspec.appendOrderBy(WTPartUsageLink.class, "lineNumber.value",
				false);
		
		//System.out.println("queryspec-------->"+ queryspec.toString());
		return PersistenceServerHelper.manager.query(queryspec);
	}
	
	
	/**
	 * 获取部件的版本号
	 * @param part
	 * @return
	 */
	public static String getVersion(WTPart part){
		if(part == null){
			return "";
		}
		String version = part.getVersionInfo().getIdentifier().getValue();
		String value   = part.getIterationInfo().getIdentifier().getValue();
		return new StringBuffer().append(version).append(".").append(value).toString();
	}
	
	/**
	 * 得到datasheet文件存放路径，如/cis/Datasheet/电阻
	 */
	public static String getFilePath(WTPart part) {
		String path = "";
		String classification = "";
		String classificationFolder = "";
		String[] temp = null;
		try {
				classification = PartUtil.getClassificationFullPathByPart(part);
				System.out.println("Part "+ part.getNumber()+" 分类："+classification );
				if (!StringUtils.isEmpty(classification)) {
					temp = classification.split(PartUtil.CLASSIFICATION_SEPRATOR);
					if(temp.length>=4){
						classificationFolder = temp[3];//得到分类的倒数第四级分类名称
					}else{
//						classificationFolder = temp[temp.length - 1];
					}
					path = rootPath + File.separator + classificationFolder + File.separator;
				}
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("datasheet path----------->" + path);
		return path;
	}
	
	
	
	/**
	 * 判断一组电子元器件是否同属一个大类，是返回true，否则返回false
	 * @param list
	 * @return
	 * @throws WTException 
	 */
	public static boolean isSameFirstClassification(List<WTPart> list) throws WTException{
		String sameCls = "";
		for (WTPart part : list) {
			String cls = PartUtil.getClassificationDisplayNameByPart(part);
			//cls = StringUtils.remove(cls,SAW_STRING+"电子元器件/");
			//if(StringUtils.contains(cls, "/")){
			//	cls = StringUtils.substring(cls, 0,cls.indexOf("/"));
			if(StringUtils.isNotBlank(sameCls)){
				if(!StringUtils.equalsIgnoreCase(sameCls, cls)){
					throw new WTException("器件分类规则：本次器件申请流程涉及的电子元器件的大类必须是同属一个分类");
				}
			}else {
				sameCls = cls;
			}
		}
		return true;
	}
	
	
	/**
	 * 检出部件是否有其他流出正在运行？
	 * @param list
	 * @throws WTException
	 */
	@SuppressWarnings("deprecation")
	public static void checkOtherWorkflow(List<WTPart> list) throws WTException{
		for (WTPart wtPart : list) {
			WTCollection localList = new WTHashSet();
			localList.add(wtPart);
			WTCollection promotionNotices = MaturityHelper.getService().getPromotionNotices(localList);
			for (Object object : promotionNotices) {
				if(object instanceof ObjectReference){
					ObjectReference pn = (ObjectReference)object;
					Persistable object2 = pn.getObject();
					if(object2 instanceof PromotionNotice){
						PromotionNotice promotion = (PromotionNotice)object2;
						QueryResult localQueryResult = WorkflowCommands.getRoutingHistory(new NmOid(promotion));
						while (localQueryResult.hasMoreElements()) {
							Object nextElement = localQueryResult.nextElement();
							if(nextElement instanceof WfProcess){
								WfProcess process = (WfProcess)nextElement;
								WfState state = process.getState();
								if(WfState.OPEN_RUNNING.equals(state)){//正在运行
									String number = promotion.getNumber();
									String name = process.getName();
									String partNumber = wtPart.getNumber();
									String partName = wtPart.getName();
									throw new WTException("物料编码为"+partNumber+"的物料【"+partName+"】正在运行另一个升级请求："+number+","+name+"。请勿重复提交升级请求流程。");
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	/**
	 * 替换wtpart的单位
	 * @param part
	 * @param unit 新单位的枚举值
	 * @throws WTException
	 */
	public static void replaceUnit(WTPart part,String unit) throws WTException{
		
		if(part == null ||StringUtils.isBlank(unit)){
			return ;
		}
		QuantityUnit defaultUnit = part.getDefaultUnit();
		
		QuantityUnit quantityUnit = QuantityUnit.toQuantityUnit(unit);
		
		if(defaultUnit.equals(quantityUnit)){
			return ;
		}
		
		try {
			Identified identified = (Identified) part.getMaster();
			WTPartMaster master = (WTPartMaster)part.getMaster();
			master.setDefaultUnit(quantityUnit);
			WTPartMasterIdentity partIdentity = (WTPartMasterIdentity) identified.getIdentificationObject();
			identified = wt.fc.IdentityHelper.service.changeIdentity(master, partIdentity);
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (WTPropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new WTException(e);
		}
	}
	
//	public static void main(String[] args){
//		String pa = "PA1.234.567(A)MX";
//		String right=StringUtils.right(pa, 1);
//		while(!StringUtils.isNumeric(right)&&!StringUtils.equals(right, ")")){
//			pa = StringUtils.removeEndIgnoreCase(pa, right);
//			System.out.println(pa);
//			right=StringUtils.right(pa, 1);
//		}
//	}

	//获取分类属性
	public static String getClsValue(Persistable persistable, String typeName){
		try {
			PersistableAdapter obj = new PersistableAdapter(persistable, null, SessionHelper.getLocale(), new UpdateOperationIdentifier());
			obj.load(typeName);
			Object result = obj.get(typeName);
			return result == null ? "" : result.toString();
		} catch (WTException e){
			log.error(e.getMessage(), e);
		}
		return "";
	}


	/**
	 * 获取IBA值  如果是枚举获取其内部值
	 * @param persistable
	 * @param ibaName
	 * @return
	 * @throws WTException
	 */
	public static String getIBA(Persistable persistable, String ibaName){
		String string = "";
		try {
			Locale locale = Locale.getDefault();
			LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
			normalizedObject.load(ibaName);
			Object result = normalizedObject.get(ibaName);
			string = result == null ? "" : result.toString();
		} catch (Exception e){
			e.printStackTrace();
		}
		return string;
	}


	public static boolean checkPartSubType(WTPart part, String subType) throws WTException {
		boolean res = false;
		TypeDefinitionReference ref = (part).getTypeDefinitionReference();
		@SuppressWarnings("deprecation")
		TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities.getTypeDefinition(ref);
		WTTypeDefinition definition = (WTTypeDefinition) PersistenceHelper.manager.refresh(view.getObjectID());
		String typeDisplayName = definition.getDisplayNameKey(); // 类型的key
		if(subType.equals(typeDisplayName)){
			res = true;
		}
		return res;
	}


	/**
	 * 传入一个父部件返回在table上可以点击的物料编号连接
	 * @param part
	 * @return
	 * @throws WTException
	 */
	public static UrlDisplayComponent getPartUrlByPartNumber(WTPart part) throws WTException {
		NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();

		urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);

		NmOid contentOid = NmOid.newNmOid(part.getPersistInfo().getObjectIdentifier());

		String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null, true);

		UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent("", part.getNumber(), link);
		return urlDisplayComponent;
	}


	/**
	 * 根据部件编号、版本、视图获取最新版本部件
	 */
	public static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName){
		WTPart part = null;
		LatestConfigSpec configSpec = null;
		QuerySpec qs = null;
		QueryResult qr = null;
		try {
			if (org.apache.commons.lang.StringUtils.isNotBlank(partNumber)) {
				partNumber = partNumber.trim();

				qs = new QuerySpec(WTPart.class);
				int[] index = new int[] { 0 };
				qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);

				if (org.apache.commons.lang.StringUtils.isNotBlank(version)) {
					version = version.trim();
					qs.appendAnd();
					qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

					if (org.apache.commons.lang.StringUtils.isNotBlank(iteration)) {
						iteration = iteration.trim();
						qs.appendAnd();
						qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
					} else {
						qs.appendAnd();
						qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
					}
				}

				if (org.apache.commons.lang.StringUtils.isNotBlank(viewName)) {
					viewName = viewName.trim();
					View viewObj = ViewHelper.service.getView(viewName);
					if (viewObj == null)
						return null;
					qs.appendAnd();
					qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
				}

				configSpec = new LatestConfigSpec();
				configSpec.appendSearchCriteria(qs);
				qr = PersistenceHelper.manager.find((StatementSpec) qs);
				qr = configSpec.process(qr);
				if (qr.hasMoreElements()) {
					part = (WTPart) qr.nextElement();
				}
			}
		}catch (WTException e){
			e.printStackTrace();
		}
		return part;
	}



	/**
	 * 递归获取部件的所有子部件
	 *
	 * @param part BOM
	 * @return List<WTPart>
	 */
	public static List<WTPart> getAllBomByPart(WTPart part) {
		List<WTPart> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

		WTPart sPart = null;
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					localList.add(sPart);

					// 递归调用，将结果合并到局部列表
					localList.addAll(getAllBomByPart(sPart));
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return localList; // 返回局部列表
	}
}

