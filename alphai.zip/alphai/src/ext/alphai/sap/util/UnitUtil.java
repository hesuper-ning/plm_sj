package ext.alphai.sap.util;

import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * #如plm的EA对应erp的PCS，那么就填[EA->PCS]，左边大小写不分，匹配后会把plm端的EA替换成PCS，右边以ERP为准
 *#多个就用逗号隔开多个[]
 *#没配置的单位还是以plm为准
 *sap.mm.function.unit.mapping=[EA->PCS],[g->G]
 * 
 * @author Administrator
 *
 */
public class UnitUtil {
	public static Map<String,String> handleUnitConfig(String unitConfig){
		Map<String,String> result = new HashMap<String,String>();
		
		if(StringUtils.isNotBlank(unitConfig)) {
			String[] split = StringUtils.split(unitConfig,",");
			if(split.length > 0) {
				for (String mapping : split) {
					String[] split2 = StringUtils.split(mapping,"->");
					if(split2.length == 2) {
						String plmUnit = StringUtils.upperCase(StringUtils.removeStart(split2[0],"["));
						String erpUnit = StringUtils.removeEnd(split2[1],"]");
						result.put(plmUnit, erpUnit);
					}
				}
			}
		}
		
		return result;
	}
	
	
	
	
	
	
	
	
}
