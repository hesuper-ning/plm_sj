package ext.alphai.sap;
import org.apache.commons.lang.StringUtils;

import java.io.InputStream;

public class Config {
    public static String BUTTON ="button";
    public static String WORKITEM ="workitem";

//    private static PropertiesUtil properties = PropertiesUtil.getInstance("config.properties");


    public static EncodedProperties properties = null;
    static{
        try
        {
            InputStream is = ext.alphai.sap.Config.class.getResourceAsStream("config.properties");
            properties = new EncodedProperties("UTF-8");
            properties.load(is);
            is.close();
        } catch (Exception e) {
            System.out.println("## WARNING: " + e.getLocalizedMessage());
        }
    }
    public static String get(String key) {
        if(properties != null) {
            return properties.getProperty(key);
        }
        return "";
    }
    public static String get(String key,String defaultValue) {
        if(properties != null) {
            String property = properties.getProperty(key);
            if(StringUtils.isBlank(property)) {
                return defaultValue;
            }
            return property;
        }
        return "";
    }
    /**
     * 获取发送物料url
     * @return
     */
    public static String getSendPartUrl() {
        return get("sap.Hu.part.url");
    }

    /**
     * 获取发送物料接口的用户名
     * @return
     */
    public static String getSendPartUsername() {
        return get("sap.Hu.part.username");
    }


    /**
     * 获取发送物料接口的用户名
     * @return
     */
    public static String getSendPartPassword() {
        return get("sap.Hu.part.password");
    }

}
