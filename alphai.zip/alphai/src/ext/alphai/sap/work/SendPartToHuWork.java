package ext.alphai.sap.work;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sap.Config;
import ext.alphai.sap.entity.HuSendPartRecord;
import ext.alphai.sap.part.HUSendPartHelper;
import ext.alphai.sap.util.PersistenceUtil;
import ext.alphai.sap.util.WorkflowUtil;
import org.apache.log4j.Logger;
import wt.change2.WTChangeReview;
import wt.fc.WTObject;
import wt.log4j.LogR;
import wt.part.WTPart;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 流程中发送部件表达式
 */
public class SendPartToHuWork {

    public static final String SEND_PART_MSG = "HUSendPartRes";


    static final ObjectMapper objectMapper = new ObjectMapper();
    private static final Logger log = (Logger) LogR.getLogger(SendPartToHuWork.class.getName());
    /**
     *
     * @param pbo
     */
    public static String sendPart2HuSAP(WTObject pbo){
        String msg =null;
        try {
            if(pbo instanceof WTChangeReview){
                System.out.println("进入流程中发送物料到匈牙利SAP WTChangeReview名称为 ："+((WTChangeReview) pbo).getName());
            }


            // 从受影响对象种取到部件列表
            ArrayList<WTPart> targerObject = WorkflowUtil.getTargerObject(pbo, "AffectedObjects", WTPart.class);
            System.out.println("流程中受影响部件个数为："+targerObject.size());
            List<HuSendPartRecord> records = HUSendPartHelper.sendPartToSAP(targerObject, Config.WORKITEM);

            String json = objectMapper.writeValueAsString(records);
            System.out.println("流程发送物料结果json:"+json);
            // 放到流程变量里
            msg = json;

        } catch (Exception e){
            log.error(e.getMessage(), e);
        }
        return msg;
    }


    /**
     * 再次发送失败物料到SAP
     * @param sendPartResult 发送物料结果集合
     * @param pbo
     * @return
     */
    public static String sendPart2HuSAPAgain(String sendPartResult,WTObject pbo){
        String msg =null;
        String json = null;
        try {
            if(pbo instanceof WTChangeReview){
                System.out.println("进入流程中再次发送物料 WTChangeReview名称为 ："+((WTChangeReview) pbo).getName());
            }
            // 流程中的全部结果
            List<HuSendPartRecord> result = objectMapper.readValue(sendPartResult, new TypeReference<List<HuSendPartRecord>>() {});;
            List<WTPart> errPart = new ArrayList<>();
            for (HuSendPartRecord record : result) {
                boolean result1 = record.isResult();
                if(!result1){
                    String partOid = record.getPartOid();
                    WTPart part = (WTPart) PersistenceUtil.oid2Object(partOid);
                    errPart.add(part);
                }
            }
            if(errPart.isEmpty()){
                log.info("当前流程部件全都发送成功");
                msg = sendPartResult;
            }else {
                // 重新发送
                List<HuSendPartRecord> records = HUSendPartHelper.sendPartToSAP(errPart, Config.WORKITEM);

                for (HuSendPartRecord record : records) {
                    String partOid = record.getPartOid();
                    for (HuSendPartRecord huSendPartRecord : result) {
                        String oid = huSendPartRecord.getPartOid();

                        if(partOid.equals(oid)){
                            huSendPartRecord.setResult(record.isResult());
                            huSendPartRecord.setErrMessage(record.getErrMessage());
                        }
                    }

                }
                json = objectMapper.writeValueAsString(result);
                msg = json;
                System.out.println("流程重新发送物料结果json:"+msg);
            }
        } catch (Exception e){
            log.error(e.getMessage(), e);
        }
        return msg;
    }



    /**
     * 校验SAP给出的信息中是否存在错误信息
     *
     * @param res
     * @return fail/successful
     */
    public static String checkSendPartRes(String res) {
        String result = null;
        System.out.println("进入发送ECN解析返回值接口");
        try {
            List<HuSendPartRecord> vos = objectMapper.readValue(res, new TypeReference<List<HuSendPartRecord>>() {});
            for (HuSendPartRecord vo : vos) {
                if (!vo.isResult()) {
                    result  = "fail";
                    break;
                }
            }
        } catch (IOException e) {
            log.error(e.getMessage(),e);
            result = "fail";
        }

        if(result == null){
            result = "successful";
        }
        return result;
    }
}


