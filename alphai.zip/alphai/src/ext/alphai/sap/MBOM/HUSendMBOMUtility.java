package ext.alphai.sap.MBOM;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import ext.alphai.sap.entity.HuSendMBOMRecord;
import ext.alphai.sap.util.PartUtil;
import ext.alphai.sap.util.PersistenceUtil;
import wt.part.WTPart;
import wt.util.WTException;

public class HUSendMBOMUtility extends AbstractDataUtility {
    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        HuSendMBOMRecord record = (HuSendMBOMRecord) o;
        String partOid = record.getPartOid();
        WTPart part = (WTPart) PersistenceUtil.oid2Object(partOid);
        Object value = null;
        switch (s) {
            case "partNum" :
                value = PartUtil.getPartUrlByPartNumber(part);
                break;
            case "partName":
                value = part.getName();
                break;
            case "partFactory":
                value = part.getView().getName();
                break;
            case "result":
                if (record.isResult()) {
                    value = "发送成功";
                }else {
                    value = "发送失败";
                }
                break;
            case "errMsg":
                value = record.getErrMessage();
                break;
        }
        return value;
    }
}
