package ext.alphai.sap.MBOM;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sap.Config;
import ext.alphai.sap.entity.HuSendMBOMRecord;
import ext.alphai.sap.util.*;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.part.*;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class HUSendMBOMHelper extends StandardManager {

    // MBOM已被删除标识 ZDEL
    public static String MBOM_IS_DEL = "X";

    // 匈牙利视图名称
    public static String HU_FACTORY_VIEW_3101 = "3101";

    public static String HU_FACTORY_VIEW_3188 = "3188";

    // 定义日期格式化器，格式为 yyyyMMdd
    static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

    public static String SEND_HU_MBOM_Parent_PAR = Config.get("sap.Hu.MBOM.parent.pra");
    public static String SEND_HU_MBOM_Child_PAR = Config.get("sap.Hu.MBOM.child.pra");

    private static final long serialVersionUID = 1L;

    static final ObjectMapper objectMapper = new ObjectMapper();

    private static final Logger log = (Logger) LogR.getLogger(HUSendMBOMHelper.class.getName());

    public static HUSendMBOMHelper newHUSendMBOMHelper() throws WTException {
        HUSendMBOMHelper service = new HUSendMBOMHelper();
        service.initialize();
        return service;
    }

    /**
     * 检查BOM下所有物料视图是否为 3101 或 3188匈牙利视图
     * @param parts
     * @return
     */
    public static Set<String> noFactoryViewPartNum(List<WTPart> parts,String parentView){
        Set<String> errPartNumber = new HashSet<>();
        for (WTPart part : parts) {
            getAllBomByPart(part, errPartNumber,parentView);
        }
        return errPartNumber;
    }




    /**
     * 发送部件到SAP
     * @param parts
     * @return 接口返回信息
     */
    public static Set<HuSendMBOMRecord> sendMBOMToSAP(List<WTPart> parts) throws Exception {
        Set<HuSendMBOMRecord> result = new HashSet<>();

        // 该集合List 个数为层级也就是需要调用接口的次数   Set<WTPart>对象代表该层级的BOM部件
        List<Set<WTPart>> allBOMLevels = getAllBOMLevels(parts);

        log.info("---------以下是一次发送MBOM到匈牙利SAP-----------");
        for (int i = 0; i < allBOMLevels.size(); i++) {
            Set<WTPart> wtParts = allBOMLevels.get(i);

            // 每一层BOM发送一次
            String sendMBOMJson = getSendMBOMJson(wtParts, result);
            // 返回json
            String requestedJSON = CommonUtil.requestInterface(Config.get("sap.Hu.MBOM.url"), Config.getSendPartUsername(), Config.getSendPartPassword(), sendMBOMJson, "POST", null);
            int a = i+1;
            System.out.println("第"+a+"次调用发送MBOM接口的返回JSON为："+requestedJSON);
            log.info("第"+a+"次调用发送MBOM接口的返回JSON为："+requestedJSON);
            getJCHuMBOMSAPResponseJson(requestedJSON, result);

        }
        log.info("--------当前发送完毕--------");
        System.out.println("返回的处理结果集合为："+result.toString());
        return result;
    }


    /**
     * 处理捷昌发送MBOM到SAP接口返回值JSON
     * @param responseJson
     * @return
     */
    public static Set<HuSendMBOMRecord> getJCHuMBOMSAPResponseJson(String responseJson, Set<HuSendMBOMRecord> result) throws JSONException {
        // 解析 JSON 字符串
        JSONObject jsonObject = new JSONObject(responseJson);
        JSONArray dataArray = jsonObject.getJSONArray(SEND_HU_MBOM_Parent_PAR);
        // 遍历每个部件
        for (int i = 0; i < dataArray.length(); i++) {
            JSONObject data = dataArray.getJSONObject(i);
            // 获取 MATNR, WERKS ZTYPE 和 ZMSG 的值
            String matnr = data.optString("MATNR", "");
            //  工厂值
            String werks = data.optString("WERKS", "");
            String ztype = data.optString("ZTYPE", "");
            String zmsg = data.optString("ZMSG", "");
            // 创建 HuSendPartRecord 对象
            boolean respResult = "S".equals(ztype);  // 如果 ZTYPE 为 "S"，则是成功
            for (HuSendMBOMRecord record : result) {
                String number = record.getNumber();
                String factory = record.getFactory();
                if(number.equals(matnr) && factory.equals(werks)){
                    record.setResult(respResult);
                    record.setErrMessage(zmsg);
                }
            }
        }
        return result;
    }




    /**
     * 生成发送MBOM的JSON
     * @param parts 待发送的BOM
     * @param result 发送结果
     * @return
     */
    public static String getSendMBOMJson(Set<WTPart> parts, Set<HuSendMBOMRecord> result) throws IOException, WTException {
        Map<String, Object> map = new HashMap<String, Object>();

        // 当此发送的I_HEAD参数的组成是父项部件和下一层所有子项部件
        List<WTPart> parentListHead = new ArrayList<>();
        parentListHead.addAll(parts);
        for (WTPart part : parts) {
            String view = part.getView().getName();
            List<WTPartUsageLink> usageLinks = PartUtil.getLinksByPart(part);
            for (WTPartUsageLink usageLink : usageLinks) {
                WTPartMaster linkUses = usageLink.getUses();
                String number = linkUses.getNumber();

                WTPart latestWTPart = PartUtil.getLatestWTPart(number, null, null, view);
                parentListHead.add(latestWTPart);
            }
        }




        // 父项I_HEAD数据
        List<Object> mbomParentList = getParentReqObjectList(parentListHead, result);

        // 子项I_ITEM数据
        List<Object> mbomChildList = getChildReqObjectList(parts);

        map.put("PSTMP", "");

        map.put(SEND_HU_MBOM_Parent_PAR, mbomParentList);

        map.put(SEND_HU_MBOM_Child_PAR, mbomChildList);
        String json = objectMapper.writeValueAsString(map);
        System.out.println("发送物料到匈牙利SAP的MBOM JSON："+json);
        return json;
    }


    /**
     * 获取父项json对象
     *
     * @param parts
     * @return
     */
    private static List<Object> getParentReqObjectList(List<WTPart> parts, Set<HuSendMBOMRecord> resultVo) throws WTException {
        List<Object> result = new ArrayList<Object>();

        for (WTPart part : parts) {
            HuSendMBOMRecord vo = new HuSendMBOMRecord(part.getNumber(), part.getView().getName(),PersistenceUtil.object2Oid(part));
            HashMap<String, Object> parentReqObject = getParentReqObject(part);
            result.add(parentReqObject);
            resultVo.add(vo);
        }
        return result;
    }

    /**
     * 获取单个父项信息
     * @param part
     * @return
     */
    private static HashMap<String,Object> getParentReqObject(WTPart part) throws WTException {
        HashMap<String,Object> map = new HashMap<String, Object>();
        map.put("MATNR", part.getNumber());
        // 工厂
        String view = part.getView().getName();
        map.put("WERKS", view);
        // 可选

        map.put("STLAL", part.getVariation2().getValue());
        // 可选BOM文本
        map.put("STKTX", "");
        // 父件数量
        map.put("BMENG", PartUtil.getIBA(part, Config.get("sap.mm.function.parentpart.num")));

        System.out.println("父部件编号："+part.getNumber());
        String defaultUnit = part.getDefaultUnit().toString().toUpperCase();//默认单位
        System.out.println("父件单位转换前："+defaultUnit);
        // 单位转换
        Map<String, String> plmerpUnitMapping = UnitUtil.handleUnitConfig(Config.get("sap.mm.function.unit.mapping"));
        if(plmerpUnitMapping.containsKey(defaultUnit)) {
            defaultUnit = plmerpUnitMapping.get(defaultUnit);
        }
        String parentPartUnit = defaultUnit.toUpperCase();
        System.out.println("父件单位转换后："+parentPartUnit);
        // 父件单位
        map.put("BMEIN", parentPartUnit);

        // 有效起始日  接口发送日期
        // 获取今天的日期
        LocalDate today = LocalDate.now();
        // 格式化日期为字符串
        String formattedDate = today.format(formatter);

        map.put("DATUV", formattedDate);
        // 有效至
        map.put("VALID_TO", "99991231");
        // 如果父项不是BOM则该参数值为

        List<WTPartUsageLink> usageLinks = PartUtil.getLinksByPart(part);
        if(usageLinks.isEmpty()){
            map.put("ZDEL", MBOM_IS_DEL);
        }else {
            map.put("ZDEL", "");
        }

        return map;
    }




    /**
     * 获取子项json对象
     * @param parts
     * @return
     */
    private static List<Object> getChildReqObjectList(Set<WTPart> parts){
        List<Object> result = new ArrayList<Object>();

        for (WTPart part : parts) {
            List<Object> childReqObject = getChildReqObject(part);
            result.addAll(childReqObject);
        }
        return result;
    }

    /**
     * 获取单个父项 的子料信息
     * @param part
     * @return
     */
    private static List<Object> getChildReqObject(WTPart part){
        List<Object> result = new ArrayList<Object>();

        List<WTPartUsageLink> usageLinks = PartUtil.getLinksByPart(part);

        for (WTPartUsageLink usageLink : usageLinks) {
            String childNum = usageLink.getUses().getNumber();
            LineNumber lineNumber = usageLink.getLineNumber();
            String lineNumStr = "";
            if (lineNumber != null){
                lineNumStr = lineNumber.toString();
            }

            Quantity quantity = usageLink.getQuantity();
            String childAmountStr = "";
            if(quantity != null){
                double childAmount = usageLink.getQuantity().getAmount();
                childAmountStr = Double.toString(childAmount);
            }
            // 子项单位进行映射
            String childUnitStr = usageLink.getQuantity().getUnit().toString();
            System.out.println("子部件编号："+childNum);
            System.out.println("子件单位转换前："+childUnitStr);
            // 单位转换
            Map<String, String> plmerpUnitMapping = UnitUtil.handleUnitConfig(Config.get("sap.mm.function.unit.mapping"));
            if(plmerpUnitMapping.containsKey(childUnitStr)) {
                childUnitStr = plmerpUnitMapping.get(childUnitStr);
            }

            HashMap<String,Object> map = new HashMap<String, Object>();

            map.put("MATNR", part.getNumber());
            // 工厂
            String view = part.getView().getName();
            map.put("WERKS", view);
            // 项目号（行号）
            map.put("POSNR", lineNumStr);
            // 子件编码
            map.put("IDNRK", childNum);
            // 子件数量
            map.put("MENGE", childAmountStr);

            String childUnitStrUpperCase = childUnitStr.toUpperCase();
            System.out.println("子件单位转换后："+childUnitStrUpperCase);
            // 子件计量单位
            map.put("MEINS", childUnitStrUpperCase);

            // 有效起始日  接口发送日期
            // 获取今天的日期
            LocalDate today = LocalDate.now();
            // 格式化日期为字符串
            String formattedDate = today.format(formatter);

            map.put("DATUV", formattedDate);
            // 有效至
            map.put("VALID_TO", "99991231");
            result.add(map);

        }

        return result;
    }

    /**
     * 传入一个BOM 判断它的子项是否有BOM 如果有返回子项对象
     * @param part
     * @return
     */
    private static List<WTPart> isMBOM(WTPart part) throws WTException {
        List<WTPart> result = new ArrayList<WTPart>();
        String view = part.getView().getName();
        List<WTPartUsageLink> usageLinks = PartUtil.getLinksByPart(part);
        for (WTPartUsageLink usageLink : usageLinks) {
            WTPartMaster master = usageLink.getUses();
            WTPart child = PartUtil.getLatestWTPart(master.getNumber(),null,null,view);
            List<WTPartUsageLink> linksByPart = PartUtil.getLinksByPart(child);
            if(!linksByPart.isEmpty()){
                result.add(child);
            }
        }
        return result;
    }



    // 获取所有层级的BOM结构
    public static List<Set<WTPart>> getAllBOMLevels(List<WTPart> parents) throws WTException {
        List<Set<WTPart>> result = new ArrayList<>();
        // 第0层直接添加parents
        Set<WTPart> firstLevel = new HashSet<>(parents);
        result.add(firstLevel);

        // 递归获取后续的BOM层级
        getBOMLevelsRecursively(parents, result, 1);
        return result;
    }

    // 递归获取每一层BOM结构
    private static void getBOMLevelsRecursively(List<WTPart> currentLevelParts, List<Set<WTPart>> result, int currentLevel) throws WTException {
        // 当前层BOM结构的集合
        Set<WTPart> nextLevelParts = new HashSet<>();

        // 遍历当前层的所有部件
        for (WTPart part : currentLevelParts) {
            // 获取当前部件的BOM子部件
            List<WTPart> bomChildren = isMBOM(part);
            if (!bomChildren.isEmpty()) {
                nextLevelParts.addAll(bomChildren);
            }
        }

        // 如果存在下一层BOM部件，将其加入到结果集中
        if (!nextLevelParts.isEmpty()) {
            result.add(nextLevelParts);
            // 递归处理下一层
            getBOMLevelsRecursively(new ArrayList<>(nextLevelParts), result, currentLevel + 1);
        }
    }




    /**
     * 递归获取部件的所有子部件
     *
     * @param part BOM
     * @return List<WTPart>
     */
    public static List<WTPart> getAllBomByPart(WTPart part, Set<String> errPartNum, String parentView) {
        List<WTPart> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        WTPart sPart = null;
        QueryResult qr2 = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                WTPartMaster master = usageLink.getUses();
                sPart = PartUtil.getLatestWTPart(master.getNumber(), null, null, parentView);
                if(sPart != null){
                    localList.add(sPart);
                }else {
                    errPartNum.add(master.getNumber());
                }
                localList.addAll(getAllBomByPart(sPart, errPartNum, parentView));
//                qr2 = VersionControlHelper.service.allVersionsOf(master);
//                if (qr2.hasMoreElements()) {
//                    sPart = (WTPart) qr2.nextElement();
//                    String view = sPart.getView().getName();
//                    if(parentView.equals(view)){
//                        localList.add(sPart);
//                    }else {
//                        errPartNum.add(sPart.getNumber());
//                    }
//                    // 递归调用，将结果合并到局部列表
//                    localList.addAll(getAllBomByPart(sPart, errPartNum, parentView));
//                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }











    /**
     * 递归获取部件的所有子部件
     * errPartList 没有匈牙利视图的部件集合
     * @param part BOM
     * @param parentView 子项取与父项相同视图
     * @return List<WTPart> 返回值是所有匈牙利工厂部件
     */
    public static List<WTPart> getAllBomByPart(WTPart part, List<WTPart> errPartList, String parentView) {
        List<WTPart> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        WTPart sPart = null;
        QueryResult qr2 = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                WTPartMaster master = usageLink.getUses();
                sPart = PartUtil.getLatestWTPart(master.getNumber(), null, null, parentView);
                if(sPart != null){
                    localList.add(sPart);
                }else {
                    errPartList.add(PartUtil.getLatestWTPart(master.getNumber(), null, null, "Design"));
                }
                localList.addAll(getAllBomByPart(sPart, errPartList, parentView));
//                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
//                if (qr2.hasMoreElements()) {
//                    sPart = (WTPart) qr2.nextElement();
//                    String view = sPart.getView().getName();
//                    if(parentView.equals(view)){
//                        localList.add(sPart);
//                    }else {
//                        errPartList.add(sPart);
//                    }
//                    // 递归调用，将结果合并到局部列表
//                    localList.addAll(getAllBomByPart(sPart, errPartList,parentView));
//                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }


    /**
     * 检查所有BOM是否有重复编号
     * @param boms
     * @return
     */
    public static Map<WTPart, List<String>> sameChildPartNum(List<WTPart> boms) throws WTException {

        Map<WTPart, List<String>> map = new HashMap<>();

        // 获取全部部件的BOM
        List<WTPart> bomParts = getBOMParts(boms);

        for (WTPart bomPart : bomParts) {
            List<WTPartUsageLink> links = PartUtil.getLinksByPart(bomPart);
            List<String> masterNums = new ArrayList<>();
            for (WTPartUsageLink link : links) {
                String childNum = link.getUses().getNumber();
                masterNums.add(childNum);
            }
            // 找到BOM中存在重复的子部件
            List<String> duplicates = findDuplicates(masterNums);
            if(!duplicates.isEmpty()){
                map.put(bomPart, duplicates);
            }
        }


        return map;
    }




    // 方法：递归返回所有有BOM结构的WTPart
    public static List<WTPart> getBOMParts(List<WTPart> allParts) throws WTException{
        List<WTPart> bomParts = new ArrayList<>();

        // 遍历所有WTPart部件
        for (WTPart part : allParts) {
            // 递归地检查BOM结构
            collectBOMParts(part, bomParts);
        }

        return bomParts;
    }

    // 递归收集所有BOM结构的WTPart部件
    private static void collectBOMParts(WTPart part, List<WTPart> bomParts) throws WTException{
        String viewName = part.getView().getName();
        // 如果该部件有BOM结构并且未添加到结果列表中
        if (isBOMPart(part) && !bomParts.contains(part)) {
            bomParts.add(part);  // 添加到结果列表
        }

        // 获取该部件的子部件（递归检查它们）
        List<WTPartUsageLink> links = PartUtil.getLinksByPart(part);
        for (WTPartUsageLink link : links) {
            String childNum = link.getUses().getNumber();
            // 获取子部件
            WTPart childPart =PartUtil.getLatestWTPart(childNum, null, null, viewName);
            if(childPart !=null){
                collectBOMParts(childPart, bomParts);  // 递归调用
            }
        }
    }

    // 判断一个WTPart是否包含BOM结构
    private static boolean isBOMPart(WTPart part) {
        // 这里可以加入根据具体逻辑判断部件是否具有BOM结构
        List<WTPartUsageLink> links = PartUtil.getLinksByPart(part);
        return !links.isEmpty();  // 如果有BOM链接，说明有BOM结构
    }





    /**
     * 获取BOM下相同编号
     * @param childs
     * @return
     */
    public static List<String> findDuplicates(List<String> childs) {
        // 创建一个Map，用来统计字符串出现次数
        HashMap<String, Integer> countMap = new HashMap<>();

        // 遍历childs集合，记录每个字符串出现的次数
        for (String child : childs) {
            countMap.put(child, countMap.getOrDefault(child, 0) + 1);
        }

        // 存放重复的字符串
        ArrayList<String> result = new ArrayList<>();

        // 查找出现次数大于1的字符串并加入result
        for (String key : countMap.keySet()) {
            if (countMap.get(key) > 1) {
                result.add(key);
            }
        }

        return result;
    }




}
