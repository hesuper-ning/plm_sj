package ext.alphai.sap.MBOM;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sap.Config;
import ext.alphai.sap.entity.HuSendMBOMRecord;
import ext.alphai.sap.entity.HuSendPartRecord;
import ext.alphai.sap.part.HUSendPartHelper;
import ext.alphai.sap.util.PartUtil;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.*;

/**
 * 物料操作按钮 发送MBOM到匈牙利SAP
 */
public class SendMBOMToHuSAPProcessor extends DefaultObjectFormProcessor {

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        try{
            if(content instanceof WTPart){
                WTPart part = (WTPart) content;

                String view = part.getView().getName();

                if(!HUSendMBOMHelper.HU_FACTORY_VIEW_3101.equals(view) && !HUSendMBOMHelper.HU_FACTORY_VIEW_3188.equals(view)){
                    throw new WTException("This part is not a view of a Hungarian factory！");
                }

                List<WTPart> partList = new ArrayList<WTPart>();
                partList.add(part);





                String check = Config.get("sap.Hu.MBOM.factory.check");
                if("yes".equalsIgnoreCase(check)){
                    System.out.println("--------开启子BOM 工厂视图 3101 或 3188 校验-----");
                    // 递归获取BOM下全部子件并要求所有子件都是匈牙利视图
                    Set<String> errViewPartNum = HUSendMBOMHelper.noFactoryViewPartNum(partList,view);
                    if(!errViewPartNum.isEmpty()){
                        throw new WTException("In BOM"+errViewPartNum+"part not have"+ view +" Hungarian factory view Please check!");
                    }
                }
                System.out.println("--------通过子BOM 工厂视图 3101 或 3188 校验-----");



                // 物料BOM下如果有多个相同编号部件 抛异常
                Map<WTPart, List<String>> stringListMap = HUSendMBOMHelper.sameChildPartNum(partList);
                if(!stringListMap.isEmpty()){
                    StringBuilder sb = new StringBuilder();
                    Set<Map.Entry<WTPart, List<String>>> entries = stringListMap.entrySet();
                    for (Map.Entry<WTPart, List<String>> entry : entries) {
                        String number = entry.getKey().getNumber();
                        List<String> value = entry.getValue();
                        sb.append("BOM:").append(number).append("Sub item number").append(Arrays.toString(new List[]{value})).append("There is duplication").append("\r\n");
                    }
                    throw new WTException("Detect BOM："+sb);
                }



                Set<String> errPartNumber = new HashSet<>();

                List<WTPart> allBomByPart = HUSendMBOMHelper.getAllBomByPart(part, errPartNumber, view);
                allBomByPart.add(part);


                // 发送BOM相关所有子项物料到匈牙利
                List<HuSendPartRecord> huSendPartRecords = HUSendPartHelper.sendPartToSAP(allBomByPart, Config.BUTTON);

                List<HuSendPartRecord> errSendPartRecords = new ArrayList<>();
                StringBuilder sb = new StringBuilder();
                for (HuSendPartRecord huSendPartRecord : huSendPartRecords){

                    // 如果有发送失败的物料抛出异常
                    if(!huSendPartRecord.isResult()){
                        errSendPartRecords.add(huSendPartRecord);
                        sb.append(huSendPartRecord.getNumber()).append("\r\n").append("Error Message:").append(huSendPartRecord.getErrMessage()).append(",").append("\r\n");
                    }
                }

                System.out.println("当前发送物料失败的个数为:"+errSendPartRecords.size());
                if(!errSendPartRecords.isEmpty()){
                    throw new WTException("The material number in the BOM is"+sb+"Sending materials to SAP Hungary failed. Please confirm！");
                }



                // 发送到匈牙利SAP
                // http返回值
                Set<HuSendMBOMRecord> records = HUSendMBOMHelper.sendMBOMToSAP(partList);
                for (HuSendMBOMRecord mbomRecord : records) {
                    boolean resp = mbomRecord.isResult();
                    if(!resp){
                        FormResult result = new FormResult(FormProcessingStatus.FAILURE);
                        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(),null,null,new String[]{"MBOM Number："+mbomRecord.getNumber()+"Sending Hungarian SAP failed"+"The error message is:"+mbomRecord.getErrMessage()}));
                        return result;
                    }
                }
            }
        }catch (Exception e) {
            FormResult result = new FormResult(FormProcessingStatus.FAILURE);
            result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(),null,null,new String[]{e.getMessage()}));
            return result;
        }
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS,SessionHelper.getLocale(),null,null,new String[]{"Successfully sent MBOM to SAP Hungary。"}));
        return result;
    }


}
