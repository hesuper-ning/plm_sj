package ext.alphai.sap.MBOM.MVC;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.htmlcomp.components.AbstractConfigurableTableBuilder;
import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.jca.mvc.components.JcaTableConfig;
import com.ptc.mvc.components.*;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sap.CustomActionsRB;
import ext.alphai.sap.MBOM.work.SendMBOMToHuWork;
import ext.alphai.sap.entity.HuSendPartRecord;
import org.apache.commons.lang3.StringUtils;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import java.util.ArrayList;
import java.util.List;

/**
 * 发送MBOM相关 部件 返回信息table
 */
@ComponentBuilder("ext.alphai.sap.MBOM.MVC.SendMBOMPartTable")
public class SendMBOMPartTable extends AbstractConfigurableTableBuilder {


    public static final String RESOURCE = CustomActionsRB.class.getName();
    static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
        final ComponentConfigFactory factory = getComponentConfigFactory();
        final JcaTableConfig table; {
            table = (JcaTableConfig)factory.newTableConfig();
            table.setComponentMode(ComponentMode.VIEW);
            table.setAutoGenerateRowId(true);
            table.setType(WTPart.class.getName());
            table.setLabel(WTMessage.getLocalizedMessage(RESOURCE,
                    CustomActionsRB.PRIVATE_CONSTANT_001, null));
            // 条件过滤model
//            table.setActionModel("quotationActionList");
            table.setSelectable(true);
            table.setShowCount(true);
//            table.setShowCustomViewLink(false);
            table.setConfigurable(true);
            final ColumnConfig name; {
                name = factory.newColumnConfig(WTPart.NUMBER, true);
                name.setInfoPageLink(true);
                name.setSortable(true);
            }
            // 添加物料编号列并生成链接
            ColumnConfig partNum = factory.newColumnConfig("partNum", true);
            partNum.setLabel("物料编号");
            partNum.setDataUtilityId("HUSendPartUtility");
            partNum.setRenderAllStates(true);
            table.addComponent(partNum);

            ColumnConfig partName = factory.newColumnConfig("partName", true);
            partName.setLabel("物料名称");
            partName.setDataUtilityId("HUSendPartUtility");
            table.addComponent(partName);

            ColumnConfig result = factory.newColumnConfig("result", true);
            result.setLabel("发送结果");
            result.setDataUtilityId("HUSendPartUtility");
            table.addComponent(result);

            ColumnConfig errMsg = factory.newColumnConfig("errMsg", true);
            errMsg.setLabel("错误信息");
            errMsg.setDataUtilityId("HUSendPartUtility");
            table.addComponent(errMsg);
        }
        return table;
    }

    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        JcaComponentParams jca_params = (JcaComponentParams) componentParams;
        NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
        NmOid primaryOid2 = cb.getPrimaryOid();
        List<HuSendPartRecord> result = new ArrayList<>();
        if (primaryOid2 != null) {
            Object content = primaryOid2.getRef();
            if (content instanceof WorkItem) {
                WorkItem wi = (WorkItem) content;
                System.out.println("wi:" + wi);
                WfAssignedActivity wfAssignedActivity = (WfAssignedActivity) wi.getSource().getObject();
                WfProcess wfProcess = wfAssignedActivity.getParentProcess();
                System.out.println("wfProcess:" + wfProcess);
                String json = (String) wfProcess.getContext().getValue(SendMBOMToHuWork.MBOM_Send_PART_MSG);
                // 拆解json
                if(!StringUtils.isBlank(json)){
                    result = objectMapper.readValue(json, new TypeReference<List<HuSendPartRecord>>() {});;
                }
            }
        }
        return result;
    }




    @Override
    public ConfigurableTable buildConfigurableTable(String s) throws WTException {
        return null;
    }
}
