package ext.alphai.sap.MBOM.work;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sap.Config;
import ext.alphai.sap.MBOM.HUSendMBOMHelper;
import ext.alphai.sap.entity.HuSendMBOMRecord;
import ext.alphai.sap.entity.HuSendPartRecord;
import ext.alphai.sap.part.HUSendPartHelper;
import ext.alphai.sap.util.PersistenceUtil;
import ext.alphai.sap.util.WorkflowUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import wt.fc.WTObject;
import wt.log4j.LogR;
import wt.part.WTPart;

import java.io.IOException;
import java.util.*;

/**
 * 发送MBOM到匈牙利SAP流程表达式类
 * 升级请求  产生的对象
 */
public class SendResObjMBOMToHuWork {

    // 校验MBOM相关物料是否为匈牙利工厂流程全局变量
    public static final String CHECK_PART_Fac = "HUSendMBOMCheck";


    // 发送MBOM相关物料是否发送成功流程全局变量
    public static final String MBOM_Send_PART_MSG = "HUMBOMSendPartMsg";

    // 发送MBOM 返回结果 流程全局变量
    public static final String SEND_MBOM_MSG = "HUSendMBOMRes";


    static final ObjectMapper objectMapper = new ObjectMapper();
    private static final Logger log = (Logger) LogR.getLogger(SendResObjMBOMToHuWork.class.getName());
    /**
     * 发送MBOM
     * @param pbo
     */
    public static String sendMBOM2HuSAP(WTObject pbo, String HUSendMBOMRes){

        System.out.println("--------------正在执行发送MBOM到匈牙利SAP表达式----------------");
        String msg ="";

        try {
            if(StringUtils.isBlank(HUSendMBOMRes)){
                System.out.println("当前发MBOM 结果变量为空 判定为第一次发送");
            }else {
                System.out.println("当前发MBOM 结果变量不为空 判定为重复发送");
            }

            // 从受影响对象种取到部件列表
            ArrayList<WTPart> targerObject = WorkflowUtil.getTargerObject(pbo, "ResultingObjects", WTPart.class);
            System.out.println("流程中产生的对象部件个数为："+targerObject.size());
            Set<HuSendMBOMRecord> records = HUSendMBOMHelper.sendMBOMToSAP(targerObject);
            String json = objectMapper.writeValueAsString(records);
            System.out.println("流程发送MBOM结果json:"+json);
            // 放到流程变量里
            msg = json;

        } catch (Exception e){
            log.error(e.getMessage(), e);
        }
        return msg;
    }


    /**
     * 发送MBOM前置操作
     * 1.检查MBOM相关物料是否都为 3101或3188 视图
     * @param pbo
     * @return
     */
    public static String sendMBOMCheckPart(WTObject pbo) throws Exception {
        System.out.println("--------------正在执行MBOM到匈牙利SAP部件工厂判断表达式----------------");
        String json = "";
        ArrayList<WTPart> targerObject = WorkflowUtil.getTargerObject(pbo, "AffectedObjects", WTPart.class);
        // 检查
        // 匈牙利工厂部件集合
        List<WTPart> HUFactoryPartLists = new ArrayList<>();
        // 非匈牙利工厂集合
        List<WTPart> noHUFactoryPartLists = new ArrayList<>();

        for (WTPart part : targerObject) {
            String view = part.getView().getName();
            // 当前BOM
            List<WTPart> noFactoryPart = new ArrayList<>();
            List<WTPart> allBomByPart = HUSendMBOMHelper.getAllBomByPart(part,noFactoryPart, view);
            if(HUSendMBOMHelper.HU_FACTORY_VIEW_3101.equals(view) || HUSendMBOMHelper.HU_FACTORY_VIEW_3188.equals(view)){
                allBomByPart.add(part);
            }else {
                noFactoryPart.add(part);
            }
            HUFactoryPartLists.addAll(allBomByPart);
            noHUFactoryPartLists.addAll(noFactoryPart);
        }
        List<HuSendPartRecord> records = new ArrayList<>();
        // 代表有部件不是匈牙利工厂
        if(!noHUFactoryPartLists.isEmpty()){

            for (WTPart noHUFactoryPart : noHUFactoryPartLists) {
                HuSendPartRecord record = new HuSendPartRecord(PersistenceUtil.object2Oid(noHUFactoryPart), noHUFactoryPart.getNumber());
                record.setResult(false);
                record.setErrMessage("部件没有匈牙利工厂 3101或3188视图");
                records.add(record);
            }

            System.out.println("***********当前待发送的MBOM中存在 没有匈牙利工厂的部件***********");

        }


        Map<WTPart, List<String>> stringListMap = HUSendMBOMHelper.sameChildPartNum(targerObject);
        // BOM中有相同编号的使用关系
        if(!stringListMap.isEmpty()){
            System.out.println("***********BOM中有重复编号子项***********");
            Set<Map.Entry<WTPart, List<String>>> entries = stringListMap.entrySet();

            for (Map.Entry<WTPart, List<String>> entry : entries) {
                WTPart key = entry.getKey();
                HuSendPartRecord record = new HuSendPartRecord(PersistenceUtil.object2Oid(key), key.getNumber());
                record.setResult(false);
                record.setErrMessage("BOM下有相同编号子件："+Arrays.toString(new List[]{entry.getValue()}));
                records.add(record);
            }
        }
        if(!records.isEmpty()){
            json = objectMapper.writeValueAsString(records);
        }
        return json;
    }


    /**
     * 发送所有MBOM相关物料
     */
    public static String sendMBOMSendPart(WTObject pbo) throws Exception {
        System.out.println("--------------正在执行MBOM到匈牙利SAP部件发送表达式----------------");
        String json = "";
        ArrayList<WTPart> targerObject = WorkflowUtil.getTargerObject(pbo, "AffectedObjects", WTPart.class);
        // 检查
        // 匈牙利工厂部件集合
        List<WTPart> HUFactoryPartLists = new ArrayList<>();
        for (WTPart part : targerObject) {
            String view = part.getView().getName();
            // 当前BOM
            List<WTPart> noFactoryPart = new ArrayList<>();
            List<WTPart> allBomByPart = HUSendMBOMHelper.getAllBomByPart(part,noFactoryPart, view);
            if(HUSendMBOMHelper.HU_FACTORY_VIEW_3101.equals(view) || HUSendMBOMHelper.HU_FACTORY_VIEW_3188.equals(view)){
                allBomByPart.add(part);
            }
            HUFactoryPartLists.addAll(allBomByPart);
        }
        // 发送MBOM相关部件到物料接口
        List<HuSendPartRecord> records = HUSendPartHelper.sendPartToSAP(HUFactoryPartLists, Config.BUTTON);
        json = objectMapper.writeValueAsString(records);
        return json;
    }

    /**
     * 检查 发送MBOM前置条件是否满足
     * @param HUSendMBOMCheck
     * @return
     */
    public static String checkMBOMPreOperation(String HUSendMBOMCheck, String HUMBOMSendPartMsg){
        String result = null;
        System.out.println("--------进入发送MBOM前置条件过滤方法------");
        try {
            if(!StringUtils.isBlank(HUSendMBOMCheck)){
                result = "fail";
            }
            // 如果checkPartFacVOs为空代表MBOM通过了是否为匈牙利工厂校验

            System.out.println("读取到流程部件工厂全局变量值为:"+HUSendMBOMCheck);

            System.out.println("读取到流程部件发送SAP结果全局变量值为:"+HUMBOMSendPartMsg);
            if(StringUtils.isBlank(HUSendMBOMCheck) && !StringUtils.isBlank(HUMBOMSendPartMsg)){
                List<HuSendMBOMRecord> sendPartVOs = objectMapper.readValue(HUMBOMSendPartMsg, new TypeReference<List<HuSendMBOMRecord>>() {});
                for (HuSendMBOMRecord sendPartVO : sendPartVOs) {
                    if (!sendPartVO.isResult()) {
                        result = "fail";
                        break;
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            result = "fail";
        }

        if(result == null){
            result = "successful";
        }
        return result;
    }





    /**
     * 校验SAP给出的信息中是否存在错误信息
     *
     * @param res
     * @return fail/successful
     */
    public static String checkSendMBOMRes(String res) {
        String result = null;
        System.out.println("进入发送MBOM解析返回值接口");
        try {
            List<HuSendMBOMRecord> vos = objectMapper.readValue(res, new TypeReference<List<HuSendMBOMRecord>>() {});
            System.out.println("当前解析到的发送BOM 结果集合为："+vos);
            for (HuSendMBOMRecord vo : vos) {
                if (!vo.isResult()) {
                    result  = "fail";
                    break;
                }
            }
        } catch (IOException e) {
            log.error(e.getMessage(),e);
            result = "fail";
        }

        if(result == null){
            result = "successful";
            System.out.println("发送MBOM成功！");
        }
        return result;
    }
}
