package ext.alphai.sap.entity;

/**
 * 发送物料到匈牙利SAP记录类
 */
public class HuSendPartRecord {
    // 部件编号
    private String number;

    // 部件OID
    private String partOid;

    // 发送成功或者失败的结果
    private boolean result;

    // 错误信息
    private String errMessage;

    public HuSendPartRecord(String partOid, String number) {
        this.partOid = partOid;
        this.number = number;
    }

    public HuSendPartRecord() {
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPartOid() {
        return partOid;
    }

    public void setPartOid(String partOid) {
        this.partOid = partOid;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    @Override
    public String toString() {
        return "HuSendPartRecord{" +
                "number='" + number + '\'' +
                ", partOid='" + partOid + '\'' +
                ", result=" + result +
                ", errMessage='" + errMessage + '\'' +
                '}';
    }
}
