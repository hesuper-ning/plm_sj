package ext.alphai.sap.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 发送部件
 */
public class HuSendPartEntity {
    // 访问ID
    @JsonProperty("IV_ZIFID")
    private String visitId;

    // 物料状态
    @JsonProperty("MAT_STATUS")
    private String partState;

    // 行业
    @JsonProperty("MBRSH")
    private String industry;

    // 物料类型
    @JsonProperty("MBRSH")
    private String partType;

    // 物料编号
    @JsonProperty("MATNR")
    private String partNumber;

    // 旧物料编号
    @JsonProperty("BISMT")
    private String oldPartNumber;


    // 物料描述
    @JsonProperty("ZMAKTX")
    private String ZPartDescribe;

    // 物料描述
    @JsonProperty("EMAKTX")
    private String EPartDescribe;


    // 基本计量单位
    @JsonProperty("MEINS")
    private String BUoM;

    // 物料组
    @JsonProperty("MATKL")
    private String partGroup;

    // 中文长描述
    @JsonProperty("ZCTEXT")
    private String zhLongDescribe;

    // 英文长文本
    @JsonProperty("ECTEXT")
    private String enLongDescribe;

    // 客供料标识
    @JsonProperty("ZFLAG")
    private String customSupplyIdent;

    // 图纸
    @JsonProperty("DRAWNO")
    private String partDrawing;

    // 图纸版本
    @JsonProperty("DRAWVERSION")
    private String partDrawingVersion;

    // 物料被锁定
    @JsonProperty("MATFI")
    private String partLocked;

    // 工厂特定的物料状态
    @JsonProperty("MMSTA")
    private String factoryPartState;

    // 产品组
    @JsonProperty("SPART")
    private String productGroup;

    // 实验室/设计室
    @JsonProperty("LABOR")
    private String laboratoryOrDesign;

    // 净重
    @JsonProperty("NTGEW")
    private double netWeight;

    // 重量单位
    @JsonProperty("GEWEI")
    private String unitOfWeight;

    // 长度
    @JsonProperty("LAENG")
    private double length;

    // 宽度
    @JsonProperty("BREIT")
    private double width;

    // 宽度
    @JsonProperty("HOEHE")
    private double height;

    // 长宽高的尺寸单位
    @JsonProperty("MEABM")
    private String unitOfMeasurement;

    // 业务量
    @JsonProperty("VOLUM")
    private double businessVolume;

    // 体积单位
    @JsonProperty("VOLEH")
    private String volumeUnit;

    // 大小/量纲
    @JsonProperty("GROES")
    private String sizeOrDimension;

    // 管材类型
    @JsonProperty("CUBETYPE")
    private String pipeType;

    // 颜色
    @JsonProperty("COLOUR")
    private String colour;

    // 返回类型
    @JsonProperty("ZTYPE")
    private String backType;

    // 返回消息
    @JsonProperty("ZMSG")
    private String backMsg;


    @JsonIgnore
    public String getVisitId() {
        return visitId;
    }

    @JsonIgnore
    public void setVisitId(String visitId) {
        this.visitId = visitId;
    }

    @JsonIgnore
    public String getPartState() {
        return partState;
    }

    @JsonIgnore

    public void setPartState(String partState) {
        this.partState = partState;
    }

    @JsonIgnore

    public String getIndustry() {
        return industry;
    }

    @JsonIgnore

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    @JsonIgnore

    public String getPartType() {
        return partType;
    }

    @JsonIgnore

    public void setPartType(String partType) {
        this.partType = partType;
    }

    @JsonIgnore

    public String getPartNumber() {
        return partNumber;
    }

    @JsonIgnore

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    @JsonIgnore

    public String getOldPartNumber() {
        return oldPartNumber;
    }

    @JsonIgnore

    public void setOldPartNumber(String oldPartNumber) {
        this.oldPartNumber = oldPartNumber;
    }

    @JsonIgnore

    public String getZPartDescribe() {
        return ZPartDescribe;
    }

    @JsonIgnore

    public void setZPartDescribe(String ZPartDescribe) {
        this.ZPartDescribe = ZPartDescribe;
    }

    @JsonIgnore

    public String getEPartDescribe() {
        return EPartDescribe;
    }

    @JsonIgnore

    public void setEPartDescribe(String EPartDescribe) {
        this.EPartDescribe = EPartDescribe;
    }

    @JsonIgnore

    public String getBUoM() {
        return BUoM;
    }

    @JsonIgnore

    public void setBUoM(String BUoM) {
        this.BUoM = BUoM;
    }

    @JsonIgnore

    public String getPartGroup() {
        return partGroup;
    }

    @JsonIgnore

    public void setPartGroup(String partGroup) {
        this.partGroup = partGroup;
    }

    @JsonIgnore

    public String getZhLongDescribe() {
        return zhLongDescribe;
    }

    @JsonIgnore

    public void setZhLongDescribe(String zhLongDescribe) {
        this.zhLongDescribe = zhLongDescribe;
    }

    @JsonIgnore

    public String getEnLongDescribe() {
        return enLongDescribe;
    }

    @JsonIgnore

    public void setEnLongDescribe(String enLongDescribe) {
        this.enLongDescribe = enLongDescribe;
    }

    @JsonIgnore

    public String getCustomSupplyIdent() {
        return customSupplyIdent;
    }

    @JsonIgnore

    public void setCustomSupplyIdent(String customSupplyIdent) {
        this.customSupplyIdent = customSupplyIdent;
    }

    @JsonIgnore

    public String getPartDrawing() {
        return partDrawing;
    }

    @JsonIgnore

    public void setPartDrawing(String partDrawing) {
        this.partDrawing = partDrawing;
    }

    @JsonIgnore

    public String getPartDrawingVersion() {
        return partDrawingVersion;
    }

    @JsonIgnore

    public void setPartDrawingVersion(String partDrawingVersion) {
        this.partDrawingVersion = partDrawingVersion;
    }

    @JsonIgnore

    public String getPartLocked() {
        return partLocked;
    }

    @JsonIgnore

    public void setPartLocked(String partLocked) {
        this.partLocked = partLocked;
    }

    @JsonIgnore

    public String getFactoryPartState() {
        return factoryPartState;
    }

    @JsonIgnore

    public void setFactoryPartState(String factoryPartState) {
        this.factoryPartState = factoryPartState;
    }

    @JsonIgnore

    public String getProductGroup() {
        return productGroup;
    }

    @JsonIgnore

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    @JsonIgnore

    public String getLaboratoryOrDesign() {
        return laboratoryOrDesign;
    }

    @JsonIgnore

    public void setLaboratoryOrDesign(String laboratoryOrDesign) {
        this.laboratoryOrDesign = laboratoryOrDesign;
    }

    @JsonIgnore

    public double getNetWeight() {
        return netWeight;
    }

    @JsonIgnore

    public void setNetWeight(double netWeight) {
        this.netWeight = netWeight;
    }

    @JsonIgnore

    public String getUnitOfWeight() {
        return unitOfWeight;
    }

    @JsonIgnore

    public void setUnitOfWeight(String unitOfWeight) {
        this.unitOfWeight = unitOfWeight;
    }

    @JsonIgnore

    public double getLength() {
        return length;
    }

    @JsonIgnore

    public void setLength(double length) {
        this.length = length;
    }

    @JsonIgnore

    public double getWidth() {
        return width;
    }

    @JsonIgnore

    public void setWidth(double width) {
        this.width = width;
    }

    @JsonIgnore

    public double getHeight() {
        return height;
    }

    @JsonIgnore

    public void setHeight(double height) {
        this.height = height;
    }

    @JsonIgnore

    public String getUnitOfMeasurement() {
        return unitOfMeasurement;
    }

    @JsonIgnore

    public void setUnitOfMeasurement(String unitOfMeasurement) {
        this.unitOfMeasurement = unitOfMeasurement;
    }

    @JsonIgnore

    public double getBusinessVolume() {
        return businessVolume;
    }

    @JsonIgnore

    public void setBusinessVolume(double businessVolume) {
        this.businessVolume = businessVolume;
    }

    @JsonIgnore

    public String getVolumeUnit() {
        return volumeUnit;
    }

    @JsonIgnore

    public void setVolumeUnit(String volumeUnit) {
        this.volumeUnit = volumeUnit;
    }

    @JsonIgnore

    public String getSizeOrDimension() {
        return sizeOrDimension;
    }

    @JsonIgnore

    public void setSizeOrDimension(String sizeOrDimension) {
        this.sizeOrDimension = sizeOrDimension;
    }

    @JsonIgnore

    public String getPipeType() {
        return pipeType;
    }

    @JsonIgnore

    public void setPipeType(String pipeType) {
        this.pipeType = pipeType;
    }

    @JsonIgnore

    public String getColour() {
        return colour;
    }

    @JsonIgnore

    public void setColour(String colour) {
        this.colour = colour;
    }

    @JsonIgnore

    public String getBackType() {
        return backType;
    }

    @JsonIgnore

    public void setBackType(String backType) {
        this.backType = backType;
    }

    @JsonIgnore

    public String getBackMsg() {
        return backMsg;
    }

    @JsonIgnore

    public void setBackMsg(String backMsg) {
        this.backMsg = backMsg;
    }
}
