package ext.alphai.sap.entity;

import java.util.Objects;

/**
 * 发送MBOM到匈牙利SAP记录类
 */
public class HuSendMBOMRecord {
    // 部件编号
    private String number;

    // 部件工厂
    private String factory;
    // 部件OID
    private String partOid;

    // 发送成功或者失败的结果
    private boolean result;

    // 错误信息
    private String errMessage;

    public HuSendMBOMRecord() {
    }

    public String getFactory() {
        return factory;
    }

    public void setFactory(String factory) {
        this.factory = factory;
    }

    public HuSendMBOMRecord(String number, String factory, String partOid) {
        this.number = number;
        this.factory = factory;
        this.partOid = partOid;
    }

    public HuSendMBOMRecord(String number, String partOid) {
        this.number = number;
        this.partOid = partOid;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPartOid() {
        return partOid;
    }

    public void setPartOid(String partOid) {
        this.partOid = partOid;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        HuSendMBOMRecord that = (HuSendMBOMRecord) o;
//        return result == that.result &&
//                Objects.equals(number, that.number) &&
//                Objects.equals(factory, that.factory) &&
//                Objects.equals(partOid, that.partOid)
//                Objects.equals(errMessage, that.errMessage)
//                ;
//    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HuSendMBOMRecord that = (HuSendMBOMRecord) o;
        return  Objects.equals(number, that.number) &&
                Objects.equals(factory, that.factory) &&
                Objects.equals(partOid, that.partOid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(number, factory, partOid);
    }


    @Override
    public String toString() {
        return "HuSendMBOMRecord{" +
                "number='" + number + '\'' +
                ", factory='" + factory + '\'' +
                ", partOid='" + partOid + '\'' +
                ", result=" + result +
                ", errMessage='" + errMessage + '\'' +
                '}';
    }
}
