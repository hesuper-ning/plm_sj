package ext.alphai.sap.colourEnum;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
@RequestMapping({ "/JC_PLM" })
public class PartColourEnumController {
    static final ObjectMapper objectMapper = new ObjectMapper();


    @RequestMapping(value = "/updateColourEnum", method = RequestMethod.POST)
    public void updateColourEnum(@RequestBody String json ,HttpServletRequest request,
                                 HttpServletResponse response)throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("新增颜色全局枚举条目接口");

//        // 读取请求体中的JSON数据
//        StringBuilder sb = new StringBuilder();
//        BufferedReader reader = request.getReader();
//        String line;
//        while ((line = reader.readLine()) != null) {
//            sb.append(line);
//        }
//        reader.close();
//        String jsonStr = sb.toString();
        System.out.println("打印post数据：" + json);
        List<ColourEnumEntity> colourEnumEntities = objectMapper.readValue(json, new TypeReference<List<ColourEnumEntity>>(){});

        ResponseVo vo = ColourEnumService.updateColourEnum(colourEnumEntities);

        outResponse(response, objectMapper.writeValueAsString(vo));
    }




    public void outResponse(HttpServletResponse response, String json) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }
}
