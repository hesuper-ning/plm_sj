package ext.alphai.sap.colourEnum;

import com.ptc.core.lwc.common.view.EnumerationDefinitionReadView;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.server.LWCEnumerationEntry;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import ext.alphai.sap.Config;
import org.springframework.util.ObjectUtils;
import wt.util.WTException;

import java.util.*;

/**
 * 添加颜色全局枚举条目发服务类
 */
public class ColourEnumService {

    public static ResponseVo updateColourEnum(List<ColourEnumEntity> colourEnums){
        ResponseVo vo = new ResponseVo();
        // 重复性校验
        EnumerationDefinitionReadView edr = null;
        HashMap<String,String> map = new HashMap<String,String>();
        // 检验入参是否有重复内部值枚举条目

        Set<String> duplicateInternalNames = getDuplicateInternalNames(colourEnums);
        if(!duplicateInternalNames.isEmpty()){
            return new ResponseVo(400,"请求参数异常","请求参数中颜色枚举内部值："+duplicateInternalNames+"重复 请检查!");
        }

        try {
            edr = TypeDefinitionServiceHelper.service.getEnumDefView(Config.get("part.colour"));
        } catch (WTException e) {
            return new ResponseVo(500,"服务器内部异常",e.getMessage());
        }
        if(ObjectUtils.isEmpty(edr)){
            return new ResponseVo(500,"服务器内部异常","");
        }
        Map<String, EnumerationEntryReadView> views = edr.getAllEnumerationEntries();
        Set<String> keysOfView = views.keySet();
        for (String key : keysOfView) {
            EnumerationEntryReadView view = views.get(key);
            String enumKey = view.getName();
            String enumName = view.getPropertyValueByName("displayName").getValue().toString();
            // 此方法判断枚举值是否在可用列表
            if (view.getPropertyValueByName("selectable").getValue().equals(true)) {
                map.put(enumKey, enumName);
            }
        }

        // 要校验是否存在相同内部值的颜色
        // 重复内部名枚举条目
        List<ColourEnumEntity> repeatColourEnums = new ArrayList<>();
        Set<String> repeatColourSets = new HashSet<>();
        // 内部值集合
        Set<String> enumKeys = map.keySet();
        for (ColourEnumEntity colourEnum : colourEnums) {
            String internalName = colourEnum.getInternalName();
            if(enumKeys.contains(internalName)){
                repeatColourEnums.add(colourEnum);
                repeatColourSets.add(colourEnum.getInternalName());
            }
        }

        // 移除已存在的同名内部值条目
//        colourEnums.removeAll(repeatColourEnums);
        if(!repeatColourEnums.isEmpty()){
            return new ResponseVo(400,"请求参数异常","请求参数枚举内部值："+repeatColourSets+"已存在");
        }
        // 执行插入新条目




        return vo;
    }

    public static Set<String> getDuplicateInternalNames(List<ColourEnumEntity> colourEnums) {
        // 存储每个internalName出现的次数
        Map<String, Integer> nameCountMap = new HashMap<>();

        // 统计每个 internalName 出现的次数
        for (ColourEnumEntity colourEnum : colourEnums) {
            String internalName = colourEnum.getInternalName();
            nameCountMap.put(internalName, nameCountMap.getOrDefault(internalName, 0) + 1);
        }

        // 存储重复的internalName
        Set<String> duplicates = new HashSet<>();

        // 遍历统计结果，找出重复的internalName
        for (Map.Entry<String, Integer> entry : nameCountMap.entrySet()) {
            if (entry.getValue() > 1) {
                duplicates.add(entry.getKey()); // 将重复的internalName添加到Set中
            }
        }

        return duplicates;
    }
}
