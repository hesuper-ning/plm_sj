package ext.alphai.sap.colourEnum;

/**
 * 修改颜色全局枚举条目
 */
public class ColourEnumEntity {
    // 条目内部名
    private String internalName;

    // 条目显示值
    private String displayName;


    public String getInternalName() {
        return internalName;
    }

    public void setInternalName(String internalName) {
        this.internalName = internalName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public ColourEnumEntity() {
    }

    public ColourEnumEntity(String internalName, String displayName) {
        this.internalName = internalName;
        this.displayName = displayName;
    }
}
