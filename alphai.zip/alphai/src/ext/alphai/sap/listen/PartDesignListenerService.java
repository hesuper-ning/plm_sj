package ext.alphai.sap.listen;
import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import ext.alphai.sap.Config;
import ext.alphai.sap.util.CommonUtil;
import ext.alphai.sap.util.IBAUtil;
import ext.alphai.sap.util.PartUtil;
import org.apache.commons.lang3.StringUtils;
import wt.epm.EPMDocument;
import wt.events.KeyedEventListener;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManagerEvent;
import wt.fc.WTObject;
import wt.iba.value.service.IBAValueManagerEvent;
import wt.part.WTPart;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.vc.VersionControlServiceEvent;
import wt.vc.wip.WorkInProgressServiceEvent;

import java.io.Serializable;
import java.sql.ResultSet;
import java.util.*;

public class PartDesignListenerService extends StandardManager implements PartDesignListener, Serializable{

    // 匈牙利视图名称
    public static String HU_FACTORY_VIEW_3101 = "3101";

    public static String HU_FACTORY_VIEW_3188 = "3188";

    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = PartDesignListenerService.class.getName();
    private KeyedEventListener listener;

    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public PartDesignListenerService() {
    }

    public static PartDesignListenerService newPartDesignListenerService() throws WTException {
        PartDesignListenerService instance = new PartDesignListenerService();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new WCListenerEventListener(getConceptualClassname());
        //版本控制的检入监听事件  WorkInProgressServiceEvent
//        getManagerService().addEventListener(listener,
//                VersionControlServiceEvent.generateEventKey(VersionControlServiceEvent.POST_SUPERSEDE));//新版本
        // 网页端检入
//        getManagerService().addEventListener(listener,
//                WorkInProgressServiceEvent.generateEventKey(WorkInProgressServiceEvent.POST_CHECKIN));
//        getManagerService().addEventListener(this.listener,
//                EPMWorkspaceManagerEvent.generateEventKey(EPMWorkspaceManagerEvent.POST_WORKSPACE_CHECKIN));

        // 监听检入
//        getManagerService().addEventListener(listener,
//                PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_STORE));//新版本

        // IBA赋值的事件
        getManagerService().addEventListener(listener,
                IBAValueManagerEvent.generateEventKey(IBAValueManagerEvent.POST_COPY_ALL_IBAS));//新版本
    }

    public static final String ClassificationNode = "ClassificationNode";

    /**
     * 同步设计视图属性给所有版本的制造视图部件
     * @param partCheckIn
     */
    public static void syncCheckInPartAttribute(WTPart partCheckIn, Map<String,String> map) throws Exception {
        List<WTPart> parts = getWTPartListByNumber(partCheckIn);
        Set<Map.Entry<String, String>> entries = map.entrySet();
        IBAUtil iba = new IBAUtil();
        for (WTPart part : parts) {
            for (Map.Entry<String, String> entry : entries) {
                String key = entry.getKey();
                String orDefault = map.getOrDefault(key, "");
                if(!StringUtils.isBlank(orDefault)){
                    iba.setIBAAttribute4AllType(part, key, orDefault);
                }
            }

        }
    }

    /**
     * 根据检入的EPM文档中的 IBA值设置其部件的其他工厂视图的IBA值
     * @param epmDocument
     * @param map
     */
    public static void syncIBAToFacPartByEPM(EPMDocument epmDocument, Map<String,String> map){

    }





    class WCListenerEventListener extends ServiceEventListenerAdapter {

        public WCListenerEventListener(String s) {
            super(s);
        }

        @Override
        public void notifyVetoableEvent(Object event) throws Exception {
            System.out.println("-----------检入监听器----------");
//            if (event instanceof EPMWorkspaceManagerEvent) {
//
//                EPMWorkspaceManagerEvent eve = (EPMWorkspaceManagerEvent) event;
//                Object target = eve.getEventTarget();
//                doLis(target);
//            }
//            else
//                if (event instanceof PersistenceManagerEvent){
//
//                    PersistenceManagerEvent eve = (PersistenceManagerEvent) event;
//                Object target = eve.getEventTarget();
//                doLis(target);
//            }



            if (event instanceof IBAValueManagerEvent){

                IBAValueManagerEvent eve = (IBAValueManagerEvent) event;
                Object target = eve.getEventTarget();
                doLis(target);
            }
//            VersionControlServiceEvent pmEvent = (VersionControlServiceEvent) event;
//            Object target = pmEvent.getEventTarget();
//            boolean checkedOut = WorkInProgressHelper.isCheckedOut((Workable) target);
            // 如果是true 小版本升级   如果是false 就是修订 大版本

//            如果返回 TRUE 则表示对象是升小版本因为它需要一个检入操作
//            如果返回 FALSE 则表示对象是升大版本因为它不需要一个检出-检入操作

        }
    }




    // 旧代码
    public static void doLis(Object target) throws Exception {

//        if(target instanceof EPMDocument){
//            System.out.println("----检入的是EPM文档----");
//            EPMDocument doc = (EPMDocument)target;
//            String ibas = Config.get("epm.creo.iba");
//            IBAUtil iba = new IBAUtil(doc);
//            String[] ibaNames = ibas.split(",");
//            Map<String, String> map = new HashMap<String, String>();
//
//            for (String ibaName : ibaNames) {
//                String ibaValue = iba.getIBAValue(ibaName);
//                System.out.println("读取到检入EPM文档的IBA KEY："+ibaName+" IBA VALUE:"+ibaValue);
//                map.put(ibaName, ibaValue);
//            }
//
//            // 手动设置相关部件的其他工厂视图的值
//            syncIBAToFacPartByEPM(doc, map);
//        }






        if (target instanceof WTPart){
            WTPart partCheckIn = (WTPart) target;
            System.out.println("检入的部件版本为："+partCheckIn.getVersionIdentifier().getValue()+"."+partCheckIn.getIterationIdentifier().getValue());
            System.out.println("OR为:"+ object2Oid(partCheckIn));
            String viewName = partCheckIn.getViewName();
            System.out.println("视图为："+viewName);
             if(((WTPart) target).getPersistInfo().getObjectIdentifier().getId() == 0){
                 return;
             }
            // 当视图为设计视图检入时  触发同步到其他工厂
            if("Design".equals(viewName)){
                partCheckIn = (WTPart)PersistenceHelper.manager.refresh(partCheckIn);
                IBAUtil iba = new IBAUtil(partCheckIn);
                String ibas = Config.get("sap.Hu.part.listen.IBA");

                String[] ibaNames = ibas.split(",");
                Map<String, String> map = new HashMap<String, String>();

                for (String ibaName : ibaNames) {
                    String ibaValue = iba.getIBAValue(ibaName);
//                    Vector ibaValues = iba.getIBAValues(ibaName);
//                    System.out.println("部件新方法 key:"+ibaName+" value:"+getIBA(partCheckIn, ibaName));

//                    System.out.println("取值集合："+String.join(",",ibaValues));
                    System.out.println("读取到设计视图检入部件的IBA KEY："+ibaName+" IBA VALUE:"+ibaValue);
                    map.put(ibaName, ibaValue);
                }
                System.out.println("map中的值："+map);
                syncCheckInPartAttribute(partCheckIn, map);
            }
        }


    }





    /**
     * 通过部件编号获取所有非design视图全部版本部件
     * @param part
     * @return
     */
    @SuppressWarnings("deprecation")
    public static List<WTPart> getWTPartListByNumber(WTPart part) throws Exception{
        List<WTPart> result = new ArrayList<WTPart>();

        List<String> viewsStr = new ArrayList<>();
        ResultSet resultSet = CommonUtil.excuteSelect("Select NAME from WTView");
        while (resultSet.next()) {
            viewsStr.add(resultSet.getString("NAME"));
        }
        System.out.println("视图名称集合："+Arrays.toString(new List[]{viewsStr}));

        String number = part.getNumber();
        for (String view : viewsStr) {
            if("Design".equals(view)){
                continue;
            }
            WTPart latestWTPart = PartUtil.getLatestWTPart(number, null, null, view);
            if(latestWTPart != null){
                result.add(latestWTPart);
            }
        }



        return result;
    }



    public static String getIBA(Persistable persistable, String ibaName) throws WTException {
        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        return normalizedObject.get(ibaName) == null ? null : normalizedObject.get(ibaName).toString();
    }

    public static String object2Oid(WTObject obj) {
        String className = obj.getClass().getName();
        String oid = String.valueOf(obj.getPersistInfo().getObjectIdentifier().getId());
        return "OR:" + className + ":" + oid;
    }


}
