package ext.alphai.sap.listen;

public interface PartDesignListener {
}
