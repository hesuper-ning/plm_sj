package ext.alphai.sap.part;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.lwc.common.view.EnumerationDefinitionReadView;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.TypeIdentifierUtilityHelper;
import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import ext.techsoft.logicdata.businessalgorhytmus.CalculateWTPartIBA;
import ext.techsoft.logicdata.helper.IBAHelper;
import ext.alphai.sap.Config;
import ext.alphai.sap.entity.HuSendPartRecord;
import ext.alphai.sap.util.*;
import groovy.lang.GroovyShell;
import groovy.lang.Script;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import wt.change2.WTChangeReview;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.services.StandardManager;
import wt.type.TypeDefinitionReference;
import wt.type.Typed;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.util.*;

/**
 * 发送部件到匈牙利SAP
 */
public class HUSendPartHelper extends StandardManager {
    public static final String LDPartSoftType = "com.jiecang.LDPART";

    public static String SEND_HU_PART_PAR = Config.get("sap.Hu.part.pra");
    private static final long serialVersionUID = 1L;

    static final ObjectMapper objectMapper = new ObjectMapper();
    // 停止量产
    private static final String EOP_DATE = "AI_EOP_DATE";

    // 完全停产
    private static final String EOL_DATE = "AI_EOL_DATE";

    private static final String Obsolescence_CN = "废弃";
    private static final String Frozen_CN = "已冻结";

    private static final String Frozen = "Frozen";
    private static final String Obsolescence = "Obsolescence";

    public static HUSendPartHelper newHUSendPartHelper() throws WTException {
        HUSendPartHelper service = new HUSendPartHelper();
        service.initialize();
        return service;
    }


    /**
     * 发送部件到SAP
     *
     * @param parts
     * @return 接口返回信息
     */
    public static List<HuSendPartRecord> sendPartToSAP(List<WTPart> parts, String inlet) throws Exception {
        List<HuSendPartRecord> result = new ArrayList<>();
        String sendPartJson = getSendPartJson(parts, result, inlet);
        // 返回json
        String requestedJSON = CommonUtil.requestInterface(Config.getSendPartUrl(), Config.getSendPartUsername(), Config.getSendPartPassword(), sendPartJson, "POST", null);
        return getJCHuSAPResponseJson(requestedJSON, result);

    }


    /**
     * 处理捷昌发送物料到SAP接口返回值JSON
     *
     * @param responseJson
     * @return
     */
    public static List<HuSendPartRecord> getJCHuSAPResponseJson(String responseJson, List<HuSendPartRecord> result) throws JSONException {
        // 解析 JSON 字符串
        JSONObject jsonObject = new JSONObject(responseJson);
        JSONArray dataArray = jsonObject.getJSONArray(SEND_HU_PART_PAR);
        // 遍历每个部件
        for (int i = 0; i < dataArray.length(); i++) {
            JSONObject data = dataArray.getJSONObject(i);
            // 获取 MATNR, ZTYPE 和 ZMSG 的值
            String matnr = data.optString("MATNR", "");
            String ztype = data.optString("ZTYPE", "");
            String zmsg = data.optString("ZMSG", "");
            // 创建 HuSendPartRecord 对象
            boolean respResult = "S".equals(ztype);  // 如果 ZTYPE 为 "S"，则是成功
            for (HuSendPartRecord record : result) {
                String number = record.getNumber();
                if (number.equals(matnr)) {
                    record.setResult(respResult);
                    record.setErrMessage(zmsg);
                }
            }
        }
        return result;
    }


    /**
     * 拼接物料发送到SAP的json
     *
     * @param parts  待发送的部件集合
     * @param result 发送结果记录
     * @return 发送的JSON
     */
    public static String getSendPartJson(List<WTPart> parts, List<HuSendPartRecord> result, String inlet) throws Exception {
        Map<String, List<Object>> map = new HashMap<String, List<Object>>();

        List<Object> partReqList = new ArrayList<>();
        for (WTPart part : parts) {
            HuSendPartRecord record = new HuSendPartRecord(PersistenceUtil.object2Oid(part), part.getNumber());
            Map<String, Object> partInformation = getPartInformation(part, inlet);
            partReqList.add(partInformation);
            result.add(record);
        }
        map.put(SEND_HU_PART_PAR, partReqList);
        String json = objectMapper.writeValueAsString(map);
        System.out.println("发送物料到匈牙利SAP的JSON为：" + json);
        return json;
    }


    public static Map<String, Object> getPartInformation(WTPart part, String inlet) throws Exception {
        // 2025-07-17  判断部件是否LD部件
        boolean isLDPart = getTypeIdentifier(part);

        Map<String, Object> map = new HashMap<>();
        IBAUtil partIba = new IBAUtil(part);
        map.put("IV_ZIFID", UUID.randomUUID().toString());
        map.put("MAT_STATUS", "C");
        map.put("MBRSH", "M");
        map.put("MTART", Config.get("sap.mm.function.ptype.pre") + StringUtils.substring(part.getNumber(), 0, 1));
        map.put("MATNR", part.getNumber());
        if (isLDPart) {
            map.put("BISMT", partIba.getIBAValue(Config.get("sap.LD.iba.oldnumber")));
        } else {
            map.put("BISMT", partIba.getIBAValue(Config.get("sap.mm.function.oldnumber.iba")));
        }
        map.put("ZMAKTX", partIba.getIBAValue(Config.get("sap.mm.function.pname.cn")));


        map.put("WERKS", part.getView().getName());
        // 基本计量单位,大写
        String defaultUnit = part.getDefaultUnit().toString().toUpperCase();//默认单位

        // 单位转换
        Map<String, String> plmerpUnitMapping = UnitUtil.handleUnitConfig(Config.get("sap.mm.function.unit.mapping"));
        if (plmerpUnitMapping.containsKey(defaultUnit)) {
            defaultUnit = plmerpUnitMapping.get(defaultUnit);
        }
        map.put("MEINS", defaultUnit.toUpperCase());


        //物料组
        //获取分类
        String value = partIba.getIBAValue(Config.get("sap.mm.function.classfication.iba"));
//        System.out.println("分类内部值："+value);
        if (isLDPart) {
            // LD部件给默认值
            if (StringUtils.isNotBlank(value)) {
                map.put("MATKL", value);
            } else {
                map.put("MATKL", "LD_11");
            }
        } else {
            map.put("MATKL", value);
        }
        // 英文描述 部件名称
        if ("LD_11".equals(value) || StringUtils.isBlank(value)) {
//            String s = Config.get("sap.LD.iba.SAPMATERIALDESCRIPTION");
//            System.out.println("配置文件读取到的LD英文描述内部值为："+s);
//            IBAUtil partMasterIBA = new IBAUtil(part.getMaster());
            map.put("EMAKTX", getSAPMaterialDescription(part, "SAP_MATERIAL_DESCRIPTION"));
//            map.put("EMAKTX", partIba.getIBAValue(Config.get("sap.LD.iba.SAPMATERIALDESCRIPTION")));
        } else {
            map.put("EMAKTX", part.getName());
        }
        //规格型号,中文规格
        value = partIba.getIBAValue(Config.get("sap.mm.function.spec.cn.iba"));
        map.put("ZCTEXT", value);

        //规格型号,英文规格
        value = partIba.getIBAValue(Config.get("sap.mm.function.spec.en.iba"));
        map.put("ECTEXT", value);

        //是否客供标识
        value = partIba.getIBAValue(Config.get("sap.mm.function.clientsupply.iba"));
        map.put("ZFLAG", value);
        if (StringUtils.equals(value, "真")) {
            map.put("ZFLAG", "true");
        } else if (StringUtils.equals(value, "假")) {
            map.put("ZFLAG", "");
        } else if (StringUtils.equals(value, "True")) {
            map.put("ZFLAG", "true");
        } else if (StringUtils.equals(value, "False")) {
            map.put("ZFLAG", "");
        }
        EPMDocument cadDocs = PartUtil.get2DByPart(part);
        if (cadDocs != null) {
            String number = cadDocs.getNumber();
            number = StringUtils.remove(number, "-D");
            map.put("DRAWNO", number);// 图号
            String version = cadDocs.getVersionInfo().getIdentifier().getValue();
            map.put("DRAWVERSION", version);// 版本号
        } else {
            System.out.println("当前部件关联的是WTDoc类型");
            WTDocument doc = null;
            QueryResult qr = WTPartHelper.service.getDescribedByDocuments(part);
            // 迭代处理查询结果
            while (qr.hasMoreElements()) {
                Object res = qr.nextElement();
                if (res instanceof WTDocument) {
                    doc = (WTDocument) res;
                    System.out.println("当前部件关联的是WTDoc子类型为类型：" + getTypeInternalName(doc));
                    if (StringUtils.equals(getTypeInternalName(doc), Config.get("PDF"))) {
                        map.put("DRAWNO", doc.getNumber());// 图号
                        String version = doc.getVersionInfo().getIdentifier().getValue();
                        map.put("DRAWVERSION", version);// 版本号
                        System.out.println("Found user: " + doc.getName());
                        break;
                    }
                }
            }
            if (doc == null) {
                map.put("DRAWNO", "");// 图号
                map.put("DRAWVERSION", "");// 版本号
            }
        }
        // 物料锁定
        map.put("MATFI", "");
        // 工厂特定的物料状态
        // 部件状态转换

        // 在流程里才需要传状态 按钮的不需要传 （测试阶段暂时都不传）
//        map.put("MMSTA", "");
//        if(Config.BUTTON.equals(inlet)){
//            map.put("MMSTA", "");
//        } else if (Config.WORKITEM.equals(inlet)) {
        String display = part.getLifeCycleState().getDisplay();
        String lifeDisplay = display;
        Map<String, String> plmerpLiftMapping = UnitUtil.handleUnitConfig(Config.get("sap.mm.function.liftCycle.mapping"));
        if (plmerpLiftMapping.containsKey(lifeDisplay)) {
            lifeDisplay = plmerpLiftMapping.get(lifeDisplay);
        }
        map.put("MMSTA", lifeDisplay);
//        }

        // 产品组 getIBA获取的是显示值 需要转成内部值

        String proGroup = PartUtil.getIBA(part, Config.get("sap.mm.function.Product_group.iba"));
        String productGroup = isChinese(proGroup, "Product_group");
//        if(!isLDPart){
        if (StringUtils.isBlank(productGroup)) {
            throw new WTException("Please fill in the attributes of the SAP Division !");
        }
        map.put("SPART", productGroup);
        System.out.println("----物料产品组映射值为----：" + productGroup);
//        }else {
//            map.put("SPART", productGroup);
//        }
        // 实验室/设计室   Laboratory_Engineeringoffice 研发到生产地址
        String laboratoryEngineeringoffice = getLABORDisplay(PartUtil.getIBA(part, Config.get("sap.mm.function.Laboratory_Engineeringoffice.iba")), "SAP_LABOFFICE");
//        if(!isLDPart){
        System.out.println("实验室设计师 研发生产地址映射值：" + laboratoryEngineeringoffice);
        if (StringUtils.isBlank(laboratoryEngineeringoffice)) {
            throw new WTException("Please fill in the attributes of the SAP LabOffice !");
        }
        map.put("LABOR", laboratoryEngineeringoffice);
//        } else {
//            map.put("LABOR", "");
//        }


        // 净重
        String NTGEW = PartUtil.getIBA(part, Config.get("sap.mm.function.Net_weight.cls"));
        if (StringUtils.isBlank(NTGEW)) {
            map.put("NTGEW", 0);
            map.put("GEWEI", "");
        } else {
//            String[] split = NTGEW.split(" ");
//            System.out.println("净重拆分数组："+Arrays.toString(split));
//            String ntgew = split[0];
//            // 判断如果净重为纯数字才转成double类型 否则给默认值0
//            map.put("NTGEW", Double.parseDouble(ntgew));
//            //map.put("GEWEI", split[1].toUpperCase());
//            map.put("GEWEI", "");


            try {
                // 直接调用转换方法，传入完整的字符串
                String[] converted = SAPMassConverterUtil.convertMassForSAP(NTGEW);

                String convertedValue = converted[0];
                String convertedUnit = converted[1];

                System.out.println("原始净重: " + NTGEW);
                System.out.println("转换后结果: " + convertedValue + " " + convertedUnit);

                // 存储到map
                map.put("NTGEW", Double.parseDouble(convertedValue));
                map.put("GEWEI", convertedUnit);

            } catch (NumberFormatException e) {
                // 转换失败，给默认值
                map.put("NTGEW", 0);
                map.put("GEWEI", "");
                System.err.println("净重转换失败: " + NTGEW + ", 错误: " + e.getMessage());
            } catch (Exception e) {
                // 其他异常处理
                map.put("NTGEW", 0);
                map.put("GEWEI", "");
                System.err.println("处理净重时发生异常: " + NTGEW + ", 错误: " + e.getMessage());
            }

        }
        // 长度 sap.mm.function.Length_Solid.cls
        String LAENG = PartUtil.getIBA(part, Config.get("sap.mm.function.Length_Solid.cls"));
        if (StringUtils.isBlank(LAENG)) {
            map.put("LAENG", 0);
        } else {
            map.put("LAENG", Double.parseDouble(LAENG));
        }
        // 宽度 sap.mm.function.Width_Solid.cls
        String BREIT = PartUtil.getIBA(part, Config.get("sap.mm.function.Width_Solid.cls"));
        if (StringUtils.isBlank(BREIT)) {
            map.put("BREIT", 0);
        } else {
            map.put("BREIT", Double.parseDouble(BREIT));
        }
        // 高度 sap.mm.function.Height_Solid.cls
        String HOEHE = PartUtil.getIBA(part, Config.get("sap.mm.function.Height_Solid.cls"));
        if (StringUtils.isBlank(HOEHE)) {
            map.put("HOEHE", 0);
        } else {
            map.put("HOEHE", Double.parseDouble(HOEHE));
        }

        // 业务量
        map.put("VOLUM", "");
        // 体积单位
        map.put("VOLEH", "");

        // 大小/量纲
        map.put("GROES", "");
        // 管材类型 sap.mm.function.Pipe_type.cls
        map.put("CUBETYPE", PartUtil.getIBA(part, Config.get("sap.mm.function.Pipe_type.cls")));
        // 颜色
        map.put("COLOUR", PartUtil.getIBA(part, Config.get("sap.mm.function.Color.cls")));

        // 接口操作结果
        map.put("ZTYPE", "");
        // 接口返回信息
        map.put("ZMSG", "");

        // 下坡

        if (Obsolescence_CN.equals(display)) {
            map.put("MMSTD", PartUtil.getIBA(part, EOL_DATE));
        } else if (Frozen_CN.equals(display)) {
            map.put("MMSTD", PartUtil.getIBA(part, EOP_DATE));
        } else {
            map.put("MMSTD", "");
        }

        return map;
    }


    //获取内部名称
    public static String getTypeInternalName(Typed typed_object) throws WTException {
        String name = null;
        try {
            TypeIdentifier type = TypeIdentifierUtilityHelper.service.getTypeIdentifier(typed_object);
            TypeDefinitionReadView trv = TypeDefinitionServiceHelper.service.getTypeDefView(type);
            name = trv.getName();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        }
        return name;
    }


    public static String getLABORDisplay(String str, String enumName) {
        // 正则表达式：匹配所有的中文字符
        if (str != null) {
            // 将字符串转成枚举内部值
            Map<String, String> enumTypeByInternalName = getEnumTypeByInternalName(enumName);
            for (Map.Entry<String, String> stringStringEntry : enumTypeByInternalName.entrySet()) {
                String value = stringStringEntry.getValue();
                if (str.equals(value)) {
                    str = stringStringEntry.getKey();
                }
            }
        }
        // 使用正则表达式判断字符串是否符合条件
        return str;
    }


    public static String isChinese(String str, String enumName) {
        // 正则表达式：匹配所有的中文字符
        String regex = "^[\u4e00-\u9fa5]+$";

        if (str != null && str.matches(regex)) {
            // 将字符串转成枚举内部值
            Map<String, String> enumTypeByInternalName = getEnumTypeByInternalName(enumName);
            for (Map.Entry<String, String> stringStringEntry : enumTypeByInternalName.entrySet()) {
                String value = stringStringEntry.getValue();
                if (str.equals(value)) {
                    str = stringStringEntry.getKey();
                }
            }
        }
        // 使用正则表达式判断字符串是否符合条件
        return str;
    }


    /**
     * 根据全局枚举的内部名称获取其中所有的子枚举的内部名称与外部名称
     *
     * @param String
     * @return Map<String, String>
     */
    public static Map<String, String> getEnumTypeByInternalName(String internalName) {
        Map<String, String> map = new HashMap<>();
        try {
            EnumerationDefinitionReadView edr = TypeDefinitionServiceHelper.service.getEnumDefView(internalName);
            if (edr != null) {
                Map<String, EnumerationEntryReadView> views = edr.getAllEnumerationEntries();
                Set<String> keysOfView = views.keySet();
                for (String key : keysOfView) {
                    EnumerationEntryReadView view = views.get(key);
                    String enumKey = view.getName();
                    String enumName = view.getPropertyValueByName("displayName").getValue().toString();
                    // 此方法判断枚举值是否在可用列表
                    if (view.getPropertyValueByName("selectable").getValue().equals(true)) {
                        map.put(enumKey, enumName);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }


    /**
     * 判断部件是否是LD类型部件 涉及取数逻辑修改
     * @param part
     * @return
     */
    /**
     * 获取类型的全路径  如：com.jiecang.ReferenceDocument|com.jiecang.WINDCHILL_GENERAL_DOCUMENT
     *
     * @param persistable
     * @return
     */
    public static boolean getTypeIdentifier(Persistable persistable) {
        boolean result = false;
        try {
            String externalTypeIdentifier = TypedUtilityServiceHelper.service.getExternalTypeIdentifier(persistable);
            if (externalTypeIdentifier.contains(LDPartSoftType)) {
                result = true;
            }
        } catch (WTException var2) {
            var2.printStackTrace();
        } catch (RemoteException var3) {
            var3.printStackTrace();
        }
        return result;
    }


    /**
     * 获取SAP物料描述
     *
     * @param wtPart 部件对象
     * @return SAP物料描述字符串
     */
    public static String getSAPMaterialDescription(WTPart wtPart) throws WTException {
        String ibaValue = "";

        String claName = IBAHelper.getIBAValue(wtPart, "MPartsClsNODE").toString();
        String sapCat0 = IBAHelper.getIBAValue(wtPart, "SAP_CAT0").toString();

        if ("MAT".equals(sapCat0)) {
            if ("LD_11".equals(claName)) {
                // LD_11且SAP_CAT0=MAT的处理逻辑
                String cat2 = IBAHelper.getIBAValue(wtPart, "SAP_CAT2").toString();
                if (cat2.length() >= 6) cat2 = cat2.substring(0, 6);

                String name = IBAHelper.getIBAValue(wtPart, "name").toString();
                if (name.length() >= (28 - cat2.length())) {
                    name = name.substring(0, (28 - cat2.length()));
                }

                String designId = IBAHelper.getIBAValue(wtPart, "DESIGNID").toString();
                if (designId.length() >= 6) {
                    designId = designId.substring(designId.length() - 6);
                }
                if (designId.length() < 6) {
                    designId = "000000".substring(0, 6 - designId.length()) + designId;
                }

                String designRev = IBAHelper.getIBAValue(wtPart, "DESIGNREVISION").toString();
                if (designRev.length() >= 2) {
                    designRev = designRev.substring(0, 2);
                }
                if (designRev.length() < 2) {
                    designRev = "00".substring(0, 2 - designRev.length()) + designRev;
                }

                ibaValue = String.format("%s-%s-%s-R%s", cat2, name, designId, designRev);
            } else {
                // 非LD_11且SAP_CAT0=MAT的处理逻辑
                String nameEn = IBAHelper.getIBAValue(wtPart, "AI_NAME_EN").toString();
                String designId = IBAHelper.getIBAValue(wtPart, "DESIGNID").toString();

                if (designId.length() >= 6) {
                    designId = designId.substring(designId.length() - 6);
                }
                if (designId.length() < 6) {
                    designId = "000000".substring(0, 6 - designId.length()) + designId;
                }

                String designRev = IBAHelper.getIBAValue(wtPart, "DESIGNREVISION").toString();
                if (designRev.length() >= 2) {
                    designRev = designRev.substring(0, 2);
                }
                if (designRev.length() < 2) {
                    designRev = "00".substring(0, 2 - designRev.length()) + designRev;
                }

                if (nameEn.isEmpty()) {
                    String cat2 = IBAHelper.getIBAValue(wtPart, "SAP_CAT2").toString();
                    if (cat2.length() >= 6) cat2 = cat2.substring(0, 6);

                    String name = IBAHelper.getIBAValue(wtPart, "name").toString();
                    if (name.length() >= (28 - cat2.length())) {
                        name = name.substring(0, (28 - cat2.length()));
                    }

                    ibaValue = String.format("%s-%s-R%s", name, designId, designRev);
                } else {
                    ibaValue = String.format("%s-%s-R%s", nameEn, designId, designRev);
                }
            }
        } else {
            if ("LD_11".equals(claName)) {
                // LD_11且SAP_CAT0≠MAT的处理逻辑
                String name = IBAHelper.getIBAValue(wtPart, "name").toString();
                if (name.length() >= 36) name = name.substring(0, 36);

                String designRev = IBAHelper.getIBAValue(wtPart, "DESIGNREVISION").toString();
                if (designRev.length() >= 2) {
                    designRev = designRev.substring(0, 2);
                }
                if (designRev.length() < 2) {
                    designRev = "00".substring(0, 2 - designRev.length()) + designRev;
                }

                ibaValue = String.format("%s-R%s", name, designRev);
            } else {
                // 非LD_11且SAP_CAT0≠MAT的处理逻辑
                String nameEn = IBAHelper.getIBAValue(wtPart, "AI_NAME_EN").toString();
                String designRev = IBAHelper.getIBAValue(wtPart, "DESIGNREVISION").toString();

                if (designRev.length() >= 2) {
                    designRev = designRev.substring(0, 2);
                }
                if (designRev.length() < 2) {
                    designRev = "00".substring(0, 2 - designRev.length()) + designRev;
                }

                if (nameEn.isEmpty()) {
                    String name = IBAHelper.getIBAValue(wtPart, "name").toString();
                    if (name.length() >= 36) name = name.substring(0, 36);
                    ibaValue = String.format("%s-R%s", name, designRev);
                } else {
                    ibaValue = String.format("%s-R%s", nameEn, designRev);
                }
            }
        }

        return ibaValue;
    }


    private static String getSAPMaterialDescription(WTPart part, String IBAName) {
        String value = "";
        GroovyShell groovyShell = new GroovyShell();
        InputStream stream = CalculateWTPartIBA.class.getResourceAsStream("CalculateStringValueForWTPart.groovy");
        Script script = groovyShell.parse(new BufferedReader(new InputStreamReader(stream)));
        if (script != null) {
            value = (String) script.invokeMethod("getCalculatedValue", new Object[]{part, IBAName});
        }

        return value;
    }


}
