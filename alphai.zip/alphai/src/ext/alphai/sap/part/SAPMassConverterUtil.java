package ext.alphai.sap.part;

import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * SAP质量单位转换工具类（仅支持K和KG单位）
 */
public class SAPMassConverterUtil {

    /**
     * 转换质量值供SAP使用（主方法）
     * @param plmMass PLM质量字符串，格式如 "0.00272 KG" 或 "2.72 K" 或 "0.00272KG"
     * @return 转换后的字符串数组 [值, 单位]
     */
    public static String[] convertMassForSAP(String plmMass) {
        if (StringUtils.isBlank(plmMass)) {
            return new String[]{"0", ""};
        }

        // 清理字符串
        String cleanedMass = plmMass.trim();

        // 检查是否是纯数字（没有单位）
        if (isPureNumber(cleanedMass)) {
            try {
                BigDecimal value = new BigDecimal(cleanedMass);
                // 如果是纯数字且值很小，自动转换为克
                if (value.compareTo(BigDecimal.valueOf(0.001)) < 0) {
                    return new String[]{formatValue(value.multiply(BigDecimal.valueOf(1000))), "G"};
                }
                return new String[]{formatValue(value), ""};
            } catch (NumberFormatException e) {
                return new String[]{"0", ""};
            }
        }

        // 分离数值和单位（支持空格分隔或无空格）
        String valueStr;
        String unit;

        // 查找第一个非数字、非小数点、非负号的字符位置
        int unitStartIndex = -1;
        for (int i = 0; i < cleanedMass.length(); i++) {
            char c = cleanedMass.charAt(i);
            if (!Character.isDigit(c) && c != '.' && c != '-' && c != 'E' && c != 'e') {
                unitStartIndex = i;
                break;
            }
        }

        if (unitStartIndex > 0) {
            valueStr = cleanedMass.substring(0, unitStartIndex).trim();
            unit = cleanedMass.substring(unitStartIndex).trim();
        } else {
            // 如果没有找到单位分隔符，尝试按空格分割
            String[] parts = cleanedMass.split("\\s+");
            if (parts.length >= 2) {
                valueStr = parts[0];
                unit = parts[1];
                // 如果有更多部分，合并到单位中
                for (int i = 2; i < parts.length; i++) {
                    unit += " " + parts[i];
                }
            } else {
                // 格式不正确
                return new String[]{"0", ""};
            }
        }

        // 检查是否为有效数字
        if (!isValidNumber(valueStr)) {
            return new String[]{"0", ""};
        }

        BigDecimal value = new BigDecimal(valueStr);
        String normalizedUnit = normalizeUnit(unit);

        // 处理K单位（假设K就是KG）
        if ("K".equals(normalizedUnit) || "KG".equals(normalizedUnit)) {
            return processKGValue(value);
        }
        // 处理其他单位（原样返回）
        else {
            return new String[]{formatValue(value), unit.toUpperCase()};
        }
    }

    /**
     * 处理KG单位的转换逻辑
     */
    private static String[] processKGValue(BigDecimal value) {
        // 检查是否需要转换为G
        if (needConvertToGrams(value)) {
            // 乘以1000转换为G
            BigDecimal grams = value.multiply(BigDecimal.valueOf(1000));
            return new String[]{formatValue(grams), "G"};
        } else {
            // 保持KG单位，但限制3位小数
            BigDecimal rounded = value.setScale(3, RoundingMode.HALF_UP);
            return new String[]{formatValue(rounded), "KG"};
        }
    }

    /**
     * 判断是否需要转换为克
     */
    private static boolean needConvertToGrams(BigDecimal value) {
        try {
            // 如果值小于0.001（1克），则转换为克
            if (value.compareTo(BigDecimal.valueOf(0.001)) < 0) {
                return true;
            }

            String str = value.toPlainString();
            int dotIndex = str.indexOf('.');

            // 如果没有小数点，不需要转换
            if (dotIndex == -1) {
                return false;
            }

            String decimalPart = str.substring(dotIndex + 1);

            // 如果小数位数小于4，不需要转换
            if (decimalPart.length() < 4) {
                return false;
            }

            // 获取第4位小数
            char fourthChar = decimalPart.charAt(3);

            // 第4位非0时需要转换
            return fourthChar != '0';
        } catch (Exception e) {
            // 异常情况下不转换
            return false;
        }
    }

    /**
     * 标准化单位
     */
    private static String normalizeUnit(String unit) {
        if (StringUtils.isBlank(unit)) {
            return "";
        }

        String normalized = unit.trim().toUpperCase();

        // 移除多余的空格和特殊字符
        normalized = normalized.replaceAll("\\s+", "");

        // 处理K单位
        if ("K".equals(normalized)) {
            return "K";
        }
        // 处理KG单位
        else if (normalized.contains("KG")) {
            return "KG";
        }
        // 处理G单位
        else if ("G".equals(normalized) || "GR".equals(normalized) || "GRAM".equals(normalized)) {
            return "G";
        }

        return normalized;
    }

    /**
     * 格式化数值，移除末尾多余的0
     */
    private static String formatValue(BigDecimal value) {
        return value.stripTrailingZeros().toPlainString();
    }

    /**
     * 检查是否为有效数字字符串
     */
    private static boolean isValidNumber(String str) {
        if (StringUtils.isBlank(str)) {
            return false;
        }
        try {
            new BigDecimal(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * 检查是否是纯数字（没有单位）
     */
    private static boolean isPureNumber(String str) {
        if (StringUtils.isBlank(str)) {
            return false;
        }
        String trimmed = str.trim();
        try {
            new BigDecimal(trimmed);
            // 确保字符串中没有字母（单位）
            return !trimmed.matches(".*[a-zA-Z].*");
        } catch (NumberFormatException e) {
            return false;
        }
    }
}