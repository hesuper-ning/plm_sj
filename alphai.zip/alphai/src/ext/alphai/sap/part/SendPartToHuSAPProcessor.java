package ext.alphai.sap.part;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sap.Config;
import ext.alphai.sap.MBOM.HUSendMBOMHelper;
import ext.alphai.sap.entity.HuSendPartRecord;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;

/**
 * 发送物料到匈牙利SAP
 */
public class SendPartToHuSAPProcessor extends DefaultObjectFormProcessor {

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        try{
            if(content instanceof WTPart){
                WTPart part = (WTPart) content;

                String viewName = part.getView().getName();

                String check = Config.get("sap.Hu.MBOM.factory.check");
                if("yes".equalsIgnoreCase(check)){
                    if(!HUSendMBOMHelper.HU_FACTORY_VIEW_3101.equals(viewName) && !HUSendMBOMHelper.HU_FACTORY_VIEW_3188.equals(viewName)){
                        throw new WTException("Sending to JSHU-SAP is not allowed in the Dsign view. It must first be assigned to the Plant view.");
                    }
                }



                List<WTPart> partList = new ArrayList<WTPart>();
                partList.add(part);
                // 发送到匈牙利SAP
                // http返回值
                List<HuSendPartRecord> records = HUSendPartHelper.sendPartToSAP(partList, Config.BUTTON);
                for (HuSendPartRecord partRecord : records) {
                    boolean resp = partRecord.isResult();
                    if(!resp){
                        FormResult result = new FormResult(FormProcessingStatus.FAILURE);
                        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE,SessionHelper.getLocale(),null,null,new String[]{"Part Number："+partRecord.getNumber()+"Sending Hungarian SAP failed"+"The error message is:"+partRecord.getErrMessage()}));
                        return result;
                    }
                }
            }
        }catch (Exception e) {
            FormResult result = new FormResult(FormProcessingStatus.FAILURE);
            result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(),null,null,new String[]{e.getMessage()}));
            return result;
        }
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS,SessionHelper.getLocale(),null,null,new String[]{"Successfully sent Part to SAP Hungary"}));
        return result;
    }
}
