package ext.alphai.syncDoc.timeQueue;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.syncDoc.domain.AIDrawing;
import ext.alphai.syncDoc.domain.ResponseVo;
import ext.alphai.syncDoc.service.AIDrawingService;
import ext.alphai.syncDoc.util.CommonUtil;
import ext.alphai.syncDoc.util.PropertiesUtil;
import ext.alphai.syncDoc.vo.SyncReqVo;

import java.util.Date;
import java.util.List;

public class SendDocToGDP {
    static final ObjectMapper objectMapper = new ObjectMapper();

    public static void queueTest() {
        Date date = new Date();
        System.out.println("======发送图纸信息到GDP队列正在执行======" + date);
        ResponseVo responseVo = null;
        try {
            List<AIDrawing> drawingsLists = AIDrawingService.getDrawingsLists(AIDrawingService.GDP_STATUE_UNSEND);
            if(!drawingsLists.isEmpty()){
                // 调用同步接口后的返回json
                SyncReqVo syncReqVo = AIDrawingService.sendAIDrawingToGDP(drawingsLists);
                String reqJson = objectMapper.writeValueAsString(syncReqVo);

                // 登录
                String loginGDPToken = CommonUtil.loginGDP();

//                System.out.println("GDP同步数据库的请求json:"+reqJson);
                String respJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("GDP.url"), loginGDPToken, reqJson, "POST");

                System.out.println("GDP同步返回数据："+respJson);
                // 解析后修改状态
                responseVo = AIDrawingService.updateAIDrawingStatus(drawingsLists, respJson);
            }else {
                System.out.println("暂无待同步条目");
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("发送后的返回结果："+responseVo);
        System.out.println("==============发送图纸信息到GDP执行完毕==================");
    }
}
