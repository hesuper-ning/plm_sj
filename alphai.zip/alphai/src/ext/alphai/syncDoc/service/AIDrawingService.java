package ext.alphai.syncDoc.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.wvs.common.ui.VisualizationHelper;
import ext.alphai.syncDoc.domain.AIDrawing;
import ext.alphai.syncDoc.domain.AIDrawingReq;
import ext.alphai.syncDoc.domain.AIDrawingResp;
import ext.alphai.syncDoc.domain.ResponseVo;
import ext.alphai.syncDoc.util.CommonUtil;
import ext.alphai.syncDoc.util.IBAUtil;
import ext.alphai.syncDoc.util.PropertiesUtil;
import ext.alphai.syncDoc.vo.*;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import wt.content.*;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.fc.ObjectIdentifier;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.pom.Transaction;
import wt.representation.Representation;
import wt.util.WTException;
import wt.vc.Mastered;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 对AIDrawing 表进行操作的服务类
 */
public class AIDrawingService {
    // 已发送过后状态为 1
    public static final String GDP_STATUE_SENDED = "1";
    // 未发 DOCSTATUE 为 0
    public static final String GDP_STATUE_UNSEND = "0";

    static final ObjectMapper objectMapper = new ObjectMapper();

    public static final String OK = "OK";

    /**
     * 上传文件
     * @param
     */
    public static ResponseVo uploadDraw(GDPDownloadDrawVo downloadDrawVo) {
        ResponseVo vo = new ResponseVo();
        String drawName = downloadDrawVo.getDrawName();
        String docOr = downloadDrawVo.getDocOr();
        InputStream is = null;
        try {
            if (!StringUtils.isBlank(drawName) && !StringUtils.isBlank(docOr)) {
                WTObject object = CommonUtil.oid2Object(docOr);
                if (object == null) {
                    vo.setCode(400);
                    vo.setMsg("文档不存在可能已被删除");
                    return vo;
                }

                if (docOr.contains("wt.epm.EPMDocument")) {
                    EPMDocument epm = (EPMDocument) object;
                    ApplicationData data = getEPMApplicationDataByDrawName(epm, drawName);
                    if (data == null) {
                        vo.setCode(400);
                        vo.setMsg("在Windchill中未找到文档名称为：" + epm.getCADName() + "的名称为：" + drawName + "的图纸");
                        return vo;
                    }

                    System.out.println("文件大小为："+data.getFileSize());
                    // 获取输入流并转换为字节数组
                    is = ContentServerHelper.service.findContentStream(data);
                    byte[] bytes = IOUtils.toByteArray(is); // 使用 Apache Commons IO 工具类

                    vo.setCode(200);
                    vo.setMsg("上传成功");
                    vo.setData(bytes); // 存储字节数组而不是流
                } else {
                    System.out.println("当前OR非EPM类型：" + docOr);
                }
            } else {
                vo.setCode(400);
                vo.setMsg("文件名称及文档OR为必填参数");
            }
        } catch (Exception e) {
            e.printStackTrace();
            vo.setCode(500);
            vo.setMsg("服务器内部异常，请联系管理员");
        } finally {
            // 确保关闭输入流
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return vo;
    }












    /**
     * 发送完成后通过状态
     * @param respJson
     */
    public static ResponseVo updateAIDrawingStatus(List<AIDrawing> aiDrawingsByIds,String respJson) throws Exception {
        ResponseVo responseVo = new ResponseVo();
        HashMap<String, Object> map = objectMapper.readValue(respJson, new TypeReference<HashMap<String, Object>>() {});
        Integer code = (Integer) map.get("code");
        if(code == 200){
            responseVo.setCode(code);
            responseVo.setMsg("发送成功");
            int updateNum = 0;
            // 修改状态
            for (AIDrawing drawings : aiDrawingsByIds) {
                String sql = "UPDATE AIDRAWING SET DOCSTATUS = ? WHERE AIDRAWINGID = TO_NUMBER(?)";
                int i = CommonUtil.excuteUpdate(sql, GDP_STATUE_SENDED, String.valueOf(drawings.getAIDrawingId()));
                if(i>0){
                    updateNum ++;
                }
                // 修改IBA值
                String docOr = drawings.getDocOr();
//                System.out.println("docOr:"+docOr);
                WTObject object = CommonUtil.oid2Object(docOr);
                if(object != null){
                    if(docOr.contains("WTDocument") && object instanceof WTDocument ){
//                        System.out.println("属于WTDoc");
                        WTDocument document = (WTDocument) object;
                        IBAUtil iba = new IBAUtil(document);
                        iba.setIBAAttribute4AllType(document,PropertiesUtil.getValueByKey("GDP.iba.state"),OK);
                        iba.setIBAAttribute4AllType(document,PropertiesUtil.getValueByKey("GDP.iba.sendtime"),nowTime());
                    } else if (docOr.contains("EPMDocument") && object instanceof EPMDocument) {
//                        System.out.println("属于EPMDocument");
                        EPMDocument epmDocument = (EPMDocument) object;
                        IBAUtil iba = new IBAUtil(epmDocument);
                        iba.setIBAAttribute4AllType(epmDocument,PropertiesUtil.getValueByKey("GDP.iba.state"),OK);
                        iba.setIBAAttribute4AllType(epmDocument,PropertiesUtil.getValueByKey("GDP.iba.sendtime"),nowTime());
                    }

                }

            }




        }else {
            responseVo.setCode(code);
            responseVo.setMsg("发送失败");
        }
        return responseVo;
    }






    /**
     * 删除
     * @param ids
     */
    public static void deleteAIDrawing(List<Long> ids){
        String sql = "DELETE FROM AIDRAWING WHERE AIDRAWINGID IN (" + StringUtils.join(ids, ",") + ")";
        CommonUtil.excuteUpdate(sql);
    }


    /**
     * 获取指定状态的待发送EPM临时表项
     * @param docStatus
     * @return
     * @throws SQLException
     */
    public static List<AIDrawing> getDrawingsLists(String docStatus) throws SQLException {
        List<AIDrawing> list = new ArrayList<>();
        String sql = "SELECT * FROM AIDRAWING WHERE DOCSTATUS = ?";

        ResultSet rs = CommonUtil.excuteSelect(sql, docStatus);

        while (rs.next()) {
            AIDrawing aiDrawing = new AIDrawing(rs.getString("DOCMASTERCLASS"), Long.parseLong(rs.getString("DOCMASTERIDA2A2")), rs.getString("DOCOR"), rs.getString("DOCSTATUS"),rs.getString("ADDTIME"));
            aiDrawing.setAIDrawingId(Long.parseLong(rs.getString("AIDRAWINGID")));
            list.add(aiDrawing);
        }
        return list;
    }


    /**
     * 查询方法
     * @param req
     * @return
     */
    public static List<AIDrawingResp> getAIDrawingRespList(AIDrawingReq req) throws SQLException, WTException {
//        StringBuilder sb = new StringBuilder("SELECT A.*, E.IDA2A2, E.NAME, E.DOCUMENTNUMBER, D.NAME, D.WTDOCUMENTNUMBER FROM AIDRAWING A LEFT JOIN EPMDOCUMENTMASTER E ON A.DOCMASTERIDA2A2 = E.IDA2A2 LEFT JOIN WTDOCUMENTMASTER D ON A.DOCMASTERIDA2A2 = D.IDA2A2 ");
//
        List<AIDrawingResp> resps = new ArrayList<>();
//        String docStatus = req.getDocStatus();
//
//        String docName = req.getDocName();
//        String docNumber = req.getDocNumber();
//
//        if(!StringUtils.isBlank(docStatus)){
//            sb.append("WHERE A.DOCSTATUS = ?");
//        }
//
//        if(!StringUtils.isBlank(docName)){
//            sb.append("AND E.NAME LIKE '%" + docName + "%'" );
//        }
//
//        if(!StringUtils.isBlank(docNumber)){
//            sb.append("AND E.DOCUMENTNUMBER LIKE '%" + docNumber + "%'" );
//        }
//        sb.append(" ORDER BY A.ADDTIME DESC");
//
//        String sql = sb.toString();

        // 基础SQL（添加字段别名避免列名冲突）
        StringBuilder sb = new StringBuilder(
                "SELECT A.*, "
                        + "E.IDA2A2 AS E_IDA2A2, "
                        + "E.NAME AS E_NAME, "
                        + "E.DOCUMENTNUMBER AS E_DOCNUM, "
                        + "D.NAME AS D_NAME, "
                        + "D.WTDOCUMENTNUMBER AS D_WTDOCNUM "
                        + "FROM AIDRAWING A "
                        + "LEFT JOIN EPMDOCUMENTMASTER E ON A.DOCMASTERIDA2A2 = E.IDA2A2 "
                        + "LEFT JOIN WTDOCUMENTMASTER D ON A.DOCMASTERIDA2A2 = D.IDA2A2 ");

        List<Object> params = new ArrayList<>();  // 参数列表
        List<String> conditions = new ArrayList<>();  // 条件列表

        // 处理文档状态
        String docStatus = req.getDocStatus();
        if (!StringUtils.isBlank(docStatus)) {
            conditions.add("A.DOCSTATUS = ?");
            params.add(docStatus);  // 假设DOCSTATUS是数字类型
        }

        // 处理文档名称（同时查询EPM和WT的NAME）
        String docName = req.getDocName();
        if (!StringUtils.isBlank(docName)) {
            conditions.add("(E.NAME LIKE ? OR D.NAME LIKE ?)");
            params.add("%" + docName + "%");
            params.add("%" + docName + "%");
        }

        // 处理文档编号（同时查询EPM的DOCUMENTNUMBER和WT的WTDOCUMENTNUMBER）
        String docNumber = req.getDocNumber();
        if (!StringUtils.isBlank(docNumber)) {
            conditions.add("(E.DOCUMENTNUMBER LIKE ? OR D.WTDOCUMENTNUMBER LIKE ?)");
            params.add("%" + docNumber + "%");
            params.add("%" + docNumber + "%");
        }

        // 合并WHERE条件
        if (!conditions.isEmpty()) {
            sb.append("WHERE ").append(String.join(" AND ", conditions));
        }

        // 排序
        sb.append(" ORDER BY A.ADDTIME DESC");

        // 执行查询（使用预编译防止SQL注入）
        String sql = sb.toString();
        ResultSet rs = CommonUtil.executePreparedQuery(sql, params.toArray());
        while (rs.next()) {
            String docOr = rs.getString("DOCOR");
            WTObject object = CommonUtil.oid2Object(docOr);
            if(object !=null && docOr.contains("wt.epm.EPMDocument")){
                EPMDocument epmDoc = (EPMDocument) object;
                UrlDisplayComponent epmDocUrl = CommonUtil.getEPMDocUrl(epmDoc);

                AIDrawingResp resp = new AIDrawingResp(Long.parseLong(rs.getString("AIDRAWINGID")), rs.getString("DOCMASTERCLASS"),Long.parseLong(rs.getString("DOCMASTERIDA2A2")), docOr,rs.getString("DOCSTATUS"),rs.getString("ADDTIME"), rs.getString("E_NAME"),rs.getString("E_DOCNUM"),epmDocUrl.getLink());
                resp.setVersion(epmDoc.getVersionIdentifier().getValue());
                resp.setIteration(epmDoc.getIterationIdentifier().getValue());
                resp.setEPMStatus(epmDoc.getState().getState().getDisplay(Locale.CHINA));
                resps.add(resp);
            } else if (object !=null && docOr.contains("wt.doc.WTDocument")){
                WTDocument doc = (WTDocument) object;
                UrlDisplayComponent docUrl = CommonUtil.getWTDocUrl(doc);
                AIDrawingResp resp = new AIDrawingResp(Long.parseLong(rs.getString("AIDRAWINGID")), rs.getString("DOCMASTERCLASS"),Long.parseLong(rs.getString("DOCMASTERIDA2A2")), docOr,rs.getString("DOCSTATUS"),rs.getString("ADDTIME"), rs.getString("D_NAME"),rs.getString("D_WTDOCNUM"),docUrl.getLink());
                resp.setVersion(doc.getVersionIdentifier().getValue());
                resp.setIteration(doc.getIterationIdentifier().getValue());
                resp.setEPMStatus(doc.getState().getState().getDisplay(Locale.CHINA));
                resps.add(resp);
            }
        }
        return resps;
    }


    /**
     * 获取指定Id 的 中间表对象
     * @param ids
     * @return
     */
    public static List<AIDrawing> getAIDrawingsByIds(List<Long> ids) throws SQLException {

        String sql = "SELECT * FROM AIDRAWING WHERE AIDRAWINGID = TO_NUMBER(?)";

        List<AIDrawing> list = new ArrayList<>();
        for (Long id : ids) {
            ResultSet resultSet = CommonUtil.excuteSelect(sql, String.valueOf(id));
            while (resultSet.next()) {
                AIDrawing drawing = new AIDrawing(resultSet.getString("DOCMASTERCLASS"),Long.parseLong(resultSet.getString("DOCMASTERIDA2A2")),resultSet.getString("DOCOR"), resultSet.getString("DOCSTATUS"), resultSet.getString("ADDTIME"));
                drawing.setAIDrawingId(id);
                list.add(drawing);
            }
        }
        return list;
    }




    /**
     * 发送临时表数据到GDP
     * @param drawings
     * @return
     */
    public static SyncReqVo sendAIDrawingToGDP(List<AIDrawing> drawings) throws WTException, PropertyVetoException, IOException {

        SyncReqVo vo = new SyncReqVo();
        vo.setUserId(PropertiesUtil.getValueByKey("GDP.userId"));
        vo.setDeptId(Long.parseLong(PropertiesUtil.getValueByKey("GDP.deptId")));
        vo.setRequestDate(nowTimeToDate());
        vo.setDocMasters(getDocMasterVoList(drawings));
        return vo;
    }


    private static List<DocMasterVo> getDocMasterVoList(List<AIDrawing> drawings) throws WTException, PropertyVetoException, IOException {
        List<DocMasterVo> vos = new ArrayList<>();


        Map<String, List<AIDrawing>> fieldValuesAsMap = AIDrawing.getFieldValuesAsMap(drawings, "DOCMASTERCLASS", "DOCMASTERIDA2A2");

        for (Map.Entry<String, List<AIDrawing>> stringListEntry : fieldValuesAsMap.entrySet()) {
            String masterOr = stringListEntry.getKey();
            ObjectIdentifier oid =  ObjectIdentifier.newObjectIdentifier(masterOr);
            EPMDocumentMaster epmMaster =null;
            WTDocumentMaster documentMaster = null;
            DocMasterVo masterVo = new DocMasterVo();
            if(masterOr.contains("wt.epm.EPMDocumentMaster")){
                epmMaster = (EPMDocumentMaster) wt.fc.PersistenceHelper.manager.refresh(oid);
                masterVo.setDocName(epmMaster.getName());
                masterVo.setDocNumber(epmMaster.getNumber());
                masterVo.setDocMasterOr(CommonUtil.object2Oid(epmMaster));
                masterVo.setExist(true);
                masterVo.setDeptId(Long.parseLong(PropertiesUtil.getValueByKey("GDP.deptId")));
                masterVo.setUpdateTime(epmMaster.getModifyTimestamp());
                masterVo.setDocs(getDocVoList(stringListEntry.getValue()));
            } else if (masterOr.contains("wt.doc.WTDocumentMaster")) {
                documentMaster = (WTDocumentMaster) wt.fc.PersistenceHelper.manager.refresh(oid);
                masterVo.setDocName(documentMaster.getName());
                masterVo.setDocNumber(documentMaster.getNumber());
                masterVo.setDocMasterOr(CommonUtil.object2Oid(documentMaster));
                masterVo.setExist(true);
                masterVo.setDeptId(Long.parseLong(PropertiesUtil.getValueByKey("GDP.deptId")));
                masterVo.setUpdateTime(documentMaster.getModifyTimestamp());
                masterVo.setDocs(getDocVoList(stringListEntry.getValue()));
            }
            vos.add(masterVo);
        }

        return vos;
    }

    /**
     * 获取文档相关信息
     * @param drawings
     * @return
     */
    public static List<DocVo> getDocVoList(List<AIDrawing> drawings) throws PropertyVetoException, WTException, IOException {
        List<DocVo> result = new ArrayList<>();
        for (AIDrawing drawing : drawings) {
            DocVo vo = new DocVo();
            vo.setAIDrawingId(drawing.getAIDrawingId());
            String docOr = drawing.getDocOr();
            String docmasterclass = drawing.getDOCMASTERCLASS();
            WTObject object = CommonUtil.oid2Object(docOr);
            EPMDocument epmDoc = null;
            WTDocument wtDoc = null;
            if(docmasterclass.contains("wt.epm.EPMDocumentMaster")){
                if(object != null){
                    epmDoc = (EPMDocument)object;
                    vo.setVersionIdentifier(epmDoc.getVersionIdentifier().getValue());
                    vo.setIterationIdentifier(epmDoc.getIterationIdentifier().getValue());
                    vo.setEpmDocStatus(epmDoc.getState().getState().getDisplay(Locale.CHINA));
                    vo.setReleaseTime(epmDoc.getModifyTimestamp());
                    vo.setUpdateTime(epmDoc.getModifyTimestamp());
                }

            }else if (docmasterclass.contains("wt.doc.WTDocumentMaster")){
                if(object != null){
                    wtDoc = (WTDocument)object;
                    vo.setVersionIdentifier(wtDoc.getVersionIdentifier().getValue());
                    vo.setIterationIdentifier(wtDoc.getIterationIdentifier().getValue());
                    vo.setEpmDocStatus(wtDoc.getState().getState().getDisplay(Locale.CHINA));
                    vo.setReleaseTime(wtDoc.getModifyTimestamp());
                    vo.setUpdateTime(wtDoc.getModifyTimestamp());
                }
            }

            vo.setDocOr(docOr);

            vo.setExist(true);
            vo.setDocDraws(getDocDrawVosByWTObjectOr(docOr));

            result.add(vo);
        }

        return result;
    }


    /**
     * 通过文档OR 获取图纸相关信息集合
     * @param or
     * @return
     */
    private static List<DocDrawVo> getDocDrawVosByWTObjectOr(String or) throws PropertyVetoException, WTException, IOException {
        List<DocDrawVo> docDrawVos = new ArrayList<>();
        WTObject object = CommonUtil.oid2Object(or);
        if(object!=null && or.contains("wt.epm.EPMDocument")){
            EPMDocument epmDocument = (EPMDocument) object;
            List<ApplicationData> dataList = SyncDocDrawService.getEPMApplicationData(epmDocument);
            for (ApplicationData data : dataList) {
                DocDrawVo vo = new DocDrawVo();
                String fileName = data.getFileName();
                vo.setDrawName(fileName);
                vo.setExist(true);
                vo.setPersonResponsible(data.getModifiedBy().getDisplayName());
                vo.setUpdateTime(data.getModifyTimestamp());
                vo.setPictureFormat(FilenameUtils.getExtension(fileName));
                vo.setSourceFormat(FilenameUtils.getExtension(fileName));
                InputStream is = ContentServerHelper.service.findContentStream(data);
                byte[] bytes = IOUtils.toByteArray(is); // 使用 Apache Commons IO 工具类
                vo.setByteFile(bytes);
                docDrawVos.add(vo);
            }
        } else if(object!=null && or.contains("wt.doc.WTDocument")){
            // 文档主要内容
            WTDocument doc = (WTDocument) object;
//            List<ApplicationData> dataList = CommonUtil.getWTDocPrimary(doc);
            String oid = CommonUtil.object2Oid(doc);
            ContentItem primary = CommonUtil.findPrimary(oid);
            if(primary !=null){
                ApplicationData data = (ApplicationData) primary;
                DocDrawVo vo = new DocDrawVo();
                String fileName = data.getFileName();
                vo.setDrawName(fileName);
                vo.setExist(true);
                vo.setPersonResponsible(data.getModifiedBy().getDisplayName());
                vo.setUpdateTime(data.getModifyTimestamp());
                vo.setPictureFormat(FilenameUtils.getExtension(fileName));
                vo.setSourceFormat(FilenameUtils.getExtension(fileName));
                InputStream is = ContentServerHelper.service.findContentStream(data);
                byte[] bytes = IOUtils.toByteArray(is); // 使用 Apache Commons IO 工具类
                vo.setByteFile(bytes);
                docDrawVos.add(vo);
            }
        }
        return docDrawVos;
    }


    /**
     * 通过or 和  文档状态判断是否存在
     * @param or
     * @param docStatus
     * @return
     */
    public static String selectAIDrawingByOR(String or, String docStatus) throws SQLException {
        String result = "";
        String sql = "SELECT * FROM AIDRAWING WHERE DOCOR = ? AND DOCSTATUS = ?";
        ResultSet resultSet = CommonUtil.excuteSelect(sql, or, docStatus);
        while (resultSet.next()) {
            String docOr = resultSet.getString("DOCOR");
            String aiDrawingId = resultSet.getString("AIDRAWINGID");
            if(!StringUtils.isBlank(aiDrawingId)){
                result = aiDrawingId;
            }
        }

        return result;
    }


    /**
     * 插入临时表
     * @param epms
     * @return
     */
    public static int insertDocumentToAIDrawing(List<EPMDocument> epms, List<WTDocument> docs) {
        int result = 0;
        List<AIDrawing> draws = new ArrayList<>();
        for (EPMDocument epm : epms) {
            Mastered master = epm.getMaster();
            AIDrawing aiDrawing = new AIDrawing(master.getConceptualClassname(), master.getPersistInfo().getObjectIdentifier().getId(),CommonUtil.object2Oid(epm), GDP_STATUE_UNSEND, nowTime());
            draws.add(aiDrawing);
        }

        for (WTDocument doc : docs) {
            Mastered master = doc.getMaster();
            AIDrawing aiDrawing = new AIDrawing(master.getConceptualClassname(), master.getPersistInfo().getObjectIdentifier().getId(),CommonUtil.object2Oid(doc), GDP_STATUE_UNSEND, nowTime());
            draws.add(aiDrawing);
        }



        Transaction trx = null;
        try {
            trx= new Transaction();
            trx.start();
            for (AIDrawing draw : draws) {
                String sql = null;
                String docOr = draw.getDocOr();
                String aiDrawingId = selectAIDrawingByOR(docOr, GDP_STATUE_UNSEND);
                if (!StringUtils.isBlank(aiDrawingId)) {
                    // update
                    sql = "UPDATE AIDRAWING SET ADDTIME = TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS') WHERE AIDRAWINGID = TO_NUMBER(?)";
                    int i = CommonUtil.excuteUpdate(sql, nowTime(), aiDrawingId);
                    if(i >0){
                        result ++;
                    }
                }else {
                    // insert
                    sql = "INSERT INTO AIDRAWING (DOCOR, DOCSTATUS, ADDTIME,DOCMASTERCLASS,DOCMASTERIDA2A2) VALUES (?, ?, TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'),?,TO_NUMBER(?))";
//                String sql = "INSERT INTO AIDRAWING (DOCOR, DOCSTATUE, ADDTIME) VALUES (?, ?, ?)";
                    int i = CommonUtil.excuteUpdate(sql, docOr, draw.getDocStatus(), draw.getAddTime(), draw.getDOCMASTERCLASS(),String.valueOf(draw.getDOCMASTERIDA2A2()));
                    if(i >0){
                        result ++;
                    }
                }
            }
            trx.commit();
            trx = null;
        }catch (Exception e){
            e.printStackTrace();
        } finally {
            if(trx!=null){
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }

        return result;

    }


    /**
     * 根据文件名称获取默认表示法文件的 ApplicationData
     * @param epm
     * @param drawName
     * @return
     * @throws PropertyVetoException
     * @throws WTException
     */
    public static ApplicationData getEPMApplicationDataByDrawName(EPMDocument epm, String drawName) throws PropertyVetoException, WTException {
        ApplicationData data = null;
        VisualizationHelper vizHelper = new VisualizationHelper();
        QueryResult result = vizHelper.getRepresentations(epm);
        Representation rep = null;
        ContentHolder ch = null;
        Vector<?> appDatas = null;
        ApplicationData appData = null;

        while (result.hasMoreElements()) {
            rep = (Representation) result.nextElement();
            ch = ContentHelper.service.getContents(rep);
            String name = rep.getName();

            Boolean defaultRepresentation = rep.getDefaultRepresentation();
            //必须从默认表示法中获取pdf
            if(!defaultRepresentation){
                continue;
            }
            appDatas = ContentHelper.getContentListAll(ch);
            for (int i = 0; i < appDatas.size(); i++) {
                appData = (ApplicationData) appDatas.get(i);
                ContentRoleType role = appData.getRole();
                // 检查表示法中是否包含pdf
                if ((role.equals(ContentRoleType.ADDITIONAL_FILES) || role.equals(ContentRoleType.SECONDARY))) {
                    if(drawName.equalsIgnoreCase(appData.getFileName())){
                        data = appData;
                    }
                }
            }
        }

        return data;
    }



    private static String nowTime(){
        // 获取当前时间
        LocalDateTime now = LocalDateTime.now();

        // 在当前时间上加8小时
        LocalDateTime nowPlus8Hours = now.plusHours(8);

        // 定义日期时间格式，匹配 Oracle 的 DATE 字段格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // 格式化当前时间
        return nowPlus8Hours.format(formatter);
    }





    /**
     * 获取当前时间并加上8小时，返回 java.util.Date
     */
    private static Date nowTimeToDate() {
        // 获取当前时间
        LocalDateTime now = LocalDateTime.now();

        // 在当前时间上加8小时
        LocalDateTime nowPlus8Hours = now.plusHours(8);

        // 将 LocalDateTime 转换为 java.util.Date
        return Date.from(nowPlus8Hours.atZone(ZoneId.systemDefault()).toInstant());
    }
}
