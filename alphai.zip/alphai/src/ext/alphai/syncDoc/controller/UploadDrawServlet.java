package ext.alphai.syncDoc.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.syncDoc.domain.ResponseVo;
import ext.alphai.syncDoc.service.AIDrawingService;
import ext.alphai.syncDoc.vo.GDPDownloadDrawVo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Controller
public class UploadDrawServlet extends HttpServlet {


    static final ObjectMapper objectMapper = new ObjectMapper();
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("deprecation")
    @RequestMapping(method = { RequestMethod.GET, RequestMethod.POST,
            RequestMethod.HEAD })
    protected void processRequest(@RequestBody String json, HttpServletRequest request,
                                  HttpServletResponse response) throws ServletException, IOException {

        GDPDownloadDrawVo downloadDrawVo = objectMapper.readValue(json, GDPDownloadDrawVo.class);
        ResponseVo vo = AIDrawingService.uploadDraw(downloadDrawVo);
        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response, respJson);
    }


    public void outResponse(HttpServletResponse response, String json) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }


}
