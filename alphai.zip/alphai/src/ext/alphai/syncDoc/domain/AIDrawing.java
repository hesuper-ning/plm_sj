package ext.alphai.syncDoc.domain;



import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AIDrawing {

    private Long AIDrawingId;

    private String DOCMASTERCLASS;

    private Long DOCMASTERIDA2A2;

    private String docOr;

    private String docStatus;

    private String addTime;

    public AIDrawing() {
    }

    public AIDrawing(String DOCMASTERCLASS, Long DOCMASTERIDA2A2, String docOr, String docStatus, String addTime) {
        this.DOCMASTERCLASS = DOCMASTERCLASS;
        this.DOCMASTERIDA2A2 = DOCMASTERIDA2A2;
        this.docOr = docOr;
        this.docStatus = docStatus;
        this.addTime = addTime;
    }

    public Long getAIDrawingId() {
        return AIDrawingId;
    }

    public void setAIDrawingId(Long AIDrawingId) {
        this.AIDrawingId = AIDrawingId;
    }

    public String getDOCMASTERCLASS() {
        return DOCMASTERCLASS;
    }

    public void setDOCMASTERCLASS(String DOCMASTERCLASS) {
        this.DOCMASTERCLASS = DOCMASTERCLASS;
    }

    public Long getDOCMASTERIDA2A2() {
        return DOCMASTERIDA2A2;
    }

    public void setDOCMASTERIDA2A2(Long DOCMASTERIDA2A2) {
        this.DOCMASTERIDA2A2 = DOCMASTERIDA2A2;
    }

    public String getDocOr() {
        return docOr;
    }

    public void setDocOr(String docOr) {
        this.docOr = docOr;
    }

    public String getDocStatus() {
        return docStatus;
    }

    public void setDocStatus(String docStatus) {
        this.docStatus = docStatus;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }


    public static Map<String, List<AIDrawing>> getFieldValuesAsMap(List<AIDrawing> list, String fieldName1, String fieldName2) {
        Map<String, List<AIDrawing>> result = new HashMap<>();

        try {
            // 提前获取字段对象，避免重复反射
            Field field1 = AIDrawing.class.getDeclaredField(fieldName1);
            field1.setAccessible(true);

            Field field2 = AIDrawing.class.getDeclaredField(fieldName2);
            field2.setAccessible(true);

            for (AIDrawing doc : list) {
                // 获取字段值
                String value1 = (String) field1.get(doc);
                Long value2 = (Long) field2.get(doc);

                // 拼接 key
                String key = value1 + ":" + value2;

                // 如果 key 不存在，创建一个新的 List
                result.computeIfAbsent(key, k -> new ArrayList<>()).add(doc);
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace(); // 异常处理，根据需要调整
        }

        return result;
    }











//    public static Map<String, AIDrawing> getFieldValuesAsMap(List<AIDrawing> list, String fieldName1, String fieldName2) {
//        Map<String, AIDrawing> result = new HashMap<>();
//
//        // 提前获取字段对象，避免重复反射
//        Field field1 = getField(AIDrawing.class, fieldName1);
//        Field field2 = getField(AIDrawing.class, fieldName2);
//
//        if (field1 == null || field2 == null) {
//            throw new IllegalArgumentException("字段不存在");
//        }
//
//        for (AIDrawing doc : list) {
//            try {
//                // 获取字段值并转换为字符串
//                String value1 = getFieldValueAsString(doc, field1);
//                String value2 = getFieldValueAsString(doc, field2);
//
//                // 拼接键并放入结果 Map
//                result.put(value1 + ":" + value2, doc);
//            } catch (IllegalAccessException e) {
//                e.printStackTrace(); // 异常处理，根据需要调整
//            }
//        }
//
//        return result;
//    }
//
//    /**
//     * 获取字段对象
//     */
//    private static Field getField(Class<?> clazz, String fieldName) {
//        try {
//            Field field = clazz.getDeclaredField(fieldName);
//            field.setAccessible(true);
//            return field;
//        } catch (NoSuchFieldException e) {
//            e.printStackTrace(); // 异常处理，根据需要调整
//            return null;
//        }
//    }
//
//    /**
//     * 获取字段值并转换为字符串
//     */
//    private static String getFieldValueAsString(Object obj, Field field) throws IllegalAccessException {
//        Object value = field.get(obj);
//        return value != null ? value.toString() : ""; // 处理 null 值
//    }
}
