package ext.alphai.syncDoc.QRCode;

import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import ext.alphai.syncDoc.util.PropertiesUtil;

import java.io.*;

/**
 * 操作PDF的方法
 */
public class PDFWithQRCode {


    // 将二维码流添加到现有 PDF 的右上角
    public static void addQRCodeToPDF(InputStream qrCodeImageStream, String inputPdfPath, String outputPdfPath, String pdfType) throws Exception {
        int size = Integer.parseInt(PropertiesUtil.getValueByKey("GDP.QR.Size"));  // 二维码的长宽
        // 检查输入参数
        if (qrCodeImageStream == null) {
            throw new IllegalArgumentException("二维码输入流不能为空");
        }
        if (inputPdfPath == null || outputPdfPath == null) {
            throw new IllegalArgumentException("输入或输出文件路径不能为空");
        }

        // 检查输入 PDF 文件
        File inputFile = new File(inputPdfPath);
        if (!inputFile.exists() || inputFile.length() == 0) {
            throw new IOException("输入 PDF 文件不存在或为空: " + inputPdfPath);
        }

        // 检查输出文件路径
        File outputFile = new File(outputPdfPath);
        File outputDir = outputFile.getParentFile();
        if (!outputDir.exists()) {
            if (!outputDir.mkdirs()) {
                throw new IOException("无法创建输出目录: " + outputDir.getAbsolutePath());
            }
        }
        if (!outputDir.canWrite()) {
            throw new IOException("输出目录无写入权限: " + outputDir.getAbsolutePath());
        }

        PdfReader reader = null;
        FileOutputStream outputStream = null;
        PdfStamper stamper = null;

        try {
            // 初始化 PdfReader 和 FileOutputStream
            reader = new PdfReader(inputPdfPath);
            outputStream = new FileOutputStream(outputFile);

            // 初始化 PdfStamper
            stamper = new PdfStamper(reader, outputStream);

            // 获取第一个页面
            PdfContentByte canvas = stamper.getOverContent(1);

            // 将 InputStream 转换为字节数组
            byte[] imageBytes = inputStreamToByteArray(qrCodeImageStream);
            if (imageBytes == null || imageBytes.length == 0) {
                throw new IOException("二维码图片流无效");
            }

            // 加载二维码图片
            Image qrCodeImage = Image.getInstance(imageBytes);

            // 设置二维码的大小
            qrCodeImage.scaleAbsolute(size, size);

            // 获取页面的宽度和高度
//            float pageWidth = reader.getPageSize(1).getWidth();
//            float pageHeight = reader.getPageSize(1).getHeight();
//
//            // 计算二维码的位置（右上角）
//            float x = pageWidth - qrCodeImage.getScaledWidth() - 40;  // 右边距 40 像素
//            float y = pageHeight - qrCodeImage.getScaledHeight() - 40;  // 上边距 40 像素
            // 配置文件中的XY 轴
            String xyStr = PropertiesUtil.getValueByKey(pdfType);
            String[] split = xyStr.split(",");

            qrCodeImage.setAbsolutePosition(Integer.parseInt(split[0])-size, Integer.parseInt(split[1])-size);

            // 将二维码添加到页面
            canvas.addImage(qrCodeImage);

            System.out.println("二维码贴到图纸PDF成功!");
        } catch (IOException | DocumentException e) {
            System.err.println("操作 PDF 失败: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            // 手动关闭资源
            try {
                if (stamper != null) {
                    stamper.close(); // 关闭 PdfStamper
                }
            } catch (Exception e) {
                System.err.println("关闭 PdfStamper 失败: " + e.getMessage());
                e.printStackTrace();
            } finally {
                try {
                    if (reader != null) {
                        reader.close(); // 关闭 PdfReader
                    }
                } catch (Exception e) {
                    System.err.println("关闭 PdfReader 失败: " + e.getMessage());
                } finally {
                    try {
                        if (outputStream != null) {
                            outputStream.close(); // 关闭 FileOutputStream
                        }
                    } catch (IOException e) {
                        System.err.println("关闭 FileOutputStream 失败: " + e.getMessage());
                    }
                }
            }
        }
    }

    // 将 InputStream 转换为字节数组
    private static byte[] inputStreamToByteArray(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) != -1) {
            byteArrayOutputStream.write(buffer, 0, length);
        }
        return byteArrayOutputStream.toByteArray();
    }
}
