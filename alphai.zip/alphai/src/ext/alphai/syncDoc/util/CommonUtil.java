package ext.alphai.syncDoc.util;
import java.beans.PropertyVetoException;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.HttpURLConnection;
import java.net.URL;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.lwc.common.view.EnumerationDefinitionReadView;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.server.LWCLocalizablePropertyValue;
import com.ptc.core.lwc.server.LWCTypeDefinition;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.*;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import wt.change2.*;
import wt.content.*;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.method.MethodContext;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.OrganizationServicesHelper;
import wt.org.WTUser;
import wt.pom.WTConnection;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class CommonUtil implements RemoteAccess {

	/**
	 * 转换中文格式，避免中文乱码
	 * 
	 * @param value
	 * @return
	 * @throws WTException
	 */
	public static String formatString(String value) throws WTException {
		try {
			if (value != null && value.trim().length() > 0) {
				byte[] tembyte = value.getBytes("gb2312");
				return new String(tembyte);
			} else {
				return value;
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 根据给定的参数来添加指定数量的前导零
	 * 
	 * @param attr   传入的数
	 * @param length 添加0之后的总长度
	 * @return 添加前导0之后的字符串
	 */
	public static String addLead0(String attr, int length) {
		if (attr.length() < length) {
			StringBuilder resultSB = new StringBuilder(attr);
			while (resultSB.length() < length) {
				resultSB.insert(0, '0'); // 在前面添加零
			}
			return resultSB.toString();
		}
		return attr;
	}

	/**
	 * 将一个实体类中的所有字段转换为Map
	 * 
	 * @param entity 实体类
	 * @return 输出的Map
	 */
	public static <T> Map<String, Object> entityToMap(T entity) {
		Map<String, Object> resultMap = new HashMap<>();

		// 使用反射获取类的所有字段
		Field[] fields = entity.getClass().getDeclaredFields();

		try {
			for (Field field : fields) {
				// 设置字段为可访问，以便获取私有字段的值
				field.setAccessible(true);

				// 将字段名和字段值添加到Map中
				resultMap.put(field.getName(), field.get(entity));
			}
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}

		return resultMap;
	}

	/**
	 * 根据用户id获取WTUser对象
	 * 
	 * @param id
	 * @return
	 * @throws WTException
	 */
	@SuppressWarnings("deprecation")
	public static WTUser getUserById(String id) throws WTException {
		WTUser user = null;
		try {
			if (id != null && id.trim().length() > 0) {
				QuerySpec qs = new QuerySpec(WTUser.class);
				SearchCondition sc1 = new SearchCondition(WTUser.class, WTUser.NAME, SearchCondition.EQUAL, id);
				SearchCondition sc2 = new SearchCondition(WTUser.class, WTUser.FULL_NAME, SearchCondition.EQUAL, id);
				qs.appendWhere(sc1);
				qs.appendOr();
				qs.appendWhere(sc2);
				QueryResult qr = new QueryResult();
				qr = PersistenceHelper.manager.find(qs);
				while (qr.hasMoreElements()) {
					user = (WTUser) qr.nextElement();
				}
			}
			return user;
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 通过类型的Key获取国际化的名称
	 * 
	 * @param key
	 * @return
	 * @throws WTException
	 */
	@SuppressWarnings("deprecation")
	public static String getTypeDisplayName(String key) throws WTException {
		String typeDisplayName = "";
		try {
			LWCTypeDefinition lwcType = null;
			QuerySpec lwcSpec = new QuerySpec(LWCTypeDefinition.class);
			lwcSpec.appendSearchCondition(
					new SearchCondition(LWCTypeDefinition.class, LWCTypeDefinition.NAME, SearchCondition.EQUAL, key));
			QueryResult qr = PersistenceHelper.manager.find(lwcSpec);
			while (qr.hasMoreElements()) {
				lwcType = (LWCTypeDefinition) qr.nextElement();
			}
			if (lwcType != null) {
				/**
				 * LWCLocalizablePropertyValue记录所有的国际化字段
				 */
				QuerySpec valueSpec = new QuerySpec(LWCLocalizablePropertyValue.class);
				valueSpec.appendSearchCondition(
						new SearchCondition(LWCLocalizablePropertyValue.class, "contextReference.key.id",
								SearchCondition.EQUAL, lwcType.getPersistInfo().getObjectIdentifier().getId()));
				valueSpec.appendAnd();
				valueSpec.appendSearchCondition(
						new SearchCondition(LWCLocalizablePropertyValue.class, "holderReference.key.id",
								SearchCondition.EQUAL, lwcType.getPersistInfo().getObjectIdentifier().getId()));
				QueryResult vqr = PersistenceHelper.manager.find(valueSpec);
				while (vqr.hasMoreElements()) {
					LWCLocalizablePropertyValue value = (LWCLocalizablePropertyValue) vqr.nextElement();
					typeDisplayName = value.getValue(Locale.CHINA);
					if (typeDisplayName == null || typeDisplayName.trim().length() == 0) {
						typeDisplayName = value.getValue();
					}
				}
			}
			return typeDisplayName;
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 根据用户名称/用户全名获取用户对象
	 * 
	 * @param String
	 * @param boolean
	 * @return WTUser
	 */
	@SuppressWarnings("deprecation")
	public static WTUser getUserByName(String name, boolean IsFull) {
		String parm = IsFull ? WTUser.FULL_NAME : WTUser.NAME;
		if (StringUtils.isBlank(name)) {
			return null;
		}
		try {
			Enumeration enumUser = OrganizationServicesHelper.manager.findUser(parm, name.trim());
			while (enumUser.hasMoreElements()) {
				return (WTUser) enumUser.nextElement();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	/**
	 * 根据全局枚举的内部名称获取其中所有的子枚举的内部名称与外部名称
	 * 
	 * @param String
	 * @return Map<String, String>
	 */
	public static Map<String, String> getEnumTypeByInternalName(String internalName) {
		Map<String, String> map = new HashMap<>();
		try {
			EnumerationDefinitionReadView edr = TypeDefinitionServiceHelper.service.getEnumDefView(internalName);
			if (edr != null) {
				Map<String, EnumerationEntryReadView> views = edr.getAllEnumerationEntries();
				Set<String> keysOfView = views.keySet();
				for (String key : keysOfView) {
					EnumerationEntryReadView view = views.get(key);
					String enumKey = view.getName();
					String enumName = view.getPropertyValueByName("displayName").getValue().toString();
					// 此方法判断枚举值是否在可用列表
					if (view.getPropertyValueByName("selectable").getValue().equals(true)) {
						map.put(enumKey, enumName);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}

	/**
	 * 从QueryResult中获取需要类型的对象数据
	 * 
	 * @param <T>   泛型对象
	 * @param qr
	 * @param clazz
	 * @return
	 */
	public static <T> ArrayList<T> getListFromQR(QueryResult qr, Class<T> clazz) {
		ArrayList<T> list = new ArrayList<T>();
		while (qr.hasMoreElements()) {
			Object obj = qr.nextElement();
			if (clazz.isInstance(obj)) {
				T castedObj = clazz.cast(obj);
				list.add(castedObj);
			}
		}
		return list;
	}

	/**
	 * 连接Windchill数据库来运行自定义sql
	 * 
	 * @return WTConnection 数据库连接
	 * @throws Exception
	 */
	public static WTConnection getWTConnection() {
		WTConnection wtconnection = null;
		try {
			MethodContext methodcontext = MethodContext.getContext();
			wtconnection = (WTConnection) methodcontext.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return wtconnection;
	}

	/**
	 * 执行查询的SQL语句并返回结果 SQL示例：SELECT WTPARTNUMBER FROM WTPARTMASTER WHERE
	 * WTPARTNUMBER LIKE ?
	 * 
	 * @param sql    SQL语句
	 * @param params 参数集
	 * @return ResultSet 返回结果集
	 */
	public static ResultSet excuteSelect(String sql, String... params) {
		try {
			WTConnection connection = CommonUtil.getWTConnection();
			PreparedStatement statement = connection.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				statement.setString(i + 1, params[i]);
			}

			// 输出当前执行查询操作的SQL语句
			String fullSql = sql;
			for (String param : params) {
				param = param.length() > 250 ? "此属性太长，不显示内容" : param;
				fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
			}
			System.out.println("--------当前执行查询操作的SQL语句为--------");
			System.out.println(fullSql);

			ResultSet resultSet = statement.executeQuery();
			return resultSet;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static ResultSet executePreparedQuery(String sql, Object... params) {
		try {
			WTConnection conn = getWTConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				pstmt.setObject(i + 1, params[i]);
			}
			return pstmt.executeQuery();
		} catch (SQLException e){
			e.printStackTrace();
		}
         return null;
	}

	/**
	 * 获取文档主要内容
	 * @param document
	 * @return
	 */
	public static List<ApplicationData> getWTDocPrimary(WTDocument document){
		List<ApplicationData> appData = new ArrayList<ApplicationData>();
		try {

			ContentHolder contentHolder = ContentHelper.service.getContents(document);
			//然后获取主文件
			QueryResult qr = ContentHelper.service.getContentsByRole(contentHolder, ContentRoleType.PRIMARY);
			if (qr != null && qr.hasMoreElements()) {
				ContentItem primarycontent = (ContentItem) qr.nextElement();
				appData.add((ApplicationData) primarycontent);
			}
		} catch (WTException e) {
			e.printStackTrace();
		} catch (PropertyVetoException e) {
			e.printStackTrace();
		}
		return appData;
	}


	/**
	 * 执行更新的SQL语句并返回被更新的条数 SQL示例：UPDATE WTPARTMASTER SET WTPARTNUMBER = ? WHERE
	 * IDA2A2 = ?
	 * 
	 * @param sql    SQL语句
	 * @param params 参数集
	 * @return int 数据库表被影响的行数
	 */
	public static int excuteUpdate(String sql, String... params) {
		try {
			WTConnection connection = CommonUtil.getWTConnection();
			PreparedStatement statement = connection.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				statement.setString(i + 1, params[i]);
			}

			// 输出当前执行更新操作的SQL语句
			String fullSql = sql;
			for (String param : params) {
				param = param.length() > 250 ? "此属性太长，不显示内容" : param;
				fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
			}
			System.out.println("--------当前执行更新操作的SQL语句为--------");
			System.out.println(fullSql);

			return statement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * 执行插入的SQL语句
	 * 
	 * @param sql    被执行的SQL语句
	 * @param params SQL语句中的参数
	 * @return 是否执行成功
	 */
	public static int excuteInsert(String sql, String... params) {
		try {
			WTConnection connection = CommonUtil.getWTConnection();
			PreparedStatement statement = connection.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				statement.setString(i + 1, params[i]);
			}

			// 输出当前执行更新操作的SQL语句
			String fullSql = sql;
			for (String param : params) {
				param = param.length() > 250 ? "此属性太长，不显示内容" : param;
				fullSql = fullSql.replaceFirst("\\?", "\"" + param + "\"");
			}
			System.out.println("--------当前执行插入操作的SQL语句为--------");
			System.out.println(fullSql);
			return statement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * 携带信息并用POST请求外部系统（如SAP，OA）中的某个接口 存在账户和密码时则设置验证否则不设置 map为添加到Headers上的内容，无则填null
	 * 
	 * @param url      访问目标接口的URL
	 * @param username 访问目标接口需要验证的用户名
	 * @param password 访问目标接口需要验证的密码
	 * @param json     携带的json信息
	 * @param method   请求的方式 GET/POST
	 * @param map      请求头中需要添加的信息,没有填null
	 * @return 返回的json信息
	 */
	public static String requestInterface(String url, String username, String password, String json, String method,
			HashMap<String, String> map) {
		// 输出日志文件
		System.out.println("--------当前执行的请求接口的参数列表--------");
		System.out.println("URL: " + url);
		System.out.println("USERNAME: " + username + " PASSWORD:" + password);
//		System.out.println("JSON: " + processJson(json));
		System.out.println("JSON: " + json);
		System.out.println("METHOD: " + method);
		System.out.println("HEADERS: ");

		RestTemplate restTemplate = new RestTemplate();
		// 添加BASIC认证
		if (StringUtils.isNotBlank(password) && StringUtils.isNotBlank(username)) {
//			restTemplate.getInterceptors().add(new BasicAuthenticationInterceptor(username, password));
		}
		restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(Charset.forName("utf-8")));
		// 自定义请求头,添加headers内容
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAcceptCharset(Collections.singletonList(Charset.forName("utf-8")));
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		if (map != null) {
			Set<String> set = map.keySet();
			if (set.size() > 0) {
				for (String key : set) {
					String value = map.get(key);
					System.out.println("key:" + key + " value:" + map.get(key));
					headers.add(key, value);
				}
			}
		}
		// 添加json参数,设置请求的方法并获取返回的json信息
		HttpEntity<String> entity = new HttpEntity<String>(json, headers);
		ResponseEntity<String> responseEntity = method.equalsIgnoreCase("GET")
				? restTemplate.exchange(url, HttpMethod.GET, entity, String.class)
				: restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

		if (responseEntity == null) {
			return null;
		}
		String resultJson = responseEntity.getBody().toString();
		System.out.println("RESULTJSON: " + resultJson);
		return resultJson;
	}

	/**
	 * 当参数类型为x-www-form-urlencoded时调用接口，大致与上个方法相同
	 * 
	 * @param url      访问目标接口的URL
	 * @param formData 访问目标接口携带的formdata信息
	 * @param method   请求的方式 GET/POST
	 * @param map      请求头中需要添加的信息,没有填null
	 * @return 返回的json信息
	 */
	public static String requestInterface(String url, String method, HashMap<String, Object> formData,
			HashMap<String, String> map) {
		System.out.println("--------当前执行的请求接口的参数列表--------");
		System.out.println("URL: " + url);
		System.out.println("METHOD: " + method);
		System.out.println("HEADERS: ");

		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(Charset.forName("utf-8")));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.setAcceptCharset(Collections.singletonList(Charset.forName("utf-8")));
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		if (map != null) {
			Set<String> set = map.keySet();
			if (set.size() > 0) {
				for (String key : set) {
					String value = map.get(key);
					System.out.println("key:" + key + " value:" + map.get(key));
					headers.add(key, value);
				}
			}
		}
		// 创建 x-www-form-urlencoded 参数
		MultiValueMap<String, Object> formDataMap = new LinkedMultiValueMap<>();
		if (formData != null) {
			formData.forEach((key, value) -> {
				System.out.println("KEY: " + key + " VALUE: " + value);
			});
			formDataMap.setAll(formData);
		}
		// 参数
		HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(formDataMap, headers);
		ResponseEntity<String> responseEntity = method.equalsIgnoreCase("GET")
				? restTemplate.exchange(url, HttpMethod.GET, entity, String.class)
				: restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

		if (responseEntity == null) {
			return null;
		}
		String resultJson = responseEntity.getBody().toString();
		System.out.println("RESULTJSON: " + resultJson);
		return resultJson;
	}

	private static String processJson(String json) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			ObjectNode rootNode = objectMapper.createObjectNode();

			JsonNode originalRootNode = objectMapper.readTree(json);
			processJsonNode(rootNode, originalRootNode);

			return objectMapper.writeValueAsString(rootNode);
		} catch (Exception e) {
			e.printStackTrace();
			return json; // Return the original JSON in case of an error
		}
	}

	private static void processJsonNode(ObjectNode targetNode, JsonNode sourceNode) {
		if (sourceNode.isObject()) {
			Iterator<Map.Entry<String, JsonNode>> fields = sourceNode.fields();
			while (fields.hasNext()) {
				Map.Entry<String, JsonNode> entry = fields.next();
				String fieldName = entry.getKey();
				JsonNode fieldNode = entry.getValue();
				if (fieldNode.isTextual()) {
					String fieldValue = fieldNode.asText();
					if (fieldValue.length() > 250) {
						targetNode.put(fieldName, "此属性太长，不显示内容");
					} else {
						targetNode.set(fieldName, fieldNode);
					}
				} else if (fieldNode.isObject() || fieldNode.isArray()) {
					ObjectNode childTargetNode = targetNode.putObject(fieldName);
					processJsonNode(childTargetNode, fieldNode);
				}
			}
		} else if (sourceNode.isArray()) {
			// Handle arrays if necessary
		}
	}

	/**
	 * 获取Windchill系统CSRF_NONCE（token）
	 * 
	 * @return CSRF_NONCE
	 */
	public static String getCSRF_NONCE(String url) throws Exception{
		String result = CommonUtil.requestInterface(url, "wcadmin", "wcadmin", "", "GET", null);
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode rootNode = objectMapper.readTree(result);
			JsonNode NonceValue = rootNode.get("NonceValue");
			return NonceValue.asText();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return "";
	}

	/**
	 * 从request中获取字节流的信息将其中的json转换为实体类列表
	 * 
	 * @param <T>            实体类
	 * @param request        传递的请求参数
	 * @param clazz          实体类类型
	 * @param rootNodeString 是否有根节点
	 * @return T 实体类列表
	 */
	public static <T> List<T> getEntitiesFromRequest(HttpServletRequest request, Class<T> clazz,
			String rootNodeString)  throws Exception{
		try {
			BufferedReader reader = request.getReader();
			StringBuilder jsonInput = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				jsonInput.append(line);
			}
			System.out.println("-------从HttpServletRequest获取到的内容-------");
			System.out.println("json: " + jsonInput.toString());
			return getEntitiesFromJson(jsonInput.toString(), clazz, rootNodeString);
		} catch (IOException e) {
			e.printStackTrace();
			return Collections.emptyList();
		}
	}

	/**
	 * 将json转换为实体类列表
	 * 
	 * @param <T>            实体类
	 * @param json           需要转换的json
	 * @param clazz          实体类类型
	 * @param rootNodeString 是否有根节点
	 * @return T 实体类列表
	 */
	public static <T> List<T> getEntitiesFromJson(String json, Class<T> clazz, String rootNodeString)  throws Exception{
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(json.toString());
			List<T> entities = new ArrayList<>();
			// 如果没有指定根节点字符串，则直接尝试解析为实体对象
			// 如果指定了根节点字符串，则尝试从根节点中获取指定的节点
			rootNode = StringUtils.isNotBlank(rootNodeString) ? rootNode.get(rootNodeString) : rootNode;

			if (rootNode.isArray()) {
				for (JsonNode node : rootNode) {
					T entity = objectMapper.treeToValue(node, clazz);
					entities.add(entity);
				}
			} else {
				T entity = objectMapper.treeToValue(rootNode, clazz);
				entities.add(entity);
			}
			return entities;
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return Collections.emptyList();
	}

	/**
	 * 将实体类转换为json
	 * 
	 * @param data 可以为entity，map，Object几乎任何可以转换为json的类型
	 * @return json
	 */
	public static <T> String getJsonFromObject(T data) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 将传入的PBO解析为方便处理的List<T>
	 * 
	 * @param <T>        泛型
	 * @param obj        PBO
	 * @param targetType 结果的类型
	 * @return
	 */
	public static <T> List<T> getListFromPBO(WTObject obj, Class<T> targetType) {
		List<T> list = new ArrayList<>();
		try {
			if (targetType.isInstance(obj)) {
				list.add(targetType.cast(obj));
			} else if (obj instanceof PromotionNotice) {
				PromotionNotice pn = (PromotionNotice) obj;
				QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
				list = CommonUtil.getListFromQR(qr, targetType);
			} else if (obj instanceof WTChangeOrder2) {
				WTChangeOrder2 co = (WTChangeOrder2) obj;
				QueryResult qr = ChangeHelper2.service.getChangeablesAfter(co);
				list = CommonUtil.getListFromQR(qr, targetType);
			} else if (obj instanceof WTChangeActivity2) {
				WTChangeActivity2 eca = (WTChangeActivity2) obj;
				QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
				list = CommonUtil.getListFromQR(qr, targetType);
			} else if (obj instanceof WTChangeRequest2) {
				WTChangeRequest2 ecr = (WTChangeRequest2) obj;
				QueryResult qr = ChangeHelper2.service.getChangeables((ChangeRequestIfc) ecr);
				list = CommonUtil.getListFromQR(qr, targetType);
			} else {
				System.out.println("数据不正确!");
			}
		} catch (ChangeException2 e) {
			e.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}
	/**
	 * 获取对象的oid
	 *
	 * @param WTObject
	 * @return String
	 */
	public static String object2Oid(WTObject obj) {
		String className = obj.getClass().getName();
		String oid = String.valueOf(obj.getPersistInfo().getObjectIdentifier().getId());
		return "OR:" + className + ":" + oid;
	}

	/**
	 * 获取oid所对应的对象
	 *
	 * @param String
	 * @return WTObject
	 * @throws WTException
	 */
	public static WTObject oid2Object(String oid) {
		try {
			ReferenceFactory factory = new ReferenceFactory();
			return (WTObject) factory.getReference(oid).getObject();
		} catch (WTRuntimeException e) {
			e.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		}
		return null;
	}


	/**
	 * 根据master获取所有版本EPMDoc
	 * @param master
	 * @return
	 */
	public static List<EPMDocument> getEPMDocumentByMaster(EPMDocumentMaster master){
		List<EPMDocument> documents = new ArrayList<>();
		QueryResult qr = null;

        try {
			qr = VersionControlHelper.service.allVersionsOf(master);
			while (qr.hasMoreElements()) {
				Object o = qr.nextElement();
				if(o!=null){
					EPMDocument doc = (EPMDocument)o;
					documents.add(doc);
				}
			}

        } catch (WTException e) {
            e.printStackTrace();
        }

		return documents;
    }



	private static final ObjectMapper objectMapper = new ObjectMapper();

	/**
	 * 登录 RuoYi 并获取 Token
	 * @return Token
	 */
	public static String loginGDP() throws Exception {
		String token = "";
		URL url = new URL(PropertiesUtil.getValueByKey("GDP.login.url")); // RuoYi 登录接口 URL
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setDoOutput(true);

		// 构造登录参数
		HashMap<String, String> params = new HashMap<>();
		params.put("username", PropertiesUtil.getValueByKey("GDP.username")); // RuoYi 用户名
		params.put("password", PropertiesUtil.getValueByKey("GDP.password")); // RuoYi 密码
		String jsonInputString = objectMapper.writeValueAsString(params);

		// 发送请求
		try (OutputStream os = conn.getOutputStream()) {
			byte[] input = jsonInputString.getBytes("utf-8");
			os.write(input, 0, input.length);
		}

		// 读取响应
		try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
			StringBuilder response = new StringBuilder();
			String responseLine;
			while ((responseLine = br.readLine()) != null) {
				response.append(responseLine.trim());
			}
			// 解析 Token
			HashMap<String, String> responseMap = objectMapper.readValue(response.toString(), HashMap.class);
			token = responseMap.get("token"); // 假设返回的 Token 字段名为 "token"
		}

		return token;
	}








	/**
	 * 发送请求到目标接口
	 * @param url       目标接口 URL
	 * @param token     RuoYi 的 Token
	 * @param json      请求的 JSON 数据
	 * @param method    请求方法（GET/POST）
	 * @return 返回的 JSON 数据
	 */
	public static String sendRequest(String url, String token, String json, String method) {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(Charset.forName("utf-8")));

		// 设置请求头
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + token); // 添加 Token 到请求头

		// 构造请求实体
		HttpEntity<String> entity = new HttpEntity<>(json, headers);

		// 发送请求
		ResponseEntity<String> responseEntity = method.equalsIgnoreCase("GET")
				? restTemplate.exchange(url, HttpMethod.GET, entity, String.class)
				: restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

		if (responseEntity == null) {
			return null;
		}
		return responseEntity.getBody();
	}



	/**
	 * 传入一个父部件返回在table上可以点击的物料编号连接
	 * @param part
	 * @return
	 * @throws WTException
	 */
	public static UrlDisplayComponent getEPMDocUrl(EPMDocument epm) throws WTException {
		NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();

		urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);

		NmOid contentOid = NmOid.newNmOid(epm.getPersistInfo().getObjectIdentifier());

		String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null, true);

		UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent("", epm.getNumber(), link);
		return urlDisplayComponent;
	}


	public static UrlDisplayComponent getWTDocUrl(WTDocument doc) throws WTException {
		NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();

		urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);

		NmOid contentOid = NmOid.newNmOid(doc.getPersistInfo().getObjectIdentifier());

		String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null, true);

		UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent("", doc.getNumber(), link);
		return urlDisplayComponent;
	}



	/**
	 * 判断对象是否处于检出状态
	 *
	 * @param Workable
	 * @return boolean
	 */
	public static boolean isCheckOut(Workable workable) {
		try {
			return WorkInProgressHelper.isCheckedOut(workable);
		} catch (WTException e) {

		}
		return false;
	}


	/**
	 * 下载主要内容——服务器文件夹
	 *
	 * @param oid
	 * @param directory
	 * @return
	 */
	public static File downloadPrimary(String oid, String directory) {
		if (!RemoteMethodServer.ServerFlag) {
			Class<?>[] classArray = new Class[]{String.class, String.class};
			Object[] objs = new Object[]{oid, directory};
			try {
				return (File) RemoteMethodServer.getDefault().invoke("downloadPrimary", WTDocument.NAME, WTDocument.class, classArray, objs);
			} catch (InvocationTargetException | RemoteException e) {
				e.printStackTrace();
			}
		} else {
			File file = null;
			ContentItem primaryContent = findPrimary(oid);
			if (primaryContent != null && primaryContent instanceof ApplicationData) {
				ApplicationData applicationData = (ApplicationData) primaryContent;
				file = new File(directory + applicationData.getFileName());

				InputStream instream = null;
				BufferedInputStream buffInStream = null;
				FileOutputStream outstream = null;
				try {
					instream = ContentServerHelper.service.findContentStream(applicationData);
					buffInStream = new BufferedInputStream(instream);
					byte[] buf = new byte[1024];
					outstream = new FileOutputStream(file);
					int readBytes = 0;
					while ((readBytes = buffInStream.read(buf, 0, 1024)) != -1) {
						outstream.write(buf, 0, readBytes);
					}
				} catch (WTException | IOException e) {
					e.printStackTrace();
				} finally {
					try {
						outstream.close();
						buffInStream.close();
						instream.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return file;
		}
		return null;
	}
	/**
	 * 获取文档主要内容
	 *
	 * @param oid
	 * @return
	 */
	public static ContentItem findPrimary(String oid) {
		if (!RemoteMethodServer.ServerFlag) {
			Class<?>[] classArray = new Class[]{String.class};
			Object[] param = new Class[]{String.class};
			try {
				return (ContentItem) RemoteMethodServer.getDefault().invoke("findPrimary", WTDocument.NAME, WTDocument.class, classArray, param);
			} catch (RemoteException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
		} else {
			ContentItem primarycontent = null;
			WTDocument doc = null;
			try {
				NmOid nmOid = NmOid.newNmOid(oid);
				Object obj = nmOid.getRefObject();
				if (obj != null && obj instanceof WTDocument) {
					doc = (WTDocument) obj;
					//初始化:现将文件内容列表加载到内存中
					ContentHolder contentHolder = ContentHelper.service.getContents(doc);
					//然后获取主文件
					QueryResult qr = ContentHelper.service.getContentsByRole(contentHolder, ContentRoleType.PRIMARY);
					if (qr != null && qr.hasMoreElements()) {
						primarycontent = (ContentItem) qr.nextElement();
					}
				}
			} catch (WTException e) {
				e.printStackTrace();
			} catch (PropertyVetoException e) {
				e.printStackTrace();
			}

			return primarycontent;
		}
		return null;
	}

}
