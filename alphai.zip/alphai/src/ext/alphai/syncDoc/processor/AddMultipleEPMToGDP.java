package ext.alphai.syncDoc.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.syncDoc.service.AIDrawingService;
import ext.alphai.syncDoc.util.CommonUtil;
import  ext.alphai.syncDoc.util.PropertiesUtil;
import org.apache.commons.lang3.StringUtils;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.method.MethodContext;
import wt.pom.WTConnection;
import wt.session.SessionHelper;
import wt.type.TypeDefinitionReference;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.wip.Workable;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddMultipleEPMToGDP extends DefaultObjectFormProcessor {


    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;
        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();
        String[] soids = new String[]{};
        List<String> ors = new ArrayList<>();


        for (String key: parameterMap.keySet()) {
            Object value = parameterMap.get(key);
//            String[] values = (String[]) value;
//            for (String a : values) {
//                System.out.println("key=" + key + "value=" + a);
//            }
            if("soid".equals(key)){
                soids = (String[]) value;
            }

//            if("werks".equals(key)){
//                werks = (String[]) value;
//            }
        }


        for (String oid : soids) {
            String or = getPartOR(oid);
            if(!StringUtils.isBlank(or)){
                ors.add(or);
            }
        }

        List<EPMDocument> drawings = new ArrayList<>();
        List<WTDocument> pdfDocs = new ArrayList<>();
        for (String or : ors) {
            WTObject object = oid2Object(or);
            if(CommonUtil.isCheckOut((Workable) object)){
                continue;
            }
            if(object!=null){
                if(object instanceof EPMDocument){
                    EPMDocument drawing = (EPMDocument)object;
                    String cadName = drawing.getCADName();
                    drawings.add(drawing);
                }else if(object instanceof WTDocument){
                    WTDocument doc = (WTDocument) object;
                    // 判断是否为文档的子类型 PDF图纸
                    String[] split = PropertiesUtil.getValueByKey("draw.child.doc").split(",");
                    List<String> childKeys = Arrays.asList(split);
//                    for (String childKey : childKeys) {
//                        System.out.println("合法文档子类型为:"+childKey);
//                    }
                    TypeDefinitionReference ref = (doc).getTypeDefinitionReference();
                    @SuppressWarnings("deprecation")
                    TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities.getTypeDefinition(ref);
                    WTTypeDefinition definition = (WTTypeDefinition) PersistenceHelper.manager.refresh(view.getObjectID());
                    String typeDisplayName = definition.getDisplayNameKey(); // 类型的key
//                        System.out.println("当前文档类型为："+typeDisplayName);
                        if(childKeys.contains(typeDisplayName)){
                            pdfDocs.add(doc);
                        }
                }
            }
        }

        int i = AIDrawingService.insertDocumentToAIDrawing(drawings, pdfDocs);

        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(),null,null,new String[]{"已将文档添加到待发送列表"}));
        return result;
    }

    /**
     *
     * 在返回的String soid中得到部件OR
     * @param soid
     * @return
     */
    public static String getPartOR(String soid) {
        String pattern =null;
        if(soid.contains("VR:wt.doc.WTDocument:")){
            pattern = "VR:wt.doc.WTDocument:\\d+"; // 正则表达式匹配模式
        } else if(soid.contains("OR:wt.doc.WTDocument:")){
            pattern = "OR:wt.doc.WTDocument:\\d+"; // 正则表达式匹配模式
        } else if (soid.contains("VR:wt.epm.EPMDocument:")) {
            pattern = "VR:wt.epm.EPMDocument:\\d+"; // 正则表达式匹配模式
        } else if(soid.contains("OR:wt.epm.EPMDocument:")){
            pattern = "OR:wt.epm.EPMDocument:\\d+"; // 正则表达式匹配模式
        } else {
            return "";
        }
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(soid);
        if (m.find()) {
            String partVROrOR = m.group(0);
            if(partVROrOR.contains("OR")){
                return partVROrOR;
            } else if (partVROrOR.contains("VR")){

                if(partVROrOR.contains("WTDocument")){

                    return getORbyVR(partVROrOR, "WTDOCUMENT");
                } else if (partVROrOR.contains("EPMDocument")) {
                    return getORbyVR(partVROrOR, "EPMDOCUMENT");
                } else {
                    return "";
                }
            }
        }
        return "";
    }


    /**
     * 根据部件的EPM WTDOC查找到部件的OR
     *
     */
    public static String getORbyVR(String VR, String table) {
        String sql = "";
        VR = VR.split(":")[2];

        if("WTDOCUMENT".equals(table)){
            sql = "SELECT IDA2A2 FROM WTDOCUMENT WHERE BRANCHIDITERATIONINFO = ?";
        } else if("EPMDOCUMENT".equals(table)){
            sql = "SELECT IDA2A2 FROM EPMDOCUMENT WHERE BRANCHIDITERATIONINFO = ?";
        } else {
            return "";
        }


        String OR = "";
        try {
            ResultSet resultSet = excuteSelect(sql,VR);
            while (resultSet.next()) {
                if("WTDOCUMENT".equals(table)){
                    OR = "OR:wt.doc.WTDocument:" + resultSet.getString("IDA2A2");
                } else if("EPMDOCUMENT".equals(table)){
                    OR = "OR:wt.epm.EPMDocument:" + resultSet.getString("IDA2A2");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return OR;
    }
    /**
     * 执行查询的SQL语句并返回结果 SQL示例：SELECT WTPARTNUMBER FROM WTPARTMASTER WHERE
     * WTPARTNUMBER LIKE ?
     *
     * @param sql    SQL语句
     * @param params 参数集
     * @return ResultSet 返回结果集
     */
    public static ResultSet excuteSelect(String sql, String... params) {
        try {
            WTConnection connection = getWTConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                statement.setString(i + 1, params[i]);
            }

            // 输出当前执行查询操作的SQL语句
            String fullSql = sql;
            for (String param : params) {
                param = param.length() > 250 ? "此属性太长，不显示内容" : param;
                fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
            }
            System.out.println("--------当前执行查询操作的SQL语句为--------");
            System.out.println(fullSql);

            ResultSet resultSet = statement.executeQuery();
            return resultSet;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 连接Windchill数据库来运行自定义sql
     *
     * @return WTConnection 数据库连接
     * @throws Exception
     */
    public static WTConnection getWTConnection() {
        WTConnection wtconnection = null;
        try {
            MethodContext methodcontext = MethodContext.getContext();
            wtconnection = (WTConnection) methodcontext.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtconnection;
    }

    public static WTObject oid2Object(String oid) {

        try {
            ReferenceFactory factory = new ReferenceFactory();
            return (WTObject) factory.getReference(oid).getObject();
        } catch (WTRuntimeException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return null;
    }
}
