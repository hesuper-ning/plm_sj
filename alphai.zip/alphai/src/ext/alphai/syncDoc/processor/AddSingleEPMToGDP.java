package ext.alphai.syncDoc.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.syncDoc.service.AIDrawingService;
import ext.alphai.syncDoc.util.CommonUtil;
import ext.alphai.syncDoc.util.PropertiesUtil;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.PersistenceHelper;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.type.TypeDefinitionReference;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AddSingleEPMToGDP extends DefaultObjectFormProcessor {
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        List<EPMDocument> epms = new ArrayList<>();
        List<WTDocument> docs = new ArrayList<>();
        try{
            if(content instanceof EPMDocument){
                EPMDocument epm = (EPMDocument) content;
                if (CommonUtil.isCheckOut(epm)) {
                    throw new WTException("请检入后再操作");
                }

                epms.add(epm);

            } else if(content instanceof WTDocument){
                WTDocument doc = (WTDocument) content;
                if (CommonUtil.isCheckOut(doc)) {
                    throw new WTException("请检入后再操作");
                }

                // 判断是否为文档的子类型 PDF图纸
                String[] split = PropertiesUtil.getValueByKey("draw.child.doc").split(",");
                List<String> childKeys = Arrays.asList(split);
//                for (String childKey : childKeys) {
//                    System.out.println("合法文档子类型为:"+childKey);
//                }
                TypeDefinitionReference ref = (doc).getTypeDefinitionReference();
                @SuppressWarnings("deprecation")
                TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities.getTypeDefinition(ref);
                WTTypeDefinition definition = (WTTypeDefinition) PersistenceHelper.manager.refresh(view.getObjectID());
                String typeDisplayName = definition.getDisplayNameKey(); // 类型的key
//                System.out.println("当前文档类型为："+typeDisplayName);
                if(childKeys.contains(typeDisplayName)){
                    docs.add(doc);
                }else {
                    throw new WTException("当前文档类型不支持发送图纸");
                }
            }
            int i = AIDrawingService.insertDocumentToAIDrawing(epms, docs);


        }catch (Exception e) {
            FormResult result = new FormResult(FormProcessingStatus.FAILURE);
            result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(),null,null,new String[]{e.getMessage()}));
            return result;
        }
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS,SessionHelper.getLocale(),null,null,new String[]{"已将文档添加到待发送列表"}));
        return result;
    }
}
