package ext.alphai.syncDoc;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;


@RBUUID("ext.alphai.syncDoc.CustomActionsRB")
public class CustomActionsRB extends WTListResourceBundle {

    @RBEntry("sync to GDP")
    public static final String PRIVATE_CONSTANT_1 = "GDP.syncToGDP.description";
    @RBEntry("sync to GDP")
    public static final String PRIVATE_CONSTANT_2 = "GDP.syncToGDP.tooltip";

    @RBEntry("paste_24.png")
    public static final String PRIVATE_CONSTANT_3 = "GDP.syncToGDP.icon";


    @RBEntry("sync multiple to GDP")
    public static final String PRIVATE_CONSTANT_4 = "GDP.syncMultipleToGDP.description";
    @RBEntry("sync multiple to GDP")
    public static final String PRIVATE_CONSTANT_5 = "GDP.syncMultipleToGDP.tooltip";

    @RBEntry("paste_24.png")
    public static final String PRIVATE_CONSTANT_6 = "GDP.syncMultipleToGDP.icon";



     @RBEntry("GDP Manage")
    public static final String PRIVATE_CONSTANT_7 = "navigation.GDPManage.description";

    @RBEntry("GDP Manage")
    public static final String PRIVATE_CONSTANT_8 = "navigation.GDPManage.tooltip";

    @RBEntry("GDP.svg")
    public static final String PRIVATE_CONSTANT_9 = "navigation.GDPManage.icon";


     @RBEntry("GDP Main")
    public static final String PRIVATE_CONSTANT_10 = "GDPManage.GDPMain.description";

    @RBEntry("GDP Main")
    public static final String PRIVATE_CONSTANT_11 = "GDPManage.GDPMain.tooltip";

    @RBEntry("GDP.svg")
    public static final String PRIVATE_CONSTANT_12 = "GDPManage.GDPMain.icon";


    @RBEntry("paste QR")
    public static final String PRIVATE_CONSTANT_13 = "GDP.pasteQR.description";
    @RBEntry("paste QR")
    public static final String PRIVATE_CONSTANT_14 = "GDP.pasteQR.tooltip";

}
