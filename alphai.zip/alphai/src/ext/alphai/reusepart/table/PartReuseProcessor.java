package ext.alphai.reusepart.table;

import com.ptc.core.components.forms.DefaultObjectFormProcessor;

/**
 * 物料重用等级展示列表table
 */
public class PartReuseProcessor extends DefaultObjectFormProcessor {
}
