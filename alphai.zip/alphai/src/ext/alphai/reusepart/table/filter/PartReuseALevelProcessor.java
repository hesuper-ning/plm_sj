package ext.alphai.reusepart.table.filter;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.alphai.reusepart.table.PartReuseTable;
import wt.util.WTException;

import java.util.List;

public class PartReuseALevelProcessor extends DefaultObjectFormProcessor {

    @Override
    public FormResult doOperation(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList) throws WTException {
        PartReuseTable.currentPhase = PartReuseTable.LIST_A;
        return super.doOperation(paramNmCommandBean, paramList);
    }
}
