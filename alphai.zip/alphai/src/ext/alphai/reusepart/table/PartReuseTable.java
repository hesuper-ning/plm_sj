package ext.alphai.reusepart.table;

import com.ptc.core.htmlcomp.components.AbstractConfigurableTableBuilder;
import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.jca.mvc.components.JcaTableConfig;
import com.ptc.mvc.components.*;
import ext.alphai.reusepart.Config;
import ext.alphai.reusepart.CustomRB;
import ext.alphai.reusepart.server.PartReuseService;
import ext.alphai.reusepart.util.CommonUtil;
import ext.alphai.reusepart.util.IBAUtil;
import ext.alphai.reusepart.util.PartUtil;
import ext.alphai.sap.util.PersistenceUtil;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;
import wt.util.WTMessage;

import java.sql.ResultSet;
import java.util.*;

/**
 * 部件重用等级二级菜单表格
 */
@ComponentBuilder("ext.alphai.reusepart.partReuseTable")
public class PartReuseTable extends AbstractConfigurableTableBuilder {

    // 查看全部
    public static final int LIST_ALL = 0;
    // 查看A的
    public static final int LIST_A = 1;
    // 查看B的
    public static final int LIST_B = 2;
    // 查看C的(默认)
    public static final int LIST_C = 3;

    public static int currentPhase = 3;

    static final String RESOURCE = CustomRB.class.getName();
    private static final int PAGE_SIZE = 2000; // 每一页的数据量


    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
//        String sql = "SELECT DISTINCT IDA3A4 FROM STRINGVALUE SV WHERE SV.IDA3A4 IN(SELECT DISTINCT IDA3A4 FROM STRINGVALUE SV2 WHERE SV2.IDA3A6 = (SELECT SD2.IDA2A2 FROM STRINGDEFINITION SD2 WHERE SD2.NAME = ?)and VALUE2 = ?)" ;

        String partName = (String) componentParams.getParameter("partName");
        String partNumber = (String) componentParams.getParameter("partNumber");

        Integer pageNumber = (Integer) componentParams.getParameter("pageNumber");
        System.out.println("选择的是第几页："+pageNumber);
        System.out.println("查询条件： partName："+partName+" partNumber: "+ partNumber);

//        List<WTPart> result = new ArrayList<>();

        List<WTPartMaster> resultSet = null;
        switch (currentPhase){
            case LIST_A:
                resultSet = PartReuseService.getPartLevelBuyParam(pageNumber,PAGE_SIZE,partName, partNumber, LIST_A);
                break;
            case LIST_B:
                resultSet = PartReuseService.getPartLevelBuyParam(pageNumber,PAGE_SIZE,partName, partNumber, LIST_B);
                break;
            case LIST_C:
                resultSet = PartReuseService.getPartLevelBuyParam(pageNumber,PAGE_SIZE,partName, partNumber, LIST_C);
                break;
            case LIST_ALL:
                resultSet = PartReuseService.getPartLevelBuyParam(pageNumber,PAGE_SIZE,partName, partNumber, LIST_ALL);
                break;
        }


//        currentPhase = 3;
        return resultSet;
    }



//    private WTPart phaseFilter(WTPart part){
//        // todo 如果后期任务状态成为一个IBA属性则在属性中拿取
//        // 如果选择的是all则不移除任何一个对象
//        if(LIST_ALL == currentPhase){
//            return null;
//        }
//        IBAUtil ibaUtil = null;
//        try {
//            ibaUtil = new IBAUtil(part);
//        } catch (WTException e) {
//            e.printStackTrace();
//        }
//        String reuseLevel = ibaUtil.getIBAValue(Config.AI_reusingLevel);
//        switch (currentPhase){
//            case LIST_A:
//                if(!"A".equals(reuseLevel)){
//                    return part;
//                }
//                break;
//            case LIST_B:
//                if(!"B".equals(reuseLevel)){
//                    return part;
//                }
//            case LIST_C:
//                if(!"C".equals(reuseLevel)){
//                    return part;
//                }
//                break;
//        }
//        return null;
//    }






    @Override
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
        final ComponentConfigFactory factory = getComponentConfigFactory();
        final JcaTableConfig table; {
            table = (JcaTableConfig)factory.newTableConfig();
            table.setComponentMode(ComponentMode.VIEW);
            table.setAutoGenerateRowId(true);
            table.setType(WTPart.class.getName());
            table.setLabel(WTMessage.getLocalizedMessage(RESOURCE,
                    CustomRB.Part_Reuse_Level, null));
            // 条件过滤model
            table.setActionModel("reusePartLevel");
            table.setSelectable(true);
            table.setShowCount(true);
//            table.setShowCustomViewLink(false);
            table.setConfigurable(true);
            // 添加物料编号列并生成链接
//            ColumnConfig partThumbnail = factory.newColumnConfig("partThumbnail", true);
//            partThumbnail.setLabel("部件缩略图");
//            partThumbnail.setDataUtilityId("PartReuseTableUtility");
//            partThumbnail.setRenderAllStates(true);
//            table.addComponent(partThumbnail);

            ColumnConfig partNumber = factory.newColumnConfig("partNumber", true);
            partNumber.setLabel("部件编号");
            partNumber.setDataUtilityId("PartReuseTableUtility");
            table.addComponent(partNumber);

            ColumnConfig partName = factory.newColumnConfig("partName", true);
            partName.setLabel("部件名称");
            partName.setDataUtilityId("PartReuseTableUtility");
            table.addComponent(partName);

            ColumnConfig partVersion = factory.newColumnConfig("partVersion", true);
            partVersion.setLabel("最新大小版本");
            partVersion.setDataUtilityId("PartReuseTableUtility");
            table.addComponent(partVersion);

            ColumnConfig reuseLevel = factory.newColumnConfig("reuseLevel", true);
            reuseLevel.setLabel("重用等级");
            reuseLevel.setDataUtilityId("PartReuseTableUtility");
            table.addComponent(reuseLevel);

            ColumnConfig lifecycle = factory.newColumnConfig("lifecycle", true);
            lifecycle.setLabel("生命周期状态");
            lifecycle.setDataUtilityId("PartReuseTableUtility");
            table.addComponent(lifecycle);

            ColumnConfig updateTime = factory.newColumnConfig("updateTime", true);
            updateTime.setLabel("最后修改时间");
            updateTime.setDataUtilityId("PartReuseTableUtility");
            table.addComponent(updateTime);

            ColumnConfig updateUser = factory.newColumnConfig("updateUser", true);
            updateUser.setLabel("最后修改人");
            updateUser.setDataUtilityId("PartReuseTableUtility");
            table.addComponent(updateUser);


        }
        return table;
    }





    @Override
    public ConfigurableTable buildConfigurableTable(String s) throws WTException {
        return null;
    }


    ColumnConfig getColumn(final String id, final ComponentConfigFactory factory) {
        final ColumnConfig column = factory.newColumnConfig(id, true);
        column.setSortable(false);
        return column;
    }
}
