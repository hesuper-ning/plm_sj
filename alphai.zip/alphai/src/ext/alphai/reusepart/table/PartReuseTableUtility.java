package ext.alphai.reusepart.table;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import ext.alphai.reusepart.Config;
import ext.alphai.reusepart.util.IBAUtil;
import ext.alphai.reusepart.util.PartUtil;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * 部件重用等级二级菜单dateutility
 */
public class PartReuseTableUtility extends AbstractDataUtility {
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

    public PartReuseTableUtility() {
    }

    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        if(o instanceof WTPartMaster){
            WTPartMaster partMaster = (WTPartMaster) o;
            String number = partMaster.getNumber();
            WTPart part = PartUtil.getWTPartByNumber(number);
            switch (s) {
                case "partThumbnail":
                    UrlDisplayComponent partThumbnail = PartUtil.getPartThumbnail(part);
                    if(partThumbnail!=null){
                        return partThumbnail;
                    }
                    return null;
                case "partNumber":
                    return PartUtil.getPartUrlByPartNumber(part);
                case "partName":
                    return partMaster.getName();
                case "partVersion":
                    String bigVersion = part.getVersionIdentifier().getValue();
                    String smallVersion = part.getIterationIdentifier().getValue();
                    return bigVersion+"."+smallVersion;
                case "reuseLevel":
                    IBAUtil ibaUtil = new IBAUtil(partMaster);
                    return ibaUtil.getIBAValue(Config.AI_reusingLevel);
                case "lifecycle":
                    return part.getLifeCycleState().getDisplay();
                case "updateTime":
                    Timestamp timestamp = partMaster.getModifyTimestamp();
                    return dateFormat.format(timestamp);
                case "updateUser":
                    WTPrincipalReference modifier = part.getModifier();
                    WTPrincipal p = modifier.getPrincipal();
                    WTUser user = (WTUser) p;
                    return user.getFullName();
            }
        }
        return null;
    }
}
