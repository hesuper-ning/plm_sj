package ext.alphai.reusepart;

import ext.alphai.reusepart.util.CommonUtil;
import ext.alphai.reusepart.util.PersistenceUtil;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.pom.WTConnection;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTRuntimeException;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * 
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * 
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * 
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * 
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 * 
 * @author dz
 *
 */
public class RemoteTest38 implements RemoteAccess, Serializable {

	private static final long serialVersionUID = 1L;

	private static String CLASS_PATH;
	static {
		WTProperties wtProperties = null;
		try {
			wtProperties = WTProperties.getLocalProperties();
		} catch (IOException e) {

		}
		CLASS_PATH =wtProperties.getProperty("wt.codebase.location") + "\\"+"ext\\alphai\\sap\\saplog";
	}

	public static void main(String[] args) throws WTRuntimeException, WTException {

		String str = (String) invoke("process", RemoteTest38.class.getName(), null, new Class[]{}, new Object[]{});
	}

	public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("JieCang@002");
		try {
			return rms.invoke(methodName, className, instance, cla, obj);
		} catch (RemoteException e) {
			e.printStackTrace();
			return null;
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String process() {
		try {
			updateREUSEPARTMASTER();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}



	/**
	 * 键集分页优化版（带游标控制）
	 */
	public static void updateREUSEPARTMASTER() throws SQLException {
		final int PAGE_SIZE = 2000;
		final int BATCH_COMMIT_SIZE = 500; // 每500条提交一次

		Long lastId = null;
		int totalProcessed = 0;
		long startTime = System.currentTimeMillis();

		try {
			do {
				// 1. 分页获取数据
				List<WTPartMaster> pageData = getPageWTPartMaster(PAGE_SIZE, lastId);

				// 2. 分批处理数据
				if (!pageData.isEmpty()) {
					int batchCount = (int) Math.ceil((double)pageData.size() / BATCH_COMMIT_SIZE);

					for (int i = 0; i < batchCount; i++) {
						int fromIndex = i * BATCH_COMMIT_SIZE;
						int toIndex = Math.min((i+1)*BATCH_COMMIT_SIZE, pageData.size());
						List<WTPartMaster> subList = pageData.subList(fromIndex, toIndex);

						updatePartReuseTable(subList);
						totalProcessed += subList.size();
					}
				}

				// 3. 更新分页锚点
				lastId = !pageData.isEmpty() ?
						pageData.get(pageData.size()-1).getPersistInfo().getObjectIdentifier().getId() : null;
				System.out.println("处理完第2000条master");
			} while (lastId != null);

		} finally {
			System.out.printf("处理完成！总记录数：%d, 耗时：%.2f秒%n",
					totalProcessed, (System.currentTimeMillis()-startTime)/1000.0);
		}
	}



	/**
	 * 高效分页查询（Oracle 19键集分页）
	 */
	public static List<WTPartMaster> getPageWTPartMaster(int pageSize, Long lastId)
			throws SQLException {

		List<WTPartMaster> masters = new ArrayList<>();
		String sql = buildPaginationQuery(lastId);
		WTConnection conn = CommonUtil.getWTConnection();
		try (PreparedStatement ps = conn.prepareStatement(sql)) {

			// 绑定参数（动态处理分页锚点）
			int paramIdx = 1;
			if (lastId != null) {
				ps.setLong(paramIdx++, lastId);
			}
			ps.setInt(paramIdx, pageSize);

			// 执行查询并解析结果
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					WTPartMaster master = parseResultSet(rs);
					if (master != null) {
						masters.add(master);
					}
				}
			}
		} // 自动关闭资源（Connection/PreparedStatement/ResultSet）

		return masters;
	}
	/**
	 * 解析ResultSet到对象
	 */
	private static WTPartMaster parseResultSet(ResultSet rs) throws SQLException {
		String ida2a2 = rs.getString("IDA2A2");
		String className = rs.getString("CLASSNAMEA2A2");
		Object obj = PersistenceUtil.oid2Object("OR:" + className + ":" + ida2a2);
		return (obj instanceof WTPartMaster) ? (WTPartMaster) obj : null;
	}
	/**
	 * 构建分页SQL（利用索引提高性能）
	 */
	private static String buildPaginationQuery(Long lastId) {
		StringBuilder sb = new StringBuilder()
				.append("SELECT * FROM (")
				.append("  SELECT /*+ INDEX(w IDX_WTPARTMASTER_IDA2A2) */ ")
				.append("    w.IDA2A2, w.CLASSNAMEA2A2 ")
				.append("  FROM WTPARTMASTER w ");

		if (lastId != null) {
			sb.append("  WHERE w.IDA2A2 > ? ");
		}

		sb.append("  ORDER BY w.IDA2A2 ASC ")
				.append(") WHERE ROWNUM <= ?");

		return sb.toString();
	}



	/**
	 * 安全批量更新方法（带增强型游标控制）
	 */
	public static void updatePartReuseTable(List<WTPartMaster> masters) {
		final String MERGE_SQL =
				"MERGE INTO REUSEPARTMASTER r " +
						"USING (SELECT ? MASTERIDA2A2, ? REUSELEVEL FROM DUAL) src " +
						"ON (r.MASTERIDA2A2 = src.MASTERIDA2A2) " +
						"WHEN MATCHED THEN UPDATE SET REUSELEVEL = src.REUSELEVEL " +
						"WHEN NOT MATCHED THEN INSERT (MASTERIDA2A2, REUSELEVEL) " +
						"VALUES (src.MASTERIDA2A2, src.REUSELEVEL)";

		WTConnection wtConn = null;
		Connection conn = null;
		boolean originalAutoCommit = true;

		try {
			// 安全获取连接（带空指针保护）
			wtConn = CommonUtil.getWTConnection();
			if (wtConn == null) {
				throw new RuntimeException("无法获取数据库连接");
			}

			conn = wtConn.getConnection();
			if (conn == null) {
				throw new RuntimeException("底层连接不可用");
			}

			// 保存原始自动提交状态
			originalAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);

			try (PreparedStatement ps = conn.prepareStatement(MERGE_SQL)) {
				int batchCounter = 0;

				for (WTPartMaster master : masters) {
					// 参数绑定（带空值检查）
					long ida2a2 = master.getPersistInfo().getObjectIdentifier().getId();
					String reuseLevel = getPartReuseLevel(master);

					ps.setLong(1, ida2a2);
					ps.setString(2, reuseLevel != null ? reuseLevel : "DEFAULT");
					ps.addBatch();

					// 批量提交控制
					if (++batchCounter % 500 == 0) {
						executeBatchWithRetry(ps, conn);
					}
				}

				// 提交剩余批次
				if (batchCounter % 500 != 0) {
					executeBatchWithRetry(ps, conn);
				}
			}

		} catch (SQLException | RuntimeException e) {
			// 增强型回滚机制
			safeRollback(conn);
			throw new RuntimeException("批量更新失败: " + e.getMessage(), e);
		} finally {
			// 安全恢复自动提交状态
			safeResetAutoCommit(conn, originalAutoCommit);
		}
	}

	/**
	 * 带重试机制的批处理执行
	 */
	private static void executeBatchWithRetry(PreparedStatement ps, Connection conn) throws SQLException {
		try {
			ps.executeBatch();
			conn.commit();
			ps.clearBatch();
		} catch (SQLException e) {
			if (isConnectionValid(conn)) {
				conn.rollback();
			}
			throw e;
		}
	}

	/**
	 * 安全回滚方法
	 */
	private static void safeRollback(Connection conn) {
		try {
			if (conn != null && !conn.isClosed() && !conn.getAutoCommit()) {
				conn.rollback();
			}
		} catch (SQLException ex) {
			System.err.println("回滚失败: " + ex.getMessage());
		}
	}

	/**
	 * 安全重置自动提交状态
	 */
	private static void safeResetAutoCommit(Connection conn, boolean originalAutoCommit) {
		try {
			if (conn != null && !conn.isClosed()) {
				conn.setAutoCommit(originalAutoCommit);
			}
		} catch (SQLException e) {
			System.err.println("恢复自动提交失败: " + e.getMessage());
		}
	}

	/**
	 * 连接有效性检查
	 */
	private static boolean isConnectionValid(Connection conn) {
		try {
			return conn != null && !conn.isClosed() && conn.isValid(5);
		} catch (SQLException e) {
			return false;
		}
	}


	/**
	 * 获取部件重用等级
	 * @param master
	 * @return
	 */
	public static String getPartReuseLevel(WTPartMaster master){
		List<WTPart> parentParts = getParentParts(master);
		if(parentParts.size() > Config.getALevel()){
			// A
			return Config.A_Level;

		} else if (Config.getALevel() >= parentParts.size() && parentParts.size() > Config.getBLevel()) {
			// B
			return Config.B_Level;
		} else if (parentParts.size() <= Config.getBLevel()) {
			// C
			return Config.C_Level;
		}
		return null;
	}


	/**
	 * 获取所有父部件
	 * @param master
	 * @return
	 */
	public static List<WTPart> getParentParts(WTPartMaster master) {
		List<WTPart> list = new ArrayList<WTPart>();
		try {
			if (master != null) {
				//查到的是什么
				QueryResult qr = WTPartHelper.service.getUsedByWTParts(master);
				while (qr.hasMoreElements()) {
					WTPart parentPart = (WTPart) qr.nextElement();
					list.add(parentPart);
				}

			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}

}
