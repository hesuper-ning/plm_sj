package ext.alphai.reusepart.util;

import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import ext.alphai.reusepart.bean.BomResultBean;
import org.apache.commons.lang.StringUtils;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.query.QuerySpec;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.WorkInProgressHelper;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ReusingUtil {

    public static void updateReusingLevel() {
        WTPart result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr = cfg.process(qr);
            System.out.println("查询的个数是：" + qr.size());
            while (qr.hasMoreElements()) {
                WTPart part = (WTPart) qr.nextElement();
                if (!WorkInProgressHelper.isCheckedOut(part)) {
                    WorkInProgressHelper.service.checkout(part, WorkInProgressHelper.service.getCheckoutFolder(), null);
                    part = (WTPart) WorkInProgressHelper.service.workingCopyOf(part);
                }
                System.out.println(part.getNumber() + "当前物料的父级数量是：" + getParentParts(part).size());
                if (getParentParts(part).size() > 10) {
                    setIBA(part, "reusingLevel", "B");
                } else {
                    setIBA(part, "reusingLevel", "A");
                }
                if (WorkInProgressHelper.isCheckedOut(part)) {
                    WorkInProgressHelper.service.checkin(part, null);
                }
                System.out.println("处理完成");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取部件所有父部件
     * @param part
     * @return
     */
    public static List<WTPart> getParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            if (part != null) {
                //查到的是什么
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());
                while (qr.hasMoreElements()) {
                    WTPart childPart = (WTPart) qr.nextElement();
                    list.add(childPart);
                }

            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void setIBA(Persistable persistable, String ibaName, String value) throws WTException {

        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        normalizedObject.set(ibaName, value);
        persistable = normalizedObject.apply();
        PersistenceHelper.manager.modify(persistable);
    }

    public static String getIBA(Persistable persistable, String ibaName) throws WTException {

        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        Object result = normalizedObject.get(ibaName);
        return result == null ? null : result.toString();
    }

    public static void CreateReusingLevelBOM() {
        WTPart result = null;
        QueryResult qr = null;
        ArrayList<BomResultBean> A_Beans = new ArrayList<>();
        ArrayList<BomResultBean> B_Beans = new ArrayList<>();
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr = cfg.process(qr);
            System.out.println("查询的个数是：" + qr.size());
            while (qr.hasMoreElements()) {
                WTPart part = (WTPart) qr.nextElement();
                BomResultBean bomResultBean = createBomResultBean(part);
                System.out.println(part.getNumber() + "当前物料的父级数量是：" + getParentParts(part).size());
                if (StringUtils.equals(getIBA(part, "reusingLevel"),"A")) {
                    A_Beans.add(bomResultBean);
                } else {
                    B_Beans.add(bomResultBean);
                }
                if (WorkInProgressHelper.isCheckedOut(part)) {
                    WorkInProgressHelper.service.checkin(part, null);
                }
                System.out.println("处理完成");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static BomResultBean createBomResultBean(WTPart part) {
        BomResultBean bean = new BomResultBean();
        Timestamp timestamp = part.getModifyTimestamp();
        String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(timestamp);
        bean.setEditTime(format);
        bean.setName(part.getName());
        bean.setNumber(part.getNumber());
        bean.setModifiedMan(part.getModifierFullName());
        bean.setState(part.getLifeCycleState().getLocalizedMessage(Locale.CHINA));
        bean.setVersion(part.getVersionIdentifier().getValue() + "." + part.getIterationIdentifier().getValue());

        return bean;
    }
}
