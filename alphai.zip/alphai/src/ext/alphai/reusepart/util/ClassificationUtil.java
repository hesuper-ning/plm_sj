package ext.alphai.reusepart.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.google.common.collect.Maps;
import com.ptc.cat.entity.client.constraint.impl.DiscreteSetConstraint;
import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.dynamicEnum.EnumerationEntryInfo;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.PropertyValueReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.*;
import com.ptc.core.meta.common.*;
import com.ptc.core.meta.common.impl.TypeIdentifierUtilityHelper;
import com.ptc.core.meta.container.common.AttributeTypeSummary;
import com.ptc.windchill.csm.client.helpers.CSMTypeDefHelper;
import com.ptc.windchill.csm.common.CsmConstants;

import org.apache.commons.lang3.StringUtils;
import wt.facade.classification.ClassificationFacade;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.inf.container.WTContainerException;
import wt.meta.LocalizedValues;
import wt.method.RemoteAccess;
import wt.part.WTPart;
import wt.pom.WTConnection;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.TypedUtility;
import wt.util.WTException;

public class ClassificationUtil implements RemoteAccess {

	/**
	 * 获取部件的分类属性的枚举值属性值的显示名称（在之前调用中出现了一些问题，但是其他程序调用是没有问题的）
	 * 
	 * @param part    需要获取属性的部件
	 * @param ibaName 分类属性值的内部名称
	 * @return 显示名称
	 */
	public static String getEnumDisplay(WTPart part, String ibaName) {
		String displayName = "";
		try {
			Locale loc = SessionHelper.manager.getLocale();
			PersistableAdapter adapter = new PersistableAdapter(part, null, loc,
					OperationIdentifier.newOperationIdentifier(OperationIdentifierConstants.VIEW));
			SessionHelper.manager.setAdministrator();
			// HHT_Classification是分类属性映射到部件上面的内部名称
			adapter.load(new String[] { "HHT_Classification", ibaName });
			Object obj = (String) adapter.get(ibaName);

			AttributeTypeSummary ats_csm = adapter.getAttributeDescriptor(ibaName);
			DataSet lvs_csm = ats_csm.getLegalValueSet();
			if (lvs_csm != null) {
				if (lvs_csm instanceof EnumeratedSet) {
					EnumerationEntryIdentifier eei = ((EnumeratedSet) lvs_csm).getElementByKey(obj.toString());
					LWCEnumerationEntryValuesFactory eevf = new LWCEnumerationEntryValuesFactory();
					LocalizedValues valueLocale = eevf.get(eei, loc);
					displayName = valueLocale.getDisplay();
				}
			} else {
				System.out.println("lvs_csm is null");
				return displayName;
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return displayName;
	}

	/**
	 * 根据查询数据库从的内部名称获取到部件对应枚举值的显示名称 Manufacturing->ZeroStickers->零贴
	 * 
	 * @param part     数据源部件
	 * @param internal 分类属性
	 * @return 显示名称
	 */
	public static String getDisplayByInternal(WTPart part, String internal) {
		String display = "";
		try {
			Locale loc = SessionHelper.manager.getLocale();
			PersistableAdapter adapter = new PersistableAdapter(part, null, loc,
					OperationIdentifier.newOperationIdentifier(OperationIdentifierConstants.VIEW));
			SessionHelper.manager.setAdministrator();
			adapter.load(new String[] { "HHT_Classification", internal });
			Object obj = (String) adapter.get(internal);
			display = getDisplayByInternal(obj.toString());
		} catch (WTException e) {
			e.printStackTrace();
		}
		return display;
	}

	/**
	 * 根据查询数据库从全局枚举的内部名称获取显示名称 ZeroStickers->零贴
	 * 
	 * @param internal 内部名称
	 * @return display 显示名称
	 */
	public static String getDisplayByInternal(String internal) {
		String display = internal;
		String sql = "SELECT VALUE FROM LWCLOCALIZABLEPROPERTYVALUE WHERE IDA3B4 IN ( SELECT IDA2A2 FROM LWCENUMERATIONENTRY WHERE NAME= ? )";
		try {
			ResultSet resultSet = CommonUtil.excuteSelect(sql, internal.toString());
			while (resultSet.next()) {
				display = resultSet.getString("VALUE");
			}
			resultSet.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return display;
	}

	/**
	 * 根据查询数据库从全局枚举的内部名称获取显示名称 ZeroStickers->零贴
	 * 
	 * @param internal 内部名称
	 * @return display 显示名称
	 */
	public static String getDisplayByInternal(String internal, WTConnection connection) {
		System.out.println("参数2:" + internal);

		String display = "";
		String sql = "SELECT VALUE FROM LWCLOCALIZABLEPROPERTYVALUE WHERE IDA3B4 IN ( SELECT IDA2A2 FROM LWCENUMERATIONENTRY WHERE NAME = '"
				+ internal + "' )";

		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				display = resultSet.getString("VALUE");
			}
			resultSet.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return display;
	}

	/**
	 * 根据分类的内部名称获取分类的显示名称
	 * 
	 * @param classificationCode 分类内部名称
	 * @return 分类外部名称
	 */
	public static String getClassificationdDisPlayName(String classificationCode) {
		String sql = "SELECT VALUE FROM LWCLOCALIZABLEPROPERTYVALUE WHERE IDA3B4 IN ( SELECT IDA2A2 FROM LWCStructEnumAttTemplate WHERE NAME= ? )";
		String classificationName = "";
		try {
			ResultSet resultSet = CommonUtil.excuteSelect(sql, classificationCode);
			if (resultSet.next()) {
				classificationName = resultSet.getString("VALUE");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return classificationName;
	}

	/**
	 * 根据分类节点内部名称获取完整分类路径
	 * 
	 * @param internalName 内部名称
	 * @return 分类完整路径
	 */
	public static String getFullPathByInternal(String internalName) {
		StringBuilder result = new StringBuilder();
		Class<?> clazz = ClassificationFacade.class;
		try {
			// 通过Constructor破坏单例模式来完成多层级的获取
			Constructor<?> clazzDeclaredConstructor = clazz.getDeclaredConstructor(null);
			clazzDeclaredConstructor.setAccessible(true);

			while (internalName != null) {
				ClassificationFacade facadeInstance = (ClassificationFacade) clazzDeclaredConstructor.newInstance();
				Object classificationNodeInfo = facadeInstance.getClassificationNodeInfo(internalName,
						CsmConstants.NAMESPACE);
				EnumerationEntryInfo entryInfo = (EnumerationEntryInfo) classificationNodeInfo;
				Set<String> set = entryInfo.getNonLocalizablePropertyNames();

				// 添加显示名称在最前端
				String displayName = entryInfo.getLocalizablePropertyValue(EnumerationEntryInfo.DISPLAY_NAME,
						Locale.CHINA);
				result.insert(0, "\\" + displayName);

				// 判断是否存在父节点，不存在则跳出循环
				if (set.contains("parent")) {
					String parentName = (String) entryInfo.getNonLocalizablePropertyValue(EnumerationEntryInfo.PARENT);
					internalName = parentName;
				} else {
					internalName = null;
				}
			}
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	/**
	 * 根据部件和部件绑定的分类属性的全局字符属性来得到分类的内部名称
	 * 
	 * @param part           部件
	 * @param bind_attr_name 部件绑定的属性
	 * @return 部件分类属性的内部名称
	 */
	public static String getClassificationInternal(WTPart part, String bind_attr_name) {
		String bind_attr_value = null;
		try {
			if (bind_attr_name != null) {
				PersistableAdapter obj = new PersistableAdapter(part, null, Locale.US, null);
				obj.load(bind_attr_name);
				bind_attr_value = (String) obj.get(bind_attr_name);
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return bind_attr_value;
	}

	/**
	 * 通过SQL语句来获取某个分类中的所有部件
	 * 
	 * @param IBAName   部件绑定的属性
	 * @param classNode 分类节点内部名称
	 * @return classNode这个分类节点中的所有部件
	 */
	public static List<WTPart> getClassPart(String IBAName, String classNode) {
		List<WTPart> partList = new ArrayList<>();

		String sql = "WITH MPartsClsNODE AS (SELECT SD2.IDA2A2 FROM STRINGDEFINITION SD2 WHERE SD2.NAME =?) SELECT DISTINCT SV.IDA3A4 FROM STRINGVALUE SV JOIN MPartsClsNODE MPartsClsNODE ON SV.IDA3A6 = MPartsClsNODE.IDA2A2 WHERE SV.VALUE2 = ?";
		sql = sql.replace("MPartsClsNODE" , IBAName);
//		String sql = "SELECT DISTINCT SV.IDA3A4 FROM STRINGVALUE SV JOIN STRINGVALUE SV2 ON SV.IDA3A4 = SV2.IDA3A4 JOIN STRINGDEFINITION SD2 ON SV2.IDA3A6 = SD2.IDA2A2 AND SD2.NAME =?\n" +
//				"WHERE SV2.VALUE2 = ?";
		try {
			ResultSet resultSet = CommonUtil.excuteSelect(sql, IBAName, classNode);
			while (resultSet.next()) {
				String oid = resultSet.getString("IDA3A4");
				WTObject obj = PersistenceUtil.oid2Object("OR:wt.part.WTPart:" + oid);
				if(obj != null){
					WTPart part = (WTPart) obj;
//					String number = part.getNumber();
//					String view = part.getView().getName();
//					WTPart latestWTPart = PartUtil.getLatestWTPart(number, null, null, view);
//					partList.add(latestWTPart);
					partList.add(part);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return partList;
	}



	public TypeDefinitionReadView getTopClassification() throws WTException {
		Collection<TypeDefinitionReadView> topClassification = CSMTypeDefHelper.getRootTypeDefViews(CsmConstants.NAMESPACE);
		Iterator<TypeDefinitionReadView> itera = topClassification.iterator();
		return itera.hasNext() ? (TypeDefinitionReadView)itera.next() : null;
	}

	public Map<String, Object> getlistAllChildClassifi(TypeDefinitionReadView parentClassifiReadView) throws WTException {
		Map<String, Object> map = Maps.newHashMap();
		map.put("A_name", parentClassifiReadView.getName() + "_" + parentClassifiReadView.getDisplayName() + "$$" + parentClassifiReadView.getOid().getId());
		List<Map<String, Object>> childMaps = new LinkedList();
		if (parentClassifiReadView != null) {
			Collection<TypeDefinitionReadView> childClassification = CSMTypeDefHelper.getChildTypeDefViews(parentClassifiReadView);
			Iterator<TypeDefinitionReadView> itera = childClassification.iterator();

			while(itera.hasNext()) {
				TypeDefinitionReadView typeDefin = (TypeDefinitionReadView)itera.next();
				childMaps.add(this.getlistAllChildClassifi(typeDefin));
			}
		}
		map.put("B_children", childMaps);
		return map;
	}


	/**
	 * 通过分类节点的内部名，获取分类属性
	 * @param classNodeName
	 * @return
	 */
	public static Set<AttributeTypeIdentifier> getAllClassInterName(String classNodeName) throws WTException {
		ClassificationFacade facadeInstance = ClassificationFacade.getInstance();
		Set<AttributeTypeIdentifier> atis = facadeInstance.getClassificationAttributes("com.ptc.csm.default_clf_namespace", classNodeName);
		return atis;
	}




	/**
	 *   通过分类节点，分类属性的内部名，获取分类属性的显示名称
	 * @param classNodeName  分类节点内部名
	 * @param attributeName   分类属性内部名
	 * @return  返回分类属性显示名，若没找到改分类属性返回空字符串   ,  注意  AttributeDefinitionReadView  可以返回显示值
	 */
	public static AttributeDefinitionReadView getClassAttDisplayName(String classNodeName , String attributeName) throws WTException {
		AttributeDefinitionReadView adrv = null;
		//用分类节点内部值 获取是视图对象
		TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
				"com.ptc.csm.default_clf_namespace", classNodeName);
		adrv = clfNodeView.getAttributeByName(attributeName);
		if(adrv == null){
			TypeDefinitionReadView nodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCTYPE,
					"com.ptc.csm.default_clf_namespace", classNodeName);
			adrv = nodeView.getAttributeByName(attributeName);
		}

		return adrv;
	}


	/**
	 * 判断是否分类属性
	 * @param classify
	 * @param partInternalName
	 * @return
	 * @throws Exception
	 */
	public static boolean isClsValue(String classify, String partInternalName) throws Exception {
		TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
				"com.ptc.csm.default_clf_namespace", classify);
		AttributeDefinitionReadView adrv = clfNodeView.getAttributeByName(partInternalName);
		return adrv == null ? false : true;
	}


	/**
	 * 判断是否是IBA属性
	 * @param part
	 * @param typeInternalName
	 * @return
	 * @throws WTException
	 * @throws RemoteException
	 */
	public static boolean isIBA(Persistable part, String typeInternalName) throws WTException, RemoteException {

		String s = TypeIdentifierUtilityHelper.service.getTypeIdentifier(part).toString();
		System.out.println("isIBA里打印什么" + s);
		TypeIdentifier ti = TypedUtility.getTypeIdentifier(s);
		TypeDefinitionReadView tv = TypeDefinitionServiceHelper.service.getTypeDefView(ti);
		AttributeDefinitionReadView av = tv.getAttributeByName(typeInternalName);
		return av == null ? false : true;
	}


	/**
	 * 获取分类属性的合法值列表
	 * @param attributeDefinitionReadView
	 * @return 如果没有合法值列表 返回null  如果有返回合法值集合
	 * @throws WTException
	 */
	public static List<String> getLegitimateValues(AttributeDefinitionReadView attributeDefinitionReadView) throws WTException {
		List<String> result = new ArrayList<>();
		Collection<ConstraintDefinitionReadView> constraints1 = attributeDefinitionReadView.getAllConstraints();

		String constraintClassname = "";

		for (ConstraintDefinitionReadView ci : constraints1) {

			constraintClassname = ci.getRule().getRuleClassname();

			if ("com.ptc.core.meta.container.common.impl.DiscreteSetConstraint".equals(constraintClassname)) {
//				System.out.println("*****Legal Value List=" + ci.getRuleData());// Legal Value list values
				// 合法值[1.01.06.01,111,222,333]
				// 去掉前后的方括号并按逗号分割
				if(ci.getRuleData() ==null){
					return null;
				}
				String value = ci.getRuleData().toString();
				String content = value.substring(1, value.length() - 1);  // 去掉方括号
				String[] elements = content.split(",");
				// 将数组转换为 List
				result = Arrays.asList(elements);
			}

		}
		return result;
	}


	/**
	 * 当前属性是否展示
	 * 获取分类属性的说明值
	 * @param attributeDefinitionReadView
	 * @return 是 展示   否 不展示
	 */
	public static boolean showAttribute(AttributeDefinitionReadView attributeDefinitionReadView){
		boolean result = false;
		Collection<PropertyValueReadView> props = attributeDefinitionReadView.getAllProperties();
		for(PropertyValueReadView prop : props){
//			System.out.println("=== ts debug=== prop.getPropDef().toString() = " + prop.getPropDef().toString());
			if("description".equals(prop.getPropDef().getName())){
				System.out.println("当前分类属性为=="+attributeDefinitionReadView.getDisplayName());
				String description = prop.getValue().toString();
				// 获取到的是 主文本里的值
				System.out.println("分类属性获取说明主文本 = " + description);
				// 满足某种条件就展示这个属性
//				if(){
//					result = true;
//				}
			}
		}
		return result;
	}

}
