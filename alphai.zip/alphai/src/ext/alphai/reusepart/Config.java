package ext.alphai.reusepart;

import ext.alphai.reusepart.util.PropertiesUtil;

public class Config {
    private static PropertiesUtil properties = PropertiesUtil.getInstance("config.properties");
    public static final String AI_reusingLevel = "AI_reusingLevel";
    public static String Classification = "";

    static {
        Classification = getClassification();
    }

    public static final String INPUT = "input";

    public static final String SELECT = "select";

    public static final String A_Level = "A";
    public static final String B_Level = "B";
    public static final String C_Level = "C";

    // 重用次数在这个数以下包含这个数为A
    public static Integer getALevel() {
        return Integer.parseInt(properties.getValueByKey("Level.A"));
    }
    // 重用次数在A之上且这个数以下包含这个数为B
    public static Integer getBLevel() {
        return Integer.parseInt(properties.getValueByKey("Level.B"));
    }

    public static String getClassification() {
        return properties.getValueByKey("Classification");
    }
}
