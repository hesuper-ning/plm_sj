package ext.alphai.reusepart.server;

import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.lwc.common.dynamicEnum.EnumerationEntryInfo;
import com.ptc.core.lwc.common.view.*;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.windchill.csm.client.helpers.CSMTypeDefHelper;
import com.ptc.windchill.csm.common.CsmConstants;
import ext.alphai.reusepart.Config;
import ext.alphai.reusepart.bean.ClassificationAttributeVo;
import ext.alphai.reusepart.bean.ClassificationTreeVo;
import ext.alphai.reusepart.bean.QueryClassPartReqVo;
import ext.alphai.reusepart.bean.QueryClassPartRespVo;
import ext.alphai.reusepart.util.ClassificationUtil;
import ext.alphai.reusepart.util.IBAUtil;
import ext.alphai.reusepart.util.PartUtil;
import org.apache.commons.lang3.StringUtils;
import wt.facade.classification.ClassificationFacade;
import wt.part.WTPart;
import wt.util.WTException;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 快速检索服务类
 */
public class QuickRetrievalService {

    // 查询通配符
    private static final String select_wildcard="*";

    /**
     * 根据分类内部名获取所有部件对象（是否是最新版本）
     * @param className 分类节点内部名
     * @param vos 查询的请求参数
     * @return
     */
    public static List<QueryClassPartRespVo> getQueryClassPartByClassName(String className, List<QueryClassPartReqVo> vos) throws Exception {

        // 带所有版本的当前分类的物料
        List<WTPart> classPart = ClassificationUtil.getClassPart(Config.Classification, className);

        // 待展示的版本物料
         List<WTPart> lastWTPartInList = PartUtil.getMaxVersionParts(classPart);

        return getQueryClassPartByCondition(lastWTPartInList, vos, className);
    }


    /**
     * 根据请求参数获取待返回的部件信息集合
     * @param lastWTPartInList 当前节点的全部最新版本部件集合
     * @param vos 分类属性请求参数
     * @param className 分类节点内部值
     * @return
     */
    public static List<QueryClassPartRespVo> getQueryClassPartByCondition(List<WTPart> lastWTPartInList, List<QueryClassPartReqVo> vos, String className) throws Exception {
        // 等待展示的部件对象集合，初始为空的Set
        List<WTPart> parameter = new ArrayList<>();

        // 根据条件过滤部件集合，找出符合查找条件的WTPart对象
        if (vos.isEmpty()) {
            // 没有任何条件，直接将所有部件加入参数集合
            parameter.addAll(lastWTPartInList);
        } else {
            // 条件过滤后的部件集合，使用临时Set
            List<WTPart> afterFiltering = new ArrayList<>(lastWTPartInList);  // 初始时直接赋值为所有部件

            for (QueryClassPartReqVo vo : vos) {
                String label = vo.getLabel();
                String attributeName = vo.getAttributeName();
                String attributeValue = vo.getAttributeValue();

                List<WTPart> tempFiltering = new ArrayList<>(); // 临时集合存储每次过滤后的结果

                for (WTPart part : afterFiltering) {
                    IBAUtil iba = new IBAUtil(part);
                    String ibaAttributeValue = iba.getIBAValue(attributeName);

                    // 根据条件进行精确或模糊比对
                    if (Config.INPUT.equals(label)) {
                        if (match(ibaAttributeValue, attributeValue)) {
                            tempFiltering.add(part);  // 将符合条件的部件加入临时集合
                        }
                    } else if (Config.SELECT.equals(label)) {
                        if (ibaAttributeValue.equals(attributeValue)) {
                            tempFiltering.add(part);  // 将符合条件的部件加入临时集合
                        }
                    }
                }

                // 更新parameter集合为此次过滤后的结果
                afterFiltering = tempFiltering;
            }

            // 最终筛选后符合条件的部件
            parameter = afterFiltering;
        }

        return wtpartConvertQueryClassPartRespVo(parameter, className);
    }

    /**
     * 提取WTPart中的有效数据转换成前端页面展示的数据
     * @param parameter 待展示的部件
     * @param className 分类内部值
     * @return
     */
    public static List<QueryClassPartRespVo> wtpartConvertQueryClassPartRespVo(List<WTPart> parameter, String className) throws Exception {
        List<QueryClassPartRespVo> result = new ArrayList<>();
        // 获取部件基础属性
        // 获取当前分类所有需要展示的属性（非基础属性）
        List<ClassificationAttributeVo> classAttribute = getClassAttribute(className);

        for (WTPart part : parameter) {
            QueryClassPartRespVo vo = new QueryClassPartRespVo();
            String number = part.getNumber();
            String name = part.getName();
            String partStatus = part.getState().getState().getDisplay();

            UrlDisplayComponent partUrlByPartNumber = PartUtil.getPartUrlByPartNumber(part);
            vo.setPartURL(partUrlByPartNumber.getLink());
            vo.setPartName(name);
            vo.setPartNumber(number);
            vo.setPartStatue(partStatus);
            Map<String, String> attrMap = new HashMap<>();
            IBAUtil ibaUtil = new IBAUtil(part);
            for (ClassificationAttributeVo attributeVo : classAttribute) {
                String displayName = attributeVo.getDisplayName();
                // IBA属性内部值
                String ibaName = attributeVo.getName();
                String attrValue = ibaUtil.getIBAValue(ibaName);
                attrMap.put(displayName,attrValue);
            }
            vo.setAttributeMap(attrMap);
            result.add(vo);
        }
        return result;
    }








    /**
     * @param className
     * @return
     */
    public static List<ClassificationAttributeVo> getClassAttribute(String className) throws Exception {
        List<ClassificationAttributeVo> result = new ArrayList<>();
        // 获取所有分类属性
        Set<AttributeTypeIdentifier> allClassInterName = ClassificationUtil.getAllClassInterName(className);
        for (AttributeTypeIdentifier identifier : allClassInterName) {
            ClassificationAttributeVo classificationAttributeVo = new ClassificationAttributeVo();
            classificationAttributeVo.setName(identifier.getAttributeName());
            AttributeDefinitionReadView classAttDisplayName = ClassificationUtil.getClassAttDisplayName(className, identifier.getAttributeName());
            classificationAttributeVo.setDisplayName(classAttDisplayName.getDisplayName());

            // 判断是否展示值
//            boolean showAttribute = ClassificationUtil.showAttribute(classAttDisplayName);
//            if(showAttribute){
                // 是否是合法值还是枚举 或者都没有
                ClassificationAttributeVo attributeVo = getClassificationAttributeValue(classAttDisplayName, classificationAttributeVo);




                // 得到分类IBA属性的数据类型
// 这是第二种方法PersistableAdapter obj=new PersistableAdapter(doc,null,Locale.getDefault(),new DisplayOperationIdentifier());
//            obj.load("MyIBA");
//            System.out.println(obj.getAttributeDescriptor("MyIBA").getDataType());
                String dataType = classAttDisplayName.getDatatype().getName();
                attributeVo.setDataType(dataType);
                result.add(attributeVo);
//            }
        }



        return result;
    }


    /**
     * 获取分类属性的 枚举值  或者 合法值列表
     * @param classAttDisplayName
     * @param vo
     * @return
     */
    public static ClassificationAttributeVo getClassificationAttributeValue(AttributeDefinitionReadView classAttDisplayName, ClassificationAttributeVo vo){
        System.out.println("当前属性名=="+classAttDisplayName.getName());


        Collection<ConstraintDefinitionReadView> constraints1 = classAttDisplayName.getAllConstraints();
        String constraintClassname = "";
        vo.setLabel(Config.INPUT);
        for (ConstraintDefinitionReadView ci : constraints1) {
            constraintClassname = ci.getRule().getRuleClassname();
            if ("com.ptc.core.meta.container.common.impl.DiscreteSetConstraint".equals(constraintClassname)) {
                vo.setLabel(Config.SELECT);
                Serializable ruleData = ci.getRuleData();
//                System.out.println("*****Legal Value List=" + ruleData);// Legal Value list values
                EnumerationDefinitionReadView enumDef = ci.getEnumDef();
//                System.out.println("ruleData是否为空=="+(ruleData==null));
//                System.out.println("EnumerationDefinitionReadView是否为空=="+(enumDef==null));
                    Map<String, String> map = new HashMap<>();
                    if(ruleData != null){
                        String value = ci.getRuleData().toString();
                        String content = value.substring(1, value.length() - 1);  // 去掉方括号
                        String[] elements = content.split(",");
                        for (String element : elements) {
                            map.put(element,element);
                        }
                    }
                    if(enumDef != null){
                        String enumGetName = ci.getEnumDef().getName();
                        vo.setEnumKey(enumGetName);
                        // 直接用枚举值获取所有内部值和显示值
                        Map<String, EnumerationEntryReadView> allEnumerationEntries = ci.getEnumDef().getAllEnumerationEntries();
//                        System.out.println("枚举="+ allEnumerationEntries);
//                        System.out.println("是否是枚举="+ !allEnumerationEntries.isEmpty());
                        Set<String> keysOfView = allEnumerationEntries.keySet();
//                        System.out.println("keyset"+keysOfView);

                        for (String key : keysOfView) {
                            EnumerationEntryReadView view = allEnumerationEntries.get(key);
                            String enumKey = view.getName();
                            String enumName = view.getPropertyValueByName("displayName").getValue().toString();
                            // 此方法判断枚举值是否在可用列表
                            if (view.getPropertyValueByName("selectable").getValue().equals(true)) {
                                map.put(enumKey, enumName);
                            }
                        }
                    }
                vo.setEnumValuesList(map);
            }
        }
        return vo;
    }





    /**
     * 获取分类树
     * @return
     */
    public static ClassificationTreeVo getClassificationTree() throws WTException {
        // 分类树对象
        ClassificationTreeVo treeVo = new ClassificationTreeVo();
        // 获取根分类
        TypeDefinitionReadView rootClassification = getTopClassification();

        if(rootClassification !=null){
            treeVo.setInsideName(rootClassification.getName());
            treeVo.setDisplayName(rootClassification.getDisplayName());

            treeVo.setChildren(getChildClass(rootClassification));
        }
        return treeVo;
    }

    /**
     * 获取根节点
     * @return
     * @throws WTException
     */
    public static TypeDefinitionReadView getTopClassification() throws WTException {
        Collection<TypeDefinitionReadView> topClassification = CSMTypeDefHelper.getRootTypeDefViews(CsmConstants.NAMESPACE);
        Iterator<TypeDefinitionReadView> itera = topClassification.iterator();
        return itera.hasNext() ? (TypeDefinitionReadView)itera.next() : null;
    }


//    /**
//     * 递归获取分类节点 通过
//     * @param rootClassification  TypeDefinitionReadView currentClassification对象的sortOrder 值来从小到大排序 如果没有值就默认放在集合的后面
//     *
//     *        ClassificationFacade facadeInstance = ClassificationFacade.getInstance();
//     *         Object classificationNodeInfo = facadeInstance.getClassificationNodeInfo(currentClassification.getName(),
//     *                 CsmConstants.NAMESPACE);
//     *         EnumerationEntryInfo entryInfo = (EnumerationEntryInfo)classificationNodeInfo;
//     *         Integer sortOrder = (Integer) entryInfo.getNonLocalizablePropertyValue(EnumerationEntryInfo.SORT_ORDER);
//     * @return
//     * @throws WTException
//     */
//    public static List<ClassificationTreeVo> getChildClass(TypeDefinitionReadView rootClassification) throws WTException {
//        List<ClassificationTreeVo> result = new ArrayList<>();
//
//        Collection<TypeDefinitionReadView> childClassification = CSMTypeDefHelper.getChildTypeDefViews(rootClassification);
//
////        TypeDefinitionReadView view = childClassification.
//        // 使用 stream 和 Comparator 对集合进行排序  正式用
//        List<TypeDefinitionReadView> toSortList = childClassification.stream()
//                .filter(item -> !(item.getDisplayName().startsWith("JC35T")))  // 过滤掉以 "10_" 或 "12_" 开头的元素
//                .sorted(Comparator.comparingInt(item -> {
//                    // 提取显示名并获取数字部分
//                    String displayName = item.getDisplayName();
//                    String numberPart = displayName.split("_")[0]; // 获取数字部分，例如 "01" 从 "01_弹簧"
//                    return Integer.parseInt(numberPart); // 将数字部分解析为整数用于排序
//                }))
//                .collect(Collectors.toList());
//
//        // 获取所有以 "10_" 或 "12_" 开头的分类（不进行排序）
//        List<TypeDefinitionReadView> tenOrTwelvePrefixList = childClassification.stream()
//                .filter(item -> item.getDisplayName().startsWith("JC35T"))
//                .collect(Collectors.toList());
//
//        // 将两个列表合并，tenOrTwelvePrefixList 不参与排序，排在任意位置
//        List<TypeDefinitionReadView> sortedList = new ArrayList<>();
//        sortedList.addAll(toSortList);  // 先添加已排序的元素
//        sortedList.addAll(tenOrTwelvePrefixList);  // 然后添加不排序的元素
//
//
//
//
//        // 测试用
//        // 将以 10_ 或 12_ 开头的分类和其他分类分开
////        List<TypeDefinitionReadView> toSortList = childClassification.stream()
////                .filter(item -> !(item.getDisplayName().startsWith("10") || item.getDisplayName().startsWith("12")))  // 过滤掉以 "10_" 或 "12_" 开头的元素
////                .sorted(Comparator.comparingInt(item -> {
////                    // 提取显示名并获取数字部分
////                    String displayName = item.getDisplayName();
////                    String numberPart = displayName.split("_")[0]; // 获取数字部分，例如 "01" 从 "01_弹簧"
////                    return Integer.parseInt(numberPart); // 将数字部分解析为整数用于排序
////                }))
////                .collect(Collectors.toList());
////
////        // 获取所有以 "10_" 或 "12_" 开头的分类（不进行排序）
////        List<TypeDefinitionReadView> tenOrTwelvePrefixList = childClassification.stream()
////                .filter(item -> item.getDisplayName().startsWith("10") || item.getDisplayName().startsWith("12"))
////                .collect(Collectors.toList());
////
////        // 将两个列表合并，tenOrTwelvePrefixList 不参与排序，排在任意位置
////        List<TypeDefinitionReadView> sortedList = new ArrayList<>();
////        sortedList.addAll(toSortList);  // 先添加已排序的元素
////        sortedList.addAll(tenOrTwelvePrefixList);  // 然后添加不排序的元素
//
//
//
//
//
//
//
//
//
//        Iterator<TypeDefinitionReadView> itera = sortedList.iterator();
//        while(itera.hasNext()) {
//            ClassificationTreeVo treeVo = new ClassificationTreeVo();
//            TypeDefinitionReadView typeDefin = (TypeDefinitionReadView)itera.next();
//            treeVo.setInsideName(typeDefin.getName());
//            treeVo.setDisplayName(typeDefin.getDisplayName());
//            List<ClassificationTreeVo> childClass = getChildClass(typeDefin);
//            if(!childClass.isEmpty()){
//                treeVo.setChildren(childClass);
//            }
//            result.add(treeVo);
//        }
//        return result;
//    }












    /**
     * 递归获取分类节点的子节点，根据 sortOrder 排序
     * @param rootClassification 当前分类节点
     * @return 分类树结构列表
     * @throws WTException
     */
    public static List<ClassificationTreeVo> getChildClass(TypeDefinitionReadView rootClassification) throws WTException {
        List<ClassificationTreeVo> result = new ArrayList<>();
        Collection<TypeDefinitionReadView> childClassification = CSMTypeDefHelper.getChildTypeDefViews(rootClassification);

        // 获取子分类并排序：根据 sortOrder 升序，未设置 sortOrder 的排在最后
        List<TypeDefinitionReadView> sortedList = childClassification.stream()
                .map(item -> {
                    try {
                        // 获取分类的 EnumerationEntryInfo 以提取 sortOrder
                        ClassificationFacade facade = ClassificationFacade.getInstance();
                        EnumerationEntryInfo entryInfo = (EnumerationEntryInfo) facade.getClassificationNodeInfo(
                                item.getName(), CsmConstants.NAMESPACE);
                        Integer sortOrder = (Integer) entryInfo.getNonLocalizablePropertyValue(EnumerationEntryInfo.SORT_ORDER);
                        // 处理 sortOrder 为 null 的情况，设为最大值确保排在最后
                        int order = (sortOrder != null) ? sortOrder : Integer.MAX_VALUE;
                        return new AbstractMap.SimpleEntry<>(item, order);
                    } catch (WTException e) {
                        // 异常处理：返回默认排序值
                        return new AbstractMap.SimpleEntry<>(item, Integer.MAX_VALUE);
                    }
                })
                .sorted(Comparator.comparingInt(AbstractMap.SimpleEntry::getValue)) // 按 sortOrder 升序
                .map(AbstractMap.SimpleEntry::getKey)
                .collect(Collectors.toList());

        // 递归构建分类树
        for (TypeDefinitionReadView typeDef : sortedList) {
            ClassificationTreeVo treeVo = new ClassificationTreeVo();
            treeVo.setInsideName(typeDef.getName());
            treeVo.setDisplayName(typeDef.getDisplayName());
            List<ClassificationTreeVo> childClasses = getChildClass(typeDef);
            if (!childClasses.isEmpty()) {
                treeVo.setChildren(childClasses);
            }
            result.add(treeVo);
        }
        return result;
    }






    /**
     * 输入框字符串匹配方法
     * @param ibaAttributeValue
     * @param attributeValue
     * @return
     */
    public static boolean match(String ibaAttributeValue, String attributeValue) {
        // 如果 attributeValue 没有通配符 *，则直接比较两个字符串是否完全相同
        if (!attributeValue.contains(select_wildcard)) {
            return ibaAttributeValue.equals(attributeValue);
        }

        // 如果 attributeValue 以 * 开头，则需要匹配尾部
        if (attributeValue.startsWith(select_wildcard) && attributeValue.endsWith(select_wildcard)) {
            // 如果 * 在两端，使用通配符进行模糊匹配
            String pattern = attributeValue.replace(select_wildcard, ".*");
            return ibaAttributeValue.matches(pattern);
        }

        // 如果 attributeValue 以 * 结尾，则需要匹配头部
        if (attributeValue.endsWith(select_wildcard)) {
            String prefix = attributeValue.substring(0, attributeValue.length() - 1);
            return ibaAttributeValue.startsWith(prefix);
        }

        // 如果 attributeValue 以 * 开头，则需要匹配尾部
        if (attributeValue.startsWith(select_wildcard)) {
            String suffix = attributeValue.substring(1);
            return ibaAttributeValue.endsWith(suffix);
        }

        return false;
    }
    
    
    
    
    
    
    
    
    
    
    
}
