package ext.alphai.reusepart.server;

import ext.alphai.reusepart.Config;
import ext.alphai.reusepart.bean.MbomVo;
import ext.alphai.reusepart.bean.PartReuseFormVo;
import ext.alphai.reusepart.bean.ResponseVo;
import ext.alphai.reusepart.table.PartReuseTable;
import ext.alphai.reusepart.util.CommonUtil;
import ext.alphai.reusepart.util.IBAUtil;
import ext.alphai.reusepart.util.PartUtil;
import ext.alphai.reusepart.util.PersistenceUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.pom.WTConnection;
import wt.query.QuerySpec;
import wt.util.WTException;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * 部件重用报表服务类
 */
public class PartReuseService {
    // 定义常量
    private static final String WTPARTMASTER = "WTPARTMASTER";
    public static final int PAGE_SIZE = 2000; // 每一页的数据量

    /**
     * 获取部件重用报表
     * @param part
     * @return
     */
    public static ResponseVo getPartReuseForm(WTPart part) throws WTException {
        ResponseVo responseVo = new ResponseVo();
        PartReuseFormVo vo = new PartReuseFormVo();

        vo.setPartNumber(part.getNumber());
        vo.setPartName(part.getName());
        vo.setPartVersion(part.getVersionIdentifier().getValue()+"."+part.getIterationIdentifier().getValue());
        vo.setPartStatue(part.getState().getState().getDisplay());

        List<WTPartUsageLink> usageLinks = PartUtil.getLinksByPart(part);
        // 每次查看报表时会刷新当前料及其主料的重用等级表的数据
        List<WTPartMaster> waitRefreshMaster = new ArrayList<>();

        waitRefreshMaster.add(part.getMaster());


        Set<WTPartMaster> childPartMasterSet = new HashSet<>();
        for (WTPartUsageLink link : usageLinks) {
            childPartMasterSet.add(link.getUses());

            waitRefreshMaster.add(link.getUses());
        }

        if(childPartMasterSet.isEmpty()){
            responseVo.setCode(400);
            responseVo.setMsg("当前物料不是BOM结构");
            responseVo.setData(vo);
        }else {
            // 报表接口的值都来自于实施获取的数据
            responseVo.setCode(200);
            List<MbomVo> ALevel = new ArrayList<>();
            List<MbomVo> BLevel = new ArrayList<>();
            List<MbomVo> CLevel = new ArrayList<>();
            for (WTPartMaster master : childPartMasterSet) {
                WTPart partByNumber = PartUtil.getWTPartByNumber(master.getNumber());
                String partReuseLevel = getPartReuseLevel(master);
                IBAUtil iba = new IBAUtil(partByNumber);
                MbomVo mbomVo = new MbomVo();
                mbomVo.setmName(master.getName());
                mbomVo.setmNumber(master.getNumber());
                mbomVo.setmClassification(iba.getIBAValue(Config.getClassification()));
                mbomVo.setmVersion(partByNumber.getVersionIdentifier().getValue()+"."+partByNumber.getIterationIdentifier().getValue());
                mbomVo.setmStatue(partByNumber.getLifeCycleState().getDisplay());
                if(Config.C_Level.equals(partReuseLevel)){
                    CLevel.add(mbomVo);
                } else if (Config.B_Level.equals(partReuseLevel)) {
                    BLevel.add(mbomVo);
                } else if (Config.A_Level.equals(partReuseLevel)) {
                    ALevel.add(mbomVo);
                }
            }
            vo.setAPartList(ALevel);
            vo.setBPartList(BLevel);
            vo.setCPartList(CLevel);

            vo.setAUsageRate(usageRate(ALevel.size(), childPartMasterSet.size()));
            vo.setBUsageRate(usageRate(BLevel.size(), childPartMasterSet.size()));
            vo.setCUsageRate(usageRate(CLevel.size(), childPartMasterSet.size()));
            responseVo.setData(vo);
        }

        // 更新重用表
        updatePartReuseTable(waitRefreshMaster);

        return responseVo;
    }


    /**
     * 导出产品标准化报表
     * @param part
     * @return
     */
    public static File exportReuseForm(WTPart part) throws Exception{
        ResponseVo vo = getPartReuseForm(part);




        return null;
    }



    private static String usageRate(int molecule, int denominator){
        double percentage = (double) molecule / denominator * 100;

        // 将百分数格式化为字符串
        String percentageString = String.format("%.2f%%", percentage);
        return percentageString;
    }



    /**
     * 刷新部件重用等级IBA属性
     * @param part
     */
    public static void refreshPartReuseLevel(WTPart part){
        try{
            List<WTPart> parentParts = PartUtil.getParentParts(part);
            IBAUtil ibaUtil = new IBAUtil();
            if(parentParts.size() <= Config.getALevel()){
                // A
                ibaUtil.setIBAAttribute4AllType(part,Config.AI_reusingLevel, Config.A_Level);
            } else if (Config.getALevel() < parentParts.size() && parentParts.size() <= Config.getBLevel()) {
                // B
                ibaUtil.setIBAAttribute4AllType(part,Config.AI_reusingLevel, Config.B_Level);
            } else if (parentParts.size() > Config.getBLevel()) {
                // C
                ibaUtil.setIBAAttribute4AllType(part,Config.AI_reusingLevel, Config.C_Level);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }





    /*-----------------------建库查看部件重用方法--------------------------------*/

    /**
     *
     * @param tableName
     * @return
     */
    public static Integer getTableCount(String tableName) throws SQLException {
        Integer count = 0;
        StringBuilder sb = new StringBuilder("SELECT COUNT(*) FROM ");
        sb.append(tableName);

        ResultSet resultSet = CommonUtil.excuteSelect(sb.toString());
        while (resultSet.next()) {
            count = resultSet.getInt("COUNT(*)");

        }
        System.out.println("查询的表为："+tableName+" 查询到的条目："+count);
        return count;
    }


    /**
     * 分页查询方法（使用IDA2A2键集分页）
     */
    public static List<WTPartMaster> getPageWTPartMaster(int pageSize, Long lastId)
            throws SQLException {

        List<WTPartMaster> masters = new ArrayList<>();
        WTConnection conn = CommonUtil.getWTConnection();

        // 动态构建WHERE条件（避免SQL注入）
        StringBuilder whereClause = new StringBuilder();
        List<Object> params = new ArrayList<>();

        // 构建分页查询条件
        if (lastId != null) {
            whereClause.append("WHERE w.IDA2A2 > ? ");
            params.add(lastId); // 添加上次记录的ID参数
        }

        // 核心SQL（使用IDA2A2分页）
        String sql = "SELECT * FROM ( " +
                "  SELECT /*+ INDEX(w IDX_WTPARTMASTER_IDA2A2) */ " +  // 强制使用索引
                "    w.IDA2A2, w.CLASSNAMEA2A2 " +
                "  FROM WTPARTMASTER w " +
                "  " + whereClause.toString() +
                "  ORDER BY w.IDA2A2 ASC " +  // 确保排序唯一性
                ") WHERE ROWNUM <= ?";

        PreparedStatement ps = conn.prepareStatement(sql);

        // 动态绑定参数
        int paramIndex = 1;
        for (Object param : params) {
            ps.setObject(paramIndex++, param);
        }
        ps.setInt(paramIndex, pageSize); // 设置分页大小

        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            // 解析查询结果
            String ida2a2 = rs.getString("IDA2A2");
            String className = rs.getString("CLASSNAMEA2A2");
            Object obj = PersistenceUtil.oid2Object("OR:" + className + ":" + ida2a2);
            if (obj instanceof WTPartMaster) {
                masters.add((WTPartMaster) obj);
            }
        }
        rs.close();

        return masters;
    }


    /**
     * 获取部件重用等级
     * @param master
     * @return
     */
    public static String getPartReuseLevel(WTPartMaster master){
        List<WTPart> parentParts = getParentParts(master);
        if(parentParts.size() > Config.getALevel()){
            // A
            return Config.A_Level;

        } else if (Config.getALevel() >= parentParts.size() && parentParts.size() > Config.getBLevel()) {
            // B
            return Config.B_Level;
        } else if (parentParts.size() <= Config.getBLevel()) {
            // C
            return Config.C_Level;
        }
        return null;
    }


    /**
     * 获取所有父部件
     * @param master
     * @return
     */
    public static List<WTPart> getParentParts(WTPartMaster master) {
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            if (master != null) {
                //查到的是什么
                QueryResult qr = WTPartHelper.service.getUsedByWTParts(master);
                while (qr.hasMoreElements()) {
                    WTPart parentPart = (WTPart) qr.nextElement();
                    list.add(parentPart);
                }

            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    public static Integer partMasterLevelCount(Integer pageSize, String partName, String partNumber, Integer param) {
        Integer total = 0;
        WTConnection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = CommonUtil.getWTConnection();
            StringBuilder sql = new StringBuilder();
            List<Object> params = new ArrayList<>();

            // 参数预处理
            partName = StringUtils.trimToEmpty(partName);
            partNumber = StringUtils.trimToEmpty(partNumber);

            // 构建基础SQL
            sql.append("WITH MPartsClsNODE AS (")
                    .append("  SELECT MASTERIDA2A2 ")
                    .append("  FROM REUSEPARTMASTER ")
                    .append("  WHERE REUSELEVEL = ? ")
                    .append(") ")
                    .append("SELECT COUNT(*) AS total ")
                    .append("FROM WTPARTMASTER WM ")
                    .append("JOIN MPartsClsNODE MPN ON WM.IDA2A2 = MPN.MASTERIDA2A2 ");

            // 添加参数
            String valueCondition = resolveValueCondition(param);
            params.add(valueCondition);

            // 处理模糊条件
            boolean hasName = !partName.isEmpty();
            boolean hasNum = !partNumber.isEmpty();
            if (hasName && hasNum) {
                sql.append("WHERE WM.NAME LIKE '%' || ? || '%' AND WM.WTPARTNUMBER LIKE '%' || ? || '%'");
                params.add(partName);
                params.add(partNumber);
            } else if (hasName) {
                sql.append("WHERE WM.NAME LIKE '%' || ? || '%'");
                params.add(partName);
            } else if (hasNum) {
                sql.append("WHERE WM.WTPARTNUMBER LIKE '%' || ? || '%'");
                params.add(partNumber);
            }

            pstmt = conn.prepareStatement(sql.toString());

            // 参数绑定
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            rs = pstmt.executeQuery();

            // 结果处理
            if (rs.next()) {
                total = rs.getInt("total");
            }

        } catch (SQLException e) {
            System.err.println("COUNT查询异常:");
            e.printStackTrace();
        }

        return total;
    }

    public static List<WTPartMaster> getPartLevelBuyParam(Integer pageNumber, Integer pageSize, String partName, String partNumber, Integer param) {
        List<WTPartMaster> result = new ArrayList<>();
        WTConnection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = CommonUtil.getWTConnection();
            StringBuilder sql = new StringBuilder();
            List<Object> params = new ArrayList<>();

            // 构建基础SQL结构
            sql.append("WITH MPartsClsNODE AS (")
                    .append("  SELECT MASTERIDA2A2 ")
                    .append("  FROM REUSEPARTMASTER ")
                    .append("  WHERE REUSELEVEL = ? ")
                    .append(") ")
                    .append("SELECT * FROM (")
                    .append("  SELECT a.*, ROWNUM rnum FROM (")
                    .append("    SELECT WM.IDA2A2, WM.NAME, WM.WTPARTNUMBER ")
                    .append("    FROM WTPARTMASTER WM ")
                    .append("    JOIN MPartsClsNODE MPN ON WM.IDA2A2 = MPN.MASTERIDA2A2 ");

            // 添加参数
            String valueCondition = resolveValueCondition(param);
            params.add(valueCondition);

            // 处理模糊查询条件
            partName = StringUtils.trimToEmpty(partName);
            partNumber = StringUtils.trimToEmpty(partNumber);
            boolean hasPartName = !partName.isEmpty();
            boolean hasPartNumber = !partNumber.isEmpty();

            if (hasPartName && hasPartNumber) {
                sql.append("    WHERE WM.NAME LIKE '%' || ? || '%' AND WM.WTPARTNUMBER LIKE '%' || ? || '%'");
                params.add(partName);
                params.add(partNumber);
            } else if (hasPartName) {
                sql.append("    WHERE WM.NAME LIKE '%' || ? || '%'");
                params.add(partName);
            } else if (hasPartNumber) {
                sql.append("    WHERE WM.WTPARTNUMBER LIKE '%' || ? || '%'");
                params.add(partNumber);
            }

            // 排序
            sql.append("    ORDER BY WM.IDA2A2 ")
                    .append("  ) a WHERE ROWNUM <= ? ")
                    .append(") WHERE rnum > ? ");

            // 计算分页参数
            int startRow = (pageNumber - 1) * pageSize;
            int endRow = pageNumber * pageSize;
            params.add(endRow);
            params.add(startRow);

            pstmt = conn.prepareStatement(sql.toString());

            // 参数绑定
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            rs = pstmt.executeQuery();

            // 处理结果集
            while (rs.next()) {
                String ida2A2 = rs.getString("IDA2A2");
                WTObject obj = PersistenceUtil.oid2Object("OR:wt.part.WTPartMaster:" + ida2A2);
                if (obj instanceof WTPartMaster) {
                    result.add((WTPartMaster) obj);
                }
            }

        } catch (SQLException e) {
            System.err.println("数据库查询异常:");
            e.printStackTrace();
        }
        return result;
    }

    private static String resolveValueCondition(Integer param) {
        if (param == null) {
            throw new IllegalArgumentException("param参数不能为空");
        }
        switch (param) {
            case PartReuseTable.LIST_A: return "A";
            case PartReuseTable.LIST_B: return "B";
            case PartReuseTable.LIST_C: return "C";
            default:
                throw new IllegalArgumentException("非法的param值: " + param);
        }
    }







    /**
     * 解析ResultSet到对象
     */
    private static WTPartMaster parseResultSet(ResultSet rs) throws SQLException {
        String ida2a2 = rs.getString("IDA2A2");
        String className = rs.getString("CLASSNAMEA2A2");
        Object obj = PersistenceUtil.oid2Object("OR:" + className + ":" + ida2a2);
        return (obj instanceof WTPartMaster) ? (WTPartMaster) obj : null;
    }








/*
刷新 中间表
 */


    /**
     * 键集分页优化版（带游标控制）
     */
    public static void updateREUSEPARTMASTER() throws SQLException {
        final int PAGE_SIZE = 2000;
        final int BATCH_COMMIT_SIZE = 500; // 每500条提交一次

        Long lastId = null;
        int totalProcessed = 0;
        long startTime = System.currentTimeMillis();

        try {
            do {
                // 1. 分页获取数据
                List<WTPartMaster> pageData = getPageWTPartMaster(PAGE_SIZE, lastId);

                // 2. 分批处理数据
                if (!pageData.isEmpty()) {
                    int batchCount = (int) Math.ceil((double)pageData.size() / BATCH_COMMIT_SIZE);

                    for (int i = 0; i < batchCount; i++) {
                        int fromIndex = i * BATCH_COMMIT_SIZE;
                        int toIndex = Math.min((i+1)*BATCH_COMMIT_SIZE, pageData.size());
                        List<WTPartMaster> subList = pageData.subList(fromIndex, toIndex);

                        updatePartReuseTable(subList);
                        totalProcessed += subList.size();
                    }
                }

                // 3. 更新分页锚点
                lastId = !pageData.isEmpty() ?
                        pageData.get(pageData.size()-1).getPersistInfo().getObjectIdentifier().getId() : null;
                System.out.println("处理完第2000条master");
            } while (lastId != null);

        } finally {
            System.out.printf("处理完成！总记录数：%d, 耗时：%.2f秒%n",
                    totalProcessed, (System.currentTimeMillis()-startTime)/1000.0);
        }
    }



    /**
     * 构建分页SQL（利用索引提高性能）
     */
    private static String buildPaginationQuery(Long lastId) {
        StringBuilder sb = new StringBuilder()
                .append("SELECT * FROM (")
                .append("  SELECT /*+ INDEX(w IDX_WTPARTMASTER_IDA2A2) */ ")
                .append("    w.IDA2A2, w.CLASSNAMEA2A2 ")
                .append("  FROM WTPARTMASTER w ");

        if (lastId != null) {
            sb.append("  WHERE w.IDA2A2 > ? ");
        }

        sb.append("  ORDER BY w.IDA2A2 ASC ")
                .append(") WHERE ROWNUM <= ?");

        return sb.toString();
    }



    /**
     * 安全批量更新方法（带增强型游标控制）
     */
    public static void updatePartReuseTable(List<WTPartMaster> masters) {
        final String MERGE_SQL =
                "MERGE INTO REUSEPARTMASTER r " +
                        "USING (SELECT ? MASTERIDA2A2, ? REUSELEVEL FROM DUAL) src " +
                        "ON (r.MASTERIDA2A2 = src.MASTERIDA2A2) " +
                        "WHEN MATCHED THEN UPDATE SET REUSELEVEL = src.REUSELEVEL " +
                        "WHEN NOT MATCHED THEN INSERT (MASTERIDA2A2, REUSELEVEL) " +
                        "VALUES (src.MASTERIDA2A2, src.REUSELEVEL)";

        WTConnection wtConn = null;
        Connection conn = null;
        boolean originalAutoCommit = true;

        try {
            // 安全获取连接（带空指针保护）
            wtConn = CommonUtil.getWTConnection();
            if (wtConn == null) {
                throw new RuntimeException("无法获取数据库连接");
            }

            conn = wtConn.getConnection();
            if (conn == null) {
                throw new RuntimeException("底层连接不可用");
            }

            // 保存原始自动提交状态
            originalAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(MERGE_SQL)) {
                int batchCounter = 0;

                for (WTPartMaster master : masters) {
                    // 参数绑定（带空值检查）
                    long ida2a2 = master.getPersistInfo().getObjectIdentifier().getId();
                    String reuseLevel = getPartReuseLevel(master);

                    ps.setLong(1, ida2a2);
                    ps.setString(2, reuseLevel != null ? reuseLevel : "DEFAULT");
                    ps.addBatch();

                    // 批量提交控制
                    if (++batchCounter % 500 == 0) {
                        executeBatchWithRetry(ps, conn);
                    }
                }

                // 提交剩余批次
                if (batchCounter % 500 != 0) {
                    executeBatchWithRetry(ps, conn);
                }
            }

        } catch (SQLException | RuntimeException e) {
            // 增强型回滚机制
            safeRollback(conn);
            throw new RuntimeException("批量更新失败: " + e.getMessage(), e);
        } finally {
            // 安全恢复自动提交状态
            safeResetAutoCommit(conn, originalAutoCommit);
        }
    }

    /**
     * 带重试机制的批处理执行
     */
    private static void executeBatchWithRetry(PreparedStatement ps, Connection conn) throws SQLException {
        try {
            ps.executeBatch();
            conn.commit();
            ps.clearBatch();
        } catch (SQLException e) {
            if (isConnectionValid(conn)) {
                conn.rollback();
            }
            throw e;
        }
    }

    /**
     * 安全回滚方法
     */
    private static void safeRollback(Connection conn) {
        try {
            if (conn != null && !conn.isClosed() && !conn.getAutoCommit()) {
                conn.rollback();
            }
        } catch (SQLException ex) {
            System.err.println("回滚失败: " + ex.getMessage());
        }
    }

    /**
     * 安全重置自动提交状态
     */
    private static void safeResetAutoCommit(Connection conn, boolean originalAutoCommit) {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.setAutoCommit(originalAutoCommit);
            }
        } catch (SQLException e) {
            System.err.println("恢复自动提交失败: " + e.getMessage());
        }
    }

    /**
     * 连接有效性检查
     */
    private static boolean isConnectionValid(Connection conn) {
        try {
            return conn != null && !conn.isClosed() && conn.isValid(5);
        } catch (SQLException e) {
            return false;
        }
    }






}
