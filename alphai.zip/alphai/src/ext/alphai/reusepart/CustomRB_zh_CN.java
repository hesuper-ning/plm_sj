package ext.alphai.reusepart;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.reusepart.CustomRB_zh_CN")
public class CustomRB_zh_CN extends WTListResourceBundle {
    @RBEntry("报表")
    public static final String PRIVATE_CONSTANT_1 = "navigation.jcReportForms.description";
    @RBEntry("报表")
    public static final String PRIVATE_CONSTANT_2 = "navigation.jcReportForms.tooltip";

    @RBEntry("paste_24.png")
    public static final String PRIVATE_CONSTANT_5 = "navigation.jcReportForms.icon";

    @RBEntry("部件重用等级")
    public static final String PRIVATE_CONSTANT_3 = "jcpartReuse.partReuseLevel.description";
    @RBEntry("部件重用等级")
    public static final String PRIVATE_CONSTANT_4 = "jcpartReuse.partReuseLevel.tooltip";

//    @RBEntry("add16x16.gif")
//    public static final String PRIVATE_CONSTANT_3 = "changeNotBom.addWizard.icon";


    @RBEntry("重用报表")
    public static final String PRIVATE_CONSTANT_6 = "jcpartReuse.partreuseForm.description";
    @RBEntry("重用报表")
    public static final String PRIVATE_CONSTANT_7 = "jcpartReuse.partreuseForm.tooltip";
    @RBEntry("flex_lifecycle.png")
    public static final String PRIVATE_CONSTANT_8 = "jcpartReuse.partreuseForm.icon";


    @RBEntry("A级")
    public static final String PRIVATE_CONSTANT_9 = "jcpartReuse.LevelA.description";
    @RBEntry("A级")
    public static final String PRIVATE_CONSTANT_10 = "jcpartReuse.LevelA.tooltip";


    @RBEntry("B级")
    public static final String PRIVATE_CONSTANT_12 = "jcpartReuse.LevelB.description";
    @RBEntry("B级")
    public static final String PRIVATE_CONSTANT_13 = "jcpartReuse.LevelB.tooltip";


    @RBEntry("C级")
    public static final String PRIVATE_CONSTANT_14 = "jcpartReuse.LevelC.description";
    @RBEntry("C级")
    public static final String PRIVATE_CONSTANT_15 = "jcpartReuse.LevelC.tooltip";



    @RBEntry("全部")
    public static final String PRIVATE_CONSTANT_16= "jcpartReuse.AllLevel.description";
    @RBEntry("全部")
    public static final String PRIVATE_CONSTANT_17 = "jcpartReuse.AllLevel.tooltip";



    @RBEntry("物料搜索")
    public static final String PRIVATE_CONSTANT_18= "jcpartReuse.jcquickSearch.description";
    @RBEntry("物料搜索")
    public static final String PRIVATE_CONSTANT_19 = "jcpartReuse.jcquickSearch.tooltip";


    @RBEntry("A.svg")
    public static final String PRIVATE_CONSTANT_20 = "jcpartReuse.LevelA.icon";
    @RBEntry("B.svg")
    public static final String PRIVATE_CONSTANT_21 = "jcpartReuse.LevelB.icon";
    @RBEntry("C.svg")
    public static final String PRIVATE_CONSTANT_22 = "jcpartReuse.LevelC.icon";

    @RBEntry("all.svg")
    public static final String PRIVATE_CONSTANT_23 = "jcpartReuse.AllLevel.icon";
}
