package ext.alphai.reusepart.timeQueue;


import ext.alphai.reusepart.server.PartReuseService;
import ext.alphai.reusepart.server.PartReuseService12;

import java.util.*;

/**
 * 同步PDM2表格中的物料描述属性字段
 */
public class SyncPartReusingLevel {

    public static void queueTest() {
        Date date = new Date();
        System.out.println("======同步物料重用等级队列正在执行======" + date);

        try {
            syncPartReusingLevel();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("==============更新物料重用等级执行完毕==================");
    }

    /**
     * 刷新所有部件重用等级
     */
    public static void syncPartReusingLevel() throws Exception {
        PartReuseService.updateREUSEPARTMASTER();
    }





}
