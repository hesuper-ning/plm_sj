package ext.alphai.reusepart.timeQueue;

import java.sql.Timestamp;
import java.util.Enumeration;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.org.OrganizationServicesHelper;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.scheduler.ScheduleItem;
import wt.scheduler.SchedulingHelper;
import wt.util.WTException;
/**
 * 创建同步PDM2物料描述队列
 */
public class CreateSyncDesQueue {
    public static void main(String[] args) throws WTException {
            QueryResult queryResult1 = getScheduleItem("update kucun", "sap1");
            while (queryResult1.hasMoreElements()) {
                ScheduleItem scheduleItem = (ScheduleItem) queryResult1.nextElement();
                // 删除系统中已存在的队列
                PersistenceHelper.manager.delete(scheduleItem);
            }

            createScheduleQueue1();

    }




    public static QueryResult getScheduleItem(String schedule_item_name, String Schedule_queque_name)
            throws WTException {
        QuerySpec queryspec = new QuerySpec(ScheduleItem.class);
        queryspec.appendWhere(new SearchCondition(ScheduleItem.class, ScheduleItem.ITEM_NAME, SearchCondition.EQUAL,
                schedule_item_name), new int[] { 0 });
        queryspec.appendAnd();
        queryspec.appendWhere(new SearchCondition(ScheduleItem.class, ScheduleItem.QUEUE_NAME, SearchCondition.EQUAL,
                Schedule_queque_name), new int[] { 0 });
        // queryspec.appendOrderBy(ScheduleItem.class, ScheduleItem.START_DATE,
        // true);

        QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec) queryspec);
        return queryResult;
    }

    public static void createScheduleQueue1() throws WTException {
        System.out.println("开始创建计划执行队列... ...");

        // 创建计划队列对象
        ScheduleItem si = ScheduleItem.newScheduleItem();
        // 设置该队列的描述信息
        si.setItemName("SyncPartReusingLevel");
        si.setItemDescription("更新部件重用关系队列");
        // 设置队列的名称，一般以英文命名
        si.setQueueName("SyncPartReusingLevel");
        // 设置要执行的类和方法
        // 类名
        si.setTargetClass(SyncPartReusingLevel.class.getName());
        // 方法名
        si.setTargetMethod("queueTest");
        si.setToBeRun(-1l);
        // 设置开始时间,在这里我设置为队列创建后立即执行
        Timestamp timestamp = Timestamp.valueOf("2025-05-06 23:00:00.000"); // 设置2020年10月24号
        // 2点开始执行
        si.setStartDate(timestamp);
        // 设置执行周期,这里设置为每隔7天执行一次
        si.setPeriodicity(604800);
        // 设置执行该任务的用户,如果是操作Windchill对象的话会牵扯到权限控制,这里设置为管理员执行
        WTUser administrator = getUserFromName("Administrator");
        si.setPrincipalRef(WTPrincipalReference.newWTPrincipalReference(administrator));
        // 最后，将计划任务对象添加到队列
        si = SchedulingHelper.service.addItem(si, null);
    }

    @SuppressWarnings("deprecation")
    public static WTUser getUserFromName(String name) throws WTException {
        Enumeration<?> enumUser = OrganizationServicesHelper.manager.findUser(WTUser.NAME, name);
        WTUser user = null;
        if (enumUser.hasMoreElements())
            user = (WTUser) enumUser.nextElement();

        if (user == null) {
            enumUser = OrganizationServicesHelper.manager.findUser(WTUser.FULL_NAME, name);
            if (enumUser.hasMoreElements())
                user = (WTUser) enumUser.nextElement();
        }
        if (user == null) {
            throw new WTException("系统中不存在用户名为'" + name + "'的用户！");
        }

        return user;
    }
}
