package ext.alphai.reusepart.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * 部件重用等级报表接口数据返回Vo
 */
public class PartReuseFormVo {

    public String partNumber;


    public String partName;

    public String partVersion;


    public String partStatue;

    public String partScore;


    // A类物料使用率
    @JsonProperty("AUsageRate")
    public String AUsageRate;

    // B类物料使用率
    @JsonProperty("BUsageRate")
    public String BUsageRate;

    // C类物料使用率
    @JsonProperty("CUsageRate")
    public String CUsageRate;

    @JsonProperty("APartList")
    public List<MbomVo> APartList;

    @JsonProperty("BPartList")
    public List<MbomVo> BPartList;
    @JsonProperty("CPartList")
    public List<MbomVo> CPartList;


    public PartReuseFormVo() {
    }
    
    public String getPartNumber() {
        return partNumber;
    }
    
    public String getPartScore() {
        return partScore;
    }
    
    public void setPartScore(String partScore) {
        this.partScore = partScore;
    }
    
    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }
    
    public String getPartName() {
        return partName;
    }
    
    public void setPartName(String partName) {
        this.partName = partName;
    }
    
    public String getPartVersion() {
        return partVersion;
    }
    
    public void setPartVersion(String partVersion) {
        this.partVersion = partVersion;
    }
    
    public String getPartStatue() {
        return partStatue;
    }
    
    public void setPartStatue(String partStatue) {
        this.partStatue = partStatue;
    }
    
    public String getAUsageRate() {
        return AUsageRate;
    }
    
    public void setAUsageRate(String AUsageRate) {
        this.AUsageRate = AUsageRate;
    }
    
    public String getBUsageRate() {
        return BUsageRate;
    }
    
    public void setBUsageRate(String BUsageRate) {
        this.BUsageRate = BUsageRate;
    }
    
    public String getCUsageRate() {
        return CUsageRate;
    }
    
    public void setCUsageRate(String CUsageRate) {
        this.CUsageRate = CUsageRate;
    }
    
    public List<MbomVo> getAPartList() {
        return APartList;
    }
    
    public void setAPartList(List<MbomVo> APartList) {
        this.APartList = APartList;
    }
    
    public List<MbomVo> getBPartList() {
        return BPartList;
    }
    
    public void setBPartList(List<MbomVo> BPartList) {
        this.BPartList = BPartList;
    }
    
    public List<MbomVo> getCPartList() {
        return CPartList;
    }
    
    public void setCPartList(List<MbomVo> CPartList) {
        this.CPartList = CPartList;
    }
}
