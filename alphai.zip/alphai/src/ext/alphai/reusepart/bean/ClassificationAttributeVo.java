package ext.alphai.reusepart.bean;

import java.util.List;
import java.util.Map;

/**
 * 分类属性Vo
 */
public class ClassificationAttributeVo {

    // 属性内部名称
    public String name;

    // 属性显示名
    public String displayName;

    // 页面是下拉框还是输入框
    public String label;


    // 枚举key
    public String enumKey;

    // 数据类型
    public String dataType;

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    // 枚举值列表 key为显示名  value为内部名 用于属性值为枚举
    public Map<String, String> enumValuesList;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }


    public Map<String, String> getEnumValuesList() {
        return enumValuesList;
    }

    public void setEnumValuesList(Map<String, String> enumValuesList) {
        this.enumValuesList = enumValuesList;
    }

    public String getEnumKey() {
        return enumKey;
    }

    public void setEnumKey(String enumKey) {
        this.enumKey = enumKey;
    }
}
