package ext.alphai.reusepart.bean;


import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import ext.alphai.reusepart.Config;
import ext.alphai.reusepart.table.PartReuseTable;
import ext.alphai.reusepart.util.ClassificationUtil;
import ext.alphai.reusepart.util.IBAUtil;
import ext.alphai.reusepart.util.PartUtil;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.util.ArrayList;
import java.util.List;

public class PartReuseShowVo {

    private String partThumbnail;

    private String partNumber;

    private String partURL;
    private String partName;

    private String partVersion;

    private String reuseLevel;

    private String lifecycle;

    private String updateTime;

    private String updateUser;

    private String classification;

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getPartURL() {
        return partURL;
    }

    public void setPartURL(String partURL) {
        this.partURL = partURL;
    }

    public String getPartThumbnail() {
        return partThumbnail;
    }

    public void setPartThumbnail(String partThumbnail) {
        this.partThumbnail = partThumbnail;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPartVersion() {
        return partVersion;
    }

    public void setPartVersion(String partVersion) {
        this.partVersion = partVersion;
    }

    public String getReuseLevel() {
        return reuseLevel;
    }

    public void setReuseLevel(String reuseLevel) {
        this.reuseLevel = reuseLevel;
    }

    public String getLifecycle() {
        return lifecycle;
    }

    public void setLifecycle(String lifecycle) {
        this.lifecycle = lifecycle;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }


    public static List<PartReuseShowVo> getPartReuseShowVoByMasters(List<WTPartMaster> list, Integer param) throws WTException {
        List<PartReuseShowVo> result = new ArrayList<>();
        for (WTPartMaster master : list) {


            PartReuseShowVo vo = new PartReuseShowVo();
            String number = master.getNumber();

            WTPart part = (WTPart) VersionControlHelper.service.allVersionsOf(master).nextElement();
            if(part == null){
                continue;
            }
            String bigVersion = part.getVersionIdentifier().getValue();
            String smallVersion = part.getIterationIdentifier().getValue();
            UrlDisplayComponent partThumbnail = PartUtil.getPartThumbnail(part);
            if(partThumbnail!=null){
                vo.setPartThumbnail(partThumbnail.getLink());
            }

            vo.setPartURL(PartUtil.getPartUrlByPartNumber(part).getLink());
            vo.setPartName(master.getName());
            vo.setPartNumber(number);
            vo.setPartVersion(bigVersion+"."+smallVersion);
            vo.setLifecycle(part.getLifeCycleState().getDisplay());
            vo.setReuseLevel(resolveValueCondition(param));
            vo.setUpdateTime(master.getModifyTimestamp().toString());
            WTPrincipalReference modifier = part.getModifier();
            WTPrincipal p = modifier.getPrincipal();
            WTUser user = (WTUser) p;
            vo.setUpdateUser(user.getFullName());
            // 获取
            IBAUtil iba= new IBAUtil(part);
            // 分类内部值
            String classKey = iba.getIBAValue(Config.getClassification());
//            // 根据分类内部值获取显示值ClassificationUtil.getClassificationdDisPlayName(classKey)
//            vo.setClassification(ClassificationUtil.getClassificationdDisPlayName(classKey));
            vo.setClassification(classKey);
            result.add(vo);
        }
        return result;
    }


    private static String resolveValueCondition(Integer param) {
        if (param == null) {
            throw new IllegalArgumentException("param参数不能为空");
        }
        switch (param) {
            case PartReuseTable.LIST_A: return "A";
            case PartReuseTable.LIST_B: return "B";
            case PartReuseTable.LIST_C: return "C";
            default:
                throw new IllegalArgumentException("非法的param值: " + param);
        }
    }
}
