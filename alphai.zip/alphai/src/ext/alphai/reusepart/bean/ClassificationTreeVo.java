package ext.alphai.reusepart.bean;

import java.util.List;

/**
 * 分类树Vo
 */
public class ClassificationTreeVo {

    public String insideName;


    public String displayName;

    public List<ClassificationTreeVo> children;


    public String getInsideName() {
        return insideName;
    }

    public void setInsideName(String insideName) {
        this.insideName = insideName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public List<ClassificationTreeVo> getChildren() {
        return children;
    }

    public void setChildren(List<ClassificationTreeVo> children) {
        this.children = children;
    }
}
