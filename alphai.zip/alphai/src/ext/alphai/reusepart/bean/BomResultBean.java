package ext.alphai.reusepart.bean;

public class BomResultBean {
    //物料编号
    private String number;
    //物料名称
    private String name;
    //最后修改人
    private String modifiedMan;
    //版本
    private String version;
    //修改时间
    private String editTime;
    //生命周期状态
    private String state;
    //重用等级
    private String reusing;


    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModifiedMan() {
        return modifiedMan;
    }

    public void setModifiedMan(String modifiedMan) {
        this.modifiedMan = modifiedMan;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getEditTime() {
        return editTime;
    }

    public void setEditTime(String editTime) {
        this.editTime = editTime;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getReusing() {
        return reusing;
    }

    public void setReusing(String reusing) {
        this.reusing = reusing;
    }

    @Override
    public String toString() {
        return "{" +
                "number:" + number +
                ", name:" + name +
                ", modifiedMan:" + modifiedMan +
                ", version:" + version +
                ", editTime:" + editTime +
                ", state:" + state +
                ", reusing:" + reusing +
                '}';
    }
}
