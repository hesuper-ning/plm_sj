package ext.alphai.reusepart.bean;

import ext.alphai.reusepart.Config;
import ext.alphai.reusepart.util.ClassificationUtil;
import ext.alphai.reusepart.util.IBAUtil;
import wt.part.WTPart;
import wt.util.WTException;


/**
 * 物料清单Vo
 */
public class MbomVo {


    public String mNumber;

    public String mName;


    public String mClassification;


    public String mVersion;

    public String mStatue;

    public MbomVo() {
    }

    public MbomVo(WTPart part) throws WTException {
        this.mNumber = part.getNumber();
        this.mName = part.getName();
        IBAUtil ibaUtil = new IBAUtil(part);
        String insideValue = ibaUtil.getIBAValue(Config.Classification);
        this.mClassification = ClassificationUtil.getClassificationdDisPlayName(insideValue);
        this.mVersion = part.getVersionIdentifier().getValue()+"."+part.getIterationIdentifier().getValue();
        this.mStatue = part.getState().getState().getDisplay();
    }


    public MbomVo(String mNumber, String mName, String mClassification, String mVersion, String mStatue) {
        this.mNumber = mNumber;
        this.mName = mName;
        this.mClassification = mClassification;
        this.mVersion = mVersion;
        this.mStatue = mStatue;
    }

    
    public String getmNumber() {
        return mNumber;
    }
    
    public void setmNumber(String mNumber) {
        this.mNumber = mNumber;
    }
    
    public String getmName() {
        return mName;
    }
    
    public void setmName(String mName) {
        this.mName = mName;
    }
    
    public String getmClassification() {
        return mClassification;
    }
    
    public void setmClassification(String mClassification) {
        this.mClassification = mClassification;
    }
    
    public String getmVersion() {
        return mVersion;
    }
    
    public void setmVersion(String mVersion) {
        this.mVersion = mVersion;
    }
    
    public String getmStatue() {
        return mStatue;
    }
    
    public void setmStatue(String mStatue) {
        this.mStatue = mStatue;
    }
}
