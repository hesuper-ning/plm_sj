package ext.alphai.reusepart.bean;

/**
 * 查询分类部件请求
 */
public class QueryClassPartReqVo {

    // 分类节点内部名
    public String classificationName;

    // 是输入框还是下拉框
    public String label;

    // 分类属性名
    public String attributeName;

    // 查询值
    public String attributeValue;

    public String getClassificationName() {
        return classificationName;
    }

    public void setClassificationName(String classificationName) {
        this.classificationName = classificationName;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public String getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }
}
