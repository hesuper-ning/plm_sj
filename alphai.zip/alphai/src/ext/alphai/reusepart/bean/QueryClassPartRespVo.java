package ext.alphai.reusepart.bean;

import java.util.Map;

/**
 * 查询分类部件返回对象
 */
public class QueryClassPartRespVo {

    public String partNumber;

    public String partURL;


    public String partName;

    // 部件状态
    public String partStatue;

    // 分类属性动态值列表
    public Map<String, String> attributeMap;

    public String getPartURL() {
        return partURL;
    }

    public void setPartURL(String partURL) {
        this.partURL = partURL;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPartStatue() {
        return partStatue;
    }

    public void setPartStatue(String partStatue) {
        this.partStatue = partStatue;
    }

    public Map<String, String> getAttributeMap() {
        return attributeMap;
    }

    public void setAttributeMap(Map<String, String> attributeMap) {
        this.attributeMap = attributeMap;
    }
}
