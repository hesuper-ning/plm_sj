package ext.alphai.reusepart.controller;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.reusepart.bean.PartReuseShowVo;
import ext.alphai.reusepart.bean.TableDataInfo;
import ext.alphai.reusepart.server.PartReuseService;
import ext.alphai.reusepart.server.PartReuseService12;
import ext.alphai.reusepart.util.PartUtil;
import ext.alphai.reusepart.util.PersistenceUtil;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import ext.alphai.reusepart.bean.ResponseVo;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;
import wt.util.WTProperties;

import java.io.*;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Objects;

/**
 * 部件重用属性报表接口
 */
@Controller
@RequestMapping({ "/PartReuse" })
public class PartReuseFormController {

    static final ObjectMapper objectMapper = new ObjectMapper();

    public static String TEMP_PART;
    // 临时目录
    public static String TEMP_DIR;
    static {
        try {
            WTProperties wtProperties = WTProperties.getLocalProperties();
            String CLASS_PATH = wtProperties.getProperty("wt.codebase.location");
            TEMP_PART = CLASS_PATH + "\\netmarkets\\jsp\\alphai\\reusepart\\template.xlsx" ;

            TEMP_DIR = wtProperties.getProperty("wt.temp")+"\\";
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static final DateFormat dateFormatFile = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * 需求4   部件重用报表
     * @param oid 部件OID
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/partReuseForms", method = RequestMethod.GET )
    public void getDetailData(@RequestParam("oid") String oid, HttpServletRequest request,
                              HttpServletResponse response) throws IOException, WTException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("进入部件重用报表接口");
        String resultJson ;

        System.out.println("oid="+oid);

        if(oid.contains("VR")){
            oid = PartUtil.getORbyVR(oid);
        }

        WTPart part = (WTPart) PersistenceUtil.oid2Object(oid);
        ResponseVo responseVo = new ResponseVo();
        if(part != null){
            responseVo = PartReuseService.getPartReuseForm(part);
        }
        resultJson = objectMapper.writeValueAsString(responseVo);

        System.out.println(resultJson);
        outResponse(response ,resultJson);
    }


    /**
     * 导出产品标准化报表
     * @param oid
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/exportReuseForm", method = RequestMethod.GET )
    public void getExportReuseForm(@RequestParam("oid") String oid, HttpServletRequest request,
                              HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        if(oid.contains("VR")){
            oid = PartUtil.getORbyVR(oid);
        }

        WTPart part = (WTPart) PersistenceUtil.oid2Object(oid);

        if(part == null){
            response.reset();
            response.setContentType("application/json;charset=utf-8");
            response.setContentType("text/html;charset=UTF-8");  //这句太重要了
            PrintWriter out = response.getWriter();
            out.print("当前部件不存在");
            out.flush();
            return;
        }

        try {
            File file = PartReuseService.exportReuseForm(part);
            if (file.exists()) {
                // 设置响应头，告诉浏览器这是一个Excel文件
                response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                // 设置响应头，告诉浏览器文件需要下载，而不是直接打开
                response.setHeader("Content-Disposition", "attachment; filename="+ URLEncoder.encode(file.getName(), "UTF-8"));
                // 获取文件输入流
                try(FileInputStream input = new FileInputStream(file);
                    OutputStream output = response.getOutputStream();) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    // 将文件内容写入输出流
                    while ((bytesRead = input.read(buffer)) != -1) {
                        output.write(buffer, 0, bytesRead);
                    }
                }catch (IOException e){
                    e.getMessage();
                }
            }else {
                throw new Exception();
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.reset();
            response.setContentType("application/json;charset=utf-8");
            response.setContentType("text/html;charset=UTF-8");  //这句太重要了
            PrintWriter out = response.getWriter();
            out.print("导出报表出现错误，请联系管理员");
            out.flush();
        }

    }


    /**
     * 分页查询部件重用
     * @param pageCount
     * @param request
     * @param response
     */
    @RequestMapping(value = "/partReuseSelect", method = RequestMethod.GET )
    public void partReuseSelect(@RequestParam("pageCount") Integer pageCount, @RequestParam("partName") String partName,
                                @RequestParam("partNumber") String partNumber,@RequestParam("param") Integer param,HttpServletRequest request,
                                HttpServletResponse response) throws IOException, WTException {
        response.setContentType("application/json;charset=UTF-8");
        System.out.println("接口请求参数：pageCount："+pageCount +" partName:"+partName+" partNumber:"+ partNumber+" param:"+ param);

        // 检查部件名称或编号是否有变化，如果有则重置页码为1
        boolean nameOrNumberChanged = !Objects.equals(request.getSession().getAttribute("lastPartName"), partName) ||
                !Objects.equals(request.getSession().getAttribute("lastPartNumber"), partNumber);
        if (nameOrNumberChanged) {
            pageCount = 1;
        }
        request.getSession().setAttribute("lastPartName", partName);
        request.getSession().setAttribute("lastPartNumber", partNumber);

        // 获得当前查询条件的总条目数
        Integer pageNumber = PartReuseService.partMasterLevelCount(PartReuseService.PAGE_SIZE, partName, partNumber, param);

        int totalPages = (pageNumber + PartReuseService.PAGE_SIZE - 1) / PartReuseService.PAGE_SIZE;
        System.out.println("[分页计算] 总页数: " + totalPages);

        System.out.println("当前条件查询的总数据数量："+pageNumber);
        List<WTPartMaster> partLevelBuyParam = PartReuseService.getPartLevelBuyParam(pageCount, PartReuseService.PAGE_SIZE, partName, partNumber, param);

        List<PartReuseShowVo> vos = PartReuseShowVo.getPartReuseShowVoByMasters(partLevelBuyParam, param);

        TableDataInfo dataTable = TableDataInfo.getDataTable(vos, pageNumber, pageCount, totalPages);

        String resultJson = objectMapper.writeValueAsString(dataTable);
        response.getWriter().write(resultJson);
    }





    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }
}
