package ext.alphai.reusepart.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.reusepart.bean.*;

import ext.alphai.reusepart.server.QuickRetrievalService;
import ext.alphai.reusepart.util.ClassificationUtil;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * 部件分类快速检索
 */
@Controller
@RequestMapping({ "/QuickRetrieval" })
public class QuickRetrievalController {
    static final ObjectMapper objectMapper = new ObjectMapper();


    /**
     * 获取条件查询当前分类的部件
 * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/getClassificationPart", method = RequestMethod.POST)
    public void getClassificationPart(HttpServletRequest request,
                                      HttpServletResponse response)throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("根据分类属性值查找部件接口");

        // 读取请求体中的JSON数据
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        String jsonStr = sb.toString();
        System.out.println("打印post数据：" + jsonStr);

        // 查询的请求参数
        List<QueryClassPartReqVo> vos = objectMapper.readValue(jsonStr, new TypeReference<List<QueryClassPartReqVo>>() {});
        String resultJson ;
        ResponseVo responseVo = new ResponseVo();

        String className = vos.get(0).getClassificationName();
        try {
            // 通过分类内部名获取显示名来判断传入的内部值是否有效
            String classificationdDisPlayName = ClassificationUtil.getClassificationdDisPlayName(className);
            System.out.println("分类节点内部名为："+className+"数据库中显示名为："+classificationdDisPlayName);
//            if(StringUtils.isBlank(classificationdDisPlayName)){
//                responseVo.setCode(400);
//                responseVo.setMsg("参数错误未找到这个分类");
//            }
//            else {
                // 调用方法
                List<QueryClassPartRespVo> queryClassPartByClassName = QuickRetrievalService.getQueryClassPartByClassName(className, vos);
                responseVo.setCode(200);
                responseVo.setMsg("操作成功");
                responseVo.setData(queryClassPartByClassName);
//            }
        }catch (Exception e){
            e.printStackTrace();
            responseVo.setCode(500);
            responseVo.setMsg("服务器内部异常");
        }
        resultJson = objectMapper.writeValueAsString(responseVo);
        System.out.println(resultJson);
        outResponse(response ,resultJson);
    }






    /**
     * 获取分类树
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/classificationTree", method = RequestMethod.GET )
    public void getClassificationTree(HttpServletRequest request,
                              HttpServletResponse response)throws IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("进入获取分类树结构接口");
        String resultJson ;
        ResponseVo responseVo = new ResponseVo();
        try {
            ClassificationTreeVo classificationTree = QuickRetrievalService.getClassificationTree();
            responseVo.setCode(200);
            responseVo.setMsg("操作成功");
            responseVo.setData(classificationTree);
        }catch (WTException e){
            responseVo.setCode(500);
            responseVo.setMsg("服务器内部异常");
        }
        resultJson = objectMapper.writeValueAsString(responseVo);
        System.out.println(resultJson);
        outResponse(response ,resultJson);
    }

    /**
     * 通过分类内部名获取所有属性列表
     * @param className 分类内部名
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/getClassAttribute", method = RequestMethod.GET )
    public void getAttribute(@RequestParam("className") String className, HttpServletRequest request, HttpServletResponse response)throws IOException{

        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("进入根据分类获取属性接口");
        String resultJson ;
        ResponseVo responseVo = new ResponseVo();
        try {
            // 通过分类内部名获取显示名来判断传入的内部值是否有效
            String classificationdDisPlayName = ClassificationUtil.getClassificationdDisPlayName(className);
            System.out.println("分类节点内部名为："+className+"数据库中显示名为："+classificationdDisPlayName);
//            if(StringUtils.isBlank(classificationdDisPlayName)){
//                responseVo.setCode(400);
//                responseVo.setMsg("参数错误未找到这个分类");
//            }
//            else {
                // 调用方法
                List<ClassificationAttributeVo> classAttribute = QuickRetrievalService.getClassAttribute(className);
                responseVo.setCode(200);
                responseVo.setMsg("操作成功");
                responseVo.setData(classAttribute);
//            }
        }catch (Exception e){
            e.printStackTrace();
            responseVo.setCode(500);
            responseVo.setMsg("服务器内部异常");
        }
        resultJson = objectMapper.writeValueAsString(responseVo);
        System.out.println(resultJson);
        outResponse(response ,resultJson);
    }






    public void outResponse(HttpServletResponse response, String json) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }
}
