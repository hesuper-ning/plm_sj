package ext.alphai.reusepart;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.reusepart.CustomRB_en_US")
public class CustomRB_en_US extends WTListResourceBundle {


    @RBEntry("部件重用等级")
    public static final String Part_Reuse_Level = "Part Reuse Level";

    @RBEntry("Component Reuse Report")
    public static final String PRIVATE_CONSTANT_1 = "navigation.jcReportForms.description";
    @RBEntry("Component Reuse Report")
    public static final String PRIVATE_CONSTANT_2 = "navigation.jcReportForms.tooltip";
    @RBEntry("paste_24.png")
    public static final String PRIVATE_CONSTANT_5 = "navigation.jcReportForms.icon";


    @RBEntry("Part Reuse Level")
    public static final String PRIVATE_CONSTANT_3 = "jcpartReuse.partReuseLevel.description";
    @RBEntry("Part Reuse Level")
    public static final String PRIVATE_CONSTANT_4 = "jcpartReuse.partReuseLevel.tooltip";




    @RBEntry("Component Reuse Report")
    public static final String PRIVATE_CONSTANT_6 = "jcpartReuse.partreuseForm.description";
    @RBEntry("Component Reuse Report")
    public static final String PRIVATE_CONSTANT_7 = "jcpartReuse.partreuseForm.tooltip";
    @RBEntry("flex_lifecycle.png")
    public static final String PRIVATE_CONSTANT_8 = "jcpartReuse.partreuseForm.icon";



    @RBEntry("A Level")
    public static final String PRIVATE_CONSTANT_9 = "jcpartReuse.LevelA.description";
    @RBEntry("A Level")
    public static final String PRIVATE_CONSTANT_10 = "jcpartReuse.LevelA.tooltip";
//    @RBEntry("flex_lifecycle.png")
//    public static final String PRIVATE_CONSTANT_11 = "jcpartReuse.LevelA.icon";

    @RBEntry("B Level")
    public static final String PRIVATE_CONSTANT_12 = "jcpartReuse.LevelB.description";
    @RBEntry("B Level")
    public static final String PRIVATE_CONSTANT_13 = "jcpartReuse.LevelB.tooltip";


    @RBEntry("C Level")
    public static final String PRIVATE_CONSTANT_14 = "jcpartReuse.LevelC.description";
    @RBEntry("C Level")
    public static final String PRIVATE_CONSTANT_15 = "jcpartReuse.LevelC.tooltip";


    @RBEntry("ALL Level")
    public static final String PRIVATE_CONSTANT_16= "jcpartReuse.AllLevel.description";
    @RBEntry("ALL Level")
    public static final String PRIVATE_CONSTANT_17 = "jcpartReuse.AllLevel.tooltip";


//    @RBEntry("add16x16.gif")
//    public static final String PRIVATE_CONSTANT_3 = "changeNotBom.addWizard.icon";


    @RBEntry("A.svg")
    public static final String PRIVATE_CONSTANT_20 = "jcpartReuse.LevelA.icon";
    @RBEntry("B.svg")
    public static final String PRIVATE_CONSTANT_21 = "jcpartReuse.LevelB.icon";
    @RBEntry("C.svg")
    public static final String PRIVATE_CONSTANT_22 = "jcpartReuse.LevelC.icon";

    @RBEntry("all.svg")
    public static final String PRIVATE_CONSTANT_23 = "jcpartReuse.AllLevel.icon";

    @RBEntry("Classification Quick Search")
    public static final String PRIVATE_CONSTANT_18= "jcpartReuse.jcquickSearch.description";
    @RBEntry("Classification Quick Search")
    public static final String PRIVATE_CONSTANT_19 = "jcpartReuse.jcquickSearch.tooltip";
}
