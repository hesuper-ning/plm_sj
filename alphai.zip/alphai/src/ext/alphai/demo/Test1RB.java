package ext.alphai.demo;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;
@RBUUID("ext.alphai.demo.Test1RB")
public class Test1RB extends WTListResourceBundle {


    @RBEntry("供应商(<U class='mnemonic'>S</U>)")
    public static final String PRIVATE_CONSTANT_10 = "newTable.firstNav.description";

    @RBEntry("主要选项卡:供应商")
    public static final String PRIVATE_CONSTANT_12 = "newTable.firstNav.tooltip";

    @RBEntry("navigator_home.png")
    public static final String PRIVATE_CONSTANT_14 = "newTable.firstNav.icon";


    @RBEntry("供应商列表1")
    public static final String PRIVATE_CONSTANT_15 = "newTable.list1.description";

    @RBEntry("供应商列表1")
    public static final String PRIVATE_CONSTANT_19 = "newTable.list1.tooltip";


    @RBEntry("供应商列表2")
    public static final String PRIVATE_CONSTANT_16 = "newTable.list2.description";
    @RBEntry("供应商列表2")
    public static final String PRIVATE_CONSTANT_20 = "newTable.list2.tooltip";

    @RBEntry("供应商列表3")
    public static final String PRIVATE_CONSTANT_17 = "newTable.list3.description";
    @RBEntry("供应商列表3")
    public static final String PRIVATE_CONSTANT_21 = "newTable.list3.tooltip";

    @RBEntry("供应商列表4")
    public static final String PRIVATE_CONSTANT_18 = "newTable.list4.description";

    @RBEntry("供应商列表4")
    public static final String PRIVATE_CONSTANT_22 = "newTable.list4.tooltip";
}
