package ext.alphai.globalPart.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.util.CommonUtil;
import wt.org.WTGroup;
import wt.org.WTUser;
import wt.session.SessionHelper;

/**
 * LD部件更改版本序列过滤器
 */
public class JYChangeCADVersionFilter extends DefaultSimpleValidationFilter {

    @Override
    public UIValidationStatus preValidateAction(UIValidationKey uiValidationKey, UIValidationCriteria uiValidationCriteria) {
        UIValidationStatus status = UIValidationStatus.HIDDEN;
        try {
            // 获取当前登录用户
            WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
            // 用户如果在LD组里展示
            String LDGroup = PropertiesUtil.getValueByKey("JY.user.group");
            System.out.println("JY组："+LDGroup);
            // 查询出全部报价任务
            String[] split = LDGroup.split(Constant.Comma);
            for (String string : split) {
//                System.out.println("循环JY组："+string);
                WTGroup wtGroup = CommonUtil.queryGroupByName(string);
                if (wtGroup.isMember(user)) {
                    UIValidationStatus enabled = UIValidationStatus.ENABLED;
//                    System.out.println("展示按钮");
                    return enabled;
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
            status = UIValidationStatus.HIDDEN;
        }
        return status;
    }
}
