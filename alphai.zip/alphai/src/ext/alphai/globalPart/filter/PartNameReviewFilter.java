package ext.alphai.globalPart.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.util.CommonUtil;
import wt.org.WTGroup;
import wt.org.WTUser;
import wt.session.SessionHelper;

/**
 * 全球物料物料名称审核二级菜单过滤器
 */
public class PartNameReviewFilter extends DefaultSimpleValidationFilter {
    public static final String AI_Part_Name_Approval_Group = "AI_Part_Name_Approval_Group";
    @Override
    public UIValidationStatus preValidateAction(UIValidationKey uiValidationKey, UIValidationCriteria uiValidationCriteria) {
        UIValidationStatus status = UIValidationStatus.HIDDEN;
        try {
            // 获取当前登录用户
            WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
            // 用户如果在LD组里展示
//            String LDGroup = PropertiesUtil.getValueByKey("LD.copyDesignIBA.group");
////            System.out.println("LD拷贝Design部件组："+LDGroup);
//            // 查询出全部报价任务
//            String[] split = LDGroup.split(Constant.Comma);
//            for (String string : split) {
//                System.out.println("循环LD组："+string);
                WTGroup wtGroup = CommonUtil.queryGroupByName(AI_Part_Name_Approval_Group);
                if (wtGroup.isMember(user)) {
                    UIValidationStatus enabled = UIValidationStatus.ENABLED;
//                    System.out.println("展示按钮");
                    return enabled;
                }
//            }
        }catch (Exception e) {
            e.printStackTrace();
            status = UIValidationStatus.HIDDEN;
        }
        return status;
    }
}
