package ext.alphai.globalPart.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.util.CommonUtil;
import wt.fc.Persistable;
import wt.org.WTGroup;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.session.SessionHelper;

import java.util.Arrays;
import java.util.List;

/**
 * 设计视图拷贝属性按钮屏蔽
 */
public class CopyDesignToThisMPartIBAFilter extends DefaultSimpleValidationFilter {

    public static final List<String> MPartView = Arrays.asList(new String[]{"3101", "3188", "Manufacturing"});


    @Override
    public UIValidationStatus preValidateAction(UIValidationKey uiValidationKey, UIValidationCriteria uiValidationCriteria) {
        UIValidationStatus status = UIValidationStatus.HIDDEN;
        try {
            // 获取当前登录用户
            Persistable persistable = uiValidationCriteria.getContextObject().getObject();
            if(persistable instanceof WTPart){
                WTPart part = (WTPart) persistable;
                String partView = part.getView().getName();
//                System.out.println("工厂视图过滤器：当前部件视图:"+partView);
                if(MPartView.contains(partView)){
                    UIValidationStatus enabled = UIValidationStatus.ENABLED;
                    return enabled;
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
            status = UIValidationStatus.HIDDEN;
        }
        return status;
    }
}
