package ext.alphai.globalPart.servcie;

import com.ptc.core.lwc.common.dynamicEnum.EnumerationEntryInfo;
import com.ptc.core.lwc.common.view.*;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.windchill.csm.client.helpers.CSMTypeDefHelper;
import com.ptc.windchill.csm.common.CsmConstants;
import com.ptc.windchill.enterprise.part.commands.AssociationLinkObject;
import com.ptc.windchill.enterprise.part.commands.PartDocServiceCommand;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.domain.AIGlossary;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.alphai.globalPart.vo.AttrCnEnGeVo;
import ext.alphai.globalPart.vo.ClassifyDataVo;
import ext.alphai.globalPart.vo.ResponseVo;
import ext.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.epm.EPMDocument;
import wt.facade.classification.ClassificationFacade;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.pom.WTConnection;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.part.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 通用服务方法
 */
public class GeneralService {
    private static final Logger logger = LogManager.getLogger(GeneralService.class);
    private static final String LogicDATA = "LOGICDATA";

    private static final String jieCang = "jiecang";
    /**
     * 获取三语错误信息
     * @param cn
     * @param en
     * @param de
     * @return
     */
    public static String getTrilingualErrMsg(String cn, String en ,String de , Locale locale){
        String result = "";
        if(Locale.CHINESE.equals(locale)){
            result = cn;
        } else if (Locale.UK.equals(locale)) {
            result = en;
        } else if(Locale.GERMAN.equals(locale)){
            result = de;
        }
        return result;
    }


    public static void updateAndVerificationPart(WTPart part) throws WTException {
        Locale locale = SessionHelper.getLocale();
        WTPartMaster partMaster = part.getMaster();
        IBAUtil iba = new IBAUtil(part);
        String cnName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.JCCNNAME"));




        String hostLangName = cnName;
        int length = hostLangName.length();
        if(length > Constant.partNameLength ){
            throw new WTException(getTrilingualErrMsg("部件主语言名称超过40字符", "The main language name of the component exceeds 40 characters", "Widget-Hauptsprachennamen mit mehr als 40 Zeichen", locale));
        }
        if(!allowRepeat(iba)){
            String reusePartNumber = checkPartNameReuse(part, hostLangName);
            if (!reusePartNumber.isEmpty()  ) {
                throw new WTException(hostLangName+"\r\n"+"部件名称已在系统中存在 编号："+reusePartNumber);
            }
        }
        // PersistenceHelper.manager.refresh(partMaster);
        if(!part.getName().equals(hostLangName)){
            // 需要修改部件名称时要同步部件三语IBA
            PartUtil.changePartName(part, hostLangName);
        }
    }

    //获取允许创建重复名称的部件
    public static boolean allowRepeat(IBAUtil iba) {
        String customerSupplied = iba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.AI_Customer_Supplied"));
        String allowValuesStr = PropertiesUtil.getValueByKey("part.iba.AI_Customer_Supplied.allowValue");

        // 处理配置值为空的情况
        if (allowValuesStr == null || allowValuesStr.trim().isEmpty()) {
            return false;
        }

        String[] allowValues = allowValuesStr.split(",");

        // 遍历允许值数组，检查是否包含customerSupplied
        for (String allowValue : allowValues) {
            if (allowValue != null && allowValue.trim().equals(customerSupplied)) {
                return true;
            }
        }

        return false;
    }


    // 部件的序号属性所在的两个字符串
    // 目前是约定的 后两位
    /**
     *
     * @param AICount
     * @param mainLangName
     * @param partoid
     */
    public static ResponseVo hostLangRepeatabilityVerification(String mainLangName, String AICount, String partoid) throws WTException {
        // 当前用户的语言环境 涉及到报错信息的语言
        Locale locale = getUserHostLanguage();
//        logger.info("当前部件主语言名称为：{}", mainLangName);
        int ORDER_NUM = AICount.length();
        // 截取后几个字符
        Integer orderNumInt = Integer.parseInt(AICount);
        int length = mainLangName.length();
        if(length > Constant.partNameLength){
            return ResponseVo.error(400, getTrilingualErrMsg("部件主语言名称超过40字符", "The main language name of the component exceeds 40 characters", "Widget-Hauptsprachennamen mit mehr als 40 Zeichen", locale));
        }

        long partIda2a2 = 0L;
        WTPart part = null;
        if(StringUtils.isBlank(partoid)){
            // 新建

        }else {
            // 修改
            WTObject object = PersistenceUtil.oid2Object(partoid);
            if(object != null){
                part = (WTPart)object;
                partIda2a2 = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
            }
        }
        String reusePartNumber = checkPartNameReuse(part, mainLangName);
        if (!reusePartNumber.isEmpty()) {
            return ResponseVo.error(400, mainLangName+"\r\n"+getTrilingualErrMsg("部件名称已在系统中存在 编号："+reusePartNumber, "The component name already exists in the system："+reusePartNumber, "Der Komponentenname existiert bereits im System："+reusePartNumber, locale));
        }

        // 前缀序号校验
        String namePrefix = mainLangName.substring(0, length - ORDER_NUM);
        // 相似前缀的所有序号 除开完全同名的
        List<Integer> sameNamePrefixOrder = new ArrayList<>();

        WTConnection conn = CommonUtil.getWTConnection();
        String sql = "SELECT * FROM WTPARTMASTER WHERE NAME LIKE ? AND LENGTH(NAME) = ?";
        // 创建PreparedStatement
        try (PreparedStatement stmt = conn.prepareStatement(sql);){
            stmt.setString(1, namePrefix + "%"); // 设置前缀匹配
            stmt.setInt(2, length); // 设置长度匹配

            // 执行查询
            ResultSet rs = stmt.executeQuery();

            // 输出查询结果
            while (rs.next()) {
                long dbIda2a2 = rs.getLong("IDA2A2");
                String dbPartName = rs.getString("NAME");
                if(dbIda2a2 == partIda2a2){
                    continue;
                }
                String dbOrderNum = dbPartName.substring(length - ORDER_NUM);
                sameNamePrefixOrder.add(Integer.parseInt(dbOrderNum));
            }
            rs.close();
        }catch (Exception e){
            e.printStackTrace();
            throw new WTException(e.getMessage());
        }
        // 理论上应该选的序号
        String adjustOrderNumString = adjustOrderNumInt(sameNamePrefixOrder, orderNumInt, ORDER_NUM);

        if(adjustOrderNumString.equals(AICount)){
            if("01".equals(AICount)){
                return ResponseVo.success(200,getTrilingualErrMsg("成功", "success", "Erfolgreich", locale));
            }else {
                return ResponseVo.success(300,getTrilingualErrMsg("相同前缀部件已经存在是否重复创建","Does the same prefix part already exist and need to be created repeatedly","Ist der gleiche Präfixteil bereits vorhanden und muss wiederholt erstellt werden",locale));
            }

        }else {
            return ResponseVo.error(301, getTrilingualErrMsg("系统中已存在相似部件，若您坚持创建则序号应该选择："+adjustOrderNumString+" 后再提交", "Similar components already exist in the system. If you insist on creating them, the serial number should be selected："+adjustOrderNumString+" Resubmit", "Ähnliche Komponenten existieren bereits im System, wenn Sie darauf bestehen, sie zu erstellen, sollte die Seriennummer ausgewählt werden："+adjustOrderNumString+ " Wieder einreichen", locale));
        }
    }



    /**
     * 校验部件名称 规则 通过校验修改部件名称
     * 1.主语言名称 名称不能完全重复
     * 2.最后的 轴承-冷冻轴承-6399-2-3-4-6-04     04 后缀必须顺序排列 去最后两字符
     * 3.轴承-冷冻轴承-6399-2-3-4-6-  允许修改名称但要提醒
     * @param part
     */
    public static void hostLangRepeatabilityVerification(WTPart part) throws WTException {
        // 当前用户的语言环境 涉及到报错信息的语言
        Locale locale = getUserHostLanguage();
        IBAUtil iba = new IBAUtil(part);
        String hostLangName = "";
        WTPartMaster partMaster = part.getMaster();
        IBAUtil masterIBA = new IBAUtil(partMaster);
        // 部件IDA2A2
        long partIda2a2 = part.getMaster().getPersistInfo().getObjectIdentifier().getId();

        // 部件主语言
        String hostLang = masterIBA.getIBAValue(PropertiesUtil.getValueByKey("part.master.host.lang"));
//        logger.info("当前部件选择的主语言为：{}", hostLang);

        if(StringUtils.isBlank(hostLang)){
            hostLang = getUserPrimaryLanguage();
        }
        // 主语言部件名

        String cnName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.JCCNNAME"));
        String enName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEEN"));
//        String geName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEDE"));
        if(Constant.CREATE_LANG_CN.equals(hostLang)){
            hostLangName = cnName;
        } else if (Constant.CREATE_LANG_EN.equals(hostLang)) {
            hostLangName = enName;
        }
//        else if (Constant.CREATE_LANG_DN.equals(hostLang)){
//            hostLangName = enName;
//        }
        else {
            String errMsg = "";
            throw new WTException(getTrilingualErrMsg("未选择部件创作语言", "No component creation language selected" , "Keine Widget-Erstellungssprache ausgewählt", locale));
        }
        // 部件序号
        String orderNum = iba.getIBAValue(PropertiesUtil.getValueByKey("part.count"));
        // 允许配置
        String partDuplicateNames = iba.getIBAValue(PropertiesUtil.getValueByKey("part.allow.duplicateNames"));
        logger.info("当前部件是否允许重名:{}", partDuplicateNames);

        if( "真".equals(partDuplicateNames)|| "True".equals(partDuplicateNames)|| "".equals(partDuplicateNames)){
            // 正常校验
            // 如果部件没有序号 说明不满足
            if(StringUtils.isBlank(orderNum)){
                // 如果没有防重技术号就直接判断主语言名称是否有重复
                String reusePartNumber = checkPartNameReuse(part, hostLangName);
                if (!reusePartNumber.isEmpty()) {
                    throw new WTException(hostLangName+"\r\n"+getTrilingualErrMsg("部件名称已在系统中存在 编号："+reusePartNumber, "The component name already exists in the system："+reusePartNumber, "Der Komponentenname existiert bereits im System："+reusePartNumber, locale));
                }
            }else {
                // 最终序号
                String adjustOrderNumString = orderNum;
                int ORDER_NUM = orderNum.length();
                // 截取后几个字符
                Integer orderNumInt = Integer.parseInt(orderNum);

//        logger.info("当前部件主语言名称为：{}", hostLangName);

                int length = hostLangName.length();
                if(length > Constant.partNameLength){
                    throw new WTException(getTrilingualErrMsg("部件主语言名称超过40字符", "The main language name of the component exceeds 40 characters", "Widget-Hauptsprachennamen mit mehr als 40 Zeichen", locale));
                }
                String reusePartNumber = checkPartNameReuse(part, hostLangName);
                if (!reusePartNumber.isEmpty()) {
                    throw new WTException(hostLangName+"\r\n"+getTrilingualErrMsg("部件名称已在系统中存在 编号："+reusePartNumber, "The component name already exists in the system："+reusePartNumber, "Der Komponentenname existiert bereits im System："+reusePartNumber, locale));
                }else {
                    // 检查后缀是否顺序
                    // 获取主语言名称的最后两个字符 代表序号 这个序号的位置是约定的

                    // 截取前面的部分
                    String namePrefix = hostLangName.substring(0, length - ORDER_NUM);
                    // 相似前缀的所有序号 除开完全同名的
                    List<Integer> sameNamePrefixOrder = new ArrayList<>();

                    WTConnection conn = CommonUtil.getWTConnection();
                    String sql = "SELECT * FROM WTPARTMASTER WHERE NAME LIKE ? AND LENGTH(NAME) = ?";
                    // 创建PreparedStatement
                    try (PreparedStatement stmt = conn.prepareStatement(sql);){
                        stmt.setString(1, namePrefix + "%"); // 设置前缀匹配
                        stmt.setInt(2, length); // 设置长度匹配

                        // 执行查询
                        ResultSet rs = stmt.executeQuery();

                        // 输出查询结果
                        while (rs.next()) {
                            long dbIda2a2 = rs.getLong("IDA2A2");
                            String dbPartName = rs.getString("NAME");
                            if(dbIda2a2 == partIda2a2){
                                continue;
                            }
                            String dbOrderNum = dbPartName.substring(length - ORDER_NUM);
                            try {
                                int num = Integer.parseInt(dbOrderNum);
                                sameNamePrefixOrder.add(num);
                            } catch (NumberFormatException e) {
                                // 处理异常，比如给出错误提示或者设置默认值
                            }
                        }
                        rs.close();
                    }catch (Exception e){
                        e.printStackTrace();
                        throw new WTException(e.getMessage());
                    }
                    // 顺序排列
                    // 检查项目序号是否顺序 如果非顺序 不强行修改序号 而是弹出异常
                    adjustOrderNumString = adjustOrderNumInt(sameNamePrefixOrder, orderNumInt, ORDER_NUM);
                    if(!adjustOrderNumString.equals(orderNum)){
                        // 抛出必填 序号
                        throw new WTException(getTrilingualErrMsg("系统中已存在相似部件，若您坚持创建则序号应该选择："+adjustOrderNumString+" 后再提交", "Similar components already exist in the system. If you insist on creating them, the serial number should be selected："+adjustOrderNumString+" Resubmit", "Ähnliche Komponenten existieren bereits im System, wenn Sie darauf bestehen, sie zu erstellen, sollte die Seriennummer ausgewählt werden："+adjustOrderNumString+ " Wieder einreichen", locale));
                    }
//            hostLangName = namePrefix + adjustOrderNumString;
                }
                // 如果 根据序号分析后的部件名称与原名称不符 就修改部件名称
//        PersistenceHelper.manager.refresh(partMaster);
            }
        }




        if(!part.getName().equals(hostLangName)){
            // 需要修改部件名称时要同步部件三语IBA
            PartUtil.changePartName(part, hostLangName);
        }
    }

    /**
     * 判定同前缀名序号 是否符合 序号顺序排列规则 如果不符合 则强制将序号从小到大 或者插孔占用较小的序号
     * @param sameNamePrefixOrder
     * @param orderNumInt
     */
    public static String adjustOrderNumInt(List<Integer> sameNamePrefixOrder, int orderNumInt, int orderLength) {
        String number = "";
        // 确保列表已排序
        Collections.sort(sameNamePrefixOrder);

        int minGap = 1;
        for (int num : sameNamePrefixOrder) {
            if (num == minGap) {
                minGap++;
            } else if (num > minGap) {
                break;
            }
        }

        int max = sameNamePrefixOrder.isEmpty() ? 0 : sameNamePrefixOrder.get(sameNamePrefixOrder.size() - 1);

        if (minGap <= max) {
            if (orderNumInt != minGap) {
                logger.info("提示：orderNumInt 从 {} 调整为 {}", orderNumInt, minGap);
                orderNumInt = minGap;
            }
        } else {
            if (orderNumInt > max) {
                int newValue = max + 1;
                logger.info("提示：orderNumInt 从 {} 调整为 {}", orderNumInt, newValue);
                orderNumInt = newValue;
            }
        }

        // 排序后补零
        number = String.format("%0" + orderLength + "d", orderNumInt);
        return number;
    }




    /**
     * 新增和修改 检查部件名称是否有重复
     * @param partName
     * @return true 是有重复 false 无重复
     */
//    public static String checkPartNameReuse(WTPart part, String partName) throws WTException{
//        String sql = "SELECT IDA2A2, WTPARTNUMBER FROM WTPARTMASTER WHERE NAME = ?";
//        ResultSet resultSet = CommonUtil.excuteSelect(sql, partName);
//        String reusePartNumber = "";
//
//        try {
//            if (part == null) {
//                boolean result = resultSet.next();
//                if (result) {
//                    reusePartNumber = resultSet.getString("WTPARTNUMBER");
//                }
//            }
//            else {
//                long currentId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
//                while (resultSet.next()) {
//                    long recordId = resultSet.getLong("IDA2A2");
//                    if (recordId != currentId) {
//                        String partNumber = resultSet.getString("WTPARTNUMBER");
//                        if (StringUtils.isNotBlank(partNumber)) {
//                            //获取最新部件
//                            WTPart wtPartByNumber = PartUtil.getWTPartByNumber(partNumber);
//                            IBAUtil iba = new IBAUtil(wtPartByNumber);
//                            //不允许重复
//                            if (!allowRepeat(iba)) {
//                                //
//                                reusePartNumber = partNumber;
//                                return reusePartNumber;
//                            }
//                        }
//                    }
//                }
//            }
//
//
//        } catch (SQLException e){
//            e.printStackTrace();
//            throw new WTException(e.getMessage());
//        }
//        return reusePartNumber;
//
//    }


    /**
     * 检查部件名称是否重复（创建时part为null，修改时part为当前部件）
     * @param part 当前部件（创建时为null，修改时为当前编辑的部件）
     * @param partName 部件名称
     * @return 如果不允许重复，返回重复部件的编号；否则返回空字符串
     */
    public static String checkPartNameReuse(WTPart part, String partName) throws WTException {
        if (StringUtils.isBlank(partName)) {
            return "";
        }

        String sql = "SELECT IDA2A2, WTPARTNUMBER FROM WTPARTMASTER WHERE NAME = ?";
        ResultSet resultSet = null;
        String duplicatePartNumber = "";

        logger.info("=== 开始检查部件名称重复 ===");
        logger.info("检查名称: {}", partName);
        logger.info("当前部件: {}", (part != null ? part.getNumber() : "null (新建)"));

        try {
            Long currentId = null;
            if (part != null && part.getMaster() != null) {
                currentId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
            }

            resultSet = CommonUtil.excuteSelect(sql, partName);

            int totalRecords = 0;
            int allowRepeatCount = 0;
            int notAllowRepeatCount = 0;

            while (resultSet.next()) {
                totalRecords++;
                long recordId = resultSet.getLong("IDA2A2");

                if (currentId != null && recordId == currentId) {
                    logger.info("跳过当前部件，ID: {}", recordId);
                    continue;
                }

                String partNumber = resultSet.getString("WTPARTNUMBER");
                logger.info("\n检查历史部件: {}, ID: {}", partNumber, recordId);

                if (StringUtils.isBlank(partNumber)) {
                    logger.info("部件编号为空，跳过");
                    continue;
                }

                WTPart existingPart = PartUtil.getWTPartByNumber(partNumber);
                if (existingPart == null) {
                    logger.info("未找到部件对象，跳过");
                    continue;
                }

                IBAUtil iba = new IBAUtil(existingPart);
                boolean allow = allowRepeat(iba);

                logger.info("allowRepeat结果: {}", allow);

                if (!allow) {
                    notAllowRepeatCount++;
                    duplicatePartNumber = partNumber;
                    logger.info("发现不允许重复的部件: {}", partNumber);
                    break;
                } else {
                    allowRepeatCount++;
                    logger.info("部件允许重复: {}", partNumber);
                }
            }

            logger.info("\n检查结果汇总:");
            logger.info("总同名记录数: {}", totalRecords);
            logger.info("允许重复的部件数: {}", allowRepeatCount);
            logger.info("不允许重复的部件数: {}", notAllowRepeatCount);
            logger.info("最终结果: {}", (StringUtils.isNotBlank(duplicatePartNumber) ? "存在冲突，冲突部件:" + duplicatePartNumber : "无冲突"));
            logger.info("===============================");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResultSet(resultSet);
        }

        return duplicatePartNumber;
    }



    /**
     * 关闭ResultSet资源
     */
    private static void closeResultSet(ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 判断部件是否允许名称重复
     * @param iba 部件IBA属性工具类
     * @return true-允许重复，false-不允许重复
     */
    private static boolean isAllowRepeat(IBAUtil iba) {
        // 根据实际业务逻辑判断
        // 示例：如果部件状态为"已发布"则不允许重复
        // String state = iba.getIBAValue("状态");
        // return !"已发布".equals(state);

        // 请根据实际业务实现
        return false;
    }
















    /**
     * 创建 修改部件时获取所填属性值的中英德三语显示名
     * @param className
     * @param attrName
     * @param enumName 一个分类属性有且只有一个枚举
     * @param attrValue 参数值 如果是枚举就是内部值 非枚举就是显示值
     * @param type
     * @param partHostLanguage 部件默认主语言
     * @return
     */
    public static AttrCnEnGeVo selectAttrTermDisplayName(String className, String attrName, String enumName, String attrValue,String type, String partHostLanguage) throws WTException, SQLException {
//        Locale locale = getUserHostLanguage();
//        TypeDefinitionReadView nodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, "com.ptc.csm.default_clf_namespace",className);
        logger.info("传入的值为：{}", attrValue);
        logger.info("传入的type值为：{}", type);
        logger.info("传入的分类属性内部值为：{}", attrName);
        AttrCnEnGeVo attrCnEnGeVo = new AttrCnEnGeVo(attrValue, attrValue, attrValue);
        // 如果是输入框 查找术语库
        if(Constant.INPUT.equals(type)){
            AIGlossary aiGlossaryByLag = AIGlossaryService.getAIGlossaryByLang(attrValue, partHostLanguage);
            String chineseTerm = aiGlossaryByLag.getChineseTerm();
            String englishTerm = aiGlossaryByLag.getEnglishTerm();
            String germanTerm = aiGlossaryByLag.getGermanTerm();
            if(!StringUtils.isBlank(chineseTerm)){
                attrCnEnGeVo.setCnName(chineseTerm);
            }
            if(!StringUtils.isBlank(englishTerm)){
                attrCnEnGeVo.setEnName(englishTerm);
            }
            if(!StringUtils.isBlank(germanTerm)){
                attrCnEnGeVo.setGeName(germanTerm);
            }

            return attrCnEnGeVo;
        }

        // 获取分类属性
        Set<AttributeTypeIdentifier> allClassInterName = ClassificationUtil.getAllClassInterName(className);


        for (AttributeTypeIdentifier identifier : allClassInterName) {
            AttributeDefinitionReadView attributeDefinitionReadView = ClassificationUtil.getClassAttDisplayName(className, identifier.getAttributeName());
            String attrReadViewName = attributeDefinitionReadView.getName();
            logger.info("当前循环到分类属性：{}", attrReadViewName);
            if(attrName.equals(attrReadViewName)){
                String constraintClassname = "";
                Collection<ConstraintDefinitionReadView> constraints1 = attributeDefinitionReadView.getAllConstraints();
                for (ConstraintDefinitionReadView ci : constraints1) {
                    constraintClassname = ci.getRule().getRuleClassname();
                    if ("com.ptc.core.meta.container.common.impl.DiscreteSetConstraint".equals(constraintClassname)) {
                        EnumerationDefinitionReadView enumDef = ci.getEnumDef();
                        if(enumDef != null){
                            String enumNameDef = enumDef.getName();
                            logger.info("判断为枚举约束枚举内部值为：{}", enumDef.getName());
//                            if(enumNameDef.equals(enumName)){
                            // 当前属性是枚举值
                            Map<String, EnumerationEntryReadView> allEnumerationEntries = enumDef.getAllEnumerationEntries();
                            EnumerationEntryReadView enumerationEntryReadView = allEnumerationEntries.get(attrValue);
                            String chinaName = PropertyHolderHelper.getDisplayName(enumerationEntryReadView, Locale.CHINESE);
                            // 2025 5 28 修改新需求枚举英文名称为 内部值
                            String enName = enumerationEntryReadView.getName();
//                                String enName = PropertyHolderHelper.getDisplayName(enumerationEntryReadView, Locale.UK);
                            String geName = PropertyHolderHelper.getDisplayName(enumerationEntryReadView, Locale.GERMAN);
                            if(!StringUtils.isBlank(chinaName)){
                                attrCnEnGeVo.setCnName(chinaName);
                            }
                            if(!StringUtils.isBlank(enName)){
                                attrCnEnGeVo.setEnName(enName);
                            }
                            if(!StringUtils.isBlank(geName)){
                                attrCnEnGeVo.setGeName(geName);
                            }
                            return attrCnEnGeVo;
//                            }


                        }

                    }

                }
            }


        }



        return attrCnEnGeVo;
    }




    /**
     * 获取所有可实例分类节点
     * @return
     */
    public static List<ClassifyDataVo> getClassify() throws WTException {

        // 获取根分类
        TypeDefinitionReadView rootClassification = getTopClassification();

        return getCanBeExemplified(rootClassification);

    }

    /**
     * 递归获取所有可实例分类节点（包含子树中的可用节点）
     * @param rootClassification 根分类节点
     * @return 所有可用节点列表
     */
    public static List<ClassifyDataVo> getCanBeExemplified(TypeDefinitionReadView rootClassification) throws WTException {
        List<ClassifyDataVo> vos = new ArrayList<>();
        //当前用户语言类型
        Locale locale = getUserHostLanguage();
        // 启动递归遍历
        recursiveGetCanBeExemplified(rootClassification, vos, locale);
        // 根据排序顺序字段sortOrder 进行集合排序
        Collections.sort(vos, Comparator.nullsLast(Comparator.comparingInt(ClassifyDataVo::getSortOrder)));
        return vos;
    }


    /**
     * 递归遍历分类节点
     * @param currentClassification 当前处理的分类节点
     * @param resultList 结果收集列表
     */
    private static void recursiveGetCanBeExemplified(TypeDefinitionReadView currentClassification, List<ClassifyDataVo> resultList, Locale locale) throws WTException {
        ClassificationFacade facadeInstance = ClassificationFacade.getInstance();
        Object classificationNodeInfo = facadeInstance.getClassificationNodeInfo(currentClassification.getName(),
                "AI_PartClassification");
        EnumerationEntryInfo entryInfo = (EnumerationEntryInfo)classificationNodeInfo;
        Boolean selectable = (Boolean) entryInfo.getNonLocalizablePropertyValue(EnumerationEntryInfo.SELECTABLE);

        // 1. 处理当前节点
        if (selectable) {
            ClassifyDataVo vo = new ClassifyDataVo();
            Integer sortOrder = (Integer) entryInfo.getNonLocalizablePropertyValue(EnumerationEntryInfo.SORT_ORDER);
            vo.setClassifyName(currentClassification.getName());
            // 根据用户邮箱后缀获得返回的节点名称的语言类型

            vo.setClassifyDisplayName(PropertyHolderHelper.getDisplayName(currentClassification, locale));
            vo.setSortOrder(sortOrder);
            resultList.add(vo);
        }

        // 2. 递归处理所有子节点
        Collection<TypeDefinitionReadView> childClassifications = CSMTypeDefHelper.getChildTypeDefViews(currentClassification);
        for (TypeDefinitionReadView child : childClassifications) {
            recursiveGetCanBeExemplified(child, resultList, locale);
        }
    }



    /**
     * 获取根节点
     * @return
     * @throws WTException
     */
    public static TypeDefinitionReadView getTopClassification() throws WTException {
        Collection<TypeDefinitionReadView> topClassification = CSMTypeDefHelper.getRootTypeDefViews("AI_PartClassification");
        Iterator<TypeDefinitionReadView> itera = topClassification.iterator();
        return itera.hasNext() ? (TypeDefinitionReadView)itera.next() : null;
    }


    /**
     * 获取当前用户主语言 20250924 JC元素方法
     * @return
     */
//     public static Locale getUserHostLanguage(){
//         Locale result = Locale.UK;
//         try {
//             WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
//             // 由于windchill11没有用户说明字段 先用Email代替
//             String userDescribe = user.getDescription();
// //            String userDescribe = user.getEMail();
// //            System.out.println("当前用户的用户名："+user.getFullName()+"v说明："+userDescribe);
//             String CHINA = (String)PreferenceHelper.service.getValue(Constant.User_Language_CHINA, Constant.WINDCHILL);
//             String ENGLISH = (String)PreferenceHelper.service.getValue(Constant.User_Language_ENGLISH, Constant.WINDCHILL);
// //            String GERMAN = (String)PreferenceHelper.service.getValue(Constant.User_Language_GERMAN, Constant.WINDCHILL);

//             // 使用 Arrays.asList 替代 List.of
//             List<String> chinaSign = new ArrayList<>(Arrays.asList(CHINA.split(Constant.STRING_COMMA)));
//             List<String> englishSign = new ArrayList<>(Arrays.asList(ENGLISH.split(Constant.STRING_COMMA)));
// //            List<String> germanSign = new ArrayList<>(Arrays.asList(GERMAN.split(Constant.STRING_COMMA)));

//             if(chinaSign.contains(userDescribe)){
//                 return Locale.CHINESE;
//             } else if (englishSign.contains(userDescribe)) {
//                 return Locale.UK;
//             }
// //            else if (germanSign.contains(userDescribe)) {
// //                return Locale.GERMAN;
// //            }
//         } catch (WTException e) {
//             e.printStackTrace();
//         }


//         return result;
//     }

    /**
     * 获取当前用户主语言 20250924 智通定制元素方法
     * @return
     */
    public static Locale getUserHostLanguage(){
        Locale result = Locale.CHINESE;
        return result;
    }





    public static String checkUrlOperation(String urlString) {
        try {
            URI uri = new URI(urlString);
            String path = uri.getPath(); // 获取路径部分（如 "/Windchill/ptc1/part/createPartWizard"）

            // 分割路径并过滤空字符串
            List<String> segments = Arrays.stream(path.split(Constant.Slash))
                    .filter(seg -> !seg.isEmpty())
                    .collect(Collectors.toList());

            if (segments.isEmpty()) {
                return Constant.STRING_BLANK;
            }

            String lastSegment = segments.get(segments.size() - 1);
            if (Constant.CreatePartWizard.equals(lastSegment)) {
                return Constant.CreatePartWizard;
            } else if (Constant.Edit.equals(lastSegment)) {
                return Constant.Edit;
            } else {
                return Constant.STRING_BLANK;
            }
        } catch (URISyntaxException e) {
            return Constant.STRING_BLANK;
        }
    }

    /**
     * 用户创建部件 设置部件主语言采用依据
     * @return
     * @throws WTException
     */
//     public static String getUserPrimaryLanguage() throws WTException {

//         WTUser sessionUser = (WTUser) SessionHelper.manager.getPrincipal();
// //        System.out.println("check access for user:" + sessionUser.getName());

//         String userDescribe = sessionUser.getDescription();

//         String CHINA = (String)PreferenceHelper.service.getValue(Constant.User_Language_CHINA, Constant.WINDCHILL);
//         String ENGLISH = (String)PreferenceHelper.service.getValue(Constant.User_Language_ENGLISH, Constant.WINDCHILL);
// //        String GERMAN = (String)PreferenceHelper.service.getValue(Constant.User_Language_GERMAN, Constant.WINDCHILL);

//         // 使用 Arrays.asList 替代 List.of
//         List<String> chinaSign = new ArrayList<>(Arrays.asList(CHINA.split(Constant.STRING_COMMA)));
//         List<String> englishSign = new ArrayList<>(Arrays.asList(ENGLISH.split(Constant.STRING_COMMA)));
// //        List<String> germanSign = new ArrayList<>(Arrays.asList(GERMAN.split(Constant.STRING_COMMA)));

// //        String desc = sessionUser.getEMail();
// //        System.out.println("当前用户的用户名："+sessionUser.getFullName()+"v说明："+userDescribe);
// //        if (germanSign.contains(userDescribe)) {
// //            return Constant.CREATE_LANG_DN;
// //        } else
//         if (chinaSign.contains(userDescribe)) {
//             return Constant.CREATE_LANG_CN;
//         } else if (englishSign.contains(userDescribe)){
//             return Constant.CREATE_LANG_EN;
//         }else {
//             return Constant.CREATE_LANG_EN;
//         }
//     }


    public static String getUserPrimaryLanguage() throws WTException {

        WTUser sessionUser = (WTUser) SessionHelper.manager.getPrincipal();
        logger.info("check access for user:{}", sessionUser.getName());

        String desc = sessionUser.getDescription();
//        String desc = sessionUser.getEMail();
        logger.info("当前新建的信息是：{}", desc);
        if (StringUtils.equalsIgnoreCase(desc, LogicDATA)) {
            return Constant.CREATE_LANG_DN;
        } else if (StringUtils.equalsIgnoreCase(desc, jieCang)) {
            return Constant.CREATE_LANG_CN;
        } else {
            return Constant.CREATE_LANG_EN;
        }
    }


    /**
     * 将字符串的null 转换成blank
     * @param value
     * @return
     */
    public static String replaceNullToBlank(String value){
        value = value == null ? Constant.STRING_BLANK : value;
        return value;
    }




    /**
     * 部件与CAD文档， 说明关系 通过部件获取CAD文档，可能包含3D和2D
     * 1）如果是结构部件，找结构3D图纸 CADCOMPONENT & PROE
     * 2）如果是PCBA，找ECAD图纸
     * 3）如果是软件部件，找autocad图纸
     *
     * @param part
     * @throws Exception
     */
    public static List<EPMDocument> getAllCADByPart(WTPart part) throws Exception {
        QueryResult qr = null;
        List<EPMDocument> docs = new ArrayList<EPMDocument>();
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();
            //qr = WTPartHelper.service.getDescribedByDocuments(part);// CAD文档
            Collection cadDocumentsAndLinks = PartDocServiceCommand.getAssociatedCADDocumentsAndLinks(part);
            for (Object object : cadDocumentsAndLinks) {
                if (object instanceof AssociationLinkObject) {
                    AssociationLinkObject alo = (AssociationLinkObject) object;
                    EPMDocument doc = alo.getCadObject();
                    docs.add(doc);
                }
            }

        } catch (WTException e) {
            e.printStackTrace();
            throw new Exception("No 3D CAD Document on Part :" + part.getName());
        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return docs;
    }


}
