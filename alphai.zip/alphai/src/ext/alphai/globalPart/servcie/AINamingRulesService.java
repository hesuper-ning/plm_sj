package ext.alphai.globalPart.servcie;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.PropertyHolderHelper;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.LWCStructEnumAttTemplate;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.domain.AINamingRules;
import ext.alphai.globalPart.vo.AttrCnEnGeVo;
import ext.alphai.globalPart.vo.ClassifyAttrDataVo;
import ext.alphai.globalPart.vo.ClassifyAttrVo;
import ext.util.ClassificationUtil;
import ext.util.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.ReferenceFactory;
import wt.util.WTException;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class AINamingRulesService {

    static final ObjectMapper objectMapper = new ObjectMapper();
    public static String selectSql = "SELECT * FROM AINAMINGRULES WHERE CLASSIFYNAME = ?";

    public static String insertSql = "INSERT INTO AINAMINGRULES (CLASSIFYNAME, NAMINGRULES) VALUES (?, ?)";

    public static String updateSql = "UPDATE AINAMINGRULES SET NAMINGRULES = ? WHERE CLASSIFYNAME = ?";


    public static String mergeSql =
            "MERGE INTO AINAMINGRULES a " +
                    "USING (SELECT ? CLASSIFYNAME, ? NAMINGRULES FROM DUAL) b " +
                    "ON (a.CLASSIFYNAME = b.CLASSIFYNAME) " +
                    "WHEN MATCHED THEN " +
                    "  UPDATE SET a.NAMINGRULES = b.NAMINGRULES, a.UPDATETIME = SYSDATE " +
                    "WHEN NOT MATCHED THEN " +
                    "  INSERT (CLASSIFYNAME, NAMINGRULES) VALUES (b.CLASSIFYNAME, b.NAMINGRULES)";


    /**
     * 根据分类节点内部值获取分类属性显示值内部值 以及 分类规则
     * @param className
     * @return
     */
    public static ClassifyAttrVo getClassifyAttrVoByClassName(String className) throws WTException, IOException {
        // 当前用户的主语言
        Locale userHostLanguage = GeneralService.getUserHostLanguage();
        ClassifyAttrVo vo = new ClassifyAttrVo();
        vo.setClassifyName(className);
        TypeDefinitionReadView nodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, "com.ptc.csm.default_clf_namespace",className);
        // 获取当前分类的父节点的对象
        String parentOid =  nodeView.getParentId().toString();
        ReferenceFactory rf = new ReferenceFactory();
        LWCStructEnumAttTemplate parentEnumAttTemplate = (LWCStructEnumAttTemplate) rf.getReference(parentOid).getObject();
        String parentClassifyName = parentEnumAttTemplate.getName();
        TypeDefinitionReadView parentNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, "com.ptc.csm.default_clf_namespace",parentClassifyName);

        vo.setClassifyDisplayName(PropertyHolderHelper.getDisplayName(nodeView, userHostLanguage));
        AttrCnEnGeVo attrCnEnGeVo = new AttrCnEnGeVo();
        // 改为父节点的
        String chinaName = PropertyHolderHelper.getDisplayName(parentNodeView, Locale.CHINESE);
        String enName = PropertyHolderHelper.getDisplayName(parentNodeView, Locale.UK);
        String geName = PropertyHolderHelper.getDisplayName(parentNodeView, Locale.GERMAN);
        attrCnEnGeVo.setCnName(chinaName);
        attrCnEnGeVo.setEnName(enName);
        attrCnEnGeVo.setGeName(geName);
        vo.setDisplayName(attrCnEnGeVo);
        // 获取规则
        AINamingRules namingRules = getNamingRules(className);
        String rules = namingRules.getNamingRules();
        if(StringUtils.isNotBlank(rules)){
            List<String> rulerList = objectMapper.readValue(rules, new TypeReference<List<String>>() {});
            vo.setClassifyRules(rulerList);
        }

        // 获取分类属性内部值显示值
        Set<AttributeTypeIdentifier> allClassInterName = ClassificationUtil.getAllClassInterName(className);
        List<ClassifyAttrDataVo> attrDatas = new ArrayList<>();
        for (AttributeTypeIdentifier identifier : allClassInterName) {
            AttributeDefinitionReadView classAttDisplayName = ClassificationUtil.getClassAttDisplayName(className, identifier.getAttributeName());
            // 获取分类属性主语言显示值
            String attributeDisplayName = PropertyHolderHelper.getDisplayName(classAttDisplayName, userHostLanguage);
            attrDatas.add(new ClassifyAttrDataVo(Constant.IBA+identifier.getAttributeName(), attributeDisplayName));
        }
        vo.setAttrDatas(attrDatas);
        return vo;
    }




    /**
     * 数据库查询 根据分类节点内部名获取命名规则
     * @param className
     * @return
     */
    public static AINamingRules getNamingRules(String className){
        AINamingRules ar = new AINamingRules();

        ResultSet resultSet = CommonUtil.excuteSelect(selectSql, className);
        try {
            if (resultSet.next()) {
                return new AINamingRules(className,resultSet.getString(Constant.NAMINGRULES), resultSet.getString(Constant.CREATETIME), resultSet.getString(Constant.UPDATETIME));
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
        ar.setClassifyName(className);
        return ar;
    }


    /**
     * 新增或者修改分类命名规则
     * @param classifyName 分类内部名
     * @param rulesList 命名规则集合
     * @return
     */
//    public static int insertOrUpdateAINamingRules(String classifyName, List<String> rulesList) throws IOException, SQLException {
//        int result = 0;
//        // 规则集合转成json
//        String rulesJson = objectMapper.writeValueAsString(rulesList);
//        int update = CommonUtil.excuteUpdate(updateSql, rulesJson, classifyName);
//        if (update > 0){
//            result = update;
//        } else {
//            // 新增
//            result = CommonUtil.excuteUpdate(insertSql, classifyName ,rulesJson);
//        }
//        return result;
//    }

    /**
     * 新增或更新分类命名规则（线程安全版）
     * @param classifyName 分类内部名
     * @param rulesList 命名规则集合
     * @return 受影响的行数
     */
    public static int insertOrUpdateAINamingRules(String classifyName, List<String> rulesList) throws IOException, SQLException {
        // 将规则列表转换为JSON字符串
        String rulesJson = objectMapper.writeValueAsString(rulesList);
        // 执行MERGE操作，确保原子性
        return CommonUtil.excuteUpdate(mergeSql, classifyName, rulesJson);
    }



}
