package ext.alphai.globalPart.servcie;

import ext.util.CommonUtil;
import wt.org.WTGroup;
import wt.org.WTUser;
import wt.session.SessionHelper;

/**
 * 术语库、命名规则页面VUE 按钮屏蔽依据
 */
public class ButtonShowHideService {
    // 术语库按钮查看组
    public static final String AI_JC_Terms_AdminGroup = "AI_JC_Terms_AdminGroup";
    // 命名规则按钮查看组
    public static final String AI_Part_Naming_Rules_AdminGroup = "AI_Part_Naming_Rules_AdminGroup";

    /**
     * 术语库页面按钮权限方法
     * @return
     */
    public static boolean glossaryButtonReview(){
        boolean result = false;
        try {
            WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
            WTGroup wtGroup = CommonUtil.queryGroupByName(AI_JC_Terms_AdminGroup);
            if (wtGroup.isMember(user)) {
//                UIValidationStatus enabled = UIValidationStatus.ENABLED;
//                    System.out.println("展示按钮");
                result = true;
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    /**
     * 命名规则页面按钮权限方法
     * @return
     */
    public static boolean nameRulesButtonReview(){
        boolean result = false;
        try {
            WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
            WTGroup wtGroup = CommonUtil.queryGroupByName(AI_Part_Naming_Rules_AdminGroup);
            if (wtGroup.isMember(user)) {
//                UIValidationStatus enabled = UIValidationStatus.ENABLED;
//                    System.out.println("展示按钮");
                result = true;
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
