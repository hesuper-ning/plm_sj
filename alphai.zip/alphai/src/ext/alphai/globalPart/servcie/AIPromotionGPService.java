package ext.alphai.globalPart.servcie;

import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.view.PropertyHolderHelper;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.windchill.enterprise.part.commands.AssociationLinkObject;
import com.ptc.windchill.enterprise.part.commands.PartDocServiceCommand;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.techsoft.logicdata.helper.IBAHelper;
import ext.util.CommonUtil;
import ext.util.IBAUtil;
import ext.util.PersistenceUtil;
import org.apache.commons.lang3.StringUtils;
import wt.dataops.containermove.ContainerMoveHelper;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.epm.EPMDocument;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.ObjectIdentifier;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTValuedHashMap;
import wt.fc.collections.WTValuedMap;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.session.SessionHelper;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class AIPromotionGPService {


    public static void allowCondition(WTPart part) throws WTException {
        final String isStart = PropertiesUtil.getValueByKey("ai.part.lifeState.switch").toUpperCase();
        if (StringUtils.isBlank(isStart) || isStart.equals("FALSE")) {
            return;
        }


        final String[] allowState = PropertiesUtil.getValueByKey("ai.part.lifeState").split(",");
        final List<String> ALLOW_STATE_LIST = new ArrayList(Arrays.asList(allowState));
        String partState = part.getState().toString();
        if (!ALLOW_STATE_LIST.contains(partState)) {
            throw new WTException(part.getNumber() + "部件，状态为：" + partState + "不允许升级为全球部件！");
        }

    }


    /**
     * 1.先获取分类内部名，根据内部名第二位判断是否移动
     * 2.根据配置获取指定存储库名称，找到指定存储库，
     *
     * @param part
     * @param iba
     * @throws WTException
     * @throws SQLException
     */
    public static void setPartToFolder(WTPart part, IBAUtil iba) throws Exception {
        System.out.println("部件移动文件夹方法进入");
        // 部件分类的英文名称
        final String[] existLibClassify = PropertiesUtil.getValueByKey("ai.part.existLibClassify").split(",");
        final List<String> NO_MOVE_CLASSIFY_LIST = new ArrayList<>(Arrays.asList(existLibClassify));
        String toLibrary = PropertiesUtil.getValueByKey("ai.part.movetoGlobalPartsLibrary");//移动到的存储库  3、6、8库不一样
        final String classifyName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.classify.name"));
        // 部件分类内部值

        boolean isEmptyFolder = false;
        String displayENName = PropertiesUtil.getValueByKey("ai.part.noFolder");
        //
        System.out.println("空文件夹名称"+displayENName);
        if (StringUtils.isBlank(classifyName)) {
            System.out.println("部件未设置分类！");
            isEmptyFolder = true;
        } else {
            //不符合配置的分类移动到全球部件库
            String node2ndPlace = classifyName.substring(1, 2);  // 直接获取内部名第二位
            System.out.println("节点内部名第二位：" + node2ndPlace);
            System.out.println("已存在库的分类" + NO_MOVE_CLASSIFY_LIST);
            //3--->源材料库
            if (existLibClassify[0].equals(node2ndPlace)) {
                toLibrary = PropertiesUtil.getValueByKey("ai.part.moveToMaterialsPartsLibrary");
            }else if (existLibClassify[1].equals(node2ndPlace)){//6---电子库
                toLibrary = PropertiesUtil.getValueByKey("ai.part.moveToElectronicPartsLibrary");
            }else if (existLibClassify[2].equals(node2ndPlace)){//8---机械库
                toLibrary = PropertiesUtil.getValueByKey("ai.part.moveToMechanicalLibrary");
            }
        }
        // 部件容器
        WTContainer container = part.getContainer();
        // 目标存储库
        WTLibrary targetLib = getContainerByName(toLibrary);

        if (targetLib == null) {
            System.out.println("未设置配置分类部件所属存储库" + toLibrary);
            return;
        }
        WTContainerRef c_ref = WTContainerRef.newWTContainerRef(targetLib);
        //分类不为空。选分类英文内部值做文件夹
        if (!isEmptyFolder) {
            //======可能要获取分类节点的父节点的英文显示名---暂未做处理
            // 根据分类内部值获取分类对象
            TypeDefinitionReadView nodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, "com.ptc.csm.default_clf_namespace", classifyName);
            // 分类对应的英文名称
            if (nodeView!=null) {
                displayENName = PropertyHolderHelper.getDisplayName(nodeView, Locale.UK);
            }
        }


        // 目标存储库容器
        WTContainer libContainer = targetLib.getContainer();
        // 目标文件路径      Global Parts Library/分类英文显示名
        String tarFolderPath = "/Default/" + displayENName;

        //校验是否已经根据分类英文名称创建文件夹
        QueryResult folderContents = FolderHelper.service.findFolderContents(targetLib.getDefaultCabinet());
        Vector vector = folderContents.getObjectVectorIfc().getVector();
        SubFolder folder = null;
        System.out.println("当前文件夹名称: " + displayENName);
        for (Object o : vector) {
            if (o instanceof SubFolder) {
                SubFolder subFolder = (SubFolder) o;
                String subFolderName = subFolder.getName();

                if (subFolderName.equals(displayENName)) {
                    folder = subFolder;
                    break;  // 找到后立即退出循环
                }
            }
        }

        //未创建
        if (folder == null) {
            // 创建文件夹
            System.out.println("创建分类文件夹：" + tarFolderPath);
            folder = FolderHelper.service.createSubFolder(tarFolderPath, c_ref);
        }
        if (container.equals(libContainer)) {
            // 如果是在同一个容器内 使用相同容器转移文件夹方法
            System.out.println("相同容器");

            // 与部件关联的epm
            for (EPMDocument epmDocument : getEPMByPart(part)) {
                FolderHelper.service.changeFolder((wt.folder.FolderEntry) epmDocument, folder);
            }

            //与部件关联的说明方文档
            for (WTDocument wtDocument : getDescByPart(part)) {
                FolderHelper.service.changeFolder((wt.folder.FolderEntry) wtDocument, folder);
            }

            //与部件关联的参考方
            for (WTDocument wtDocument : getRefByPart(part)) {
                FolderHelper.service.changeFolder((wt.folder.FolderEntry) wtDocument, folder);
            }
            FolderHelper.service.changeFolder((wt.folder.FolderEntry) part, folder);
        } else {
            // 不处于相同容器
            System.out.println("不相同容器");
            WTValuedMap objFolderMap = new WTValuedHashMap(1);

            // 与部件关联的epm
            for (EPMDocument epmDocument : getEPMByPart(part)) {
                objFolderMap.put(epmDocument, folder);
            }

            //与部件关联的说明方文档
            for (WTDocument wtDocument : getDescByPart(part)) {
                objFolderMap.put(wtDocument, folder);
            }

            //与部件关联的参考方文档
            for (WTDocument wtDocument : getRefByPart(part)) {
                objFolderMap.put(wtDocument, folder);
            }
            objFolderMap.put(part, folder);
            WTCollection col = ContainerMoveHelper.service.moveAllVersions(objFolderMap);
        }
    }


    public static List<EPMDocument> getEPMByPart(WTPart part) throws Exception {
        List<EPMDocument> epmDocuments = new ArrayList<>();
        List<EPMDocument> allCADByPart = getAllCADByPart(part);

        for (EPMDocument epmDocument : allCADByPart) {
            System.out.println("部件获取到的cad" + epmDocument.getNumber());
            epmDocuments.add(epmDocument);
        }
        return epmDocuments;

    }

    /**
     * 获取部件关联的说明方文档(Described)，且类型为
     *
     * @param part
     * @return List<WTDocument>
     */
    public static List<WTDocument> getDescByPart(WTPart part) {
        List<WTDocument> list = new ArrayList<WTDocument>();
        try {
            QueryResult qr = WTPartHelper.service.getDescribedByDocuments(part);// 普通说明文档
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTDocument) {
                    WTDocument doc = (WTDocument) obj;
                    // 获取
                    if (checkWTDoc(doc,"DESC")) {
                        list.add(doc);
                    }
                }
            }

        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 获取部件关联的参考文档(Reference)
     *
     * @param part
     * @return List<WTDocument>
     */
    public static List<WTDocument> getRefByPart(WTPart part) {
        List<WTDocument> list = new ArrayList<WTDocument>();
        try {
            QueryResult qr = WTPartHelper.service.getReferencesWTDocumentMasters(part);
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTDocumentMaster) {
                    WTDocumentMaster docmaster = (WTDocumentMaster) obj;
                    QueryResult qs = VersionControlHelper.service.allVersionsOf(docmaster);
                    WTDocument doc = (WTDocument) qs.nextElement();
                    if (checkWTDoc(doc,"REF")) {
                        list.add(doc);
                    }
                }
            }
        } catch (
                WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 校验 文档是否为指定  添加 说明部件的文档类型
     * @param doc
     * @return
     */
    public static boolean checkWTDoc(WTDocument doc , String relatedType) {
        boolean flag = false;
        String objectType = getTypeIdentifier(doc);

        //说明方文档
        if ("DESC".equals(relatedType)){
            String[] descTypes = PropertiesUtil.getValueByKey("ai.doc.DESCType").split(",");
            for (String descType : descTypes) {
                if (objectType!=null && objectType.contains(descType)) {
                    flag = true;
                    return flag;
                }
            }
        //参考方
        }else if("REF".equals(relatedType)){
            String[] descTypes = PropertiesUtil.getValueByKey("ai.doc.REFType").split(",");
            for (String descType : descTypes) {
                if (objectType!=null && objectType.contains(descType)) {
                    flag = true;
                    return flag;
                }
            }
        }
        //获取文档内部值

        return flag;
    }


    /**
     * 获取文档子类型
     *
     * @param doc
     * @return
     */
    public static String getDocTypeInternalName(WTDocument doc) {
        String InternalName = null;
        TypeDefinitionReference ref = (doc).getTypeDefinitionReference();
        try {
            TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities.getTypeDefinition(ref);
            WTTypeDefinition definition = (WTTypeDefinition) PersistenceHelper.manager.refresh(view.getObjectID());
            InternalName = definition.getName();
        } catch (WTException e) {
            System.out.println("获取文档子类型内部名称出错");
        }
        return InternalName;
    }



    /**
     * 通过名称获取存储库对象
     *
     * @param containerName
     * @return
     */
    public static WTLibrary getContainerByName(String containerName) throws SQLException {
        WTLibrary container = null;
        String sql = "SELECT CLASSNAMEA2A2, IDA2A2 FROM WTLIBRARY WHERE NAMECONTAINERINFO = ?";
        ResultSet resultSet = null;
        try {
            resultSet = CommonUtil.excuteSelect(sql, containerName);
            while (resultSet.next()) {
                String CLASSNAMEA2A2 = resultSet.getString("CLASSNAMEA2A2");
                String IDA2A2 = resultSet.getString("IDA2A2");
                if (!StringUtils.isBlank(CLASSNAMEA2A2) && !StringUtils.isBlank(IDA2A2)) {
                    ObjectIdentifier oid = ObjectIdentifier.newObjectIdentifier(CLASSNAMEA2A2 + ":" + IDA2A2);
                    container = (WTLibrary) PersistenceHelper.manager.refresh(oid);
                }
            }
            resultSet.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (resultSet != null) {
                resultSet.close();
            }
        }

        return container;
    }


    /**
     * 获取类型的全路径  如：com.jiecang.ReferenceDocument|com.jiecang.WINDCHILL_GENERAL_DOCUMENT
     * @param persistable
     * @return
     */
    public static String getTypeIdentifier(Persistable persistable) {
        try {
            return TypedUtilityServiceHelper.service.getExternalTypeIdentifier(persistable);
        } catch (WTException var2) {
            var2.printStackTrace();
        } catch (RemoteException var3) {
            var3.printStackTrace();
        }

        return null;
    }


    public static void setJCPartLdJCState(WTPart part, IBAUtil ibaUtil) throws Exception {
        final String LD_STATE = PropertiesUtil.getValueByKey("ai.part.iba.LDState");
        final String DesignReleased = PropertiesUtil.getValueByKey("ai.part.value.DesignReleased");

        final String JC_STATE = PropertiesUtil.getValueByKey("ai.part.iba.JCState");
        final String ProductionReleased = PropertiesUtil.getValueByKey("ai.part.value.ProductionReleased");

        ibaUtil.setIBAAttribute4AllType(part, LD_STATE, DesignReleased);//jcState设置为Production Released
        ibaUtil.setIBAAttribute4AllType(part, JC_STATE, ProductionReleased);//ldState设置为Design Released
    }

    /**
     * 升级全球物料
     * @param part
     * @param ibaUtil
     * @param option
     * @throws Exception
     */
    public static void setIBALDJCState(WTPart part, IBAUtil ibaUtil, String option) throws Exception {
        String partLifeState = part.getLifeCycleState().toString();

        String designReleased = PropertiesUtil.getValueByKey("ai.part.lifeState.DESIGNRELEASED");//设计发布生命周期
        String productReleased = PropertiesUtil.getValueByKey("ai.part.lifeState.PRODUCTIONRELEASED");//生产发布生命周期

        final String LD_STATE = PropertiesUtil.getValueByKey("ai.part.iba.LDState");
        final String JC_STATE = PropertiesUtil.getValueByKey("ai.part.iba.JCState");

        final String DesignReleased = PropertiesUtil.getValueByKey("ai.part.value.DesignReleased");
        final String ProductionReleased = PropertiesUtil.getValueByKey("ai.part.value.ProductionReleased");

        if ("LD".equals(option)) {
            // 生命周期为设计发布，LD、JC为 设计发布
            if (designReleased.equalsIgnoreCase(partLifeState)) {
                ibaUtil.setIBAAttribute4AllType(part, LD_STATE, DesignReleased);//jcState设置为Production Released
                ibaUtil.setIBAAttribute4AllType(part, JC_STATE, DesignReleased);//ldState设置为Design Released
            }
            if (productReleased.equalsIgnoreCase(partLifeState)) {
                ibaUtil.setIBAAttribute4AllType(part, LD_STATE, ProductionReleased);//jcState设置为Production Released
                ibaUtil.setIBAAttribute4AllType(part, JC_STATE, ProductionReleased);//ldState设置为Design Released
            }
        } else if ("JC".equals(option)) {
            ibaUtil.setIBAAttribute4AllType(part, LD_STATE, DesignReleased);//jcState设置为Production Released
            ibaUtil.setIBAAttribute4AllType(part, JC_STATE, ProductionReleased);//ldState设置为Design Released
        }


    }


    /**
     * 修订
     *
     * @param wtPart
     * @throws Exception
     */
    public static void setLDJCState(WTPart wtPart) throws Exception {
        String currentState = wtPart.getLifeCycleState().toString();
        String LD_STATE = PropertiesUtil.getValueByKey("ai.part.iba.LDState");
        String JC_STATE = PropertiesUtil.getValueByKey("ai.part.iba.JCState");

        String typeIdentifier = AIPromotionGPService.getTypeIdentifier(wtPart);
        String ldPartType = PropertiesUtil.getValueByKey("ai.part.ld.part");


        System.out.println("currentPart State:" + currentState);
        //生命周期变更为 生产发布
        String PRODUCTIONRELEASED = PropertiesUtil.getValueByKey("ai.part.lifeState.PRODUCTIONRELEASED");

        // LD部件修订
        if (typeIdentifier.contains(ldPartType)) {
            if (currentState.equals(PRODUCTIONRELEASED)) {
                System.out.println("lifeState is PRODUCTIONRELEASED");
                //设置JCState的值为Production Released
                String ProductionReleased = PropertiesUtil.getValueByKey("ai.part.value.ProductionReleased");
                setIBA(wtPart, JC_STATE, ProductionReleased);
                setIBA(wtPart, LD_STATE, ProductionReleased);
            }
        } else {
            if (currentState.equals(PRODUCTIONRELEASED)) {
                System.out.println("lifeState is PRODUCTIONRELEASED");
                //设置JCState的值为Production Released
                String ProductionReleased = PropertiesUtil.getValueByKey("ai.part.value.ProductionReleased");
                setIBA(wtPart, JC_STATE, ProductionReleased);
                //如果 LD State 原本就不为ProductionReleased
                String LD_STATE_Value = getIBA(wtPart, LD_STATE);
                if (!ProductionReleased.equals(LD_STATE_Value)) {
                    String DesignReleased = PropertiesUtil.getValueByKey("ai.part.value.DesignReleased");
                    setIBA(wtPart, LD_STATE, DesignReleased);
                }
            }
        }


        //生命周期变更为 生产变更  LD/JC State状态都设置为生产变更  PRODUCTIONCHANGE
        String PRODUCTIONCHANGE = PropertiesUtil.getValueByKey("ai.part.lifeState.PRODUCTIONCHANGE");
        System.out.println("currentState==PRODUCTIONCHANGE" + (currentState.equals(PRODUCTIONCHANGE)));
        if (currentState.equals(PRODUCTIONCHANGE)) {
            System.out.println("lifeState is PRODUCTIONCHANGE");
            String ProductionChange = PropertiesUtil.getValueByKey("ai.part.value.ProductionChange");
            setIBA(wtPart, LD_STATE, ProductionChange);
            setIBA(wtPart, JC_STATE, ProductionChange);
        }
    }


    //状态变更
    public static void setLDJCStateByLifeChange(WTPart wtPart) throws Exception {
        IBAUtil ibaUtil = new IBAUtil(wtPart);
        String currentState = wtPart.getLifeCycleState().toString();
        String LD_STATE = PropertiesUtil.getValueByKey("ai.part.iba.LDState");
        String JC_STATE = PropertiesUtil.getValueByKey("ai.part.iba.JCState");

        String typeIdentifier = AIPromotionGPService.getTypeIdentifier(wtPart);
        String ldPartType = PropertiesUtil.getValueByKey("ai.part.ld.part");


        System.out.println("currentPart State:" + currentState);
        //生命周期变更为 生产发布
        String PRODUCTIONRELEASED = PropertiesUtil.getValueByKey("ai.part.lifeState.PRODUCTIONRELEASED");

        // LD部件修订
        if (typeIdentifier.contains(ldPartType)) {
            if (currentState.equals(PRODUCTIONRELEASED)) {
                System.out.println("lifeState is PRODUCTIONRELEASED");
                //设置JCState的值为Production Released
                String ProductionReleased = PropertiesUtil.getValueByKey("ai.part.value.ProductionReleased");
                IBAHelper.setIBANoCheckoutDB(wtPart, JC_STATE, ProductionReleased);
                IBAHelper.setIBANoCheckoutDB(wtPart, LD_STATE, ProductionReleased);
            }
        } else {
            if (currentState.equals(PRODUCTIONRELEASED)) {
                System.out.println("lifeState is PRODUCTIONRELEASED");
                //设置JCState的值为Production Released
                String ProductionReleased = PropertiesUtil.getValueByKey("ai.part.value.ProductionReleased");
                IBAHelper.setIBANoCheckoutDB(wtPart, JC_STATE, ProductionReleased);
                //如果 LD State 原本就不为ProductionReleased
                Object LD_STATE_Value = IBAHelper.getIBAValue(wtPart, LD_STATE);
                if (!Objects.equals(ProductionReleased, LD_STATE_Value)) {
                    String DesignReleased = PropertiesUtil.getValueByKey("ai.part.value.DesignReleased");
                    IBAHelper.setIBANoCheckoutDB(wtPart, LD_STATE, DesignReleased);
                }
            }
        }


        //生命周期变更为 生产变更  LD/JC State状态都设置为生产变更  PRODUCTIONCHANGE
        String PRODUCTIONCHANGE = PropertiesUtil.getValueByKey("ai.part.lifeState.PRODUCTIONCHANGE");
        System.out.println("currentState==PRODUCTIONCHANGE" + (currentState.equals(PRODUCTIONCHANGE)));
        if (currentState.equals(PRODUCTIONCHANGE)) {
            System.out.println("lifeState is PRODUCTIONCHANGE");
            String ProductionChange = PropertiesUtil.getValueByKey("ai.part.value.ProductionChange");
            IBAHelper.setIBANoCheckoutDB(wtPart, LD_STATE, ProductionChange);
            IBAHelper.setIBANoCheckoutDB(wtPart, JC_STATE, ProductionChange);
        }
    }


    public static void setIBA(Persistable persistable, String ibaName, String value) throws WTException {
        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        normalizedObject.set(ibaName, value);
        persistable = normalizedObject.apply();
        PersistenceHelper.manager.modify(persistable);
    }

    public static String getIBA(Persistable persistable, String ibaName) throws WTException {
        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        return normalizedObject.get(ibaName) == null ? null : normalizedObject.get(ibaName).toString();
    }


    /**
     * 部件与CAD文档， 说明关系 通过部件获取CAD文档，可能包含3D和2D 1）如果是结构部件，找结构3D图纸 CADCOMPONENT & PROE
     * 2）如果是PCBA，找ECAD图纸 3）如果是软件部件，找autocad图纸
     *
     * @param WTPart
     * @return List<EPMDocument>
     * @throws Exception
     */
    @SuppressWarnings("deprecation")
    public static List<EPMDocument> getAllCADByPart(WTPart part) throws Exception {
        List<EPMDocument> docs = new ArrayList<EPMDocument>();
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();
            Collection cadDocumentsAndLinks = PartDocServiceCommand.getAssociatedCADDocumentsAndLinks(part);
            for (Object object : cadDocumentsAndLinks) {
                if (object instanceof AssociationLinkObject) {
                    AssociationLinkObject alo = (AssociationLinkObject) object;
                    EPMDocument doc = alo.getCadObject();
                    docs.add(doc);
                }
            }

        } catch (WTException e) {
            e.printStackTrace();
            throw new Exception("No 3D CAD Document on Part :" + part.getName());
        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return docs;
    }

}
