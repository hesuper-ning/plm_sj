package ext.alphai.globalPart.servcie;

import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.view.PropertyHolderHelper;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.util.ClassificationUtil;
import ext.util.CommonUtil;
import ext.util.IBAUtil;
import ext.util.PersistenceUtil;
import org.apache.commons.lang3.StringUtils;
import wt.dataops.containermove.ContainerMoveHelper;
import wt.fc.ObjectIdentifier;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTValuedHashMap;
import wt.fc.collections.WTValuedMap;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

/**
 * 部件归位到指定文件夹 服务类
 */
public class PartContainerFolderService {
    /**
     * 将部件归位到指定容器的指定文件夹
     * @param part
     */
    public static void setPartToFolder(WTPart part) throws WTException, SQLException {
        System.out.println("部件移动文件夹方法进入");
        // 部件分类的英文名称
        IBAUtil iba = new IBAUtil(part);
        // 部件分类内部值
        String classifyName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.classify.name"));
        System.out.println("部件分类内部值："+classifyName);
        // 部件子类型
        String partChild = PersistenceUtil.getSubTypeInternal(part);
        System.out.println("部件子类型："+partChild);
        // 存储库名称
        String libName = getPartChildClassify(classifyName, partChild);
        System.out.println("分类指向的存储库："+libName);
        if(StringUtils.isBlank(libName)){
            System.out.println("未找到分类："+classifyName+" 和子类型为："+partChild+" 所对应的存储库");
            return;
        }
        // 部件容器
        WTContainer container = part.getContainer();

        WTLibrary targetLib = getContainerByName(libName);

        if(targetLib == null){
            System.out.println("未设置配置分类部件所属存储库");
            return;
        }
        WTContainerRef c_ref = WTContainerRef.newWTContainerRef(targetLib);
        // 根据分类内部值获取分类对象
//        TypeDefinitionReadView nodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, "com.ptc.csm.default_clf_namespace",classifyName);
//        // 分类对应的英文名称
//        String displayENName = PropertyHolderHelper.getDisplayName(nodeView, Locale.UK);

        // 目标存储库容器
        WTContainer libContainer = targetLib.getContainer();
        // 目标文件路径
        String tarFolderPath = "/Default/"+classifyName;

        QueryResult folderContents = FolderHelper.service.findFolderContents(targetLib.getDefaultCabinet());
        Vector vector = folderContents.getObjectVectorIfc().getVector();
        Folder folder = null;
        for (Object o : vector) {
            if(o instanceof SubFolder){
                SubFolder subFolder = (SubFolder) o;
                String subFolderName = subFolder.getName();
                if(subFolderName.startsWith(classifyName)){
                    folder = subFolder;
                }
            }
        }

        if(folder == null){
            // 创建文件夹
            System.out.println("创建分类文件夹："+tarFolderPath);
            folder = FolderHelper.service.createSubFolder(tarFolderPath, targetLib.getContainerReference());
        }
        if(container.equals(libContainer)){
            // 如果是在同一个容器内 使用相同容器转移文件夹方法
            System.out.println("相同容器");
            FolderHelper.service.changeFolder((wt.folder.FolderEntry) part, folder);
        }else {
            // 不处于相同容器
            System.out.println("不相同容器");
            WTValuedMap objFolderMap = new WTValuedHashMap(1);
            objFolderMap.put(part, folder);
            WTCollection col = ContainerMoveHelper.service.moveAllVersions(objFolderMap);
        }
    }






    /**
     * 通过名称获取存储库对象
     * @param containerName
     * @return
     */
    public static WTLibrary getContainerByName(String containerName) throws SQLException {
        WTLibrary container = null;
        String sql = "SELECT CLASSNAMEA2A2, IDA2A2 FROM WTLIBRARY WHERE NAMECONTAINERINFO = ?";
        ResultSet resultSet = null;
        try {
            resultSet = CommonUtil.excuteSelect(sql, containerName);
            while (resultSet.next()) {
                String CLASSNAMEA2A2 = resultSet.getString("CLASSNAMEA2A2");
                String IDA2A2 = resultSet.getString("IDA2A2");
                if(!StringUtils.isBlank(CLASSNAMEA2A2) && !StringUtils.isBlank(IDA2A2)){
                    ObjectIdentifier oid =  ObjectIdentifier.newObjectIdentifier(CLASSNAMEA2A2+":"+IDA2A2);
                    container = (WTLibrary) wt.fc.PersistenceHelper.manager.refresh(oid);
                }
            }
            resultSet.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (resultSet != null) {
                resultSet.close();
            }
        }

        return container;
    }

    /**
     * 获取 部件 分类和子类型对应的 存储库名称
      * @param classify
     * @param childType
     * @return
     */
    private static String getPartChildClassify(String classify, String childType){
        String libName = "";
        String partClassifyList = PropertiesUtil.getValueByKey(childType);
        if(!StringUtils.isBlank(partClassifyList)){
            List<String> list = Arrays.asList(partClassifyList.split(","));
            if(list.contains(classify)){
                libName = PropertiesUtil.getValueByKey("ai.part.type." + childType);
            } else {
                System.out.println("部件子类型："+childType+" 不在配置项的分类集合中");
            }
        } else {
            System.out.println("部件子类型："+childType+" 不在配置项中");
        }
        return libName;
    }

}
