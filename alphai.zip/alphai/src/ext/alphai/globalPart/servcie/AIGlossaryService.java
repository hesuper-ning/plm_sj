package ext.alphai.globalPart.servcie;

import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.GlossaryEnum;
import ext.alphai.globalPart.domain.AIGlossary;
import ext.alphai.globalPart.vo.AIGlossaryVo;
import ext.util.CommonUtil;
import ext.util.PersistenceUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import wt.fc.WTObject;
import wt.org.WTUser;
import wt.pom.WTConnection;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 术语库服务类
 */
public class AIGlossaryService {

    /**
     * 修改术语库状态
     * @param aiGlossaryVos
     * @return
     */
    public static int updateGlossaryStatus(List<AIGlossaryVo> aiGlossaryVos) throws SQLException {
        int result = 0;
        String sql = "UPDATE AIGLOSSARY SET STATUS = ? WHERE AIGLOSSARYID = TO_NUMBER(?)";
        for (AIGlossaryVo vo : aiGlossaryVos) {
            int i = CommonUtil.excuteUpdate(sql, vo.getStatus(), String.valueOf(vo.getAIGlossaryId()));
            result += i;
        }
        return result;
    }


    /**
     * 获取查询结果的总数
     * @param chinaName 中文名称
     * @param englishName 英文名称
     * @param germanName 德文名称
     * @param glossartEnum
     * @return 当前查询条件下的总条目数
     */
    public static int getSelectCount(String chinaName, String englishName, String germanName, GlossaryEnum glossaryEnum){
        int result = 0;
        WTConnection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = CommonUtil.getWTConnection();
            StringBuilder sql = new StringBuilder("SELECT COUNT(*) AS total FROM AIGLOSSARY");
            List<Object> params = new ArrayList<>();

            // 参数预处理
            chinaName = StringUtils.trimToEmpty(chinaName);
            englishName = StringUtils.trimToEmpty(englishName);
            germanName = StringUtils.trimToEmpty(germanName);

            List<String> conditions = new ArrayList<>();

            // 构建查询条件
            if (!chinaName.isEmpty()) {
                conditions.add("CHINESETERM LIKE '%' || ? || '%'");
                params.add(chinaName);
            }
            if (!englishName.isEmpty()) {
                conditions.add("ENGLISHTERM LIKE '%' || ? || '%'");
                params.add(englishName);
            }
            if (!germanName.isEmpty()) {
                conditions.add("GERMANTERM LIKE '%' || ? || '%'");
                params.add(germanName);
            }
            if (glossaryEnum != null) {
                conditions.add("STATUS = ?");
                params.add(glossaryEnum.getKey()); // 根据枚举实际方法调整
            }

            // 拼接WHERE条件
            if (!conditions.isEmpty()) {
                sql.append(" WHERE ");
                sql.append(String.join(" AND ", conditions));
            }

            pstmt = conn.prepareStatement(sql.toString());

            // 参数绑定
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            rs = pstmt.executeQuery();

            if (rs.next()) {
                result = rs.getInt("total");
            }
        } catch (SQLException e) {
            System.err.println("COUNT查询异常:");
            e.printStackTrace();
        } finally {
            // 资源关闭
            try { if (rs != null) rs.close(); } catch (Exception e) { /* ignored */ }
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) { /* ignored */ }
        }
        return result;
    }


    /**
     * 分页查询术语库
     * @param pageCount 当前页
     * @param pageSize 每页的数据数
     * @param chinaName 中文名称
     * @param englishName 英文名称
     * @param germanName 德文名称
     * @param glossartEnum
     * @return 当前查询条件下的总条目数
     */
    public static List<AIGlossary> getSelectGlossaryList(Integer pageCount,Integer pageSize, String chinaName, String englishName, String germanName, GlossaryEnum glossartEnum){
        List<AIGlossary> result = new ArrayList<>();
        WTConnection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = CommonUtil.getWTConnection();
            StringBuilder sql = new StringBuilder("SELECT * FROM AIGLOSSARY");
            List<Object> params = new ArrayList<>();

            // 参数预处理
            chinaName = StringUtils.trimToEmpty(chinaName);
            englishName = StringUtils.trimToEmpty(englishName);
            germanName = StringUtils.trimToEmpty(germanName);

            // 构建查询条件
            List<String> conditions = new ArrayList<>();
            if (!chinaName.isEmpty()) {
                conditions.add("CHINESETERM LIKE '%' || ? || '%'");
                params.add(chinaName);
            }
            if (!englishName.isEmpty()) {
                conditions.add("ENGLISHTERM LIKE '%' || ? || '%'");
                params.add(englishName);
            }
            if (!germanName.isEmpty()) {
                conditions.add("GERMANTERM LIKE '%' || ? || '%'");
                params.add(germanName);
            }
            if (glossartEnum != null) {
                conditions.add("STATUS = ?");
                params.add(glossartEnum.getKey());
            }

            // 拼接WHERE条件
            if (!conditions.isEmpty()) {
                sql.append(" WHERE ").append(String.join(" AND ", conditions));
            }

            // 添加排序和分页（Oracle 12c+ 语法）
            sql.append(" ORDER BY AIGLOSSARYID")
                    .append(" OFFSET ? ROWS FETCH NEXT ? ROWS ONLY");

            // 计算分页参数（页码从1开始）
            int offset = (pageCount - 1) * pageSize;
            params.add(offset);
            params.add(pageSize);

            pstmt = conn.prepareStatement(sql.toString());

            // 参数绑定
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            rs = pstmt.executeQuery();

            // 处理结果集
            while (rs.next()) {
                result.add(getAIGlossaryByRS(rs));
            }
        } catch (SQLException e) {
            System.err.println("分页查询异常:");
            e.printStackTrace();
        } finally {
            // 资源关闭
            try { if (rs != null) rs.close(); } catch (Exception e) { /* ignored */ }
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) { /* ignored */ }
        }
        return result;
    }
    /**
     * 结果映射
     * @param rs
     * @return
     */
    public static AIGlossary getAIGlossaryByRS (ResultSet rs) throws SQLException {
        AIGlossary ag = new AIGlossary();
        ag.setAIGlossaryId(rs.getLong(Constant.AIGLOSSARYID));
        ag.setEnglishTerm(rs.getString(Constant.ENGLISHTERM));
        ag.setChineseTerm(rs.getString(Constant.CHINESETERM));
        ag.setGermanTerm(rs.getString(Constant.GERMANTERM));
        ag.setStatus(rs.getString(Constant.STATUS));
        ag.setCreateTime(rs.getString(Constant.CREATETIME));
        ag.setCreateBy(rs.getString(Constant.CREATEBY));
        ag.setUpdateTime(rs.getString(Constant.UPDATETIME));
        return ag;
    }


    /**
     * 转换数据库查询结果为展示结果
     * @param glossaries
     * @return
     */
    public static List<AIGlossaryVo> getAIGlossaryVo(List<AIGlossary> glossaries){
        List<AIGlossaryVo> vos = new ArrayList<>();
        for (AIGlossary glossary : glossaries) {
            AIGlossaryVo vo = new AIGlossaryVo();
            BeanUtils.copyProperties(glossary, vo);
            String statusKey = glossary.getStatus();
            String userOr = glossary.getCreateBy();
            vo.setStatus(statusKey);
            WTObject object = PersistenceUtil.oid2Object(userOr);
            if(object != null){
                if(object instanceof WTUser){
                    WTUser user = (WTUser)object;
                    vo.setCreateBy(user.getFullName());
                }
            }
            vos.add(vo);
        }
        return vos;
    }


    /**
     * 新增术语库
     * @param vos 前端传入的用户输入值
     * @param repeatList 校验失败的待插入术语对象
     * @return
     */
    public static int insertGlossary(List<AIGlossaryVo> vos, List<AIGlossaryVo> repeatList) throws WTException {
        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
        // 这是CREATEBY的传入值 当前操作用户 一定存在的
        String createByOR = PersistenceUtil.object2Oid(user);
        int result = 0;
        WTConnection conn = null;
        PreparedStatement pstmt = null;
        Connection connDB = null;
        try {
            conn = CommonUtil.getWTConnection();
            // 禁用自动提交以支持批处理
            connDB = conn.getConnection();
            connDB.setAutoCommit(false);
            // 基础插入SQL（使用序列生成主键）
            String sql = "INSERT INTO AIGLOSSARY ("
                    + " ENGLISHTERM, CHINESETERM, GERMANTERM, "
                    + "STATUS, CREATEBY, CREATETIME, UPDATETIME"
                    + ") VALUES ("
                    + " ?, ?, ?, ?, ?, SYSDATE, SYSDATE)";

            pstmt = conn.prepareStatement(sql);

            // 存储有效插入对象
            List<AIGlossaryVo> validList = new ArrayList<>();

            // 第一阶段：筛选有效数据
            for (AIGlossaryVo vo : vos) {
                if (checkGlossaryInsert(vo)) {
                    validList.add(vo);
                } else {
                    repeatList.add(vo);
                }
            }

            // 批量插入
            for (AIGlossaryVo vo : validList) {
                String englishTerm = StringUtils.trimToEmpty(vo.getEnglishTerm());
                String chineseTerm = StringUtils.trimToEmpty(vo.getChineseTerm());
                String germanTerm = StringUtils.trimToEmpty(vo.getGermanTerm());

                // 参数绑定
                pstmt.setString(1, englishTerm.isEmpty() ? null : englishTerm);
                pstmt.setString(2, chineseTerm.isEmpty() ? null : chineseTerm);
                pstmt.setString(3, germanTerm.isEmpty() ? null : germanTerm);
                pstmt.setString(4, "0"); // 显式设置状态为0
                pstmt.setString(5, createByOR);

                pstmt.addBatch();
            }

            // 执行批处理
            int[] batchResults = pstmt.executeBatch();
            connDB.commit();

            // 统计成功数量
            for (int affected : batchResults) {
                result += affected;
            }
            connDB.setAutoCommit(true);
        } catch (SQLException e) {
            try {
                if (connDB != null) connDB.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            System.err.println("批量插入异常:");
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (connDB != null) connDB.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    /**
     * 修改术语库
     * @param vo
     * @return
     */
    public static int updateGlossary(AIGlossaryVo vo) throws SQLException {
        WTConnection conn = null;
        PreparedStatement pstmt = null;
        int affectedRows = 0;

        try {
            // 校验必须参数
            if (vo.getAIGlossaryId() == null || vo.getAIGlossaryId() == 0L) {
                throw new IllegalArgumentException("术语ID不能为空");
            }

            // 校验修改后的值是否重复
            if (!checkGlossaryInsert(vo)) {
                throw new IllegalArgumentException("修改发现重复术语");
            }


            conn = CommonUtil.getWTConnection();
            List<String> setClauses = new ArrayList<>();
            List<Object> params = new ArrayList<>();

            // 处理各字段（trim后保留空值）
            String englishTerm = StringUtils.trimToEmpty(vo.getEnglishTerm());
            String chineseTerm = StringUtils.trimToEmpty(vo.getChineseTerm());
            String germanTerm = StringUtils.trimToEmpty(vo.getGermanTerm());
            String status = StringUtils.trimToEmpty(vo.getStatus());

            // 动态构建SET子句
            if (StringUtils.isNotBlank(englishTerm)) {
                setClauses.add("ENGLISHTERM = ?");
                params.add(englishTerm);
            }
            if (StringUtils.isNotBlank(chineseTerm)) {
                setClauses.add("CHINESETERM = ?");
                params.add(chineseTerm);
            }
            if (StringUtils.isNotBlank(germanTerm)) {
                setClauses.add("GERMANTERM = ?");
                params.add(germanTerm);
            }
            if (StringUtils.isNotBlank(status)) {
                setClauses.add("STATUS = ?");
                params.add(status);
            }

            // 必须至少更新一个字段
            if (setClauses.isEmpty()) {
                throw new IllegalArgumentException("至少需要更新一个字段");
            }

            // 添加更新时间（根据表结构需要）
            setClauses.add("UPDATETIME = SYSDATE");

            // 构建完整SQL
            StringBuilder sql = new StringBuilder("UPDATE AIGLOSSARY SET ");
            sql.append(String.join(", ", setClauses));
            sql.append(" WHERE AIGLOSSARYID = TO_NUMBER(?)");
            params.add(vo.getAIGlossaryId());

            pstmt = conn.prepareStatement(sql.toString());

            // 绑定参数（安全处理）
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            affectedRows = pstmt.executeUpdate();
        } finally {
            // 确保资源释放
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}

        }
        return affectedRows;
    }















    /**
     * 新增或修改术语时检查是否有某语言术语重复
     * @param vo
     * @return 返回true 代表插入的术语合法 false 存在重复术语
     */
    public static boolean checkGlossaryInsert(AIGlossaryVo vo){
        boolean result = true;
        WTConnection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = CommonUtil.getWTConnection();
            List<String> conditions = new ArrayList<>();
            List<Object> params = new ArrayList<>();

            // 处理各语言术语（去空格并检查空值）
            String englishTerm = StringUtils.trimToEmpty(vo.getEnglishTerm());
            String chineseTerm = StringUtils.trimToEmpty(vo.getChineseTerm());
            String germanTerm = StringUtils.trimToEmpty(vo.getGermanTerm());

            // 构建术语条件：即使值为空字符串也视为有效术语进行检查
            if (StringUtils.isNotBlank(englishTerm)) {  // 使用 isNotBlank 避免纯空格或空字符串
                conditions.add("ENGLISHTERM = ?");
                params.add(englishTerm.trim());  // 确保彻底去除首尾空格
            }
            if (StringUtils.isNotBlank(chineseTerm)) {
                conditions.add("CHINESETERM = ?");
                params.add(chineseTerm.trim());
            }
            if (StringUtils.isNotBlank(germanTerm)) {
                conditions.add("GERMANTERM = ?");
                params.add(germanTerm.trim());
            }

            // 关键修复：如果没有需要检查的术语，直接返回合法（避免SQL语法错误）
            if (conditions.isEmpty()) {
                return true;
            }

            // 构建基础SQL
            StringBuilder sql = new StringBuilder("SELECT AIGLOSSARYID FROM AIGLOSSARY WHERE (")
                    .append(String.join(" OR ", conditions))
                    .append(") AND STATUS <> '9'");

            // 排除当前记录（修改时）
            if (vo.getAIGlossaryId() != null && vo.getAIGlossaryId() != 0L) {
                sql.append(" AND AIGLOSSARYID != ?");
                params.add(vo.getAIGlossaryId());
            }

            pstmt = conn.prepareStatement(sql.toString());

            // 绑定参数
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            rs = pstmt.executeQuery();
            result = !rs.next(); // 无重复记录时返回true

        } catch (SQLException e) {
            System.err.println("术语查重异常:");
            e.printStackTrace();
            result = false;
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
        }
        return result;
    }

    /**
     * 根据部件创建语言获取
     * @param lang
     * @param attrValue
     * @return
     */
    /**
     * 根据语言类型和术语值查询术语表
     * @param termValue 术语值（如中文词、英文词等）
     * @param languageType 语言类型（CN/EN/DE）
     */
    public static AIGlossary getAIGlossaryByLang(String termValue, String languageType) throws SQLException {
        AIGlossary ag = new AIGlossary();
        WTConnection conn = CommonUtil.getWTConnection();
        String column;
        switch (languageType) {
            case Constant.AUTH_LAG_CN:
                column = "CHINESETERM";
                break;
            case Constant.AUTH_LAG_EN:
                column = "ENGLISHTERM";
                break;
            case Constant.AUTH_LAG_DE:
                column = "GERMANTERM";
                break;
            default:
                throw new IllegalArgumentException("无效的语言类型: " + languageType);
        }

        String sql = "SELECT * FROM AIGLOSSARY WHERE " + column + " = ? AND STATUS = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, termValue);
            pstmt.setString(2, Constant.ONE_Str);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return getAIGlossaryByRS(rs); // 解析结果集，处理多记录情况
                }

            }
        }
        return ag;
    }





}
