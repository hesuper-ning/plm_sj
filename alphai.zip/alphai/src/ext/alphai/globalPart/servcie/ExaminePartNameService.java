package ext.alphai.globalPart.servcie;

import com.ptc.core.lwc.common.view.PropertyHolderHelper;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.alphai.globalPart.vo.AICnEnDnExamineVo;
import ext.alphai.globalPart.vo.AIExamineNameVo;
import ext.alphai.globalPart.vo.PartNameExamineVo;
import ext.util.*;
import ext.util.PersistenceUtil;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.sql.Timestamp;
import java.util.*;

/**
 * 物料名称审核服务类
 */
public class ExaminePartNameService {


    public static List<AIExamineNameVo> selectExamineNameList(String statestate, int maturity, Date updateTimeStart, Date updateTimeEnd) throws WTException{
        List<AIExamineNameVo> vos = new ArrayList<>();
        QuerySpec querySpec = new QuerySpec(WTPart.class);
        Locale locale = GeneralService.getUserHostLanguage();
        querySpec.appendWhere(new SearchCondition(WTPart.class, WTPart.LIFE_CYCLE_STATE, SearchCondition.EQUAL, statestate));
        querySpec.appendAnd();
        querySpec.appendWhere(new SearchCondition(WTPart.class, WTPart.MODIFY_TIMESTAMP, SearchCondition.GREATER_THAN_OR_EQUAL, new Timestamp(updateTimeStart.getTime())));
        querySpec.appendAnd();
        querySpec.appendWhere(new SearchCondition(WTPart.class, WTPart.MODIFY_TIMESTAMP, SearchCondition.LESS_THAN_OR_EQUAL, new Timestamp(updateTimeEnd.getTime())));
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        Vector<WTPart> parts = queryResult.getObjectVectorIfc().getVector();

        List<WTPart> lastWTPartInList = PartUtil.getMaxVersionParts(parts);

        for (WTPart part : lastWTPartInList) {
            IBAUtil iba = new IBAUtil(part);
            String cnExamine = iba.getIBAValue(PropertiesUtil.getValueByKey("part.cn.examine"));
            String enExamine = iba.getIBAValue(PropertiesUtil.getValueByKey("part.en.examine"));
            String dnExamine = iba.getIBAValue(PropertiesUtil.getValueByKey("part.dn.examine"));
            int maturitySys = 0;
            AICnEnDnExamineVo aiCnEnDnExamineVo = new AICnEnDnExamineVo(false, false, false);
            if(Constant.ONE_Str.equals(cnExamine)){
                aiCnEnDnExamineVo.setChineseApproved(true);
                maturitySys ++;
            }
            if(Constant.ONE_Str.equals(enExamine)){
                aiCnEnDnExamineVo.setEnglishApproved(true);
                maturitySys ++;
            }
            if(Constant.ONE_Str.equals(dnExamine)){
                aiCnEnDnExamineVo.setGermanApproved(true);
                maturitySys ++;
            }

            if(maturitySys == maturity){
                AIExamineNameVo vo = new AIExamineNameVo();
                vo.setMaturity(maturitySys);
                vo.setOid(PersistenceUtil.object2Oid(part));
                vo.setPartNumber(part.getNumber());
                vo.setChineseTerm(iba.getIBAValue(PropertiesUtil.getValueByKey("part.JCCNNAME")));
                vo.setEnglishTerm(iba.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEEN")));
                vo.setGermanTerm(iba.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEDE")));
                vo.setPartURL(PartUtil.getPartUrlByPartNumber(part).getLink());
                vo.setExamineVo(aiCnEnDnExamineVo);
                vo.setLifeCycle(part.getLifeCycleState().getDisplay(locale));
                vos.add(vo);
            }

        }



        return vos;
    }

    /**
     * 执行审核动作
     * @param partNameExamineVo
     * @return
     */
    public static void doExaminePartName(PartNameExamineVo partNameExamineVo) throws Exception {
        String oid = partNameExamineVo.getOid();
        WTPart part = (WTPart) PersistenceUtil.oid2Object(oid);
        long id = part.getPersistInfo().getObjectIdentifier().getId();
        AICnEnDnExamineVo examineVo = partNameExamineVo.getExamineVo();
        String chineseApproved = Constant.ZERO_Str;
        String englishApproved = Constant.ZERO_Str;
        String germanApproved = Constant.ZERO_Str;
        if (examineVo.isChineseApproved()) {
            chineseApproved = Constant.ONE_Str;
        }
        if (examineVo.isEnglishApproved()) {
            englishApproved = Constant.ONE_Str;
        }
        if (examineVo.isGermanApproved()) {
            germanApproved = Constant.ONE_Str;
        }
        // 修改部件当前版本及 比它更新的版本部件的IBA
        QueryResult qr = VersionControlHelper.service.allVersionsOf(part.getMaster());
        while (qr.hasMoreElements()){
            IBAUtil ibaUtil = new IBAUtil();
            WTPart nextElement = (WTPart) qr.nextElement();
            long idDB = nextElement.getPersistInfo().getObjectIdentifier().getId();
            if(idDB >= id){
                ibaUtil.setIBAAttribute4AllType(nextElement, PropertiesUtil.getValueByKey("part.cn.examine"), chineseApproved);
                ibaUtil.setIBAAttribute4AllType(nextElement, PropertiesUtil.getValueByKey("part.en.examine"), englishApproved);
                ibaUtil.setIBAAttribute4AllType(nextElement, PropertiesUtil.getValueByKey("part.dn.examine"), germanApproved);
            }
        }
    }

    /**
     * 名称审核查询页面获取可用于筛选的部件状态
     * @return
     */
    public static Map<String, String> getAvailableState(){
        Map<String, String> map = new HashMap<>();
        Locale locale = GeneralService.getUserHostLanguage();
        String value = PropertiesUtil.getValueByKey("part.examine.state");
        String[] split = value.split(Constant.Comma);
        for (String stateName : split) {
            State state = State.toState(stateName);
            if(state != null){
                map.put(state.getValue(), state.getDisplay(locale));
            }
        }
        return map;
    }
}
