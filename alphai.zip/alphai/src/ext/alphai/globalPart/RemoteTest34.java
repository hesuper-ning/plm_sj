package ext.alphai.globalPart;

import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.windchill.csm.client.helpers.CSMTypeDefHelper;
import com.ptc.windchill.csm.common.CsmConstants;
import ext.alphai.globalPart.vo.ClassifyDataVo;
import ext.util.PersistenceUtil;
import ext.util.VersionUtil;
import wt.associativity.EquivalenceLink;
import wt.enterprise.RevisionControlled;
import wt.fc.*;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.preference.PreferenceHelper;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.series.HarvardSeries;
import wt.series.MultilevelSeries;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.wip.WorkInProgressHelper;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.*;


/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * 
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * 
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * 
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * 
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 * 
 * @author dz
 * ant -f bin/tools.xml class -Dclass.includes=ext/alphai/globalPart/RemoteTest30.java
 * windchill ext.alphai.globalPart.RemoteTest30
 */
public class RemoteTest34 implements RemoteAccess, Serializable {

	private static final long serialVersionUID = 1L;

	private static String CLASS_PATH;
	static {
		WTProperties wtProperties = null;
		try {
			wtProperties = WTProperties.getLocalProperties();
		} catch (IOException e) {

		}
		CLASS_PATH =wtProperties.getProperty("wt.codebase.location") + "\\"+"ext\\alphai\\sap\\saplog";
	}

	public static void main(String[] args) throws WTRuntimeException, WTException {

		String str = (String) invoke("process", RemoteTest34.class.getName(), null, new Class[]{}, new Object[]{});
	}

	public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("JieCang@002");
		try {
			return rms.invoke(methodName, className, instance, cla, obj);
		} catch (RemoteException e) {
			e.printStackTrace();
			return null;
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 从上游部件获取所有链接
	 * @param designPart
	 * @return
	 */
	private static List<EquivalenceLink> getLinkByDesignPart(WTPart designPart) throws WTException {
		List<EquivalenceLink> links = new ArrayList<>();
		QueryResult qr = wt.fc.PersistenceHelper.manager.navigate(designPart,wt.associativity.EquivalenceLink.DOWNSTREAM_ROLE, wt.associativity.EquivalenceLink.class, false);
		while (qr.hasMoreElements()){
			Object o = qr.nextElement();
			if(o instanceof EquivalenceLink){
				links.add((EquivalenceLink)o);
			}
		}
		return links;
	}


	/**
	 * 根据下游部件获取所有链接
	 * @param mPart
	 * @return
	 */
	private static List<EquivalenceLink> getLinksByMPart(WTPart mPart) throws WTException {
		List<EquivalenceLink> links = new ArrayList<>();
		QueryResult qr = wt.fc.PersistenceHelper.manager.navigate(mPart,wt.associativity.EquivalenceLink.UPSTREAM_ROLE, wt.associativity.EquivalenceLink.class, false);
		while (qr.hasMoreElements()){
			Object o = qr.nextElement();
			if(o instanceof EquivalenceLink){
				links.add((EquivalenceLink)o);
			}
		}
		return links;
	}
	private static EquivalenceLink createEquivalenceLink(WTPart dPart, WTPart mPart) throws WTPropertyVetoException, WTException {
		EquivalenceLink link = EquivalenceLink.newEquivalenceLink(dPart,mPart);
		link.setIsConsumable(true);
		link.setUpstreamContextRef(dPart.getView());
		link.setDownstreamContextRef(mPart.getView());
		// save 保存  modify修改
		try {
			link = (EquivalenceLink) PersistenceHelper.manager.save(link);
		} catch (WTException e) {
			e.printStackTrace();
		}
		return link;
	}


	public static List<WTPart> getWTPartListByNumber(String number) {
		List<WTPart> result = new ArrayList<WTPart>();
		QueryResult qr = null;
		try {
			QuerySpec qs = new QuerySpec(WTPart.class);
			SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
					number.toUpperCase());
			qs.appendSearchCondition(scnumber);
			qs.appendAnd();
			SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
			qs.appendSearchCondition(sclatest);
			qr = PersistenceHelper.manager.find(qs);
			while (qr != null && qr.hasMoreElements()) {
				WTPart part = (WTPart) qr.nextElement();
				if("Manufacturing".equals(part.getView().getName())){
					// 获取工作副本
//                    if(WorkInProgressHelper.isCheckedOut(part)){
//                        part = (WTPart) WorkInProgressHelper.service.workingCopyOf(part);
//                    }else {
//                        part = (WTPart)WorkInProgressHelper.service.checkout(part, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
//                    }
					result.add(part);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public static String process() {
		try {
			ReferenceFactory rf = new ReferenceFactory();
			WTPart designPart = (WTPart) rf.getReference("OR:wt.part.WTPart:12725025").getObject();
			System.out.println("测试创建Link");
			List<EquivalenceLink> equivalenceLinks = getLinkByDesignPart(designPart);
			System.out.println("link 个数为："+equivalenceLinks.size());
			List<WTPart> wtPartListByNumber = getWTPartListByNumber(designPart.getNumber());
			for (WTPart part : wtPartListByNumber) {
				System.out.println("相同编号的生产视图部件："+part);
				createEquivalenceLink(designPart, part);
			}



//			System.out.println("测试根据design视图部件获取对等链接");
//			List<EquivalenceLink> designLinks = getLinkByDesignPart(designPart);
//			for (EquivalenceLink designLink : designLinks) {
//				Persistable object = designLink.getRoleBObjectRef().getObject();
//				System.out.println("designLink:"+designLink);
//				System.out.println("对等链接关联的B部件："+ object);
//			}

//			System.out.println("根据生产视图获取的链接");
//			WTPart mPart = (WTPart) rf.getReference("OR:wt.part.WTPart:1151594834").getObject();
//			List<EquivalenceLink> mLinks = getLinksByMPart(mPart);
//			for (EquivalenceLink mLink : mLinks) {
//				Persistable object = mLink.getRoleAObjectRef().getObject();
//				System.out.println("mLink:"+mLink);
//				System.out.println("对等链接关联的A部件："+ object);
//			}
//			createEquivalenceLink(designPart, mPart);
//			System.out.println("");

//			reviseWTPartByNumber((WTPart)object);
//			upPart((WTPart)part);
//			String china = (String)PreferenceHelper.service.getValue("ext.alphai.globalPart.language.CHINA", "WINDCHILL");
//			String ENGLISH = (String)PreferenceHelper.service.getValue("ext.alphai.globalPart.language.ENGLISH", "WINDCHILL");
//			String GERMAN = (String)PreferenceHelper.service.getValue("ext.alphai.globalPart.language.GERMAN", "WINDCHILL");
//
//
//			System.out.println("china:"+china);
//			System.out.println("ENGLISH:"+ENGLISH);
//			System.out.println("GERMAN:"+GERMAN);
//			List<ClassifyDataVo> vos = new ArrayList<>();
			// 获取根分类
//			TypeDefinitionReadView rootClassification = getTopClassification();
//			List<ClassifyDataVo> canBeExemplified = getCanBeExemplified(rootClassification);
//			String tr = "Half-ASSY_Mixed_carbon2";
//			String fa = "Half-FG";
//			TypeDefinitionReadView nodeView1 = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, "com.ptc.csm.default_clf_namespace",tr);
//			TypeDefinitionReadView nodeView2 = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, "com.ptc.csm.default_clf_namespace",fa);
//
//			SessionHelper.getLocale();
//			System.out.println("nodeView1：显示值"+nodeView1.getDisplayName()+" 内部值："+nodeView1.getName());
//			System.out.println("nodeView2：显示值"+PropertyHolderHelper.getDisplayName(nodeView2, Locale.CHINESE)+" 内部值："+nodeView2.getName());
//			getDisplayNameByClassName(fa);



//			ClassificationFacade facadeInstance = ClassificationFacade.getInstance();
//			Object classificationNodeInfo = facadeInstance.getClassificationNodeInfo(tr,
//					CsmConstants.NAMESPACE);
//			EnumerationEntryInfo entryInfo = (EnumerationEntryInfo)classificationNodeInfo;
//			String internalName = entryInfo.getName();
//			String description = entryInfo.getLocalizablePropertyValue(EnumerationEntryInfo.DESCRIPTION,
//					SessionHelper.getLocale());
//			String displayName = entryInfo.getLocalizablePropertyValue(EnumerationEntryInfo.DISPLAY_NAME,
//					SessionHelper.getLocale());
//			String parentName = (String) entryInfo.getNonLocalizablePropertyValue(EnumerationEntryInfo.PARENT);
//			Integer sortOrder = (Integer) entryInfo.getNonLocalizablePropertyValue(EnumerationEntryInfo.SORT_ORDER);
//			Boolean selectable = (Boolean) entryInfo.getNonLocalizablePropertyValue(EnumerationEntryInfo.SELECTABLE);
//
//			System.out.println("internalName:"+internalName+" displayName:"+displayName+" sortOrder:"+sortOrder+" selectable"+selectable);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * 通过部件编号修订到下一个大版本
	 * @param number
	 * @return
	 */
	public static WTPart reviseWTPartByNumber(WTPart partByNumber) throws WTException, WTPropertyVetoException {
		System.out.println("333");
		// 修订后的部件对象
		WTPart afterReviseWTPart = null;
		// 获取当前版本
		RevisionControlled latestObjectByMaster = VersionUtil.getLatestObjectByMaster(partByNumber.getMaster());

		String bigVersion = latestObjectByMaster.getVersionIdentifier().getValue();
		System.out.println("当前部件的大版本为="+bigVersion);

		char c = bigVersion.charAt(0);
		String nextLetter = "B";
		System.out.println("获得到下一大版本="+nextLetter);

		// 修订
		// 大版本设定   wt.series.HarvardSeries   wt.series.HarvardSeries
		MultilevelSeries mls = MultilevelSeries.newMultilevelSeries ("wt.series.HarvardSeries", nextLetter);

//		HarvardSeries hds = HarvardSeries.newHarvardSeries("wt.series.HarvardSeries", nextLetter);


		// 小版本设定
		VersionIdentifier vid = VersionIdentifier.newVersionIdentifier(mls);
		IterationIdentifier iid = IterationIdentifier.newIterationIdentifier("1");

		afterReviseWTPart = (WTPart) VersionControlHelper.service.newVersion(partByNumber,vid,iid);
		afterReviseWTPart=(WTPart) PersistenceHelper.manager.save(afterReviseWTPart);

		return afterReviseWTPart;
	}





	public static void upPart(WTPart part) throws WTException, WTPropertyVetoException {

		MultilevelSeries multilevelseries = MultilevelSeries.newMultilevelSeries("wt.series.HarvardSeries.LogicDataCustom", "A");
		VersionIdentifier ver = VersionIdentifier.newVersionIdentifier(multilevelseries);
		IterationIdentifier iid = IterationIdentifier.newIterationIdentifier("1");
//		part = (WTPart)VersionControlHelper.service.newVersion(part, ver, iid);
		part = (WTPart)VersionControlHelper.service.newVersion(part);
		part.getMaster().setSeries("wt.series.HarvardSeries.LogicDataCustom");
		VersionControlHelper.setVersionIdentifier(part, ver);
		part = (WTPart)PersistenceHelper.manager.save(part);
	}








//	/**
//	 * 根据分类的内部值获取显示值
//	 * @param className
//	 * @return
//	 */
//	public static String getDisplayNameByClassName(String className){
//		String display = "";
//		try {
//
//		} catch (Exception e){
//			e.printStackTrace();
//		}
//
//		return display;
//	}
//
//
//
//
//
//	/**
//	 * 递归获取所有可实例分类节点（包含子树中的可用节点）
//	 * @param rootClassification 根分类节点
//	 * @return 所有可用节点列表
//	 */
//	public static List<ClassifyDataVo> getCanBeExemplified(TypeDefinitionReadView rootClassification) throws WTException {
//		List<ClassifyDataVo> vos = new ArrayList<>();
//		// 启动递归遍历
//		recursiveGetCanBeExemplified(rootClassification, vos);
//		return vos;
//	}
//
//
//	/**
//	 * 递归遍历分类节点
//	 * @param currentClassification 当前处理的分类节点
//	 * @param resultList 结果收集列表
//	 */
//	private static void recursiveGetCanBeExemplified(TypeDefinitionReadView currentClassification, List<ClassifyDataVo> resultList) throws WTException {
//		System.out.println("节点显示名："+currentClassification.getDisplayName()+" 内部名："+currentClassification.getName()+" 是否可实例isModeled："+currentClassification.isModeled()
//		+" isTypeManagedOnly:"+currentClassification.isTypeManagedOnly()+" isSubTypeable:"+currentClassification.isSubTypeable());
//
//		// 1. 处理当前节点
//		if (currentClassification.isModeled()) {
//			ClassifyDataVo vo = new ClassifyDataVo();
//			vo.setClassifyName(currentClassification.getName());
//			vo.setClassifyDisplayName(currentClassification.getDisplayName());
//			resultList.add(vo);
//		}
//
//		// 2. 递归处理所有子节点
//		Collection<TypeDefinitionReadView> childClassifications = CSMTypeDefHelper.getChildTypeDefViews(currentClassification);
//		for (TypeDefinitionReadView child : childClassifications) {
//			recursiveGetCanBeExemplified(child, resultList);
//		}
//	}
//	/**
//	 * 获取根节点
//	 * @return
//	 * @throws WTException
//	 */
//	public static TypeDefinitionReadView getTopClassification() throws WTException {
//		Collection<TypeDefinitionReadView> topClassification = CSMTypeDefHelper.getRootTypeDefViews(CsmConstants.NAMESPACE);
//		Iterator<TypeDefinitionReadView> itera = topClassification.iterator();
//		return itera.hasNext() ? (TypeDefinitionReadView)itera.next() : null;
//	}

}
