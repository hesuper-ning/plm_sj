package ext.alphai.globalPart.controller;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.GlossaryEnum;
import ext.alphai.globalPart.domain.AIGlossary;
import ext.alphai.globalPart.servcie.AIGlossaryService;
import ext.alphai.globalPart.servcie.AINamingRulesService;
import ext.alphai.globalPart.servcie.ExaminePartNameService;
import ext.alphai.globalPart.servcie.GeneralService;
import ext.alphai.globalPart.vo.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import wt.lifecycle.State;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * 全球物料命名规范控制器
 */
@Controller
@RequestMapping({ "/globalPartNaming" })
public class GlobalPartNamingController {
    //
    private static final String lastChinaName = "lastChinaName";
    private static final String lastEnglishName = "lastEnglishName";
    private static final String lastGermanName = "lastGermanName";

    static final ObjectMapper objectMapper = new ObjectMapper();

    public static final int partNameLength = 40;
    /**
     * 获取可编辑分类
     * @param request
     * @param response
     */
    @RequestMapping(value = "/selectEditableClassify", method = RequestMethod.GET )
    public void selectEditableClassify(HttpServletRequest request,HttpServletResponse response) throws IOException {
        SessionServerHelper.manager.setAccessEnforced(false);
        ResponseVo vo = null;
        try {
            List<ClassifyDataVo> classify = GeneralService.getClassify();
            vo = ResponseVo.success(classify);
        } catch (WTException e) {
            e.printStackTrace();
            vo = ResponseVo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);
    }



    /**
     * 查询分类规则
     * @param className
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/selectAINamingRules", method = RequestMethod.GET )
    public void selectAINamingRules(@RequestParam("className") String className, HttpServletRequest request,
                                                 HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        SessionServerHelper.manager.setAccessEnforced(false);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        try {
            ClassifyAttrVo classifyAttrVoByClassName = AINamingRulesService.getClassifyAttrVoByClassName(className);
            vo = ResponseVo.success(classifyAttrVoByClassName);
        } catch (Exception e) {
            vo = ResponseVo.error(500, e.getMessage());
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }

        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);
    }

    /**
     * 新增或修改命名规则
     * @param json
     * @param request
     * @param response
     */
    @RequestMapping(value = "/insertAINamingRules", method = RequestMethod.POST )
    public void insertAINamingRules(@RequestBody String json, HttpServletRequest request,
                                    HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        SessionServerHelper.manager.setAccessEnforced(false);
        ResponseVo vo = null;
        try {
            AINamingRulesReqVo aiNamingRulesReqVo = objectMapper.readValue(json, new TypeReference<AINamingRulesReqVo>() {});
            int i = AINamingRulesService.insertOrUpdateAINamingRules(aiNamingRulesReqVo.getClassName(), aiNamingRulesReqVo.getRulesList());
            vo = ResponseVo.result(i);
        } catch (Exception e) {
            vo = ResponseVo.error(500, e.getMessage());
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);

    }

    /**
     * 分页查询术语库
     * @param pageCount 当前页
     * @param chinaName 中文
     * @param englishName 英语
     * @param germanName 德语
     * @param status 状态 0 1 9
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/selectAIGlossaryByPara", method = RequestMethod.GET )
    public void selectAIGlossaryByPara(@RequestParam("pageCount") Integer pageCount, @RequestParam("chinaName") String chinaName,
            @RequestParam("englishName") String englishName, @RequestParam("germanName") String germanName, @RequestParam("status") String status,
                                       HttpServletRequest request,HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        SessionServerHelper.manager.setAccessEnforced(false);
        boolean nameOrNumberChanged = !Objects.equals(request.getSession().getAttribute(lastChinaName), chinaName) ||
                !Objects.equals(request.getSession().getAttribute(lastEnglishName), englishName) || !Objects.equals(request.getSession().getAttribute(lastGermanName), germanName);
        if (nameOrNumberChanged) {
            pageCount = 1;
        }
        request.getSession().setAttribute(lastChinaName, chinaName);
        request.getSession().setAttribute(lastEnglishName, englishName);
        request.getSession().setAttribute(lastGermanName, germanName);

        GlossaryEnum objectByKey = GlossaryEnum.getObjectByKey(status);

        Integer pageNumber = AIGlossaryService.getSelectCount(chinaName, englishName, germanName, objectByKey);

        int totalPages = (pageNumber + Constant.pageSize - 1) / Constant.pageSize;
        System.out.println("[分页计算] 总页数: " + totalPages);
        System.out.println("当前条件查询的总数据数量："+pageNumber);
        List<AIGlossary> selectGlossaryList = AIGlossaryService.getSelectGlossaryList(pageCount, Constant.pageSize, chinaName, englishName, germanName, objectByKey);
        List<AIGlossaryVo> aiGlossaryVo = AIGlossaryService.getAIGlossaryVo(selectGlossaryList);
        TableDataInfo dataTable = TableDataInfo.getDataTable(aiGlossaryVo, pageNumber, pageCount, totalPages);
        SessionServerHelper.manager.setAccessEnforced(true);
        String resultJson = objectMapper.writeValueAsString(dataTable);
        outResponse(response, resultJson);
    }


    /**
     * 插入术语库
     * @param json
     * @param request
     * @param response
     */
    @RequestMapping(value = "/insertGlossaryList", method = RequestMethod.POST )
    public void insertGlossaryList(@RequestBody String json, HttpServletRequest request,
                                    HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        SessionServerHelper.manager.setAccessEnforced(false);
        response.setCharacterEncoding("UTF-8");
        System.out.println("新增术语库前端传来的json:"+json);
        ResponseVo vo = null;
        try {
            List<AIGlossaryVo> aiGlossaryVos = objectMapper.readValue(json, new TypeReference<List<AIGlossaryVo>>() {});
            // 失败的对象集合
            List<AIGlossaryVo> repeatList = new ArrayList<>();
            for (AIGlossaryVo aiGlossaryVo : aiGlossaryVos) {
                String englishTerm = aiGlossaryVo.getEnglishTerm();
                if(!StringUtils.isBlank(englishTerm)){
                    String upperCase = englishTerm.toUpperCase();
                    aiGlossaryVo.setEnglishTerm(upperCase);
                }
            }
            int i = AIGlossaryService.insertGlossary(aiGlossaryVos, repeatList);
            // 根据失败对象集合返回提示数据
            StringBuilder msg = new StringBuilder();
            if (!repeatList.isEmpty()) {
                msg.append(objectMapper.writeValueAsString(repeatList)).append("发现重复术语不允许添加");
                vo = ResponseVo.success(202, msg.toString());
            }else {
                vo = ResponseVo.success(i);
            }
        } catch (Exception e){
            vo = ResponseVo.error(500, e.getMessage());
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }

    /**
     * 批量修改术语状态
     * json
     * @param request
     * @param response
     */
    @RequestMapping(value = "/updateGlossaryStatus", method = RequestMethod.POST )
    public void updateGlossaryStatus(@RequestBody String json,
                                     HttpServletRequest request,HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        SessionServerHelper.manager.setAccessEnforced(false);
        ResponseVo vo = null;
        try {
            List<AIGlossaryVo> aiGlossaryVos = objectMapper.readValue(json, new TypeReference<List<AIGlossaryVo>>() {});
            int i = AIGlossaryService.updateGlossaryStatus(aiGlossaryVos);
            vo = ResponseVo.success(i);
        } catch (Exception e)
        {
            vo = ResponseVo.error(500, e.getMessage());
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }





    /**
     * 修改术语
     * @param json
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/updateGlossaryList", method = RequestMethod.POST )
    public void updateGlossaryList(@RequestBody String json, HttpServletRequest request,
                                    HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        SessionServerHelper.manager.setAccessEnforced(false);
        System.out.println("修改术语库前端传来的json:"+json);
        try {
            AIGlossaryVo aiGlossaryVo = objectMapper.readValue(json, new TypeReference<AIGlossaryVo>() {});
            String englishTerm = aiGlossaryVo.getEnglishTerm();
            if(!StringUtils.isBlank(englishTerm)){
                String upperCase = englishTerm.toUpperCase();
                aiGlossaryVo.setEnglishTerm(upperCase);
            }
            int i = AIGlossaryService.updateGlossary(aiGlossaryVo);
            vo = ResponseVo.result(i);
        } catch (Exception e){
            vo = ResponseVo.error(500, e.getMessage());
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }


    /**
     * 部件创建编辑页面获取所填数据的中英德语
     * @param className 分类节点内部名
     * @param attrName 分类属性
     * @param enumName
     * @param attrValue
     * @param type
     * @param partAuthLang
     * @param request
     * @param response
     */
    @RequestMapping(value = "/selectAttrTermDisplayName", method = RequestMethod.GET )
    public void selectAttrTermDisplayName(@RequestParam("className") String className,@RequestParam("attrName") String attrName,
                                           @RequestParam("enumName") String enumName, @RequestParam("attrValue") String attrValue,
                                          @RequestParam("type") String type,@RequestParam("partAuthLang") String partAuthLang,
                                           HttpServletRequest request,HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        SessionServerHelper.manager.setAccessEnforced(false);
        try {
            AttrCnEnGeVo attrCnEnGeVo = GeneralService.selectAttrTermDisplayName(className, attrName, enumName, attrValue, type, partAuthLang);
            vo = ResponseVo.success(attrCnEnGeVo);
        } catch (Exception e) {
            e.printStackTrace();
            vo = ResponseVo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);

    }

    /**
     * 根据分类节点内部名获取分类节点三语显示值
     * @param className
     * @param request
     * @param response

    @RequestMapping(value = "/selectClassifyCNENGE", method = RequestMethod.GET )
    public void selectClassifyCNENGE(@RequestParam("className") String className, HttpServletRequest request,HttpServletResponse response)throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        AttrCnEnGeVo attrCnEnGeVo = new AttrCnEnGeVo();
        try {
            TypeDefinitionReadView nodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, "com.ptc.csm.default_clf_namespace",className);
            String chinaName = PropertyHolderHelper.getDisplayName(nodeView, Locale.CHINESE);
            String enName = PropertyHolderHelper.getDisplayName(nodeView, Locale.UK);
            String geName = PropertyHolderHelper.getDisplayName(nodeView, Locale.GERMAN);
            attrCnEnGeVo.setCnName(chinaName);
            attrCnEnGeVo.setEnName(enName);
            attrCnEnGeVo.setGeName(geName);
            vo = ResponseVo.success(attrCnEnGeVo);
        } catch (Exception e){
            e.printStackTrace();
            vo = ResponseVo.error(500, e.getMessage());
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }

     */

    /**
     * 部件 主语言名称重复性校验按钮
     * @param mainLangName 主语言部件名称
     * @param request
     * @param response
     */
    @RequestMapping(value = "/nameRepeatabilityVerification", method = RequestMethod.GET )
    public void nameRepeatabilityVerification(@RequestParam("mainLangName") String mainLangName,@RequestParam("AICount") String AICount
            ,@RequestParam("partoid") String partoid, HttpServletRequest request,HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        SessionServerHelper.manager.setAccessEnforced(false);
        try {
            vo = GeneralService.hostLangRepeatabilityVerification(mainLangName, AICount, partoid);
        } catch (Exception e){
            e.printStackTrace();
            vo = ResponseVo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }

        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }


    /**
     * 部件名称审核查询页面
     * @param lifeCycle  生命周期状态内部值
     * @param maturity 成熟度
     * @param updateTimeStart 部件修改时间区间 开始
     * @param updateTimeEnd 部件修改时间区间 结束
     * @param request
     * @param response
     */
    @RequestMapping(value = "/partNameToExamine", method = RequestMethod.GET )
    public void partNameToExamine(@RequestParam("lifeCycle") String lifeCycle, @RequestParam("maturity") int maturity
            , @RequestParam("updateTimeStart") @DateTimeFormat(pattern = "yyyy-MM-dd") Date updateTimeStart, @RequestParam("updateTimeEnd") @DateTimeFormat(pattern = "yyyy-MM-dd")Date updateTimeEnd,
                                  HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        SessionServerHelper.manager.setAccessEnforced(false);
        try {
            List<AIExamineNameVo> aiExamineNameVos = ExaminePartNameService.selectExamineNameList(lifeCycle, maturity, updateTimeStart, updateTimeEnd);
            vo = ResponseVo.success(aiExamineNameVos);
        } catch (WTException e){
            e.printStackTrace();
            vo = ResponseVo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }

    /**
     * 审核名称
     * @param json
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/nameExamine", method = RequestMethod.POST)
    public void nameExamine (@RequestBody String json ,HttpServletRequest request, HttpServletResponse response)throws IOException{
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        SessionServerHelper.manager.setAccessEnforced(false);
        PartNameExamineVo partNameExamineVo = objectMapper.readValue(json, new TypeReference<PartNameExamineVo>() {});
        try {
            ExaminePartNameService.doExaminePartName(partNameExamineVo);
            vo = ResponseVo.success("");
        } catch (Exception e){
            e.printStackTrace();
            vo = ResponseVo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }

    /**
     * 名称审核查询页面获取可用于筛选的部件状态
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/getAvailableState", method = RequestMethod.GET)
    public void getAvailableState(HttpServletRequest request, HttpServletResponse response)throws IOException{
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        SessionServerHelper.manager.setAccessEnforced(false);
        ResponseVo vo = null;
        try {
            Map<String, String> availableState = ExaminePartNameService.getAvailableState();
            vo = ResponseVo.success(availableState);
        } catch (Exception e){
            e.printStackTrace();
            vo = ResponseVo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }



    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }
}
