package ext.alphai.globalPart.listen;

public interface JCCreatePartFolderListen {
}
