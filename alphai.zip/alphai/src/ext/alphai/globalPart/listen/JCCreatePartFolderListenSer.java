package ext.alphai.globalPart.listen;

import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.meta.descriptor.common.DefinitionDescriptor;
import com.ptc.core.meta.descriptor.common.DefinitionDescriptorFactory;
import com.ptc.core.meta.type.mgmt.server.impl.TypeDomainHelper;
import com.ptc.netmarkets.work.WorkItemHelper;
import ext.alphai.globalPart.servcie.PartContainerFolderService;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.util.PartUtil;
import ext.util.PersistenceUtil;
import wt.events.KeyedEventListener;
import wt.fc.PersistenceManagerEvent;
import wt.part.WTPart;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.VersionControlServiceEvent;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.WorkInProgressServiceEvent;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * 监听部件创建和检入 将部件位置移动至指定容器和文件夹下
 */
public class JCCreatePartFolderListenSer extends StandardManager implements JCCreatePartFolderListen, Serializable {

    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = JCCreatePartFolderListenSer.class.getName();
    private KeyedEventListener listener;


    public JCCreatePartFolderListenSer() {
    }

    public static JCCreatePartFolderListenSer newJCCreatePartFolderListenSer() throws WTException {
        JCCreatePartFolderListenSer instance = new JCCreatePartFolderListenSer();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new JCCreatePartFolderListenSer.WCListenerEventListener(getConceptualClassname());
        //创建对象

//        getManagerService().addEventListener(this.listener, WorkInProgressServiceEvent.generateEventKey(WorkInProgressServiceEvent.POST_CHECKIN ));//新检入
        getManagerService().addEventListener(this.listener, PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_STORE));//创建
    }


    class WCListenerEventListener extends ServiceEventListenerAdapter {

        public WCListenerEventListener(String s) {
            super(s);
        }

        @Override
        public void notifyVetoableEvent(Object event) throws Exception {

            if (event instanceof PersistenceManagerEvent) {
                System.out.println("创建事件");
                PersistenceManagerEvent eve = (PersistenceManagerEvent) event;
                Object target = eve.getEventTarget();
//                System.out.println(target);
                movePart(target);
            }
//            else if (event instanceof WorkInProgressServiceEvent){
//                System.out.println("检入事件");
//                WorkInProgressServiceEvent eve = (WorkInProgressServiceEvent) event;
//                Object target = eve.getEventTarget();
////                System.out.println(target);
//                movePart(target);
//            }

        }
    }

    /**
     * 移动部件位置
     * @param target
     */
    private static void movePart(Object target) throws WTException, SQLException {
        if(target instanceof WTPart){
            WTPart part = (WTPart) target;
            if (WorkInProgressHelper.isCheckedOut(part)) {
                return;
            }
            // LD子类型不移动
//            if(excludeLDPart(part)){
//                return;
//            }
            PartContainerFolderService.setPartToFolder(part);
        }
    }

    /**
     * 如果是LD子类型部件返回true
     * @param part
     * @return
     */
    private static boolean excludeLDPart(WTPart part) throws WTException {
        boolean r = false;
//        final DefinitionDescriptorFactory DESCRIPTOR_FACTORY = (DefinitionDescriptorFactory) DefaultServiceProvider.getService(DefinitionDescriptorFactory.class, "default");
        String valueByKey = PropertiesUtil.getValueByKey("LD.part.type");
        // 部件子类型
        String subTypeInternal = PersistenceUtil.getSubTypeInternal(part);
        TypeIdentifier tid = TypeDefinitionServiceHelper.service.getTypeIdentifier(valueByKey);
        TypeIdentifier[] tis = TypedUtilityServiceHelper.service.getSubtypes(tid, false, false, TypeDomainHelper.getDefaultContainerIdentifier());
        List<String> list = new ArrayList<>();
        for (int i = 0; i < tis.length; i++)
        {
            TypeIdentifier typei = tis[i];
            String typeName = typei.getTypename();

            // 使用转义字符分割竖线（|是正则特殊字符）
            String[] parts = typeName.split("\\|");

            // 取分割后的最后一个元素（如果分割后数组不为空）
            String lastPart = parts.length > 0 ? parts[parts.length - 1] : typeName;

            list.add(lastPart);
//            String typeDisplayName =   TypedUtilityServiceHelper.service.getLocalizedTypeName(tis[tt]).getLocalizedMessage(Locale.getDefault());
//            DefinitionDescriptor ti_desc = DESCRIPTOR_FACTORY.get(sub_tid[tt]);
//            String description = ti_desc.getLongDescription();
        }
        if(list.contains(subTypeInternal)){
            r = true;
        }
        return r;
    }

}
