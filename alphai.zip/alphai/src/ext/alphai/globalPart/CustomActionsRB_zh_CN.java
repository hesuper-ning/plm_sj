package ext.alphai.globalPart;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;
@RBUUID("ext.alphai.globalPart.CustomActionsRB_zh_CN")
public class CustomActionsRB_zh_CN extends WTListResourceBundle {

    @RBEntry("术语库")
    public static final String PRIVATE_CONSTANT_1= "jcGlobalPart.jcGlossary.description";
    @RBEntry("术语库")
    public static final String PRIVATE_CONSTANT_2 = "jcGlobalPart.jcGlossary.tooltip";

    @RBEntry("命名规则")
    public static final String PRIVATE_CONSTANT_3= "jcGlobalPart.jcNamingRules.description";
    @RBEntry("命名规则")
    public static final String PRIVATE_CONSTANT_4 = "jcGlobalPart.jcNamingRules.tooltip";

    @RBEntry("物料名称审核")
    public static final String PRIVATE_CONSTANT_5= "jcGlobalPart.jcNamingExamine.description";
    @RBEntry("物料名称审核")
    public static final String PRIVATE_CONSTANT_6 = "jcGlobalPart.jcNamingExamine.tooltip";

    @RBEntry("修订LD部件")
    public static final String PRIVATE_CONSTANT_7= "jcGlobalPart.revisedLDversionWizard.description";
    @RBEntry("修订LD部件")
    public static final String PRIVATE_CONSTANT_8 = "jcGlobalPart.revisedLDversionWizard.tooltip";

    @RBEntry("修订LD部件")
    public static final String PRIVATE_CONSTANT_9= "jcGlobalPart.revisedLDversion.description";
    @RBEntry("修订LD部件")
    public static final String PRIVATE_CONSTANT_10 = "jcGlobalPart.revisedLDversion.tooltip";
	
	
	
	@RBEntry("升级为全球部件")
    public static final String PRIVATE_CONSTANT_13= "jcGlobalPart.setGlobalPart.description";
    @RBEntry("升级为全球部件")
    public static final String PRIVATE_CONSTANT_14 = "jcGlobalPart.setGlobalPart.tooltip";

    @RBEntry("设置LD/JC State")
    public static final String PRIVATE_CONSTANT_15= "jcGlobalPart.setLDJCState.description";
    @RBEntry("设置LD/JC State")
    public static final String PRIVATE_CONSTANT_16 = "jcGlobalPart.setLDJCState.tooltip";

    @RBEntry("JY 修改CAD文档版本")
    public static final String PRIVATE_CONSTANT_17= "jcGlobalPart.CADChangeVersionWizard.description";
    @RBEntry("JY 修改CAD文档版本")
    public static final String PRIVATE_CONSTANT_18 = "jcGlobalPart.CADChangeVersionWizard.tooltip";


    @RBEntry("传播到全部工厂")
    public static final String PRIVATE_CONSTANT_19= "jcGlobalPart.copyDesignPartAttrToAllManufacturingParts.description";
    @RBEntry("传播到全部工厂")
    public static final String PRIVATE_CONSTANT_20 = "jcGlobalPart.copyDesignPartAttrToAllManufacturingParts.tooltip";

    @RBEntry("获取设计属性")
    public static final String PRIVATE_CONSTANT_21= "jcGlobalPart.copyDesignPartAttrToThisManufacturingPart.description";
    @RBEntry("获取设计属性")
    public static final String PRIVATE_CONSTANT_22 = "jcGlobalPart.copyDesignPartAttrToThisManufacturingPart.tooltip";

    @RBEntry("部件属性拷贝")
    public static final String PRIVATE_CONSTANT_99 = "object.copyDesignAttribute.description";
}
