package ext.alphai.globalPart;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.globalPart.CustomActionsRB_de")
public class CustomActionsRB_de extends WTListResourceBundle {
    @RBEntry("JC Begriffsbibliothek")
    public static final String PRIVATE_CONSTANT_1= "jcGlobalPart.jcGlossary.description";
    @RBEntry("JC Begriffsbibliothek")
    public static final String PRIVATE_CONSTANT_2 = "jcGlobalPart.jcGlossary.tooltip";

    @RBEntry("Regeln der Materialbenannung")
    public static final String PRIVATE_CONSTANT_3= "jcGlobalPart.jcNamingRules.description";
    @RBEntry("Regeln der Materialbenannung")
    public static final String PRIVATE_CONSTANT_4 = "jcGlobalPart.jcNamingRules.tooltip";

    @RBEntry("Materialnamenprüfung")
    public static final String PRIVATE_CONSTANT_5= "jcGlobalPart.jcNamingExamine.description";
    @RBEntry("Materialnamenprüfung")
    public static final String PRIVATE_CONSTANT_6 = "jcGlobalPart.jcNamingExamine.tooltip";

    @RBEntry("Überarbeitung LD Teil")
    public static final String PRIVATE_CONSTANT_7= "jcGlobalPart.revisedLDversionWizard.description";
    @RBEntry("Überarbeitung LD Teil")
    public static final String PRIVATE_CONSTANT_8 = "jcGlobalPart.revisedLDversionWizard.tooltip";
    @RBEntry("Überarbeitung LD Teil")
    public static final String PRIVATE_CONSTANT_9= "jcGlobalPart.revisedLDversion.description";
    @RBEntry("Überarbeitung LD Teil")
    public static final String PRIVATE_CONSTANT_10 = "jcGlobalPart.revisedLDversion.tooltip";
	
	
	
	
	@RBEntry("Elevate to Global Parts")
    public static final String PRIVATE_CONSTANT_13= "jcGlobalPart.setGlobalPart.description";
    @RBEntry("Elevate to Global Parts")
    public static final String PRIVATE_CONSTANT_14 = "jcGlobalPart.setGlobalPart.tooltip";

    @RBEntry("auf LD/JC-Zustand setzen")
    public static final String PRIVATE_CONSTANT_15= "jcGlobalPart.setLDJCState.description";
    @RBEntry("auf LD/JC-Zustand setzen")
    public static final String PRIVATE_CONSTANT_16 = "jcGlobalPart.setLDJCState.tooltip";

    @RBEntry("JY CAD-Dokumentversion ändern")
    public static final String PRIVATE_CONSTANT_17= "jcGlobalPart.CADChangeVersionWizard.description";
    @RBEntry("JY CAD-Dokumentversion ändern")
    public static final String PRIVATE_CONSTANT_18 = "jcGlobalPart.CADChangeVersionWizard.tooltip";


    @RBEntry("Auf alle Fabriken verbreiten")
    public static final String PRIVATE_CONSTANT_19= "jcGlobalPart.copyDesignPartAttrToAllManufacturingParts.description";
    @RBEntry("Auf alle Fabriken verbreiten")
    public static final String PRIVATE_CONSTANT_20 = "jcGlobalPart.copyDesignPartAttrToAllManufacturingParts.tooltip";

    @RBEntry("Designattribute abrufen")
    public static final String PRIVATE_CONSTANT_21= "jcGlobalPart.copyDesignPartAttrToThisManufacturingPart.description";
    @RBEntry("Designattribute abrufen")
    public static final String PRIVATE_CONSTANT_22 = "jcGlobalPart.copyDesignPartAttrToThisManufacturingPart.tooltip";

    @RBEntry("Kopieren Sie das Designattribut")
    public static final String PRIVATE_CONSTANT_99 = "object.copyDesignAttribute.description";
}
