package ext.alphai.globalPart.domain;

/**
 * 命名规则数据库映射
 */
public class AINamingRules {

    /*
    分类内部名
    */
    private String classifyName;
    /*
    命名规则
    */
    private String namingRules;

    /*
    创建时间
     */
    private String createTime;

    /*
    修改时间
     */
    private String updateTime;

    public String getClassifyName() {
        return classifyName;
    }

    public void setClassifyName(String classifyName) {
        this.classifyName = classifyName;
    }

    public String getNamingRules() {
        return namingRules;
    }

    public void setNamingRules(String namingRules) {
        this.namingRules = namingRules;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public AINamingRules() {
    }

    public AINamingRules(String classifyName, String namingRules, String createTime, String updateTime) {
        this.classifyName = classifyName;
        this.namingRules = namingRules;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }
}
