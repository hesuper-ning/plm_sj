package ext.alphai.globalPart.method;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.globalPart.servcie.AINamingRulesService;
import ext.alphai.globalPart.vo.AINamingRulesReqVo;
import org.apache.poi.ss.usermodel.*;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.util.WTException;
import wt.util.WTRuntimeException;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

/**
 * 批量导入分类规则 远程调用方法
 * ant -f bin/tools.xml class -Dclass.includes=ext/alphai/globalPart/method/ImportClassifyMethod.java
 * windchill ext.alphai.globalPart.method.ImportClassifyMethod
 */
public class ImportClassifyMethod implements RemoteAccess, Serializable {
    private static final long serialVersionUID = 1L;

    public static void main(String[] args) throws WTRuntimeException, WTException {

        String str = (String) invoke("process", ImportClassifyMethod.class.getName(), null, new Class[]{}, new Object[]{});
    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("JieCang@002");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }

    /* org.apache.poi 读取
    AINamingRulesReqVo  属性有     private String className;      public List<String> rulesList;
    读取 一行是一个AINamingRulesReqVo 对象 用于放置到list集合中
    第一列是className ，第二列是连接符号  从第三列开始组合成rulesList集合
    组成的rulesList集合 的对象是  ["IBA|AI_Type","-","IBA|AI_Length","-","IBA|AI_Width","-","IBA|AI_Height","-","IBA|AI_Count"]
    M8100	-	AI_Type	AI_Length	AI_Width	AI_Height	AI_Count
    M8080	-	AI_Type	AI_Outer_Diameter	AI_Hardness	AI_Length	PTC_MATERIAL_NAME	AI_Count
    M8030	-	AI_Type	AI_Inner_Diameter	AI_Outer_Diameter	AI_Thickness	AI_Surface	AI_Count
    M8050	-	AI_Type	AI_Standard_Type	AI_Pitch	AI_Count
    M8130	-	AI_Type	AI_Strength	AI_Count
    ... 按照这个规则可能有好多行对象 只是每一行的列数不一定  碰到空字符串旧代表这一行结束 不用把空放进集合
     */
    public static String process() throws Exception{
        ObjectMapper objectMapper = new ObjectMapper();
        String filePath = "C:\\导入分类规则模板.xlsx";
        File excelFile = new File(filePath);
        List<AINamingRulesReqVo> list = new ArrayList<>();
        DataFormatter dataFormatter = new DataFormatter();

        try (InputStream inputStream = new FileInputStream(excelFile);
             Workbook workbook = WorkbookFactory.create(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                // 读取className（第一列）
                Cell classNameCell = row.getCell(0);
                if (classNameCell == null) continue;
                String className = dataFormatter.formatCellValue(classNameCell).trim();
                if (className.isEmpty()) continue;

                // 读取连接符号（第二列）
                Cell separatorCell = row.getCell(1);
                String separator = dataFormatter.formatCellValue(separatorCell).trim();

                // 读取第三列及后续非空单元格，并添加"IBA|"前缀
                List<String> ruleParts = new ArrayList<>();
                for (int colIdx = 2; ; colIdx++) {
                    Cell cell = row.getCell(colIdx);
                    if (cell == null) break; // 单元格不存在则终止
                    String value = dataFormatter.formatCellValue(cell).trim();
                    if (value.isEmpty()) break; // 单元格内容为空则终止
                    ruleParts.add("IBA|" + value);
                }

                if (ruleParts.isEmpty()) continue; // 无有效规则时跳过

                // 构建rulesList（交替插入连接符）
                List<String> rulesList = new ArrayList<>();
                for (int i = 0; i < ruleParts.size(); i++) {
                    rulesList.add(ruleParts.get(i));
                    if (i < ruleParts.size() - 1) rulesList.add(separator);
                }

                // 创建对象并添加到列表
                AINamingRulesReqVo vo = new AINamingRulesReqVo();
                vo.setClassName(className);
                vo.setRulesList(rulesList);
                list.add(vo);
            }
        }

        // 设置
        for (AINamingRulesReqVo vo : list) {
            System.out.println("分类内部值："+vo.getClassName());
            List<String> rulesList = vo.getRulesList();
            System.out.println("规则json："+objectMapper.writeValueAsString(rulesList));
            AINamingRulesService.insertOrUpdateAINamingRules(vo.getClassName(), rulesList);
        }

        System.out.println("---导入分类规则完成---");
        return null;
    }



}
