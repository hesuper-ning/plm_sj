package ext.alphai.globalPart.vo;

/**
 * 部件名称审核VO
 */
public class PartNameExamineVo {
    private String oid;
    private AICnEnDnExamineVo examineVo;

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public AICnEnDnExamineVo getExamineVo() {
        return examineVo;
    }

    public void setExamineVo(AICnEnDnExamineVo examineVo) {
        this.examineVo = examineVo;
    }
}
