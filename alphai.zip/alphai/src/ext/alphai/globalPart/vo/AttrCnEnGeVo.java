package ext.alphai.globalPart.vo;

/**
 * 属性的中英德
 */
public class AttrCnEnGeVo {


    private String cnName;

    private String enName;

    private String geName;


    public String getCnName() {
        return cnName;
    }

    public void setCnName(String cnName) {
        this.cnName = cnName;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public String getGeName() {
        return geName;
    }

    public void setGeName(String geName) {
        this.geName = geName;
    }

    public AttrCnEnGeVo() {
    }


    public AttrCnEnGeVo(String cnName, String enName, String geName) {
        this.cnName = cnName;
        this.enName = enName;
        this.geName = geName;
    }
}
