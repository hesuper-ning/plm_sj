package ext.alphai.globalPart.vo;

/**
 * 分类属性对象
 */
public class ClassifyAttrDataVo {
    /*
    分类属性内部名
     */
    private String attributeName;


    /*
    分类属性显示名
     */
    private String attributeDisplayName;

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public String getAttributeDisplayName() {
        return attributeDisplayName;
    }

    public void setAttributeDisplayName(String attributeDisplayName) {
        this.attributeDisplayName = attributeDisplayName;
    }

    public ClassifyAttrDataVo(String attributeName, String attributeDisplayName) {
        this.attributeName = attributeName;
        this.attributeDisplayName = attributeDisplayName;
    }

    public ClassifyAttrDataVo() {
    }
}
