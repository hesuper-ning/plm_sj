package ext.alphai.globalPart.vo;

public class AIGlossaryVo {
    /*
    主键id
     */
    private Long AIGlossaryId;
    /*
    英文术语
     */
    private String englishTerm;
    /*
    中文术语
     */
    private String chineseTerm;
    /*
    德文术语
     */
    private String germanTerm;
    /*
    状态显示值
     */
    private String status;
    /*
    创建时间
     */
    private String createTime;
    /*
    创建者fileName
     */
    private String createBy;
    /*
    修改时间
     */
    private String updateTime;

    public Long getAIGlossaryId() {
        return AIGlossaryId;
    }

    public void setAIGlossaryId(Long AIGlossaryId) {
        this.AIGlossaryId = AIGlossaryId;
    }

    public String getEnglishTerm() {
        return englishTerm;
    }

    public void setEnglishTerm(String englishTerm) {
        this.englishTerm = englishTerm;
    }

    public String getChineseTerm() {
        return chineseTerm;
    }

    public void setChineseTerm(String chineseTerm) {
        this.chineseTerm = chineseTerm;
    }

    public String getGermanTerm() {
        return germanTerm;
    }

    public void setGermanTerm(String germanTerm) {
        this.germanTerm = germanTerm;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public AIGlossaryVo() {
    }

    public AIGlossaryVo(Long AIGlossaryId, String englishTerm, String chineseTerm, String germanTerm, String status, String createTime, String createBy, String updateTime) {
        this.AIGlossaryId = AIGlossaryId;
        this.englishTerm = englishTerm;
        this.chineseTerm = chineseTerm;
        this.germanTerm = germanTerm;
        this.status = status;
        this.createTime = createTime;
        this.createBy = createBy;
        this.updateTime = updateTime;
    }
}
