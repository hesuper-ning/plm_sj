package ext.alphai.globalPart.vo;

import java.util.List;

public class ClassifyAttrVo {

    /*
    分类内部名
     */
    private String classifyName;

    /*
    显示内部名
     */
    private String classifyDisplayName;

    private AttrCnEnGeVo displayName;

    /*
    分类命名规则
     */
    private List<String> classifyRules;

    /*
    分类属性对象集合
     */
    private List<ClassifyAttrDataVo> attrDatas;



    public String getClassifyName() {
        return classifyName;
    }

    public void setClassifyName(String classifyName) {
        this.classifyName = classifyName;
    }

    public String getClassifyDisplayName() {
        return classifyDisplayName;
    }

    public void setClassifyDisplayName(String classifyDisplayName) {
        this.classifyDisplayName = classifyDisplayName;
    }

    public List<String> getClassifyRules() {
        return classifyRules;
    }

    public void setClassifyRules(List<String> classifyRules) {
        this.classifyRules = classifyRules;
    }

    public List<ClassifyAttrDataVo> getAttrDatas() {
        return attrDatas;
    }

    public void setAttrDatas(List<ClassifyAttrDataVo> attrDatas) {
        this.attrDatas = attrDatas;
    }

    public AttrCnEnGeVo getDisplayName() {
        return displayName;
    }

    public void setDisplayName(AttrCnEnGeVo displayName) {
        this.displayName = displayName;
    }
}
