package ext.alphai.globalPart.vo;

import java.io.Serializable;
import java.util.List;

/**
 * 表格分页数据对象
 * 
 * @author ruoyi
 */
public class TableDataInfo implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 总记录数 */
    private Integer total;

    /** 列表数据 */
    private List<?> rows;

    /** 消息状态码 */
    private int code;

    /** 消息内容 */
    private String msg;

    // 当前是第几页
    private Integer pageNowNumber;

    // 总页数
    private Integer totalPageNum;

    public Integer getTotalPageNum() {
        return totalPageNum;
    }

    public void setTotalPageNum(Integer totalPageNum) {
        this.totalPageNum = totalPageNum;
    }

    /**
     * 表格数据对象
     */
    public TableDataInfo()
    {
    }

    public Integer getPageNowNumber() {
        return pageNowNumber;
    }

    public void setPageNowNumber(Integer pageNowNumber) {
        this.pageNowNumber = pageNowNumber;
    }

    /**
     * 分页
     * 
     * @param list 列表数据
     * @param total 总记录数
     */
    public TableDataInfo(List<?> list, int total)
    {
        this.rows = list;
        this.total = total;
    }

    public long getTotal()
    {
        return total;
    }

    public void setTotal(Integer total)
    {
        this.total = total;
    }

    public List<?> getRows()
    {
        return rows;
    }

    public void setRows(List<?> rows)
    {
        this.rows = rows;
    }

    public int getCode()
    {
        return code;
    }

    public void setCode(int code)
    {
        this.code = code;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }


    public static TableDataInfo getDataTable(List<?> list, Integer pageSize, Integer pageNowNumber, Integer totalPageNum)
    {
        TableDataInfo rspData = new TableDataInfo();
        rspData.setCode(200);
        rspData.setMsg("查询成功");
        rspData.setRows(list);
        rspData.setTotal(pageSize);
        rspData.setPageNowNumber(pageNowNumber);
        rspData.setTotalPageNum(totalPageNum);
        return rspData;
    }
}
