package ext.alphai.globalPart.vo;

/**
 * 名称审核展示数据
 */
public class AIExamineNameVo {

    private String oid;

    private String partNumber;

    private String partURL;

    private String chineseTerm;


    private String englishTerm;


    private String germanTerm;


    private String globalPart;

    private int maturity;
    private String lifeCycle;

    private AICnEnDnExamineVo examineVo;

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartURL() {
        return partURL;
    }

    public void setPartURL(String partURL) {
        this.partURL = partURL;
    }

    public String getChineseTerm() {
        return chineseTerm;
    }

    public void setChineseTerm(String chineseTerm) {
        this.chineseTerm = chineseTerm;
    }

    public String getEnglishTerm() {
        return englishTerm;
    }

    public void setEnglishTerm(String englishTerm) {
        this.englishTerm = englishTerm;
    }

    public String getGermanTerm() {
        return germanTerm;
    }

    public void setGermanTerm(String germanTerm) {
        this.germanTerm = germanTerm;
    }

    public String getGlobalPart() {
        return globalPart;
    }

    public void setGlobalPart(String globalPart) {
        this.globalPart = globalPart;
    }

    public int getMaturity() {
        return maturity;
    }

    public void setMaturity(int maturity) {
        this.maturity = maturity;
    }

    public String getLifeCycle() {
        return lifeCycle;
    }

    public void setLifeCycle(String lifeCycle) {
        this.lifeCycle = lifeCycle;
    }

    public AICnEnDnExamineVo getExamineVo() {
        return examineVo;
    }

    public void setExamineVo(AICnEnDnExamineVo examineVo) {
        this.examineVo = examineVo;
    }
}
