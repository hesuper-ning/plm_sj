package ext.alphai.globalPart.vo;

/**
 * 物料名称 三语审核情况对象
 */
public class AICnEnDnExamineVo {
    private boolean chineseApproved;
    private boolean englishApproved;
    private boolean germanApproved;

    public boolean isChineseApproved() {
        return chineseApproved;
    }

    public void setChineseApproved(boolean chineseApproved) {
        this.chineseApproved = chineseApproved;
    }

    public boolean isEnglishApproved() {
        return englishApproved;
    }

    public void setEnglishApproved(boolean englishApproved) {
        this.englishApproved = englishApproved;
    }

    public boolean isGermanApproved() {
        return germanApproved;
    }

    public void setGermanApproved(boolean germanApproved) {
        this.germanApproved = germanApproved;
    }

    public AICnEnDnExamineVo() {
    }

    public AICnEnDnExamineVo(boolean chineseApproved, boolean englishApproved, boolean germanApproved) {
        this.chineseApproved = chineseApproved;
        this.englishApproved = englishApproved;
        this.germanApproved = germanApproved;
    }
}
