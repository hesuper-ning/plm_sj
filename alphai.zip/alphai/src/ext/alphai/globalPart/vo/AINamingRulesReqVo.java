package ext.alphai.globalPart.vo;

import java.util.List;

/**
 * 创建和修改 命名规则
 */
public class AINamingRulesReqVo {

    /*
    分类名
     */
    private String className;

    /*
    规则集合
     */
    public List<String> rulesList;

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public List<String> getRulesList() {
        return rulesList;
    }

    public void setRulesList(List<String> rulesList) {
        this.rulesList = rulesList;
    }

    public AINamingRulesReqVo() {
    }

    public AINamingRulesReqVo(String className, List<String> rulesList) {
        this.className = className;
        this.rulesList = rulesList;
    }
}
