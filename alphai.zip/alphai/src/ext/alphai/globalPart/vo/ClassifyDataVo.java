package ext.alphai.globalPart.vo;

public class ClassifyDataVo {
    /*
    分类内部名
     */
    private String classifyName;

    /*
    显示内部名
     */
    private String classifyDisplayName;

    private Integer sortOrder;

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getClassifyName() {
        return classifyName;
    }

    public void setClassifyName(String classifyName) {
        this.classifyName = classifyName;
    }

    public String getClassifyDisplayName() {
        return classifyDisplayName;
    }

    public void setClassifyDisplayName(String classifyDisplayName) {
        this.classifyDisplayName = classifyDisplayName;
    }

    public ClassifyDataVo(String classifyName, String classifyDisplayName) {
        this.classifyName = classifyName;
        this.classifyDisplayName = classifyDisplayName;
    }

    public ClassifyDataVo() {
    }
}
