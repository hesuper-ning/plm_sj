package ext.alphai.globalPart.processor;
import com.ptc.windchill.enterprise.part.forms.CreatePartAndCADDocFormProcessor;
import ext.alphai.globalPart.servcie.GeneralService;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.util.PersistenceUtil;
import wt.fc.PersistenceHelper;
import wt.generic.GenericType;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AICreatePartProcessor extends CreatePartAndCADDocFormProcessor {

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("进入编辑部件processor");
        FormResult result = null;


        WTPart part = (!list.isEmpty())
                ? (list.get(0).getObject() instanceof WTPart ? (WTPart) list.get(0).getObject() : null)
                : null;

        if(part != null){
            //jc逻辑
//            GeneralService.hostLangRepeatabilityVerification(part);
            GeneralService.updateAndVerificationPart(part);

//            IBAUtil iba = new IBAUtil(part);
//            WTPartMaster partMaster = part.getMaster();
//            IBAUtil masterIBA = new IBAUtil(partMaster);
//            String hostLang = masterIBA.getIBAValue(PropertiesUtil.getValueByKey("part.master.host.lang"));
//            System.out.println("当前部件选择的主语言为："+hostLang);
//            // 主语言部件名
//            String hostLangName = "";
//            String cnName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.JCCNNAME"));
//            String enName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEEN"));
//            String geName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEDE"));
//            if(Constant.CREATE_LANG_CN.equals(hostLang)){
//                hostLangName = cnName;
//            } else if (Constant.CREATE_LANG_EN.equals(hostLang)) {
//                hostLangName = enName;
//            } else if (Constant.CREATE_LANG_DN.equals(hostLang)){
//                hostLangName = geName;
//            } else {
//                throw new WTException("未能匹配部件创作语言"+"\r\n"+"Failed to match component creation language"+"\r\n"+"Widget-Erstellungssprache kann nicht übereinstimmen");
//            }
//            if(!part.getName().equals(hostLangName)){
//                // 需要修改部件名称时要同步部件三语IBA
//                PartUtil.changePartName(part, hostLangName);
//            }

            try {
                setPartUnitAndGeneric(part);
            } catch (WTPropertyVetoException e) {
                throw new RuntimeException(e);
            }
        }

        //设置部件默认单位

        super.postProcess(nmCommandBean, list);
        return result;
    }


    public static void setPartUnitAndGeneric(WTPart part) throws WTPropertyVetoException, WTException {
        WTPartMaster master = part.getMaster();
        master = (WTPartMaster) PersistenceHelper.manager.refresh(master);
        String subTypeInternal = PersistenceUtil.getSubTypeInternal(part);
        if("com.aistoneglobal.AI_FGParts".equals(subTypeInternal) ){
            //设置可配置模块
            master.setGenericType(GenericType.DYNAMIC);
            //设置为成品
            master.setEndItem(true);
        }

        master.setDefaultUnit(defaultUnitMapping(part));
        PersistenceHelper.manager.save(master);

    }

    public static QuantityUnit defaultUnitMapping(WTPart part) {
        QuantityUnit result = QuantityUnit.toQuantityUnit("PCS");

        String unitMapping = PropertiesUtil.getValueByKey("part.type.defaultUnit");
        if (unitMapping == null || unitMapping.trim().isEmpty()) {
            return result;
        }

        Map<String, QuantityUnit> quantityUnitMap = new HashMap<>();
        String[] groups = unitMapping.split(";");
        for (String group : groups) {
            if (group == null || group.trim().isEmpty()) {
                continue;
            }
            String[] unitArr = group.split(",");
            if (unitArr.length >= 2) {
                quantityUnitMap.put(unitArr[0].trim(), QuantityUnit.toQuantityUnit(unitArr[1].trim()));
            }
        }

        String subTypeInternal = PersistenceUtil.getSubTypeInternal(part);
        if (subTypeInternal != null && quantityUnitMap.containsKey(subTypeInternal)) {
            result = quantityUnitMap.get(subTypeInternal);
        }

        return result;
    }

//    @Override
//    public FormResult postTransactionProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
//        System.out.println("进入创建部件processor");
//        WTPart part = (!list.isEmpty())
//                ? (list.get(0).getObject() instanceof WTPart ? (WTPart) list.get(0).getObject() : null)
//                : null;
//        if(part != null){
//            GeneralService.hostLangRepeatabilityVerification(part);
//        }
//        return super.postTransactionProcess(nmCommandBean, list);
//    }
}
