package ext.alphai.globalPart.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.servcie.AIPromotionGPService;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.util.IBAUtil;
import ext.util.PartUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.Identified;
import wt.fc.IdentityHelper;
import wt.fc.PersistenceHelper;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.part.WTPartMasterIdentity;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.*;
public class AIPromotionGPProcessor extends DefaultObjectFormProcessor {

//    public  String SUCCESS_ZH = PropertiesUtil.getValueByKey("ai.part.GD.SUCCESSMSGZH");
//    public  String ERR_ZH = PropertiesUtil.getValueByKey("ai.part.GD.ERRMSGZH");
//    public  String SUCCESS_EN = PropertiesUtil.getValueByKey("ai.part.GD.SUCCESSMSGEN");
//    public  String ERR_EN = PropertiesUtil.getValueByKey("ai.part.GD.ERRMSGEN");

    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        String SUCCESS_ZH = PropertiesUtil.getValueByKey("ai.part.GD.SUCCESSMSGZH");
        String ERR_ZH = PropertiesUtil.getValueByKey("ai.part.GD.ERRMSGZH");
        String SUCCESS_EN = PropertiesUtil.getValueByKey("ai.part.GD.SUCCESSMSGEN");
        String ERR_EN = PropertiesUtil.getValueByKey("ai.part.GD.ERRMSGEN");


        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();

        WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
        String success_msg = SUCCESS_ZH;
        String err_msg = ERR_ZH;
        try {
            if (content instanceof WTPart){




                System.out.println("升级为全球部件开始");
                WTPart part = (WTPart)content;
                IBAUtil ibaUtil = new IBAUtil(part);

                //校验必填属性
                isRequired(ibaUtil);

                //校验部件状态---关闭
                AIPromotionGPService.allowCondition(part);

                //修改部件名称，用英文名称修改
                String enName = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEEN"));
                System.out.println("修改部件名称为"+enName);
                part= changePartName(part, enName);
                //修改主语言
                IBAUtil partMasterIBAUtil = new IBAUtil(part.getMaster());
                System.out.println("修改主语言为："+Constant.CREATE_LANG_EN);
                partMasterIBAUtil.setIBAAttribute4AllType(part.getMaster(), PropertiesUtil.getValueByKey("part.master.host.lang"), Constant.CREATE_LANG_EN);

                //设置为管理员执行
                SessionHelper.manager.setAdministrator();
                String typeIdentifier = AIPromotionGPService.getTypeIdentifier(part);
                String ldPartKey = PropertiesUtil.getValueByKey("ai.part.ld.part");
                //LD-->全球

                if (typeIdentifier.contains(ldPartKey)) {
                    AIPromotionGPService.setIBALDJCState(part,ibaUtil,"LD");
                    success_msg = SUCCESS_EN;
                    err_msg =  ERR_EN;
                }else{ //JC-->全球部件
                    //设置LD State、JC State
                    AIPromotionGPService.setIBALDJCState(part,ibaUtil,"JC");
                }
                //移动文件夹
                AIPromotionGPService.setPartToFolder(part,ibaUtil);
            }
        }  catch (Exception e) {
            e.printStackTrace();
            FormResult result = new FormResult(FormProcessingStatus.FAILURE);
            result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), (String)null, (ArrayList)null, new String[]{err_msg + e.getMessage()}));
            return result;
        }finally {
            //修改回用户
            SessionHelper.manager.setPrincipal(currentUser.getName());
        }
        System.out.println("升级为全球部件结束，返回显示信息！");
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null, new String[] { success_msg}));
        return result;
    }



    /**
     * 修改部件名称
     *
     * @param part
     * @param newName
     */
    public static WTPart changePartName(WTPart part, String newName) {

        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();
            part = (WTPart) PersistenceHelper.manager.refresh(part);
            Identified identified = (Identified) part.getMaster();
            WTPartMasterIdentity partIdentity = (WTPartMasterIdentity) identified.getIdentificationObject();
            partIdentity.setName(newName);
            identified = IdentityHelper.service.changeIdentity(identified, partIdentity);
            part = (WTPart) PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (currentUser != null) {
                try {
                    SessionHelper.manager.setPrincipal(currentUser.getName());
                } catch (WTException e) {
                    e.printStackTrace();
                }
            }
        }
        return part;
    }

    public static void isRequired(IBAUtil ibaUtil) throws Exception {
        Locale locale = SessionHelper.getLocale();
//        boolean flag = false;
        //获取必填IBA属性内部值
        String[] requiredIBAs = PropertiesUtil.getValueByKey("ai.part.IBA.required").split(",");
        for (String requiredIBA : requiredIBAs) {
            //必填的属性value
            String requiredValue = ibaUtil.getIBAValue(requiredIBA);
            if (StringUtils.isBlank(requiredValue)) {
                String internalDisplayName = ibaUtil.getInternalDisplayName(requiredIBA);
                System.out.println("净重显示名称"+internalDisplayName);
                System.out.println("净重显示名称"+internalDisplayName);
//                flag = true;
                throw new WTException(getTrilingualErrMsg("'"+internalDisplayName+"' 为升级全球物料必填字段，必须为其指定有效信息", "To be designated as a global part (Elevate to Global Parts), valid data must be entered in the '"+internalDisplayName+"' field." , "To be designated as a global part (Elevate to Global Parts), valid data must be entered in the '"+internalDisplayName+"' field.", locale));
            }
        }
    }


    /**
     * 获取三语错误信息
     * @param cn
     * @param en
     * @param de
     * @return
     */
    public static String getTrilingualErrMsg(String cn, String en ,String de , Locale locale){
        String result = "";
        if(Locale.CHINA.equals(locale) || Locale.CHINESE.equals(locale)){
            result = cn;
        } else if (Locale.UK.equals(locale)) {
            result = en;
        } else if(Locale.GERMAN.equals(locale)){
            result = de;
        }else {
            result = cn+en;
        }
        return result;
    }




}
