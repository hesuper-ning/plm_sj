package ext.alphai.globalPart.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.alphai.sap.util.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import wt.associativity.EquivalenceLink;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTReference;
import wt.inf.container.WTContainer;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.IterationInfo;
import wt.vc.VersionInfo;
import wt.vc.Versioned;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.Variation2;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;
import wt.vc.wip.WorkInProgressHelper;

import java.util.*;

/*
制造视图点击创建或更新上下游链接 并将设计视图指定IBA属性拷贝到当前制造视图
 */
public class AIManufacturingCreateEquivalenceLink extends DefaultObjectFormProcessor {
    public static final String DESIGN = "Design";
    public static final String MANUFACTURING = "Manufacturing";
    public static final String M_3101 = "3101";
    public static final String M_3188 = "3188";
    static List<String> allowFactory = Arrays.asList(new String[]{MANUFACTURING, M_3101, M_3188});
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        if(content instanceof WTPart){
            WTPart part = (WTPart) content;
//            String partNumber = part.getNumber();
            try {
                String view = part.getView().getName();
                if(!allowFactory.contains(view)){
                    throw new WTException("当前部件并非制造、3101、3188 视图");
                }
                // 判断当前部件是否为最新版本
                if (!isLastPart(part)) {
                    throw new WTException("前往最新版本的部件");
                }
                // 要求部件是检入状态
                if (WorkInProgressHelper.isCheckedOut(part)) {
                    throw new WTException("请先检入部件");
                }
                // 根据当前制造视图反向获取所有上下游链接  检查链接的上游相同master的设计视图部件是否是最新版本 如果不是 更新链接， 如果没有链接创建与最新设计视图的链接
                createDMPartLinkAndCopyIBAProcess(part);
            } catch (Exception e){
                e.printStackTrace();
                throw new WTException(e.getMessage());
            }
        }
        formResult= new FormResult(FormProcessingStatus.SUCCESS);
//        formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, locale, null,null, new String[]{GeneralService.getTrilingualErrMsg("修订成功","Revised successfully","Erfolgreich überarbeitet",locale)}));
        formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null,null, new String[]{"更新属性成功"}));
        return formResult;
    }


    /**
     * 根据当前制造视图反向获取所有上下游链接  检查链接的上游相同master的设计视图部件是否是最新版本 如果不是 更新链接， 如果没有链接创建与最新设计视图的链接
     * @param mPart
     */
    private static void createDMPartLinkAndCopyIBAProcess(WTPart mPart) throws Exception {
        WTPart designPart = getLatestWTPart(mPart.getNumber(), null, null, DESIGN, null);
//        mPart = (WTPart)WorkInProgressHelper.service.checkout(mPart, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
//        // 根据下游部件获取所有链接
        List<EquivalenceLink> linksByMPart = getLinksByMPart(mPart);
        for (EquivalenceLink link : linksByMPart) {
            PersistenceHelper.manager.delete(link);
        }
        boolean whetherNeedCreateLink = true;
        for (EquivalenceLink link : linksByMPart) {
            WTReference roleAObjectRef = link.getRoleAObjectRef();
            if(roleAObjectRef instanceof WTPart){
                // 上游部件
                WTPart upPart = (WTPart) roleAObjectRef;
                if(upPart.equals(designPart)){
                    whetherNeedCreateLink = false;
                }
            }
        }
        if(whetherNeedCreateLink){
            createEquivalenceLink(designPart, mPart);
        }

//        mPart = (WTPart) WorkInProgressHelper.service.checkin(mPart, "create EquivalenceLink checkin");
        Map<String, String> map = getDesignWaitCopyIBA(designPart);
        copyDesignIBAToManufacturing(map, mPart);

    }


    private static void copyDesignIBAToManufacturing(Map<String,String> map, WTPart mPart) throws Exception {
        Set<Map.Entry<String, String>> entries = map.entrySet();
        IBAUtil iba = new IBAUtil();
        for (Map.Entry<String, String> entry : entries) {
            String key = entry.getKey();
            String orDefault = map.getOrDefault(key, "");
            if(!StringUtils.isBlank(orDefault)){
                iba.setIBAAttribute4AllType(mPart, key, orDefault);
            }
        }
    }


    /**
     * 收集设计视图所有待拷贝部件
     * @param designPart
     * @return
     */
    public static Map<String, String> getDesignWaitCopyIBA(WTPart designPart){
        IBAUtil designPartIBA = new IBAUtil(designPart);
        // 收集设计视图部件所有带拷贝IBA
        String designPartAttrStr = PropertiesUtil.getValueByKey("design.copy.manufacturing.iba");
        String[] ibaNames = designPartAttrStr.split(",");
        Map<String, String> map = new HashMap<String, String>();
        for (String ibaName : ibaNames) {
            String ibaValue = designPartIBA.getIBAValue(ibaName);
            System.out.println("读取到设计视图检入部件的IBA KEY："+ibaName+" IBA VALUE:"+ibaValue);
            map.put(ibaName, ibaValue);
        }
        return map;
    }

    /**
     * 创建下游链接关系
     * @param dPart
     * @param mPart
     */
    private static EquivalenceLink createEquivalenceLink(WTPart dPart, WTPart mPart) throws WTException, WTPropertyVetoException {
        EquivalenceLink link = EquivalenceLink.newEquivalenceLink(dPart,mPart);
        link.setIsConsumable(true);
        link.setUpstreamContextRef(dPart.getView());
        link.setDownstreamContextRef(mPart.getView());
        // save 保存  modify修改
        try {
            link = (EquivalenceLink) PersistenceHelper.manager.save(link);
        } catch (WTException e) {
            System.out.println("已存在相同链接");
            e.printStackTrace();
        }
        return link;
    }

    /**
     * 判断是否为最新版本部件
     * @param part
     * @return
     */
    private static boolean isLastPart(WTPart part){
        boolean result = false;
        String number = part.getNumber();
        String view = part.getView().getName();
        // 产线
        String v2 = null;
        Variation2 variation2 = part.getVariation2();
        if(variation2 != null){
            v2 = variation2.getValue();
        }
//        System.out.println("当前产线为："+v2);
        WTPart latestWTPart = getLatestWTPart(number, null, null, view, v2);
//        System.out.println("查询到的最新IDA2A2为："+latestWTPart.getPersistInfo().getObjectIdentifier().getId());
        if(part.equals(latestWTPart)){
            result = true;
        }
        return result;
    }



    private static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName, String line){
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        try {
            if (StringUtils.isNotBlank(partNumber)) {
                partNumber = partNumber.trim();

                qs = new QuerySpec(WTPart.class);
                int[] index = new int[] { 0 };
                qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class,"containerReference.key.classname", SearchCondition.NOT_EQUAL, "wt.projmgmt.admin.Project2", false), index);
                if(!StringUtils.isBlank(line)) {
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, WTPart.VARIATION2, SearchCondition.EQUAL, line, false), index);
                }
                if (StringUtils.isNotBlank(version)) {
                    version = version.trim();
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

                    if (StringUtils.isNotBlank(iteration)) {
                        iteration = iteration.trim();
                        qs.appendAnd();
                        qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
                    } else {
                        qs.appendAnd();
                        qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
                    }
                }

                if (StringUtils.isNotBlank(viewName)) {
                    viewName = viewName.trim();
                    View viewObj = ViewHelper.service.getView(viewName);
                    if (viewObj == null)
                        return null;
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
                }

                configSpec = new LatestConfigSpec();
                configSpec.appendSearchCriteria(qs);
                qr = PersistenceHelper.manager.find((StatementSpec) qs);
                qr = configSpec.process(qr);
                if (qr.hasMoreElements()) {
                    WTPart element = (WTPart) qr.nextElement();
                    WTContainer container = element.getContainer();
                    if(!(container instanceof Project2)){
                        part = element;
                    }
                }
            }
        }catch (WTException e){
            e.printStackTrace();
        }
        return part;
    }

    /**
     * 根据下游部件获取所有链接
     * @param mPart
     * @return
     */
    private static List<EquivalenceLink> getLinksByMPart(WTPart mPart) throws WTException {
        List<EquivalenceLink> links = new ArrayList<>();
        QueryResult qr = wt.fc.PersistenceHelper.manager.navigate(mPart,wt.associativity.EquivalenceLink.UPSTREAM_ROLE, wt.associativity.EquivalenceLink.class, false);
        while (qr.hasMoreElements()){
            Object o = qr.nextElement();
            if(o instanceof EquivalenceLink){
                links.add((EquivalenceLink)o);
            }
        }
        return links;
    }


}
