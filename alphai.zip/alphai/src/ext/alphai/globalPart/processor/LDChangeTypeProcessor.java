package ext.alphai.globalPart.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.servcie.GeneralService;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.part.WTPart;
import wt.series.MultilevelSeries;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;
import wt.vc.wip.WorkInProgressHelper;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Locale;

/**
 * LD历史部件 修改子类型
 */
public class LDChangeTypeProcessor extends DefaultObjectFormProcessor {

    final String JCClassify = "com.jiecang.MPart";

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;
        Locale locale = GeneralService.getUserHostLanguage();
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        if(content instanceof WTPart){
            WTPart part = (WTPart) content;
//            if(WorkInProgressHelper.isCheckedOut(part)){
//                formResult = new FormResult(FormProcessingStatus.FAILURE);
//                formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, locale,null,null,new String[]{GeneralService.getTrilingualErrMsg("请现检入部件","Please check in the part","Bitte überprüfen Sie den Teil",locale)}));
//                return formResult;
//            }
            // 修改部件版本
            try {
                createSoftTypePart(part, JCClassify);
            } catch (Exception e){
                e.printStackTrace();
                throw new WTException(e.getMessage());
            }
        }
        formResult= new FormResult(FormProcessingStatus.SUCCESS);
        formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, locale, null,null, new String[]{GeneralService.getTrilingualErrMsg("修订成功","Revised successfully","Erfolgreich überarbeitet",locale)}));
        return formResult;
    }



    /**
     * 设置部件子类型
     * @param part
     * @param softName 内部值
     * @throws WTException
     * @throws RemoteException
     * @throws WTPropertyVetoException
     */
    public static void createSoftTypePart(WTPart part, String softName) throws WTException, RemoteException, WTPropertyVetoException {
        System.out.println("修改部件子类型");
        TypeIdentifier myCustomType = TypeHelper.getTypeIdentifier(softName);
        WCTypeIdentifier myCustomWCType = (WCTypeIdentifier) myCustomType;
        TypeDefinitionReference myCustomTDR = TypedUtilityServiceHelper.service.getTypeDefinitionReference(myCustomWCType.getTypename());
        part.setTypeDefinitionReference(myCustomTDR);
        PersistenceHelper.manager.save(part);
    }



}
