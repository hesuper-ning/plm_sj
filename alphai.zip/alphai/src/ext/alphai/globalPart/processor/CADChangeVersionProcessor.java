package ext.alphai.globalPart.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.globalPart.servcie.GeneralService;
import ext.techsoft.logicdata.helper.IBAHelper;
import org.apache.commons.lang3.StringUtils;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.MethodContext;
import wt.part.WTPart;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * SQL修改CAD 文档版本
 */
public class CADChangeVersionProcessor extends DefaultObjectFormProcessor {
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;
        Locale locale = GeneralService.getUserHostLanguage();
//        EPMDocument epm = (!list.isEmpty())
//                ? (list.get(0).getObject() instanceof EPMDocument ? (EPMDocument) list.get(0).getObject() : null)
//                : null;
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        String version = nmCommandBean.getTextParameter("revisedVersion");
        Object content = primaryOid2.getRef();
        if(content != null){
            if(content instanceof EPMDocument){
                System.out.println("JY SQL 修改CAD版本");
                EPMDocument epm = (EPMDocument)content;
                WTPart partByEPM = getPartByEPM(epm);
                String epmNumber = epm.getNumber();
                updateEPMDoc(epmNumber, version);
                if(partByEPM != null){
                    System.out.println("修改部件版本");
                    String partNumber = partByEPM.getNumber();
                    updatePart(partNumber, version);
                }
            }
        }
        formResult= new FormResult(FormProcessingStatus.SUCCESS);
        formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, locale, null,null, new String[]{GeneralService.getTrilingualErrMsg("修订成功","Revised successfully","Erfolgreich überarbeitet",locale)}));
        return formResult;
    }





    public static void updateEPMDoc(String epmNumber, String version){
        System.out.println("-----当前是在修改CAD版本-------");
        String sql1 = "UPDATE CONTROLBRANCH set VERSIONID = ? where idA3B5  = (select IDA2A2 from EPMDOCUMENTMASTER where DOCUMENTNUMBER = ?)";
        String sql2 = "UPDATE EPMDOCUMENT set VERSIONIDA2VERSIONINFO = ? where IDA3MASTERREFERENCE  = (select IDA2A2 from EPMDOCUMENTMASTER where DOCUMENTNUMBER = ?)";

        excuteUpdate(sql1, version, epmNumber);
        excuteUpdate(sql2, version, epmNumber);

    }


    /**
     * 执行更新的SQL语句并返回被更新的条数 SQL示例：UPDATE WTPARTMASTER SET WTPARTNUMBER = ? WHERE
     * IDA2A2 = ?
     *
     * @param sql    SQL语句
     * @param params 参数集
     * @return int 数据库表被影响的行数
     */
    public static int excuteUpdate(String sql, String... params) {
        try {
            WTConnection connection = getWTConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                statement.setString(i + 1, params[i]);
            }

            // 输出当前执行更新操作的SQL语句
            String fullSql = sql;
            for (String param : params) {
                param = param.length() > 250 ? "此属性太长，不显示内容" : param;
                fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
            }
            System.out.println("--------当前执行更新操作的SQL语句为--------");
            System.out.println(fullSql);

            return statement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 连接Windchill数据库来运行自定义sql
     *
     * @return WTConnection 数据库连接
     * @throws Exception
     */
    public static WTConnection getWTConnection() {
        WTConnection wtconnection = null;
        try {
            MethodContext methodcontext = MethodContext.getContext();
            wtconnection = (WTConnection) methodcontext.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtconnection;
    }


    public static WTPart getPartByEPM(EPMDocument drw) throws WTException {

        WTPart part = null;

        if (drw != null) {
            System.out.println("当前的CAD是：" + drw.getCADName());
            QueryResult dl_qr = PersistenceHelper.manager.navigate(drw, EPMBuildRule.BUILD_TARGET_ROLE, EPMBuildRule.class, true);
            System.out.println("查询的长度是：" + dl_qr.size());
            while (dl_qr.hasMoreElements()) {
                Object obj = dl_qr.nextElement();
                if (obj instanceof WTPart) {
                    part = (WTPart) obj;
                    System.out.println("关联部件的编号是：" + part.getNumber());
                }
            }
        } else {
            System.out.println("没有part");
        }

        return part;
    }



    public static void updatePart(String partNumber, String version) throws WTException {
        String sql1 = "UPDATE CONTROLBRANCH set VERSIONID = ? where idA3B5  = (select IDA2A2 from WTPARTMASTER where WTPARTNUMBER = ?) and VIEWID = (select IDA2A2 from WTVIEW where name = 'Design')";
        String sql2 = "UPDATE WTPART set VERSIONIDA2VERSIONINFO = ? where IDA3MASTERREFERENCE  = (select IDA2A2 from WTPARTMASTER where WTPARTNUMBER = ?) and IDA3VIEW = (select IDA2A2 from WTVIEW where name = 'Design')";
        excuteUpdate(sql1, version, partNumber);
        excuteUpdate(sql2, version, partNumber);
    }

}
