package ext.alphai.globalPart.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.alphai.globalPart.util.PropertiesUtil;
import ext.alphai.sap.util.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import wt.associativity.EquivalenceLink;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTReference;
import wt.inf.container.WTContainer;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.*;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.*;
import wt.vc.wip.WorkInProgressHelper;

import java.util.*;

/*
设计视图点击创建或更新上下游链接 并将设计视图指定IBA属性拷贝到所有制造视图
 */
public class AIDesignCreateEquivalenceLink extends DefaultObjectFormProcessor {
    public static final String DESIGN = "Design";
    public static final String MANUFACTURING = "Manufacturing";
    public static final String M_3101 = "3101";
    public static final String M_3188 = "3188";
    static List<String> allowFactory = Arrays.asList(new String[]{MANUFACTURING, M_3101, M_3188});
    public static final String M_001 = "001";
    public static final String M_002 = "002";
    public static final String M_003 = "003";
    public static final String M_004 = "004";
    static List<String> productionLine = Arrays.asList(new String[]{M_001, M_002, M_003, M_004});
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        if(content instanceof WTPart){
            WTPart part = (WTPart) content;
//            String partNumber = part.getNumber();
            try {
                String view = part.getView().getName();
                if(!DESIGN.equals(view)){
                    throw new WTException("当前部件并非设计视图");
                }
                // 判断当前部件是否为最新版本
                if (!isLastPart(part)) {
                    throw new WTException("前往最新版本的部件");
                }
                // 要求部件是检入状态
                if (WorkInProgressHelper.isCheckedOut(part)) {
                    throw new WTException("请先检入部件");
                }

                // 获取设计视图所有上下游链接 判断链接指向的部件是否为最新版本 如果不是更新当前链接至最新版本
                createDMPartLinkAndCopyIBAProcess(part);
            } catch (Exception e){
                e.printStackTrace();
                throw new WTException(e.getMessage());
            }
        }
        formResult= new FormResult(FormProcessingStatus.SUCCESS);
//        formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, locale, null,null, new String[]{GeneralService.getTrilingualErrMsg("修订成功","Revised successfully","Erfolgreich überarbeitet",locale)}));
        formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null,null, new String[]{"更新生产部件属性成功"}));
        return formResult;
    }


    /**
     * 获取设计视图所有上下游链接 判断链接指向的部件是否为最新版本 如果不是更新当前链接至最新版本
     * 同时拷贝设计视图部件IBA属性
     * @param designPart
     */
    private static void createDMPartLinkAndCopyIBAProcess(WTPart designPart) throws Exception {
        String designPartNumber = designPart.getNumber();
        // 根据编号获取所有生产视图部件
        List<WTPart> mPartLists = getWTPartListByNumber(designPartNumber);

        System.out.println("获取的待关联部件对象："+Arrays.toString(new List[]{mPartLists}));
        try {
            // key 由生产部件的 视图name+ ,+ 产线组成  因为都是生产视图所以不存在key为空的情况
//            Map<String, WTPart> factoryPartMap = new HashMap<>();
//            for (WTPart mPartList : mPartLists) {
//                String key = "";
//                String view = mPartList.getView().getName();
//                Variation2 variation2 = mPartList.getVariation2();
//                if(variation2!=null){
//                    String variation2Value = variation2.getValue();
//                    key = view+","+variation2Value;
//                    factoryPartMap.put(key, mPartList);
//                }else {
//                    key = view;
//                    factoryPartMap.put(key, mPartList);
//                }
//            }

            List<EquivalenceLink> equivalenceLinks = getLinkByDesignPart(designPart);
            // 删除所有旧链接
            for (EquivalenceLink equivalenceLink : equivalenceLinks) {
                PersistenceHelper.manager.delete(equivalenceLink);
            }

            for (WTPart mPartList : mPartLists) {
                createEquivalenceLink(designPart, mPartList);
            }
//            for (EquivalenceLink equivalenceLink : equivalenceLinks) {
//                WTReference roleBObjectRef = equivalenceLink.getRoleBObjectRef();
//                if(roleBObjectRef instanceof WTPart){
//                    // 下游部件
//                    WTPart downPart = (WTPart) roleBObjectRef;
//                    String key = "";
//                    String downPartView = downPart.getView().getName();
//                    Variation2 downPartVariation2 = downPart.getVariation2();
//                    if(downPartVariation2 != null){
//                        String downPartVariation2Value = downPartVariation2.getValue();
//                        key = downPartView+","+downPartVariation2Value;
//                    } else {
//                        key = downPartView;
//                    }
//                    // 根据视图 产线获取的最新版本生产视图部件
//                    WTPart lastPart = factoryPartMap.get(key);
//                    System.out.println("最新版本生产视图部件lastPart："+lastPart);
//                    System.out.println("下游部件downPart："+downPart);
//                    System.out.println("是否equals:"+downPart.equals(lastPart));
//                    // 最新版本生产部件与下游连列部件不相同
//                    if(!downPart.equals(lastPart)){
//                        // 删除并创建一个新的最新版本的
//                        PersistenceHelper.manager.delete(equivalenceLink);
//                        createEquivalenceLink(designPart, lastPart);
//                        // 移除 factoryPartMap 中 key 和lastPart对应的那个对象
//                        factoryPartMap.remove(key);
//                    }
//                }
//            }
//            System.out.println("Map:里的结构为："+factoryPartMap);
            // 现在factoryPartMap 里就是剩下的没有链接的mPartLists 里的对象
            // 循环factoryPartMap   调用createEquivalenceLink(designPart, 传入factoryPartMap value里的 WTPart对象)
//            for (WTPart unlinkedPart : factoryPartMap.values()) {
//                createEquivalenceLink(designPart, unlinkedPart);
//            }
        } catch (Exception e){
            e.printStackTrace();
        }


        Map<String, String> map = getDesignWaitCopyIBA(designPart);
        // 再执行一次查询所有最新生产部件
//        List<WTPart> newNPartLists = getWTPartListByNumber(designPartNumber);
        // 设置设计视图的IBA属性给所有生产视图
        copyDesignIBAToManufacturing(map,mPartLists);
    }

    /**
     * 创建下游链接关系
     * @param dPart
     * @param mPart
     */
    private static EquivalenceLink createEquivalenceLink(WTPart dPart, WTPart mPart) throws WTPropertyVetoException, WTException {
        EquivalenceLink link = EquivalenceLink.newEquivalenceLink(dPart,mPart);
        link.setIsConsumable(true);
        link.setUpstreamContextRef(dPart.getView());
        link.setDownstreamContextRef(mPart.getView());
        // save 保存  modify修改
        try {
            link = (EquivalenceLink) PersistenceHelper.manager.save(link);
        } catch (WTException e) {
            System.out.println("已存在相同链接");
            e.printStackTrace();
        }
        return link;
    }

    /**
     * 判断是否为最新版本部件
     * @param part
     * @return
     */
    private static boolean isLastPart(WTPart part){
        boolean result = false;
        String number = part.getNumber();
        String view = part.getView().getName();
        // 产线
        String v2 = null;
        Variation2 variation2 = part.getVariation2();
        if(variation2 != null){
            v2 = variation2.getStringValue();
        }
        WTPart latestWTPart = getLatestWTPart(number, null, null, view, v2);
        if(part.equals(latestWTPart)){
            result = true;
        }
        return result;
    }



    private static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName, String line){
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        try {
            if (org.apache.commons.lang3.StringUtils.isNotBlank(partNumber)) {
                partNumber = partNumber.trim();

                qs = new QuerySpec(WTPart.class);
                int[] index = new int[] { 0 };
                qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class,"containerReference.key.classname", SearchCondition.NOT_EQUAL, "wt.projmgmt.admin.Project2", false), index);

                if(!StringUtils.isBlank(line)) {
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, WTPart.VARIATION2, SearchCondition.EQUAL, line, false), index);
                }
                if (org.apache.commons.lang3.StringUtils.isNotBlank(version)) {
                    version = version.trim();
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

                    if (org.apache.commons.lang3.StringUtils.isNotBlank(iteration)) {
                        iteration = iteration.trim();
                        qs.appendAnd();
                        qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
                    } else {
                        qs.appendAnd();
                        qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
                    }
                }

                if (org.apache.commons.lang3.StringUtils.isNotBlank(viewName)) {
                    viewName = viewName.trim();
                    View viewObj = ViewHelper.service.getView(viewName);
                    if (viewObj == null)
                        return null;
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
                }

                configSpec = new LatestConfigSpec();
                configSpec.appendSearchCriteria(qs);
                qr = PersistenceHelper.manager.find((StatementSpec) qs);
                qr = configSpec.process(qr);
                if (qr.hasMoreElements()) {
                    part = (WTPart) qr.nextElement();
                }
            }
        }catch (WTException e){
            e.printStackTrace();
        }
        return part;
    }

    /**
     * 拷贝动作
     *
     * @param mParts
     */
    private static void copyDesignIBAToManufacturing(Map<String,String> map,  List<WTPart> mParts) throws Exception {
        Set<Map.Entry<String, String>> entries = map.entrySet();
        IBAUtil iba = new IBAUtil();
        for (WTPart part : mParts) {
//            if(WorkInProgressHelper.isCheckedOut(part)){
//                part = (WTPart)WorkInProgressHelper.service.checkin(part, "create EquivalenceLink checkin");
//            }
            for (Map.Entry<String, String> entry : entries) {
                String key = entry.getKey();
                String orDefault = map.getOrDefault(key, "");
                if(!StringUtils.isBlank(orDefault)){
                    iba.setIBAAttribute4AllType(part, key, orDefault);
                }
            }

        }
    }




    /**
     * 根据编号查询设计视图List
     *
     * @param number 部件编号
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static List<WTPart> getWTPartListByNumber(String number) {
        List<WTPart> result = new ArrayList<WTPart>();
        QueryResult qr = null;
        try {
            for (String factory : allowFactory) {
                if (MANUFACTURING.equals(factory)){
                    for (String line : productionLine) {
                        WTPart mWTPart = getLatestWTPart(number, null, null, factory, line);
                        if(mWTPart != null){
                            result.add(mWTPart);
                        }
                    }
                } else {
                    WTPart mWTPart = getLatestWTPart(number, null, null, factory, null);
                    if(mWTPart != null){
                        result.add(mWTPart);
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    /**
     * 收集设计视图所有待拷贝部件
     * @param designPart
     * @return
     */
    public static Map<String, String> getDesignWaitCopyIBA(WTPart designPart){
        IBAUtil designPartIBA = new IBAUtil(designPart);
        // 收集设计视图部件所有带拷贝IBA
        String designPartAttrStr = PropertiesUtil.getValueByKey("design.copy.manufacturing.iba");
        String[] ibaNames = designPartAttrStr.split(",");
        Map<String, String> map = new HashMap<String, String>();
        for (String ibaName : ibaNames) {
            String ibaValue = designPartIBA.getIBAValue(ibaName);
            System.out.println("读取到设计视图检入部件的IBA KEY："+ibaName+" IBA VALUE:"+ibaValue);
            map.put(ibaName, ibaValue);
        }
        return map;
    }


    /**
     * 从上游部件获取所有链接
     * @param designPart
     * @return
     */
    private static List<EquivalenceLink> getLinkByDesignPart(WTPart designPart) throws WTException {
        List<EquivalenceLink> links = new ArrayList<>();
        QueryResult qr = wt.fc.PersistenceHelper.manager.navigate(designPart,wt.associativity.EquivalenceLink.DOWNSTREAM_ROLE, wt.associativity.EquivalenceLink.class, false);
        while (qr.hasMoreElements()){
            Object o = qr.nextElement();
            if(o instanceof EquivalenceLink){
                links.add((EquivalenceLink)o);
            }
        }
        return links;
    }

}
