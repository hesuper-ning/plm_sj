package ext.alphai.globalPart.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.servcie.GeneralService;
import ext.util.PersistenceUtil;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentType;
import wt.epm.build.EPMBuildHistory;
import wt.epm.build.EPMBuildRule;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.series.MultilevelSeries;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.WorkInProgressHelper;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * LD历史部件 修改数字版本序列为字母
 */
public class LDChangeVersionProcessor extends DefaultObjectFormProcessor {
    // LD版本序列
    public static final String HDS = "wt.series.HarvardSeries.LogicDataCustom";

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;
        Locale locale = GeneralService.getUserHostLanguage();
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        String version = nmCommandBean.getTextParameter("revisedVersion");

        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();
        String[] epmOids = new String[]{};
        String[] revisedEpmVersions = new String[]{};
        for (String key: parameterMap.keySet()) {
            Object value = parameterMap.get(key);
//            String[] values = (String[]) value;
//            for (String a : values) {
//                System.out.println("key=" + key + "value=" + a);
//            }
            if("epmOR".equals(key)){
                epmOids = (String[]) value;
            }
            if("revisedEpmVersion".equals(key)){
                revisedEpmVersions = (String[]) value;
            }
        }

        Object content = primaryOid2.getRef();
        if(content instanceof WTPart){
            WTPart part = (WTPart) content;
            if(WorkInProgressHelper.isCheckedOut(part)){
                formResult = new FormResult(FormProcessingStatus.FAILURE);
                formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, locale,null,null,new String[]{GeneralService.getTrilingualErrMsg("请现检入部件","Please check in the part","Bitte überprüfen Sie den Teil",locale)}));
                return formResult;
            }
            // 修改部件版本
            try {
                Versioned versioned = changeVersion(part, version);
                WTPart revisedPart = (WTPart)versioned;
                // 修订关联的CAD文档版本
                for (int i = 0; i < epmOids.length; i++) {
                    String epmOid = epmOids[i];
                    String revisedEpmVersion = revisedEpmVersions[i];
                    EPMDocument oldEpm = (EPMDocument) PersistenceUtil.oid2Object(epmOid);
                    Versioned epmVersioned = changeVersion(oldEpm, revisedEpmVersion);
                    EPMDocument epmDocumentRevised = (EPMDocument) epmVersioned;
                    if(!EPMDocumentType.toEPMDocumentType("CADDRAWING").equals(epmDocumentRevised.getDocType())){
                        QueryResult qr = PersistenceHelper.manager.find(EPMBuildRule.class, revisedPart, EPMBuildRule.BUILD_TARGET_ROLE, oldEpm);
                        while (qr.hasMoreElements()) {
                            Object obj = qr.nextElement();
                            if (obj instanceof EPMBuildRule) {
                                EPMBuildRule rule = (EPMBuildRule) obj;
                                if (rule.getBuildType() == 7) {
                                    PersistenceServerHelper.manager.remove(rule);
                                    System.out.println(revisedPart.getNumber() + "所有者链接删除");
                                }
                            }
                        }
                        Long UUID = 0L;
                        EPMBuildRule newEPMBuildRule = EPMBuildRule.newEPMBuildRule(epmDocumentRevised, revisedPart, EPMBuildRule.ALL_BUILD_ROLES);
                        PersistenceServerHelper.manager.insert(newEPMBuildRule);
                        PersistenceHelper.manager.refresh(newEPMBuildRule);
                        UUID = newEPMBuildRule.getUniqueID();
                        EPMBuildHistory epmbuildhistory = EPMBuildHistory.newEPMBuildHistory(epmDocumentRevised, revisedPart, UUID);
                        epmbuildhistory.setStatus(0);
                        PersistenceServerHelper.manager.insert(epmbuildhistory);
                        PersistenceHelper.manager.refresh(epmbuildhistory);
                        System.out.println(epmDocumentRevised.getCADName() + " 开始所有者关联 " + revisedPart.getNumber());
                    }
                }
            } catch (Exception e){
                e.printStackTrace();
                throw new WTException(e.getMessage());
            }
        }
//        else if (content instanceof WTDocument) {
//            WTDocument document = (WTDocument) content;
//            // 文档
//            try {
//                changeVersion(document, version);
//            } catch (Exception e){
//                e.printStackTrace();
//                throw new WTException(e.getMessage());
//            }
//        } else if (content instanceof EPMDocument){
//            EPMDocument epm = (EPMDocument) content;
//            // epm文档
//            try {
//                changeVersion(epm, version);
//            } catch (Exception e){
//                e.printStackTrace();
//                throw new WTException(e.getMessage());
//            }
//        }
        formResult= new FormResult(FormProcessingStatus.SUCCESS);
        formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, locale, null,null, new String[]{GeneralService.getTrilingualErrMsg("修订成功","Revised successfully","Erfolgreich überarbeitet",locale)}));
        return formResult;
    }


    /**
     * 修改版本
     * @param persistable
     * @param version
     */
    public static Versioned changeVersion(Versioned persistable, String version) throws Exception{
        MultilevelSeries multilevelseries = MultilevelSeries.newMultilevelSeries(HDS, version);
        VersionIdentifier ver = VersionIdentifier.newVersionIdentifier(multilevelseries);
        IterationIdentifier iid = IterationIdentifier.newIterationIdentifier(Constant.ONE_Str);
        persistable = (Versioned) VersionControlHelper.service.newVersion(persistable);
        persistable.getMaster().setSeries(HDS);
        VersionControlHelper.setVersionIdentifier(persistable, ver);
        persistable = (Versioned) PersistenceHelper.manager.save(persistable);
        return persistable;
    }





    /**
     * 获取指定版本
     */
    public static EPMDocument getEPMByVersion(EPMDocument epm, String bigVersion, String smallVersion) throws WTException {

        System.out.println("查询的版本 " + bigVersion + "." + smallVersion);
        EPMDocument currentPart = null;
        QueryResult qr = VersionControlHelper.service.allVersionsOf(epm);
        while (qr != null && qr.hasMoreElements()) {
            EPMDocument epmLast = (EPMDocument) qr.nextElement();
            if (epmLast.getVersionIdentifier().getValue().equals(bigVersion) && epmLast.getIterationIdentifier().getValue().equals(smallVersion))
                currentPart = epmLast;
        }
        return currentPart;
    }

    /**
     * 获取指定版本
     */
    public static WTPart getPartByVersion(WTPart part, String bigVersion, String smallVersion) throws WTException {

        System.out.println("查询的版本 " + bigVersion + "." + smallVersion);
        WTPart currentPart = null;
        QueryResult qr = VersionControlHelper.service.allVersionsOf(part);
        while (qr != null && qr.hasMoreElements()) {
            WTPart partLast = (WTPart) qr.nextElement();
            if (partLast.getVersionIdentifier().getValue().equals(bigVersion) && partLast.getIterationIdentifier().getValue().equals(smallVersion))
                currentPart = partLast;
        }
        return currentPart;
    }


    public static Object getLatestPersistableByNumber(String number, Class c) throws WTException {
        Object persistable = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(c);
            SearchCondition scnumber = new SearchCondition(c, WTPart.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(c, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                persistable = (Object) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return persistable;
    }

}
