package ext.alphai.globalPart.processor;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.globalPart.Constant;
import ext.alphai.globalPart.servcie.*;
import ext.alphai.globalPart.util.PropertiesUtil;
import ext.techsoft.logicdata.form.LogicDataEditPartFormProcessor;
import ext.util.IBAUtil;
import ext.util.PartUtil;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;

import java.sql.SQLException;
import java.util.List;

/**
 * 全球物料重写编辑部件
 */
public class AIEditPartProcessor extends LogicDataEditPartFormProcessor
//public class AIEditPartProcessor extends DefaultObjectFormProcessor
{

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult result = null;
        System.out.println("进入编辑部件processor");
        WTPart part = (!list.isEmpty())
                ? (list.get(0).getObject() instanceof WTPart ? (WTPart) list.get(0).getObject() : null)
                : null;
        if(part != null){
            GeneralService.hostLangRepeatabilityVerification(part);
//            IBAUtil iba = new IBAUtil(part);
//            WTPartMaster partMaster = part.getMaster();
//            IBAUtil masterIBA = new IBAUtil(partMaster);
//            String hostLang = masterIBA.getIBAValue(PropertiesUtil.getValueByKey("part.master.host.lang"));
//            System.out.println("当前部件选择的主语言为："+hostLang);
//            // 主语言部件名
//            String hostLangName = "";
//            String cnName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.JCCNNAME"));
//            String enName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEEN"));
//            String geName = iba.getIBAValue(PropertiesUtil.getValueByKey("part.NAMEDE"));
//            if(Constant.CREATE_LANG_CN.equals(hostLang)){
//                hostLangName = cnName;
//            } else if (Constant.CREATE_LANG_EN.equals(hostLang)) {
//                hostLangName = enName;
//            } else if (Constant.CREATE_LANG_DN.equals(hostLang)){
//                hostLangName = geName;
//            } else {
//                throw new WTException("未能匹配部件创作语言"+"\r\n"+"Failed to match component creation language"+"\r\n"+"Widget-Erstellungssprache kann nicht übereinstimmen");
//            }
//            if(!part.getName().equals(hostLangName)){
//                // 需要修改部件名称时要同步部件三语IBA
//                PartUtil.changePartName(part, hostLangName);
//            }
        }
        super.postProcess(nmCommandBean, list);
        return result;
    }

    @Override
    public FormResult postTransactionProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        return super.postTransactionProcess(nmCommandBean, list);
    }
}
