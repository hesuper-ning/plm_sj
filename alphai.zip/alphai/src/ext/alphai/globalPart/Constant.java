package ext.alphai.globalPart;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 常量类
 */
public class Constant {

    public static final String ZERO_Str = "0";
    public static final String ONE_Str = "1";
    public static final String NINE_Str = "9";

    public static final String WINDCHILL ="WINDCHILL";

    public static final String STRING_BLANK= "";
    public static final String Single_Quotes = "'";

    public static final String Comma = ",";
    // 首选项配置中文用户说明 key
    public static final String User_Language_CHINA ="ext.alphai.globalPart.language.CHINA";

    // 首选项配置英文用户说明 key
    public static final String User_Language_ENGLISH ="ext.alphai.globalPart.language.ENGLISH";
    // 首选项配置德文用户说明 key
    public static final String User_Language_GERMAN ="ext.alphai.globalPart.language.GERMAN";

    public static final String Time_Format = "yyyy-MM-dd HH:mm:ss";

    // 分页大小
    public static final int pageSize = 20;

    // IBA|
    public static final String IBA = "IBA|";

    /*
    命名规则数据库字段
     */
    public static final String CLASSIFYNAME = "CLASSIFYNAME";
    public static final String NAMINGRULES = "NAMINGRULES";

    /*
    术语库数据库字段
    STATUS         VARCHAR2(5) DEFAULT '0' NOT NULL,
     */
    public static final String AIGLOSSARYID = "AIGLOSSARYID";
    public static final String ENGLISHTERM = "ENGLISHTERM";

    public static final String CHINESETERM = "CHINESETERM";
    public static final String GERMANTERM = "GERMANTERM";
    public static final String STATUS = "STATUS";



    public static final String CREATETIME = "CREATETIME";
    public static final String UPDATETIME = "UPDATETIME";
    public static final String CREATEBY = "CREATEBY";

    /*
    部件的创建和修改标识
     */
    public static final String CreatePartWizard = "createPartWizard";
    public static final String Edit = "edit";
    /*
    符号
     */
    public static final String Slash = "/";
    public static final String STRING_COMMA = ",";

    public static final String SELECT = "select";
    public static final String INPUT = "input";

    // 部件默认语言 枚举内部值
    public static final String AUTH_LAG_CN = "CN";
    public static final String AUTH_LAG_EN = "EN";
    public static final String AUTH_LAG_DE= "DE";
    // 部件名称主语言长度上线
    public static final int partNameLength = 40;
    /*
    部件IBA 内部名
     */
    // 部件主语言
    public static final String IBA_HOST_LANG = "AI_AuthLanguage";
    // 中文名称
    public static final String JC_CNNAME = "JC_CNNAME";
    // 英文名称
    public static final String AI_NAME_EN = "AI_NAME_EN";
    // 德文名称
    public static final String AI_NAME_DE = "AI_NAME_DE";

    // 部件创作语言标识
    // 中文
    public static final String CREATE_LANG_CN = "CN";
    // 英文
    public static final String CREATE_LANG_EN = "EN";
    // 德文
    public static final String CREATE_LANG_DN = "DN";
}
