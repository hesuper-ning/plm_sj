package ext.alphai.globalPart;

public enum GlossaryEnum {

    Open("0", "打开"),
    Published("1", "已发布"),
    obsolete("9", "已废弃"),
    ;

    private final String key;
    private final String value;


    GlossaryEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }



    // 根据key获取对应的value
    public static String getValueByKey(String key) {
        for (GlossaryEnum enumItem : GlossaryEnum.values()) {
            if (enumItem.key.equals(key)) {
                return enumItem.value;
            }
        }
        return null; // 或者抛出异常或特定的默认值，视需求而定
    }


    public static GlossaryEnum getObjectByKey(String key) {
        for (GlossaryEnum enumItem : GlossaryEnum.values()) {
            if (enumItem.key.equals(key)) {
                return enumItem;
            }
        }
        return null; // 或者抛出异常或特定的默认值，视需求而定
    }

    // 根据value获取对应的key
    public static String getKeyByValue(String value) {
        for (GlossaryEnum enumItem : GlossaryEnum.values()) {
            if (enumItem.value.equals(value)) {
                return enumItem.key;
            }
        }
        return null; // 或者抛出异常或特定的默认值，视需求而定
    }


    /**
     * 根据value获得枚举对象
     * @param value
     * @return
     */
    public static GlossaryEnum getObjectByValue(String value) {
        for (GlossaryEnum enumItem : GlossaryEnum.values()) {
            if (enumItem.value.equals(value)) {
                return enumItem;
            }
        }
        return null; // 或者抛出异常或特定的默认值，视需求而定
    }
}
