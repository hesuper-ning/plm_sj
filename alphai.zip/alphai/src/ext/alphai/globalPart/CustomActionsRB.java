package ext.alphai.globalPart;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;
@RBUUID("ext.alphai.globalPart.CustomActionsRB")
public class CustomActionsRB extends WTListResourceBundle {

    @RBEntry("JC Terms")
    public static final String PRIVATE_CONSTANT_1= "jcGlobalPart.jcGlossary.description";
    @RBEntry("JC Terms")
    public static final String PRIVATE_CONSTANT_2 = "jcGlobalPart.jcGlossary.tooltip";

    @RBEntry("Part Naming Rules")
    public static final String PRIVATE_CONSTANT_3= "jcGlobalPart.jcNamingRules.description";
    @RBEntry("Part Naming Rules")
    public static final String PRIVATE_CONSTANT_4 = "jcGlobalPart.jcNamingRules.tooltip";


    @RBEntry("Part Name Confirm")
    public static final String PRIVATE_CONSTANT_5= "jcGlobalPart.jcNamingExamine.description";
    @RBEntry("Part Name Confirm")
    public static final String PRIVATE_CONSTANT_6 = "jcGlobalPart.jcNamingExamine.tooltip";


    @RBEntry("Revision LD Part")
    public static final String PRIVATE_CONSTANT_7= "jcGlobalPart.revisedLDversionWizard.description";
    @RBEntry("Revision LD Part")
    public static final String PRIVATE_CONSTANT_8 = "jcGlobalPart.revisedLDversionWizard.tooltip";

    @RBEntry("Revision LD Part")
    public static final String PRIVATE_CONSTANT_9= "jcGlobalPart.revisedLDversion.description";
    @RBEntry("Revision LD Part")
    public static final String PRIVATE_CONSTANT_10 = "jcGlobalPart.revisedLDversion.tooltip";
	
	
	
	@RBEntry("Elevate to Global Parts")
    public static final String PRIVATE_CONSTANT_13= "jcGlobalPart.setGlobalPart.description";
    @RBEntry("Elevate to Global Parts")
    public static final String PRIVATE_CONSTANT_14 = "jcGlobalPart.setGlobalPart.tooltip";

    @RBEntry("set to LD/JC State")
    public static final String PRIVATE_CONSTANT_15= "jcGlobalPart.setLDJCState.description";
    @RBEntry("set to LD/JC State")
    public static final String PRIVATE_CONSTANT_16 = "jcGlobalPart.setLDJCState.tooltip";


    @RBEntry("JY Change CAD Doc Version")
    public static final String PRIVATE_CONSTANT_17= "jcGlobalPart.CADChangeVersionWizard.description";
    @RBEntry("JY Change CAD Doc Version")
    public static final String PRIVATE_CONSTANT_18 = "jcGlobalPart.CADChangeVersionWizard.tooltip";


    @RBEntry("Spread to all factories")
    public static final String PRIVATE_CONSTANT_19= "jcGlobalPart.copyDesignPartAttrToAllManufacturingParts.description";
    @RBEntry("Spread to all factories")
    public static final String PRIVATE_CONSTANT_20 = "jcGlobalPart.copyDesignPartAttrToAllManufacturingParts.tooltip";

    @RBEntry("Get design attributes")
    public static final String PRIVATE_CONSTANT_21= "jcGlobalPart.copyDesignPartAttrToThisManufacturingPart.description";
    @RBEntry("Get design attributes")
    public static final String PRIVATE_CONSTANT_22 = "jcGlobalPart.copyDesignPartAttrToThisManufacturingPart.tooltip";



    @RBEntry("Copy Design Attribute")
    public static final String PRIVATE_CONSTANT_99 = "object.copyDesignAttribute.description";
}
