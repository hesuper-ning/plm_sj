package ext.alphai.sinoboom.colorpart.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sinoboom.colorpart.service.BatchColorPartService;
import ext.alphai.sinoboom.colorpart.vo.ResponseVo;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@Controller
@RequestMapping({"/colorPart"})
public class ColorPartController {
    static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 查询部件以及颜色选择
     * @param partNumber
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/selectPart", method = RequestMethod.GET )
    public void selectPart(@RequestParam("partNumber") String partNumber, HttpServletRequest request,
                                    HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        try {
            vo = BatchColorPartService.getColorPartChoiceVO(partNumber);
        } catch (Exception e) {
            vo = ResponseVo.error(500, e.getMessage());
            e.printStackTrace();
        }

        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);
    }


    @RequestMapping(value = "/selectModel", method = RequestMethod.GET )
    public void selectModel(@RequestParam("modelNumber") String modelNumber, HttpServletRequest request,
                                    HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        try {
//            vo = BatchColorPartService.updateColorModel(modelNumber);
            vo = BatchColorPartService.updateColorModelExcel(modelNumber);
        } catch (Exception e) {
            vo = ResponseVo.error(500, e.getMessage());
            e.printStackTrace();
        }

        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);
    }




    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }
}
