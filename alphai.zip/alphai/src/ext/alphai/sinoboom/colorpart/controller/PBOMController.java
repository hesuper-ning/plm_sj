package ext.alphai.sinoboom.colorpart.controller;

import ext.alphai.sinoboom.colorpart.service.PBOMTreeService;
import ext.alphai.sinoboom.colorpart.vo.PBOMFormRequest;
import ext.alphai.sinoboom.colorpart.vo.PBOMPartNodeVo;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@Controller
@RequestMapping({"/pbom"})
public class PBOMController{


        private PBOMTreeService pbomTreeService = new PBOMTreeService();

        /**
         * 获取PBOM树
         *
         * @param includeChildren true-获取所有子项(多层), false-只获取根部件(单层)
         */
        @GetMapping("/tree")
        public ResponseEntity<?> getPBOMTree(
                @RequestParam("oid") String oid,
                @RequestParam("factoryName") String factoryName,
                @RequestParam("includeChildren") boolean includeChildren) {

            try {
                PBOMPartNodeVo tree;
                if (includeChildren) {
                    // 多层：获取完整树结构
                    tree = pbomTreeService.buildFullPBOMTree(oid, factoryName);
                } else {
                    // 单层：只返回根部件，不获取子项
                    tree = pbomTreeService.buildSingleLevelPBOM(oid, factoryName);
                }
                return ResponseEntity.ok(tree);
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(Map.of("error", "获取PBOM失败: " + e.getMessage()));
            }
        }

        /**
         * 获取PBOM扁平列表
         *
         * @param includeChildren true-获取所有子项(多层), false-只获取根部件(单层)
         */
        @GetMapping("/flat")
        public ResponseEntity<?> getPBOMFlatList(
                @RequestParam("oid") String oid,
                @RequestParam("factoryName") String factoryName,
                @RequestParam("includeChildren") boolean includeChildren) {

            try {
                List<PBOMPartNodeVo> flatList;
                if (includeChildren) {
                    // 多层：获取完整列表
                    PBOMPartNodeVo tree = pbomTreeService.buildFullPBOMTree(oid, factoryName);
                    flatList = flattenTree(tree);
                } else {
                    // 单层：只返回根部件
                    PBOMPartNodeVo root = pbomTreeService.buildSingleLevelPBOM(oid, factoryName);
                    flatList = Arrays.asList(root);
                }
                return ResponseEntity.ok(flatList);
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(Map.of("error", "获取PBOM失败: " + e.getMessage()));
            }
        }

        /**
         * 处理PBOM表单提交（兼容原有processor逻辑）
         */
        @PostMapping("/submit")
        public ResponseEntity<?> submitPBOMForm(@RequestBody PBOMFormRequest request) {
            try {
                // 这里调用原有的processor逻辑
                Map<String, Object> result = processPBOMForm(request);
                return ResponseEntity.ok(result);
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(Map.of("error", "处理PBOM表单失败: " + e.getMessage()));
            }
        }

        private List<PBOMPartNodeVo> flattenTree(PBOMPartNodeVo root) {
            List<PBOMPartNodeVo> result = new ArrayList<>();
            flattenTreeRecursive(root, result);
            return result;
        }

        private void flattenTreeRecursive(PBOMPartNodeVo node, List<PBOMPartNodeVo> result) {
            result.add(node);
            if (node.hasChildren()) {
                for (PBOMPartNodeVo child : node.getChildren()) {
                    flattenTreeRecursive(child, result);
                }
            }
        }

        /**
         * 处理PBOM表单请求 - 这里调用您原有的CreatePBOMProcessor逻辑
         */
        private Map<String, Object> processPBOMForm(PBOMFormRequest request) throws Exception {
            // 这里可以调用您原有的CreatePBOMProcessor逻辑
            // 或者将原有逻辑重构到服务层

            Map<String, Object> result = new HashMap<>();
            result.put("status", "SUCCESS");
            result.put("message", "PBOM处理完成");

            // 这里可以添加原有的业务逻辑处理
            // 比如：创建新视图、设置IBA属性、生成工艺任务等

            return result;
        }


}
