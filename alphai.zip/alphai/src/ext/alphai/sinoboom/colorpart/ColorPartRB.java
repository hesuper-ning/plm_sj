package ext.alphai.sinoboom.colorpart;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.sinoboom.colorpart.ColorPartRB")
public class ColorPartRB extends WTListResourceBundle {

    @RBEntry("Batch Create Color Part")
    public static final String BATCH_COlOR_PART_TITLE= "ColorPart.batchCreateColorPart.title";

    @RBEntry("Batch Create Color Part")
    public static final String BATCH_COlOR_PART_TOOLTIP = "ColorPart.batchCreateColorPart.tooltip";

    @RBEntry("Batch Create Color Part")
    public static final String BATCH_COlOR_PART_DES= "ColorPart.batchCreateColorPart.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String BATCH_COlOR_PART_ICON = "ColorPart.batchCreateColorPart.icon";


    @RBEntry("Batch Create PBOM")
    public static final String BATCH_PBOM_VIEW_TITLE= "ColorPart.batchCreatePBOM.title";

    @RBEntry("Batch Create PBOM")
    public static final String  BATCH_PBOM_VIEW_TOOLTIP = "ColorPart.batchCreatePBOM.tooltip";

    @RBEntry("Batch Create PBOM")
    public static final String  BATCH_PBOM_VIEW_DES= "ColorPart.batchCreatePBOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String  BATCH_PBOM_VIEW_ICON = "ColorPart.batchCreatePBOM.icon";
}
