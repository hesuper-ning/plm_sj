package ext.alphai.sinoboom.colorpart.processor;


import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.option.model.Choice;
import com.ptc.windchill.option.model.Option;
import ext.alphai.sinoboom.colorpart.constants.ColorPartConstant;
import ext.alphai.sinoboom.colorpart.service.BatchColorPartService;
import ext.alphai.sinoboom.colorpart.vo.ChoiceVO;
import ext.alphai.sinoboom.colorpart.vo.ColorPartChoiceVO;
import ext.cirpoint.integration.mdm.clients.MDMDataHelper;
import ext.cirpoint.integration.mdm.clients.ReleaseDesignPart2MDMProcessor;
import ext.cirpoint.integration.mdm.clients.ReleaseFactoryPart2MDMProcessor;
import ext.cirpoint.mpm.common.util.IBAUtils;
import ext.cirpoint.mpm.common.util.ToolUtils;
import ext.cirpoint.mpm.pbom.util.EBOM2PBOMHelper;
import ext.cirpoint.mpm.variantspec.helper.ConfigurableBOMHelper;
import ext.cirpoint.mpm.variantspec.helper.VariantSpecWorkflowHelper;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTList;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/***
 * 根据颜色件手工创建颜色实例
 */
public class BatchCreateColorPartProcessor extends DefaultObjectFormProcessor {
    private static final Logger LOGGER = LogManager.getLogger(BatchCreateColorPartProcessor.class.getName());

    @Override
    public FormResult doOperation(NmCommandBean nmcb, List<ObjectBean> paramList) throws WTException {
        FormResult result = super.doOperation(nmcb, paramList);
        String colorPartsJson = nmcb.getRequest().getParameter("colorParts");


        Gson gson = new Gson();
        Type listType = new TypeToken<List<ColorPartChoiceVO>>() {}.getType();
        List<ColorPartChoiceVO> colorPartChoiceList = gson.fromJson(colorPartsJson, listType);

        // 收集所有处理结果
        StringBuilder allMessages = new StringBuilder();
        int successCount = 0;
        int failureCount = 0;
        boolean hasOverallFailure = false;

        boolean accessEnforced = SessionServerHelper.manager.setAccessEnforced(false);// 忽略权限

        try {
            SessionServerHelper.manager.setAccessEnforced(false);
            for (ColorPartChoiceVO colorPartChoiceVO : colorPartChoiceList) {
                EBOM2PBOMHelper ebom2PBOMHelper = new EBOM2PBOMHelper();
                VariantSpecWorkflowHelper variantSpecWorkflowHelper = new VariantSpecWorkflowHelper();
                MDMDataHelper mdmDataHelper = new MDMDataHelper();
                List<WTPart> colorPartList = new ArrayList<>();
                WTList wtList = new WTArrayList();

                ReleaseDesignPart2MDMProcessor designPart2MDMProcessor = new ReleaseDesignPart2MDMProcessor();
                ReleaseFactoryPart2MDMProcessor factoryPart2MDMProcessor = new ReleaseFactoryPart2MDMProcessor();
                StringBuffer msg = new StringBuffer();

                try {
                    String partOid = colorPartChoiceVO.getPartOid();
                    String partNumber = colorPartChoiceVO.getPartNumber();

                    //获取到部件
                    WTPart wtPart = (WTPart) ToolUtils.getObjectByOid(partOid);
                    List<String> factoryList = ebom2PBOMHelper.getFactoryList(wtPart);

//                    IBAUtils ibaUtils = new IBAUtils(wtPart);
//                    String external_material_group = ibaUtils.getIBATypeValue(ColorPartConstant.IBA_PART_EXTERNAL_MATERIAL_GROUP);

                    //外购物料组找到颜色选项
//                    Option option = ConfigurableBOMHelper.getOptionByNumber(external_material_group);

                    List<Choice> choiceInfos = new ArrayList<>();
                    //获取到颜色选择集合
                    List<ChoiceVO> choiceVOList = colorPartChoiceVO.getChoiceVOList();

                    //
                    for (ChoiceVO choiceVO : choiceVOList) {
                        //选中的颜色选择
                        if (choiceVO.getSelected()){
                            //用oid获取到选择对象
                            String choiceOid = choiceVO.getChoiceOid();
                            Choice choice = (Choice) ToolUtils.getObjectByOid(choiceOid);


                            //获取选择的颜色代码
//                            IBAUtils choiceibaUtils = new IBAUtils(choice);
//                            String choiceEnName = choiceibaUtils.getIBATypeValue(ColorPartConstant.IBA_EN_NAME);//选择英文名称
//                            String extendedColored = choiceibaUtils.getIBATypeValue(ColorPartConstant.IBA_EXTENDEDCOLORED);
                            String extendedColored = choiceVO.getChoiceColorCode();

                            if (StringUtils.isNotBlank(extendedColored)) {
                                //部件外部物料组找到选项
                                Option option = ConfigurableBOMHelper.getOptionByNumber(colorPartChoiceVO.getExternalMaterialGroup());
                                WTPart colorPart = variantSpecWorkflowHelper.createColorPart(choice, wtPart, extendedColored);
                                variantSpecWorkflowHelper.syncColorPartIBAValues(wtPart, colorPart, extendedColored, option, mdmDataHelper);
                                //设置部件英文名称  =  本色件+空格+选择英文名称
                                BatchColorPartService.setEnName(colorPart ,choice);

                                colorPartList.add(colorPart);
                                wtList.add(colorPart);
                            } else {
                                msg.append("选择（").append(choice.getName()).append("）颜色代码为空，创建失败！");
                            }
                            choiceInfos.add(choice);
                        }
                    }



                    if (choiceInfos.isEmpty()) {
                        msg.append("未找到可扩充的选择，创建失败！");
                    }

                    if (colorPartList.size() > 0) {
                        MDMDataHelper.flagSendMdmOrErpDesignData(colorPartList, msg, wtPart.getCreatorName(), "");
                        Thread.sleep(30000);

                        for (String factory : factoryList) {
                            MDMDataHelper.flagSendMdmOrErpFactoryData(colorPartList, msg, wtPart.getCreatorName(), factory);
                        }
                    }

                    if (wtList.size() > 0) {
                        State state = State.toState(ColorPartConstant.STATE_RELEASED);
                        LifeCycleHelper.service.setLifeCycleState(wtList, state, true);
                    }

                    // 记录单个处理结果
                    if (msg.length() == 0) {
                        successCount++;
                        allMessages.append("部件 ").append(partNumber).append(" 处理成功\n");
                    } else {
                        failureCount++;
                        hasOverallFailure = true;
                        allMessages.append("部件 ").append(partNumber).append(" 处理失败: ").append(msg.toString()).append("\n");
                    }

                } catch (InterruptedException e) {
                    failureCount++;
                    hasOverallFailure = true;
                    String errorMsg = "部件 " + colorPartChoiceVO.getPartNumber() + " 处理中断: " + e.getLocalizedMessage();
                    LOGGER.error(errorMsg);
                    allMessages.append(errorMsg).append("\n");
                } catch (WTException e) {
                    failureCount++;
                    hasOverallFailure = true;
                    String errorMsg = "部件 " + colorPartChoiceVO.getPartNumber() + " 处理异常: " + e.getLocalizedMessage();
                    LOGGER.error(errorMsg);
                    allMessages.append(errorMsg).append("\n");
                } catch (Exception e) {
                    failureCount++;
                    hasOverallFailure = true;
                    String errorMsg = "部件 " + colorPartChoiceVO.getPartNumber() + " 处理异常: " + e.getLocalizedMessage();
                    LOGGER.error(errorMsg);
                    allMessages.append(errorMsg).append("\n");
                }
            }
        } finally {
            SessionServerHelper.manager.setAccessEnforced(accessEnforced);// 恢复权限
        }

        // 设置最终结果
        if (!hasOverallFailure) {
            result.setStatus(FormProcessingStatus.SUCCESS);
            String feedbackMsg = "所有颜色件创建成功! 成功: " + successCount + "个, 失败: " + failureCount + "个\n" + allMessages.toString();
            result.addFeedbackMessage(
                    new FeedbackMessage(FeedbackType.SUCCESS, null, null, null, new String[]{feedbackMsg}));
        } else {
            result.setStatus(FormProcessingStatus.FAILURE);
            String feedbackMsg = "颜色件创建完成，但有部分失败! 成功: " + successCount + "个, 失败: " + failureCount + "个\n" + allMessages.toString();
            result.addFeedbackMessage(
                    new FeedbackMessage(FeedbackType.FAILURE, null, null, null, new String[]{feedbackMsg}));
        }

        result.setSkipPageRefresh(true);
        return result;
    }


}