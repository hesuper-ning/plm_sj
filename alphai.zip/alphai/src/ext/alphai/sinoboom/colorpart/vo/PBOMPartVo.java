package ext.alphai.sinoboom.colorpart.vo;

import ext.alphai.sinoboom.colorpart.constants.ColorPartConstant;
import ext.alphai.sinoboom.colorpart.util.IBAUtil;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

public class PBOMPartVo {
    private String partOid;

    private String partNumber;

    private String partName;

    private String partVersion;

    private String partState;

    private String sapMaterialGroup;

    private boolean isPhantom;

    private String factoryName;

    private String source; //源---对应 *采购类型

    public PBOMPartVo(WTPart part) throws WTException {
//        this.factoryName = part.getViewName();//工厂视图 这个值从前端传入，暂时使用部件的工厂视图
        this.partOid = part.getPersistInfo().getObjectIdentifier().toString();//工厂oid
        this.partNumber = part.getNumber();//工厂编号
        this.partName = part.getName();//工厂名称
        this.partVersion = part.getVersionIdentifier().getValue()+"."+part.getIterationIdentifier().getValue()+"("+part.getViewName()+")";//修订版本.迭代版本(工厂视图)
        this.partState = part.getLifeCycleState().toString();//部件状态
        this.isPhantom = part.isPhantom();//是否虚拟键
        this.source = part.getSource().getDisplay(SessionHelper.getLocale());
        //IBA属性
        IBAUtil ibaUtil = new IBAUtil(part);
        this.sapMaterialGroup = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_SAPMATERIALGROUP);
    }

    public String getPartOid() {
        return partOid;
    }

    public void setPartOid(String partOid) {
        this.partOid = partOid;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPartVersion() {
        return partVersion;
    }

    public void setPartVersion(String partVersion) {
        this.partVersion = partVersion;
    }

    public String getPartState() {
        return partState;
    }

    public void setPartState(String partState) {
        this.partState = partState;
    }

    public String getSapMaterialGroup() {
        return sapMaterialGroup;
    }

    public void setSapMaterialGroup(String sapMaterialGroup) {
        this.sapMaterialGroup = sapMaterialGroup;
    }

    public Boolean getIsPhantom() {
        return isPhantom;
    }

    public void setIsPhantom(Boolean isPhantom) {
        this.isPhantom = isPhantom;
    }

    public String getFactoryName() {
        return factoryName;
    }

    public void setFactoryName(String factoryName) {
        this.factoryName = factoryName;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
