package ext.alphai.sinoboom.colorpart.vo;

import java.util.List;

public class ColorPartChoiceVO {
    private String partOid;

    private String partNumber;

    private String partName;

    private String partVersion;

    private String partState;

    private String externalMaterialGroup;

    public String getExternalMaterialGroup() {
        return externalMaterialGroup;
    }

    public void setExternalMaterialGroup(String externalMaterialGroup) {
        this.externalMaterialGroup = externalMaterialGroup;
    }

    private List<ChoiceVO> choiceVOList;

    public String getPartOid() {
        return partOid;
    }

    public void setPartOid(String partOid) {
        this.partOid = partOid;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPartVersion() {
        return partVersion;
    }

    public void setPartVersion(String partVersion) {
        this.partVersion = partVersion;
    }

    public String getPartState() {
        return partState;
    }

    public void setPartState(String partState) {
        this.partState = partState;
    }

    public List<ChoiceVO> getChoiceVOList() {
        return choiceVOList;
    }

    public void setChoiceVOList(List<ChoiceVO> choiceVOList) {
        this.choiceVOList = choiceVOList;
    }
}
