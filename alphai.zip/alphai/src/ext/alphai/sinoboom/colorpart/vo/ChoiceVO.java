package ext.alphai.sinoboom.colorpart.vo;

public class ChoiceVO {
    private String choiceOid;
    private String choiceName;
    private String choiceNumber;
    private String choiceState;
    private String choiceVersion;
    private String choiceColorCode;
    private boolean selected = false;
    private String externalMaterialGroup;//外部物料组

    @Override
    public String toString() {
        return "ChoiceVO{" +
                "choiceOid='" + choiceOid + '\'' +
                ", choiceName='" + choiceName + '\'' +
                ", choiceNumber='" + choiceNumber + '\'' +
                ", choiceState='" + choiceState + '\'' +
                ", choiceVersion='" + choiceVersion + '\'' +
                ", choiceColorCode='" + choiceColorCode + '\'' +
                ", selected=" + selected +
                ", externalMaterialGroup='" + externalMaterialGroup + '\'' +
                '}';
    }

    public boolean isSelected() {
        return selected;
    }

    public String getExternalMaterialGroup() {
        return externalMaterialGroup;
    }

    public void setExternalMaterialGroup(String externalMaterialGroup) {
        this.externalMaterialGroup = externalMaterialGroup;
    }

    public String getChoiceOid() {
        return choiceOid;
    }

    public void setChoiceOid(String choiceOid) {
        this.choiceOid = choiceOid;
    }

    public String getChoiceName() {
        return choiceName;
    }

    public void setChoiceName(String choiceName) {
        this.choiceName = choiceName;
    }

    public String getChoiceNumber() {
        return choiceNumber;
    }

    public void setChoiceNumber(String choiceNumber) {
        this.choiceNumber = choiceNumber;
    }

    public String getChoiceState() {
        return choiceState;
    }

    public void setChoiceState(String choiceState) {
        this.choiceState = choiceState;
    }

    public String getChoiceVersion() {
        return choiceVersion;
    }

    public void setChoiceVersion(String choiceVersion) {
        this.choiceVersion = choiceVersion;
    }

    public String getChoiceColorCode() {
        return choiceColorCode;
    }

    public void setChoiceColorCode(String choiceColorCode) {
        this.choiceColorCode = choiceColorCode;
    }

    public boolean getSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }




}
