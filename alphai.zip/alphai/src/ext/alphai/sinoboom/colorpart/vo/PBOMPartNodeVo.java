package ext.alphai.sinoboom.colorpart.vo;

import ext.alphai.sinoboom.colorpart.util.PartUtil;
import ext.alphai.sinoboom.colorpart.util.VersionUtil;
import wt.part.WTPart;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;

/**
 * PBOM树节点VO - 扩展基础VO，添加树形结构能力
 */
public class PBOMPartNodeVo extends PBOMPartVo {
    // 树形结构字段
    private String parentOid;
    private String parentPartNumber;
    private Integer level;
    private Integer sortOrder;
    private Double quantity;
    private String unit;

    // 链接信息
    private String linkOid;
    private String linkType; // "USAGE" 或 "SUBSTITUTE"

    // 表单字段（兼容原有processor）
    private String technologyType; // 工艺类型
    private String zz; // 制造属性   是部件的源，在新建PBOM是采购类型

    // 子节点列表
    private List<PBOMPartNodeVo> children = new ArrayList<>();



    public PBOMPartNodeVo(WTPart part) throws WTException {
        super(part);
    }

    public PBOMPartNodeVo(WTPartUsageLink usageLink) throws WTException {
        super((WTPart)VersionUtil.getLatestObjectByMaster(usageLink.getUses()));
        this.linkOid = usageLink.getPersistInfo().getObjectIdentifier().toString();
        this.linkType = "USAGE";

        this.quantity =  usageLink.getQuantity().getAmount();
        this.unit = usageLink.getQuantity().getUnit() != null ? usageLink.getQuantity().getUnit().toString() : null;
    }

    public PBOMPartNodeVo(WTPartSubstituteLink substituteLink) throws WTException {
        super(PartUtil.getReleateDesignPartByNumber(substituteLink.getSubstitutes().getNumber()));
        this.linkOid = substituteLink.getPersistInfo().getObjectIdentifier().toString();
        this.linkType = "SUBSTITUTE";
    }

    // 树操作方法
    public void addChild(PBOMPartNodeVo child) {
        if (this.children == null) {
            this.children = new ArrayList<>();
        }
        this.children.add(child);
    }

    public boolean hasChildren() {
        return this.children != null && !this.children.isEmpty();
    }

    // getter和setter方法
    public String getParentOid() { return parentOid; }
    public void setParentOid(String parentOid) { this.parentOid = parentOid; }

    public String getParentPartNumber() { return parentPartNumber; }
    public void setParentPartNumber(String parentPartNumber) { this.parentPartNumber = parentPartNumber; }

    public Integer getLevel() { return level; }
    public void setLevel(Integer level) { this.level = level; }

    public Integer getSortOrder() { return sortOrder; }
    public void setSortOrder(Integer sortOrder) { this.sortOrder = sortOrder; }

    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getLinkOid() { return linkOid; }
    public void setLinkOid(String linkOid) { this.linkOid = linkOid; }

    public String getLinkType() { return linkType; }
    public void setLinkType(String linkType) { this.linkType = linkType; }

    public String getTechnologyType() { return technologyType; }
    public void setTechnologyType(String technologyType) { this.technologyType = technologyType; }

    public String getZz() { return zz; }
    public void setZz(String zz) { this.zz = zz; }

    public List<PBOMPartNodeVo> getChildren() { return children; }
    public void setChildren(List<PBOMPartNodeVo> children) { this.children = children; }
}