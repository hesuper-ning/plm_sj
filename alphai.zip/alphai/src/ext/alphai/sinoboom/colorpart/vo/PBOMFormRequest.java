package ext.alphai.sinoboom.colorpart.vo;

import java.util.Map;

/**
 * PBOM表单请求对象
 */
public  class PBOMFormRequest {
    private String oid;
    private String factoryName;
    private Map<String, Map<String, String>> selectedData;

    // getter和setter
    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getFactoryName() {
        return factoryName;
    }

    public void setFactoryName(String factoryName) {
        this.factoryName = factoryName;
    }

    public Map<String, Map<String, String>> getSelectedData() {
        return selectedData;
    }

    public void setSelectedData(Map<String, Map<String, String>> selectedData) {
        this.selectedData = selectedData;
    }
}