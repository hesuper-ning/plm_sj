package ext.alphai.sinoboom.colorpart.vo;

public class ColorConf {
    private String materialCode;
    private String englishDescription;
    private String chineseDescription;
    private boolean remark;

    public ColorConf(String materialCode, String englishDescription, String chineseDescription, boolean remark) {
        this.materialCode = materialCode;
        this.englishDescription = englishDescription;
        this.chineseDescription = chineseDescription;
        this.remark = remark;
    }

    // Getter和Setter方法
    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getEnglishDescription() {
        return englishDescription;
    }

    public void setEnglishDescription(String englishDescription) {
        this.englishDescription = englishDescription;
    }

    public String getChineseDescription() {
        return chineseDescription;
    }

    public void setChineseDescription(String chineseDescription) {
        this.chineseDescription = chineseDescription;
    }

    public boolean isRemark() {
        return remark;
    }

    public void setRemark(boolean remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "ColorConf{" +
                "materialCode='" + materialCode + '\'' +
                ", englishDescription='" + englishDescription + '\'' +
                ", chineseDescription='" + chineseDescription + '\'' +
                ", remark=" + remark +
                '}';
    }
}

