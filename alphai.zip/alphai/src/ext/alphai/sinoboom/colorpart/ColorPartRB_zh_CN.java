package ext.alphai.sinoboom.colorpart;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.sinoboom.colorpart.ColorPartRB_zh_CN")
public class ColorPartRB_zh_CN extends WTListResourceBundle {

    @RBEntry("批量创建颜色件")
    public static final String BATCH_COlOR_PART_TITLE= "ColorPart.batchCreateColorPart.title";

    @RBEntry("批量创建颜色件")
    public static final String BATCH_COlOR_PART_TOOLTIP = "ColorPart.batchCreateColorPart.tooltip";

    @RBEntry("批量创建颜色件")
    public static final String BATCH_COlOR_PART_DES= "ColorPart.batchCreateColorPart.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String BATCH_COlOR_PART_ICON = "ColorPart.batchCreateColorPart.icon";


    @RBEntry("批量PBOM视图扩充")
    public static final String BATCH_PBOM_VIEW_TITLE= "ColorPart.batchCreatePBOM.title";

    @RBEntry("批量PBOM视图扩充")
    public static final String  BATCH_PBOM_VIEW_TOOLTIP = "ColorPart.batchCreatePBOM.tooltip";

    @RBEntry("批量PBOM视图扩充")
    public static final String  BATCH_PBOM_VIEW_DES= "ColorPart.batchCreatePBOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String  BATCH_PBOM_VIEW_ICON = "ColorPart.batchCreatePBOM.icon";

}
