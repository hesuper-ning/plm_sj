package ext.alphai.sinoboom.colorpart.service;


import ext.alphai.sinoboom.colorpart.util.ToolUtils;
import ext.alphai.sinoboom.colorpart.vo.ColorConf;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.content.ApplicationData;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


// Excel处理器
public class ExcelColorProcessor {

    public static  String COLOR_CHOICE_DOC_NUMBER = "COLORCHOICECONFIG";


    /**
     * 获取所有sheet的名称（从Windchill文档）
     * @return sheet名称列表
     */
    public static List<String> getAllSheetNames() {
        List<String> sheetNames = new ArrayList<>();

        try {
            WTDocument document = (WTDocument) ToolUtils.getObjByNumber(COLOR_CHOICE_DOC_NUMBER, WTDocument.class);
            ApplicationData applicationData = ToolUtils.getWTDocPrimary(document);
            InputStream is = ContentServerHelper.service.findContentStream(applicationData);

            try (Workbook workbook = new XSSFWorkbook(is)) {
                int numberOfSheets = workbook.getNumberOfSheets();
                for (int i = 0; i < numberOfSheets; i++) {
                    Sheet sheet = workbook.getSheetAt(i);
                    sheetNames.add(sheet.getSheetName());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return sheetNames;
    }

    /**
     * 根据sheet名称获取该表的所有颜色配置（从Windchill文档）
     * @param sheetName sheet名称
     * @return 颜色配置列表
     */
    public static List<ColorConf> getColorDataBySheetName( String sheetName) {
        List<ColorConf> colorConfList = new ArrayList<>();

        try {
            WTDocument document = (WTDocument) ToolUtils.getObjByNumber(COLOR_CHOICE_DOC_NUMBER, WTDocument.class);
            ApplicationData applicationData = ToolUtils.getWTDocPrimary(document);
            InputStream is = ContentServerHelper.service.findContentStream(applicationData);

            try (Workbook workbook = new XSSFWorkbook(is)) {
                Sheet sheet = workbook.getSheet(sheetName);
                if (sheet == null) {
                    System.out.println("Sheet '" + sheetName + "' not found!");
                    return colorConfList;
                }

                // 使用DataFormatter处理各种单元格类型
                DataFormatter formatter = new DataFormatter();

                // 跳过表头，从第二行开始读取
                for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                    Row row = sheet.getRow(i);
                    if (row == null) continue;

                    // 读取四列数据
                    String materialCode = getCellValue(row.getCell(0), formatter); // A列
                    String englishDescription = getCellValue(row.getCell(1), formatter); // B列
                    String chineseDescription = getCellValue(row.getCell(2), formatter); // C列
                    String remarkValue = getCellValue(row.getCell(3), formatter); // D列

                    // 判断备注是否为√，如果是则为true
                    boolean remark = "√".equals(remarkValue);

                    // 创建对象并添加到列表
                    ColorConf colorConf = new ColorConf(materialCode, englishDescription, chineseDescription, remark);
                    colorConfList.add(colorConf);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return colorConfList;
    }

    /**
     * 获取所有颜色配置数据（从Windchill文档）
     * @return 包含所有sheet数据的Map
     */
    public static Map<String, List<ColorConf>> getAllColorData() {
        Map<String, List<ColorConf>> allData = new HashMap<>();

        try {
            WTDocument document = (WTDocument) ToolUtils.getObjByNumber(COLOR_CHOICE_DOC_NUMBER, WTDocument.class);
            ApplicationData applicationData = ToolUtils.getWTDocPrimary(document);
            InputStream is = ContentServerHelper.service.findContentStream(applicationData);

            try (Workbook workbook = new XSSFWorkbook(is)) {
                int numberOfSheets = workbook.getNumberOfSheets();
                for (int i = 0; i < numberOfSheets; i++) {
                    Sheet sheet = workbook.getSheetAt(i);
                    String sheetName = sheet.getSheetName();
                    List<ColorConf> sheetData = getColorDataFromSheet(sheet);
                    allData.put(sheetName, sheetData);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return allData;
    }

    /**
     * 从指定sheet获取颜色配置数据
     * @param sheet Excel sheet
     * @return 颜色配置列表
     */
    private static List<ColorConf> getColorDataFromSheet(Sheet sheet) {
        List<ColorConf> colorConfList = new ArrayList<>();
        DataFormatter formatter = new DataFormatter();

        // 跳过表头，从第二行开始读取
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;

            String materialCode = getCellValue(row.getCell(0), formatter);
            String englishDescription = getCellValue(row.getCell(1), formatter);
            String chineseDescription = getCellValue(row.getCell(2), formatter);
            String remarkValue = getCellValue(row.getCell(3), formatter);

            boolean remark = "√".equals(remarkValue);
            ColorConf colorConf = new ColorConf(materialCode, englishDescription, chineseDescription, remark);
            colorConfList.add(colorConf);
        }

        return colorConfList;
    }

    /**
     * 获取单元格的值（使用DataFormatter，兼容所有版本）
     * @param cell 单元格
     * @param formatter DataFormatter实例
     * @return 单元格值的字符串表示
     */
    private static String getCellValue(Cell cell, DataFormatter formatter) {
        if (cell == null) {
            return "";
        }
        return formatter.formatCellValue(cell).trim();
    }

    // 测试方法
    public static void main(String[] args) {
        ExcelColorProcessor processor = new ExcelColorProcessor();
        String docNumber = "你的Windchill文档编号"; // 替换为实际的文档编号

        // 测试获取所有sheet名称
        System.out.println("=== 所有Sheet名称 ===");
        List<String> sheetNames = processor.getAllSheetNames();
        for (String name : sheetNames) {
            System.out.println(name);
        }

        // 测试获取指定sheet的数据
        System.out.println("\n=== 臂架Sheet的颜色配置 ===");
        List<ColorConf> armData = processor.getColorDataBySheetName( "臂架");
        for (ColorConf conf : armData) {
            System.out.println(conf);
        }

        System.out.println("\n=== 剪叉Sheet的颜色配置 ===");
        List<ColorConf> scissorsData = processor.getColorDataBySheetName( "剪叉");
        for (ColorConf conf : scissorsData) {
            System.out.println(conf);
        }

        // 获取所有数据
        System.out.println("\n=== 所有Sheet的颜色配置 ===");
        Map<String, List<ColorConf>> allData = processor.getAllColorData();
        for (Map.Entry<String, List<ColorConf>> entry : allData.entrySet()) {
            System.out.println("Sheet: " + entry.getKey() + ", 记录数: " + entry.getValue().size());
        }

        // 显示有备注的数据
        System.out.println("\n=== 臂架Sheet中有备注(√)的颜色配置 ===");
        for (ColorConf conf : armData) {
            if (conf.isRemark()) {
                System.out.println(conf);
            }
        }
    }
}