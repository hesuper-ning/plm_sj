package ext.alphai.sinoboom.colorpart.service;

import ext.alphai.sinoboom.colorpart.util.PartUtil;
import ext.alphai.sinoboom.colorpart.vo.ResponseVo;
import wt.part.WTPart;

public class PBOMService {

    public static ResponseVo getPartByNumber(String partNumber,String factoryName){

        WTPart wtPartByNumber = PartUtil.getWTPartByNumber(partNumber);
        if (wtPartByNumber == null) {
            return ResponseVo.error(201,partNumber+"编号部件不存在");
        }



        return  ResponseVo.success(null);
    }



}
