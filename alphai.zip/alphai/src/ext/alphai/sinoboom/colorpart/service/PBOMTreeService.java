package ext.alphai.sinoboom.colorpart.service;

import ext.alphai.sinoboom.colorpart.constants.ColorPartConstant;
import ext.alphai.sinoboom.colorpart.util.PartUtil;
import ext.alphai.sinoboom.colorpart.vo.PBOMPartNodeVo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTKeyedMap;
import wt.part.*;
import wt.util.WTException;
import wt.vc.config.ConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;

import java.util.*;

/**
 * PBOM树构建服务
 */
@Service
public class PBOMTreeService {
    private static final Logger logger = LogManager.getLogger(PBOMTreeService.class);



    /**
     * 构建单层PBOM（只返回根部件，不获取子项）
     */
    public PBOMPartNodeVo buildSingleLevelPBOM(String partNumber, String factoryName) throws WTException {

        WTPart rootPart = PartUtil.getWTPartByNumber(partNumber);
        if (rootPart == null) {
            throw new WTException("未找到编号"+partNumber+"部件！");
        }


        PBOMPartNodeVo rootNode = new PBOMPartNodeVo(rootPart);
        rootNode.setLevel(1);
        rootNode.setFactoryName(factoryName);

        logger.debug("单层PBOM构建完成, 根节点: {}", rootPart.getNumber());
        return rootNode;
    }

    /**
     * 构建完整多层PBOM树（获取所有子项，无层级限制）
     */
    public PBOMPartNodeVo buildFullPBOMTree(String partNumber, String factoryName) throws WTException {

        WTPart rootPart = PartUtil.getWTPartByNumber(partNumber);
        if (rootPart == null) {
            throw new WTException("未找到编号"+partNumber+"部件！");
        }


        PBOMPartNodeVo rootNode = new PBOMPartNodeVo(rootPart);
        rootNode.setLevel(1);
        rootNode.setFactoryName(factoryName);

        // 递归构建完整树（无层级限制）
        buildTreeRecursively(rootNode, factoryName, new HashMap<>());

        logger.debug("完整PBOM树构建完成, 根节点: {}", rootPart.getNumber());
        return rootNode;
    }

    /**
     * 递归构建树结构（无层级限制）
     */
    private void buildTreeRecursively(PBOMPartNodeVo parentNode, String factoryName,
                                      Map<String, WTPart> partCache) throws WTException {

        WTPart parentPart = getPartByOid(parentNode.getPartOid(), partCache);
        List<PBOMPartNodeVo> children = getDirectChildNodes(parentPart, factoryName, parentNode.getLevel() + 1, partCache);

        for (PBOMPartNodeVo child : children) {
            // 设置父子关系
            child.setParentOid(parentNode.getPartOid());
            child.setParentPartNumber(parentNode.getPartNumber());
            child.setLevel(parentNode.getLevel() + 1);

            parentNode.addChild(child);

            // 递归处理子节点（无层级限制）
            buildTreeRecursively(child, factoryName, partCache);
        }
    }

    /**
     * 获取直接子节点（一层）
     */
    private List<PBOMPartNodeVo> getDirectChildNodes(WTPart parentPart, String factoryName,
                                                     int level, Map<String, WTPart> partCache) throws WTException {
        List<PBOMPartNodeVo> childNodes = new ArrayList<>();

        // 获取使用链接子项
        QueryResult childNodesResult = WTPartHelper.service.getUsesWTParts(parentPart,getViewConfig(factoryName));

        // 处理使用链接
        List<WTPartUsageLink> usageLinks = new ArrayList<>();
        while (childNodesResult.hasMoreElements()) {
            Persistable[] nodePair = (Persistable[]) childNodesResult.nextElement();
            WTPartUsageLink usageLink = (WTPartUsageLink) nodePair[0];
            WTPart childPart = (WTPart) nodePair[1];

            // 业务逻辑校验
            if (isValidChildPart(childPart, factoryName)) {
                usageLinks.add(usageLink);

                PBOMPartNodeVo childNode = new PBOMPartNodeVo(usageLink);
                childNode.setLevel(level);
                childNode.setFactoryName(factoryName);
                childNodes.add(childNode);

                // 缓存部件
                partCache.put(childPart.getPersistInfo().getObjectIdentifier().toString(), childPart);
            }
        }

        // 处理替代件
        if (!usageLinks.isEmpty()) {
            processSubstituteLinks(usageLinks, childNodes, level, factoryName, partCache);
        }

        logger.debug("部件 {} 获取到 {} 个直接子节点", parentPart.getNumber(), childNodes.size());
        return childNodes;
    }

    /**
     * 处理替代件链接
     */
    private void processSubstituteLinks(List<WTPartUsageLink> usageLinks, List<PBOMPartNodeVo> childNodes,
                                        int level, String factoryName, Map<String, WTPart> partCache) throws WTException {

        WTCollection wtlist = new WTArrayList(usageLinks);
        WTKeyedMap keyMap = WTPartHelper.service.getSubstituteLinks(wtlist);

        if (keyMap != null && keyMap.size() > 0) {
            Iterator<?> iterator = keyMap.keySet().iterator();
            while (iterator.hasNext()) {
                Object list = keyMap.get(iterator.next());
                if (list instanceof WTCollection) {
                    WTCollection collection = (WTCollection) list;
                    Iterator<?> iter = collection.persistableIterator();
                    while (iter.hasNext()) {
                        Object tempObj = iter.next();
                        if (tempObj instanceof WTPartSubstituteLink) {
                            WTPartSubstituteLink substituteLink = (WTPartSubstituteLink) tempObj;
                            WTPart substitutePart = getFactoryPart(substituteLink.getSubstitutes().getNumber(), factoryName, partCache);

                            if (substitutePart != null && isValidChildPart(substitutePart, factoryName)) {
                                PBOMPartNodeVo substituteNode = new PBOMPartNodeVo(substituteLink);
                                substituteNode.setLevel(level);
                                substituteNode.setFactoryName(factoryName);
                                childNodes.add(substituteNode);

                                partCache.put(substitutePart.getPersistInfo().getObjectIdentifier().toString(), substitutePart);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 验证子部件是否有效
     */
    private boolean isValidChildPart(WTPart part, String factoryName) throws WTException {
        String viewName = part.getViewName();
        String state = part.getLifeCycleState().toString();

        // 判断是否为设计视图
        if (!viewName.equalsIgnoreCase(ColorPartConstant.DESIGN)) {
            return false;
        }

        // 判断状态是否有效
        if (!state.equals(ColorPartConstant.STATE_RELEASED) && !state.equals("TRIALPRODUCE")) {
            // 查找已发布版本
            WTPart releasedPart = PartUtil.getReleateDesignPartByNumber(part.getNumber());
            if (releasedPart == null) {
                return false;
            }
        }

        // 判断是否需要创建新视图
        return PartUtil.isNeedCreateNewView(part);
    }

    private WTPart getPartByOid(String partNumber, Map<String, WTPart> partCache) throws WTException {
        if (partCache.containsKey(partNumber)) {
            return partCache.get(partNumber);
        }

        WTPart part = PartUtil.getWTPartByNumber(partNumber);

        partCache.put(partNumber, part);
        return part;
    }

    private WTPart getFactoryPart(String number, String factoryName, Map<String, WTPart> partCache) throws WTException {
        for (WTPart part : partCache.values()) {
            if (part.getNumber().equals(number) && part.getViewName().equals(factoryName)) {
                return part;
            }
        }

        WTPart part = PartUtil.getPartByNumberAndView(number, factoryName);
        if (part != null) {
            partCache.put(part.getPersistInfo().getObjectIdentifier().toString(), part);
        }
        return part;
    }


    /**
     * 获取视图过滤条件
     *
     * @return
     * @throws WTException
     */
    public static ConfigSpec getViewConfig(String viewname) {
        ConfigSpec configSpec = null;
        try {
            // 这个是设计视图
            if (viewname != null) {
                View view = ViewHelper.service.getView(viewname);
                configSpec = WTPartConfigSpec
                        .newWTPartConfigSpec(WTPartStandardConfigSpec.newWTPartStandardConfigSpec(view, null));
            }
        } catch (WTException e) {
            logger.error(e.getLocalizedMessage(), e);
        }
        return configSpec;
    }
}