package ext.alphai.sinoboom.colorpart.service;

import com.ptc.windchill.option.model.Choice;
import com.ptc.windchill.option.model.Option;
import ext.alphai.sinoboom.colorpart.constants.ColorPartConstant;
import ext.alphai.sinoboom.colorpart.util.*;
import ext.alphai.sinoboom.colorpart.vo.ChoiceVO;
import ext.alphai.sinoboom.colorpart.vo.ColorConf;
import ext.alphai.sinoboom.colorpart.vo.ColorPartChoiceVO;
//历史代码的常量

import ext.alphai.sinoboom.colorpart.vo.ResponseVo;
import ext.cirpoint.mpm.common.constants.LifecycleConstant;
import ext.cirpoint.mpm.common.util.IBAUtils;
import org.apache.commons.lang3.StringUtils;简要
import wt.change2.WTChangeOrder2;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;
//windchill13版本的jdk需要的http包路径
//import jakarta.servlet.ServletOutputStream;
//import jakarta.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class BatchColorPartService {


    /**
     * 从配置文件获取颜色默认选择     弃用
     * @param modelNumber
     * @return
     */
    public static ResponseVo updateColorModel(String modelNumber) {

        String[] models = PropertiesUtil.getValueByKey(ColorPartConstant.AI_MB).split(";");
        if (!hasModel(models,modelNumber)) {
            return ResponseVo.error(201, "未找到指定模板，请重新选择");
        }
        String colorConf = PropertiesUtil.getValueByKey(modelNumber);

        Map<String, List<String>> colorMapByConf = getColorMapByConf(colorConf);
        return ResponseVo.success(colorMapByConf);

    }


    /**
     * 从excel获取默认颜色  启用
     * @param modelName
     * @return
     */
    public static ResponseVo updateColorModelExcel(String modelName ) {
        List<String> allSheetNames = ExcelColorProcessor.getAllSheetNames();
        if (!hasModel(allSheetNames,modelName)) {
            return ResponseVo.error(201, "未找到指定模板，请重新选择");
        }
        List<ColorConf> colorDataBySheetName = ExcelColorProcessor.getColorDataBySheetName(modelName);
        return ResponseVo.success(colorDataBySheetName);
    }


    /**
     * 获取配置文件
     * @param colorConf
     * @return
     */

    public static Map<String, List<String>> getColorMapByConf(String colorConf){
        Map<String, List<String>> result = new HashMap<>();

        Pattern pattern = Pattern.compile("(\\w+):\\{(.*?)\\}");
        Matcher matcher = pattern.matcher(colorConf);

        while (matcher.find()) {
            String key = matcher.group(1);
            String valuesStr = matcher.group(2);

            List<String> values = Arrays.stream(valuesStr.split(","))
                    .map(String::trim)
                    .collect(Collectors.toList());

            result.put(key, values);
        }

        return result;
    }

    public static boolean hasModel(String[] models, String modelNumber){
        boolean flag = false;
        for (String model : models) {
            String[] split = model.split(",");
            if (modelNumber.equals(split[1])){
                flag =true;
            }
        }
        return flag;
    }


    public static boolean hasModel( List<String> excelSheetNames, String modelName){
        boolean flag = false;
        for (String excelSheetName : excelSheetNames) {
            if (modelName.equals(excelSheetName)) {
                flag = true;
                break;
            }
        }
        return flag;
    }
    public static ResponseVo getColorPartChoiceVO(String partNumber) throws WTException {
        Locale locale = SessionHelper.getLocale();
        WTPart wtPartByNumber = PartUtil.getLatestWTPart(partNumber,"Design");
        System.out.println("部件视图："+wtPartByNumber.getViewName());
        System.out.println("部件版本："+wtPartByNumber.getVersionIdentifier().getValue()+"."+wtPartByNumber.getIterationIdentifier().getValue());
        if (wtPartByNumber == null) {
            return ResponseVo.error(201,partNumber+"编号部件不存在");
        }

        IBAUtil ibaUtil = new IBAUtil(wtPartByNumber);
        //后期改成用星邦常量类
        String isColorPart = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_ColorPart);
        //后期改成用星邦常量类
        String externalMaterialGroup = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_EXTERNAL_MATERIAL_GROUP);//外部物料组
        if (!isValidColorPart(isColorPart,externalMaterialGroup)) {
            return ResponseVo.error(202,partNumber+"编号部件不是颜色件，或者外部物料组为空！");
        }
        ColorPartChoiceVO colorPartChoiceVO = createColorPartChoiceVO(wtPartByNumber, locale);
        return ResponseVo.success(colorPartChoiceVO);
    }

    /**
     * 用reques返回的soid参数获取选中的wtPart集合
     *
     * @param request
     * @return
     * @throws WTException
     */
    public static List<WTPart> getWTPartListByReq(HttpServletRequest request) throws WTException {
        ArrayList<WTPart> wtParts = new ArrayList<>();

        Map<String, String[]> paramMap = request.getParameterMap();
        String[] soids = getSOid(paramMap);
        for (String soid : soids) {
            System.out.println("打印soid:" + soid);
            String or = getVROrORBySOid(soid);
            Persistable object = ToolUtils.getObjectByOid(or);
            if (object instanceof WTPart) {
                WTPart wtPart = (WTPart) object;
                wtParts.add(wtPart);
            }
        }
        return wtParts;

    }

    public static String[] getSOid(Map<String, String[]> paramMap) {
        String[] soids = new String[]{};
        for (Map.Entry<String, String[]> entry : paramMap.entrySet()) {
            String key = entry.getKey();
            String[] values = entry.getValue();
            if (key.equals("soid")) {
                soids = values;
            }
        }
        return soids;
    }


    /**
     * 分类soid含有的对象OR  包含epm、wtDoc、wtPart
     *
     * @param soid
     * @return
     */
    public static String getVROrORBySOid(String soid) {
        String pattern = null;
        if (soid.contains("VR:wt.doc.WTDocument:")) {
            pattern = "VR:wt.doc.WTDocument:\\d+"; // 正则表达式匹配模式
        } else if (soid.contains("OR:wt.doc.WTDocument:")) {
            pattern = "OR:wt.doc.WTDocument:\\d+"; // 正则表达式匹配模式
        } else if (soid.contains("VR:wt.epm.EPMDocument:")) {
            pattern = "VR:wt.epm.EPMDocument:\\d+"; // 正则表达式匹配模式
        } else if (soid.contains("OR:wt.epm.EPMDocument:")) {
            pattern = "OR:wt.epm.EPMDocument:\\d+"; // 正则表达式匹配模式
        } else if (soid.contains("VR:wt.part.WTPart:")) {
            pattern = "VR:wt.part.WTPart:\\d+"; // 正则表达式匹配模式
        } else if (soid.contains("OR:wt.part.WTPart:")) {
            pattern = "OR:wt.part.WTPart:\\d+"; // 正则表达式匹配模式
        } else {
            return "";
        }
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(soid);
        if (m.find()) {
            return m.group(0);
        }
        return "";
    }


//    public static List<ColorPartChoiceVO> getColorPartChoiceVO(List<WTPart> wtParts) throws WTException {
//        Locale locale = SessionHelper.getLocale();
//        List<ColorPartChoiceVO> colorPartChoiceVOS = new ArrayList<>();
//
//        for (WTPart wtPart : wtParts) {
//            ColorPartChoiceVO colorPartChoiceVO = new ColorPartChoiceVO();
//            colorPartChoiceVO.setPartOid(ToolUtils.getOid(wtPart));//oid
//            colorPartChoiceVO.setPartNumber(wtPart.getNumber()); //编号
//            colorPartChoiceVO.setPartName(wtPart.getName());//名称
//            colorPartChoiceVO.setPartState(wtPart.getLifeCycleState().getDisplay(locale));//状态
//            colorPartChoiceVO.setPartVersion(wtPart.getVersionIdentifier().getValue()+"."+wtPart.getIterationIdentifier().getValue());//版本
//            IBAUtil ibaUtil = new IBAUtil(wtPart);
//            String isColorPart = ibaUtil.getIBAValue(AttributesConstant.IBA_PART_ColorPart);
//            String external_material_group = ibaUtil.getIBAValue(AttributesConstant.IBA_PART_EXTERNAL_MATERIAL_GROUP);
//            //获取产品线---上下文
//            String containerName = wtPart.getContainer().getName();
//            String[] colorArr = PropertiesUtil.getValueByKey(containerName).split(",");
//            if(StringUtils.isNotBlank(isColorPart) && "Y".equals(isColorPart) && StringUtils.isNotBlank(external_material_group)){
//                Option option = OptionSetUtil.getOptionByNumber(external_material_group);
//                List<Choice> choices =  OptionSetUtil.getChoiceByOption(option);
//                List< ChoiceVO> choiceVOList = new ArrayList<>();
//                for (Choice choice : choices) {
//                    ChoiceVO choiceVO = new ChoiceVO();
//                    choiceVO.setChoiceOid(ToolUtils.getOid(choice));
//                    choiceVO.setChoiceNumber(choice.getNumber());
//                    choiceVO.setChoiceName(choice.getName());
//                    choiceVO.setChoiceState(choice.getLifeCycleState().getDisplay(locale));
//                    choiceVO.setChoiceVersion(choice.getVersionIdentifier().getValue() + "." + choice.getIterationIdentifier().getValue());//版本
//                    //会根据配置改动，是否选中
//                    if (Arrays.stream(colorArr)
//                           .anyMatch(element -> choice.getName().equals(element))) {
//                        choiceVO.setSelected(true);
//                    }
//                    choiceVOList.add(choiceVO);
//                }
//                colorPartChoiceVO.setChoiceVOList(choiceVOList);
//            }
//
//        }
//
//        return colorPartChoiceVOS;
//    }

    public static List<ColorPartChoiceVO> getColorPartChoiceVO(List<WTPart> wtParts) throws WTException {
        Locale locale = SessionHelper.getLocale();
        List<ColorPartChoiceVO> colorPartChoiceVOS = new ArrayList<>();

        for (WTPart wtPart : wtParts) {
            ColorPartChoiceVO colorPartChoiceVO = createColorPartChoiceVO(wtPart, locale);
            colorPartChoiceVOS.add(colorPartChoiceVO);
        }

        return colorPartChoiceVOS;
    }

    private static ColorPartChoiceVO createColorPartChoiceVO(WTPart wtPart, Locale locale) throws WTException {
        ColorPartChoiceVO colorPartChoiceVO = new ColorPartChoiceVO();

        // 检查是否为颜色部件
        IBAUtil ibaUtil = new IBAUtil(wtPart);
        //后期改成用星邦常量类
        String isColorPart = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_ColorPart);
        //后期改成用星邦常量类
        String externalMaterialGroup = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_EXTERNAL_MATERIAL_GROUP);//外部物料组


        // 设置部件基本信息
        colorPartChoiceVO.setPartOid(ToolUtils.getOid(wtPart));
        colorPartChoiceVO.setPartNumber(wtPart.getNumber());
        colorPartChoiceVO.setPartName(wtPart.getName());
        colorPartChoiceVO.setPartState(wtPart.getLifeCycleState().getDisplay(locale));
        colorPartChoiceVO.setExternalMaterialGroup(externalMaterialGroup);
        colorPartChoiceVO.setPartVersion(getVersionString(wtPart));

        if (isValidColorPart(isColorPart, externalMaterialGroup)) {
            //从外部物料组的值获取对应的选项
            Option option = OptionSetUtil.getOptionByNumber(externalMaterialGroup);
            //从选项获取所有的选择
            List<Choice> choices = OptionSetUtil.getChoiceByOption(option);
            //选择填入ChoiceVO
            List<ChoiceVO> choiceVOList = createChoiceVOs(choices, wtPart, locale);
            //填入到ColorPartChoiceVO  ---组成完整的数据
            colorPartChoiceVO.setChoiceVOList(choiceVOList);
        } else {
            //传入空集合
            List<ChoiceVO> choiceVOList = new ArrayList<>();
            colorPartChoiceVO.setChoiceVOList(choiceVOList);
        }

        return colorPartChoiceVO;
    }

    /**
     * 部件是否含有颜色选择校验
     *
     * @param isColorPart
     * @param externalMaterialGroup
     * @return
     */
    public static boolean isValidColorPart(String isColorPart, String externalMaterialGroup) {
        return StringUtils.isNotBlank(isColorPart) && "Y".equals(isColorPart) &&
                StringUtils.isNotBlank(externalMaterialGroup);
    }

    private static List<ChoiceVO> createChoiceVOs(List<Choice> choices, WTPart wtPart, Locale locale) throws WTException {
        List<ChoiceVO> choiceVOList = new ArrayList<>();
        IBAUtil ibaUtil = new IBAUtil(wtPart);
        //后期改成用星邦常量类
        String externalMaterialGroup = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_EXTERNAL_MATERIAL_GROUP);//外部物料组
        //获取默认选中的颜色选择
//        Set<String> colorSet = getColorSet(wtPart.getContainer().getName());

        for (Choice choice : choices) {
            ChoiceVO choiceVO = createChoiceVO(choice, locale);

            choiceVO.setExternalMaterialGroup(externalMaterialGroup);//将外部物料组填写給选择，方便创建的时候获取
//            // 检查是否选中
//            if (colorSet.contains(choice.getName())) {
//                choiceVO.setSelected(true);
//            }

            choiceVOList.add(choiceVO);
        }

        return choiceVOList;
    }

    /**
     * 添加选择vo
     *
     * @param choice
     * @param locale
     * @return
     * @throws WTException
     */
    private static ChoiceVO createChoiceVO(Choice choice, Locale locale) throws WTException {
        IBAUtil ibaUtil = new IBAUtil(choice);
        ChoiceVO choiceVO = new ChoiceVO();
        choiceVO.setChoiceOid(ToolUtils.getOid(choice));
        choiceVO.setChoiceNumber(choice.getNumber());
        choiceVO.setChoiceName(choice.getName());
        //后期改成用星邦常量类
        choiceVO.setChoiceColorCode(ibaUtil.getIBAValue(ColorPartConstant.EXTENDEDCOLORED));
        choiceVO.setChoiceState(choice.getLifeCycleState().getDisplay(locale));
        choiceVO.setChoiceVersion(getVersionString(choice));
        return choiceVO;
    }

    /**
     * 获取对应上下文对应产品线的默认颜色
     *
     * @param containerName
     * @return
     */
    private static Set<String> getColorSet(String containerName) {
        //获取配置
        String productLineMP = PropertiesUtil.getValueByKey(ColorPartConstant.AI_PRODUCTLINE_MAPPING);//获取上下文与产品线的映射
        String[] productLineArr = productLineMP.split(",");
        Set<String> colorSet = new HashSet<>();

        for (String productLine : productLineArr) {
            //上下文名称含有产品线名称说明是对应产品线
            if (containerName.contains(productLine)) {
                //用产品线获取对应的颜色名称
                String[] colorArr = PropertiesUtil.getValueByKey(productLine).split(",");
                colorSet.addAll(Arrays.asList(colorArr));
            }
        }

        return colorSet;
    }

    /**
     * 拼接选择版本  如：A.1(Design)
     *
     * @param obj
     * @return
     */
    private static String getVersionString(Choice obj) {

        return obj.getVersionIdentifier().getValue() + "." +
                obj.getIterationIdentifier().getValue();
    }

    /**
     * 拼接部件版本  如：A.1(Design)
     *
     * @param obj
     * @return
     */
    private static String getVersionString(WTPart obj) {

        return obj.getVersionIdentifier().getValue() + "." +
                obj.getIterationIdentifier().getValue();
    }


    public static WTPart setEnName(WTPart colorPart ,Choice choice) throws WTException {
        IBAUtils colorPartUtils = new IBAUtils(colorPart);
        IBAUtils choiceibaUtils = new IBAUtils(choice);
        String choiceEnName = choiceibaUtils.getIBATypeValue(ColorPartConstant.IBA_EN_NAME);//选择英文名称
        String partEnName = colorPartUtils.getIBATypeValue(ColorPartConstant.IBA_EN_NAME);//部件英文名称
        partEnName = partEnName+" "+choiceEnName;
        colorPartUtils.setIBAAnyValue(colorPart,ColorPartConstant.IBA_EN_NAME,partEnName);
        return colorPart;
    }


    public static String checkColorPart(WTObject pbo) throws WTException {
        String errorInf ="";
        ArrayList<WTPart> wtParts = new ArrayList<>();
        if(pbo instanceof WTChangeOrder2){
            WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
            QueryResult qr = ChangeHelper2.service.getChangeablesAfter(ecn);
            wtParts = CommonUtil.getListFromQR(qr, WTPart.class);
            for (WTPart part : wtParts) {
                IBAUtil ibaUtil = new IBAUtil(part);
                String isColorPart = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_ColorPart);
                if(StringUtils.isNotBlank(isColorPart) && "Y".equals(isColorPart)){
                    String version = part.getVersionIdentifier().getValue();
                    if (StringUtils.equals(version, "A") && !StringUtils.equals(LifecycleConstant.STATE_RELEASED,part.getState().toString())) {
                        throw new WTException(part.getNumber()+" 当前为A版未发布颜色件!");
                    }
                }

            }
        }

        return errorInf;
    }




    //获取升级请求中的颜色件
    public static List<WTPart> getColorPartsFromPromotion(PromotionNotice pn) throws WTException {
        QueryResult targets = MaturityHelper.service.getPromotionTargets(pn);
        List<WTPart> allParts = CommonUtil.getListFromQR(targets, WTPart.class);
        List<WTPart> colorPart = new ArrayList<>();
        for (WTPart part : allParts) {
            IBAUtil ibaUtil = new IBAUtil(part);
            String isColorPart = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_ColorPart);
            String externalMaterialGroup = ibaUtil.getIBAValue(ColorPartConstant.IBA_PART_EXTERNAL_MATERIAL_GROUP);//外部物料组
            if (isValidColorPart(isColorPart,externalMaterialGroup)) {
                String version = part.getVersionIdentifier().getValue();
                if (StringUtils.equals(version, "A")){
                    colorPart.add(part);
                }
            }

        }

        return colorPart;
    }

    //颜色件集合  获取选项选项集合
    public static List<ColorPartChoiceVO>  getColorPartChoiceVOs(List<WTPart> wtParts) throws WTException {
        Locale locale = SessionHelper.getLocale();
        List<ColorPartChoiceVO> colorPartChoiceList = new ArrayList<>();
        List<ColorConf> colorDataBySheetName = ExcelColorProcessor.getColorDataBySheetName("默认");
        for (WTPart wtPart : wtParts) {
            ColorPartChoiceVO colorPartChoiceVO = createColorPartChoiceVO(wtPart, locale);

            //获取全部选择
            List<ChoiceVO> choiceVOList = colorPartChoiceVO.getChoiceVOList();
            List<ChoiceVO> newChoice = new ArrayList<>();
            //获取默认模板
            for (ChoiceVO choiceVO : choiceVOList) {
                //如果外部物料组为Y15  默认为
                if ("Y15".equals(choiceVO.getExternalMaterialGroup()) && "RAL9017黑色".equals(choiceVO.getChoiceName())){
                    choiceVO.setSelected(true);
                    newChoice.add(choiceVO);
                    break;
                }
                for (ColorConf colorConf : colorDataBySheetName) {

                    //判断模板是否含有
                    if (colorConf.getChineseDescription().equals(choiceVO.getChoiceName()) && colorConf.isRemark() ) {
                        choiceVO.setSelected(true);
                        newChoice.add(choiceVO);
                        break;
                    }
                }
            }
            //将新的选择集合设置给颜色件选择集合
            colorPartChoiceVO.setChoiceVOList(newChoice);
            colorPartChoiceList.add(colorPartChoiceVO);
        }

        return colorPartChoiceList;
    }




}
