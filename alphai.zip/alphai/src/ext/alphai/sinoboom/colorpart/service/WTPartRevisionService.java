package ext.alphai.sinoboom.colorpart.service;

import ext.alphai.sinoboom.colorpart.constants.ColorPartConstant;
import ext.alphai.sinoboom.colorpart.util.IBAUtil;
import ext.alphai.sinoboom.colorpart.util.ToolUtils;
import org.apache.commons.lang3.StringUtils;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pom.WTConnection;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class WTPartRevisionService {

    public static List<WTPart> getColorParts(WTPart wtPart){
        String number = wtPart.getNumber();
        return getColorPartListByNumber(number);
    }

    /**
     * 用部件编号和编号长度+2查到所有相关部件，然后判断是否为颜色件
     * 且视图为Design  状态为已发布
     * @param partNumber
     * @return
     */
    public static List<WTPart> getColorPartListByNumber(String  partNumber) {
        List<WTPart> result = new ArrayList<WTPart>();
        int length = partNumber.length()+2;

        WTConnection conn = ToolUtils.getWTConnection();
        String sql = "SELECT * FROM WTPARTMASTER WHERE WTPARTNUMBER LIKE ? AND LENGTH(WTPARTNUMBER) = ?";
        // 创建PreparedStatement
        try (PreparedStatement stmt = conn.prepareStatement(sql);){
            stmt.setString(1, partNumber + "%"); // 设置前缀匹配
            stmt.setInt(2, length); // 设置长度匹配

            // 执行查询
            ResultSet rs = stmt.executeQuery();

            // 输出查询结果
            while (rs.next()) {
                long dbIda2a2 = rs.getLong("IDA2A2");
                //查的是master
                String or = "OR:wt.part.WTPartMaster:"+dbIda2a2;
                WTPartMaster partMaster = (WTPartMaster)ToolUtils.getObjectByOid(or);
                QueryResult queryResult = VersionControlHelper.service.allVersionsOf(partMaster);
                if (queryResult.hasMoreElements()) {
                    WTPart o =(WTPart) queryResult.nextElement();
                    //判断是否为颜色件
                    boolean isColorPart = isColorPart(o);
                    IBAUtil ibaUtils = new IBAUtil(o);
                    String primaryColorPartNumber = ibaUtils.getIBAValue(ColorPartConstant.IBA_PART_COLORPARTNUMBER);

                    // 是颜色件且外购物料组不为空且本色件==partNumber
                    if(isColorPart && StringUtils.isNotEmpty(primaryColorPartNumber) && partNumber.equals(primaryColorPartNumber)){
                        String colorState = o.getLifeCycleState().toString();
                        //视图为设计且为已发布
                        if (ColorPartConstant.DESIGN.equals(o.getViewName()) && ColorPartConstant.STATE_RELEASED.equals(colorState)) {
                            result.add(o);

                        }
                    }
                }
            }
            rs.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }


    public static boolean isColorPart(WTPart part)  {
        try {
            IBAUtil ibaUtils = new IBAUtil(part);
            String colorPart = ibaUtils.getIBAValue(ColorPartConstant.IBA_PART_ColorPart);
            String external_material_group = ibaUtils.getIBAValue(ColorPartConstant.IBA_PART_EXTERNAL_MATERIAL_GROUP);
            if(StringUtils.isNotBlank(colorPart) && "Y".equals(colorPart) && StringUtils.isNotBlank(external_material_group)){
                return true;
            }
        }catch (WTException e){
            System.out.println(e.getLocalizedMessage());
        }

        return false;
    }





}
