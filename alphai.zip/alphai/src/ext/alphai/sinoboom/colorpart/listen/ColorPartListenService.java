package ext.alphai.sinoboom.colorpart.listen;
import ext.alphai.sinoboom.colorpart.service.WTPartRevisionService;
import ext.alphai.sinoboom.colorpart.util.PropertiesUtil;
import ext.alphai.sinoboom.colorpart.util.ToolUtils;
import wt.events.KeyedEventListener;
import wt.part.WTPart;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.VersionControlServiceEvent;
import wt.vc.Versioned;

import java.io.Serializable;
import java.util.List;

/**
 * 监听部件创建和检入 将部件位置移动至指定容器和文件夹下
 */
public class ColorPartListenService extends StandardManager implements ColorPartListen , Serializable {

    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = ColorPartListenService.class.getName();
    private KeyedEventListener listener;


    public ColorPartListenService() {
    }

    public static ColorPartListenService newColorPartListenService() throws WTException {
        ColorPartListenService instance = new ColorPartListenService();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new WCListenerEventListener(getConceptualClassname());
        //创建对象
        getManagerService().addEventListener(this.listener, VersionControlServiceEvent.generateEventKey(VersionControlServiceEvent.NEW_VERSION));//修订变更

    }


    class WCListenerEventListener extends ServiceEventListenerAdapter {
        public WCListenerEventListener(String s) {
            super(s);
        }

        @Override
        public void notifyVetoableEvent(Object event) throws Exception {

            if (!(event instanceof VersionControlServiceEvent)) {
                return;
            }

            VersionControlServiceEvent vcsEvent = (VersionControlServiceEvent) event;
            Object eventTarget = vcsEvent.getEventTarget();


            //部件的修订
            if (eventTarget instanceof WTPart ) {
                WTPart wtPart = (WTPart) eventTarget;
                if (VersionControlHelper.service.allVersionsOf(wtPart.getMaster()).size() > 1) {
                    String version = wtPart.getVersionIdentifier().getValue();
                    String wtPartState = wtPart.getLifeCycleState().toString();
                    //视图为Design  状态为已发布
                    List<WTPart> colorParts = WTPartRevisionService.getColorParts(wtPart);
                    //允许修订的版本
//                    String allowState = PropertiesUtil.getValueByKey("ai.allowRevision.state");

                    String RELEASED = "RELEASED";
                    for (WTPart colorPart : colorParts) {

                        //修订指定版本，切记只能修改为新版本不能修改成历史版本
                        String colorPartVersion = colorPart.getVersionIdentifier().getValue();


                        int result = version.compareTo(colorPartVersion);
                        if (result < 0 ){
                            System.out.println("颜色件的版本(" + colorPartVersion + ") 比 本色件的版本(" + version + ") 更新。");
                        }else{
                            System.out.println("颜色件的版本(" + colorPartVersion + ") 比 本色件的版本(" + version + ") 更旧或者相同。");
                            //获取颜色件的状态
                            String colorState = colorPart.getLifeCycleState().toString();
                            //修改为已发布
//                            ToolUtils.changePartState(colorPart, allowState);
                            //若颜色件是已发布，才允许修订,在获取颜色件的方法里过滤了
                            if(RELEASED.equals(colorState)){
                                //修改颜色件版本
                                Versioned versioned = ToolUtils.changeVersion(colorPart, version);
                                //修订后的新版本设置回原状态
                                ToolUtils.changePartState((WTPart) versioned, colorState);
                            }
//                          //修改颜色件版本
//                            Versioned versioned = ToolUtils.changeVersion(colorPart, version);

                        }
                    }

                }
                System.out.println("wtPart 修订 end");
            }
        }
    }




}
