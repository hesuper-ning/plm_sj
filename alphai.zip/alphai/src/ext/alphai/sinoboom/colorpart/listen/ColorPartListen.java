package ext.alphai.sinoboom.colorpart.listen;

public interface ColorPartListen {
}
