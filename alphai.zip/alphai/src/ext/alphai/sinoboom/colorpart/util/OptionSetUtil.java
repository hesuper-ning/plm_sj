package ext.alphai.sinoboom.colorpart.util;

import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.windchill.option.model.Choice;
import com.ptc.windchill.option.model.ChoiceMaster;
import com.ptc.windchill.option.model.Option;
import com.ptc.windchill.option.model.OptionChoiceMasterLink;
import com.ptc.windchill.option.server.ChoiceInfo;
import com.ptc.windchill.option.server.OptionsClientHelper;
import wt.enterprise.RevisionControlled;
import wt.fc.*;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

import java.util.ArrayList;
import java.util.List;

public class OptionSetUtil {
    public static Option getOptionByNumber(String number) throws WTException {
        QuerySpec querySpec = new QuerySpec(Option.class);
        querySpec.appendSearchCondition(new SearchCondition(Option.class, Option.NUMBER, "=", number));
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        LatestConfigSpec cfg = new LatestConfigSpec();
        QueryResult queryResult2 = cfg.process(queryResult);
        if (queryResult2.hasMoreElements()) {
            return (Option) queryResult2.nextElement();
        }
        return null;
    }

    /**
     * 根据选择获取下面所有选项
     * @param option
     * @return
     */
//    public static List<ChoiceInfo> getChoiceByOption(Option option) throws WTException {
//        List<ChoiceInfo> var5 = new ArrayList();
//        ReferenceFactory referencefactory = new ReferenceFactory();
//        WTReference var6 = referencefactory.getReference(ToolUtils.getVrOid(option));
//        WTReference var8 = ObjectReference.newObjectReference(option);
//        var5.addAll(OptionsClientHelper.service.getChoiceInfo(var8,var6,false, (TypeIdentifier)null));
//        return var5;
//    }


    /**
     * 根据选项获取选择
     * @param option
     * @return
     * @throws WTException
     */
    public static List<Choice> getChoiceByOption(Option option) throws WTException {
        List<Choice> links = new ArrayList<>();
        QueryResult qr = PersistenceHelper.manager.navigate(option, OptionChoiceMasterLink.CHOICE_MASTER_ROLE,OptionChoiceMasterLink.class, false);
        while (qr.hasMoreElements()){
            Object o = qr.nextElement();
            if(o instanceof OptionChoiceMasterLink){
                OptionChoiceMasterLink masterLink = (OptionChoiceMasterLink) o;
                ChoiceMaster choiceMaster = masterLink.getChoiceMaster();
                Choice latestObjectByMaster =(Choice) VersionUtil.getLatestObjectByMaster(choiceMaster);
                links.add(latestObjectByMaster);
            }
        }
        return links;
    }
}
