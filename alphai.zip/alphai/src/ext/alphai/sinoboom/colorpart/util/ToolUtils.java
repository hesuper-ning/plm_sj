package ext.alphai.sinoboom.colorpart.util;

import org.apache.commons.lang3.StringUtils;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.fc.*;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.State;
import wt.method.MethodContext;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.pom.WTConnection;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.series.MultilevelSeries;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;
import wt.vc.config.LatestConfigSpec;

import java.beans.PropertyVetoException;

public class ToolUtils {
//    public static final String HDS = "wt.vc.VersionIdentifier";
    public static final String HDS = "wt.series.HarvardSeries";

    public static final String ONE_Str = "1";
    /**
     *
     * 获取对象oid的ID值
     *
     * @param persistable
     * @return
     */
    public static long getOidID(Persistable persistable) {
        return persistable.getPersistInfo().getObjectIdentifier().getId();
    }

    /**
     *
     * 获取完整的OID字符串
     *
     * @param persistable
     * @return
     * @throws WTException
     */
    public static String getOid(Persistable persistable) throws WTException {
        ReferenceFactory refFactory = new ReferenceFactory();
        return refFactory.getReferenceString(
                ObjectReference.newObjectReference((persistable.getPersistInfo().getObjectIdentifier())));
    }

    /**
     *
     * 获取VR完整的字符串
     *
     * @param persistable
     * @return
     * @throws WTException
     */
    public static String getVrOid(Persistable persistable) throws WTException {
        ReferenceFactory refFactory = new ReferenceFactory();
        return refFactory.getReferenceString(persistable);
    }


    /**
     *
     * 通过oid获取对应的Persistable
     *
     * @param oid
     * @return
     * @throws WTException
     */
    public static Persistable getObjectByOid(String oid) throws WTException {
        WTReference wtreference = getReferenceByOid(oid);
        return wtreference.getObject();
    }


    /**
     *
     * 通过oid获取对应的WTReference
     *
     * @param oid
     * @return
     * @throws WTException
     */
    public static WTReference getReferenceByOid(String oid) throws WTException {
        ReferenceFactory referencefactory = new ReferenceFactory();
        WTReference wtreference = referencefactory.getReference(oid);
        return wtreference;
    }

    /**
     * 修改版本
     * @param persistable
     * @param version
     */
    public static Versioned changeVersion(Versioned persistable, String version) throws Exception{
        MultilevelSeries multilevelseries = MultilevelSeries.newMultilevelSeries(HDS, version);
        VersionIdentifier ver = VersionIdentifier.newVersionIdentifier(multilevelseries);
        IterationIdentifier iid = IterationIdentifier.newIterationIdentifier(ONE_Str);
        persistable = (Versioned) VersionControlHelper.service.newVersion(persistable);
        persistable.getMaster().setSeries(HDS);
        VersionControlHelper.setVersionIdentifier(persistable, ver);
        persistable = (Versioned) PersistenceHelper.manager.save(persistable);
        return persistable;
    }



    /**
     * 连接Windchill数据库来运行自定义sql
     *
     * @return WTConnection 数据库连接
     * @throws Exception
     */
    public static WTConnection getWTConnection() {
        WTConnection wtconnection = null;
        try {
            MethodContext methodcontext = MethodContext.getContext();
            wtconnection = (WTConnection) methodcontext.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtconnection;
    }


    /**
     * 修改部件生命周期状态
     *
     * @param part
     * @param state
     * @return String
     * @throws WTPropertyVetoException
     * @throws WTException
     */
    public static String changePartState(WTPart part, String state) throws WTPropertyVetoException, WTException {
        String message = "";
        boolean accessEnforced = SessionServerHelper.manager.setAccessEnforced(false);// 忽略权限
        try {
            SessionServerHelper.manager.setAccessEnforced(false);
            part = (WTPart) LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged) part,
                    State.toState(state));

            PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        } finally {
            SessionServerHelper.manager.setAccessEnforced(accessEnforced);// 恢复权限
        }
        return message;
    }


    /**
     * 根据编号获取对象
     *
     * @param String
     * @param Class
     * @return Object
     */
    @SuppressWarnings("deprecation")
    public static Object getObjByNumber(String number, Class queryClass) {
        try {
            if (StringUtils.isBlank(number)) {
                return null;
            }

            QuerySpec qs = new QuerySpec(queryClass);
            qs.appendWhere(new SearchCondition(queryClass, "master>number", SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                return qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 获取文档主要内容
     * @param document
     * @return
     */
    public static ApplicationData getWTDocPrimary(WTDocument document) {


        ApplicationData appData = new ApplicationData();
        try {

            ContentHolder contentHolder = ContentHelper.service.getContents(document);
            //然后获取主文件
            QueryResult qr = ContentHelper.service.getContentsByRole(contentHolder, ContentRoleType.PRIMARY);
            if (qr != null && qr.hasMoreElements()) {
                appData = (ApplicationData) qr.nextElement();
            }
        } catch (WTException e) {
            e.printStackTrace();
        } catch (PropertyVetoException e) {
            e.printStackTrace();
        }
        return appData;
    }
}
