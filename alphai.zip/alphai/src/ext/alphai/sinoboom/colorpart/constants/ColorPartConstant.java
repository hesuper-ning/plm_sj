package ext.alphai.sinoboom.colorpart.constants;

public class ColorPartConstant {
    /** 是否颜色件 */
    public static final String IBA_PART_ColorPart = "ColorPart";

    // 外部物料组
    public static final String IBA_PART_EXTERNAL_MATERIAL_GROUP = "external_material_group";

    public static final String EXTENDEDCOLORED = "ExtendedColored"; // 扩展颜色
    public static final String AI_PRODUCTLINE_MAPPING = "ai.productLine.mapping"; //配置key  停用，改为导入模板
    public static final String AI_MB = "MB"; //配置key  停用，改为导入模板


    // 颜色代码
    public static final String IBA_EXTENDEDCOLORED = "ExtendedColored";

    // 英文名称
    public static final String IBA_EN_NAME = "EN_NAME";



    //本色件编码
    public static final String IBA_PART_COLORPARTNUMBER="ColorPartNumber";
    //PBOM  sap物料组
    public static final String IBA_PART_SAPMATERIALGROUP="SapMaterialGroup";



    // 已发布
    public static final String STATE_RELEASED = "RELEASED";
    // 废弃
    public static final String STATE_OBSOLESCENCE = "OBSOLETED";

    //试制中
    public static final String STATE_TRIALPRODUCE = "TRIALPRODUCE";


    public static final String DESIGN = "Design";

    // 来源 “外购”的key值
    public static final String SOURCE_BUY = "buy";
}
