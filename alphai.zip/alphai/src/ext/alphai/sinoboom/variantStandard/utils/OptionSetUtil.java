package ext.alphai.sinoboom.variantStandard.utils;

import com.ptc.windchill.option.model.*;
import com.ptc.windchill.option.service.OptionHelper;
import com.ptc.wpcfg.doc.VariantSpec;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.pdmlink.PDMLinkProduct;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 选项集、选项、选择 相关工具
 */
public class OptionSetUtil {


    /**
     * 根据optionNumber 获取OptionMaster
     * @param optionNumber
     * @return
     */
//    public static OptionMaster getOptionByNumber(String optionNumber){
//
//    }



    /**
     * 根据选项集获取OptionSetMemberLink
     * @param optionSet
     * @return
     * @throws WTException
     */
    public static List<OptionSetMemberLink> getOptionSetMemberLinkByOptionSet(OptionSet optionSet) throws WTException {
        List<OptionSetMemberLink> list = new ArrayList<>();
        QueryResult qr = PersistenceHelper.manager.navigate(optionSet, OptionSetMemberLink.CHOICE_MASTER_ROLE,OptionSetMemberLink.class, false);
        while (qr.hasMoreElements()){
            Object o = qr.nextElement();
            if (o instanceof OptionSetMemberLink) {
                list.add((OptionSetMemberLink)o);
            }
        }
        return list;
    }


    /**
     *
     * @param optionSet
     * @return
     * @throws WTException
     */
    public static List<Option> getOptionByOptionSet(OptionSet optionSet) throws WTException {
        List<Option> list = new ArrayList<>();
        QueryResult qr = OptionHelper.service.getOptions(optionSet);
        while(qr.hasMoreElements()) {
            Object o = qr.nextElement();
            if(o instanceof Option){
                list.add((Option)o);
            }
        }
        return list;
    }

    public static List<OptionChoiceMasterLink> getOptionChoiceMasterLinkByOption(Option option) throws WTException {
        List<OptionChoiceMasterLink> links = new ArrayList<>();
        QueryResult qr = PersistenceHelper.manager.navigate(option, OptionChoiceMasterLink.CHOICE_MASTER_ROLE,OptionChoiceMasterLink.class, false);
        while (qr.hasMoreElements()){
            Object o = qr.nextElement();
            if(o instanceof OptionChoiceMasterLink){
                links.add((OptionChoiceMasterLink)o);
            }
        }
        return links;
    }


    public static OptionMaster getOptionChoiceMasterLinkByChoiceMaster(ChoiceMaster choiceMaster) throws WTException {
        OptionMaster optionMaster = null;
        QueryResult qr = PersistenceHelper.manager.navigate(choiceMaster, OptionChoiceMasterLink.OPTION_ROLE,OptionChoiceMasterLink.class, true);
        while (qr.hasMoreElements()){
            Object o = qr.nextElement();
            if(o instanceof Option){
                Option option = (Option) o;
                optionMaster = (OptionMaster)option.getMaster();
            }
        }
        return optionMaster;
    }

    /**
     * 根据选项获取选择Master
     * @param option
     * @return
     * @throws WTException
     */
    public static List<ChoiceMaster> getChoiceMasterByOption(Option option) throws WTException {
        List<ChoiceMaster> links = new ArrayList<>();
        QueryResult qr = PersistenceHelper.manager.navigate(option, OptionChoiceMasterLink.CHOICE_MASTER_ROLE,OptionChoiceMasterLink.class, false);
        while (qr.hasMoreElements()){
            Object o = qr.nextElement();
            if(o instanceof OptionChoiceMasterLink){
                OptionChoiceMasterLink masterLink = (OptionChoiceMasterLink) o;
                links.add(masterLink.getChoiceMaster());
            }
        }
        return links;
    }




    /**
     * 根据选择编号获取最新版本选择对象
     * @param number
     * @return
     */
    public static Choice getLastByChoiceNumber(String number){
        Choice choice = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(Choice.class);
            SearchCondition scnumber = new SearchCondition(Choice.class, Choice.NUMBER, SearchCondition.EQUAL,number);
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(Choice.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                choice = (Choice) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return choice;
    }


    /**
     * 根据编号获取最新版本选项对象
     * @param number
     * @return
     */
    public static Option getLastByOptionNumber(String number){
        Option option = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(Option.class);
            SearchCondition scnumber = new SearchCondition(Option.class, Option.NUMBER, SearchCondition.EQUAL,number);
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(Option.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                option = (Option) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return option;
    }




    /**
     * 创建选项集与选择之间的链接关系
     * @param optionSet 选项集是工作副本
     * @param choiceMaster
     * @return
     */
    public static OptionSetMemberLink createOptionSetChoiceLink(OptionSet optionSet, ChoiceMaster choiceMaster) throws WTException {
        OptionSetMemberLink optionSetMemberLink = OptionSetMemberLink.newOptionSetMemberLink(optionSet, choiceMaster);
        optionSetMemberLink = (OptionSetMemberLink)PersistenceHelper.manager.store(optionSetMemberLink);
        return optionSetMemberLink;
    }


    /**
     * 创建选项与选择之间的链接关系
     * @param option 选项是检出后的工作副本
     * @param choiceMaster
     * @return
     */
    private static OptionChoiceMasterLink createOptionChoiceLink(Option option, ChoiceMaster choiceMaster) throws WTException {
        OptionChoiceMasterLink localOptionChoiceMasterLink = OptionChoiceMasterLink.newOptionChoiceMasterLink(option,choiceMaster);;
        localOptionChoiceMasterLink = (OptionChoiceMasterLink)PersistenceHelper.manager.store(localOptionChoiceMasterLink);
        return localOptionChoiceMasterLink;
    }



    /**
     * 根据产品获取选项对象
     * @param product
     * @return
     */
    public static List<Option> getOptionsFromProduct(PDMLinkProduct product){
        long productIDA2A2 = product.getPersistInfo().getObjectIdentifier().getId();
        List<Option> options = new ArrayList<>();
        QuerySpec querySpec = null;
        try {
            querySpec = new QuerySpec(Option.class);
            querySpec.setAdvancedQueryEnabled(true);
            querySpec.appendWhere(new SearchCondition(Option.class,"containerReference.key.id",SearchCondition.EQUAL, productIDA2A2));
            QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
            while (queryResult.hasMoreElements()){
                Object o = queryResult.nextElement();
                if(o instanceof Option){
                    options.add((Option)o);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return options;
    }


    /**
     * 从产品中获取所有选项
     * @param product
     * @return
     */
    public static List<Choice> getChoicesFromProduct(PDMLinkProduct product){
        long productIDA2A2 = product.getPersistInfo().getObjectIdentifier().getId();
        List<Choice> options = new ArrayList<>();
        QuerySpec querySpec = null;
        try {
            querySpec = new QuerySpec(Choice.class);
            querySpec.setAdvancedQueryEnabled(true);
            querySpec.appendWhere(new SearchCondition(Choice.class,"containerReference.key.id",SearchCondition.EQUAL, productIDA2A2));
            QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
            while (queryResult.hasMoreElements()){
                Object o = queryResult.nextElement();
                if(o instanceof Choice){
                    options.add((Choice)o);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return options;
    }



    /**
     * 根据编号查询part
     *
     * @param String
     * @return OptionSet
     */
    @SuppressWarnings("deprecation")
    public static OptionSet getOptionSetByName(String optionNumber) {
        OptionSet result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(OptionSet.class);
            SearchCondition scnumber = new SearchCondition(OptionSet.class, OptionSet.NAME, SearchCondition.EQUAL,
                    optionNumber);
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(OptionSet.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (OptionSet) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }




    /**
     * 根据编号查询最新版本变型规范
     *
     * @param String
     * @return VariantSpec
     */
    @SuppressWarnings("deprecation")
    public static VariantSpec getVariantSpecByNumber(String variantSpecNumber) {
        VariantSpec result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(OptionSet.class);
            SearchCondition scnumber = new SearchCondition(VariantSpec.class, VariantSpec.NUMBER, SearchCondition.EQUAL,
                    variantSpecNumber);
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(VariantSpec.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (VariantSpec) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
