package ext.alphai.sinoboom.variantStandard;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.filter.ATONavigationFilterHelper;
import com.ptc.windchill.option.model.*;
import com.ptc.wpcfg.deliverables.DeliverableDefinition;
import com.ptc.wpcfg.deliverables.DeliverablesMakerHelper;
import com.ptc.wpcfg.deliverables.VariantSpecDeliverableLink;
import com.ptc.wpcfg.doc.DocHelper;
import com.ptc.wpcfg.doc.VariantSpec;
import com.ptc.wpcfg.doc.VariantSpecMaster;
import ext.alphai.sinoboom.variantStandard.server.VariantSpecServer;
import ext.alphai.sinoboom.variantStandard.utils.CommonUtil;
import ext.alphai.sinoboom.variantStandard.utils.OptionSetUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.*;
import wt.fc.collections.WTCollection;
import wt.filter.NavigationCriteria;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 * ant -f bin/tools.xml class -Dclass.includes=ext/alphai/sinoboom/variantStandard/RemoteTest73.java
 * windchill ext.alphai.sinoboom.variantStandard.RemoteTest73
 */
//import ext.techsoft.logicdata.datautility.EditSAPMaterialNumberDataUtility
public class RemoteTest73 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;


    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", RemoteTest73.class.getName(), null, new Class[]{}, new Object[]{});
    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }
    static ObjectMapper objectMapper = new ObjectMapper();
    static ReferenceFactory rf = new ReferenceFactory();

    public static String process() {
        try {
            String vsOR = "OR:com.ptc.wpcfg.doc.VariantSpec:1927461414";
//            String choiceORTB051601 = "OR:com.ptc.windchill.option.model.Choice:1827420607";
            VariantSpec variantSpec = (VariantSpec) rf.getReference(vsOR).getObject();
//            Choice choiceORTB051601c = (Choice) rf.getReference(choiceORTB051601).getObject();
//            ChoiceMaster choiceMaster = (ChoiceMaster) choiceORTB051601c.getMaster();
//            String choiceOR100 = "OR:com.ptc.windchill.option.model.Choice:1825683174";
//            Choice choiceOR100Choice = (Choice) rf.getReference(choiceOR100).getObject();
//            ChoiceMaster choiceMaster = (ChoiceMaster) choiceOR100Choice.getMaster();
//            int i = addChoice2VariantSpect(variantSpec, choiceMaster);
//            System.out.println("创建ATONavigationFilterChoiceLink条目数："+i);
            // 删除ChoiceLink操作
//            deleteChoice2VariantSpect(variantSpec, choiceMaster);
//            System.out.println();
//            List<String> vsChoiceMasterNumber = VariantSpecServer.getVSChoiceMasterNumber(variantSpec);
//            System.out.println("变型规范:"+variantSpec.getName()+"结构:"+vsChoiceMasterNumber);
//            updateVsOptionSetToLatestVersion(variantSpec);
            String partOR = "OR:wt.part.WTPart:1927462220";
            WTPart part = (WTPart) rf.getReference(partOR).getObject();
            createVariantSpecDeliverableLink(part, variantSpec);
            System.out.println("执行完成");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 根据部件和 变型规范 绑定可交付结果
     * @param part
     * @param variantSpec
     * @return
     */
    public static VariantSpecDeliverableLink createVariantSpecDeliverableLink(WTPart part, VariantSpec variantSpec) throws WTException {
        QueryResult qr = DeliverablesMakerHelper.service.listDefinitions(variantSpec.getGenericizable(), true);
        DeliverableDefinition definition = (DeliverableDefinition) qr.nextElement();
        DeliverablesMakerHelper.service.addDeliverable(variantSpec, part, true, definition, definition.getData().getTag(), 0);
        return null;
    }



    /**
     * 修改变型规范的选项集为最新版本
     * @param variantSpec
     */
    public static void updateVsOptionSetToLatestVersion(VariantSpec variantSpec) throws WTException, WTPropertyVetoException {
        OptionSet optionSet = DocHelper.service.getOptionSet(variantSpec);
//        OptionSetMaster optionSetMaster = (OptionSetMaster) optionSet.getMaster();
        OptionSet optionSetByNameLatestVersion = OptionSetUtil.getOptionSetByName(optionSet.getName());
        // 如果变型规范的版本绑定的不是最新版本就修改
        if(!optionSet.equals(optionSetByNameLatestVersion)){
            System.out.println("变型规范指向的不是最新版本选项集");
            ATONavigationFilter atoNavigationFilter = DocHelper.service.getATONavigationFilter(variantSpec);
            atoNavigationFilter.setOptionSet(optionSetByNameLatestVersion);
            PersistenceServerHelper.manager.update(atoNavigationFilter);
            System.out.println("修改选项集版本成功");
        }else {
            System.out.println("变型规范指向的是最新版本选项集");
        }
    }
    /**
     * 删除变型规范相关的选择
     * @param variantSpec
     * @param choiceMaster
     * @return
     */
    public static int deleteChoice2VariantSpect(VariantSpec variantSpec, ChoiceMaster choiceMaster) throws WTException {
        int result = 0;
        List<ATONavigationFilterChoiceLink> choiceLinksByVariantSpec = getChoiceLinksByVariantSpec(variantSpec);
        for (ATONavigationFilterChoiceLink atoNavigationFilterChoiceLink : choiceLinksByVariantSpec) {
            ChoiceMaster choiceMasterFromLink = atoNavigationFilterChoiceLink.getChoiceMaster();
            if(choiceMasterFromLink.equals(choiceMaster)){
                PersistenceHelper.manager.delete(atoNavigationFilterChoiceLink);
            }
        }
        return  result;
    }


    public static int addChoice2VariantSpect(VariantSpec variantSpec, ChoiceMaster choiceMaster) throws WTException, WTPropertyVetoException, SQLException {
        int result = 0;
        NavigationCriteria navigationCriteria = (NavigationCriteria)variantSpec.getNavigationCriteriaReference().getObject();
        Collection<ATONavigationFilter> filtersByClass = navigationCriteria.getFiltersByClass(ATONavigationFilter.class);

        ATONavigationFilter atoNavigationFilter = DocHelper.service.getATONavigationFilter(variantSpec);
//        for (ATONavigationFilter byClass : filtersByClass) {
            System.out.println("ATONavigationFilter "+ object2Oid(atoNavigationFilter));
//            String ATONavigationFilterIDA2A2 = String.valueOf(atoNavigationFilter.getPersistInfo().getObjectIdentifier().getId());
//            String querySql = "SELECT SELECTIONORDER FROM ATONAVIGATIONFILTERCHOICELINK WHERE IDA3A5=? ORDER BY SELECTIONORDER DESC";
//            ResultSet resultSet = CommonUtil.excuteSelect(querySql, ATONavigationFilterIDA2A2);
//            int choiceIndex=0;
//            if (resultSet != null) {
//                if (resultSet.next()) {
//                    int selectionorder = resultSet.getInt("SELECTIONORDER");
//                    choiceIndex =selectionorder+1;
//                }else {
//                    choiceIndex++;
//                }
//            }else {
//                choiceIndex++;
//            }

            List<ATONavigationFilterChoiceLink> choiceLinksByVariantSpec = getChoiceLinksByVariantSpec(variantSpec);
            int nextATONavigationFilterChoiceLinkIndex = getNextATONavigationFilterChoiceLinkIndex(choiceLinksByVariantSpec);
            ATONavigationFilterChoiceLink atoNavigationFilterChoiceLink = ATONavigationFilterChoiceLink.newATONavigationFilterChoiceLink(atoNavigationFilter, choiceMaster);
            atoNavigationFilterChoiceLink.setSelectionOrder(nextATONavigationFilterChoiceLinkIndex);
            atoNavigationFilterChoiceLink = (ATONavigationFilterChoiceLink)PersistenceHelper.manager.save(atoNavigationFilterChoiceLink);
            if(atoNavigationFilterChoiceLink != null) {
                result++;
            }
//        }
        return result;
    }
    /**
     * 获取对象的oid
     *
     * @param WTObject
     * @return String
     */
    public static String object2Oid(WTObject obj) {
        String className = obj.getClass().getName();
        String oid = String.valueOf(obj.getPersistInfo().getObjectIdentifier().getId());
        return "OR:" + className + ":" + oid;
    }


    /**
     * 根据VariantSpec 获取所有ATONavigationFilterChoiceLink
     * @param variantSpec
     * @return
     */
    public static List<ATONavigationFilterChoiceLink> getChoiceLinksByVariantSpec(VariantSpec variantSpec) throws WTException {
        List<ATONavigationFilterChoiceLink> list =new ArrayList<>();
        ATONavigationFilter atoNavigationFilter = DocHelper.service.getATONavigationFilter(variantSpec);
//        System.out.println("ATONavigationFilter:"+atoNavigationFilter.getPersistInfo().getObjectIdentifier().getId());
        WTCollection choiceLinks = ATONavigationFilterHelper.service.getChoiceLinks(atoNavigationFilter);
        for (Object choiceLink : choiceLinks) {
//            System.out.println("choiceLink:"+choiceLink);
//            System.out.println("choiceLink:"+choiceLink.getClass().getName());
            if(choiceLink instanceof ObjectReference){
                ObjectReference objectReference = (ObjectReference) choiceLink;
                list.add((ATONavigationFilterChoiceLink)objectReference.getObject());
            }
        }
        return list;
    }

    /**
     * 返回递增的list 集合中atoNavigationFilterChoiceLink.getSelectionOrder(); 的加一值
     * @param list
     * @return
     */
    public static int getNextATONavigationFilterChoiceLinkIndex(List<ATONavigationFilterChoiceLink> list) {
        if (list == null || list.isEmpty()) {
            return 1;
        }

        return list.stream()
                .map(ATONavigationFilterChoiceLink::getSelectionOrder)
                .filter(Objects::nonNull)
                .mapToInt(Integer::intValue)
                .max()
                .orElse(0) + 1;
    }
}
