package ext.alphai.sinoboom.variantStandard.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.option.variantspec.form.CreateVariantSpecFormProcessor;
import com.ptc.wpcfg.doc.VariantSpec;
import ext.alphai.sinoboom.variantStandard.utils.IBAUtil;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.List;

/**
 * 客制化创建变更选项
 */
public class CustomCreVariantSpecProcessor extends CreateVariantSpecFormProcessor {
    // 产品外销类型
    public static final String Product_Model = "ProductModel";


    @Override
    public FormResult postTransactionProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("list.get(0).getObject():"+list.get(0).getObject());
        VariantSpec variantSpec = (!list.isEmpty())
                ? (list.get(0).getObject() instanceof VariantSpec ? (VariantSpec) list.get(0).getObject() : null)
                : null;
        if(variantSpec != null){
            System.out.println("创建变型规范process");
            IBAUtil ibaUtil = new IBAUtil();
            Persistable object = variantSpec.getGenericizableReference().getObject();
            System.out.println(variantSpec.getName()+" 变型规范超级BOM："+object);
            if(object instanceof WTPart){
                WTPart part = (WTPart) object;
                IBAUtil partIBA = new IBAUtil(part);
                String partProductModel = partIBA.getIBAValue(Product_Model);
                System.out.println("变型规范超级BOM 产品外销型号值："+partProductModel);
                try {
                    ibaUtil.setIBAAttribute4AllType(variantSpec, Product_Model, partProductModel);
                    System.out.println("设置完成");
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new WTException(e.getMessage());
                }
            }
        }
        return super.postProcess(nmCommandBean, list);
    }
}
