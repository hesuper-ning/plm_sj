package ext.alphai.sinoboom.variantStandard.domain.vsVo;
import java.util.Objects;

/**
 * 变型规范变更项子项
 */
public class VariantSpecChangeItem {
    private String type;
    private String choiceMasterNumber;
    private String choiceMasterName;
    private String choiceMasterOR;
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VariantSpecChangeItem that = (VariantSpecChangeItem) o;
        return Objects.equals(type, that.type) && Objects.equals(choiceMasterOR, that.choiceMasterOR);
    }


    @Override
    public int hashCode() {
        return Objects.hash(type, choiceMasterOR);
    }
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getChoiceMasterNumber() {
        return choiceMasterNumber;
    }

    public void setChoiceMasterNumber(String choiceMasterNumber) {
        this.choiceMasterNumber = choiceMasterNumber;
    }

    public String getChoiceMasterName() {
        return choiceMasterName;
    }

    public void setChoiceMasterName(String choiceMasterName) {
        this.choiceMasterName = choiceMasterName;
    }

    public String getChoiceMasterOR() {
        return choiceMasterOR;
    }

    public void setChoiceMasterOR(String choiceMasterOR) {
        this.choiceMasterOR = choiceMasterOR;
    }

    public VariantSpecChangeItem() {
    }

    public VariantSpecChangeItem(String type, String choiceMasterNumber, String choiceMasterName, String choiceMasterOR) {
        this.type = type;
        this.choiceMasterNumber = choiceMasterNumber;
        this.choiceMasterName = choiceMasterName;
        this.choiceMasterOR = choiceMasterOR;
    }
}
