package ext.alphai.sinoboom.variantStandard.domain.vsVo;

import java.util.Set;

/**
 * 新增修改变型规范选择项详细内容
 */
public class UploadVariantSpecItemVo {
    private String variantSpecMasterOR;
    private Set<UploadVariantSpecChoiceItemVo> vos;

    public String getVariantSpecMasterOR() {
        return variantSpecMasterOR;
    }

    public void setVariantSpecMasterOR(String variantSpecMasterOR) {
        this.variantSpecMasterOR = variantSpecMasterOR;
    }

    public Set<UploadVariantSpecChoiceItemVo> getVos() {
        return vos;
    }

    public void setVos(Set<UploadVariantSpecChoiceItemVo> vos) {
        this.vos = vos;
    }
}
