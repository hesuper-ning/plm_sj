package ext.alphai.sinoboom.variantStandard.domain;

/**
 * 选项集的选项结构
 */
public class OptionSetChoice {
    private String choiceName;
    private String choiceNumber;
    private String choiceMasterOR;
    private int level;
    // 原本结构里有的为true
    private boolean source;

    // 是否将其删除 null或空字符都是保留   delete是删除
    private String willDelete;

    public String getWillDelete() {
        return willDelete;
    }

    public void setWillDelete(String willDelete) {
        this.willDelete = willDelete;
    }

    public boolean isSource() {
        return source;
    }

    public void setSource(boolean source) {
        this.source = source;
    }
    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getChoiceName() {
        return choiceName;
    }

    public void setChoiceName(String choiceName) {
        this.choiceName = choiceName;
    }

    public String getChoiceNumber() {
        return choiceNumber;
    }

    public void setChoiceNumber(String choiceNumber) {
        this.choiceNumber = choiceNumber;
    }

    public String getChoiceMasterOR() {
        return choiceMasterOR;
    }

    public void setChoiceMasterOR(String choiceMasterOR) {
        this.choiceMasterOR = choiceMasterOR;
    }
}
