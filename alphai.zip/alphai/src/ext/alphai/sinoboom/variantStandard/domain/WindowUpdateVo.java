package ext.alphai.sinoboom.variantStandard.domain;

import ext.alphai.sinoboom.variantStandard.excel.ChangeItemDomainDB;

import java.util.List;

/**
 *
 */
public class WindowUpdateVo {
    private String ecnOR;
    private String ecnNumber;
    private List<ChangeItemDomainDB> vos;

    public String getEcnOR() {
        return ecnOR;
    }

    public void setEcnOR(String ecnOR) {
        this.ecnOR = ecnOR;
    }

    public String getEcnNumber() {
        return ecnNumber;
    }

    public void setEcnNumber(String ecnNumber) {
        this.ecnNumber = ecnNumber;
    }

    public List<ChangeItemDomainDB> getVos() {
        return vos;
    }

    public void setVos(List<ChangeItemDomainDB> vos) {
        this.vos = vos;
    }
}
