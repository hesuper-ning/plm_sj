package ext.alphai.sinoboom.variantStandard.domain;

import java.util.List;

/**
 * 选项集展示数据
 */
public class OptionSetVo {
    private String optionSetName;
    private String optionSetOR;
    private String optionSetBigVersion;
    private String optionSetSmallVersion;
    private int level;

    List<OptionSetOption> vos;

    public String getOptionSetName() {
        return optionSetName;
    }

    public void setOptionSetName(String optionSetName) {
        this.optionSetName = optionSetName;
    }

    public String getOptionSetOR() {
        return optionSetOR;
    }

    public void setOptionSetOR(String optionSetOR) {
        this.optionSetOR = optionSetOR;
    }

    public String getOptionSetBigVersion() {
        return optionSetBigVersion;
    }

    public void setOptionSetBigVersion(String optionSetBigVersion) {
        this.optionSetBigVersion = optionSetBigVersion;
    }

    public String getOptionSetSmallVersion() {
        return optionSetSmallVersion;
    }

    public void setOptionSetSmallVersion(String optionSetSmallVersion) {
        this.optionSetSmallVersion = optionSetSmallVersion;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public List<OptionSetOption> getVos() {
        return vos;
    }

    public void setVos(List<OptionSetOption> vos) {
        this.vos = vos;
    }
}
