package ext.alphai.sinoboom.variantStandard.domain;

/**
 * 根据名称搜索选择的返回值
 */
public class SelectChoiceByName {
    private String productName;
    private String productOR;
    private String optionName;
    private String optionNumber;
    private String optionOR;
    private String choiceName;
    private String choiceNumber;
    private String choiceMasterOR;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductOR() {
        return productOR;
    }

    public void setProductOR(String productOR) {
        this.productOR = productOR;
    }

    public String getOptionName() {
        return optionName;
    }

    public void setOptionName(String optionName) {
        this.optionName = optionName;
    }

    public String getOptionNumber() {
        return optionNumber;
    }

    public void setOptionNumber(String optionNumber) {
        this.optionNumber = optionNumber;
    }

    public String getOptionOR() {
        return optionOR;
    }

    public void setOptionOR(String optionOR) {
        this.optionOR = optionOR;
    }

    public String getChoiceName() {
        return choiceName;
    }

    public void setChoiceName(String choiceName) {
        this.choiceName = choiceName;
    }

    public String getChoiceNumber() {
        return choiceNumber;
    }

    public void setChoiceNumber(String choiceNumber) {
        this.choiceNumber = choiceNumber;
    }

    public String getChoiceMasterOR() {
        return choiceMasterOR;
    }

    public void setChoiceMasterOR(String choiceMasterOR) {
        this.choiceMasterOR = choiceMasterOR;
    }
}
