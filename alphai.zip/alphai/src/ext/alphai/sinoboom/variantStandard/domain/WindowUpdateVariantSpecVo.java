package ext.alphai.sinoboom.variantStandard.domain;

import ext.alphai.sinoboom.variantStandard.domain.vsVo.ChangeVsItemDomainDB;
import ext.alphai.sinoboom.variantStandard.excel.ChangeItemDomainDB;

import java.util.List;

/**
 *
 */
public class WindowUpdateVariantSpecVo {
    private String ecnOR;
    private String ecnNumber;
    private List<ChangeVsItemDomainDB> vos;

    public String getEcnOR() {
        return ecnOR;
    }

    public void setEcnOR(String ecnOR) {
        this.ecnOR = ecnOR;
    }

    public String getEcnNumber() {
        return ecnNumber;
    }

    public void setEcnNumber(String ecnNumber) {
        this.ecnNumber = ecnNumber;
    }

    public List<ChangeVsItemDomainDB> getVos() {
        return vos;
    }

    public void setVos(List<ChangeVsItemDomainDB> vos) {
        this.vos = vos;
    }
}
