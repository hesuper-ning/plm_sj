package ext.alphai.sinoboom.variantStandard.domain.vsVo;

import java.util.Set;

/**
 * 添加或者修改变型规范修改项
 */
public class UploadVariantSpecVo {
    private String ECNOR;
    Set<UploadVariantSpecItemVo> variantSpecItemVos;

    public String getECNOR() {
        return ECNOR;
    }

    public void setECNOR(String ECNOR) {
        this.ECNOR = ECNOR;
    }

    public Set<UploadVariantSpecItemVo> getVariantSpecItemVos() {
        return variantSpecItemVos;
    }

    public void setVariantSpecItemVos(Set<UploadVariantSpecItemVo> variantSpecItemVos) {
        this.variantSpecItemVos = variantSpecItemVos;
    }
}
