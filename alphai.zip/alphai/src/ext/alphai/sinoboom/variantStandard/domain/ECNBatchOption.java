package ext.alphai.sinoboom.variantStandard.domain;

/**
 *
 */
public class ECNBatchOption {
    private String ECNNUMBER;
    private String ECNOR;
    private String CHANGECONTENTJSON;
    private String UPDATETIME;


    public String getECNNUMBER() {
        return ECNNUMBER;
    }

    public void setECNNUMBER(String ECNNUMBER) {
        this.ECNNUMBER = ECNNUMBER;
    }

    public String getECNOR() {
        return ECNOR;
    }

    public void setECNOR(String ECNOR) {
        this.ECNOR = ECNOR;
    }

    public String getCHANGECONTENTJSON() {
        return CHANGECONTENTJSON;
    }

    public void setCHANGECONTENTJSON(String CHANGECONTENTJSON) {
        this.CHANGECONTENTJSON = CHANGECONTENTJSON;
    }

    public String getUPDATETIME() {
        return UPDATETIME;
    }

    public void setUPDATETIME(String UPDATETIME) {
        this.UPDATETIME = UPDATETIME;
    }
}
