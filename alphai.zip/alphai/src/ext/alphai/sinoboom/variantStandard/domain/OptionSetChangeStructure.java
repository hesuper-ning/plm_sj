package ext.alphai.sinoboom.variantStandard.domain;

import java.util.List;

/**
 * 页面展示
 */
public class OptionSetChangeStructure {

    private String ECNOR;
    private String ECNName;
    private String ECNNumber;

    List<OptionSetVo> optionSetList;

    public String getECNOR() {
        return ECNOR;
    }

    public void setECNOR(String ECNOR) {
        this.ECNOR = ECNOR;
    }

    public String getECNName() {
        return ECNName;
    }

    public void setECNName(String ECNName) {
        this.ECNName = ECNName;
    }

    public String getECNNumber() {
        return ECNNumber;
    }

    public void setECNNumber(String ECNNumber) {
        this.ECNNumber = ECNNumber;
    }

    public List<OptionSetVo> getOptionSetList() {
        return optionSetList;
    }

    public void setOptionSetList(List<OptionSetVo> optionSetList) {
        this.optionSetList = optionSetList;
    }
}
