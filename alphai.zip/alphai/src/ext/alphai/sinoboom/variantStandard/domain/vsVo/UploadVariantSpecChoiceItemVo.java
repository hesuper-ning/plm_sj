package ext.alphai.sinoboom.variantStandard.domain.vsVo;

import java.util.Objects;

/**
 * 变型规范修改选择子项
 */
public class UploadVariantSpecChoiceItemVo {
    private String type;
    private String choiceMasterNumber;
    private String errorMessage;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getChoiceMasterNumber() {
        return choiceMasterNumber;
    }

    public void setChoiceMasterNumber(String choiceMasterNumber) {
        this.choiceMasterNumber = choiceMasterNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UploadVariantSpecChoiceItemVo that = (UploadVariantSpecChoiceItemVo) o;
        return Objects.equals(type, that.type) && Objects.equals(choiceMasterNumber, that.choiceMasterNumber);
    }


    @Override
    public int hashCode() {
        return Objects.hash(type, choiceMasterNumber);
    }
}
