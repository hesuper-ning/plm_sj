package ext.alphai.sinoboom.variantStandard.domain;

import java.util.Objects;

/**
 * 变更校验项 子类型
 */
public class SelectChangeItemSonReq {
    private String type;
    private String optionMasterNumber;
    private String choiceMasterNumber;
    public String getType() {
        return type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SelectChangeItemSonReq that = (SelectChangeItemSonReq) o;
        return Objects.equals(type, that.type) && Objects.equals(optionMasterNumber, that.optionMasterNumber) && Objects.equals(choiceMasterNumber, that.choiceMasterNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, optionMasterNumber, choiceMasterNumber);
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOptionMasterNumber() {
        return optionMasterNumber;
    }

    public void setOptionMasterNumber(String optionMasterNumber) {
        this.optionMasterNumber = optionMasterNumber;
    }

    public String getChoiceMasterNumber() {
        return choiceMasterNumber;
    }

    public void setChoiceMasterNumber(String choiceMasterNumber) {
        this.choiceMasterNumber = choiceMasterNumber;
    }
}
