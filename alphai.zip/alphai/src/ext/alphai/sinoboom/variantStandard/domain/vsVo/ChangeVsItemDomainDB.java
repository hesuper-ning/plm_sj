package ext.alphai.sinoboom.variantStandard.domain.vsVo;

import java.util.Set;

/**
 * 变型规范修改 数据库JSON对象
 */
public class ChangeVsItemDomainDB {
    private String variantSpecName;
    private String variantSpecNumber;
    private String variantSpecMasterOR;

    private Set<VariantSpecChangeItem> vos;

    public String getVariantSpecName() {
        return variantSpecName;
    }

    public void setVariantSpecName(String variantSpecName) {
        this.variantSpecName = variantSpecName;
    }

    public String getVariantSpecNumber() {
        return variantSpecNumber;
    }

    public void setVariantSpecNumber(String variantSpecNumber) {
        this.variantSpecNumber = variantSpecNumber;
    }

    public String getVariantSpecMasterOR() {
        return variantSpecMasterOR;
    }

    public void setVariantSpecMasterOR(String variantSpecMasterOR) {
        this.variantSpecMasterOR = variantSpecMasterOR;
    }

    public Set<VariantSpecChangeItem> getVos() {
        return vos;
    }

    public void setVos(Set<VariantSpecChangeItem> vos) {
        this.vos = vos;
    }

    public ChangeVsItemDomainDB() {
    }

    public ChangeVsItemDomainDB(String variantSpecName, String variantSpecNumber, String variantSpecMasterOR, Set<VariantSpecChangeItem> vos) {
        this.variantSpecName = variantSpecName;
        this.variantSpecNumber = variantSpecNumber;
        this.variantSpecMasterOR = variantSpecMasterOR;
        this.vos = vos;
    }
}
