package ext.alphai.sinoboom.variantStandard.domain;

import java.util.Set;

public class SelectChangeOptionSetVo {
    private String optionSetName;
    private Set<SelectChangeItemSonReq> child;

    public String getOptionSetName() {
        return optionSetName;
    }

    public void setOptionSetName(String optionSetName) {
        this.optionSetName = optionSetName;
    }

    public Set<SelectChangeItemSonReq> getChild() {
        return child;
    }

    public void setChild(Set<SelectChangeItemSonReq> child) {
        this.child = child;
    }
}
