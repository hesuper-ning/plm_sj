package ext.alphai.sinoboom.variantStandard.domain;

import java.util.List;

/**
 * 选项集与选项
 */
public class OptionSetOption {
    private String optionName;
    private String optionNumber;
    private String optionOR;
    private int level;
    List<OptionSetChoice> vos;
    // 原本结构里有的为true
    private boolean source;

    public boolean isSource() {
        return source;
    }

    public void setSource(boolean source) {
        this.source = source;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getOptionName() {
        return optionName;
    }

    public void setOptionName(String optionName) {
        this.optionName = optionName;
    }

    public String getOptionNumber() {
        return optionNumber;
    }

    public void setOptionNumber(String optionNumber) {
        this.optionNumber = optionNumber;
    }

    public String getOptionOR() {
        return optionOR;
    }

    public void setOptionOR(String optionOR) {
        this.optionOR = optionOR;
    }

    public List<OptionSetChoice> getVos() {
        return vos;
    }

    public void setVos(List<OptionSetChoice> vos) {
        this.vos = vos;
    }
}
