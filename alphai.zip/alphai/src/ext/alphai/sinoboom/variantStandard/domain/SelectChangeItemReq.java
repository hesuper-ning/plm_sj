package ext.alphai.sinoboom.variantStandard.domain;

import java.util.List;
import java.util.Set;

/**
 * 前端填写选项集变更项
 */
public class SelectChangeItemReq {
    private String ECNOR;
    private List<SelectChangeOptionSetVo> changeOptionSetVos;

    public String getECNOR() {
        return ECNOR;
    }

    public void setECNOR(String ECNOR) {
        this.ECNOR = ECNOR;
    }

    public List<SelectChangeOptionSetVo> getChangeOptionSetVos() {
        return changeOptionSetVos;
    }

    public void setChangeOptionSetVos(List<SelectChangeOptionSetVo> changeOptionSetVos) {
        this.changeOptionSetVos = changeOptionSetVos;
    }
}
