package ext.alphai.sinoboom.variantStandard.domain;

import org.springframework.web.multipart.MultipartFile;

public class UploadExcelVo {
    private String ECNNumber;
    private String ECNOR;
    private MultipartFile file;

    public String getECNNumber() {
        return ECNNumber;
    }

    public void setECNNumber(String ECNNumber) {
        this.ECNNumber = ECNNumber;
    }

    public String getECNOR() {
        return ECNOR;
    }

    public void setECNOR(String ECNOR) {
        this.ECNOR = ECNOR;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }
}
