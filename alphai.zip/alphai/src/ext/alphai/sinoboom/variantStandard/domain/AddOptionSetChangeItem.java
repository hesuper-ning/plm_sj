package ext.alphai.sinoboom.variantStandard.domain;

import java.util.List;

/**
 * 添加选项集添加变更项
 */
public class AddOptionSetChangeItem {
    private String optionSetOR;
    private List<String> choiceMasterORs;

    public String getOptionSetOR() {
        return optionSetOR;
    }

    public void setOptionSetOR(String optionSetOR) {
        this.optionSetOR = optionSetOR;
    }

    public List<String> getChoiceMasterORs() {
        return choiceMasterORs;
    }

    public void setChoiceMasterORs(List<String> choiceMasterORs) {
        this.choiceMasterORs = choiceMasterORs;
    }
}
