package ext.alphai.sinoboom.variantStandard;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.wpcfg.doc.VariantSpec;
import com.ptc.wpcfg.doc.VariantSpecMaster;
import ext.alphai.sinoboom.variantStandard.domain.ResponseVo;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.UploadVariantSpecChoiceItemVo;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.UploadVariantSpecItemVo;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.UploadVariantSpecVo;
import ext.alphai.sinoboom.variantStandard.server.VariantSpecServer;
import ext.alphai.sinoboom.variantStandard.work.ChangeVariantSpecWork;
import wt.change2.WTChangeOrder2;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.util.WTException;
import wt.util.WTRuntimeException;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Set;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 * ant -f bin/tools.xml class -Dclass.includes=ext/alphai/sinoboom/variantStandard/RemoteTest110.java
 * windchill ext.alphai.sinoboom.variantStandard.RemoteTest110
 */
//import ext.techsoft.logicdata.datautility.EditSAPMaterialNumberDataUtility
public class RemoteTest110 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;


    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", RemoteTest110.class.getName(), null, new Class[]{}, new Object[]{});
    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }
    static ObjectMapper objectMapper = new ObjectMapper();
    static ReferenceFactory rf = new ReferenceFactory();
    /**
     * 测试导入excel
     * @return
     */
    public static String process() {
        try {
            String ecnVR = "VR:wt.change2.WTChangeOrder2:1916798837";
            WTChangeOrder2 changeOrder2 = (WTChangeOrder2) rf.getReference(ecnVR).getObject();
            String ecnOR = object2Oid(changeOrder2);
//            String OR10430 = "OR:com.ptc.wpcfg.doc.VariantSpec:1916798644";
//            VariantSpec OR10430VS = (VariantSpec) rf.getReference(OR10430).getObject();
//            VariantSpecMaster OR10430VSMaster = (VariantSpecMaster) OR10430VS.getMaster();
//            String OR10463 = "OR:com.ptc.wpcfg.doc.VariantSpec:1916798643";
//            VariantSpec OR10463VS = (VariantSpec) rf.getReference(OR10463).getObject();
//            VariantSpecMaster OR10463VSMaster = (VariantSpecMaster) OR10463VS.getMaster();
//            String OR10462 = "OR:com.ptc.wpcfg.doc.VariantSpec:1916798642";
//            VariantSpec OR10462VS = (VariantSpec) rf.getReference(OR10462).getObject();
//            VariantSpecMaster OR10462VSMaster = (VariantSpecMaster) OR10462VS.getMaster();
            String respJson = ChangeVariantSpecWork.processChangeVariantSpec(changeOrder2);

            System.out.println("执行结果:"+respJson);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 获取对象的oid
     *
     * @param WTObject
     * @return String
     */
    public static String object2Oid(WTObject obj) {
        String className = obj.getClass().getName();
        String oid = String.valueOf(obj.getPersistInfo().getObjectIdentifier().getId());
        return "OR:" + className + ":" + oid;
    }
}
