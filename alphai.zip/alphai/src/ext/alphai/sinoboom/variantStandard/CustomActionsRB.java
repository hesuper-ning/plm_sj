package ext.alphai.sinoboom.variantStandard;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.sinoboom.variantStandard.CustomActionsRB")
public class CustomActionsRB extends WTListResourceBundle {

    @RBEntry("Batch modification of option sets")
    public static final String PRIVATE_CONSTANT_01 ="variantStandard.batchChange.description";

    @RBEntry("Batch modification of option sets")
    public static final String PRIVATE_CONSTANT_001 ="variantStandard.batchChange.tooltip";
    @RBEntry("Batch modification of variant spec")
    public static final String PRIVATE_CONSTANT_02 ="variantStandard.variantSpecBatchChange.description";

    @RBEntry("Batch modification of variant spec")
    public static final String PRIVATE_CONSTANT_002 ="variantStandard.variantSpecBatchChange.tooltip";
}
