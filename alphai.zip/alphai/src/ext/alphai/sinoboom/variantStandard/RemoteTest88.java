package ext.alphai.sinoboom.variantStandard;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.model.*;
import com.ptc.wpcfg.deliverables.VariantSpecDeliverableLink;
import com.ptc.wpcfg.doc.DocHelper;
import com.ptc.wpcfg.doc.VariantSpec;
import com.ptc.wpcfg.doc.VariantSpecMaster;
import ext.alphai.sinoboom.variantStandard.domain.ResponseVo;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.UploadVariantSpecChoiceItemVo;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.UploadVariantSpecItemVo;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.UploadVariantSpecVo;
import ext.alphai.sinoboom.variantStandard.server.VariantSpecServer;
import wt.change2.WTChangeOrder2;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.filter.NavigationCriteria;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 * ant -f bin/tools.xml class -Dclass.includes=ext/alphai/sinoboom/variantStandard/RemoteTest82.java
 * windchill ext.alphai.sinoboom.variantStandard.RemoteTest82
 */
//import ext.techsoft.logicdata.datautility.EditSAPMaterialNumberDataUtility
public class RemoteTest88 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;


    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", RemoteTest88.class.getName(), null, new Class[]{}, new Object[]{});
    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }
    static ObjectMapper objectMapper = new ObjectMapper();
    static ReferenceFactory rf = new ReferenceFactory();
    /**
     * 测试导入excel
     * @return
     */
    public static String process() {
        try {
            String ecnVR = "VR:wt.change2.WTChangeOrder2:1154227";
            WTChangeOrder2 changeOrder2 = (WTChangeOrder2) rf.getReference(ecnVR).getObject();
            String ecnOR = object2Oid(changeOrder2);
            String OR10430 = "OR:com.ptc.wpcfg.doc.VariantSpec:1136396";
            VariantSpec OR10430VS = (VariantSpec) rf.getReference(OR10430).getObject();
            VariantSpecMaster OR10430VSMaster = (VariantSpecMaster) OR10430VS.getMaster();
//            String OR10463 = "OR:com.ptc.wpcfg.doc.VariantSpec:1916798643";
//            VariantSpec OR10463VS = (VariantSpec) rf.getReference(OR10463).getObject();
//            VariantSpecMaster OR10463VSMaster = (VariantSpecMaster) OR10463VS.getMaster();
//            String OR10462 = "OR:com.ptc.wpcfg.doc.VariantSpec:1916798642";
//            VariantSpec OR10462VS = (VariantSpec) rf.getReference(OR10462).getObject();
//            VariantSpecMaster OR10462VSMaster = (VariantSpecMaster) OR10462VS.getMaster();

            UploadVariantSpecVo uploadVariantSpecVo = new UploadVariantSpecVo();
            uploadVariantSpecVo.setECNOR(ecnOR);
            Set<UploadVariantSpecItemVo> itemVoSet = new HashSet<>();
            // itemVo01
            UploadVariantSpecItemVo itemVo01 = new UploadVariantSpecItemVo();
            itemVo01.setVariantSpecMasterOR(object2Oid(OR10430VSMaster));


            Set<UploadVariantSpecChoiceItemVo> itemChoiceVoSet01 = new HashSet<>();
            // 结构中已经存在
//            UploadVariantSpecChoiceItemVo choiceItemVo01 = new UploadVariantSpecChoiceItemVo();
//            choiceItemVo01.setType("添加");
//            choiceItemVo01.setChoiceMasterNumber("SSDQ1103");
//            // 结构中已经不存在
//            UploadVariantSpecChoiceItemVo choiceItemVo02 = new UploadVariantSpecChoiceItemVo();
//            choiceItemVo02.setType("删除");
//            choiceItemVo02.setChoiceMasterNumber("SSDQ1103");
//
//            // Windchill中已经不存在
            UploadVariantSpecChoiceItemVo choiceItemVo03 = new UploadVariantSpecChoiceItemVo();
            choiceItemVo03.setType("删除");
            choiceItemVo03.setChoiceMasterNumber("00046");

            // 正确的添加

            UploadVariantSpecChoiceItemVo choiceItemVo04 = new UploadVariantSpecChoiceItemVo();
            choiceItemVo04.setType("添加");
            choiceItemVo04.setChoiceMasterNumber("00041");

            // 正确的删除
            // Windchill中已经不存在
//            UploadVariantSpecChoiceItemVo choiceItemVo05 = new UploadVariantSpecChoiceItemVo();
//            choiceItemVo05.setType("删除");
//            choiceItemVo05.setChoiceMasterNumber("Y0904");

//            itemChoiceVoSet01.add(choiceItemVo01);
//            itemChoiceVoSet01.add(choiceItemVo02);
            itemChoiceVoSet01.add(choiceItemVo03);
            itemChoiceVoSet01.add(choiceItemVo04);
//            itemChoiceVoSet01.add(choiceItemVo05);
            itemVo01.setVos(itemChoiceVoSet01);
            itemVoSet.add(itemVo01);
            // itemVo01
            uploadVariantSpecVo.setVariantSpecItemVos(itemVoSet);

            ResponseVo responseVo = VariantSpecServer.itemDataSelect(uploadVariantSpecVo);
            System.out.println("执行结果:"+responseVo.getCode());
            System.out.println("执行结果:"+responseVo.getMsg());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 获取对象的oid
     *
     * @param WTObject
     * @return String
     */
    public static String object2Oid(WTObject obj) {
        String className = obj.getClass().getName();
        String oid = String.valueOf(obj.getPersistInfo().getObjectIdentifier().getId());
        return "OR:" + className + ":" + oid;
    }
}
