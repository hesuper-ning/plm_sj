package ext.alphai.sinoboom.variantStandard.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sinoboom.variantStandard.domain.*;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.ECNBatchVariantSpec;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.UploadVariantSpecVo;
import ext.alphai.sinoboom.variantStandard.server.OptionSetService;
import ext.alphai.sinoboom.variantStandard.server.VariantSpecServer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import wt.fc.ReferenceFactory;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

@Controller
@RequestMapping({ "/variantSpec" })
public class VariantSpecController {

    static ReferenceFactory rf = new ReferenceFactory();
    static final ObjectMapper objectMapper = new ObjectMapper();


    @RequestMapping(value = "/ecnVariantSpecChangeItem", method = RequestMethod.GET)
    public void getChangeItem(@RequestParam("ECNOR") String ECNOR , HttpServletRequest request,
                              HttpServletResponse response) throws WTException, IOException, SQLException {
        ResponseVo vo = VariantSpecServer.getChangeItemByECN(ECNOR);
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }



    /**
     * 页面添加变型规范 变更项 校验和新增保存
     * SelectChangeItemReq
     * @param json
     * @param response
     */
    @RequestMapping(value = "/itemDataSelect", method = RequestMethod.POST)
    public void itemDataSelect(@RequestBody String json, HttpServletResponse response) throws Exception {
        UploadVariantSpecVo uploadVariantSpecVo = objectMapper.readValue(json, new TypeReference<UploadVariantSpecVo>() {});
        ResponseVo responseVo = VariantSpecServer.itemDataSelect(uploadVariantSpecVo);
        String resultJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response, resultJson);
    }


    @RequestMapping(value = "/insertOrUpdateECNBatchVariantSpec", method = RequestMethod.POST)
    public void insertOrUpdateECNBatchVariantSpec(@RequestBody String json ,HttpServletRequest request,
                                             HttpServletResponse response) throws IOException {
        ResponseVo vo = null;
        WindowUpdateVariantSpecVo windowUpdateVSVo = objectMapper.readValue(json, WindowUpdateVariantSpecVo.class);
        ECNBatchVariantSpec ecnBatchVariantSpec = new ECNBatchVariantSpec();
        ecnBatchVariantSpec.setECNNUMBER(windowUpdateVSVo.getEcnNumber());
        ecnBatchVariantSpec.setECNOR(windowUpdateVSVo.getEcnOR());
        ecnBatchVariantSpec.setCHANGECONTENTJSON(objectMapper.writeValueAsString(windowUpdateVSVo.getVos()));
        int i = VariantSpecServer.insertOrUpdateECNBatchVariantSpec(ecnBatchVariantSpec);
        if(i>0){
            vo = ResponseVo.success(null);
        }else {
            vo = ResponseVo.error(400, "修改失败");
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }

    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }
}
