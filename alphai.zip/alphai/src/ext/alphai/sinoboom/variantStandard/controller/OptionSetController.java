package ext.alphai.sinoboom.variantStandard.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sinoboom.variantStandard.domain.*;
import ext.alphai.sinoboom.variantStandard.excel.OptionSetChangeExcel;
import ext.alphai.sinoboom.variantStandard.server.OptionSetService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import wt.fc.ReferenceFactory;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;

import java.io.*;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
@Controller
@RequestMapping({ "/optionSet" })
public class OptionSetController {

    static String ECNCLASS = "OR:wt.change2.WTChangeOrder2:";
    static ReferenceFactory rf = new ReferenceFactory();
    static final ObjectMapper objectMapper = new ObjectMapper();

    @RequestMapping(value = "/ecnChangeItem", method = RequestMethod.GET)
    public void getChangeItem(@RequestParam("ECNOR") String ECNOR , HttpServletRequest request,
                    HttpServletResponse response) throws WTException, IOException, SQLException {
        ResponseVo vo = OptionSetService.getChangeItemByECN(ECNOR);
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }

    /**
     * 页面添加选项集变更项 校验和新增保存
     * SelectChangeItemReq
     * @param json
     * @param response
     */
    @RequestMapping(value = "/itemDataSelect", method = RequestMethod.POST)
    public void itemDataSelect(@RequestBody String json, HttpServletResponse response) throws Exception {
        SelectChangeItemReq selectChangeItemReq = objectMapper.readValue(json, new TypeReference<SelectChangeItemReq>() {});
        ResponseVo responseVo = OptionSetService.itemDataSelect(selectChangeItemReq);
        String resultJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response, resultJson);
    }



    /**
     * 根据选择名称模糊搜索
     * @param choiceName
     * @param response
     */
    @RequestMapping(value = "/selectChoice", method = RequestMethod.GET)
    public void selectChoice(@RequestParam("optionName") String optionName, @RequestParam("choiceName") String choiceName, HttpServletResponse response) throws IOException {
        ResponseVo vo = null;
        if(StringUtils.isBlank(optionName) && StringUtils.isBlank(choiceName)){
            vo = ResponseVo.error(400, "请填写搜索条件");
        }else {
            List<SelectChoiceByName> selectChoiceByNames = OptionSetService.selectChoiceByNames(optionName, choiceName);
            vo = ResponseVo.success(selectChoiceByNames);
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }

    /**
     * AddOptionSetChangeItem
     */
    @RequestMapping(value = "/addOptionSetChoiceChangeItem", method = RequestMethod.POST)
    public void addOptionSetChoiceChangeItem(@RequestBody String json ,HttpServletRequest request,
                                             HttpServletResponse response) throws JsonProcessingException {
        ResponseVo vo = null;
        List<AddOptionSetChangeItem> items = objectMapper.readValue(json, new TypeReference<List<AddOptionSetChangeItem>>() {});





    }


    /**
     * 上传EXCEL 变更项
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/uploadOptionSetItem", method = RequestMethod.POST)
    public void uploadOptionSetItem(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        System.out.println("进入excel上传变更项接口");
        String resultJson = "";
        ResponseVo vo = null;

        // 检查请求是否为 multipart
        if (!ServletFileUpload.isMultipartContent(request)) {
            vo = ResponseVo.error(400, "请上传文件");
            resultJson = objectMapper.writeValueAsString(vo);
            outResponse(response, resultJson);
            return;
        }

        String ECNOR = null;
        String ECNNumber = null;
        FileItem fileItem = null;
        String fileName = null;

        // 创建文件上传处理器
        DiskFileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);

        try {
            // 解析请求
            List<FileItem> items = upload.parseRequest(request);
            for (FileItem item : items) {
                if (item.isFormField()) {
                    // 处理普通表单字段
                    String fieldName = item.getFieldName();
                    String value = item.getString("UTF-8");
                    if ("ECNOR".equals(fieldName)) {
                        ECNOR = value;
                    } else if ("ECNNumber".equals(fieldName)) {
                        ECNNumber = value;
                    }
                } else {
                    // 处理文件字段
                    fileItem = item;
                    fileName = item.getName();
                }
            }

            // 验证参数
            if (ECNOR == null || ECNNumber == null || fileItem == null) {
                vo = ResponseVo.error(400, "请上传正确的参数");
            } else if (fileName == null || !(fileName.toLowerCase().endsWith(".xls") || fileName.toLowerCase().endsWith(".xlsx"))) {
                vo = ResponseVo.error(400, "只支持 .xls 或 .xlsx 格式的 Excel 文件");
            } else {
                // 验证文件内容确实是 Excel 格式
                try (InputStream is = fileItem.getInputStream()) {
                    // 检查文件是否有有效内容
                    if (is.available() == 0) {
                        vo = ResponseVo.error(400, "上传的文件为空");
                    } else {
                        // 尝试读取文件头验证文件类型
                        byte[] header = new byte[8];
                        is.read(header);
                        is.reset(); // 重置流位置

                        // Excel 文件特征签名检查
                        if (!isExcelFile(header)) {
                            vo = ResponseVo.error(400, "上传的文件不是有效的 Excel 文件");
                        } else {
                            // 调用业务方法
                            vo = OptionSetChangeExcel.addChangeItem(ECNNumber, ECNOR, is);
                        }
                    }
                } catch (Exception e) {
                    vo = ResponseVo.error(500, "处理 Excel 文件时发生错误: " + e.getMessage());
                }
            }
        } catch (Exception e) {
            vo = ResponseVo.error(500, "处理请求时发生错误: " + e.getMessage());
        }

        resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }

    /**
     * 检查文件头是否为 Excel 格式
     */
    private boolean isExcelFile(byte[] header) {
        // Excel 文件特征签名 (XLS: D0 CF 11 E0 A1 B1 1A E1; XLSX: 50 4B 03 04)
        boolean isXls = header[0] == (byte) 0xD0 && header[1] == (byte) 0xCF &&
                header[2] == (byte) 0x11 && header[3] == (byte) 0xE0 &&
                header[4] == (byte) 0xA1 && header[5] == (byte) 0xB1 &&
                header[6] == (byte) 0x1A && header[7] == (byte) 0xE1;

        boolean isXlsx = header[0] == (byte) 0x50 && header[1] == (byte) 0x4B &&
                header[2] == (byte) 0x03 && header[3] == (byte) 0x04;

        return isXls || isXlsx;
    }


    @RequestMapping(value = "/insertOrUpdateECNBatchOption", method = RequestMethod.POST)
    public void insertOrUpdateECNBatchOption(@RequestBody String json ,HttpServletRequest request,
                              HttpServletResponse response) throws IOException {
        ResponseVo vo = null;
        WindowUpdateVo windowUpdateVo = objectMapper.readValue(json, WindowUpdateVo.class);
        ECNBatchOption ecnBatchOption = new ECNBatchOption();
        ecnBatchOption.setECNNUMBER(windowUpdateVo.getEcnNumber());
        ecnBatchOption.setECNOR(windowUpdateVo.getEcnOR());
        ecnBatchOption.setCHANGECONTENTJSON(objectMapper.writeValueAsString(windowUpdateVo.getVos()));
        int i = OptionSetService.insertOrUpdateECNBatchOption(ecnBatchOption);
        if(i>0){
            vo = ResponseVo.success(null);
        }else {
            vo = ResponseVo.error(400, "修改失败");
        }
        String resultJson = objectMapper.writeValueAsString(vo);
        outResponse(response, resultJson);
    }




    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }


    private static InputStream getFileInputStream(HttpServletRequest request, List<String> fileList) throws Exception{
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);
        if (isMultipart) {
            FileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            Iterator<FileItem> items = upload.parseRequest(request).iterator();// 解析表单中提交的所有文件内容
            while (items.hasNext()) {
                FileItem item = (FileItem) items.next();
                if (!item.isFormField()) {
                    String fileName = item.getName();
                    if (fileList != null) {
                        fileList.add(fileName);
                    }
                    return item.getInputStream();
                }
            }
        }
        return null;
    }
}
