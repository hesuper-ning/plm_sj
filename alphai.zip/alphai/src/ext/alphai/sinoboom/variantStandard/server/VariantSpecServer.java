package ext.alphai.sinoboom.variantStandard.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.filter.ATONavigationFilterHelper;
import com.ptc.windchill.option.model.*;
import com.ptc.wpcfg.deliverables.DeliverableDefinition;
import com.ptc.wpcfg.deliverables.DeliverablesMakerHelper;
import com.ptc.wpcfg.deliverables.VariantSpecDeliverableLink;
import com.ptc.wpcfg.doc.DocHelper;
import com.ptc.wpcfg.doc.VariantSpec;
import com.ptc.wpcfg.doc.VariantSpecMaster;
import ext.alphai.sinoboom.variantStandard.domain.ECNBatchOption;
import ext.alphai.sinoboom.variantStandard.domain.SelectChangeItemReq;
import ext.alphai.sinoboom.variantStandard.domain.SelectChangeOptionSetVo;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.*;
import ext.alphai.sinoboom.variantStandard.domain.ResponseVo;
import ext.alphai.sinoboom.variantStandard.excel.ChangeItemDomainDB;
import ext.alphai.sinoboom.variantStandard.utils.CommonUtil;
import ext.alphai.sinoboom.variantStandard.utils.IBAUtil;
import ext.alphai.sinoboom.variantStandard.utils.OptionSetUtil;
import ext.alphai.sinoboom.variantStandard.utils.PersistenceUtil;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeOrder2;
import wt.fc.*;
import wt.fc.collections.WTCollection;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.pom.WTConnection;
import wt.util.WTException;

/**
 * 变型规范相关服务类
 */
public class VariantSpecServer {

    public static String HOST_URL = "http://plmtest.sinoboom.com.cn/Windchill/servlet/odata/v3/ProdPlatformMgmt/VariantSpecifications";
    // 产品外销类型
    public static final String Product_Model = "ProductModel";
    // 整机状态IBA内部值
    public static final String MachineStatus = "MachineStatus";
    static final ObjectMapper objectMapper = new ObjectMapper();
    static ReferenceFactory rf = new ReferenceFactory();
    static String ECNCLASS = "OR:wt.change2.WTChangeOrder2:";
    private static String ADD = "添加";
    private static String DELETE = "删除";
    /**
     * 检验变型规范与部件是否合法
     * @param pbo
     */
    public static void checkVariantSpecDeliverableLink(WTObject pbo) throws WTException {
        StringBuilder sb = new StringBuilder();
        List<VariantSpec> variantSpecs = new ArrayList<>();
        if(pbo instanceof WTChangeOrder2){
            WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
            // 产生的对象
            QueryResult qr = ChangeHelper2.service.getChangeablesAfter(ecn);
            variantSpecs = CommonUtil.getListFromQR(qr, VariantSpec.class);
        } else if (pbo instanceof PromotionNotice) {
            PromotionNotice pn = (PromotionNotice) pbo;
            QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
            variantSpecs = CommonUtil.getListFromQR(qr, VariantSpec.class);
        }  else if(pbo instanceof VariantSpec){
            variantSpecs.add((VariantSpec)pbo);
        }
        if(variantSpecs.isEmpty()){
            sb.append("流程中没有选中任何变型规范对象");
        }else {
            for (VariantSpec variantSpec : variantSpecs) {
                IBAUtil vsIBA = new IBAUtil(variantSpec);
                IBAUtil iba = new IBAUtil();
                String vsNumber = variantSpec.getNumber();
                List<WTPart> wtPartList = getWTPartListByVariantSpecOfficial(variantSpec);
                if(wtPartList.isEmpty()){
                    sb.append("变型规范：").append(variantSpec.getName()).append("没有可交付结果").append("\r\n");
                }else {
                    // 如果变型规范有可交付结果   一个或多个交付结果 只要其中一个可交付结果编号与变型规范一致视为通过校验
                    boolean passCheck = false;
                    for (WTPart part : wtPartList) {
                        String partNumber = part.getNumber();
                        if(vsNumber.equalsIgnoreCase(partNumber)){
                            passCheck = true;
                        }
                    }
                    // 取反表示没有同编号可交付结果
                    if(passCheck){
                        // 通过校验将变型规范的整机状态映射到所有可交付结果上
                        String vsMachineStatus = vsIBA.getIBAValue(MachineStatus);
                        for (WTPart part : wtPartList) {
                            try {
                                iba.setIBAAttribute4AllType(part, MachineStatus, vsMachineStatus);
                            } catch (Exception e) {
                                throw new WTException(e.getMessage());
                            }
                        }
                    }else {
                        // 没通过校验
                        sb.append("变型规范：").append(variantSpec.getName()).append("交付结果中没有相同编号对象").append("\r\n");
                    }
                }
            }
        }
        if(sb.length()>0){
            throw new WTException(sb.toString());
        }
    }











    /**
     * 部件发送Design 视图到SAP MDM
     * 逻辑：检查部件是否是某变型规范的可交付结果 如果是可交付结果 就将变型规范的产品外销型号(ProductModel) 给到待发送的部件中
     * @param parts
     */
    public static void setProductModel(List<WTPart> parts) throws Exception {
        IBAUtil ibaUtil = new IBAUtil();
        for (WTPart part : parts) {
            IBAUtil partIBA = new IBAUtil(part);
            VariantSpec vs = getWTPartListByVariantSpecOfficial(part);
            if(vs != null){
                IBAUtil vsIBA = new IBAUtil(vs);
                String vsProductModel = vsIBA.getIBAValue(Product_Model);
                ibaUtil.setIBAAttribute4AllType(part, Product_Model, vsProductModel);

                // 整机状态  如果部件的整机状态为空值 就将变型规范的整机状态值映射到部件上
                String partMachineStatus = partIBA.getIBAValue(MachineStatus);
                if(StringUtils.isBlank(partMachineStatus)){
                    String vsMachineStatus = vsIBA.getIBAValue(MachineStatus);
                    ibaUtil.setIBAAttribute4AllType(part, MachineStatus, vsMachineStatus);
                }
            }
        }
    }

    /**
     * 非官方方法 获取变型规范的完成的可交付结果部件集合
     * @param vs
     * @return
     */
    public static List<WTPart> getWTPartListByVariantSpecUnofficial(VariantSpec vs){
        List<WTPart> parts = new ArrayList<>();
        QueryResult qr = null;
        try {
            qr = DeliverablesMakerHelper.service.listDeliverables((VariantSpec) vs, true);
            while (qr.hasMoreElements()){
                Object o = qr.nextElement();
                if(o instanceof WTPart){
                    parts.add((WTPart)o);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return parts;
    }

    /**
     * 官方方法 获取变型规范的完成的可交付结果部件集合
     * @param vs
     * @return
     */
    public static List<WTPart> getWTPartListByVariantSpecOfficial(VariantSpec vs){
        List<WTPart> parts = new ArrayList<>();
        QueryResult qr = null;
        try {
            qr = PersistenceHelper.manager.navigate(vs, VariantSpecDeliverableLink.DELIVERABLE_ROLE, VariantSpecDeliverableLink.class);
            while (qr.hasMoreElements()){
                Object o = qr.nextElement();
                if(o instanceof WTPart){
                    parts.add((WTPart)o);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return parts;
    }

    /**
     * 官方方法 获取变型规范的完成的可交付结果LINK关系
     * @param vs ObjectA 是部件 B 是变型规范
     * @return
     */
    public static List<VariantSpecDeliverableLink> getVariantSpecDeliverableLinkListByVariantSpecOfficial(VariantSpec vs){
        List<VariantSpecDeliverableLink> links = new ArrayList<>();
        QueryResult qr = null;
        try {
            qr = PersistenceHelper.manager.navigate(vs, VariantSpecDeliverableLink.DELIVERABLE_ROLE, VariantSpecDeliverableLink.class, false);
            while (qr.hasMoreElements()){
                Object o = qr.nextElement();
                if(o instanceof VariantSpecDeliverableLink){
                    links.add((VariantSpecDeliverableLink)o);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return links;
    }
    /**
     * 官方方法 获取部件是否有对应的变型规范LINK关系
     * @param part ObjectA 是部件 B 是变型规范
     * @return
     */
    public static List<VariantSpecDeliverableLink> getVariantSpecDeliverableLinkListByPartOfficial(WTPart part){
        List<VariantSpecDeliverableLink> links = new ArrayList<>();
        QueryResult qr = null;
        try {
            qr = PersistenceHelper.manager.navigate(part, VariantSpecDeliverableLink.SPEC_ROLE, VariantSpecDeliverableLink.class, false);
            while (qr.hasMoreElements()){
                Object o = qr.nextElement();
                if(o instanceof VariantSpecDeliverableLink){
                    links.add((VariantSpecDeliverableLink)o);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return links;
    }


    /**
     * 官方方法 根据部件获取相对应的变型规范对象
     * @param part
     * @return
     */
    public static VariantSpec getWTPartListByVariantSpecOfficial(WTPart part){
        VariantSpec vs = null;
        QueryResult qr = null;
        try {
            qr = PersistenceHelper.manager.navigate(part, VariantSpecDeliverableLink.SPEC_ROLE, VariantSpecDeliverableLink.class);
            while (qr.hasMoreElements()){
                Object o = qr.nextElement();
                if(o instanceof VariantSpec){
                    return (VariantSpec)o;
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return vs;
    }





    /**
     * 获取变型规范的选择OR集合
     * @param variantSpecOR
     * @return
     */
    public static List<String> getChoiceORByVariantSpecOR(String variantSpecOR) {
        List<String> results = new ArrayList<>();

        try {
            // 调用接口获取JSON数据
            String jsonResponse = getJsonFromHttp(variantSpecOR);

            // 检查是否返回错误
            if (jsonResponse.contains("\"error\"")) {
                // 如果是错误响应，直接返回空列表
                return results;
            }

            // 解析JSON响应
            JSONObject jsonObject = new JSONObject(jsonResponse);

            // 检查是否存在Filters数组
            if (jsonObject.has("Filters")) {
                JSONArray filters = jsonObject.getJSONArray("Filters");

                // 遍历所有Filters
                for (int i = 0; i < filters.length(); i++) {
                    JSONObject filter = filters.getJSONObject(i);

                    // 检查当前Filter是否有ChoiceValues
                    if (filter.has("ChoiceValues")) {
                        JSONArray choiceValues = filter.getJSONArray("ChoiceValues");

                        // 遍历所有ChoiceValues并提取ID
                        for (int j = 0; j < choiceValues.length(); j++) {
                            JSONObject choiceValue = choiceValues.getJSONObject(j);
                            if (choiceValue.has("ID")) {
                                results.add(choiceValue.getString("ID"));
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            // 发生任何异常时返回空列表
            e.printStackTrace();
            return new ArrayList<>();
        }

        return results;
    }




    /**
     * 调用接口获取数据
     * @param OR 参数标识符
     * @return 返回JSON格式字符串
     */
    public static String getJsonFromHttp(String OR) {
        StringBuilder json = new StringBuilder();
        String urlString = HOST_URL+"('" + OR + "')/NavigationCriteria";

        // Basic认证信息
        String username = "wcadmin";
        String password = "wcadmin";
        String auth = username + ":" + password;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + encodedAuth;

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json; charset=utf-8");
            conn.setRequestProperty("Authorization", authHeaderValue); // 添加认证头

            // 设置连接和读取超时
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // 明确指定使用UTF-8编码读取响应
                try (BufferedReader in = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        json.append(inputLine);
                    }
                }
            } else {
                // 处理错误响应
                try (BufferedReader in = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))) {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        json.append(inputLine);
                    }
                }
                return "{\"error\": \"HTTP error code: " + responseCode + "\", \"response\": \"" + json.toString() + "\"}";
            }
            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\": \"" + e.getMessage().replace("\"", "\\\"") + "\"}";
        }

        return json.toString();
    }


    /**
     * 变型规范页面修改所用到的方法
     *
     */
    /**
     * 根据ECN对象获取
     * @param ecnOR
     */
    public static ResponseVo getChangeItemByECN(String ecnOR) throws WTException, SQLException, JsonProcessingException {
        ResponseVo vo = null;
        List<ChangeVsItemDomainDB> vos = new ArrayList<>();
        WTChangeOrder2 changeOrder = (WTChangeOrder2) rf.getReference(ecnOR).getObject();
        List<VariantSpec> affectedObjectsByECN = getAffectedObjectsByECN(changeOrder);
        ECNBatchVariantSpec ecnBatchVariantSpecByECNOR = getECNBatchVariantSpecByECNOR(ecnOR);
        String ecnnumber = ecnBatchVariantSpecByECNOR.getECNNUMBER();
        if (StringUtils.isNotBlank(ecnnumber)) {
            String changecontentjson = ecnBatchVariantSpecByECNOR.getCHANGECONTENTJSON();
            vos = objectMapper.readValue(changecontentjson, new TypeReference<List<ChangeVsItemDomainDB>>() {});
            for (ChangeVsItemDomainDB changeVsItemDomainDB : vos) {
                String variantSpecMasterOR = changeVsItemDomainDB.getVariantSpecMasterOR();
                VariantSpecMaster variantSpecMaster = (VariantSpecMaster) PersistenceUtil.oid2Object(variantSpecMasterOR);
                changeVsItemDomainDB.setVariantSpecNumber(variantSpecMaster.getNumber());
                changeVsItemDomainDB.setVariantSpecName(variantSpecMaster.getName());
            }


            List<String> variantSpecNumbers = new ArrayList<>();
            for (VariantSpec variantSpec : affectedObjectsByECN) {
                VariantSpecMaster variantSpecMaster = (VariantSpecMaster) variantSpec.getMaster();
                variantSpecNumbers.add(PersistenceUtil.object2Oid(variantSpecMaster));
            }
            List<String> vosVariantSpecNumbers = new ArrayList<>();
            for (ChangeVsItemDomainDB changeVsItemDomainDB : vos) {
                vosVariantSpecNumbers.add(changeVsItemDomainDB.getVariantSpecMasterOR());
            }
            // 取对称差集
            List<String> nonOverlappingElements = findNonOverlappingElements(variantSpecNumbers, vosVariantSpecNumbers);
            for (String nonOverlappingElement : nonOverlappingElements) {
                for (VariantSpec variantSpec : affectedObjectsByECN) {
                    VariantSpecMaster variantSpecMaster = (VariantSpecMaster) variantSpec.getMaster();
                    String variantSpecMasterOR = PersistenceUtil.object2Oid(variantSpecMaster);
                    if(variantSpecMasterOR.equals(nonOverlappingElement)){
                        ChangeVsItemDomainDB itemDomainDB = new ChangeVsItemDomainDB();
                        itemDomainDB.setVariantSpecNumber(variantSpecMaster.getNumber());
                        itemDomainDB.setVariantSpecMasterOR(variantSpecMasterOR);
                        itemDomainDB.setVariantSpecName(variantSpecMaster.getName());
                        itemDomainDB.setVos(new HashSet<>());
                        vos.add(itemDomainDB);
                    }
                }
            }
        } else {
            for (VariantSpec variantSpec : affectedObjectsByECN) {
                VariantSpecMaster variantSpecMaster = (VariantSpecMaster) variantSpec.getMaster();
                ChangeVsItemDomainDB DBvo = new ChangeVsItemDomainDB();
                DBvo.setVariantSpecName(variantSpecMaster.getName());
                DBvo.setVariantSpecNumber(variantSpecMaster.getNumber());
                DBvo.setVariantSpecMasterOR(PersistenceUtil.object2Oid(variantSpecMaster));
                DBvo.setVos(new HashSet<>());
                vos.add(DBvo);
            }
        }
        vo  =ResponseVo.success(vos);
        return vo;
    }





    /**
     * 用ECN获取受影响对象里的选项集集合
     * @return
     */
    public static List<VariantSpec> getAffectedObjectsByECN(WTChangeOrder2 ecn) throws WTException {
        QueryResult qr = ChangeHelper2.service.getChangeablesBefore(ecn);
        return CommonUtil.getListFromQR(qr, VariantSpec.class);
    }


    /**
     * 如果ecnNumber字段在数据库中已存在就更新（非空字段），否则新增。
     * 更新时只更新对象中非空（非null且非空字符串）的属性，UPDATETIME由数据库触发器自动更新。
     * 新增时UPDATETIME由数据库默认值填充。
     *
     * @param variantSpec 要保存的ECNBatchVariantSpec对象
     * @return 受影响的行数
     */
    public static int insertOrUpdateECNBatchVariantSpec(ECNBatchVariantSpec variantSpec) {
        WTConnection connection = null;
        PreparedStatement checkStmt = null;
        PreparedStatement updateStmt = null;
        PreparedStatement insertStmt = null;
        ResultSet rs = null;
        int result = 0;

        Connection connectionConnection = null;
        try {
            connection = CommonUtil.getWTConnection();
            connectionConnection = connection.getConnection();
//            connection.setAutoCommit(false);

            // 1. 检查记录是否存在
            String checkSql = "SELECT COUNT(1) FROM ECNBATCHVARIANTSPEC WHERE ECNNUMBER = ?";
            checkStmt = connection.prepareStatement(checkSql);
            checkStmt.setString(1, variantSpec.getECNNUMBER());
            rs = checkStmt.executeQuery();

            boolean exists = false;
            if (rs.next()) {
                exists = rs.getInt(1) > 0;
            }

            // 2. 根据存在情况执行更新或插入
            if (exists) {
                // 更新操作 - 只更新非空字段
                StringBuilder updateSql = new StringBuilder("UPDATE ECNBATCHVARIANTSPEC SET ");
                List<Object> params = new ArrayList<>();

                // 动态构建SET子句
                if (variantSpec.getECNOR() != null && !variantSpec.getECNOR().isEmpty()) {
                    updateSql.append("ECNOR = ?, ");
                    params.add(variantSpec.getECNOR());
                }

                if (variantSpec.getCHANGECONTENTJSON() != null && !variantSpec.getCHANGECONTENTJSON().isEmpty()) {
                    updateSql.append("CHANGECONTENTJSON = ?, ");
                    params.add(variantSpec.getCHANGECONTENTJSON());
                }

                // 移除最后一个逗号
                if (params.isEmpty()) {
                    return 0; // 没有需要更新的字段
                }
                updateSql.setLength(updateSql.length() - 2);
                updateSql.append(" WHERE ECNNUMBER = ?");
                params.add(variantSpec.getECNNUMBER());

                // 执行更新
                updateStmt = connection.prepareStatement(updateSql.toString());
                for (int i = 0; i < params.size(); i++) {
                    Object param = params.get(i);
                    if (param instanceof String && "CHANGECONTENTJSON".equals(param)) {
                        // 处理CLOB类型
                        Clob clob = connectionConnection.createClob();
                        clob.setString(1, variantSpec.getCHANGECONTENTJSON());
                        updateStmt.setClob(i + 1, clob);
                    } else {
                        updateStmt.setObject(i + 1, param);
                    }
                }

                result = updateStmt.executeUpdate();
            } else {
                // 插入操作 - 必须字段校验
                if (variantSpec.getECNNUMBER() == null || variantSpec.getECNNUMBER().isEmpty() ||
                        variantSpec.getECNOR() == null || variantSpec.getECNOR().isEmpty() ||
                        variantSpec.getCHANGECONTENTJSON() == null || variantSpec.getCHANGECONTENTJSON().isEmpty()) {
                    throw new IllegalArgumentException("必须字段(ECNNUMBER, ECNOR, CHANGECONTENTJSON)不能为空");
                }

                // 插入语句（不包含UPDATETIME，使用数据库默认值）
                String insertSql = "INSERT INTO ECNBATCHVARIANTSPEC (ECNNUMBER, ECNOR, CHANGECONTENTJSON) VALUES (?, ?, ?)";
                insertStmt = connection.prepareStatement(insertSql);
                insertStmt.setString(1, variantSpec.getECNNUMBER());
                insertStmt.setString(2, variantSpec.getECNOR());

                // 处理CLOB类型
                Clob clob = connectionConnection.createClob();
                clob.setString(1, variantSpec.getCHANGECONTENTJSON());
                insertStmt.setClob(3, clob);

                result = insertStmt.executeUpdate();
            }

            connectionConnection.commit();
            return result;
        } catch (Exception e) {
            try {
                if (connection != null) connectionConnection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return 0;
        } finally {
            // 关闭资源
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (checkStmt != null) checkStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (updateStmt != null) updateStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (insertStmt != null) insertStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            catch (Exception e) { e.printStackTrace(); }
        }
    }





    /**
     * 根据ECN编号查询 变型规范数据库中的待变更条目
     * @param ecnNumber
     * @return
     * @throws SQLException
     */
    public static ECNBatchVariantSpec getECNBatchVariantSpecByECNNUMBER(String ecnNumber) throws SQLException {
        ECNBatchVariantSpec ecnBatchVariantSpec = new ECNBatchVariantSpec();
        String sql = "SELECT * FROM ECNBATCHVARIANTSPEC WHERE ECNNUMBER = ?";
        ResultSet rs = null;
        try {
            rs = CommonUtil.excuteSelect(sql, ecnNumber);
            while (rs.next()) {
                ecnBatchVariantSpec.setECNNUMBER(rs.getString("ECNNUMBER"));
                ecnBatchVariantSpec.setECNOR(rs.getString("ECNOR"));

                // 关键修改：读取CLOB并转为String
                Clob jsonClob = rs.getClob("CHANGECONTENTJSON");
                String jsonString = convertClobToString(jsonClob);
                ecnBatchVariantSpec.setCHANGECONTENTJSON(jsonString);

                ecnBatchVariantSpec.setUPDATETIME(rs.getString("UPDATETIME"));
            }
        } finally {
            // 确保关闭资源
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return ecnBatchVariantSpec;
    }

    /**
     * 根据ECN编号查询 变型规范数据库中的待变更条目
     * @param ecnOR
     * @return
     * @throws SQLException
     */
    public static ECNBatchVariantSpec getECNBatchVariantSpecByECNOR(String ecnOR) throws SQLException {
        ECNBatchVariantSpec ecnBatchVariantSpec = new ECNBatchVariantSpec();
        String sql = "SELECT * FROM ECNBATCHVARIANTSPEC WHERE ECNOR = ?";
        ResultSet rs = null;
        try {
            rs = CommonUtil.excuteSelect(sql, ecnOR);
            while (rs.next()) {
                ecnBatchVariantSpec.setECNNUMBER(rs.getString("ECNNUMBER"));
                ecnBatchVariantSpec.setECNOR(rs.getString("ECNOR"));

                // 关键修改：读取CLOB并转为String
                Clob jsonClob = rs.getClob("CHANGECONTENTJSON");
                String jsonString = convertClobToString(jsonClob);
                ecnBatchVariantSpec.setCHANGECONTENTJSON(jsonString);

                ecnBatchVariantSpec.setUPDATETIME(rs.getString("UPDATETIME"));
            }
        }finally {
            // 确保关闭资源
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return ecnBatchVariantSpec;
    }


    // 新增工具方法：将CLOB转为String
    private static String convertClobToString(Clob clob) throws SQLException {
        if (clob == null) {
            return null;
        }

        StringBuilder sb = new StringBuilder();
        try (Reader reader = clob.getCharacterStream();
             BufferedReader br = new BufferedReader(reader)) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            throw new SQLException("ECN批量修改变型规范：Error converting CLOB to string", e);
        }
        return sb.toString();
    }

    public static List<String> findNonOverlappingElements(List<String> list1, List<String> list2) {
        // 找出在list1中但不在list2中的元素
        List<String> onlyInList1 = list1.stream()
                .filter(element -> !list2.contains(element))
                .collect(Collectors.toList());

        // 找出在list2中但不在list1中的元素
        List<String> onlyInList2 = list2.stream()
                .filter(element -> !list1.contains(element))
                .collect(Collectors.toList());

        // 合并两个结果
        return Stream.concat(onlyInList1.stream(), onlyInList2.stream())
                .collect(Collectors.toList());
    }


    /**
     * 变型规范添加或删除选择项记录
     * @param uploadVariantSpecVo
     * @return
     * @throws WTException
     * @throws SQLException
     * @throws JsonProcessingException
     */
    public static ResponseVo itemDataSelect(UploadVariantSpecVo uploadVariantSpecVo) throws WTException, SQLException, JsonProcessingException {
        // 返回错误信息详情
        Map<VariantSpec, List<UploadVariantSpecItemVo>> errorVos = new HashMap<>();
        ResponseVo responseVo = null;
        String ecnor = uploadVariantSpecVo.getECNOR();
        // 前端传来的变更项
        Set<UploadVariantSpecItemVo> variantSpecItemVos = uploadVariantSpecVo.getVariantSpecItemVos();
        WTChangeOrder2 changeOrder = (WTChangeOrder2) rf.getReference(ecnor).getObject();
        // 变型规范变更通告 受影响的变型规范集合
        List<VariantSpec> affectedObjectsByECN = getAffectedObjectsByECN(changeOrder);
        ECNBatchVariantSpec ecnBatchVariantSpecByECNOR = getECNBatchVariantSpecByECNOR(ecnor);
        String changecontentjson = ecnBatchVariantSpecByECNOR.getCHANGECONTENTJSON();
        // 当前ECN数据库中已存在的变更项集合
        Set<ChangeVsItemDomainDB> changeVsItemDomainDBS = new HashSet<ChangeVsItemDomainDB>();
        if(StringUtils.isNotBlank(changecontentjson)){
            changeVsItemDomainDBS = objectMapper.readValue(changecontentjson, new TypeReference<Set<ChangeVsItemDomainDB>>() {});
        }
        for (ChangeVsItemDomainDB changeVsItemDomainDB : changeVsItemDomainDBS) {
            String variantSpecMasterOR = changeVsItemDomainDB.getVariantSpecMasterOR();
            VariantSpecMaster variantSpecMaster = (VariantSpecMaster) PersistenceUtil.oid2Object(variantSpecMasterOR);
            changeVsItemDomainDB.setVariantSpecNumber(variantSpecMaster.getNumber());
            changeVsItemDomainDB.setVariantSpecName(variantSpecMaster.getName());
        }

        // 执行校验新添加的变更项
        for (UploadVariantSpecItemVo variantSpecItemVo : variantSpecItemVos) {
            // 前端传来的变型规范MasterOR
            String variantSpecMasterORFromVUE = variantSpecItemVo.getVariantSpecMasterOR();
            for (VariantSpec variantSpec : affectedObjectsByECN) {
                VariantSpecMaster variantSpecMaster = (VariantSpecMaster) variantSpec.getMaster();
                String variantSpecMasterOR = PersistenceUtil.object2Oid(variantSpecMaster);
                if(variantSpecMasterOR.equals(variantSpecMasterORFromVUE)){

                    OptionSet optionSet = DocHelper.service.getOptionSet(variantSpec);
                    // 变型规范关联的最新版本选项集用于校验添加选择是否合法
                    OptionSet optionSetLastVersion = OptionSetUtil.getOptionSetByName(optionSet.getName());
                    List<OptionSetMemberLink> optionSetMemberLinkByOptionSet = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSetLastVersion);
                    // 变型规范关联的最新版本选项集下所有选择的编号
                    List<String> optionSetChoiceMasterNumber = new ArrayList<>();
                    for (OptionSetMemberLink optionSetMemberLink : optionSetMemberLinkByOptionSet) {
                        optionSetChoiceMasterNumber.add(optionSetMemberLink.getChoiceMaster().getNumber());
                    }

                    List<String> variantSpecChoiceMasterNumber = getVSChoiceMasterNumber(variantSpec);
//                    System.out.println("变型规范:"+variantSpec.getName()+"结构:"+variantSpecChoiceMasterNumber);
                    //校验结构中选择是否符合
                    Set<UploadVariantSpecChoiceItemVo> vos = variantSpecItemVo.getVos();
                    for (UploadVariantSpecChoiceItemVo vo : vos) {
                        String type = vo.getType();
                        String choiceMasterNumber = vo.getChoiceMasterNumber();
                        boolean hasError = false;
                        String errorMsg = "";
                        // 根据编号获取选择Master对象
                        Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceMasterNumber);
                        if(lastByChoiceNumber == null){
                            hasError = true;
                            errorMsg = "选择项'" + choiceMasterNumber + "'不存在请检查";
                        } else {
//                            System.out.println("variantSpecChoiceMasterNumber里是否包含:"+choiceMasterNumber+"TRUE OR FLASE:"+(variantSpecChoiceMasterNumber.contains(choiceMasterNumber)));
                            if(ADD.equals(type)){
                                // 2025 1013 在正常也页面中 只能添加变型规范所选选项集中的选择对象  variantSpec
                                if(!optionSetChoiceMasterNumber.contains(choiceMasterNumber)){
                                    // 说明结构已存在 不能重复添加选择
                                    hasError = true;
                                    errorMsg = "选择项'" + choiceMasterNumber + "'不在变型规范关联的选项集"+optionSetLastVersion.getName()+"中,请检查";
                                }
                                if(variantSpecChoiceMasterNumber.contains(choiceMasterNumber)){
                                    // 说明结构已存在 不能重复添加选择
                                    hasError = true;
                                    errorMsg = "选择项'" + choiceMasterNumber + "'已存在于变型规范结构中，不能重复添加";
                                }
                            } else if (DELETE.equals(type)) {
                                if(!variantSpecChoiceMasterNumber.contains(choiceMasterNumber)){
                                    // 说明结构不存在这个选择
                                    hasError = true;
                                    errorMsg = "选择项'" + choiceMasterNumber + "'不存在于变型规范结构中，无法删除";
                                }
                            }
                        }
                        // 如果校验失败，记录错误信息
                        if (hasError) {
                            // 设置错误信息到vo对象
                            vo.setErrorMessage(errorMsg);
                            // 记录到错误集合
                            if (!errorVos.containsKey(variantSpec)) {
                                errorVos.put(variantSpec, new ArrayList<>());
                            }
                            // 检查是否已经包含该variantSpecItemVo，避免重复添加
                            List<UploadVariantSpecItemVo> errorItemVos = errorVos.get(variantSpec);
                            boolean exists = errorItemVos.stream()
                                    .anyMatch(item -> item.getVariantSpecMasterOR().equals(variantSpecItemVo.getVariantSpecMasterOR()));
                            if (!exists) {
                                errorVos.get(variantSpec).add(variantSpecItemVo);
                            }
                        }
                    }
                }
            }
        }

        // 校验循环完成后，检查是否有错误信息
        if (!errorVos.isEmpty()) {
            StringBuilder errorMessage = new StringBuilder("以下变型规范变更项校验失败:\n");
            int errorCount = 1;

            for (Map.Entry<VariantSpec, List<UploadVariantSpecItemVo>> entry : errorVos.entrySet()) {
                VariantSpec variantSpec = entry.getKey();
                List<UploadVariantSpecItemVo> errorItemVos = entry.getValue();

                // 获取变型规范信息
                String variantSpecName = variantSpec.getName() != null ? variantSpec.getName() : "未知变型规范";
                String variantSpecNumber = variantSpec.getNumber() != null ? variantSpec.getNumber() : "未知编号";

                errorMessage.append(errorCount).append(". 变型规范: ").append(variantSpecName)
                        .append(" (").append(variantSpecNumber).append(")\n");

                for (UploadVariantSpecItemVo itemVo : errorItemVos) {
                    Set<UploadVariantSpecChoiceItemVo> choiceItems = itemVo.getVos();
                    for (UploadVariantSpecChoiceItemVo choiceItem : choiceItems) {
                        if (choiceItem.getErrorMessage() != null) {
                            errorMessage.append("   - ").append(choiceItem.getErrorMessage()).append("\n");
                        }
                    }
                }
                errorCount++;
            }

            responseVo = ResponseVo.error(400, errorMessage.toString());
        } else {
            // 校验通过 将前端传来的UploadVariantSpecItemVo集合 对象变成数据库存储的 ChangeVsItemDomainDB集合
            responseVo = insertOrUpdateChangeVsItemDomainDBInDB(ecnor, changeOrder.getNumber(), variantSpecItemVos, changeVsItemDomainDBS) > 0 ? ResponseVo.success("") : ResponseVo.error(500, "添加变更项失败");
        }
        return responseVo;
    }

    public static List<String> getVSChoiceMasterNumber(VariantSpec variantSpec) throws WTException {
        List<String> vos = new ArrayList<>();
        List<ATONavigationFilterChoiceLink> choiceLinksByVariantSpec = getChoiceLinksByVariantSpec(variantSpec);
        for (ATONavigationFilterChoiceLink atoNavigationFilterChoiceLink : choiceLinksByVariantSpec) {
            vos.add(atoNavigationFilterChoiceLink.getChoiceMaster().getNumber());
        }
        return vos;
    }
    /**
     * 根据VariantSpec 获取所有ATONavigationFilterChoiceLink
     * @param variantSpec
     * @return
     */
    public static List<ATONavigationFilterChoiceLink> getChoiceLinksByVariantSpec(VariantSpec variantSpec) throws WTException {
        List<ATONavigationFilterChoiceLink> list =new ArrayList<>();
        ATONavigationFilter atoNavigationFilter = DocHelper.service.getATONavigationFilter(variantSpec);
//        System.out.println("ATONavigationFilter:"+atoNavigationFilter.getPersistInfo().getObjectIdentifier().getId());
        WTCollection choiceLinks = ATONavigationFilterHelper.service.getChoiceLinks(atoNavigationFilter);
        for (Object choiceLink : choiceLinks) {
//            System.out.println("choiceLink:"+choiceLink);
//            System.out.println("choiceLink:"+choiceLink.getClass().getName());
            if(choiceLink instanceof ObjectReference){
                ObjectReference objectReference = (ObjectReference) choiceLink;
                list.add((ATONavigationFilterChoiceLink)objectReference.getObject());
            }
        }
        return list;
    }

    /**
     * 生成新JSON并修改变型规范的变更项
     * @param uploadVariantSpecItemVos 从前端传来的用户手动添加的变更项
     * @param changeVsItemDomainDBS 当前ECN 在数据库里存储的之前添加过的变更项
     * @return
     */
    /**
     * 使用Stream API的简洁版本
     */
    private static int insertOrUpdateChangeVsItemDomainDBInDB(String ecnOR, String ecnNumber, Set<UploadVariantSpecItemVo> uploadVariantSpecItemVos,
                                                              Set<ChangeVsItemDomainDB> changeVsItemDomainDBS) throws JsonProcessingException {
        if (uploadVariantSpecItemVos == null || uploadVariantSpecItemVos.isEmpty()) {
            return changeVsItemDomainDBS != null ? changeVsItemDomainDBS.size() : 0;
        }

        // 创建可修改的副本，避免修改原始参数
        Set<ChangeVsItemDomainDB> resultSet = changeVsItemDomainDBS != null ?
                new HashSet<>(changeVsItemDomainDBS) : new HashSet<>();

        // 创建按variantSpecMasterOR分组的映射
        Map<String, ChangeVsItemDomainDB> dbMap = resultSet.stream()
                .collect(Collectors.toMap(
                        ChangeVsItemDomainDB::getVariantSpecMasterOR,
                        Function.identity(),
                        (existing, replacement) -> existing
                ));

        // 处理每个上传项
        uploadVariantSpecItemVos.forEach(uploadItem -> {
            String masterOR = uploadItem.getVariantSpecMasterOR();
            ChangeVsItemDomainDB existingDBItem = dbMap.get(masterOR);

            if (existingDBItem != null) {
                // 合并变更项
                Set<VariantSpecChangeItem> mergedItems = mergeChangeItemSets(
                        existingDBItem.getVos(),
                        convertUploadItemsToChangeItems(uploadItem.getVos())
                );
                existingDBItem.setVos(mergedItems);
            } else {
                // 创建新项
                ChangeVsItemDomainDB newDBItem = null;
                try {
                    newDBItem = convertToChangeVsItemDomainDB(uploadItem);
                } catch (WTException e) {
                    throw new RuntimeException(e);
                }
                resultSet.add(newDBItem);
                dbMap.put(masterOR, newDBItem);
            }
        });

        // 重要：将结果设置回原始参数（如果需要修改原始集合）
        if (changeVsItemDomainDBS != null) {
            changeVsItemDomainDBS.clear();
            changeVsItemDomainDBS.addAll(resultSet);
        }

        ECNBatchVariantSpec ecnBatchVariantSpec = new ECNBatchVariantSpec();
        ecnBatchVariantSpec.setECNOR(ecnOR);
        ecnBatchVariantSpec.setECNNUMBER(ecnNumber);
        ecnBatchVariantSpec.setCHANGECONTENTJSON(objectMapper.writeValueAsString(resultSet));
        return insertOrUpdateECNBatchVariantSpec(ecnBatchVariantSpec);
    }
//    private static int insertOrUpdateChangeVsItemDomainDBInDB(String ecnOR, String ecnNumber, Set<UploadVariantSpecItemVo> uploadVariantSpecItemVos,
//                                                              Set<ChangeVsItemDomainDB> changeVsItemDomainDBS) throws JsonProcessingException {
//        // 清空原有的变更项集合
//        if (changeVsItemDomainDBS != null) {
//            changeVsItemDomainDBS.clear();
//        } else {
//            changeVsItemDomainDBS = new HashSet<>();
//        }
//
//        // 如果上传的变更项为空，则直接返回空集合
//        if (uploadVariantSpecItemVos == null || uploadVariantSpecItemVos.isEmpty()) {
//            // 保存空的变更项到数据库
//            ECNBatchVariantSpec ecnBatchVariantSpec = new ECNBatchVariantSpec();
//            ecnBatchVariantSpec.setECNOR(ecnOR);
//            ecnBatchVariantSpec.setECNNUMBER(ecnNumber);
//            ecnBatchVariantSpec.setCHANGECONTENTJSON(objectMapper.writeValueAsString(changeVsItemDomainDBS));
//            return insertOrUpdateECNBatchVariantSpec(ecnBatchVariantSpec);
//        }
//
//        // 将前端上传的变更项转换为数据库存储格式
//        Set<ChangeVsItemDomainDB> newChangeVsItemDomainDBS = new HashSet<>();
//
//        for (UploadVariantSpecItemVo uploadItem : uploadVariantSpecItemVos) {
//            try {
//                ChangeVsItemDomainDB dbItem = convertToChangeVsItemDomainDB(uploadItem);
//                newChangeVsItemDomainDBS.add(dbItem);
//            } catch (WTException e) {
//                throw new RuntimeException("转换变型规范变更项失败: " + e.getMessage(), e);
//            }
//        }
//
//        // 将新的变更项集合设置到结果中
//        changeVsItemDomainDBS.addAll(newChangeVsItemDomainDBS);
//
//        // 保存到数据库
//        ECNBatchVariantSpec ecnBatchVariantSpec = new ECNBatchVariantSpec();
//        ecnBatchVariantSpec.setECNOR(ecnOR);
//        ecnBatchVariantSpec.setECNNUMBER(ecnNumber);
//        ecnBatchVariantSpec.setCHANGECONTENTJSON(objectMapper.writeValueAsString(changeVsItemDomainDBS));
//        return insertOrUpdateECNBatchVariantSpec(ecnBatchVariantSpec);
//    }
    /**
     * 合并两个变更项集合（基于equals去重）
     */
    private static Set<VariantSpecChangeItem> mergeChangeItemSets(Set<VariantSpecChangeItem> set1,
                                                                  Set<VariantSpecChangeItem> set2) {
        Set<VariantSpecChangeItem> result = new HashSet<>();
        if (set1 != null) result.addAll(set1);
        if (set2 != null) result.addAll(set2);
        return result;
    }

    private static Set<VariantSpecChangeItem> convertUploadItemsToChangeItems(Set<UploadVariantSpecChoiceItemVo> uploadItems) {
        if (uploadItems == null || uploadItems.isEmpty()) {
            return new HashSet<>();
        }

        return uploadItems.stream()
                .map(uploadItem -> {
                    VariantSpecChangeItem changeItem = new VariantSpecChangeItem();
                    changeItem.setType(uploadItem.getType());
                    String choiceMasterNumber = uploadItem.getChoiceMasterNumber();
                    Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceMasterNumber);

                    changeItem.setChoiceMasterNumber(choiceMasterNumber);
                    changeItem.setChoiceMasterOR(PersistenceUtil.object2Oid((ChoiceMaster)lastByChoiceNumber.getMaster()));
                    changeItem.setChoiceMasterName(lastByChoiceNumber.getName());
                    return changeItem;
                })
                .collect(Collectors.toSet());
    }
    /**
     * 将UploadVariantSpecItemVo转换为ChangeVsItemDomainDB
     */
    private static ChangeVsItemDomainDB convertToChangeVsItemDomainDB(UploadVariantSpecItemVo uploadItem) throws WTException {
        ChangeVsItemDomainDB dbItem = new ChangeVsItemDomainDB();
        String variantSpecMasterOR = uploadItem.getVariantSpecMasterOR();
        VariantSpecMaster variantSpecMaster = (VariantSpecMaster) rf.getReference(variantSpecMasterOR).getObject();
        dbItem.setVariantSpecMasterOR(variantSpecMasterOR);
        dbItem.setVariantSpecName(variantSpecMaster.getName());
        dbItem.setVariantSpecNumber(variantSpecMaster.getNumber());
        // 转换变更项子项
        Set<VariantSpecChangeItem> changeItems = convertUploadItemsToChangeItems(uploadItem.getVos());
        dbItem.setVos(changeItems);

        return dbItem;
    }



    /**
     * 根据部件和 变型规范 绑定可交付结果
     * @param part
     * @param variantSpec
     * @return
     */
    public static void createVariantSpecDeliverableLink(WTPart part, VariantSpec variantSpec) throws WTException {
        QueryResult qr = DeliverablesMakerHelper.service.listDefinitions(variantSpec.getGenericizable(), true);
        DeliverableDefinition definition = (DeliverableDefinition) qr.nextElement();
        DeliverablesMakerHelper.service.addDeliverable(variantSpec, part, true, definition, definition.getData().getTag(), 0);
    }
}
