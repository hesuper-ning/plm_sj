package ext.alphai.sinoboom.variantStandard.server;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.model.*;
import com.ptc.windchill.option.service.OptionHelper;
import ext.alphai.sinoboom.variantStandard.domain.*;
import ext.alphai.sinoboom.variantStandard.excel.ChangeItemDomainDB;
import ext.alphai.sinoboom.variantStandard.excel.OptionSetChangeItem;
import ext.alphai.sinoboom.variantStandard.utils.CommonUtil;
import ext.alphai.sinoboom.variantStandard.utils.OptionSetUtil;
import ext.alphai.sinoboom.variantStandard.utils.PersistenceUtil;
import org.apache.commons.lang3.StringUtils;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeOrder2;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.pdmlink.PDMLinkProduct;
import wt.pom.WTConnection;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 选项集相关API
 */
public class OptionSetService {

    static final ObjectMapper objectMapper = new ObjectMapper();
    static ReferenceFactory rf = new ReferenceFactory();
    static String ECNCLASS = "OR:wt.change2.WTChangeOrder2:";
    private static String ADD = "添加";
    private static String DELETE = "删除";
    static String CHOICECLASS="OR:com.ptc.windchill.option.model:ChoiceMaster";
    static String OPTIONCLASS="OR:com.ptc.windchill.option.model:OptionMaster";


    /**
     * 页面添加选项集变更项搜索及校验
     * @param selectChangeItemReq
     * @return
     */
//    public static ResponseVo itemDataSelect(SelectChangeItemReq selectChangeItemReq) throws WTException, SQLException, JsonProcessingException {
//        ResponseVo vo = null;
//        // 是否通过校验
//        boolean passVerify = true;
//        // 受影响的同名选项集
//        OptionSet optionSet = null;
//        List<OptionSetChangeItem> vosByDB = new ArrayList<>();
//        StringBuilder sb = new StringBuilder("变更项数据异常"+"\n\t");
//        String ecnor = selectChangeItemReq.getECNOR();
//        String optionSetName = selectChangeItemReq.getOptionSetName();
//        Set<SelectChangeItemSonReq> child = selectChangeItemReq.getChild();
//        // 获取ECN受影响的对象同名选项集结构 判断修改结构是否合法
//        List<OptionSet> affectedObjectsByECN = getAffectedObjectsByECN((WTChangeOrder2) rf.getReference(ecnor).getObject());
//        for (OptionSet set : affectedObjectsByECN) {
//            if(optionSetName.equals(set.getName())){
//                optionSet = set;
//            }
//        }
//        List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);
//        // 获取数据库中记录的已存在的变更项判断是否有重复的变更项避免重复变更
//        ECNBatchOption ecnBatchOption = getECNBatchOptionByECNOR(ecnor);
//        String changecontentjson = ecnBatchOption.getCHANGECONTENTJSON();
//        List<ChangeItemDomainDB> changeItemDomainDBS = objectMapper.readValue(changecontentjson, new TypeReference<List<ChangeItemDomainDB>>() {});
//        for (ChangeItemDomainDB changeItemDomainDB : changeItemDomainDBS) {
//            if(optionSetName.equals(changeItemDomainDB.getOptionSetName())){
//                vosByDB = changeItemDomainDB.getVos();
//            }
//        }
//        // 循环待校验的变更项
//        for (SelectChangeItemSonReq selectChangeItemSonReq : child) {
//            String choiceMasterNumber = selectChangeItemSonReq.getChoiceMasterNumber();
//            String optionMasterNumber = selectChangeItemSonReq.getOptionMasterNumber();
//            String type = selectChangeItemSonReq.getType();
//            if (StringUtils.isNotBlank(choiceMasterNumber)) {
//                Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceMasterNumber);
//                if(lastByChoiceNumber == null){
//                    sb.append("选择编号："+choiceMasterNumber+"不存在"+"\n\t");
//                    passVerify = false;
//                    continue;
//                }
//                ChoiceMaster choiceMaster = (ChoiceMaster) lastByChoiceNumber.getMaster();
//                String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
//                if(ADD.equals(type)){
//                    // 添加选择 要检查源结构中是否存在相同选择
//                    for (OptionSetMemberLink memberLink : memberLinks) {
//                        ChoiceMaster memberLinkChoiceMaster = memberLink.getChoiceMaster();
//                        if(choiceMaster.equals(memberLinkChoiceMaster)){
//                            sb.append("新增选择编号："+choiceMasterNumber+"已经存在于选项集"+optionSetName+"结构中请勿重复添加"+"\n\t");
//                            passVerify = false;
//                        }
//                    }
//                    // 检查在待变更项中是否有添加的相同子项
//                    for (OptionSetChangeItem optionSetChangeItem : vosByDB) {
//                        String choiceMasterORInItem = optionSetChangeItem.getChoiceMasterOR();
//                        if(choiceMasterOR.equals(choiceMasterORInItem) && ADD.equals(optionSetChangeItem.getType())){
//                            // 如果出现相同选择OR且操作也相同的不允许重复添加
//                            sb.append("选择编号："+choiceMasterNumber+"已经存在新增选择的变更项中请勿重复添加"+"\n\t");
//                            passVerify = false;
//                        }
//                    }
//                } else if (DELETE.equals(type)) {
//                    // 如果是删除
//                    // 检查结构中是否有这个选择
//                    boolean inLink = false;
//                    for (OptionSetMemberLink memberLink : memberLinks) {
//                        ChoiceMaster memberLinkChoiceMaster = memberLink.getChoiceMaster();
//                        if(choiceMaster.equals(memberLinkChoiceMaster)){
//                            inLink = true;
//                        }
//                    }
//                    // 如果结构中本来没有就代表有问题 是一个非法的变更项
//                    if(!inLink){
//                        sb.append("新增选择编号："+choiceMasterNumber+"不存在于选项集"+optionSetName+"结构中请检查"+"\n\t");
//                        passVerify = false;
//                    }
//                    // 待变更项中是否有同样的删除变更项
//                    for (OptionSetChangeItem optionSetChangeItem : vosByDB) {
//                        String choiceMasterORInItem = optionSetChangeItem.getChoiceMasterOR();
//                        if(choiceMasterOR.equals(choiceMasterORInItem) && DELETE.equals(optionSetChangeItem.getType())){
//                            // 如果出现相同选择OR且操作也相同的不允许重复添加
//                            sb.append("选择编号："+choiceMasterNumber+"已经存在于待删除的选择中请勿重复添加"+"\n\t");
//                            passVerify = false;
//                        }
//                    }
//                }
//            }
//            if(StringUtils.isNotBlank(optionMasterNumber)){
//                Option lastByOptionNumber = OptionSetUtil.getLastByOptionNumber(optionMasterNumber);
//                if(lastByOptionNumber == null){
//                    sb.append("选项编号："+optionMasterNumber+"不存在"+"\n\t");
//                    passVerify = false;
//                    continue;
//                }
//                OptionMaster optionMaster = (OptionMaster) lastByOptionNumber.getMaster();
//                String optionMasterOR = PersistenceUtil.object2Oid(optionMaster);
//                // 根据选项集获取全部选项
//                List<Option> optionByOptionSet = OptionSetUtil.getOptionByOptionSet(optionSet);
//                if(ADD.equals(type)){
//                    if (optionByOptionSet.contains(lastByOptionNumber)) {
//                        sb.append("选择编号："+optionMasterNumber+"已经存在于选项集:"+optionSetName+"中请勿重复添加");
//                        passVerify = false;
//                    }
//                    // 变更项中查看是否有相同的添加的选项
//                    for (OptionSetChangeItem optionSetChangeItem : vosByDB) {
//                        String optionMasterORFromDB = optionSetChangeItem.getOptionMasterOR();
//                        if(optionMasterOR.equals(optionMasterORFromDB) && ADD.equals(optionSetChangeItem.getType())){
//                            sb.append("选项编号："+optionMasterNumber+"已经存在于选项集:"+optionSetName+"的待新增项中请勿重复添加");
//                            passVerify = false;
//                        }
//                    }
//                } else if (DELETE.equals(type)) {
//                    if (!optionByOptionSet.contains(lastByOptionNumber)) {
//                        sb.append("选择编号："+optionMasterNumber+"已经不存在于选项集:"+optionSetName+"中请检查");
//                        passVerify = false;
//                    }
//                }
//            }
//
//        }
//
//        if(passVerify){
//            // 执行保存到数据库的动作
//            int i = insertSelectChangeItemReq(selectChangeItemReq);
//            vo = i > 0 ? ResponseVo.success(null) : ResponseVo.error(500, "修改数据失败");
//        } else {
//            vo = ResponseVo.error(400, sb.toString());
//        }
//        return vo;
//    }





    /**
     * 页面添加多个选项集变更项搜索及校验
     * @param selectChangeItemReq
     * @return
     */
    public static ResponseVo itemDataSelect(SelectChangeItemReq selectChangeItemReq) throws WTException, SQLException, JsonProcessingException {
        // 获取请求参数
        String ecnor = selectChangeItemReq.getECNOR();
        List<SelectChangeOptionSetVo> changeOptionSetVos = selectChangeItemReq.getChangeOptionSetVos();

        // 获取ECN受影响的对象同名选项集结构
        WTChangeOrder2 changeOrder = (WTChangeOrder2) rf.getReference(ecnor).getObject();
        List<OptionSet> affectedObjectsByECN = getAffectedObjectsByECN(changeOrder);

        // 获取数据库中的变更项
        ECNBatchOption ecnBatchOption = getECNBatchOptionByECNOR(ecnor);
        String changeContentJson = ecnBatchOption.getCHANGECONTENTJSON();
        List<ChangeItemDomainDB> changeItemDomainDBS = new ArrayList<>();
        if(isValidJson(changeContentJson)){
            changeItemDomainDBS = objectMapper.readValue(
                    changeContentJson, new TypeReference<List<ChangeItemDomainDB>>() {});
        }

        // 创建校验结果集合
        List<ValidationResult> validationResults = new ArrayList<>();

        // 对每个选项集进行校验
        for (SelectChangeOptionSetVo changeOptionSetVo : changeOptionSetVos) {
            String optionSetName = changeOptionSetVo.getOptionSetName();
            Set<SelectChangeItemSonReq> child = changeOptionSetVo.getChild();

            // 查找目标选项集
            OptionSet optionSet = affectedObjectsByECN.stream()
                    .filter(set -> optionSetName.equals(set.getName()))
                    .findFirst()
                    .orElse(null);

            if (optionSet == null) {
                validationResults.add(new ValidationResult(false, "未找到选项集: " + optionSetName));
                continue;
            }

            // 获取选项集成品链接
            List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);

            // 查找已存在的变更项 - 使用HashSet自动去重
            Set<OptionSetChangeItem> vosByDB = changeItemDomainDBS.stream()
                    .filter(db -> optionSetName.equals(db.getOptionSetName()))
                    .findFirst()
                    .map(db -> new HashSet<>(db.getVos())) // 转换为HashSet
                    .orElse(new HashSet<>());

            // 创建校验结果
            ValidationResult result = validateChangeItems(child, optionSet, memberLinks, vosByDB, optionSetName);
            validationResults.add(result);
        }

        // 检查所有校验结果
        boolean allPass = validationResults.stream().allMatch(ValidationResult::isPassVerify);

        if (allPass) {
            // 所有选项集校验通过，执行保存到数据库的动作
            int i = insertSelectChangeItemReq(changeOptionSetVos, affectedObjectsByECN, changeItemDomainDBS, selectChangeItemReq);
            return i > 0 ? ResponseVo.success(null) : ResponseVo.error(500, "修改数据失败");
        } else {
            // 收集所有错误信息
            StringBuilder errorMessage = new StringBuilder("以下选项集变更项校验失败:\n");
            for (int i = 0; i < validationResults.size(); i++) {
                ValidationResult result = validationResults.get(i);
                if (!result.isPassVerify()) {
                    SelectChangeOptionSetVo vo = changeOptionSetVos.get(i);
                    errorMessage.append("选项集: ").append(vo.getOptionSetName())
                            .append(" - ").append(result.getErrorMessage()).append("\n");
                }
            }
            return ResponseVo.error(400, errorMessage.toString());
        }
    }

    /**
     * 校验变更项
     */
    private static ValidationResult validateChangeItems(Set<SelectChangeItemSonReq> child,
                                                        OptionSet optionSet, List<OptionSetMemberLink> memberLinks,
                                                        Set<OptionSetChangeItem> vosByDB, String optionSetName) throws WTException {

        boolean passVerify = true;
        StringBuilder errorMessage = new StringBuilder("变更项数据异常\n\t");

        // 预计算选项集中的选项
        List<Option> optionByOptionSet = OptionSetUtil.getOptionByOptionSet(optionSet);

        for (SelectChangeItemSonReq selectChangeItemSonReq : child) {
            String choiceMasterNumber = selectChangeItemSonReq.getChoiceMasterNumber();
            String optionMasterNumber = selectChangeItemSonReq.getOptionMasterNumber();
            String type = selectChangeItemSonReq.getType();

            if (StringUtils.isNotBlank(choiceMasterNumber)) {
                passVerify &= validateChoiceChange(choiceMasterNumber, type, memberLinks,
                        vosByDB, optionSetName, errorMessage);
            }

            if (StringUtils.isNotBlank(optionMasterNumber)) {
                passVerify &= validateOptionChange(optionMasterNumber, type, optionByOptionSet,
                        vosByDB, optionSetName, errorMessage);
            }
        }

        return new ValidationResult(passVerify, errorMessage.toString());
    }

    /**
     * 校验选择变更
     */
    private static boolean validateChoiceChange(String choiceMasterNumber, String type,
                                                List<OptionSetMemberLink> memberLinks, Set<OptionSetChangeItem> vosByDB,
                                                String optionSetName, StringBuilder errorMessage) throws WTException {

        boolean isValid = true;
        Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceMasterNumber);

        if (lastByChoiceNumber == null) {
            errorMessage.append("选择编号：").append(choiceMasterNumber).append("不存在\n\t");
            return false;
        }

        ChoiceMaster choiceMaster = (ChoiceMaster) lastByChoiceNumber.getMaster();
        String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);

        // 检查是否已存在于选项集结构中
        boolean existsInStructure = memberLinks.stream()
                .anyMatch(link -> choiceMaster.equals(link.getChoiceMaster()));

        if (ADD.equals(type)) {
            // 添加选择的校验逻辑
            if (existsInStructure) {
                errorMessage.append("新增选择编号：").append(choiceMasterNumber)
                        .append("已经存在于选项集").append(optionSetName).append("结构中请勿重复添加\n\t");
                isValid = false;
            }

            // 检查是否已存在于待变更项中 - 使用HashSet的contains方法
            OptionSetChangeItem tempItem = new OptionSetChangeItem();
            tempItem.setChoiceMasterOR(choiceMasterOR);
            tempItem.setType(ADD);
            if (vosByDB.contains(tempItem)) {
                errorMessage.append("选择编号：").append(choiceMasterNumber)
                        .append("已经存在新增选择的变更项中请勿重复添加\n\t");
                isValid = false;
            }
        } else if (DELETE.equals(type)) {
            // 删除选择的校验逻辑
            if (!existsInStructure) {
                errorMessage.append("删除选择编号：").append(choiceMasterNumber)
                        .append("不存在于选项集").append(optionSetName).append("结构中请检查\n\t");
                isValid = false;
            }

            // 检查是否已存在于待删除项中 - 使用HashSet的contains方法
            OptionSetChangeItem tempItem = new OptionSetChangeItem();
            tempItem.setChoiceMasterOR(choiceMasterOR);
            tempItem.setType(DELETE);
            if (vosByDB.contains(tempItem)) {
                errorMessage.append("选择编号：").append(choiceMasterNumber)
                        .append("已经存在于待删除的选择中请勿重复添加\n\t");
                isValid = false;
            }
        }

        return isValid;
    }

    /**
     * 校验选项变更
     */
    private static boolean validateOptionChange(String optionMasterNumber, String type,
                                                List<Option> optionByOptionSet, Set<OptionSetChangeItem> vosByDB,
                                                String optionSetName, StringBuilder errorMessage) throws WTException {

        boolean isValid = true;
        Option lastByOptionNumber = OptionSetUtil.getLastByOptionNumber(optionMasterNumber);

        if (lastByOptionNumber == null) {
            errorMessage.append("选项编号：").append(optionMasterNumber).append("不存在\n\t");
            return false;
        }

        OptionMaster optionMaster = (OptionMaster) lastByOptionNumber.getMaster();
        String optionMasterOR = PersistenceUtil.object2Oid(optionMaster);
        boolean existsInOptionSet = optionByOptionSet.contains(lastByOptionNumber);

        if (ADD.equals(type)) {
            if (existsInOptionSet) {
                errorMessage.append("选项编号：").append(optionMasterNumber)
                        .append("已经存在于选项集:").append(optionSetName).append("中请勿重复添加\n\t");
                isValid = false;
            }

            // 检查是否已存在于待添加项中 - 使用HashSet的contains方法
            OptionSetChangeItem tempItem = new OptionSetChangeItem();
            tempItem.setOptionMasterOR(optionMasterOR);
            tempItem.setType(ADD);
            if (vosByDB.contains(tempItem)) {
                errorMessage.append("选项编号：").append(optionMasterNumber)
                        .append("已经存在于选项集:").append(optionSetName).append("的待新增项中请勿重复添加\n\t");
                isValid = false;
            }
        } else if (DELETE.equals(type)) {
            if (!existsInOptionSet) {
                errorMessage.append("选项编号：").append(optionMasterNumber)
                        .append("已经不存在于选项集:").append(optionSetName).append("中请检查\n\t");
                isValid = false;
            }

            // 检查是否已存在于待删除项中 - 使用HashSet的contains方法
            OptionSetChangeItem tempItem = new OptionSetChangeItem();
            tempItem.setOptionMasterOR(optionMasterOR);
            tempItem.setType(DELETE);
            if (vosByDB.contains(tempItem)) {
                errorMessage.append("选项编号：").append(optionMasterNumber)
                        .append("已经存在于待删除的选项中请勿重复添加\n\t");
                isValid = false;
            }
        }

        return isValid;
    }

    /**
     * 修改多个选项集的待变更项
     */
    public static int insertSelectChangeItemReq(List<SelectChangeOptionSetVo> changeOptionSetVos,
                                                List<OptionSet> affectedObjectsByECN,
                                                List<ChangeItemDomainDB> changeItemDomainDBS,
                                                SelectChangeItemReq selectChangeItemReq)
            throws WTException, JsonProcessingException {
        int result = 0;
        String ecnor = selectChangeItemReq.getECNOR();

        // 处理每个选项集的变更
        for (SelectChangeOptionSetVo changeOptionSetVo : changeOptionSetVos) {
            String optionSetName = changeOptionSetVo.getOptionSetName();
            Set<SelectChangeItemSonReq> child = changeOptionSetVo.getChild();

            // 查找对应的选项集
            OptionSet optionSet = affectedObjectsByECN.stream()
                    .filter(set -> optionSetName.equals(set.getName()))
                    .findFirst()
                    .orElse(null);

            if (optionSet == null) {
                continue; // 跳过不存在的选项集
            }

            // 获取选项集成品链接
            List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);

            // 查找已存在的变更项（针对当前选项集）
            ChangeItemDomainDB changeItemDomainDB = changeItemDomainDBS.stream()
                    .filter(db -> optionSetName.equals(db.getOptionSetName()))
                    .findFirst()
                    .orElse(null);

            // 如果不存在，创建一个新的 ChangeItemDomainDB 对象
            if (changeItemDomainDB == null) {
                changeItemDomainDB = new ChangeItemDomainDB();
                changeItemDomainDB.setOptionSetName(optionSetName);
                changeItemDomainDB.setOptionSetMasterOR(PersistenceUtil.object2Oid((OptionSetMaster)optionSet.getMaster()));
                changeItemDomainDB.setVos(new HashSet<>());
                changeItemDomainDBS.add(changeItemDomainDB);
            }

            Set<OptionSetChangeItem> vosByDB = changeItemDomainDB.getVos();

            // 处理当前选项集的每个变更项
            for (SelectChangeItemSonReq selectChangeItemSonReq : child) {
                String type = selectChangeItemSonReq.getType();
                String optionMasterNumber = selectChangeItemSonReq.getOptionMasterNumber();
                String choiceMasterNumber = selectChangeItemSonReq.getChoiceMasterNumber();

                if (StringUtils.isNotBlank(choiceMasterNumber)) {
                    Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceMasterNumber);
                    if (lastByChoiceNumber == null) {
                        // 记录错误或跳过
                        continue;
                    }
                    ChoiceMaster choiceMaster = (ChoiceMaster) lastByChoiceNumber.getMaster();
                    String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
                    // 用 ChoiceMaster 找 OptionMaster
                    OptionMaster optionChoiceMasterLinkByChoiceMaster = OptionSetUtil.getOptionChoiceMasterLinkByChoiceMaster(choiceMaster);
                    if (optionChoiceMasterLinkByChoiceMaster == null) {
                        // 记录错误或跳过
                        continue;
                    }

                    OptionSetChangeItem item = new OptionSetChangeItem();
                    item.setType(type);
                    item.setOptionMasterNumber(optionChoiceMasterLinkByChoiceMaster.getNumber());
                    item.setOptionMasterName(optionChoiceMasterLinkByChoiceMaster.getName());
                    item.setOptionMasterOR(PersistenceUtil.object2Oid(optionChoiceMasterLinkByChoiceMaster));
                    item.setChoiceMasterNumber(choiceMaster.getNumber());
                    item.setChoiceMasterName(choiceMaster.getName());
                    item.setChoiceMasterOR(choiceMasterOR);
                    vosByDB.add(item);
                }

                if (StringUtils.isNotBlank(optionMasterNumber)) {
                    Option lastByOptionNumber = OptionSetUtil.getLastByOptionNumber(optionMasterNumber);
                    if (lastByOptionNumber == null) {
                        // 记录错误或跳过
                        continue;
                    }
                    OptionMaster lastByOptionNumberMaster = (OptionMaster) lastByOptionNumber.getMaster();
                    String optionMasterOR = PersistenceUtil.object2Oid(lastByOptionNumberMaster);
                    List<OptionChoiceMasterLink> masterLinks = OptionSetUtil.getOptionChoiceMasterLinkByOption(lastByOptionNumber);

                    if (ADD.equals(type)) {
                        // 添加选项的所有选择
                        for (OptionChoiceMasterLink masterLink : masterLinks) {
                            ChoiceMaster linkChoiceMaster = masterLink.getChoiceMaster();
                            OptionSetChangeItem item = new OptionSetChangeItem();
                            item.setType(type);
                            item.setOptionMasterNumber(lastByOptionNumberMaster.getNumber());
                            item.setOptionMasterName(lastByOptionNumberMaster.getName());
                            item.setOptionMasterOR(optionMasterOR);
                            item.setChoiceMasterNumber(linkChoiceMaster.getNumber());
                            item.setChoiceMasterName(linkChoiceMaster.getName());
                            item.setChoiceMasterOR(PersistenceUtil.object2Oid(linkChoiceMaster));
                            vosByDB.add(item);
                        }
                    } else if (DELETE.equals(type)) {
                        // 删除当前选项集中这个选项的所有选择
                        List<ChoiceMaster> choiceMasterByOption = OptionSetUtil.getChoiceMasterByOption(lastByOptionNumber);
                        for (OptionSetMemberLink memberLink : memberLinks) {
                            ChoiceMaster choiceMaster = memberLink.getChoiceMaster();
                            if (choiceMasterByOption.contains(choiceMaster)) {
                                String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
                                OptionSetChangeItem item = new OptionSetChangeItem(type, optionMasterNumber,
                                        lastByOptionNumberMaster.getName(), optionMasterOR,
                                        choiceMaster.getNumber(), choiceMaster.getName(), choiceMasterOR);
                                vosByDB.add(item);
                            }
                        }
                    }
                }
            }
        }

        // 将整个 changeItemDomainDBS 转换为 JSON
        String itemJson = objectMapper.writeValueAsString(changeItemDomainDBS);

        // 创建 ECNBatchOption 对象
        ECNBatchOption ecnBatchOption = new ECNBatchOption();
        ecnBatchOption.setCHANGECONTENTJSON(itemJson);
        ecnBatchOption.setECNOR(ecnor);

        // 获取实际的 ECN 编号
        WTChangeOrder2 ecn = (WTChangeOrder2) rf.getReference(ecnor).getObject();
        ecnBatchOption.setECNNUMBER(ecn.getNumber());

        // 执行数据库操作
        result = insertOrUpdateECNBatchOption(ecnBatchOption);

        return result;
    }











    /**
     * 模糊查询选择
     * @param choiceName
     * @return
     */
    public static List<SelectChoiceByName> selectChoiceByNames(String optionName, String choiceName) {
        List<SelectChoiceByName> resultList = new ArrayList<>();
        String sql;
        String[] params;

        // 构建SQL和参数
        if (!StringUtils.isEmpty(optionName) && !StringUtils.isEmpty(choiceName)) {
            // 双参数查询（联表）
            sql = "SELECT opt.IDA2A2 AS OPITIONMASTERIDA2A2, chc.IDA2A2 AS CHOICEIDA2A2 " +
                    "FROM DBADMIN.ATOOPTION2MASTER opt " +
                    "JOIN DBADMIN.ATOCHOICEMASTER chc ON opt.OPTIONNUMBER = chc.OPTIONNUMBER " +
                    "WHERE opt.NAME LIKE ? AND chc.CHOICENUMBER LIKE ?";
            params = new String[]{"%" + optionName + "%", "%" + choiceName + "%"};
        } else if (!StringUtils.isEmpty(optionName)) {
            // 仅optionName查询
            sql = "SELECT IDA2A2 AS OPITIONMASTERIDA2A2, NULL AS CHOICEIDA2A2 " +
                    "FROM DBADMIN.ATOOPTION2MASTER " +
                    "WHERE NAME LIKE ?";
            params = new String[]{"%" + optionName + "%"};
        } else if (!StringUtils.isEmpty(choiceName)) {
            // 仅choiceName查询
            sql = "SELECT NULL AS OPITIONMASTERIDA2A2, CHOICENUMBER AS CHOICEIDA2A2 " +
                    "FROM DBADMIN.ATOCHOICEMASTER " +
                    "WHERE CHOICENUMBER LIKE ?";
            params = new String[]{"%" + choiceName + "%"};
        } else {
            // 理论上不会走到这里（根据您的校验）
            return resultList;
        }

        try (ResultSet rs = CommonUtil.excuteSelect(sql, params)) {
            while (rs != null && rs.next()) {
//                SelectChoiceByName item = new SelectChoiceByName();
                String choiceida2A2 = rs.getString("CHOICEIDA2A2");// 可能为NULL
                String opitionMasterida2A2 = rs.getString("OPITIONMASTERIDA2A2");// 可能为NULL
                if(!StringUtils.isBlank(choiceida2A2) && !StringUtils.isBlank(opitionMasterida2A2)){
                    // 双查询条件
                } else if(!StringUtils.isBlank(choiceida2A2) && StringUtils.isBlank(opitionMasterida2A2)){
                    // 只搜索Choice
                    String OR = CHOICECLASS+choiceida2A2;
                    ChoiceMaster choiceMaster = (ChoiceMaster) rf.getReference(OR).getObject();
                    // 根据choiceMaster 获取所有它的Option
                    Option optionForChoiceMaster = OptionHelper.service.getOptionForChoiceMaster(choiceMaster);
                    SelectChoiceByName item = new SelectChoiceByName();
                    WTContainer container = optionForChoiceMaster.getContainer();
                    String referenceString = rf.getReferenceString(container);
                    item.setProductOR(referenceString);
                    item.setProductName(container.getContainerName());
                    item.setOptionName(optionForChoiceMaster.getName());
                    item.setOptionNumber(optionForChoiceMaster.getNumber());
                    item.setOptionOR(PersistenceUtil.object2Oid(optionForChoiceMaster));
                    item.setChoiceName(choiceMaster.getName());
                    item.setChoiceNumber(choiceMaster.getNumber());
                    item.setChoiceMasterOR(PersistenceUtil.object2Oid(choiceMaster));
                    resultList.add(item);
                } else if(StringUtils.isBlank(choiceida2A2) && !StringUtils.isBlank(opitionMasterida2A2)){
                    // 只搜索OPTION
                    String OR = OPTIONCLASS+opitionMasterida2A2;
                    OptionMaster optionMaster = (OptionMaster) rf.getReference(OR).getObject();
                    WTContainer container = optionMaster.getContainer();
                    String referenceString = rf.getReferenceString(container);
                    // 根据optionMaster 获取它最新版本的Option  同时获取Option下所有的ChoiceMaster
                    QueryResult queryResult = VersionControlHelper.service.allVersionsOf(optionMaster);
                    Object o = queryResult.nextElement();
                    if(o instanceof Option){
                        Option option = (Option) o;
                        String optionOR = PersistenceUtil.object2Oid(option);
                        // 获取option 所有choiceMaster
                        List<ChoiceMaster> choiceMasterByOption = OptionSetUtil.getChoiceMasterByOption(option);
                        for (ChoiceMaster choiceMaster : choiceMasterByOption) {
                            SelectChoiceByName item = new SelectChoiceByName();
                            item.setProductOR(referenceString);
                            item.setProductName(container.getContainerName());
                            item.setOptionName(option.getName());
                            item.setOptionNumber(option.getNumber());
                            item.setOptionOR(optionOR);
                            item.setChoiceName(choiceMaster.getName());
                            item.setChoiceNumber(choiceMaster.getNumber());
                            item.setChoiceMasterOR(PersistenceUtil.object2Oid(choiceMaster));
                            resultList.add(item);
                        }

                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return resultList;
    }



    /**
     * 根据ECN对象获取
     * @param ecnIDA2A
     */
    public static ResponseVo getChangeItemByECN(String ecnOR) throws WTException, SQLException, JsonProcessingException {
        ResponseVo vo = null;
        List<ChangeItemDomainDB> vos = new ArrayList<>();
        WTChangeOrder2 changeOrder = (WTChangeOrder2) rf.getReference(ecnOR).getObject();
        List<OptionSet> affectedObjectsByECN = getAffectedObjectsByECN(changeOrder);
        // 用OR获取数据库中是否已存在的待变更项
        ECNBatchOption ecnBatchOption = getECNBatchOptionByECNOR(ecnOR);
        String ecnnumber = ecnBatchOption.getECNNUMBER();
        if (StringUtils.isNotBlank(ecnnumber)) {
            String changecontentjson = ecnBatchOption.getCHANGECONTENTJSON();
            vos = objectMapper.readValue(changecontentjson, new TypeReference<List<ChangeItemDomainDB>>() {});
            List<String> optionSetNames = new ArrayList<>();
            for (OptionSet optionSet : affectedObjectsByECN) {
                optionSetNames.add(optionSet.getName());
            }
            List<String> vosOptionSetNames = new ArrayList<>();
            for (ChangeItemDomainDB changeItemDomainDB : vos) {
                vosOptionSetNames.add(changeItemDomainDB.getOptionSetName());
            }
            // 取对称差集
            List<String> nonOverlappingElements = findNonOverlappingElements(optionSetNames, vosOptionSetNames);
            for (String nonOverlappingElement : nonOverlappingElements) {
                for (OptionSet optionSet : affectedObjectsByECN) {
                    if(optionSet.getName().equals(nonOverlappingElement)){
                        ChangeItemDomainDB itemDomainDB = new ChangeItemDomainDB();
                        itemDomainDB.setOptionSetName(nonOverlappingElement);
                        itemDomainDB.setOptionSetMasterOR(PersistenceUtil.object2Oid((OptionSetMaster)optionSet.getMaster()));
                        itemDomainDB.setVos(new HashSet<>());
                        vos.add(itemDomainDB);
                    }
                }
            }
        }else {
            // 当数据库里还没有这个ecn数据时
//            WTChangeOrder2 ecn = (WTChangeOrder2) rf.getReference(ecnOR).getObject();
//            List<OptionSet> affectedObjectsByECN = getAffectedObjectsByECN(ecn);
            for (OptionSet optionSet : affectedObjectsByECN) {
                OptionSetMaster optionSetMaster = (OptionSetMaster) optionSet.getMaster();
                ChangeItemDomainDB DBvo = new ChangeItemDomainDB();
                DBvo.setOptionSetName(optionSetMaster.getName());
                DBvo.setOptionSetMasterOR(PersistenceUtil.object2Oid(optionSetMaster));
                DBvo.setVos(new HashSet<>());
                vos.add(DBvo);
            }
        }
        vo  =ResponseVo.success(vos);
        return vo;
    }

    /**
     * 获取选项集源结构
     * @param ecn
     * @return
     */
    private static OptionSetChangeStructure getOptionSetChangeStructureByECN(WTChangeOrder2 ecn) throws WTException {
        OptionSetChangeStructure vo = new OptionSetChangeStructure();
        // 获取ECN的受影响对象
        List<OptionSet> affectedObjectsByECN = getAffectedObjectsByECN(ecn);
        vo.setECNOR(PersistenceUtil.object2Oid(ecn));
        vo.setECNNumber(ecn.getNumber());
        vo.setECNName(ecn.getName());
        vo.setOptionSetList(getOptionSetVosByOptionSetList(affectedObjectsByECN));
        return vo;
    }


    /**
     *  根据ECN选项集获取树状结构
     * @param optionSets
     * @return
     */
    public static List<OptionSetVo> getOptionSetVosByOptionSetList(List<OptionSet> optionSets) throws WTException {
        List<OptionSetVo> vos = new ArrayList<>();
        for (OptionSet optionSet : optionSets) {
            OptionSetVo vo = new OptionSetVo();
            vo.setOptionSetName(optionSet.getName());
            vo.setOptionSetOR(PersistenceUtil.object2Oid(optionSet));
            vo.setOptionSetBigVersion(optionSet.getVersionIdentifier().getValue());
            vo.setOptionSetSmallVersion(optionSet.getIterationIdentifier().getValue());
            vo.setLevel(1);
            // 选项集合
            vo.setVos(getOptionSetOptionListByOptionSet(optionSet));
            vos.add(vo);
        }
        return vos;
    }

    /**
     * 根据选项集获取选项信息
     * @param optionSet
     * @return
     */
    private static List<OptionSetOption> getOptionSetOptionListByOptionSet(OptionSet optionSet) throws WTException {
        List<OptionSetOption> vos = new ArrayList<>();
        List<Option> optionByOptionSet = OptionSetUtil.getOptionByOptionSet(optionSet);
        // 获取所有选项集的OPTIONSETMEMBERLINK
        List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);
        for (Option option : optionByOptionSet) {
            OptionSetOption vo = new OptionSetOption();
            vo.setOptionName(option.getName());
            vo.setOptionNumber(option.getNumber());
            vo.setOptionOR(PersistenceUtil.object2Oid(option));
            vo.setLevel(2);
            vo.setSource(true);
            vo.setVos(getOptionSetChoicesByOptionSet(memberLinks, option));
            vos.add(vo);
        }
        return vos;
    }

    /**
     * 根据选项集 选项  得到所有OPTIONSETMEMBERLINK 对象确定当前选项集下使用的选择对象 并归位到指定的选项对象下
     * @param memberLinks
     * @return
     */
    private static List<OptionSetChoice> getOptionSetChoicesByOptionSet(List<OptionSetMemberLink> memberLinks, Option option) throws WTException {
        List<OptionSetChoice> vos = new ArrayList<>();
        for (OptionSetMemberLink memberLink : memberLinks) {
            ChoiceMaster choiceMaster = memberLink.getChoiceMaster();
            Option optionForChoiceMaster = OptionHelper.service.getOptionForChoiceMaster(choiceMaster);
            if(option.equals(optionForChoiceMaster)){
                // 说明这个选择是属于这个选项的
                OptionSetChoice vo = new OptionSetChoice();
                vo.setChoiceName(choiceMaster.getName());
                vo.setChoiceNumber(choiceMaster.getNumber());
                vo.setChoiceMasterOR(PersistenceUtil.object2Oid(choiceMaster));
                vo.setLevel(3);
                vo.setSource(true);
                vos.add(vo);
            }
        }
        return vos;
    }




    /**
     * 用ECN获取受影响对象里的选项集集合
     * @return
     */
    public static List<OptionSet> getAffectedObjectsByECN(WTChangeOrder2 ecn) throws WTException {
        QueryResult qr = ChangeHelper2.service.getChangeablesBefore(ecn);
        return CommonUtil.getListFromQR(qr, OptionSet.class);
    }




    /**
     * 如果ecnNumber字段在数据库中已存在就更新（非空字段），否则新增。
     * 更新时只更新对象中非空（非null且非空字符串）的属性，UPDATETIME由数据库触发器自动更新。
     * 新增时UPDATETIME由数据库默认值填充。
     *
     * @param option 要保存的ECNBatchOption对象
     * @return 受影响的行数
     */
    public static int insertOrUpdateECNBatchOption(ECNBatchOption option) {
        WTConnection connection = null;
        PreparedStatement checkStmt = null;
        PreparedStatement updateStmt = null;
        PreparedStatement insertStmt = null;
        ResultSet rs = null;
        int result = 0;

        Connection connectionConnection = null;
        try {
            connection = CommonUtil.getWTConnection();
            connectionConnection = connection.getConnection();
//            connection.setAutoCommit(false);

            // 1. 检查记录是否存在
            String checkSql = "SELECT COUNT(1) FROM ECNBATCHOPTIONSET WHERE ECNNUMBER = ?";
            checkStmt = connection.prepareStatement(checkSql);
            checkStmt.setString(1, option.getECNNUMBER());
            rs = checkStmt.executeQuery();

            boolean exists = false;
            if (rs.next()) {
                exists = rs.getInt(1) > 0;
            }

            // 2. 根据存在情况执行更新或插入
            if (exists) {
                // 更新操作 - 只更新非空字段
                StringBuilder updateSql = new StringBuilder("UPDATE ECNBATCHOPTIONSET SET ");
                List<Object> params = new ArrayList<>();

                // 动态构建SET子句
                if (option.getECNOR() != null && !option.getECNOR().isEmpty()) {
                    updateSql.append("ECNOR = ?, ");
                    params.add(option.getECNOR());
                }

                if (option.getCHANGECONTENTJSON() != null && !option.getCHANGECONTENTJSON().isEmpty()) {
                    updateSql.append("CHANGECONTENTJSON = ?, ");
                    params.add(option.getCHANGECONTENTJSON());
                }

                // 移除最后一个逗号
                if (params.isEmpty()) {
                    return 0; // 没有需要更新的字段
                }
                updateSql.setLength(updateSql.length() - 2);
                updateSql.append(" WHERE ECNNUMBER = ?");
                params.add(option.getECNNUMBER());

                // 执行更新
                updateStmt = connection.prepareStatement(updateSql.toString());
                for (int i = 0; i < params.size(); i++) {
                    Object param = params.get(i);
                    if (param instanceof String && "CHANGECONTENTJSON".equals(param)) {
                        // 处理CLOB类型
                        Clob clob = connectionConnection.createClob();
                        clob.setString(1, option.getCHANGECONTENTJSON());
                        updateStmt.setClob(i + 1, clob);
                    } else {
                        updateStmt.setObject(i + 1, param);
                    }
                }

                result = updateStmt.executeUpdate();
            } else {
                // 插入操作 - 必须字段校验
                if (option.getECNNUMBER() == null || option.getECNNUMBER().isEmpty() ||
                        option.getECNOR() == null || option.getECNOR().isEmpty() ||
                        option.getCHANGECONTENTJSON() == null || option.getCHANGECONTENTJSON().isEmpty()) {
                    throw new IllegalArgumentException("必须字段(ECNNUMBER, ECNOR, CHANGECONTENTJSON)不能为空");
                }

                // 插入语句（不包含UPDATETIME，使用数据库默认值）
                String insertSql = "INSERT INTO ECNBATCHOPTIONSET (ECNNUMBER, ECNOR, CHANGECONTENTJSON) VALUES (?, ?, ?)";
                insertStmt = connection.prepareStatement(insertSql);
                insertStmt.setString(1, option.getECNNUMBER());
                insertStmt.setString(2, option.getECNOR());

                // 处理CLOB类型
                Clob clob = connectionConnection.createClob();
                clob.setString(1, option.getCHANGECONTENTJSON());
                insertStmt.setClob(3, clob);

                result = insertStmt.executeUpdate();
            }

            connectionConnection.commit();
            return result;
        } catch (Exception e) {
            try {
                if (connection != null) connectionConnection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return 0;
        } finally {
            // 关闭资源
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (checkStmt != null) checkStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (updateStmt != null) updateStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (insertStmt != null) insertStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            catch (Exception e) { e.printStackTrace(); }
        }
    }

    /**
     * 根据EC编号查询（可能返回多个匹配项）
     * @param ecnNumber
     * @return 匹配的ECNBatchOption列表（可能为空列表）
     * @throws SQLException
     */
//    public static List<ECNBatchOption> getECNBatchOptionByECNNUMBER(String ecnNumber) throws SQLException {
//        List<ECNBatchOption> resultList = new ArrayList<>();
//        String sql = "SELECT * FROM ECNBATCHOPTIONSET WHERE ECNNUMBER = ?";
//
//        try (ResultSet rs = CommonUtil.excuteSelect(sql, ecnNumber)) {
//            while (rs.next()) {
//                ECNBatchOption ecnBatchOption = new ECNBatchOption();
//                ecnBatchOption.setECNNUMBER(rs.getString("ECNNUMBER"));
//                ecnBatchOption.setECNOR(rs.getString("ECNOR"));
//
//                // 读取CLOB并转为String
//                Clob jsonClob = rs.getClob("CHANGECONTENTJSON");
//                String jsonString = convertClobToString(jsonClob);
//                ecnBatchOption.setCHANGECONTENTJSON(jsonString);
//
//                ecnBatchOption.setUPDATETIME(rs.getString("UPDATETIME"));
//
//                resultList.add(ecnBatchOption);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            throw e;
//        }
//        return resultList;
//    }
//
//    /**
//     * 根据ECNOR查询（可能返回多个匹配项）
//     * @param ecnOR
//     * @return 匹配的ECNBatchOption列表（可能为空列表）
//     * @throws SQLException
//     */
//    public static List<ECNBatchOption> getECNBatchOptionByECNOR(String ecnOR) throws SQLException {
//        List<ECNBatchOption> resultList = new ArrayList<>();
//        String sql = "SELECT * FROM ECNBATCHOPTIONSET WHERE ECNOR = ?";
//
//        try (ResultSet rs = CommonUtil.excuteSelect(sql, ecnOR)) {
//            while (rs.next()) {
//                ECNBatchOption ecnBatchOption = new ECNBatchOption();
//                ecnBatchOption.setECNNUMBER(rs.getString("ECNNUMBER"));
//                ecnBatchOption.setECNOR(rs.getString("ECNOR"));
//
//                // 读取CLOB并转为String
//                Clob jsonClob = rs.getClob("CHANGECONTENTJSON");
//                String jsonString = convertClobToString(jsonClob);
//                ecnBatchOption.setCHANGECONTENTJSON(jsonString);
//
//                ecnBatchOption.setUPDATETIME(rs.getString("UPDATETIME"));
//
//                resultList.add(ecnBatchOption);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            throw e;
//        }
//        return resultList;
//    }


    /**
     * 根据EC编号查询
     * @param ecnNumber
     * @return
     * @throws SQLException
     */
    public static ECNBatchOption getECNBatchOptionByECNNUMBER(String ecnNumber) throws SQLException {
        ECNBatchOption ecnBatchOption = new ECNBatchOption();
        String sql = "SELECT * FROM ECNBATCHOPTIONSET WHERE ECNNUMBER = ?";
        ResultSet rs = null;
        try {
            rs = CommonUtil.excuteSelect(sql, ecnNumber);
            while (rs.next()) {
                ecnBatchOption.setECNNUMBER(rs.getString("ECNNUMBER"));
                ecnBatchOption.setECNOR(rs.getString("ECNOR"));

                // 关键修改：读取CLOB并转为String
                Clob jsonClob = rs.getClob("CHANGECONTENTJSON");
                String jsonString = convertClobToString(jsonClob);
                ecnBatchOption.setCHANGECONTENTJSON(jsonString);

                ecnBatchOption.setUPDATETIME(rs.getString("UPDATETIME"));
            }
        } finally {
            // 确保关闭资源
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return ecnBatchOption;
    }


    public static ECNBatchOption getECNBatchOptionByECNOR(String ecnOR) throws SQLException {
        ECNBatchOption ecnBatchOption = new ECNBatchOption();
        String sql = "SELECT * FROM ECNBATCHOPTIONSET WHERE ECNOR = ?";
        ResultSet rs = null;
        try {
            rs = CommonUtil.excuteSelect(sql, ecnOR);
            while (rs.next()) {
                ecnBatchOption.setECNNUMBER(rs.getString("ECNNUMBER"));
                ecnBatchOption.setECNOR(rs.getString("ECNOR"));

                // 关键修改：读取CLOB并转为String
                Clob jsonClob = rs.getClob("CHANGECONTENTJSON");
                String jsonString = convertClobToString(jsonClob);
                ecnBatchOption.setCHANGECONTENTJSON(jsonString);

                ecnBatchOption.setUPDATETIME(rs.getString("UPDATETIME"));
            }
        }finally {
            // 确保关闭资源
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return ecnBatchOption;
    }




    // 新增工具方法：将CLOB转为String
    private static String convertClobToString(Clob clob) throws SQLException {
        if (clob == null) {
            return null;
        }

        StringBuilder sb = new StringBuilder();
        try (Reader reader = clob.getCharacterStream();
             BufferedReader br = new BufferedReader(reader)) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            throw new SQLException("ECN批量修改选项集：Error converting CLOB to string", e);
        }
        return sb.toString();
    }



    /**
     * 校验结果封装类
     */
    private static class ValidationResult {
        private final boolean passVerify;
        private final String errorMessage;

        public ValidationResult(boolean passVerify, String errorMessage) {
            this.passVerify = passVerify;
            this.errorMessage = errorMessage;
        }

        public boolean isPassVerify() {
            return passVerify;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }

    /**
     * 判断字符串是否是JSON
     * @param jsonString
     * @return
     */
    public static boolean isValidJson(String jsonString) {
        if (jsonString == null || jsonString.trim().isEmpty()) {
            return false;
        }
        try {
            objectMapper.readTree(jsonString);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static List<String> findNonOverlappingElements(List<String> list1, List<String> list2) {
        // 找出在list1中但不在list2中的元素
        List<String> onlyInList1 = list1.stream()
                .filter(element -> !list2.contains(element))
                .collect(Collectors.toList());

        // 找出在list2中但不在list1中的元素
        List<String> onlyInList2 = list2.stream()
                .filter(element -> !list1.contains(element))
                .collect(Collectors.toList());

        // 合并两个结果
        return Stream.concat(onlyInList1.stream(), onlyInList2.stream())
                .collect(Collectors.toList());
    }
}
