package ext.alphai.sinoboom.variantStandard;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.sinoboom.variantStandard.CustomActionsRB_zh_CN")
public class CustomActionsRB_zh_CN extends WTListResourceBundle {


    @RBEntry("选项集批量更改")
    public static final String PRIVATE_CONSTANT_01 ="variantStandard.batchChange.description";

    @RBEntry("选项集批量更改")
    public static final String PRIVATE_CONSTANT_001 ="variantStandard.batchChange.tooltip";



    @RBEntry("变型规范批量更改")
    public static final String PRIVATE_CONSTANT_02 ="variantStandard.variantSpecBatchChange.description";

    @RBEntry("变型规范批量更改")
    public static final String PRIVATE_CONSTANT_002 ="variantStandard.variantSpecBatchChange.tooltip";
}
