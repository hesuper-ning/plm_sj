package ext.alphai.sinoboom.variantStandard;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.model.*;
import com.ptc.wpcfg.doc.VariantSpec;

import com.ptc.wpcfg.doc.VariantSpecMaster;
import ext.alphai.sinoboom.variantStandard.domain.*;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.ChangeVsItemDomainDB;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.VariantSpecChangeItem;
import ext.alphai.sinoboom.variantStandard.excel.ChangeItemDomain;
import ext.alphai.sinoboom.variantStandard.excel.ChangeItemDomainDB;
import ext.alphai.sinoboom.variantStandard.excel.OptionSetChangeItem;
import ext.alphai.sinoboom.variantStandard.server.OptionSetService;
import ext.alphai.sinoboom.variantStandard.utils.OptionSetUtil;
import ext.alphai.sinoboom.variantStandard.utils.PersistenceUtil;
import java.nio.charset.StandardCharsets;

import ext.alphai.sinoboom.variantStandard.work.ChangeVariantSpecWork;
import org.apache.commons.lang3.StringUtils;
import wt.fc.*;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.util.WTException;
import wt.util.WTRuntimeException;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 * ant -f bin/tools.xml class -Dclass.includes=ext/alphai/sinoboom/variantStandard/RemoteTest50.java
 * windchill ext.alphai.sinoboom.variantStandard.RemoteTest50
 */
//import ext.techsoft.logicdata.datautility.EditSAPMaterialNumberDataUtility
public class RemoteTest50 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;


    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", RemoteTest50.class.getName(), null, new Class[]{}, new Object[]{});
    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("Theday0305");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }
    static ObjectMapper objectMapper = new ObjectMapper();
//    public static List<ChoiceMaster> getChoiceMasterByOption(Option option) throws WTException {
//        List<ChoiceMaster> links = new ArrayList<>();
//        QueryResult qr = PersistenceHelper.manager.navigate(option, OptionChoiceMasterLink.CHOICE_MASTER_ROLE,OptionChoiceMasterLink.class, false);
//        while (qr.hasMoreElements()){
//            Object o = qr.nextElement();
//            System.out.println("对象："+o);
//            if(o instanceof ChoiceMaster){
//                links.add((ChoiceMaster)o);
//            }
//        }
//        return links;
//    }



//    public static DFEMAData getDFEMAData(String number){
//        // 创建 DFEMA 测试数据
//        DFEMAData dfemaData = new DFEMAData();
//        dfemaData.setProjectNum("P123");
//        dfemaData.setProductName("支撑杆");
//        dfemaData.setProductNum(number);
//        dfemaData.setDfmeaNum("DF001");
//
//        List<DFEMAItem> dfemaItems = new ArrayList<>();
//
//        // 第一个 DFEMA 项目
////        DFEMAItem dfemaItem1 = new DFEMAItem();
////        dfemaItem1.setUpProductName("上部件1");
////        dfemaItem1.setProductName("支撑杆");
////        dfemaItem1.setDownProductName("下部件1");
////        dfemaItem1.setUpFunctionName("上功能1");
////        dfemaItem1.setFunctionName("主要功能");
////        dfemaItem1.setDownFunctionName("下功能1");
////        dfemaItem1.setResult("结果1");
////        dfemaItem1.setRaseverity("高");
////        dfemaItem1.setInvalidModeName("失效模式1");
////        dfemaItem1.setReason("原因1");
////        dfemaItem1.setYfcsName("预防措施1");
////        dfemaItem1.setRaoccurrence("中");
////        dfemaItem1.setTccsName("探测措施1");
////        dfemaItem1.setRadet("低");
////        dfemaItem1.setRaap("AP值1");
////        dfemaItem1.setFeatureSymbol("特征符号1");
////        dfemaItem1.setOccMeasuresName("发生措施1");
////        dfemaItem1.setDetMeasuresName("探测措施1");
////        dfemaItem1.setResponsibleUserName("负责人1");
////        dfemaItem1.setTargetDate("2023-12-31");
////        dfemaItem1.setStatus("进行中");
////        dfemaItem1.setValidate("已验证");
////        dfemaItem1.setFinishDate("2023-11-30");
////        dfemaItem1.setSeverity("严重度1");
////        dfemaItem1.setOccurrence("发生度1");
////        dfemaItem1.setDet("探测度1");
////        dfemaItem1.setAp("AP1");
//
//        // 第二个 DFEMA 项目
//        DFEMAItem dfemaItem2 = new DFEMAItem();
//        dfemaItem2.setUpProductName("上部件2");
//        dfemaItem2.setProductName("支撑杆");
//        dfemaItem2.setDownProductName("下部件2");
//        dfemaItem2.setUpFunctionName("上功能2");
//        dfemaItem2.setFunctionName("次要功能");
//        dfemaItem2.setDownFunctionName("下功能2");
//        dfemaItem2.setResult("结果2");
//        dfemaItem2.setRaseverity("中");
//        dfemaItem2.setInvalidModeName("失效模式2");
//        dfemaItem2.setReason("原因2");
//        dfemaItem2.setYfcsName("预防措施2");
//        dfemaItem2.setRaoccurrence("低");
//        dfemaItem2.setTccsName("探测措施2");
//        dfemaItem2.setRadet("中");
//        dfemaItem2.setRaap("AP值2");
//        dfemaItem2.setFeatureSymbol("特征符号2");
//        dfemaItem2.setOccMeasuresName("发生措施2");
//        dfemaItem2.setDetMeasuresName("探测措施2");
//        dfemaItem2.setResponsibleUserName("负责人2");
//        dfemaItem2.setTargetDate("2023-12-15");
//        dfemaItem2.setStatus("已完成");
//        dfemaItem2.setValidate("未验证");
//        dfemaItem2.setFinishDate("2023-11-15");
//        dfemaItem2.setSeverity("严重度2");
//        dfemaItem2.setOccurrence("发生度2");
//        dfemaItem2.setDet("探测度2");
//        dfemaItem2.setAp("AP2");
//
////        dfemaItems.add(dfemaItem1);
//        dfemaItems.add(dfemaItem2);
//        dfemaData.setFmeaList(dfemaItems);
//        return dfemaData;
//    }
//
//    public static PFEMAData getPFEMAData(String number){
//        PFEMAData pfemaData = new PFEMAData();
//        pfemaData.setProjectNum("P456");
//        pfemaData.setProductNum(number);
//        pfemaData.setProductName("连接器");
//
//        List<PFEMAItem> pfemaItems = new ArrayList<>();
//
//        // 第一个 PFEMA 项目
//        PFEMAItem pfemaItem1 = new PFEMAItem();
//        pfemaItem1.setProcessProject("工艺项目1");
//        pfemaItem1.setProcedureName("工序1");
//        pfemaItem1.setElementName("元素1");
//        pfemaItem1.setProcessProcedureName("工艺过程1");
//        pfemaItem1.setFunctionName("功能1");
//        pfemaItem1.setElementFunction("元素功能1");
//        pfemaItem1.setResult("结果1");
//        pfemaItem1.setRaseverity("高");
//        pfemaItem1.setInvalidModeName("失效模式1");
//        pfemaItem1.setReason("原因1");
//        pfemaItem1.setYfcsName("预防措施1");
//        pfemaItem1.setRaoccurrence("中");
//        pfemaItem1.setTccsName("探测措施1");
//        pfemaItem1.setRadet("低");
//        pfemaItem1.setRaap("AP值1");
//        pfemaItem1.setProductFeatureSymbol("产品特征1");
//        pfemaItem1.setOccMeasuresName("发生措施1");
//        pfemaItem1.setDetMeasuresName("探测措施1");
//        pfemaItem1.setResponsibleUserName("负责人1");
//        pfemaItem1.setTargetDate("2023-12-31");
//        pfemaItem1.setStatus("进行中");
//        pfemaItem1.setValidate("已验证");
//        pfemaItem1.setFinishDate("2023-11-30");
//        pfemaItem1.setSeverity("严重度1");
//        pfemaItem1.setOccurrence("发生度1");
//        pfemaItem1.setDet("探测度1");
//        pfemaItem1.setAp("AP1");
//        pfemaItem1.setFeatureSymbol("特征符号1");
//
//        // 第二个 PFEMA 项目
////        PFEMAItem pfemaItem2 = new PFEMAItem();
////        pfemaItem2.setProcessProject("工艺项目2");
////        pfemaItem2.setProcedureName("工序2");
////        pfemaItem2.setElementName("元素2");
////        pfemaItem2.setProcessProcedureName("工艺过程2");
////        pfemaItem2.setFunctionName("功能2");
////        pfemaItem2.setElementFunction("元素功能2");
////        pfemaItem2.setResult("结果2");
////        pfemaItem2.setRaseverity("中");
////        pfemaItem2.setInvalidModeName("失效模式2");
////        pfemaItem2.setReason("原因2");
////        pfemaItem2.setYfcsName("预防措施2");
////        pfemaItem2.setRaoccurrence("低");
////        pfemaItem2.setTccsName("探测措施2");
////        pfemaItem2.setRadet("中");
////        pfemaItem2.setRaap("AP值2");
////        pfemaItem2.setProductFeatureSymbol("产品特征2");
////        pfemaItem2.setOccMeasuresName("发生措施2");
////        pfemaItem2.setDetMeasuresName("探测措施2");
////        pfemaItem2.setResponsibleUserName("负责人2");
////        pfemaItem2.setTargetDate("2023-12-15");
////        pfemaItem2.setStatus("已完成");
////        pfemaItem2.setValidate("未验证");
////        pfemaItem2.setFinishDate("2023-11-15");
////        pfemaItem2.setSeverity("严重度2");
////        pfemaItem2.setOccurrence("发生度2");
////        pfemaItem2.setDet("探测度2");
////        pfemaItem2.setAp("AP2");
////        pfemaItem2.setFeatureSymbol("特征符号2");
//
//        pfemaItems.add(pfemaItem1);
////        pfemaItems.add(pfemaItem2);
//        pfemaData.setFmeaList(pfemaItems);
//        return pfemaData;
//    }
    static ReferenceFactory rf = new ReferenceFactory();
    private static String ADD = "添加";
    private static String DELETE = "删除";
    /**
     * 测试导入excel
     * @return
     */
    public static String process() {
        try {

            List<VariantSpec> variantSpecs = new ArrayList<>();
            String vsOR = "OR:com.ptc.wpcfg.doc.VariantSpec:1859930341";
            VariantSpec variantSpec = (VariantSpec) rf.getReference(vsOR).getObject();
            variantSpecs.add(variantSpec);
            String process = ChangeVariantSpecWork.process(variantSpecs, getItems(variantSpec));
            System.out.println("执行结果："+process);
//            String ECNOR = "OR:wt.maturity.PromotionNotice:2403839500";
//            PromotionNotice ecn = (PromotionNotice) rf.getReference(ECNOR).getObject();
//            WfProcess process = WorkflowUtil.getProcessByPbo((WTObject)ecn);
//            System.out.println("升级请求 创建时间："+ecn.getCreateTimestamp());
//            System.out.println("WfProcess 创建时间："+process.getCreateTimestamp());
//            System.out.println("WfProcess 开始时间："+process.getStartTime());
//            System.out.println("WfProcess 结束时间："+process.getEndTime());
//            Timestamp endTimeStamp = process.getEndTime();
//            Timestamp startTimeStamp = process.getStartTime();
//            // 获取毫秒数
//            long startMillis = startTimeStamp.getTime();
//            long endMillis = endTimeStamp.getTime();
//
//            // 计算毫秒差并转换为天数
//            long diffMillis = endMillis - startMillis;
//            long days = diffMillis / (1000 * 60 * 60 * 24); // 整除取天数
//            System.out.println("相差几天："+days);
//            String dfemaReportServlet = getDFEMAReportServlet(objectMapper.writeValueAsString(getDFEMAData("101016010070")));
//            System.out.println("DFEAM respone :"+dfemaReportServlet);
//            String pfemaReportServlet = getPFEMAReportServlet(objectMapper.writeValueAsString(getPFEMAData("101016010070")));
//            System.out.println("PFEAM respone :"+pfemaReportServlet);
//            String OR = "VR:com.ptc.windchill.option.model.Option:1062126";
//            Option lastByOptionNumber = (Option)rf.getReference(OR).getObject();
//            List<ChoiceMaster> choiceMasterByOption = getChoiceMasterByOption(lastByOptionNumber);
//            System.out.println("choiceMasterByOption:"+choiceMasterByOption.size());
//

//            String filePath="C:\\123.xlsx";
//            InputStream inputStream = new FileInputStream(filePath);
//            List<ChangeItemDomain> changeItemDomains = OptionSetChangeExcel.readChangeItems(inputStream);
//            List<OptionSet> sets = new ArrayList<>();
//            // 待变更数据
//            String optionSet37 = "VR:com.ptc.windchill.option.model.OptionSet:1062366";
//            String optionSet48 = "VR:com.ptc.windchill.option.model.OptionSet:1084173";
//            sets.add((OptionSet)rf.getReference(optionSet37).getObject());
//            sets.add((OptionSet)rf.getReference(optionSet48).getObject());
//            Map<OptionSet, List<ChangeItemDomain>> optionSetListMap = OptionSetChangeExcel.mapCollections(sets, changeItemDomains);
//            for (Map.Entry<OptionSet, List<ChangeItemDomain>> optionSetListEntry : optionSetListMap.entrySet()) {
//                OptionSet key = optionSetListEntry.getKey();
//                List<ChangeItemDomain> value = optionSetListEntry.getValue();
//                System.out.println("key："+key.getName());
//                value.forEach(v->{System.out.println("value TYPE:"+v.getType()+"getOptionSetName:"+v.getOptionSetName()+"getOptionNumber:"+v.getOptionNumber()+"getChoiceNumber:"+v.getChoiceNumber());});
//            }
//
//            ResponseVo vo = OptionSetChangeExcel.verifyExcel(optionSetListMap);
//            if(vo != null){
//                System.out.println("EXCEL 结构有问题："+vo.getMsg());
//            }else {
//                System.out.println("通过校验");
//                // 插入数据库
//                ECNBatchOption ecnBatchOption = addExcelItemToDB("12345", "OR:wt.change2.WTChangeOrder2:12345", optionSetListMap);
//                // 返回待修改的变更项
//                int i = OptionSetService.insertOrUpdateECNBatchOption(ecnBatchOption);
//            }

            // 获取JSON
//            String ECNIDA2A2 = "12345";
//            ResponseVo vo = getChangeItemByECN(ECNIDA2A2);
//            String resultJson = objectMapper.writeValueAsString(vo);
//            System.out.println("查询到的JSON："+resultJson);

//            ECNBatchOption ecnBatchOption = OptionSetService.getECNBatchOptionByECNOR("OR:wt.change2.WTChangeOrder2:12345");
//            String changecontentjson = ecnBatchOption.getCHANGECONTENTJSON();
//            List<ChangeItemDomainDB> vos = objectMapper.readValue(changecontentjson, new TypeReference<List<ChangeItemDomainDB>>() {});
//
//            // 执行结构修改
//            String process = ChangeOptionSetWork.process(sets, vos);
//            System.out.println("执行结果："+process);
//            String choiceOR = "OR:com.ptc.windchill.option.model.Choice:1824521912";
//            Choice object = (Choice) rf.getReference(choiceOR).getObject();
//            getOptionChoiceMasterLinkByChoiceMaster((ChoiceMaster) object.getMaster());
//            VariantSpec vs = VariantSpec.newVariantSpec();




            // 查询变型规范
//            String OR = "OR:com.ptc.wpcfg.doc.VariantSpec:1096464";
//            String jsonFromHttp = getJsonFromHttp(OR);
//            System.out.println("变型规范JSON："+jsonFromHttp);


//            SelectChangeItemReq selectChangeItemReq = new SelectChangeItemReq();
////            selectChangeItemReq.setOptionSetName("2座保时捷911");
//            selectChangeItemReq.setECNOR("OR:wt.change2.WTChangeOrder2:12345");
////            selectChangeItemReq.setChild(getSelectChangeItemSonReqs3());
//
//            ResponseVo responseVo = OptionSetService.itemDataSelect(selectChangeItemReq);
//            int code = responseVo.getCode();
//            if(code == 200){
//                System.out.println("通过校验");
//            }else {
//                System.out.println("未通过校验错误消息是："+responseVo.getMsg());
//            }


//            String VSOR = "OR:com.ptc.wpcfg.doc.VariantSpec:1096464";
//            VariantSpec vs = (VariantSpec) rf.getReference(VSOR).getObject();
//            System.out.println("getConfigSpecReference:"+vs.getConfigSpecReference());
//            System.out.println("getTypeDefinitionInfo:"+vs.getTypeDefinitionInfo());
//            System.out.println("getGenericizableReference:"+vs.getGenericizableReference());
//            System.out.println("getOrganizationReference:"+vs.getOrganizationReference());

//            String partOR = "OR:wt.part.WTPart:1848603241";
//            WTPart part = (WTPart)rf.getReference(partOR).getObject();

//            String vsOR = "OR:com.ptc.wpcfg.doc.VariantSpec:1848603165";
//            VariantSpec vs = (VariantSpec)rf.getReference(vsOR).getObject();
//            IBAUtil partIBA = new IBAUtil();
//            partIBA.setIBAAttribute4AllType(vs, "AI_config_desc", "中文配置描述0904");
//            partIBA.setIBAAttribute4AllType(vs, "AI_config_desc_en", "英文配置描述0904");
//            partIBA.setIBAAttribute4AllType(vs, "ProductModel", "alphai");

//            QueryResult q1 = PersistenceHelper.manager.navigate(part, VariantSpecDeliverableLink.SPEC_ROLE, VariantSpecDeliverableLink.class);
//            System.out.println("q1 true");
//            while (q1.hasMoreElements()){
//                System.out.println("q1 true:"+q1.nextElement());
//            }

//            QueryResult q2 = PersistenceHelper.manager.navigate(part, VariantSpecDeliverableLink.DELIVERABLE_ROLE, VariantSpecDeliverableLink.class, false);
//            System.out.println("q2");
//            while (q2.hasMoreElements()){
//                VariantSpecDeliverableLink o = (VariantSpecDeliverableLink)q2.nextElement();
//                System.out.println("q2:OBJB"+o.getRoleBObject());
//                System.out.println("q2:"+o);
//            }
//            QueryResult qr1 = DeliverablesMakerHelper.service.listDeliverables((VariantSpec) vs, true);
//            System.out.println("非官方支持方法结果：");
//            while (qr1.hasMoreElements()){
//                Object o = qr1.nextElement();
//                System.out.println("1集合内对象："+ o);
//                System.out.println("1集合内对象类："+ o.getClass());
//            }
//            System.out.println("VariantSpecDeliverableLink API");
//            QueryResult qr2 = PersistenceHelper.manager.navigate(vs, VariantSpecDeliverableLink.DELIVERABLE_ROLE, VariantSpecDeliverableLink.class, false);
//            while (qr2.hasMoreElements()){
//                Object o = qr2.nextElement();
//                System.out.println("2集合内对象："+ o);
//                System.out.println("2集合内对象类："+ o.getClass());
//                VariantSpecDeliverableLink deliverableLink = (VariantSpecDeliverableLink) o;
//                System.out.println("deliverableLink:"+deliverableLink);
//                System.out.println("deliverableLinkOBJECTB:"+deliverableLink.getRoleAObjectRef());
//            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public static List<ChangeVsItemDomainDB> getItems(VariantSpec variantSpec) throws WTException {
        List<ChangeVsItemDomainDB> changeVsItemDomainDBS = new ArrayList<>();
        ChangeVsItemDomainDB addItemDB1 = new ChangeVsItemDomainDB();
        VariantSpecMaster variantSpecMaster = (VariantSpecMaster) variantSpec.getMaster();
        addItemDB1.setVariantSpecName(variantSpecMaster.getName());
        addItemDB1.setVariantSpecNumber(variantSpecMaster.getNumber());
        addItemDB1.setVariantSpecMasterOR(PersistenceUtil.object2Oid(variantSpecMaster));
        Set<VariantSpecChangeItem> vos1 = new HashSet<VariantSpecChangeItem>();
        VariantSpecChangeItem addItem1 = new VariantSpecChangeItem();
        String addChoiceOR1 = "OR:com.ptc.windchill.option.model.Choice:1824621921";
        Choice addChoice1 = (Choice)rf.getReference(addChoiceOR1).getObject();
        ChoiceMaster addChoiceMaster1 = (ChoiceMaster) addChoice1.getMaster();
        addItem1.setType(ADD);
        addItem1.setChoiceMasterOR(PersistenceUtil.object2Oid(addChoiceMaster1));
        addItem1.setChoiceMasterName(addChoiceMaster1.getName());
        addItem1.setChoiceMasterNumber(addChoiceMaster1.getNumber());
        vos1.add(addItem1);

        addItemDB1.setVos(vos1);
        changeVsItemDomainDBS.add(addItemDB1);



        // 如果添加可以 就删除

        return changeVsItemDomainDBS;
    }


    public static String getDFEMAReportServlet(String dfemaDataJson) {
        StringBuilder responseBuilder = new StringBuilder();
        String urlString = "http://plmtest.sinoboom.com.cn/Windchill/servlet/Navigation/DFEMAReportServlet";

        // Basic认证信息
        String username = "wcadmin";
        String password = "wcadmin";
        String auth = username + ":" + password;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + encodedAuth;

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST"); // 改为POST请求
            conn.setRequestProperty("Accept", "application/json; charset=utf-8");
            conn.setRequestProperty("Authorization", authHeaderValue);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8"); // 设置请求体类型

            // 启用输出并写入请求体
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = dfemaDataJson.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            // 设置连接和读取超时
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int responseCode = conn.getResponseCode();
            InputStream inputStream = (responseCode == HttpURLConnection.HTTP_OK) ?
                    conn.getInputStream() : conn.getErrorStream();

            try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    responseBuilder.append(inputLine);
                }
            }

            if (responseCode != HttpURLConnection.HTTP_OK) {
                return "{\"error\": \"HTTP error code: " + responseCode + "\", \"response\": \"" +
                        responseBuilder.toString().replace("\"", "\\\"") + "\"}";
            }

            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\": \"" + e.getMessage().replace("\"", "\\\"") + "\"}";
        }

        return responseBuilder.toString();
    }

    public static String getPFEMAReportServlet(String pfemaDataJson) {
        StringBuilder responseBuilder = new StringBuilder();
        String urlString = "http://plmtest.sinoboom.com.cn/Windchill/servlet/Navigation/PFEMAReportServlet";

        // Basic认证信息
        String username = "wcadmin";
        String password = "wcadmin";
        String auth = username + ":" + password;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + encodedAuth;

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST"); // 改为POST请求
            conn.setRequestProperty("Accept", "application/json; charset=utf-8");
            conn.setRequestProperty("Authorization", authHeaderValue);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8"); // 设置请求体类型

            // 启用输出并写入请求体
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = pfemaDataJson.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            // 设置连接和读取超时
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int responseCode = conn.getResponseCode();
            InputStream inputStream = (responseCode == HttpURLConnection.HTTP_OK) ?
                    conn.getInputStream() : conn.getErrorStream();

            try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    responseBuilder.append(inputLine);
                }
            }

            if (responseCode != HttpURLConnection.HTTP_OK) {
                return "{\"error\": \"HTTP error code: " + responseCode + "\", \"response\": \"" +
                        responseBuilder.toString().replace("\"", "\\\"") + "\"}";
            }

            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\": \"" + e.getMessage().replace("\"", "\\\"") + "\"}";
        }

        return responseBuilder.toString();
    }












    /**
     * 调用接口获取数据
     * @param OR 参数标识符
     * @return 返回JSON格式字符串
     */
    public static String getJsonFromHttp(String OR) {
        StringBuilder json = new StringBuilder();
        String urlString = "http://pdm-test.xinplz.com/Windchill/servlet/odata/v3/ProdPlatformMgmt/VariantSpecifications('" + OR + "')/NavigationCriteria";

        // Basic认证信息
        String username = "wcadmin";
        String password = "wcadmin";
        String auth = username + ":" + password;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = "Basic " + encodedAuth;

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json; charset=utf-8");
            conn.setRequestProperty("Authorization", authHeaderValue); // 添加认证头

            // 设置连接和读取超时
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // 明确指定使用UTF-8编码读取响应
                try (BufferedReader in = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        json.append(inputLine);
                    }
                }
            } else {
                // 处理错误响应
                try (BufferedReader in = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))) {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        json.append(inputLine);
                    }
                }
                return "{\"error\": \"HTTP error code: " + responseCode + "\", \"response\": \"" + json.toString() + "\"}";
            }
            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\": \"" + e.getMessage().replace("\"", "\\\"") + "\"}";
        }

        return json.toString();
    }


    public static Set<OptionMaster> getOptionChoiceMasterLinkByChoiceMaster(ChoiceMaster choiceMaster) throws WTException {
        Set<OptionMaster> links = new HashSet<>();
        QueryResult qr = PersistenceHelper.manager.navigate(choiceMaster, OptionChoiceMasterLink.OPTION_ROLE,OptionChoiceMasterLink.class, true);
        while (qr.hasMoreElements()){
            Object o = qr.nextElement();
            System.out.println("o:"+o);
            if(o instanceof Option){
                Option option = (Option) o;
                links.add((OptionMaster) option.getMaster());
            }
        }
        return links;
    }
    public static ResponseVo getChangeItemByECN(String ecnIDA2A) throws WTException, SQLException, JsonProcessingException {
        ResponseVo vo = null;
        String ECNOR = "OR:wt.change2.WTChangeOrder2:"+ecnIDA2A;
//        Persistable object = rf.getReference(ECNOR).getObject();
//        OptionSetChangeStructure optionSetChangeStructure = null;
        List<ChangeItemDomainDB> vos = new ArrayList<>();

        // 用OR获取数据库中是否已存在的待变更项
        ECNBatchOption ecnBatchOption = OptionSetService.getECNBatchOptionByECNOR(ECNOR);
        String ecnnumber = ecnBatchOption.getECNNUMBER();
        if (StringUtils.isNotBlank(ecnnumber)) {
            String changecontentjson = ecnBatchOption.getCHANGECONTENTJSON();
            vos = objectMapper.readValue(changecontentjson, new TypeReference<List<ChangeItemDomainDB>>() {});
        }
        vo  =ResponseVo.success(vos);


        return vo;
    }

    public static ECNBatchOption addExcelItemToDB(String ecnNumber, String ecnOR, Map<OptionSet, List<ChangeItemDomain>> optionSetListMap)
            throws WTException, JsonProcessingException {
        ECNBatchOption ecnBatchOption = new ECNBatchOption();
        List<ChangeItemDomainDB> vos = new ArrayList<>();
        ecnBatchOption.setECNNUMBER(ecnNumber);
        ecnBatchOption.setECNOR(ecnOR);
        String itemJson = "";
        for (Map.Entry<OptionSet, List<ChangeItemDomain>> entry : optionSetListMap.entrySet()) {
            OptionSet optionSet = entry.getKey();
            List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);
            OptionSetMaster optionSetMaster = (OptionSetMaster) optionSet.getMaster();
            String optionSetMasterName = optionSetMaster.getName();
            String optionSetMasterOR = PersistenceUtil.object2Oid(optionSetMaster);
            ChangeItemDomainDB changeItemDomainDB = new ChangeItemDomainDB(optionSetMasterName, optionSetMasterOR);

            // 修复点：在items循环外部初始化itemLists
            Set<OptionSetChangeItem> itemLists = new HashSet<>(); // 移出内部循环

            List<ChangeItemDomain> items = entry.getValue();
            for (ChangeItemDomain item : items) {
                String type = item.getType();
                String optionNumber = item.getOptionNumber();
                String choiceNumber = item.getChoiceNumber();

                if (StringUtils.isNotBlank(optionNumber)) {
                    Option lastByOptionNumber = OptionSetUtil.getLastByOptionNumber(optionNumber);
                    OptionMaster optionMaster = (OptionMaster) lastByOptionNumber.getMaster();
                    String optionMasterName = optionMaster.getName();
                    String optionMasterNumber = optionMaster.getNumber();
                    String optionMasterOR = PersistenceUtil.object2Oid(optionMaster);
                    if("添加".equals(type)){
                        List<OptionChoiceMasterLink> optionChoiceMasterLinkByOption = OptionSetUtil.getOptionChoiceMasterLinkByOption(lastByOptionNumber);
                        for (OptionChoiceMasterLink optionChoiceMasterLink : optionChoiceMasterLinkByOption) {
                            ChoiceMaster choiceMaster = optionChoiceMasterLink.getChoiceMaster();
                            String choiceMasterName = choiceMaster.getName();
                            String choiceMasterNumber = choiceMaster.getNumber();
                            String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
                            OptionSetChangeItem optionSetChangeItem = new OptionSetChangeItem(type, optionMasterNumber, optionMasterName, optionMasterOR, choiceMasterNumber, choiceMasterName, choiceMasterOR);
                            itemLists.add(optionSetChangeItem);
                        }
                    } else if ("删除".equals(type)) {
                            List<ChoiceMaster> choiceMasterByOption = OptionSetUtil.getChoiceMasterByOption(lastByOptionNumber);
                            for (OptionSetMemberLink memberLink : memberLinks) {
                                ChoiceMaster choiceMaster = memberLink.getChoiceMaster();
                                if(choiceMasterByOption.contains(choiceMaster)){
                                    String choiceMasterName = choiceMaster.getName();
                                    String choiceMasterNumber = choiceMaster.getNumber();
                                    String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
                                    OptionSetChangeItem optionSetChangeItem = new OptionSetChangeItem(type, optionMasterNumber, optionMasterName, optionMasterOR, choiceMasterNumber, choiceMasterName, choiceMasterOR);
                                    itemLists.add(optionSetChangeItem);
                                }
                            }
                    }
                } else if (StringUtils.isNotBlank(choiceNumber)) {
                    Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceNumber);
                    ChoiceMaster choiceMaster = (ChoiceMaster) lastByChoiceNumber.getMaster();
                    String choiceMasterName = choiceMaster.getName();
                    String choiceMasterNumber = choiceMaster.getNumber();
                    String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
                    OptionSetChangeItem optionSetChangeItem = new OptionSetChangeItem(type, choiceMasterNumber, choiceMasterName, choiceMasterOR);
                    itemLists.add(optionSetChangeItem); // 直接添加到累积列表
                }
            } // end items循环

            // 所有变更项处理完成后设置一次
            changeItemDomainDB.setVos(itemLists);
            vos.add(changeItemDomainDB);
        }

        ecnBatchOption.setCHANGECONTENTJSON(objectMapper.writeValueAsString(vos));
        return ecnBatchOption;
    }







//    public static ECNBatchOption addExcelItemToDB(String ecnNumber, String ecnOR, Map<OptionSet, List<ChangeItemDomain>> optionSetListMap) throws WTException, JsonProcessingException {
//        ECNBatchOption ecnBatchOption = new ECNBatchOption();
//        List<ChangeItemDomainDB> vos = new ArrayList<>();
//        ecnBatchOption.setECNNUMBER(ecnNumber);
//        ecnBatchOption.setECNOR(ecnOR);
//        String itemJson = "";
//        for (Map.Entry<OptionSet, List<ChangeItemDomain>> entry : optionSetListMap.entrySet()) {
//            OptionSet optionSet = entry.getKey();
//            // 选项集所有的optionSetMemberLink
//            System.out.println("当前选项集："+optionSet.getName());
//            List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);
//            OptionSetMaster optionSetMaster = (OptionSetMaster) optionSet.getMaster();
//            String optionSetMasterName = optionSetMaster.getName();
//            String optionSetMasterOR = PersistenceUtil.object2Oid(optionSetMaster);
//            ChangeItemDomainDB changeItemDomainDB = new ChangeItemDomainDB(optionSetMasterName, optionSetMasterOR);
//            List<ChangeItemDomain> items = entry.getValue();
//            for (ChangeItemDomain item : items) {
//                List<OptionSetChangeItem> itemLists = new ArrayList<>();
//                String type = item.getType();
//                String optionNumber = item.getOptionNumber();
//                String choiceNumber = item.getChoiceNumber();
//                if (StringUtils.isNotBlank(optionNumber)) {
//                    Option lastByOptionNumber = OptionSetUtil.getLastByOptionNumber(optionNumber);
//                    OptionMaster optionMaster = (OptionMaster) lastByOptionNumber.getMaster();
//                    String optionMasterName = optionMaster.getName();
//                    String optionMasterNumber = optionMaster.getNumber();
//                    String optionMasterOR = PersistenceUtil.object2Oid(optionMaster);
//                    if("添加".equals(type)){
//                        // 根据选项读取全部选择

//                    } else if ("删除".equals(type)) {
//                        // 删除选项下的所有选择 如果存在这些选择的话
//                        List<ChoiceMaster> choiceMasterByOption = OptionSetUtil.getChoiceMasterByOption(lastByOptionNumber);
//                        for (OptionSetMemberLink memberLink : memberLinks) {
//                            ChoiceMaster choiceMaster = memberLink.getChoiceMaster();
//                            if(choiceMasterByOption.contains(choiceMaster)){
//                                String choiceMasterName = choiceMaster.getName();
//                                String choiceMasterNumber = choiceMaster.getNumber();
//                                String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
//                                OptionSetChangeItem optionSetChangeItem = new OptionSetChangeItem(type, optionMasterNumber, optionMasterName, optionMasterOR, choiceMasterNumber, choiceMasterName, choiceMasterOR);
//                                itemLists.add(optionSetChangeItem);
//                            }
//                        }
//                    }
//                } else if (StringUtils.isNotBlank(choiceNumber)) {
//                    Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceNumber);
//                    ChoiceMaster choiceMaster = (ChoiceMaster) lastByChoiceNumber.getMaster();
//                    String choiceMasterName = choiceMaster.getName();
//                    String choiceMasterNumber = choiceMaster.getNumber();
//                    String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
//                    OptionSetChangeItem optionSetChangeItem = new OptionSetChangeItem(type, choiceMasterNumber, choiceMasterName, choiceMasterOR);
//                    itemLists.add(optionSetChangeItem);
//                }
//                changeItemDomainDB.setVos(itemLists);
//            }
//            vos.add(changeItemDomainDB);
//        }
//        ecnBatchOption.setCHANGECONTENTJSON(objectMapper.writeValueAsString(vos));
//
//        return ecnBatchOption;
//    }



    /** 工艺计划获取操作
     * @param
     * @param
     * @return
     */
//    public static List<MPMOperation> getOperationByProcessPlan(MPMProcessPlan processPlan) {
//        List<MPMOperation> list = new ArrayList<>();
//        try {
//            if (processPlan != null) {
//                //查到的是什么
//                QueryResult qr = PersistenceHelper.manager.navigate(processPlan, MPMOperationUsageLink.USES_ROLE, MPMOperationUsageLink.class);
//
//                while (qr.hasMoreElements()) {
//                    MPMOperationMaster operationMaster = (MPMOperationMaster) qr.nextElement();
//
//                    MPMOperation ope = (MPMOperation) VersionControlHelper.service.allVersionsOf(operationMaster).nextElement();
//                    list.add(ope);
//                }
//
//            }
//        } catch (WTException e) {
//            e.printStackTrace();
//        }
//        return list;
//    }
//
//
//
//    /** 工艺计划获取与操作关联关系
//     * @param
//     * @param
//     * @return
//     */
//    public static List<MPMOperationUsageLink> getMPMOperationUsageLink(MPMProcessPlan processPlan) {
//        List<MPMOperationUsageLink> list = new ArrayList<>();
//        try {
//            if (processPlan != null) {
//                //false  返回 MPMOperationUsageLink   true返回 MPMOperation
//                QueryResult qr = StructHelper.service.navigateUses(processPlan, MPMOperationUsageLink.class, false);
//                while (qr.hasMoreElements()) {
//                    MPMOperationUsageLink operationUsageLink = (MPMOperationUsageLink) qr.nextElement();
//                    list.add(operationUsageLink);
//                }
//
//                // 按 operationLabel 排序（处理 null 值）
//                Collections.sort(list, Comparator.comparing(
//                        link -> link.getOperationLabel(), // 或使用方法引用：WTPartUsageLink::getOperationLabel
//                        Comparator.nullsLast(Comparator.naturalOrder())
//                ));
//            }
//        } catch (WTException e) {
//            e.printStackTrace();
//        }
//        return list;
//    }
//
//
//    /**
//     * 根据工艺与操作关联关系获取操作
//     *
//     * @param link
//     * @return WTPart
//     */
//    public static MPMOperation getMPMOperationByLink(MPMOperationUsageLink link) {
//        try {
//            QueryResult qr = VersionControlHelper.service.allVersionsOf(link.getUses());
//            if (qr.hasMoreElements()) {
//                MPMOperation operation = (MPMOperation) qr.nextElement();
//                return operation;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//
//
//    //获取工艺计划相关部件
//    public static  List<WTPart>  getWTPartByProcessPlan(MPMProcessPlan mpmProcessPlan) {
//        List<WTPart> parts = new ArrayList<>();
//        try {
////            QueryResult qr = MPMProcessPlanHelper.service.getWTParts(mpmProcessPlan);
//            QueryResult qr = PersistenceHelper.manager.navigate(mpmProcessPlan, MPMOperationToPartLink.REFERENCES_ROLE,MPMOperationToConsumableLink.class,false);
//            while (qr.hasMoreElements()){
//                WTPartMaster partMaster = (WTPartMaster) qr.nextElement();
//                WTPart part = (WTPart) VersionControlHelper.service.allVersionsOf(partMaster).nextElement();
//                parts.add(part);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return parts;
//    }
//
//    //获取工艺计划相关资源
//    public static  List<MPMOperationToConsumableLink>  getLinkOperation(MPMOperation operation) {
//        List<MPMOperationToConsumableLink> links = new ArrayList<>();
//        try {
//
//            QueryResult link = PersistenceHelper.manager.navigate(operation, MPMOperationToConsumableLink.REFERENCES_ROLE,MPMOperationToConsumableLink.class,false);
//            System.out.println("资源size"+link.size());
////            QueryResult resource = PersistenceHelper.manager.navigate(operation,MPMOperationToConsumableLink.REFERENCES_ROLE,MPMOperationToConsumableLink.class,true);
//            while (link.hasMoreElements()){
//                MPMOperationToConsumableLink operationToConsumableLink  =(MPMOperationToConsumableLink) link.nextElement();
//                links.add(operationToConsumableLink);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return links;
//    }
//
//
//    //获取工艺计划说明方文档   12版本
//    public static  List<WTDocument>  getDescribeDocuments12(MPMOperation operation) {
//        List<WTDocument> links = new ArrayList<>();
//        try {
//            Collection<Object> associatedDescribeDocuments = MPMResourceHelper.service.getAssociatedDescribeDocuments(operation);
//            System.out.println("文档size"+associatedDescribeDocuments.size());
//
//            for (Object associatedDescribeDocument : associatedDescribeDocuments) {
//                System.out.println("文档类型"+associatedDescribeDocument.getClass().getName());
//
//
//                if ( associatedDescribeDocument instanceof ObjectReference){
//                    ObjectReference objectReference =   (ObjectReference) associatedDescribeDocument;
//                    Persistable currentEffectiveObject = objectReference.getCurrentEffectiveObject();
//
//                    if (currentEffectiveObject instanceof WTDocument) {
//
//                        WTDocument doc =(WTDocument) objectReference.getCurrentEffectiveObject();
//                        links.add(doc);
//
//                    }
//
//                }
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return links;
//    }
//
//    //获取工艺计划说明方文档   13版本
//    public static  List<WTDocument>  getDescribeDocuments13(MPMOperation operation) {
//        List<WTDocument> links = new ArrayList<>();
//        try {
//            QueryResult qr = MPMServiceLocator.getInstance().getMPMResourceService().getDescribeDocumentsFromDocumentManageable(operation, null, true);
//            System.out.println("文档size"+qr.size());
//            while (qr.hasMoreElements()){
//                WTDocument doc =  (WTDocument)qr.nextElement();
//                links.add(doc);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return links;
//    }


}
