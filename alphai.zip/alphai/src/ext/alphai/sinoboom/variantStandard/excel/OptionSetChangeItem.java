package ext.alphai.sinoboom.variantStandard.excel;

import java.util.Objects;

public class OptionSetChangeItem {

    private String type;
    private String optionMasterNumber;
    private String optionMasterName;
    private String optionMasterOR;
    private String choiceMasterNumber;
    private String choiceMasterName;
    private String choiceMasterOR;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OptionSetChangeItem that = (OptionSetChangeItem) o;
        return Objects.equals(type, that.type) && Objects.equals(optionMasterOR, that.optionMasterOR) && Objects.equals(choiceMasterOR, that.choiceMasterOR);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, optionMasterOR, choiceMasterOR);
    }

    public OptionSetChangeItem() {
    }

    public OptionSetChangeItem(String type, String choiceMasterNumber, String choiceMasterName, String choiceMasterOR) {
        this.type = type;
        this.choiceMasterNumber = choiceMasterNumber;
        this.choiceMasterName = choiceMasterName;
        this.choiceMasterOR = choiceMasterOR;
    }

    public OptionSetChangeItem(String type, String optionMasterNumber, String optionMasterName, String optionMasterOR, String choiceMasterNumber, String choiceMasterName, String choiceMasterOR) {
        this.type = type;
        this.optionMasterNumber = optionMasterNumber;
        this.optionMasterName = optionMasterName;
        this.optionMasterOR = optionMasterOR;
        this.choiceMasterNumber = choiceMasterNumber;
        this.choiceMasterName = choiceMasterName;
        this.choiceMasterOR = choiceMasterOR;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOptionMasterNumber() {
        return optionMasterNumber;
    }

    public void setOptionMasterNumber(String optionMasterNumber) {
        this.optionMasterNumber = optionMasterNumber;
    }

    public String getOptionMasterName() {
        return optionMasterName;
    }

    public void setOptionMasterName(String optionMasterName) {
        this.optionMasterName = optionMasterName;
    }

    public String getOptionMasterOR() {
        return optionMasterOR;
    }

    public void setOptionMasterOR(String optionMasterOR) {
        this.optionMasterOR = optionMasterOR;
    }

    public String getChoiceMasterNumber() {
        return choiceMasterNumber;
    }

    public void setChoiceMasterNumber(String choiceMasterNumber) {
        this.choiceMasterNumber = choiceMasterNumber;
    }

    public String getChoiceMasterName() {
        return choiceMasterName;
    }

    public void setChoiceMasterName(String choiceMasterName) {
        this.choiceMasterName = choiceMasterName;
    }

    public String getChoiceMasterOR() {
        return choiceMasterOR;
    }

    public void setChoiceMasterOR(String choiceMasterOR) {
        this.choiceMasterOR = choiceMasterOR;
    }
}
