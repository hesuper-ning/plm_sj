package ext.alphai.sinoboom.variantStandard.excel;

import java.util.List;
import java.util.Set;

/**
 * 数据库中结构 用于页面展示与 执行选项集结构修改时作为修改依据
 */
public class ChangeItemDomainDB {
    private String optionSetName;
    private String optionSetMasterOR;
    private Set<OptionSetChangeItem> vos;


    public ChangeItemDomainDB() {
    }

    public ChangeItemDomainDB(String optionSetName, String optionSetMasterOR) {
        this.optionSetName = optionSetName;
        this.optionSetMasterOR = optionSetMasterOR;
    }

    public Set<OptionSetChangeItem> getVos() {
        return vos;
    }

    public void setVos(Set<OptionSetChangeItem> vos) {
        this.vos = vos;
    }

    public String getOptionSetName() {
        return optionSetName;
    }

    public void setOptionSetName(String optionSetName) {
        this.optionSetName = optionSetName;
    }

    public String getOptionSetMasterOR() {
        return optionSetMasterOR;
    }

    public void setOptionSetMasterOR(String optionSetMasterOR) {
        this.optionSetMasterOR = optionSetMasterOR;
    }
}
