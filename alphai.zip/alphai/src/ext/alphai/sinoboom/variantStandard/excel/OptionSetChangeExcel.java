package ext.alphai.sinoboom.variantStandard.excel;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.model.*;
import ext.alphai.sinoboom.variantStandard.domain.ECNBatchOption;
import ext.alphai.sinoboom.variantStandard.domain.ResponseVo;
import ext.alphai.sinoboom.variantStandard.server.OptionSetService;
import ext.alphai.sinoboom.variantStandard.utils.CommonUtil;
import ext.alphai.sinoboom.variantStandard.utils.OptionSetUtil;
import ext.alphai.sinoboom.variantStandard.utils.PersistenceUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.*;
import org.springframework.web.multipart.MultipartFile;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeOrder2;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.util.WTException;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

/**
 *
 */
public class OptionSetChangeExcel {
    static final ObjectMapper objectMapper = new ObjectMapper();
    private static String ADD = "添加";
    private static String DELETE = "删除";
    static ReferenceFactory rf = new ReferenceFactory();
    /**
     * 导入excel添加变更项
     * @param ecnNumber
     * @param ecnOR
     * @param fileIS
     * @return
     */
    /**
     * 导入excel添加变更项
     * @param ecnNumber
     * @param ecnOR
     * @param fileIS
     * @return
     */
    public static ResponseVo addChangeItem(String ecnNumber, String ecnOR, InputStream fileIS) throws Exception {
        String errMsg = "";
        StringBuffer sb = new StringBuffer("Excel 异常"+"\n\t");
        ResponseVo vo = null;

        try {
            // 读取excel
            List<ChangeItemDomain> changeItemDomains = readChangeItems(fileIS);
            if(changeItemDomains.isEmpty()){
                sb.append("请检查模板是否正确填写数据！");
                errMsg = sb.toString();
                return ResponseVo.error(400, errMsg);
            }

            WTChangeOrder2 ecn = (WTChangeOrder2) rf.getReference(ecnOR).getObject();
            List<OptionSet> affectedObjectsByECN = getAffectedObjectsByECN(ecn);
            Map<OptionSet, List<ChangeItemDomain>> optionSetListMap = mapCollections(affectedObjectsByECN, changeItemDomains);

            // 校验excel
            vo = verifyExcel(optionSetListMap);
            if(vo != null){
                return vo;
            }

            // 插入数据库
            ECNBatchOption ecnBatchOption = addExcelItemToDB(ecnNumber, ecnOR, optionSetListMap);

            // 返回待修改的变更项
            int i = OptionSetService.insertOrUpdateECNBatchOption(ecnBatchOption);
            return i>0 ? ResponseVo.success("") : ResponseVo.error(500, "导入出错");
        } catch (Exception e) {
            // 更具体的异常处理
            if (e instanceof EncryptedDocumentException) {
                return ResponseVo.error(400, "Excel 文件已加密，无法读取");
            } else if (e instanceof IOException) {
                return ResponseVo.error(400, "Excel 文件读取失败，请检查文件格式");
            } else {
                return ResponseVo.error(500, "处理 Excel 数据时发生错误: " + e.getMessage());
            }
        }
    }

    /**
     * 添加或修改变更项
     * @param ecnNumber
     * @param ecnOR
     * @param optionSetListMap
     */
    public static ECNBatchOption addExcelItemToDB(String ecnNumber, String ecnOR, Map<OptionSet, List<ChangeItemDomain>> optionSetListMap)
            throws WTException, JsonProcessingException, SQLException {
        ECNBatchOption ecnBatchOption = OptionSetService.getECNBatchOptionByECNOR(ecnOR);
        List<ChangeItemDomainDB> vos = new ArrayList<>();

        if(ecnBatchOption.getECNNUMBER() == null){
            ecnBatchOption = new ECNBatchOption();
            ecnBatchOption.setECNNUMBER(ecnNumber);
            ecnBatchOption.setECNOR(ecnOR);
        } else {
            // 已存在变更项 需要对数据库中的变更项进行修改
            String changeContentJson = ecnBatchOption.getCHANGECONTENTJSON();
            if(isValidJson(changeContentJson)){
                vos = objectMapper.readValue(changeContentJson, new TypeReference<List<ChangeItemDomainDB>>() {});
            }
        }

        // 将现有vos转换为Map，以便快速查找
        Map<String, ChangeItemDomainDB> vosMap = new HashMap<>();
        for (ChangeItemDomainDB db : vos) {
            vosMap.put(db.getOptionSetMasterOR(), db);
        }

        // 处理新的变更项
        for (Map.Entry<OptionSet, List<ChangeItemDomain>> entry : optionSetListMap.entrySet()) {
            OptionSet optionSet = entry.getKey();
            List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);
            OptionSetMaster optionSetMaster = (OptionSetMaster) optionSet.getMaster();
            String optionSetMasterName = optionSetMaster.getName();
            String optionSetMasterOR = PersistenceUtil.object2Oid(optionSetMaster);

            // 检查是否已存在该选项集的变更项
            ChangeItemDomainDB changeItemDomainDB = vosMap.get(optionSetMasterOR);
            Set<OptionSetChangeItem> itemLists;

            if (changeItemDomainDB != null) {
                // 如果已存在，获取现有的变更项集合
                itemLists = new HashSet<>(changeItemDomainDB.getVos());
            } else {
                // 如果不存在，创建新的变更项对象和集合
                changeItemDomainDB = new ChangeItemDomainDB(optionSetMasterName, optionSetMasterOR);
                itemLists = new HashSet<>();
            }

            List<ChangeItemDomain> items = entry.getValue();
            for (ChangeItemDomain item : items) {
                String type = item.getType();
                String optionNumber = item.getOptionNumber();
                String choiceNumber = item.getChoiceNumber();

                if (StringUtils.isNotBlank(choiceNumber)) {
                    Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceNumber);
                    ChoiceMaster choiceMaster = (ChoiceMaster) lastByChoiceNumber.getMaster();
                    // ChoiceMaster 找OptionMaster
                    OptionMaster optionChoiceMasterLinkByChoiceMaster = OptionSetUtil.getOptionChoiceMasterLinkByChoiceMaster(choiceMaster);
                    String choiceMasterName = choiceMaster.getName();
                    String choiceMasterNumber = choiceMaster.getNumber();
                    String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
                    OptionSetChangeItem optionSetChangeItem = new OptionSetChangeItem(type, choiceMasterNumber, choiceMasterName, choiceMasterOR);
                    optionSetChangeItem.setOptionMasterOR(PersistenceUtil.object2Oid(optionChoiceMasterLinkByChoiceMaster));
                    optionSetChangeItem.setOptionMasterName(optionChoiceMasterLinkByChoiceMaster.getName());
                    optionSetChangeItem.setOptionMasterNumber(optionChoiceMasterLinkByChoiceMaster.getNumber());
                    itemLists.add(optionSetChangeItem);
                } else if (StringUtils.isNotBlank(optionNumber)) {
                    Option lastByOptionNumber = OptionSetUtil.getLastByOptionNumber(optionNumber);
                    OptionMaster optionMaster = (OptionMaster) lastByOptionNumber.getMaster();
                    String optionMasterName = optionMaster.getName();
                    String optionMasterNumber = optionMaster.getNumber();
                    String optionMasterOR = PersistenceUtil.object2Oid(optionMaster);

                    if(ADD.equals(type)){
                        List<OptionChoiceMasterLink> optionChoiceMasterLinkByOption = OptionSetUtil.getOptionChoiceMasterLinkByOption(lastByOptionNumber);
                        for (OptionChoiceMasterLink optionChoiceMasterLink : optionChoiceMasterLinkByOption) {
                            ChoiceMaster choiceMaster = optionChoiceMasterLink.getChoiceMaster();
                            String choiceMasterName = choiceMaster.getName();
                            String choiceMasterNumber = choiceMaster.getNumber();
                            String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
                            OptionSetChangeItem optionSetChangeItem = new OptionSetChangeItem(type, optionMasterNumber, optionMasterName, optionMasterOR, choiceMasterNumber, choiceMasterName, choiceMasterOR);
                            itemLists.add(optionSetChangeItem);
                        }
                    } else if (DELETE.equals(type)) {
                        List<ChoiceMaster> choiceMasterByOption = OptionSetUtil.getChoiceMasterByOption(lastByOptionNumber);
                        for (OptionSetMemberLink memberLink : memberLinks) {
                            ChoiceMaster choiceMaster = memberLink.getChoiceMaster();
                            if(choiceMasterByOption.contains(choiceMaster)){
                                String choiceMasterName = choiceMaster.getName();
                                String choiceMasterNumber = choiceMaster.getNumber();
                                String choiceMasterOR = PersistenceUtil.object2Oid(choiceMaster);
                                OptionSetChangeItem optionSetChangeItem = new OptionSetChangeItem(type, optionMasterNumber, optionMasterName, optionMasterOR, choiceMasterNumber, choiceMasterName, choiceMasterOR);
                                itemLists.add(optionSetChangeItem);
                            }
                        }
                    }
                }
            }

            // 设置变更项集合
            changeItemDomainDB.setVos(new HashSet<>(itemLists));

            // 如果是新创建的变更项，添加到vos列表和映射中
            if (!vosMap.containsKey(optionSetMasterOR)) {
                vos.add(changeItemDomainDB);
                vosMap.put(optionSetMasterOR, changeItemDomainDB);
            }
        }

        ecnBatchOption.setCHANGECONTENTJSON(objectMapper.writeValueAsString(vos));
        return ecnBatchOption;
    }


    /**
     * 检查excel填写的数据是否合法
     * @return
     */
    public static ResponseVo verifyExcel(Map<OptionSet, List<ChangeItemDomain>> optionSetListMap) throws WTException {
        String errMsg = "";
        StringBuffer sb = new StringBuffer("Excel 异常"+"\n\t");
        // 是否有错误信息
        boolean hasErr = false;
        for (Map.Entry<OptionSet, List<ChangeItemDomain>> entry : optionSetListMap.entrySet()) {
            OptionSet optionSet = entry.getKey();
            // 当前选项集所有与选择的链接关系
            List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);
            // 获取选项集下所有的选项对象
            List<Option> optionByOptionSet = OptionSetUtil.getOptionByOptionSet(optionSet);
            List<ChangeItemDomain> items = entry.getValue();
            for (ChangeItemDomain item : items) {
                int line = item.getLine();
                String optionSetName = item.getOptionSetName();
                String optionNumber = item.getOptionNumber();
                String choiceNumber = item.getChoiceNumber();
                String type = item.getType();
                if(ADD.equals(type)){
                    // 如果添加选项
                    if(!StringUtils.isBlank(optionNumber)){
                        // 选项集添加选项 默认是添加所有选项下所有选择
                        Option lastByOptionNumber = OptionSetUtil.getLastByOptionNumber(optionNumber);
                        if(lastByOptionNumber == null){
                            sb.append("第 "+line+" 行 添加 发现异常 选项编号："+optionNumber+" 不存在"+"\n\t");
                            hasErr = true;
                            continue;
                        }
                        // 已存在选项
                        if (optionByOptionSet.contains(lastByOptionNumber)) {
                            sb.append("第 "+line+" 行 添加 发现异常 选项编号："+optionNumber+" 已存在于选项集："+optionSetName+"\n\t");
                            hasErr = true;
                        }
                    } else if (!StringUtils.isBlank(choiceNumber)) {
                        Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceNumber);
                        if(lastByChoiceNumber == null){
                            sb.append("第 "+line+" 行 添加 发现异常 选择编号："+choiceNumber+" 不存在"+"\n\t");
                            hasErr = true;
                            continue;
                        }
                        ChoiceMaster choiceMaster = (ChoiceMaster) lastByChoiceNumber.getMaster();
                        // 添加指定选择
                        boolean isExt = false;
                        for (OptionSetMemberLink memberLink : memberLinks) {
                            ChoiceMaster linkChoiceMaster = memberLink.getChoiceMaster();
                            if(linkChoiceMaster.equals(choiceMaster)){
                                isExt = true;
                            }
                        }
                        // 如果已存在就抛出异常
                        if(isExt){
                            sb.append("第 "+line+" 行 添加 发现异常 选择编号："+choiceNumber+" 已存在于 选项集："+optionSetName+"\n\t");
                            hasErr = true;
                        }
                    }
                } else if (DELETE.equals(type)) {
                    // 如果删除选项
                    if(!StringUtils.isBlank(optionNumber)){
                        Option lastByOptionNumber = OptionSetUtil.getLastByOptionNumber(optionNumber);
                        if(lastByOptionNumber == null){
                            sb.append("第 "+line+" 行 删除 发现异常 选项编号："+optionNumber+" 不存在"+"\n\t");
                            hasErr = true;
                            continue;
                        }
                        // 可能出现版本冲突问题
                        if (!optionByOptionSet.contains(lastByOptionNumber)) {
                            // 选项集里没有这个编号的选项
                            sb.append("第 "+line+" 行 删除 发现异常 选项编号："+optionNumber+" 不存在 于"+optionSetName+"结构中"+"\n\t");
                            hasErr = true;
                        }
                    } else if (!StringUtils.isBlank(choiceNumber)) {
                        Choice lastByChoiceNumber = OptionSetUtil.getLastByChoiceNumber(choiceNumber);
                        if(lastByChoiceNumber == null){
                            sb.append("第 "+line+" 行 删除 发现异常 选择编号："+choiceNumber+" 不存在"+"\n\t");
                            hasErr = true;
                            continue;
                        }
                        ChoiceMaster choiceMaster = (ChoiceMaster) lastByChoiceNumber.getMaster();
                        // 获取所有optionsetMemberLink 检查有没有该ChoiceMaster的对象
                        // 默认不存在
                        boolean isExt = false;
                        for (OptionSetMemberLink memberLink : memberLinks) {
                            ChoiceMaster memberLinkChoiceMaster = memberLink.getChoiceMaster();
                            if(memberLinkChoiceMaster.equals(choiceMaster)){
                                isExt = true;
                            }
                        }
                        // 如果选项集原本没有与这个编号选择的链接也视为一个异常
                        if(!isExt){
                            sb.append("第 "+line+" 行 删除 发现异常 选择编号："+choiceNumber+" 不存在 于"+optionSetName+"结构中"+"\n\t");
                            hasErr = true;
                        }
                    }
                } else {
                    sb.append("第 "+line+" 行 操作类型异常"+"\n\t");
                    hasErr = true;
                }
            }
        }
        // 处理返回结果sb
        if(hasErr){
            errMsg = sb.toString();
            return ResponseVo.error(400, errMsg);
        }
        return null;
    }


    /**
     * 读取文件excel并转成对象
     * @param fileIS
     * @return
     * @throws Exception
     */
    /**
     * 读取文件excel并转成对象
     * @param fileIS
     * @return
     * @throws Exception
     */
    public static List<ChangeItemDomain> readChangeItems(InputStream fileIS) throws Exception {
        List<ChangeItemDomain> result = new ArrayList<>();

        try (Workbook workbook = WorkbookFactory.create(fileIS)) {
            Sheet sheet = workbook.getSheetAt(0);
            DataFormatter formatter = new DataFormatter(); // 专门处理字符串格式

            // 从第2行开始读取（跳过标题行）
            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) continue;

                ChangeItemDomain item = new ChangeItemDomain();
                item.setLine(rowIndex + 1); // 设置Excel行号

                item.setOptionSetName(getFormattedStringValue(row.getCell(0), formatter));
                item.setType(getFormattedStringValue(row.getCell(1), formatter));
                item.setOptionNumber(getFormattedStringValue(row.getCell(2), formatter));
                item.setChoiceNumber(getFormattedStringValue(row.getCell(3), formatter));

                result.add(item);
            }
        } catch (Exception e) {
            // 重新抛出异常，由上层处理
            throw new Exception("读取 Excel 文件失败: " + e.getMessage(), e);
        }

        return result;
    }

    // 专门处理字符串格式的方法
    private static String getFormattedStringValue(Cell cell, DataFormatter formatter) {
        return cell == null ? "" : formatter.formatCellValue(cell).trim();
    }
    /**
     * 用ECN获取受影响对象里的选项集集合
     * @return
     */
    public static List<OptionSet> getAffectedObjectsByECN(WTChangeOrder2 ecn) throws WTException {
        QueryResult qr = ChangeHelper2.service.getChangeablesBefore(ecn);
        return CommonUtil.getListFromQR(qr, OptionSet.class);
    }

    /**
     * 集合合并 避免多余循环降低运行效率
     * @param optionSets
     * @param changeItemDomains
     * @return
     */
    public static Map<OptionSet, List<ChangeItemDomain>> mapCollections(
            List<OptionSet> optionSets,
            List<ChangeItemDomain> changeItemDomains) {

        // 步骤1: 先按名称分组ChangeItemDomain
        Map<String, List<ChangeItemDomain>> nameToItemsMap = changeItemDomains.stream()
                .collect(Collectors.groupingBy(ChangeItemDomain::getOptionSetName));

        // 步骤2: 创建最终结果映射
        Map<OptionSet, List<ChangeItemDomain>> resultMap = new HashMap<>();

        // 步骤3: 遍历所有OptionSet
        for (OptionSet optionSet : optionSets) {
            String optionSetName = optionSet.getName();

            // 获取匹配的ChangeItemDomain列表（如果不存在则用空列表）
            List<ChangeItemDomain> matchedItems = nameToItemsMap.getOrDefault(
                    optionSetName,
                    new ArrayList<>()
            );

            // 将OptionSet和匹配的列表放入结果映射
            resultMap.put(optionSet, matchedItems);
        }

        return resultMap;
    }

    /**
     * 判断字符串是否是JSON
     * @param jsonString
     * @return
     */
    public static boolean isValidJson(String jsonString) {
        if (jsonString == null || jsonString.trim().isEmpty()) {
            return false;
        }
        try {
            objectMapper.readTree(jsonString);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
