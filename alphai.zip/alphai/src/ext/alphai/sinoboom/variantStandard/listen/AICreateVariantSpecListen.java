package ext.alphai.sinoboom.variantStandard.listen;
import com.ptc.wpcfg.doc.VariantSpec;
import ext.alphai.sinoboom.variantStandard.utils.IBAUtil;
import wt.events.KeyedEventListener;
import wt.fc.Persistable;
import wt.fc.PersistenceManagerEvent;
import wt.part.WTPart;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;

import java.io.Serializable;

/**
 * 创建变型规范监听器
 */
public class AICreateVariantSpecListen extends StandardManager implements AICreateVariantSpecListenIF, Serializable {
    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = AICreateVariantSpecListen.class.getName();
    private KeyedEventListener listener;
    // 产品外销类型
    public static final String Product_Model = "ProductModel";

    public AICreateVariantSpecListen() {
    }


    public static AICreateVariantSpecListen newAICreateVariantSpecListen() throws WTException {
        AICreateVariantSpecListen instance = new AICreateVariantSpecListen();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new AICreateVariantSpecListen.WCListenerEventListener(getConceptualClassname());
        //创建对象

//        getManagerService().addEventListener(this.listener, WorkInProgressServiceEvent.generateEventKey(WorkInProgressServiceEvent.POST_CHECKIN ));//新检入
        getManagerService().addEventListener(this.listener, PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_STORE));//创建
    }


    class WCListenerEventListener extends ServiceEventListenerAdapter {

        public WCListenerEventListener(String s) {
            super(s);
        }

        @Override
        public void notifyVetoableEvent(Object event) throws Exception {

            if (event instanceof PersistenceManagerEvent) {
//                System.out.println("AI监听创建事件");
                PersistenceManagerEvent eve = (PersistenceManagerEvent) event;
                Object target = eve.getEventTarget();
//                System.out.println(target);
                processVS(target);
            }
//            else if (event instanceof WorkInProgressServiceEvent){
//                System.out.println("检入事件");
//                WorkInProgressServiceEvent eve = (WorkInProgressServiceEvent) event;
//                Object target = eve.getEventTarget();
////                System.out.println(target);
//                movePart(target);
//            }

        }
    }



    public static void processVS(Object target) throws WTException {
        if(target instanceof VariantSpec){
            VariantSpec variantSpec = (VariantSpec) target;
            IBAUtil ibaUtil = new IBAUtil();
            Persistable object = variantSpec.getGenericizableReference().getObject();
//            System.out.println(variantSpec.getName()+" 变型规范超级BOM："+object);
            if(object instanceof WTPart){
                WTPart part = (WTPart) object;
                IBAUtil partIBA = new IBAUtil(part);
                String partProductModel = partIBA.getIBAValue(Product_Model);
//                System.out.println("变型规范超级BOM 产品外销型号值："+partProductModel);
                try {
                    ibaUtil.setIBAAttribute4AllType(variantSpec, Product_Model, partProductModel);
//                    System.out.println("设置完成");
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new WTException(e.getMessage());
                }
            }
        }
    }
}
