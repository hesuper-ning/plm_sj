package ext.alphai.sinoboom.variantStandard.listen;

/**
 *
 */
public interface AICreateVariantSpecListenIF {
}
