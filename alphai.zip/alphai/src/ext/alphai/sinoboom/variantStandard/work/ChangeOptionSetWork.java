package ext.alphai.sinoboom.variantStandard.work;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.model.ChoiceMaster;
import com.ptc.windchill.option.model.OptionSet;
import com.ptc.windchill.option.model.OptionSetMaster;
import com.ptc.windchill.option.model.OptionSetMemberLink;
import ext.alphai.sinoboom.variantStandard.domain.ECNBatchOption;
import ext.alphai.sinoboom.variantStandard.excel.ChangeItemDomainDB;
import ext.alphai.sinoboom.variantStandard.excel.OptionSetChangeItem;
import ext.alphai.sinoboom.variantStandard.server.OptionSetService;
import ext.alphai.sinoboom.variantStandard.utils.CommonUtil;
import ext.alphai.sinoboom.variantStandard.utils.OptionSetUtil;
import ext.alphai.sinoboom.variantStandard.utils.PersistenceUtil;
import org.apache.commons.lang3.StringUtils;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeOrder2;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Mastered;
import wt.vc.wip.WorkInProgressHelper;
import wt.pom.Transaction;
import java.sql.SQLException;
import java.util.*;

/**
 * 表达式执行修改选项集结构方法
 */
public class ChangeOptionSetWork {
    static final ObjectMapper objectMapper = new ObjectMapper();
    private static String ADD = "添加";
    private static String DELETE = "删除";
    static ReferenceFactory rf = new ReferenceFactory();
    public static String processChangeOptionSet(WTObject pbo) throws SQLException, JsonProcessingException, WTException, WTPropertyVetoException {
        String respJson = "";
        if(pbo instanceof WTChangeOrder2){
            WTChangeOrder2 order2 = (WTChangeOrder2) pbo;
            // 获取ECN的产生的对象
            List<OptionSet> ecnResultingObjects = getECNResultingObjects(order2);
            // 查询
            String ecnOR = PersistenceUtil.object2Oid(order2);
            ECNBatchOption ecnBatchOption = OptionSetService.getECNBatchOptionByECNOR(ecnOR);
            String ecnor = ecnBatchOption.getECNOR();
            if(StringUtils.isNotBlank(ecnor)){
                String changecontentjson = ecnBatchOption.getCHANGECONTENTJSON();
                List<ChangeItemDomainDB> vos = objectMapper.readValue(changecontentjson, new TypeReference<List<ChangeItemDomainDB>>() {});
                // 执行结构修改 返回结果json
                respJson = process(ecnResultingObjects, vos);
            }
        }
        return respJson;
    }

    /**
     * 执行修改结构
     * @param ecnResultingObjects
     * @param vos
     */
    public static String process(List<OptionSet> ecnResultingObjects, List<ChangeItemDomainDB> vos) throws WTException, JsonProcessingException, WTPropertyVetoException {
        String respJson = "";
        List<ProcessResultVo> resultVos = new ArrayList<>();

        for (OptionSet optionSet : ecnResultingObjects) {
            // 提取事务
            Transaction trx = null;
            try {
                trx= new Transaction();
                trx.start();
                // 检出选项集
                optionSet = (OptionSet) WorkInProgressHelper.service.checkout(optionSet,WorkInProgressHelper.service.getCheckoutFolder(),"").getWorkingCopy();
                OptionSetMaster optionSetMaster = (OptionSetMaster) optionSet.getMaster();
                String optionSetMasterOR = PersistenceUtil.object2Oid(optionSetMaster);
                for (ChangeItemDomainDB vo : vos) {
                    String voMasterOR = vo.getOptionSetMasterOR();
                    if(optionSetMasterOR.equals(voMasterOR)){
                        Set<OptionSetChangeItem> items = vo.getVos();
                        for (OptionSetChangeItem item : items) {
                            String type = item.getType();
                            String choiceMasterOR = item.getChoiceMasterOR();
                            ProcessResultVo resultVo = new ProcessResultVo();
                            ChoiceMaster choiceMaster = (ChoiceMaster) rf.getReference(choiceMasterOR).getObject();
                            try {
                                if(ADD.equals(type)){
                                    OptionSetUtil.createOptionSetChoiceLink(optionSet, choiceMaster);
                                } else if (DELETE.equals(type)) {
                                    // 获取选项集所有MemberLink
                                    List<OptionSetMemberLink> memberLinks = OptionSetUtil.getOptionSetMemberLinkByOptionSet(optionSet);
                                    for (OptionSetMemberLink memberLink : memberLinks) {
                                        ChoiceMaster choiceMasterByLink = memberLink.getChoiceMaster();
                                        if(choiceMaster.equals(choiceMasterByLink)){
                                            PersistenceHelper.manager.delete(memberLink);
                                        }
                                    }
                                }
                                resultVo.setResult(true);
                                resultVo.setOptionSetName(optionSetMaster.getName());
                                resultVo.setType(type);
                                resultVo.setChoiceMasterName(choiceMaster.getName());
                            } catch (WTException e){
                                e.printStackTrace();
                                resultVo.setResult(false);
                                resultVo.setOptionSetName(optionSetMaster.getName());
                                resultVo.setType(type);
                                resultVo.setChoiceMasterName(choiceMaster.getName());
                                resultVo.setErrMsg(e.getMessage());
                            }
                            resultVos.add(resultVo);
                        }
                    }
                }
                // 检入选项集
                WorkInProgressHelper.service.checkin(optionSet ,"checkedin");
                trx.commit();
                trx = null;
            }catch (Exception e){
                e.printStackTrace();
            } finally {
                if(trx!=null){
                    try {
                        trx.rollback();
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }
        respJson = objectMapper.writeValueAsString(resultVos);
        return respJson;
    }





    /**
     * 获取ECN产生的对象集合
     * @param ecn
     * @return
     */
    public static List<OptionSet> getECNResultingObjects(WTChangeOrder2 ecn) throws WTException {
        List<OptionSet> vos = new ArrayList<>();
        QueryResult qr = ChangeHelper2.service.getChangeablesAfter(ecn);
        vos = CommonUtil.getListFromQR(qr, OptionSet.class);
        return vos;
    }
}
