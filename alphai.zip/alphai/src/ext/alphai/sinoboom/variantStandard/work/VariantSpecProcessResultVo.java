package ext.alphai.sinoboom.variantStandard.work;

/**
 * 变型规范流程修改结果
 */
public class VariantSpecProcessResultVo {
    private String type;
    private String variantSpecNumber;
    private boolean result;
    private String choiceMasterName;
    private String errMsg;

    public VariantSpecProcessResultVo(String type, String variantSpecNumber, boolean result, String choiceMasterName, String errMsg) {
        this.type = type;
        this.variantSpecNumber = variantSpecNumber;
        this.result = result;
        this.choiceMasterName = choiceMasterName;
        this.errMsg = errMsg;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public VariantSpecProcessResultVo() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVariantSpecNumber() {
        return variantSpecNumber;
    }

    public void setVariantSpecNumber(String variantSpecNumber) {
        this.variantSpecNumber = variantSpecNumber;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getChoiceMasterName() {
        return choiceMasterName;
    }

    public void setChoiceMasterName(String choiceMasterName) {
        this.choiceMasterName = choiceMasterName;
    }
}
