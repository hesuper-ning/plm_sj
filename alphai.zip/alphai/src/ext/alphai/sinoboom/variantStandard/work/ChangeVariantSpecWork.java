package ext.alphai.sinoboom.variantStandard.work;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.filter.ATONavigationFilterHelper;
import com.ptc.windchill.option.model.*;
import com.ptc.wpcfg.deliverables.VariantSpecDeliverableLink;
import com.ptc.wpcfg.doc.DocHelper;
import com.ptc.wpcfg.doc.VariantSpec;
import com.ptc.wpcfg.doc.VariantSpecMaster;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.ChangeVsItemDomainDB;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.ECNBatchVariantSpec;
import ext.alphai.sinoboom.variantStandard.domain.vsVo.VariantSpecChangeItem;
import ext.alphai.sinoboom.variantStandard.server.VariantSpecServer;
import ext.alphai.sinoboom.variantStandard.utils.CommonUtil;
import ext.alphai.sinoboom.variantStandard.utils.IBAUtil;
import ext.alphai.sinoboom.variantStandard.utils.OptionSetUtil;
import ext.alphai.sinoboom.variantStandard.utils.PersistenceUtil;
import ext.cirpoint.integration.erp.clients.mpm.processor.VariantAssignProcess;
import org.apache.commons.lang3.StringUtils;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeOrder2;
import wt.fc.*;
import wt.fc.collections.WTCollection;
import wt.filter.NavigationCriteria;
import wt.filter.NavigationFilterHelper;
import wt.part.WTPart;
import wt.pom.Transaction;
import wt.pom.WTConnection;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * 变型规范结构修改 流程表达式
 */
public class ChangeVariantSpecWork {
    static final ObjectMapper objectMapper = new ObjectMapper();
    private static String ADD = "添加";
    private static String DELETE = "删除";
    // 变型规范修改结果表示
    private static String AI_VARINANT_INDEX = "AI_VARINANT_INDEX";
    static ReferenceFactory rf = new ReferenceFactory();
    public static String processChangeVariantSpec(WTObject pbo) throws SQLException, JsonProcessingException, WTException, WTPropertyVetoException {
        String respJson = "";
        if(pbo instanceof WTChangeOrder2){
            WTChangeOrder2 order2 = (WTChangeOrder2) pbo;
            // 获取ECN的产生的对象
            List<VariantSpec> ecnResultingObjects = getECNResultingObjects(order2);
            List<WTPart> wtPartList = getECNResultingWTParts(order2);
            // 查询
            String ecnOR = PersistenceUtil.object2Oid(order2);
            ECNBatchVariantSpec ecnBatchVariantSpecByECNOR = VariantSpecServer.getECNBatchVariantSpecByECNOR(ecnOR);
            String ecnor = ecnBatchVariantSpecByECNOR.getECNOR();
            if(StringUtils.isNotBlank(ecnor)){
                String changecontentjson = ecnBatchVariantSpecByECNOR.getCHANGECONTENTJSON();
                List<ChangeVsItemDomainDB> vos = objectMapper.readValue(changecontentjson, new TypeReference<List<ChangeVsItemDomainDB>>() {});
                // 执行结构修改 返回结果json
                respJson = process(wtPartList,ecnResultingObjects, vos);
            }
        }
        return respJson;
    }


    /**
     * 执行修改变型规范和选择关系
     * @param ecnResultingObjects
     * @param vos
     * @return
     */
    public static String process(List<WTPart> wtPartList, List<VariantSpec> ecnResultingObjects, List<ChangeVsItemDomainDB> vos) throws JsonProcessingException {
        String respJson = "";
        List<VariantSpecProcessResultVo> resultVos = new ArrayList<>();
        IBAUtil vsIBA = new IBAUtil();
        for (VariantSpec ecnResultingObject : ecnResultingObjects) {

            // 提取事务
            Transaction trx = null;
            try {
                trx= new Transaction();
                trx.start();
                // 检出检入
                VariantSpec workingCopy = null;
                workingCopy = (VariantSpec)WorkInProgressHelper.service.checkout(ecnResultingObject,WorkInProgressHelper.service.getCheckoutFolder(),"").getWorkingCopy();
                workingCopy = (VariantSpec)WorkInProgressHelper.service.checkin(workingCopy ,"checkedin");
                String variantSpecNumber = workingCopy.getNumber();
                // 再绑定变型规范和可交付结果
                for (WTPart wtPart : wtPartList) {
                    if(variantSpecNumber.equals(wtPart.getNumber())){
                        VariantSpecServer.createVariantSpecDeliverableLink(wtPart, workingCopy);
                    }
                }

                VariantSpecMaster variantSpecMaster = (VariantSpecMaster) workingCopy.getMaster();
                String variantSpecMasterOR = PersistenceUtil.object2Oid(variantSpecMaster);
                for (ChangeVsItemDomainDB vo : vos) {
                    if(variantSpecMasterOR.equals(vo.getVariantSpecMasterOR())){
                        Set<VariantSpecChangeItem> variantSpecChangeItems = vo.getVos();
                        for (VariantSpecChangeItem variantSpecChangeItem : variantSpecChangeItems) {
                            String type = variantSpecChangeItem.getType();
                            String choiceMasterOR = variantSpecChangeItem.getChoiceMasterOR();
                            VariantSpecProcessResultVo voResult = new VariantSpecProcessResultVo();
                            ChoiceMaster choiceMaster = (ChoiceMaster) rf.getReference(choiceMasterOR).getObject();
                            try {
                                if(ADD.equals(type)){
                                    addChoice2VariantSpect(workingCopy, choiceMaster);
                                } else if (DELETE.equals(type)) {
                                    deleteChoice2VariantSpect(workingCopy, choiceMaster);
//                                    deleteChoiceBySQL(String.valueOf(variantSpecMaster.getPersistInfo().getObjectIdentifier().getId()), String.valueOf(choiceMaster.getPersistInfo().getObjectIdentifier().getId()));
                                }
                                voResult.setResult(true);
                                voResult.setVariantSpecNumber(variantSpecMaster.getName());
                                voResult.setType(type);
                                voResult.setChoiceMasterName(choiceMaster.getName());
                            } catch (Exception e){
                                e.printStackTrace();
                                voResult.setResult(false);
                                voResult.setVariantSpecNumber(variantSpecMaster.getName());
                                voResult.setType(type);
                                voResult.setChoiceMasterName(choiceMaster.getName());
                                voResult.setErrMsg(e.getMessage());
                            }
                            resultVos.add(voResult);
                        }
                    }
                }
                // 给修改过结构的变型规范对象IBA 属性添加标记

                vsIBA.setIBAAttribute4AllType(workingCopy, AI_VARINANT_INDEX, "ok");
                trx.commit();
                trx = null;
            }catch (Exception e){
                e.printStackTrace();
            } finally {
                if(trx!=null){
                    try {
                        trx.rollback();
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }

        respJson = objectMapper.writeValueAsString(resultVos);
        return respJson;
    }

    /**
     * 修改变型规范的选项集为最新版本
     * @param variantSpec
     */
    public static void updateVsOptionSetToLatestVersion(VariantSpec variantSpec) throws WTException, WTPropertyVetoException {
        OptionSet optionSet = DocHelper.service.getOptionSet(variantSpec);
//        OptionSetMaster optionSetMaster = (OptionSetMaster) optionSet.getMaster();
        OptionSet optionSetByNameLatestVersion = OptionSetUtil.getOptionSetByName(optionSet.getName());
        // 如果变型规范的版本绑定的不是最新版本就修改
        if(!optionSet.equals(optionSetByNameLatestVersion)){
            ATONavigationFilter atoNavigationFilter = DocHelper.service.getATONavigationFilter(variantSpec);
            atoNavigationFilter.setOptionSet(optionSetByNameLatestVersion);
            PersistenceServerHelper.manager.update(atoNavigationFilter);
        }
    }


    /**
     * 获取ECN产生的对象集合
     * @param ecn
     * @return
     */
    public static List<VariantSpec> getECNResultingObjects(WTChangeOrder2 ecn) throws WTException {
        List<VariantSpec> vos = new ArrayList<>();
        QueryResult qr = ChangeHelper2.service.getChangeablesAfter(ecn);
        vos = CommonUtil.getListFromQR(qr, VariantSpec.class);
        return vos;
    }


    /**
     * 获取ECN产生的对象集合
     * @param ecn
     * @return
     */
    public static List<WTPart> getECNResultingWTParts(WTChangeOrder2 ecn) throws WTException {
        List<WTPart> vos = new ArrayList<>();
        QueryResult qr = ChangeHelper2.service.getChangeablesAfter(ecn);
        vos = CommonUtil.getListFromQR(qr, WTPart.class);
        return vos;
    }

    /**
     * sql删除相关变体规范 返回值为影响的行数
     * @return
     */
    public static int deleteChoiceBySQL(String variantSpecMasterIDA2A2, String choiceMasterIDA2A2){
        int result = 0;
        WTConnection connection = null;
        PreparedStatement checkStmt1 = null;
        PreparedStatement checkStmt2 = null;
        PreparedStatement checkStmt3 = null;
        PreparedStatement deleteStmt = null;
        ResultSet rs1 = null;
        ResultSet rs2 = null;
        ResultSet rs3 = null;

        try {
            connection = CommonUtil.getWTConnection();

            // 1. 查询最新版变型规范的基础信息
            String sql1 = "SELECT IDA2A2,IDA3D10 FROM VARIANTSPEC WHERE IDA3MASTERREFERENCE = ? AND LATESTITERATIONINFO='1'";
            checkStmt1 = connection.prepareStatement(sql1);
            checkStmt1.setString(1, variantSpecMasterIDA2A2);
            rs1 = checkStmt1.executeQuery();

            String ida2a2 = null;
            String ida3d10 = null;
            if (rs1.next()) {
                ida2a2 = rs1.getString("IDA2A2");
                ida3d10 = rs1.getString("IDA3D10");
            }

            if (ida2a2 == null || ida3d10 == null) {
                return 0; // 没有找到对应的变型规范记录
            }

            // 2. 查询 ATONavigationFilter 的 IDA2A2
            String sql2 = "SELECT IDA2A2 FROM ATONavigationFilter WHERE idA3A4 = ?";
            checkStmt2 = connection.prepareStatement(sql2);
            checkStmt2.setString(1, ida3d10);
            rs2 = checkStmt2.executeQuery();

            String atoNavigationFilterIda2a2 = null;
            if (rs2.next()) {
                atoNavigationFilterIda2a2 = rs2.getString("IDA2A2");
            }

            if (atoNavigationFilterIda2a2 == null) {
                return 0; // 没有找到对应的ATO导航过滤器记录
            }

            // 3. 查询 ATONavigationFilterChoiceLink 的信息，找到IDA3B5等于choiceMasterIDA2A2的记录
            String sql3 = "SELECT IDA2A2 FROM ATONavigationFilterChoiceLink WHERE IDA3A5 = ? ORDER BY SELECTIONORDER";
            checkStmt3 = connection.prepareStatement(sql3);
            checkStmt3.setString(1, atoNavigationFilterIda2a2);
            rs3 = checkStmt3.executeQuery();

            String deleteIda2a2 = null;
            while (rs3.next()) {
                String ida3b5 = rs3.getString("IDA3B5");
                if (choiceMasterIDA2A2.equals(ida3b5)) {
                    deleteIda2a2 = rs3.getString("IDA2A2");
                    break; // 找到匹配的记录，退出循环
                }
            }

            if (deleteIda2a2 == null) {
                return 0; // 没有找到匹配的记录
            }

            // 4. 执行删除操作
            String deleteSql = "DELETE FROM ATONavigationFilterChoiceLink WHERE IDA2A2 = ?";
            deleteStmt = connection.prepareStatement(deleteSql);
            deleteStmt.setString(1, deleteIda2a2);

            result = deleteStmt.executeUpdate();

            return result;

        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        } finally {
            // 严格按照原代码的释放规则关闭资源
            try { if (rs1 != null) rs1.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (rs2 != null) rs2.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (rs3 != null) rs3.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (checkStmt1 != null) checkStmt1.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (checkStmt2 != null) checkStmt2.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (checkStmt3 != null) checkStmt3.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (deleteStmt != null) deleteStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    /**
     * 添加页面  变型规范添加选择
     * -- 输入变体规范编号，查询变体规范主数据的IDA2A2
     * SELECT IDA2A2,NAME from VariantSpecMaster WHERE VARIANTSPECNUMBER='00061'
     * -- 367191
     *
     * -- 通过VariantSpecMaster 要先创建wt.filter.NavigationCriteria 对象
     *
     * -- 查询最新版变型规范的基础信息
     * SELECT IDA2A2,IDA3D10 FROM VARIANTSPEC WHERE IDA3MASTERREFERENCE ='367191' AND LATESTITERATIONINFO='1'
     * -- IDA2A2 = 367194   IDA3D10 = 367174
     *
     * -- 查询 ATONavigationFilter 的 IDA2A2
     * SELECT IDA2A2 FROM ATONavigationFilter WHERE idA3A4='367174'
     * -- IDA2A2 367178
     *
     * -- 查询 ATONavigationFilterChoiceLink 的信息（变型规范与选择主数据对象的关系）
     * SELECT * FROM ATONavigationFilterChoiceLink WHERE IDA3A5='367178' ORDER BY SELECTIONORDER
     * @param variantSpec
     * @param choiceMaster
     * @return
     */
    public static int addChoice2VariantSpect(VariantSpec variantSpec, ChoiceMaster choiceMaster) throws WTException, WTPropertyVetoException, SQLException {
        int result = 0;
        NavigationCriteria navigationCriteria = (NavigationCriteria)variantSpec.getNavigationCriteriaReference().getObject();
        Collection<ATONavigationFilter> filtersByClass = navigationCriteria.getFiltersByClass(ATONavigationFilter.class);
        ATONavigationFilter atoNavigationFilter = DocHelper.service.getATONavigationFilter(variantSpec);
//        for (ATONavigationFilter byClass : filtersByClass) {
//        System.out.println("ATONavigationFilter "+ object2Oid(atoNavigationFilter));
//            String ATONavigationFilterIDA2A2 = String.valueOf(atoNavigationFilter.getPersistInfo().getObjectIdentifier().getId());
//            String querySql = "SELECT SELECTIONORDER FROM ATONAVIGATIONFILTERCHOICELINK WHERE IDA3A5=? ORDER BY SELECTIONORDER DESC";
//            ResultSet resultSet = CommonUtil.excuteSelect(querySql, ATONavigationFilterIDA2A2);
//            int choiceIndex=0;
//            if (resultSet != null) {
//                if (resultSet.next()) {
//                    int selectionorder = resultSet.getInt("SELECTIONORDER");
//                    choiceIndex =selectionorder+1;
//                }else {
//                    choiceIndex++;
//                }
//            }else {
//                choiceIndex++;
//            }

        List<ATONavigationFilterChoiceLink> choiceLinksByVariantSpec = getChoiceLinksByVariantSpec(variantSpec);
        int nextATONavigationFilterChoiceLinkIndex = getNextATONavigationFilterChoiceLinkIndex(choiceLinksByVariantSpec);
        ATONavigationFilterChoiceLink atoNavigationFilterChoiceLink = ATONavigationFilterChoiceLink.newATONavigationFilterChoiceLink(atoNavigationFilter, choiceMaster);
        atoNavigationFilterChoiceLink.setSelectionOrder(nextATONavigationFilterChoiceLinkIndex);
        atoNavigationFilterChoiceLink = (ATONavigationFilterChoiceLink)PersistenceHelper.manager.save(atoNavigationFilterChoiceLink);
        if(atoNavigationFilterChoiceLink != null) {
            result++;
        }
//        }
        return result;
    }
    /**
     * 删除变型规范相关的选择
     * @param variantSpec
     * @param choiceMaster
     * @return
     */
    public static int deleteChoice2VariantSpect(VariantSpec variantSpec, ChoiceMaster choiceMaster) throws WTException {
        int result = 0;
        List<ATONavigationFilterChoiceLink> choiceLinksByVariantSpec = getChoiceLinksByVariantSpec(variantSpec);
        for (ATONavigationFilterChoiceLink atoNavigationFilterChoiceLink : choiceLinksByVariantSpec) {
            ChoiceMaster choiceMasterFromLink = atoNavigationFilterChoiceLink.getChoiceMaster();
            if(choiceMasterFromLink.equals(choiceMaster)){
                PersistenceHelper.manager.delete(atoNavigationFilterChoiceLink);
            }
        }
        return  result;
    }




    /**
     * 根据VariantSpec 获取所有ATONavigationFilterChoiceLink
     * @param variantSpec
     * @return
     */
    public static List<ATONavigationFilterChoiceLink> getChoiceLinksByVariantSpec(VariantSpec variantSpec) throws WTException {
        List<ATONavigationFilterChoiceLink> list =new ArrayList<>();
        ATONavigationFilter atoNavigationFilter = DocHelper.service.getATONavigationFilter(variantSpec);
//        System.out.println("ATONavigationFilter:"+atoNavigationFilter.getPersistInfo().getObjectIdentifier().getId());
        WTCollection choiceLinks = ATONavigationFilterHelper.service.getChoiceLinks(atoNavigationFilter);
        for (Object choiceLink : choiceLinks) {
//            System.out.println("choiceLink:"+choiceLink);
//            System.out.println("choiceLink:"+choiceLink.getClass().getName());
            if(choiceLink instanceof ObjectReference){
                ObjectReference objectReference = (ObjectReference) choiceLink;
                list.add((ATONavigationFilterChoiceLink)objectReference.getObject());
            }
        }
        return list;
    }

    /**
     * 返回递增的list 集合中atoNavigationFilterChoiceLink.getSelectionOrder(); 的加一值
     * @param list
     * @return
     */
    public static int getNextATONavigationFilterChoiceLinkIndex(List<ATONavigationFilterChoiceLink> list) {
        if (list == null || list.isEmpty()) {
            return 1;
        }

        return list.stream()
                .map(ATONavigationFilterChoiceLink::getSelectionOrder)
                .filter(Objects::nonNull)
                .mapToInt(Integer::intValue)
                .max()
                .orElse(0) + 1;
    }

    /**
     * 发送变型规范到ERP
     * @param pbo
     * @return
     */
    public static String sendVariantSpecToERP(WTObject pbo) throws WTException {
        StringBuffer result = new StringBuffer();
        if(pbo instanceof WTChangeOrder2){
//            System.out.println("准备发送变型规范");
            WTChangeOrder2 order2 = (WTChangeOrder2) pbo;
            // 获取ECN的产生的对象
            List<VariantSpec> ecnResultingObjects = getECNResultingObjects(order2);
            VariantAssignProcess variantAssignProcess = new VariantAssignProcess();
            for (VariantSpec variantSpec : ecnResultingObjects) {
                // 取最新版本
                VariantSpec lastVersionVariantSpec = null;
                lastVersionVariantSpec = OptionSetUtil.getVariantSpecByNumber(variantSpec.getNumber());
                if(lastVersionVariantSpec != null){
                    result.append(variantAssignProcess.sendVariantAssignData(lastVersionVariantSpec));
                }else {
                    result.append(variantAssignProcess.sendVariantAssignData(variantSpec));
                }
//                System.out.println("发送变型规范:"+variantSpec.getNumber()+"发送成功");
            }
//            System.out.println("全部发送完成后的错误信息:"+result.toString());
        }
        return result.toString();
    }

    /**
     * 自动将变型规范所关联的选项集绑定为最新版本
     * @param pbo
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateVsOptionSetToLatestVersionWork(WTObject pbo) throws WTException, WTPropertyVetoException {
        if(pbo instanceof WTChangeOrder2){
//            System.out.println("准备发送变型规范");
            WTChangeOrder2 order2 = (WTChangeOrder2) pbo;
            List<VariantSpec> variantSpecList = getECNResultingObjects(order2);
            for (VariantSpec variantSpec : variantSpecList) {
                // 修改变型规范的选型集为最新版本
                updateVsOptionSetToLatestVersion(variantSpec);
            }
        }
    }



    /**
     * 绑定ECN产生的对象 变型规范与同编号部件绑定可交付结果
     * @param pbo
     */
    public static void bindWTPartWithVariantSpec(WTObject pbo) throws WTException {
        if(pbo instanceof WTChangeOrder2){
            WTChangeOrder2 order2 = (WTChangeOrder2) pbo;
            // 获取ECN的产生的对象
            List<VariantSpec> variantSpecList = getECNResultingObjects(order2);
            List<WTPart> wtPartList = getECNResultingWTParts(order2);
            for (VariantSpec variantSpec : variantSpecList) {
                // 修改变型规范的选型集为最新版本
//                updateVsOptionSetToLatestVersion(variantSpec);
                String variantSpecNumber = variantSpec.getNumber();
                for (WTPart wtPart : wtPartList) {
                    String wtPartNumber = wtPart.getNumber();
                    if(variantSpecNumber.equals(wtPartNumber)){
                        VariantSpecServer.createVariantSpecDeliverableLink(wtPart, variantSpec);
                    }
                }
            }

        }
    }



}
