package ext.alphai.sinoboom.variantStandard.work;

import com.ptc.wpcfg.deliverables.VariantSpecDeliverableLink;
import com.ptc.wpcfg.doc.VariantSpec;
import ext.alphai.sinoboom.variantStandard.server.VariantSpecServer;
import ext.alphai.sinoboom.variantStandard.utils.CommonUtil;
import ext.alphai.sinoboom.variantStandard.utils.IBAUtil;
import ext.alphai.sinoboom.variantStandard.utils.PersistenceUtil;
import ext.cirpoint.integration.mdm.clients.MDMDataHelper;
import ext.cirpoint.mpm.esi.ReleaseData2MDMHelper;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import wt.change2.ChangeHelper2;
import wt.change2.VersionableChangeItem;
import wt.change2.WTChangeOrder2;
import wt.enterprise.RevisionControlled;
import wt.fc.*;
import wt.log4j.LogR;
import wt.maturity.PromotionNotice;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;

import java.util.ArrayList;
import java.util.List;

/**
 * 修改变型规范与可交付结果的整机状态 MachineStatus IBA属性   枚举约束 枚举内部名为 MachineStatusEnum
 */
public class UpdateVSMachineStatusWork {
    // 整机状态IBA内部值
    public static final String MachineStatus = "MachineStatus";
    // 整机状态 退市内部值
    public static final String MachineStatus_Delisting = "15";

    public static final Logger LOGGER = LogR.getLogger(UpdateVSMachineStatusWork.class.getName());
    /**
     * 执行修改
     * @param pbo
     */
    public static void setVSMachineStatus(WTObject pbo) throws Exception {
        if(pbo instanceof WTChangeOrder2){
            WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
            List<VariantSpec> resultingObjects = getECNResultingObjects(ecn);
            IBAUtil ibaUtil = new IBAUtil();
            ReleaseData2MDMHelper releaseData2MDMHelper = new ReleaseData2MDMHelper();
            for (VariantSpec vs : resultingObjects) {
                ibaUtil.setIBAAttribute4AllType(vs, MachineStatus, MachineStatus_Delisting);
                // 修改整机状态后在说明属性里备注
                vs.setDescription(ecn.getNumber());
                List<VariantSpecDeliverableLink> variantSpecDeliverableLinks = VariantSpecServer.getVariantSpecDeliverableLinkListByVariantSpecOfficial(vs);
                for (VariantSpecDeliverableLink link : variantSpecDeliverableLinks) {
                    WTReference roleAObjectRef = link.getRoleAObjectRef();
                    Persistable roleAObjectRefObject = roleAObjectRef.getObject();
                    if(roleAObjectRefObject instanceof WTPart){
                        WTPart part = (WTPart) roleAObjectRefObject;
                        ibaUtil.setIBAAttribute4AllType(part, MachineStatus, MachineStatus_Delisting);
                    }
                }
//                String sql = "UPDATE VARIANTSPEC SET DESCRIPTION = ? WHERE IDA2A2 = ?";
//                int i = CommonUtil.excuteUpdate(sql, ecn.getNumber(), String.valueOf(vs.getPersistInfo().getObjectIdentifier().getId()));
//                if(i == 0){
//                    System.out.println("变型规范说明修改失败："+ PersistenceUtil.object2Oid(vs));
//                }
            }
        }

    }


    /**
     * 根据ECN获取设计视图部件
     * @param pbo
     * @return
     */
    public static List<WTPart> getVSDesignPartList(WTObject pbo){
        List<WTPart> designParts = new ArrayList<>();
        if(pbo instanceof WTChangeOrder2){
            try {
                WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
                List<VariantSpec> resultingObjects = getECNResultingObjects(ecn);
                for (VariantSpec vs : resultingObjects) {
                    List<VariantSpecDeliverableLink> variantSpecDeliverableLinks = VariantSpecServer.getVariantSpecDeliverableLinkListByVariantSpecOfficial(vs);
                    for (VariantSpecDeliverableLink link : variantSpecDeliverableLinks) {
                        Persistable object = link.getRoleAObjectRef().getObject();
                        if(object instanceof WTPart){
                            WTPart part = (WTPart) object;
                            if("Design".equalsIgnoreCase(part.getView().getName())){
                                designParts.add(part);
                            }
                        }
                    }
                }
            }catch (WTException e){
                e.printStackTrace();
            }
        }
        return designParts;
    }


    /**
     * 根据ECN获取工厂视图部件
     * @param pbo
     * @return
     */
    public static List<WTPart> getVSFactoryPartList(WTObject pbo){
        List<WTPart> factoryParts = new ArrayList<>();
        if(pbo instanceof WTChangeOrder2){
            try {
                WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
                List<VariantSpec> resultingObjects = getECNResultingObjects(ecn);
                for (VariantSpec vs : resultingObjects) {
                    List<VariantSpecDeliverableLink> variantSpecDeliverableLinks = VariantSpecServer.getVariantSpecDeliverableLinkListByVariantSpecOfficial(vs);
                    for (VariantSpecDeliverableLink link : variantSpecDeliverableLinks) {
                        Persistable object = link.getRoleAObjectRef().getObject();
                        if(object instanceof WTPart){
                            WTPart part = (WTPart) object;
                            if(!"Design".equalsIgnoreCase(part.getView().getName())){
                                factoryParts.add(part);
                            }
                        }
                    }
                }
            }catch (WTException e){
                e.printStackTrace();
            }
        }
        return factoryParts;
    }

    /**
     * 发送退市变型规范的产生的设计部件
     * @param pbo
     * sendType 只发送MDM
     * @return
     */
    public static String sendVariantSpecDesignParts(WTObject pbo,List<WTPart> designParts){
        StringBuffer result = new StringBuffer();
        if(designParts.isEmpty()){
            return result.toString();
        }
        try {
            if(pbo instanceof WTChangeOrder2){
                String user = getUser(pbo);
                WfProcess processByPbo = getProcessByPbo(pbo);
                String processName ="";
                if(processByPbo != null){
                    processName = processByPbo.getName();
                }
                // 发送设计视图部件集合
                MDMDataHelper.sendMdmOrErpDesignData(designParts, result, user,processName,"MDM");
            }
        } catch (Exception e) {
            result.append(e.getMessage());
        }
        return result.toString();
    }




    /**
     * 发送退市变型规范的产生的设计部件
     * @param pbo
     * sendType 只发送MDM
     * @return
     */
    public static String sendVariantSpecFactoryParts(WTObject pbo,List<WTPart> factoryParts){
        StringBuffer result = new StringBuffer();
        if(factoryParts.isEmpty()){
            return result.toString();
        }
        try {
            if(pbo instanceof WTChangeOrder2){
                ReleaseData2MDMHelper releaseData2MDMHelper = new ReleaseData2MDMHelper();
                // 发送设计视图部件集合
                for (WTPart factoryPart : factoryParts) {
                    String sendFactoryPartResult = releaseData2MDMHelper.releaseFactoryData2MDM(factoryPart, "MDM");
                    result.append(sendFactoryPartResult);
                }
            }
        } catch (Exception e) {
            result.append(e.getMessage());
        }
        return result.toString();
    }

    /**
     * 获取用户信息
     *
     * @param pbo
     * @return
     * @throws WTException
     */
    public static String getUser(WTObject pbo) throws WTException {
        if (pbo instanceof WTChangeOrder2) {
            return ((WTChangeOrder2) pbo).getCreatorName();
        } else if (pbo instanceof PromotionNotice) {
            return ((PromotionNotice) pbo).getCreatorName();
        } else if (pbo instanceof WTPart) {
            return ((WTPart) pbo).getCreatorName();
        }
        return SessionHelper.manager.getPrincipal().getName();
    }








    /**
     * 产生的变型规范集合
     * @param ecn
     * @return
     * @throws WTException
     */
    public static List<VariantSpec> getECNResultingObjects(WTChangeOrder2 ecn) throws WTException {
        List<VariantSpec> vos = new ArrayList<>();
        QueryResult qr = ChangeHelper2.service.getChangeablesAfter(ecn);
        vos = CommonUtil.getListFromQR(qr, VariantSpec.class);
        return vos;
    }


    /**
     * 根据评审对象（PBO）获取WfProcess对象
     *
     * @param WTObject
     * @return WfProcess
     */
    @SuppressWarnings("deprecation")
    public static WfProcess getProcessByPbo(WTObject obj) {
        WfProcess process = null;
        try {
            String pboId = "";
            if (obj instanceof VersionableChangeItem) {
                pboId = "VR:" + obj.getClass().getName() + ":"
                        + ((VersionableChangeItem) obj).getIterationInfo().getBranchId();
                ;
            } else if (obj instanceof RevisionControlled) {
                pboId = "VR:" + obj.getClass().getName() + ":"
                        + ((RevisionControlled) obj).getIterationInfo().getBranchId();
            } else if (obj instanceof PromotionNotice) {
                PromotionNotice pn = (PromotionNotice) obj;
                pboId = "OR:" + obj.getClass().getName() + ":" + pn.getPersistInfo().getObjectIdentifier().getId();
            } else {
                return null;
            }
            QuerySpec qs = new QuerySpec(WfProcess.class);
            qs.appendWhere(new SearchCondition(WfProcess.class, WfProcess.BUSINESS_OBJ_REFERENCE, SearchCondition.EQUAL,
                    pboId));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            while (qr != null && qr.hasMoreElements()) {
                WfProcess tmpProcess = (WfProcess) qr.nextElement();
                if (process == null) {
                    process = tmpProcess;
                } else {
                    if (tmpProcess.getStartTime().after(process.getStartTime())) {
                        process = tmpProcess;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return process;
    }
}
