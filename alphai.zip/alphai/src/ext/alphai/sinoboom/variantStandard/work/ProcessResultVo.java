package ext.alphai.sinoboom.variantStandard.work;

/**
 * 选项集执行结果VO
 */
public class ProcessResultVo {
    private String optionSetName;
//    private String optionSetOR;
    private String type;
    private boolean result;
    private String choiceMasterName;
//    private String choiceMasterOR;
    private String errMsg;
    public String getOptionSetName() {
        return optionSetName;
    }

    public ProcessResultVo(String optionSetName, String type, boolean result, String choiceMasterName,String errMsg) {
        this.optionSetName = optionSetName;
//        this.optionSetOR = optionSetOR;
        this.type = type;
        this.result = result;
        this.choiceMasterName = choiceMasterName;
//        this.choiceMasterOR = choiceMasterOR;
        this.errMsg = errMsg;
    }

    public ProcessResultVo() {
    }

    public void setOptionSetName(String optionSetName) {
        this.optionSetName = optionSetName;
    }

//    public String getOptionSetOR() {
//        return optionSetOR;
//    }
//
//    public void setOptionSetOR(String optionSetOR) {
//        this.optionSetOR = optionSetOR;
//    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getChoiceMasterName() {
        return choiceMasterName;
    }

    public void setChoiceMasterName(String choiceMasterName) {
        this.choiceMasterName = choiceMasterName;
    }

//    public String getChoiceMasterOR() {
//        return choiceMasterOR;
//    }
//
//    public void setChoiceMasterOR(String choiceMasterOR) {
//        this.choiceMasterOR = choiceMasterOR;
//    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
}
