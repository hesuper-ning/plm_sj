package ext.alphai.sinoboom.FMEA.report.mvc;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import ext.alphai.sinoboom.FMEA.report.vo.PFEMAItem;
import wt.util.WTException;

/**
 * PFEMA 报表DateUtility
 */
public class PFEMATableUtility extends AbstractDataUtility {
    public PFEMATableUtility() {
    }
    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        String value = null;
        PFEMAItem pfemaItem = (PFEMAItem) o;
        switch (s) {
            case "processProject":
                value = pfemaItem.getProcessProject();
                break;
            case "procedureName":
                value = pfemaItem.getProcedureName();
                break;
            case "elementName":
                value = pfemaItem.getElementName();
                break;
            case "processProcedureName":
                value = pfemaItem.getProcessProcedureName();
                break;
            case "functionName":
                value = pfemaItem.getFunctionName();
                break;
            case "elementFunction":
                value = pfemaItem.getElementFunction();
                break;
            case "result":
                value = pfemaItem.getResult();
                break;
            case "raseverity":
                value = pfemaItem.getRaseverity();
                break;
            case "invalidModeName":
                value = pfemaItem.getInvalidModeName();
                break;
            case "reason":
                value = pfemaItem.getReason();
                break;
            case "yfcsName":
                value = pfemaItem.getYfcsName();
                break;
            case "raoccurrence":
                value = pfemaItem.getRaoccurrence();
                break;
            case "tccsName":
                value = pfemaItem.getTccsName();
                break;
            case "radet":
                value = pfemaItem.getRadet();
                break;
            case "raap":
                value = pfemaItem.getRaap();
                break;
            case "productFeatureSymbol":
                value = pfemaItem.getProductFeatureSymbol();
                break;
            case "occMeasuresName":
                value = pfemaItem.getOccMeasuresName();
                break;
            case "detMeasuresName":
                value = pfemaItem.getDetMeasuresName();
                break;
            case "responsibleUserName":
                value = pfemaItem.getResponsibleUserName();
                break;
            case "targetDate":
                value = pfemaItem.getTargetDate();
                break;
            case "status":
                value = pfemaItem.getStatus();
                break;
            case "validate":
                value = pfemaItem.getValidate();
                break;
            case "finishDate":
                value = pfemaItem.getFinishDate();
                break;
            case "severity":
                value = pfemaItem.getSeverity();
                break;
            case "occurrence":
                value = pfemaItem.getOccurrence();
                break;
            case "det":
                value = pfemaItem.getDet();
                break;
            case "ap":
                value = pfemaItem.getAp();
                break;
            case "featureSymbol":
                value = pfemaItem.getFeatureSymbol();
                break;
        }
        return value;
    }
}
