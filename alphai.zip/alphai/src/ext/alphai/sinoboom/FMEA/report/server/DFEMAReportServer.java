package ext.alphai.sinoboom.FMEA.report.server;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sinoboom.FMEA.report.domain.AIDFEMAReport;
import ext.alphai.sinoboom.FMEA.report.vo.DFEMAData;
import ext.alphai.sinoboom.FMEA.util.CommonUtil;
import ext.alphai.sinoboom.FMEA.vo.ResponseVo;
import wt.pom.WTConnection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 设计视图FEMA 部件报表服务类
 */
public class DFEMAReportServer {

    public static final ObjectMapper objectMapper = new ObjectMapper();
    /**
     * 添加或修改DFEMA 部件报表
     * @param dfemaData
     * @return
     */
    public static ResponseVo saveAIDFEMAReport(DFEMAData dfemaData){
        ResponseVo vo = null;
        // 部件编号依据
        String productNum = dfemaData.getProductNum();

        String productNum12 = null;
        // 由于FEMA发送的部件编号是带版本的故而截取前12位作为真实的部件编号   20250916
        if (productNum != null && productNum.length() >= 12) {
            productNum12 = productNum.substring(0, 12);
        } else if (productNum != null) {
            // 如果不足12位，可以选择保留原值或进行其他处理
            productNum12 = productNum;
        }


        AIDFEMAReport aidfemaReport = new AIDFEMAReport();
        aidfemaReport.setPARTNUMBER(productNum12);
        try {
            aidfemaReport.setDFEMAREPORTJSON(objectMapper.writeValueAsString(dfemaData));
            int i = insertOrUpdateAIDFEMAReport(aidfemaReport);
            vo = i > 0 ? ResponseVo.success("") : ResponseVo.error(500, "添加/修改DFEMA报表失败");
        } catch (JsonProcessingException e) {
            vo = ResponseVo.error(500, e.getMessage());
        }
        return vo;
    }










    /**
     * 查询
     * @param partNumber
     * @return
     * @throws SQLException
     */
    public static AIDFEMAReport getAIDFEMAReportByPartNumber(String partNumber) throws SQLException {
        AIDFEMAReport aidfemaReport = new AIDFEMAReport();
        String sql = "SELECT * FROM AIDFEMAREPORT WHERE PARTNUMBER = ?";
        ResultSet rs = null;
        try {
            rs = CommonUtil.excuteSelect(sql, partNumber);
            while (rs.next()) {
                aidfemaReport.setPARTNUMBER(rs.getString("PARTNUMBER"));
                // 关键修改：读取CLOB并转为String
                Clob jsonClob = rs.getClob("DFEMAREPORTJSON");
                String jsonString = convertClobToString(jsonClob);
                aidfemaReport.setDFEMAREPORTJSON(jsonString);
                aidfemaReport.setUPDATETIME(rs.getString("UPDATETIME"));
            }
        }finally {
            // 确保关闭资源
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return aidfemaReport;
    }




    // 新增工具方法：将CLOB转为String
    private static String convertClobToString(Clob clob) throws SQLException {
        if (clob == null) {
            return null;
        }

        StringBuilder sb = new StringBuilder();
        try (Reader reader = clob.getCharacterStream();
             BufferedReader br = new BufferedReader(reader)) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            throw new SQLException("DFEMA：Error converting CLOB to string", e);
        }
        return sb.toString();
    }


    /**
     * 如果PARTNUMBER字段在数据库中已存在就更新（非空字段），否则新增。
     * 更新时只更新对象中非空（非null且非空字符串）的属性，UPDATETIME由数据库触发器自动更新。
     * 新增时UPDATETIME由数据库默认值填充。
     *
     * @param aidfemaReport AIDFEMAReport
     * @return 受影响的行数
     */
    public static int insertOrUpdateAIDFEMAReport(AIDFEMAReport aidfemaReport) {
        WTConnection connection = null;
        PreparedStatement checkStmt = null;
        PreparedStatement updateStmt = null;
        PreparedStatement insertStmt = null;
        ResultSet rs = null;
        int result = 0;

        Connection connectionConnection = null;
        try {
            connection = CommonUtil.getWTConnection();
            connectionConnection = connection.getConnection();
            // 取消自动提交，使用手动事务控制
            connectionConnection.setAutoCommit(false);

            // 1. 检查记录是否存在
            String checkSql = "SELECT COUNT(1) FROM AIDFEMAREPORT WHERE PARTNUMBER = ?";
            checkStmt = connection.prepareStatement(checkSql);
            checkStmt.setString(1, aidfemaReport.getPARTNUMBER());
            rs = checkStmt.executeQuery();

            boolean exists = false;
            if (rs.next()) {
                exists = rs.getInt(1) > 0;
            }

            // 2. 根据存在情况执行更新或插入
            if (exists) {
                // 更新操作 - 只更新非空字段
                StringBuilder updateSql = new StringBuilder("UPDATE AIDFEMAREPORT SET ");
                List<Object> params = new ArrayList<>();

                // 动态构建SET子句
                if (aidfemaReport.getDFEMAREPORTJSON() != null && !aidfemaReport.getDFEMAREPORTJSON().isEmpty()) {
                    updateSql.append("DFEMAREPORTJSON = ?, ");
                    params.add(aidfemaReport.getDFEMAREPORTJSON());
                }

                // 移除最后一个逗号和空格
                if (params.isEmpty()) {
                    return 0; // 没有需要更新的字段
                }
                updateSql.setLength(updateSql.length() - 2);
                updateSql.append(" WHERE PARTNUMBER = ?");
                params.add(aidfemaReport.getPARTNUMBER());

                // 执行更新
                updateStmt = connection.prepareStatement(updateSql.toString());
                for (int i = 0; i < params.size(); i++) {
                    Object param = params.get(i);
                    if (param instanceof String && "DFEMAREPORTJSON".equals(param)) {
                        // 处理CLOB类型
                        Clob clob = connectionConnection.createClob();
                        clob.setString(1, (String) param);
                        updateStmt.setClob(i + 1, clob);
                    } else {
                        updateStmt.setObject(i + 1, param);
                    }
                }

                result = updateStmt.executeUpdate();
            } else {
                // 插入操作 - 必须字段校验
                if (aidfemaReport.getPARTNUMBER() == null || aidfemaReport.getPARTNUMBER().isEmpty() ||
                        aidfemaReport.getDFEMAREPORTJSON() == null || aidfemaReport.getDFEMAREPORTJSON().isEmpty()) {
                    throw new IllegalArgumentException("必须字段(PARTNUMBER, DFEMAREPORTJSON)不能为空");
                }

                // 插入语句（不包含UPDATETIME，使用数据库默认值）
                String insertSql = "INSERT INTO AIDFEMAREPORT (PARTNUMBER, DFEMAREPORTJSON) VALUES (?, ?)";
                insertStmt = connection.prepareStatement(insertSql);
                insertStmt.setString(1, aidfemaReport.getPARTNUMBER());

                // 处理CLOB类型
                Clob clob = connectionConnection.createClob();
                clob.setString(1, aidfemaReport.getDFEMAREPORTJSON());
                insertStmt.setClob(2, clob);

                result = insertStmt.executeUpdate();
            }

            connectionConnection.commit();
            return result;
        } catch (Exception e) {
            try {
                if (connection != null) connectionConnection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return 0;
        } finally {
            // 关闭资源
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (checkStmt != null) checkStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (updateStmt != null) updateStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (insertStmt != null) insertStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            catch (Exception e) { e.printStackTrace(); }
        }
    }

}
