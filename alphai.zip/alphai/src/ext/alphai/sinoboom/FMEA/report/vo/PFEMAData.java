package ext.alphai.sinoboom.FMEA.report.vo;

import java.util.List;

/**
 * PFEMA 主数据JSON
 */
public class PFEMAData {
    private String projectNum;

    private String productNum;

    private String productName;

    private List<PFEMAItem> fmeaList;
    private String linkUrl;

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }
    public String getProjectNum() {
        return projectNum;
    }

    public void setProjectNum(String projectNum) {
        this.projectNum = projectNum;
    }

    public String getProductNum() {
        return productNum;
    }

    public void setProductNum(String productNum) {
        this.productNum = productNum;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<PFEMAItem> getFmeaList() {
        return fmeaList;
    }

    public void setFmeaList(List<PFEMAItem> fmeaList) {
        this.fmeaList = fmeaList;
    }
}
