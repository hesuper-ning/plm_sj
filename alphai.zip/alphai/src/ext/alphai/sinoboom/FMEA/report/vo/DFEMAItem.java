package ext.alphai.sinoboom.FMEA.report.vo;

/**
 * DFEMA 每一行子项
 */
public class DFEMAItem {
    private String upProductName;
    private String productName;
    private String downProductName;
    private String upFunctionName;
    private String functionName;
    private String downFunctionName;
    private String result;
    private String raseverity;
    private String invalidModeName;
    private String reason;
    private String yfcsName;
    private String raoccurrence;
    private String tccsName;
    private String radet;
    private String raap;
    private String featureSymbol;
    private String occMeasuresName;
    private String detMeasuresName;
    private String responsibleUserName;
    private String targetDate;
    private String status;
    private String validate;
    private String finishDate;
    private String severity;
    private String occurrence;
    private String det;
    private String ap;

    public String getUpProductName() {
        return upProductName;
    }

    public void setUpProductName(String upProductName) {
        this.upProductName = upProductName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDownProductName() {
        return downProductName;
    }

    public void setDownProductName(String downProductName) {
        this.downProductName = downProductName;
    }

    public String getUpFunctionName() {
        return upFunctionName;
    }

    public void setUpFunctionName(String upFunctionName) {
        this.upFunctionName = upFunctionName;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public String getDownFunctionName() {
        return downFunctionName;
    }

    public void setDownFunctionName(String downFunctionName) {
        this.downFunctionName = downFunctionName;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getRaseverity() {
        return raseverity;
    }

    public void setRaseverity(String raseverity) {
        this.raseverity = raseverity;
    }

    public String getInvalidModeName() {
        return invalidModeName;
    }

    public void setInvalidModeName(String invalidModeName) {
        this.invalidModeName = invalidModeName;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getYfcsName() {
        return yfcsName;
    }

    public void setYfcsName(String yfcsName) {
        this.yfcsName = yfcsName;
    }

    public String getRaoccurrence() {
        return raoccurrence;
    }

    public void setRaoccurrence(String raoccurrence) {
        this.raoccurrence = raoccurrence;
    }

    public String getTccsName() {
        return tccsName;
    }

    public void setTccsName(String tccsName) {
        this.tccsName = tccsName;
    }

    public String getRadet() {
        return radet;
    }

    public void setRadet(String radet) {
        this.radet = radet;
    }

    public String getRaap() {
        return raap;
    }

    public void setRaap(String raap) {
        this.raap = raap;
    }

    public String getFeatureSymbol() {
        return featureSymbol;
    }

    public void setFeatureSymbol(String featureSymbol) {
        this.featureSymbol = featureSymbol;
    }

    public String getOccMeasuresName() {
        return occMeasuresName;
    }

    public void setOccMeasuresName(String occMeasuresName) {
        this.occMeasuresName = occMeasuresName;
    }

    public String getDetMeasuresName() {
        return detMeasuresName;
    }

    public void setDetMeasuresName(String detMeasuresName) {
        this.detMeasuresName = detMeasuresName;
    }

    public String getResponsibleUserName() {
        return responsibleUserName;
    }

    public void setResponsibleUserName(String responsibleUserName) {
        this.responsibleUserName = responsibleUserName;
    }

    public String getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(String targetDate) {
        this.targetDate = targetDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getValidate() {
        return validate;
    }

    public void setValidate(String validate) {
        this.validate = validate;
    }

    public String getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(String finishDate) {
        this.finishDate = finishDate;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getOccurrence() {
        return occurrence;
    }

    public void setOccurrence(String occurrence) {
        this.occurrence = occurrence;
    }

    public String getDet() {
        return det;
    }

    public void setDet(String det) {
        this.det = det;
    }

    public String getAp() {
        return ap;
    }

    public void setAp(String ap) {
        this.ap = ap;
    }
}
