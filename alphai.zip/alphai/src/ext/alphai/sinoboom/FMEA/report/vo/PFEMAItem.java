package ext.alphai.sinoboom.FMEA.report.vo;

public class PFEMAItem {
    private String processProject;

    private String procedureName;

    private String elementName;

    private String processProcedureName;

    private String functionName;

    private String elementFunction;

    private String result;

    private String raseverity;

    private String invalidModeName;

    private String reason;

    private String yfcsName;

    private String raoccurrence;

    private String tccsName;

    private String radet;

    private String raap;

    private String productFeatureSymbol;

    private String occMeasuresName;

    private String detMeasuresName;

    private String responsibleUserName;

    private String targetDate;

    private String status;

    private String validate;

    private String finishDate;

    private String severity;

    private String occurrence;

    private String det;

    private String ap;

    private String featureSymbol;

    public String getProcessProject() {
        return processProject;
    }

    public void setProcessProject(String processProject) {
        this.processProject = processProject;
    }

    public String getProcedureName() {
        return procedureName;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public String getProcessProcedureName() {
        return processProcedureName;
    }

    public void setProcessProcedureName(String processProcedureName) {
        this.processProcedureName = processProcedureName;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public String getElementFunction() {
        return elementFunction;
    }

    public void setElementFunction(String elementFunction) {
        this.elementFunction = elementFunction;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getRaseverity() {
        return raseverity;
    }

    public void setRaseverity(String raseverity) {
        this.raseverity = raseverity;
    }

    public String getInvalidModeName() {
        return invalidModeName;
    }

    public void setInvalidModeName(String invalidModeName) {
        this.invalidModeName = invalidModeName;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getYfcsName() {
        return yfcsName;
    }

    public void setYfcsName(String yfcsName) {
        this.yfcsName = yfcsName;
    }

    public String getRaoccurrence() {
        return raoccurrence;
    }

    public void setRaoccurrence(String raoccurrence) {
        this.raoccurrence = raoccurrence;
    }

    public String getTccsName() {
        return tccsName;
    }

    public void setTccsName(String tccsName) {
        this.tccsName = tccsName;
    }

    public String getRadet() {
        return radet;
    }

    public void setRadet(String radet) {
        this.radet = radet;
    }

    public String getRaap() {
        return raap;
    }

    public void setRaap(String raap) {
        this.raap = raap;
    }

    public String getProductFeatureSymbol() {
        return productFeatureSymbol;
    }

    public void setProductFeatureSymbol(String productFeatureSymbol) {
        this.productFeatureSymbol = productFeatureSymbol;
    }

    public String getOccMeasuresName() {
        return occMeasuresName;
    }

    public void setOccMeasuresName(String occMeasuresName) {
        this.occMeasuresName = occMeasuresName;
    }

    public String getDetMeasuresName() {
        return detMeasuresName;
    }

    public void setDetMeasuresName(String detMeasuresName) {
        this.detMeasuresName = detMeasuresName;
    }

    public String getResponsibleUserName() {
        return responsibleUserName;
    }

    public void setResponsibleUserName(String responsibleUserName) {
        this.responsibleUserName = responsibleUserName;
    }

    public String getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(String targetDate) {
        this.targetDate = targetDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getValidate() {
        return validate;
    }

    public void setValidate(String validate) {
        this.validate = validate;
    }

    public String getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(String finishDate) {
        this.finishDate = finishDate;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getOccurrence() {
        return occurrence;
    }

    public void setOccurrence(String occurrence) {
        this.occurrence = occurrence;
    }

    public String getDet() {
        return det;
    }

    public void setDet(String det) {
        this.det = det;
    }

    public String getAp() {
        return ap;
    }

    public void setAp(String ap) {
        this.ap = ap;
    }

    public String getFeatureSymbol() {
        return featureSymbol;
    }

    public void setFeatureSymbol(String featureSymbol) {
        this.featureSymbol = featureSymbol;
    }
}
