package ext.alphai.sinoboom.FMEA.report.mvc;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import ext.alphai.sinoboom.FMEA.report.vo.DFEMAItem;
import wt.util.WTException;

/**
 * DFEMA 报表DateUtility
 */
public class DFEMATableUtility extends AbstractDataUtility {
    public DFEMATableUtility() {
    }
    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        String value = null;
        DFEMAItem dfemaItem = (DFEMAItem) o;
        switch (s) {
            case "upProductName":
                value = dfemaItem.getUpProductName();
                break;
            case "productName":
                value = dfemaItem.getProductName();
                break;
            case "downProductName":
                value = dfemaItem.getDownProductName();
                break;
            case "upFunctionName":
                value = dfemaItem.getUpFunctionName();
                break;
            case "functionName":
                value = dfemaItem.getFunctionName();
                break;
            case "downFunctionName":
                value = dfemaItem.getDownFunctionName();
                break;
            case "result":
                value = dfemaItem.getResult();
                break;
            case "raseverity":
                value = dfemaItem.getRaseverity();
                break;
            case "invalidModeName":
                value = dfemaItem.getInvalidModeName();
                break;
            case "reason":
                value = dfemaItem.getReason();
                break;
            case "yfcsName":
                value = dfemaItem.getYfcsName();
                break;
            case "raoccurrence":
                value = dfemaItem.getRaoccurrence();
                break;
            case "tccsName":
                value = dfemaItem.getTccsName();
                break;
            case "radet":
                value = dfemaItem.getRadet();
                break;
            case "raap":
                value = dfemaItem.getRaap();
                break;
            case "featureSymbol":
                value = dfemaItem.getFeatureSymbol();
                break;
            case "occMeasuresName":
                value = dfemaItem.getOccMeasuresName();
                break;
            case "detMeasuresName":
                value = dfemaItem.getDetMeasuresName();
                break;
            case "responsibleUserName":
                value = dfemaItem.getResponsibleUserName();
                break;
            case "targetDate":
                value = dfemaItem.getTargetDate();
                break;
            case "status":
                value = dfemaItem.getStatus();
                break;
            case "validate":
                value = dfemaItem.getValidate();
                break;
            case "finishDate":
                value = dfemaItem.getFinishDate();
                break;
            case "severity":
                value = dfemaItem.getSeverity();
                break;
            case "occurrence":
                value = dfemaItem.getOccurrence();
                break;
            case "det":
                value = dfemaItem.getDet();
                break;
            case "ap":
                value = dfemaItem.getAp();
                break;
        }
        return value;
    }
}
