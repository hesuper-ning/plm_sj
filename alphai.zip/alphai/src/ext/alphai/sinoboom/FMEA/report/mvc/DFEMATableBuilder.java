package ext.alphai.sinoboom.FMEA.report.mvc;

import com.fasterxml.jackson.core.type.TypeReference;
import com.ptc.core.components.descriptor.DescriptorConstants;
import com.ptc.core.htmlcomp.components.AbstractConfigurableTableBuilder;
import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sinoboom.FMEA.*;
import ext.alphai.sinoboom.FMEA.report.domain.AIDFEMAReport;
import ext.alphai.sinoboom.FMEA.report.server.DFEMAReportServer;
import ext.alphai.sinoboom.FMEA.report.vo.DFEMAData;
import ext.alphai.sinoboom.FMEA.report.vo.DFEMAItem;
import org.apache.commons.lang3.StringUtils;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * 部件 DFEMA 报表展示页面
 */
@ComponentBuilder("ext.alphai.sinoboom.FMEA.report.mvc.DFEMATableBuilder")
public class DFEMATableBuilder extends AbstractConfigurableTableBuilder {
    static final String RESOURCE = CustomActionsRB.class.getName();
    private final ClientMessageSource messageSource = getMessageSource(CustomActionsRB.class.getName());
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
        final ComponentConfigFactory factory = getComponentConfigFactory();
        final TableConfig table; {
            table = factory.newTableConfig();
            table.setType(WTPart.class.getName());
            table.setLabel(messageSource.getMessage(CustomActionsRB.DFEMAReport));
            // 条件过滤model
//            table.setActionModel("quotationActionList");
            table.setSelectable(true);
            table.setShowCount(true);
            table.setShowCustomViewLink(false);
            table.setConfigurable(true);


            ColumnConfig upProductName = factory.newColumnConfig("upProductName", true);
            upProductName.setLabel("上级元素");
            upProductName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(upProductName);

            ColumnConfig productName = factory.newColumnConfig("productName", true);
            productName.setLabel("聚焦元素/接口");
            productName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(productName);

            ColumnConfig downProductName = factory.newColumnConfig("downProductName", true);
            downProductName.setLabel("下级元素/接口");
            downProductName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(downProductName);

            ColumnConfig upFunctionName = factory.newColumnConfig("upFunctionName", true);
            upFunctionName.setLabel("上级元素的功能和要求");
            upFunctionName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(upFunctionName);

            ColumnConfig functionName = factory.newColumnConfig("functionName", true);
            functionName.setLabel("聚焦元素/接口的功能和要求");
            functionName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(functionName);

            ColumnConfig downFunctionName = factory.newColumnConfig("downFunctionName", true);
            downFunctionName.setLabel("下级元素功能/接口的功能和要求");
            downFunctionName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(downFunctionName);

            ColumnConfig result = factory.newColumnConfig("result", true);
            result.setLabel("失效影响");
            result.setDataUtilityId("DFEMATableUtility");
            table.addComponent(result);

            ColumnConfig raseverity = factory.newColumnConfig("raseverity", true);
            raseverity.setLabel("严重度");
            raseverity.setDataUtilityId("DFEMATableUtility");
            table.addComponent(raseverity);

            ColumnConfig invalidModeName = factory.newColumnConfig("invalidModeName", true);
            invalidModeName.setLabel("失效模式");
            invalidModeName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(invalidModeName);

            ColumnConfig reason = factory.newColumnConfig("reason", true);
            reason.setLabel("失效原因");
            reason.setDataUtilityId("DFEMATableUtility");
            table.addComponent(reason);

            ColumnConfig yfcsName = factory.newColumnConfig("yfcsName", true);
            yfcsName.setLabel("现行预防控制");
            yfcsName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(yfcsName);

            ColumnConfig raoccurrence = factory.newColumnConfig("raoccurrence", true);
            raoccurrence.setLabel("发生度");
            raoccurrence.setDataUtilityId("DFEMATableUtility");
            table.addComponent(raoccurrence);

            ColumnConfig tccsName = factory.newColumnConfig("tccsName", true);
            tccsName.setLabel("现行探测控制");
            tccsName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(tccsName);

            ColumnConfig radet = factory.newColumnConfig("radet", true);
            radet.setLabel("探测度");
            radet.setDataUtilityId("DFEMATableUtility");
            table.addComponent(radet);

            ColumnConfig raap = factory.newColumnConfig("raap", true);
            raap.setLabel("AP(行动优先级)");
            raap.setDataUtilityId("DFEMATableUtility");
            table.addComponent(raap);

            ColumnConfig featureSymbol = factory.newColumnConfig("featureSymbol", true);
            featureSymbol.setLabel("筛选符号");
            featureSymbol.setDataUtilityId("DFEMATableUtility");
            table.addComponent(featureSymbol);

            ColumnConfig occMeasuresName = factory.newColumnConfig("occMeasuresName", true);
            occMeasuresName.setLabel("预防措施");
            occMeasuresName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(occMeasuresName);

            ColumnConfig detMeasuresName = factory.newColumnConfig("detMeasuresName", true);
            detMeasuresName.setLabel("探测措施");
            detMeasuresName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(detMeasuresName);

            ColumnConfig responsibleUserName = factory.newColumnConfig("responsibleUserName", true);
            responsibleUserName.setLabel("责任人");
            responsibleUserName.setDataUtilityId("DFEMATableUtility");
            table.addComponent(responsibleUserName);

            ColumnConfig targetDate = factory.newColumnConfig("targetDate", true);
            targetDate.setLabel("计划完成时间");
            targetDate.setDataUtilityId("DFEMATableUtility");
            table.addComponent(targetDate);

            ColumnConfig status = factory.newColumnConfig("status", true);
            status.setLabel("状态");
            status.setDataUtilityId("DFEMATableUtility");
            table.addComponent(status);

            ColumnConfig validate = factory.newColumnConfig("validate", true);
            validate.setLabel("改进措施描述");
            validate.setDataUtilityId("DFEMATableUtility");
            table.addComponent(validate);

            ColumnConfig finishDate = factory.newColumnConfig("finishDate", true);
            finishDate.setLabel("实际完成时间");
            finishDate.setDataUtilityId("DFEMATableUtility");
            table.addComponent(finishDate);

            ColumnConfig severity = factory.newColumnConfig("severity", true);
            severity.setLabel("严重度");
            severity.setDataUtilityId("DFEMATableUtility");
            table.addComponent(severity);

            ColumnConfig occurrence = factory.newColumnConfig("occurrence", true);
            occurrence.setLabel("发生度");
            occurrence.setDataUtilityId("DFEMATableUtility");
            table.addComponent(occurrence);

            ColumnConfig det = factory.newColumnConfig("det", true);
            det.setLabel("探测度");
            det.setDataUtilityId("DFEMATableUtility");
            table.addComponent(det);

            ColumnConfig ap = factory.newColumnConfig("ap", true);
            ap.setLabel("AP");
            ap.setDataUtilityId("DFEMATableUtility");
            table.addComponent(ap);

        }
        return table;
    }

    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        List<DFEMAItem> fmeaList = new ArrayList<>();
        JcaComponentParams jca_params = (JcaComponentParams) componentParams;
        NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
        NmOid primaryOid2 = cb.getPrimaryOid();
        WTPart part = null;
        if (primaryOid2 == null)
            return fmeaList;
        Object content = primaryOid2.getRef();
        if (content instanceof WTPart) {
            part = (WTPart) content;
            if("Design".equalsIgnoreCase(part.getView().getName())){
                AIDFEMAReport aidfemaReportByPartNumber = DFEMAReportServer.getAIDFEMAReportByPartNumber(part.getNumber());
                if(StringUtils.isNotBlank(aidfemaReportByPartNumber.getPARTNUMBER())){
                    String dfemareportjson = aidfemaReportByPartNumber.getDFEMAREPORTJSON();
                    DFEMAData dfemaData = DFEMAReportServer.objectMapper.readValue(dfemareportjson, new TypeReference<DFEMAData>() {
                    });
                    fmeaList = dfemaData.getFmeaList();
                }
            }
        }
        return fmeaList;
    }


    ColumnConfig getColumn(final String id, final ComponentConfigFactory factory) {
        final ColumnConfig column = factory.newColumnConfig(id, true);
        column.setSortable(false);
        return column;
    }

    @Override
    public ConfigurableTable buildConfigurableTable(String s) throws WTException {
        return null;
    }
}
