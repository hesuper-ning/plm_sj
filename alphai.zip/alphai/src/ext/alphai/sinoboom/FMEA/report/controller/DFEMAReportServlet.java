package ext.alphai.sinoboom.FMEA.report.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sinoboom.FMEA.report.server.DFEMAReportServer;
import ext.alphai.sinoboom.FMEA.report.vo.DFEMAData;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import ext.alphai.sinoboom.FMEA.vo.ResponseVo;
/**
 * 设计视图FEMA 部件报表接收数据接口
 */
@Controller
@RequestMapping("/DFEMAReportServlet") // 添加特定的路径映射
public class DFEMAReportServlet extends HttpServlet {


    static final ObjectMapper objectMapper = new ObjectMapper();
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("deprecation")
    @RequestMapping(method = { RequestMethod.GET, RequestMethod.POST,
            RequestMethod.HEAD })
    protected void DFEMAprocessRequest(@RequestBody String json, HttpServletRequest request,
                                  HttpServletResponse response) throws ServletException, IOException {
        System.out.println("调用DFEAM插入接口："+json);
        DFEMAData dfemaData = objectMapper.readValue(json, DFEMAData.class);
        ResponseVo vo = DFEMAReportServer.saveAIDFEMAReport(dfemaData);
        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response, respJson);
    }


    public void outResponse(HttpServletResponse response, String json) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }


}
