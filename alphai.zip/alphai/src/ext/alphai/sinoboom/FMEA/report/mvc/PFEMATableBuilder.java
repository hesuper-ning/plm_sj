package ext.alphai.sinoboom.FMEA.report.mvc;

import com.fasterxml.jackson.core.type.TypeReference;
import com.ptc.core.htmlcomp.components.AbstractConfigurableTableBuilder;
import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sinoboom.FMEA.CustomActionsRB;
import ext.alphai.sinoboom.FMEA.report.domain.AIDFEMAReport;
import ext.alphai.sinoboom.FMEA.report.domain.AIPFEMAReport;
import ext.alphai.sinoboom.FMEA.report.server.DFEMAReportServer;
import ext.alphai.sinoboom.FMEA.report.server.PFEMAReportServer;
import ext.alphai.sinoboom.FMEA.report.vo.DFEMAData;
import ext.alphai.sinoboom.FMEA.report.vo.DFEMAItem;
import ext.alphai.sinoboom.FMEA.report.vo.PFEMAData;
import ext.alphai.sinoboom.FMEA.report.vo.PFEMAItem;
import org.apache.commons.lang3.StringUtils;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * 部件 DFEMA 报表展示页面
 */
@ComponentBuilder("ext.alphai.sinoboom.FMEA.report.mvc.PFEMATableBuilder")
public class PFEMATableBuilder extends AbstractConfigurableTableBuilder {
    static final String RESOURCE = CustomActionsRB.class.getName();
    private final ClientMessageSource messageSource = getMessageSource(CustomActionsRB.class.getName());
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
        final ComponentConfigFactory factory = getComponentConfigFactory();
        final TableConfig table; {
            table = factory.newTableConfig();
            table.setType(WTPart.class.getName());
            table.setLabel(messageSource.getMessage(CustomActionsRB.PFEMAReport));
            // 条件过滤model
//            table.setActionModel("quotationActionList");
            table.setSelectable(true);
            table.setShowCount(true);
            table.setShowCustomViewLink(false);
            table.setConfigurable(true);


            ColumnConfig processProject = factory.newColumnConfig("processProject", true);
            processProject.setLabel("过程项");
            processProject.setDataUtilityId("PFEMATableUtility");
            table.addComponent(processProject);

            ColumnConfig procedureName = factory.newColumnConfig("procedureName", true);
            procedureName.setLabel("过程步骤");
            procedureName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(procedureName);

            ColumnConfig elementName = factory.newColumnConfig("elementName", true);
            elementName.setLabel("过程工作要素");
            elementName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(elementName);

            ColumnConfig processProcedureName = factory.newColumnConfig("processProcedureName", true);
            processProcedureName.setLabel("过程名称的功能系统");
            processProcedureName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(processProcedureName);

            ColumnConfig functionName = factory.newColumnConfig("functionName", true);
            functionName.setLabel("过程步骤的功能好产品特性");
            functionName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(functionName);

            ColumnConfig elementFunction = factory.newColumnConfig("elementFunction", true);
            elementFunction.setLabel("过程工作要素的功能和过程特性");
            elementFunction.setDataUtilityId("PFEMATableUtility");
            table.addComponent(elementFunction);

            ColumnConfig result = factory.newColumnConfig("result", true);
            result.setLabel("对于上一较高级别要素和/或最终用户的失效影响");
            result.setDataUtilityId("PFEMATableUtility");
            table.addComponent(result);

            ColumnConfig raseverity = factory.newColumnConfig("raseverity", true);
            raseverity.setLabel("失效影响的严重度");
            raseverity.setDataUtilityId("PFEMATableUtility");
            table.addComponent(raseverity);

            ColumnConfig invalidModeName = factory.newColumnConfig("invalidModeName", true);
            invalidModeName.setLabel("关注要素的失效模式");
            invalidModeName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(invalidModeName);

            ColumnConfig reason = factory.newColumnConfig("reason", true);
            reason.setLabel("工作要素的失效原因");
            reason.setDataUtilityId("PFEMATableUtility");
            table.addComponent(reason);

            ColumnConfig yfcsName = factory.newColumnConfig("yfcsName", true);
            yfcsName.setLabel("现行预防控制");
            yfcsName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(yfcsName);

            ColumnConfig raoccurrence = factory.newColumnConfig("raoccurrence", true);
            raoccurrence.setLabel("失效原因");
            raoccurrence.setDataUtilityId("PFEMATableUtility");
            table.addComponent(raoccurrence);

            ColumnConfig tccsName = factory.newColumnConfig("tccsName", true);
            tccsName.setLabel("当前的失效起因");
            tccsName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(tccsName);

            ColumnConfig radet = factory.newColumnConfig("radet", true);
            radet.setLabel("探测度");
            radet.setDataUtilityId("PFEMATableUtility");
            table.addComponent(radet);

            ColumnConfig raap = factory.newColumnConfig("raap", true);
            raap.setLabel("PFEMA措施优先级");
            raap.setDataUtilityId("PFEMATableUtility");
            table.addComponent(raap);

            ColumnConfig productFeatureSymbol = factory.newColumnConfig("productFeatureSymbol", true);
            productFeatureSymbol.setLabel("特殊特性");
            productFeatureSymbol.setDataUtilityId("PFEMATableUtility");
            table.addComponent(productFeatureSymbol);

            ColumnConfig occMeasuresName = factory.newColumnConfig("occMeasuresName", true);
            occMeasuresName.setLabel("预防措施");
            occMeasuresName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(occMeasuresName);

            ColumnConfig detMeasuresName = factory.newColumnConfig("detMeasuresName", true);
            detMeasuresName.setLabel("探测措施");
            detMeasuresName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(detMeasuresName);

            ColumnConfig responsibleUserName = factory.newColumnConfig("responsibleUserName", true);
            responsibleUserName.setLabel("责任人姓名");
            responsibleUserName.setDataUtilityId("PFEMATableUtility");
            table.addComponent(responsibleUserName);

            ColumnConfig targetDate = factory.newColumnConfig("targetDate", true);
            targetDate.setLabel("目标完成时间");
            targetDate.setDataUtilityId("PFEMATableUtility");
            table.addComponent(targetDate);

            ColumnConfig status = factory.newColumnConfig("status", true);
            status.setLabel("状态");
            status.setDataUtilityId("PFEMATableUtility");
            table.addComponent(status);

            ColumnConfig validate = factory.newColumnConfig("validate", true);
            validate.setLabel("采取基于证据的措施");
            validate.setDataUtilityId("PFEMATableUtility");
            table.addComponent(validate);

            ColumnConfig finishDate = factory.newColumnConfig("finishDate", true);
            finishDate.setLabel("完成时间");
            finishDate.setDataUtilityId("PFEMATableUtility");
            table.addComponent(finishDate);

            ColumnConfig severity = factory.newColumnConfig("severity", true);
            severity.setLabel("严重度");
            severity.setDataUtilityId("PFEMATableUtility");
            table.addComponent(severity);

            ColumnConfig occurrence = factory.newColumnConfig("occurrence", true);
            occurrence.setLabel("频度");
            occurrence.setDataUtilityId("PFEMATableUtility");
            table.addComponent(occurrence);

            ColumnConfig det = factory.newColumnConfig("det", true);
            det.setLabel("探测度");
            det.setDataUtilityId("PFEMATableUtility");
            table.addComponent(det);

            ColumnConfig ap = factory.newColumnConfig("ap", true);
            ap.setLabel("PFEMA措施优先级");
            ap.setDataUtilityId("PFEMATableUtility");
            table.addComponent(ap);

            ColumnConfig featureSymbol = factory.newColumnConfig("featureSymbol", true);
            featureSymbol.setLabel("特殊特性");
            featureSymbol.setDataUtilityId("PFEMATableUtility");
            table.addComponent(featureSymbol);

        }
        return table;
    }

    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        List<PFEMAItem> fmeaList = new ArrayList<>();
        JcaComponentParams jca_params = (JcaComponentParams) componentParams;
        NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
        NmOid primaryOid2 = cb.getPrimaryOid();
        WTPart part = null;
        if (primaryOid2 == null)
            return fmeaList;
        Object content = primaryOid2.getRef();
        if (content instanceof WTPart) {
            part = (WTPart) content;
            String partView = part.getView().getName();
            if(!"Design".equalsIgnoreCase(partView)){
                AIPFEMAReport aipfemaReportByPartNumber = PFEMAReportServer.getAIPFEMAReportByPartNumber(part.getNumber()+"-"+partView);
                if(StringUtils.isNotBlank(aipfemaReportByPartNumber.getPARTNUMBER())){
                    String pfemareportjson = aipfemaReportByPartNumber.getPFEMAREPORTJSON();
                    PFEMAData pfemaData = PFEMAReportServer.objectMapper.readValue(pfemareportjson, new TypeReference<PFEMAData>() {
                    });
                    fmeaList = pfemaData.getFmeaList();
                }
            }
        }
        return fmeaList;
    }


    ColumnConfig getColumn(final String id, final ComponentConfigFactory factory) {
        final ColumnConfig column = factory.newColumnConfig(id, true);
        column.setSortable(false);
        return column;
    }

    @Override
    public ConfigurableTable buildConfigurableTable(String s) throws WTException {
        return null;
    }
}
