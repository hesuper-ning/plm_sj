package ext.alphai.sinoboom.FMEA.report.domain;

/**
 * DFEMA数据库表
 */
public class AIPFEMAReport {
    private String PARTNUMBER;
    private String PFEMAREPORTJSON;
    private String UPDATETIME;

    public String getPARTNUMBER() {
        return PARTNUMBER;
    }

    public void setPARTNUMBER(String PARTNUMBER) {
        this.PARTNUMBER = PARTNUMBER;
    }

    public String getPFEMAREPORTJSON() {
        return PFEMAREPORTJSON;
    }

    public void setPFEMAREPORTJSON(String PFEMAREPORTJSON) {
        this.PFEMAREPORTJSON = PFEMAREPORTJSON;
    }

    public String getUPDATETIME() {
        return UPDATETIME;
    }

    public void setUPDATETIME(String UPDATETIME) {
        this.UPDATETIME = UPDATETIME;
    }
}
