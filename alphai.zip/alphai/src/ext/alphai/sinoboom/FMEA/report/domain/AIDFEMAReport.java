package ext.alphai.sinoboom.FMEA.report.domain;

/**
 * DFEMA数据库表
 */
public class AIDFEMAReport {
    private String PARTNUMBER;
    private String DFEMAREPORTJSON;
    private String UPDATETIME;

    public String getPARTNUMBER() {
        return PARTNUMBER;
    }

    public void setPARTNUMBER(String PARTNUMBER) {
        this.PARTNUMBER = PARTNUMBER;
    }

    public String getDFEMAREPORTJSON() {
        return DFEMAREPORTJSON;
    }

    public void setDFEMAREPORTJSON(String DFEMAREPORTJSON) {
        this.DFEMAREPORTJSON = DFEMAREPORTJSON;
    }

    public String getUPDATETIME() {
        return UPDATETIME;
    }

    public void setUPDATETIME(String UPDATETIME) {
        this.UPDATETIME = UPDATETIME;
    }
}
