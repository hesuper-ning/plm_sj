package ext.alphai.sinoboom.FMEA.report.vo;

import java.util.List;

/**
 * DFEMA 主数据JSON
 */
public class DFEMAData {
    private String projectNum;
    private String productName;
    // 通过productNum 确定是哪个部件
    private String productNum;
    private String dfmeaNum;
    private List<DFEMAItem> fmeaList;

    private String linkUrl;

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getProjectNum() {
        return projectNum;
    }

    public void setProjectNum(String projectNum) {
        this.projectNum = projectNum;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductNum() {
        return productNum;
    }

    public void setProductNum(String productNum) {
        this.productNum = productNum;
    }

    public String getDfmeaNum() {
        return dfmeaNum;
    }

    public void setDfmeaNum(String dfmeaNum) {
        this.dfmeaNum = dfmeaNum;
    }

    public List<DFEMAItem> getFmeaList() {
        return fmeaList;
    }

    public void setFmeaList(List<DFEMAItem> fmeaList) {
        this.fmeaList = fmeaList;
    }
}
