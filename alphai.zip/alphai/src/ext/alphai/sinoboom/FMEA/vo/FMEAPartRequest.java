package ext.alphai.sinoboom.FMEA.vo;

/**
 * 发送部件到FMEA的对象
 */
public class FMEAPartRequest {
    private String productNum;
    private String productName;
    private String productType;
    private String material;
    private String count;
    private String quality;
    private String remark;
    // 规格
    private String modelyearProject;
    // 英文名
    private String enProductName;
    // 大版本
    private String plm_version;
    public String getEnProductName() {
        return enProductName;
    }

    public void setEnProductName(String enProductName) {
        this.enProductName = enProductName;
    }

    public String getProductNum() {
        return productNum;
    }

    public void setProductNum(String productNum) {
        this.productNum = productNum;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getModelyearProject() {
        return modelyearProject;
    }

    public void setModelyearProject(String modelyearProject) {
        this.modelyearProject = modelyearProject;
    }

    public String getPlm_version() {
        return plm_version;
    }

    public void setPlm_version(String plm_version) {
        this.plm_version = plm_version;
    }
}
