package ext.alphai.sinoboom.FMEA.vo;

/**
 * 调用接口返回JSON
 */
public class FMEABOMResponse {
    private Meta meta;
    private String data;
    private Object dataFormat;
    private Boolean success;

    public Meta getMeta() {
        return meta;
    }

    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Object getDataFormat() {
        return dataFormat;
    }

    public void setDataFormat(Object dataFormat) {
        this.dataFormat = dataFormat;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }
}
