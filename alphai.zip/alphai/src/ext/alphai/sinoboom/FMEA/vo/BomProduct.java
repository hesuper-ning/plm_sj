package ext.alphai.sinoboom.FMEA.vo;

import java.util.ArrayList;
import java.util.List;

/**
 * BOM结构子项
 */
public class BomProduct {
    private String productNum;
    private String productName;
    private String remark;
    private String modelyearProject;
    private List<BomProduct> children;

    public String getModelyearProject() {
        return modelyearProject;
    }

    public void setModelyearProject(String modelyearProject) {
        this.modelyearProject = modelyearProject;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    // 构造函数
    public BomProduct() {
        this.children = new ArrayList<>();
    }

    // Getter和Setter方法
    public String getProductNum() {
        return productNum;
    }

    public void setProductNum(String productNum) {
        this.productNum = productNum;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<BomProduct> getChildren() {
        return children;
    }

    public void setChildren(List<BomProduct> children) {
        this.children = children;
    }
}
