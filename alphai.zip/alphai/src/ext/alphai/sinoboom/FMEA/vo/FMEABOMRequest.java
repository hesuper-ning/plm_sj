package ext.alphai.sinoboom.FMEA.vo;
import java.util.List;
/**
 * FMEA发送BOM的请求JSON对象
 */
public class FMEABOMRequest {
    private String bomNum;

    private String bomType;

    private String description;

    private String remark;

    private String productNum;

    private String productName;

    private List<BomProduct> bomProductList;

    public String getBomNum() {
        return bomNum;
    }

    public void setBomNum(String bomNum) {
        this.bomNum = bomNum;
    }

    public String getBomType() {
        return bomType;
    }

    public void setBomType(String bomType) {
        this.bomType = bomType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getProductNum() {
        return productNum;
    }

    public void setProductNum(String productNum) {
        this.productNum = productNum;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<BomProduct> getBomProductList() {
        return bomProductList;
    }

    public void setBomProductList(List<BomProduct> bomProductList) {
        this.bomProductList = bomProductList;
    }
}
