package ext.alphai.sinoboom.FMEA.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jndi.toolkit.chars.BASE64Encoder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.http.*;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import wt.change2.*;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.method.MethodContext;
import wt.method.RemoteAccess;
import wt.org.OrganizationServicesHelper;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.pom.WTConnection;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.Iterated;
import wt.vc.IterationInfo;
import wt.vc.VersionInfo;
import wt.vc.Versioned;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;

import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class CommonUtil implements RemoteAccess {
    static Logger logger = LogManager.getLogger(CommonUtil.class);
    /**
     * 转换中文格式，避免中文乱码
     *
     * @param value
     * @return
     * @throws WTException
     */
    public static String formatString(String value) throws WTException {
        try {
            if (value != null && value.trim().length() > 0) {
                byte[] tembyte = value.getBytes("gb2312");
                return new String(tembyte);
            } else {
                return value;
            }
        } catch (Exception e) {
            throw new WTException(e);
        }
    }

    /**
     * 处理返回的json中的信息提取需要的错误信息
     *
     * @param json 返回的json
     * @return {@link String}
     */
    public static String processResult(String json) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode rootNode = objectMapper.readTree(json);
            JsonNode isSuccessNode = rootNode.path("Result").path("ResponseStatus").path("IsSuccess");
            if (!isSuccessNode.asBoolean()) {
                JsonNode errorsNode = rootNode.path("Result").path("ResponseStatus").path("Errors");
                if (errorsNode.isArray()) {
                    StringBuilder errorMessageBuilder = new StringBuilder();
                    for (JsonNode errorNode : errorsNode) {
                        String errorMessage = errorNode.path("Message").asText();
                        errorMessageBuilder.append(errorMessage).append("\n");
                    }
                    return errorMessageBuilder.toString();
                }
            } else {
                return "IsSuccess";
            }
        } catch (Exception e) {
            logger.error("处理接口请求信息时出错", e);
        }
        return null;
    }

    /**
     * 将一个实体类中的所有字段转换为Map
     *
     * @param entity 实体类
     * @return 输出的Map
     */
    public static <T> Map<String, Object> entityToMap(T entity) {
        Map<String, Object> resultMap = new HashMap<>();

        // 使用反射获取类的所有字段
        Field[] fields = entity.getClass().getDeclaredFields();

        try {
            for (Field field : fields) {
                // 设置字段为可访问，以便获取私有字段的值
                field.setAccessible(true);

                // 将字段名和字段值添加到Map中
                resultMap.put(field.getName(), field.get(entity));
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        return resultMap;
    }





    /**
     * 根据用户名称/用户全名获取用户对象
     *
     * @param String
     * @param boolean
     * @return WTUser
     */
    @SuppressWarnings("deprecation")
    public static WTUser getUserByName(String name, boolean IsFull) {
        String parm = IsFull ? WTUser.FULL_NAME : WTUser.NAME;
        if (StringUtils.isBlank(name)) {
            return null;
        }
        try {
            Enumeration enumUser = OrganizationServicesHelper.manager.findUser(parm, name.trim());
            while (enumUser.hasMoreElements()) {
                return (WTUser) enumUser.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
     * 从QueryResult中获取需要类型的对象数据
     *
     * @param <T>   泛型对象
     * @param qr
     * @param clazz
     * @return
     */
    public static <T> ArrayList<T> getListFromQR(QueryResult qr, Class<T> clazz) {
        ArrayList<T> list = new ArrayList<T>();
        while (qr.hasMoreElements()) {
            Object obj = qr.nextElement();
            if (clazz.isInstance(obj)) {
                T castedObj = clazz.cast(obj);
                list.add(castedObj);
            }
        }
        return list;
    }

    /**
     * 连接Windchill数据库来运行自定义sql
     *
     * @return WTConnection 数据库连接
     * @throws Exception
     */
    public static WTConnection getWTConnection() {
        WTConnection wtconnection = null;
        try {
            MethodContext methodcontext = MethodContext.getContext();
            wtconnection = (WTConnection) methodcontext.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtconnection;
    }

    /**
     * 执行查询的SQL语句并返回结果 SQL示例：SELECT WTPARTNUMBER FROM WTPARTMASTER WHERE
     * WTPARTNUMBER LIKE ?
     *
     * @param sql    SQL语句
     * @param params 参数集
     * @return ResultSet 返回结果集
     */
    public static ResultSet excuteSelect(String sql, String... params) {
        try {
            WTConnection connection = CommonUtil.getWTConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                statement.setString(i + 1, params[i]);
            }

            // 输出当前执行查询操作的SQL语句
            String fullSql = sql;
            for (String param : params) {
                param = param.length() > 250 ? "此属性太长，不显示内容" : param;
                fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
            }
            System.out.println("--------当前执行查询操作的SQL语句为--------");
            System.out.println(fullSql);

            ResultSet resultSet = statement.executeQuery();
            return resultSet;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
     * 将传入的PBO解析为方便处理的List<T>
     *
     * @param <T>        泛型
     * @param obj        PBO
     * @param targetType 结果的类型
     * @return
     */
    public static <T> List<T> getListFromPBO(WTObject obj, Class<T> targetType) {
        List<T> list = new ArrayList<>();
        try {
            if (targetType.isInstance(obj)) {
                list.add(targetType.cast(obj));
            } else if (obj instanceof PromotionNotice) {
                PromotionNotice pn = (PromotionNotice) obj;
                QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeOrder2) {
                WTChangeOrder2 co = (WTChangeOrder2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeablesAfter(co);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeActivity2) {
                WTChangeActivity2 eca = (WTChangeActivity2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeRequest2) {
                WTChangeRequest2 ecr = (WTChangeRequest2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeables((ChangeRequestIfc) ecr);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else {
                System.out.println("数据不正确!");
            }
        } catch (ChangeException2 e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }











    /**
     * 携带信息并用POST请求外部系统（如SAP，OA）中的某个接口 存在账户和密码时则设置验证否则不设置 map为添加到Headers上的内容，无则填null
     *
     * @param url      访问目标接口的URL
     * @param username 访问目标接口需要验证的用户名
     * @param password 访问目标接口需要验证的密码
     * @param json     携带的json信息
     * @param method   请求的方式 GET/POST
     * @param map      请求头中需要添加的信息,没有填null
     * @return 返回的json信息
     */
    public static String requestInterface(String url, String username, String password, String json, String method,
                                          HashMap<String, String> map) {
        // 输出日志文件
        System.out.println("--------当前执行的请求接口的参数列表--------");
        System.out.println("URL: " + url);
        System.out.println("USERNAME: " + username + " PASSWORD:" + password);
        System.out.println("JSON: " + json);
        System.out.println("METHOD: " + method);
        System.out.println("HEADERS: ");

        RestTemplate restTemplate = new RestTemplate();
        // 添加BASIC认证
        String auth = username + ":" + password;
        String encodedAuth = new BASE64Encoder().encode(auth.getBytes(StandardCharsets.UTF_8));
        String authHeader = "Basic " + encodedAuth;

        restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        // 自定义请求头,添加headers内容
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", authHeader);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAcceptCharset(Collections.singletonList(StandardCharsets.UTF_8));
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        if (map != null) {
            Set<String> set = map.keySet();
            if (!set.isEmpty()) {
                for (String key : set) {
                    String value = map.get(key);
                    System.out.println("key:" + key + " value:" + map.get(key));
                    headers.add(key, value);
                }
            }
        }
        // 添加json参数,设置请求的方法并获取返回的json信息
        HttpEntity<String> entity = new HttpEntity<>(json, headers);
        ResponseEntity<String> responseEntity = method.equalsIgnoreCase("GET")
                ? restTemplate.exchange(url, HttpMethod.GET, entity, String.class)
                : restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

        if (responseEntity == null) {
            return null;
        }
        String resultJson = responseEntity.getBody();
        System.out.println("RESULTJSON: " + resultJson);
        return resultJson;
    }




    /**
     * 将对象转换为json内容
     *
     * @param entity 对象
     * @return {@link String}
     */
    public static String parseJson(Object entity) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(entity);
        } catch (IOException e) {
            logger.error("发送部件到ERP,转换json出错", e);
        }
        return "";
    }

    public static boolean isNumeric(String str) {
        // 使用正则表达式判断是否为数字，允许负号和正号开头，以及小数点
        return str.matches("-?\\d+(\\.\\d+)?");
    }


    /**
     * 浮点数转换为分数
     *
     * @param decimal 浮点数
     * @return {@link String[]}
     */
    public static String[] double2Fraction(double decimal) {
        String[] fraction = new String[2];
        BigDecimal bigDecimal = BigDecimal.valueOf(decimal);
        BigInteger numerator = bigDecimal.unscaledValue();
        BigInteger denominator = BigInteger.TEN.pow(bigDecimal.scale());
        BigInteger gcd = numerator.gcd(denominator);

        fraction[0] = String.valueOf(numerator.divide(gcd));
        fraction[1] = String.valueOf(denominator.divide(gcd));
        return fraction;
    }


    /**
     * 调用接口的方法
     * @param url
     * @param token
     * @param json
     * @param method
     * @return
     */
    public static String sendRequest(String url, String token, String json, String method) {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(Charset.forName("utf-8")));

        // 设置通用请求头
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + token);

        // 根据请求方法构造不同请求实体
        HttpMethod httpMethod = HttpMethod.resolve(method.toUpperCase());
        if (httpMethod == null) {
            throw new IllegalArgumentException("Unsupported HTTP method: " + method);
        }

        // DELETE/GET请求：无请求体，参数通过URL传递
        if (httpMethod == HttpMethod.DELETE || httpMethod == HttpMethod.GET) {
            // 构造带参数的URL（如果调用方需要传参）
            // 注意：实际参数应在调用前拼接到url中
            HttpEntity<String> entity = new HttpEntity<>(null, headers);
            return restTemplate.exchange(url, httpMethod, entity, String.class).getBody();
        }
        // POST/PUT等请求：使用JSON请求体
        else {
            HttpEntity<String> entity = new HttpEntity<>(json, headers);
            return restTemplate.exchange(url, httpMethod, entity, String.class).getBody();
        }
    }

    /**
     * 根据部件编号、版本、视图获取最新版本部件
     */
    public static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName){
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        try {
            if (org.apache.commons.lang3.StringUtils.isNotBlank(partNumber)) {
                partNumber = partNumber.trim();

                qs = new QuerySpec(WTPart.class);
                int[] index = new int[] { 0 };
                qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);

                if (org.apache.commons.lang3.StringUtils.isNotBlank(version)) {
                    version = version.trim();
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

                    if (org.apache.commons.lang3.StringUtils.isNotBlank(iteration)) {
                        iteration = iteration.trim();
                        qs.appendAnd();
                        qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
                    } else {
                        qs.appendAnd();
                        qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
                    }
                }

                if (org.apache.commons.lang3.StringUtils.isNotBlank(viewName)) {
                    viewName = viewName.trim();
                    View viewObj = ViewHelper.service.getView(viewName);
                    if (viewObj == null)
                        return null;
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
                }

                configSpec = new LatestConfigSpec();
                configSpec.appendSearchCriteria(qs);
                qr = PersistenceHelper.manager.find((StatementSpec) qs);
                qr = configSpec.process(qr);
                if (qr.hasMoreElements()) {
                    part = (WTPart) qr.nextElement();
                }
            }
        }catch (WTException e){
            e.printStackTrace();
        }
        return part;
    }
}

