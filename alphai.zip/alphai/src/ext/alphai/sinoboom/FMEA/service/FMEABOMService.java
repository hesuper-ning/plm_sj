package ext.alphai.sinoboom.FMEA.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sinoboom.FMEA.util.CommonUtil;
import ext.alphai.sinoboom.FMEA.util.IBAUtil;
import ext.alphai.sinoboom.FMEA.util.PropertiesUtil;
import ext.alphai.sinoboom.FMEA.vo.BomProduct;
import ext.alphai.sinoboom.FMEA.vo.FMEABOMRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * 向FMEA发送BOM的服务类
 */
public class FMEABOMService {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static String getFMEABOMJson(WTPart bom) throws JsonProcessingException {
        String json = "";
        String bomNumber = bom.getNumber();
        String bomView = bom.getView().getName();
        FMEABOMRequest fmeabomRequest = new FMEABOMRequest();
        // BOM头物料编号
        fmeabomRequest.setBomNum(bomNumber);
        String bomType = "";
        if("Design".equalsIgnoreCase(bomView)){
            bomType = "1";
        }else {
            bomType = "2";
        }
        // bom类别
        fmeabomRequest.setBomType(bomType);
        // bom 描述
        fmeabomRequest.setDescription("");
        // bom 工厂视图
        fmeabomRequest.setRemark(bomView);
        // 父产品编号
        fmeabomRequest.setProductNum(bomNumber);
        // 父产品名称
        fmeabomRequest.setProductName(bom.getName());
        // 结构
        fmeabomRequest.setBomProductList(getBOMStructure(bom, bomView));
        json = objectMapper.writeValueAsString(fmeabomRequest);
        return json;
    }

    /**
     * 递归获取BOM结构集合
     * @param bom
     * @return
     */
    public static List<BomProduct> getBOMStructure(WTPart bom, String bomView) {
        List<BomProduct> bomProductList = new ArrayList<>();

        try {
            // 获取当前部件的直接子部件
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(bom);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                WTPartMaster childMaster = usageLink.getUses();
                WTPart childPart = null;
                childPart = CommonUtil.getLatestWTPart(childMaster.getNumber(), null, null, bomView);
                if(childPart == null){
                    childPart = CommonUtil.getLatestWTPart(childMaster.getNumber(), null, null, "Design");
                }
                if(childPart == null){
                    continue;
                }
                // 创建BomProduct对象
                IBAUtil ibaUtil = new IBAUtil(childPart);
                BomProduct bomProduct = new BomProduct();
                bomProduct.setProductNum(childMaster.getNumber());
                bomProduct.setProductName(childMaster.getName());
                bomProduct.setRemark(childPart.getView().getName());
                bomProduct.setModelyearProject(ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("FMEA.spec.iba")));
                // 递归获取子部件的子部件
                List<BomProduct> children = getBOMStructure(childPart, bomView);
                if (!children.isEmpty()) {
                    bomProduct.setChildren(children);
                }
                // 添加到列表
                bomProductList.add(bomProduct);
            }
        } catch (WTException e) {
            e.printStackTrace();
        }

        return bomProductList;
    }



}
