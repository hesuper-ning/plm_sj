package ext.alphai.sinoboom.FMEA.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.windchill.option.model.OptionSet;
import ext.alphai.sinoboom.FMEA.util.IBAUtil;
import ext.alphai.sinoboom.FMEA.util.PropertiesUtil;
import ext.alphai.sinoboom.FMEA.vo.FMEAPartRequest;
import ext.cirpoint.mpm.common.constants.AttributesConstant;
import ext.cirpoint.mpm.common.constants.CommonConstant;
import ext.cirpoint.mpm.common.constants.SofttypeConstant;
import ext.cirpoint.mpm.common.constants.ViewConstant;
import ext.cirpoint.mpm.common.util.*;
import ext.cirpoint.mpm.esi.ERPDataHelper;
import ext.cirpoint.mpm.esi.ReleaseDataHelper;
import org.apache.commons.lang.StringUtils;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FMEAPartService {
    private static final ObjectMapper objectMapper = new ObjectMapper();


    /**
     * 获取发送部件到FMEA JSON
     * @param parts
     * @return
     */
    public static String getFMEAPartJson(List<WTPart> parts) throws JsonProcessingException, WTException {
        String fmeaPartJson = "";
        List<FMEAPartRequest> vos = new ArrayList<>();
        for (WTPart part : parts) {
            IBAUtil iba = new IBAUtil(part);
            FMEAPartRequest partRequest = new FMEAPartRequest();
            String partNumber = part.getNumber();
            String partVersion = part.getVersionIdentifier().getValue();
            String productNum = "";
            if(isDesignPart(part)){
                productNum = designPartGetNum(part);
            }
            // 如果是工厂视图
            if(isFactoryPart(part)){
                productNum = factoryPartGetNum(part);
            }
            partRequest.setProductNum(productNum);
            partRequest.setProductName(part.getName());
            partRequest.setProductType("");
            partRequest.setMaterial(iba.getIBAValue(PropertiesUtil.getValueByKey("FMEA.material.iba")));
            partRequest.setCount("");
            partRequest.setQuality(iba.getIBAValue(PropertiesUtil.getValueByKey("FMEA.weight.iba")));
            partRequest.setRemark(part.getView().getName());
            partRequest.setModelyearProject(iba.getIBAValue(PropertiesUtil.getValueByKey("FMEA.spec.iba")));
            partRequest.setEnProductName(iba.getIBAValue(PropertiesUtil.getValueByKey("FMEA.enname.iba")));
            partRequest.setPlm_version(partVersion);
            vos.add(partRequest);
        }
        fmeaPartJson = objectMapper.writeValueAsString(vos);
        return fmeaPartJson;
    }

    /**
     * 设计视图部件获取部件编号
     * @param part
     * @return
     */
    public static String designPartGetNum(WTPart part) throws WTException {
        IBAUtil ibaUtil = new IBAUtil(part);
        String number = "";
        boolean switchingFlag = false;
        // 部件为零部件且是虚拟的就为true
        String strType = TypeUtils.getTypeName(part);
        if (strType.contains(SofttypeConstant.TYPE_OUTSOURCINGPART)) {
            // 外购部件
        } else if (strType.contains(SofttypeConstant.TYPE_RAWMATERIAL)) {
            // 原辅材料
        } else if (strType.contains(SofttypeConstant.TYPE_PROCESSPARTS)) {
            // 工装
        } else {
            switchingFlag = part.isPhantom();
        }
        String colorPartNumber = ibaUtil.getIBAValue(AttributesConstant.IBA_PART_COLORPARTNUMBER);
        boolean isColorPartInstance = false;

        if (new ReleaseDataHelper().isSupperParentPart(part)) {

        } else {
            // 是否颜色件
            String colorpart = ibaUtil.getIBAValue(AttributesConstant.IBA_PART_ColorPart);
            // 类类型 取值逻辑 对于颜色件实例（本色件不传。判断逻辑：本色件编码不为空）是200
            // 分类代码 取值逻辑 对于颜色件实例取本色件对应的物料编码（需要考虑拼物料版本）
            if ((colorpart != null) && ("Y".equals(colorpart) || "是".equals(colorpart))) {
                if ((colorPartNumber != null) && (!"".equals(colorPartNumber))) {
                    isColorPartInstance = true;
                }
            }
        }
        if (isColorPartInstance) {
            // 获取颜色件实例编码
            StringBuffer sbf = new StringBuffer();
            if (isColorPartInstance(part, sbf)) {
                number = sbf.toString();
            }
            if (StringUtils.isEmpty(number)) {
                number = ERPDataHelper.getPartNumber(part);
            }
        } else {
            if(switchingFlag){
//                number= part.getNumber()+part.getVersionIdentifier().getValue();
                // 2025 11 06 正常虚拟件编号不带版本
                number= part.getNumber();
            }else {
                number = ERPDataHelper.getPartNumber(part);
            }
        }
        return part.getName().contains("工艺辅料包") ? part.getNumber() : number;
    }
    /**
     * 工厂视图部件获取部件编号
     * @param part
     * @return
     */
    public static String factoryPartGetNum(WTPart part) throws WTException {
        String number = "";
        number = part.getName().contains("工艺辅料包") ? part.getNumber() : getPartNumber2MDM(part);
        return number;
    }


    /**
     * 根据零件类型获取编号
     *
     * @param wtPart
     * @return
     */
    private static String getPartNumber2MDM(WTPart wtPart) throws WTException {
        String partNumber = ERPDataHelper.getPartNumber(wtPart);
        StringBuffer sbf = new StringBuffer();
        if (isColorPartInstance(wtPart, sbf)) {
            partNumber = sbf.toString();
        }
        return partNumber;
    }



    /**
     * 是否颜色件实例
     *
     * @param wtPart
     * @return
     * @throws WTException
     */
    public static boolean isColorPartInstance(WTPart wtPart, StringBuffer colorPartNubmer) throws WTException {
        String[] ibaNames = new String[] { AttributesConstant.IBA_PART_COLORPARTNUMBER,
                AttributesConstant.EXTENDEDCOLORED, AttributesConstant.IBA_PART_EXTERNAL_MATERIAL_GROUP,
                AttributesConstant.IBA_EBOMVERSION, AttributesConstant.IBA_PART_ColorPart };
        Map<String, Object> ibaMap = IBATool.getIBAValues(wtPart, ibaNames, false, null);
        // 本色件编码
        String colorPartNumber = getIBAValue(ibaMap, AttributesConstant.IBA_PART_COLORPARTNUMBER);
        // 本色件版本
        String ebomVersion = getIBAValue(ibaMap, AttributesConstant.IBA_EBOMVERSION);
        // 扩展颜色码
        String extendedColored = getIBAValue(ibaMap, AttributesConstant.EXTENDEDCOLORED);
        // 是否颜色件
        String colorPart = getIBAValue(ibaMap, AttributesConstant.IBA_PART_ColorPart);

        if (StringUtils.isNotEmpty(colorPart) && CommonConstant.Y.equals(colorPart) && StringUtils.isNotEmpty(extendedColored)
                && StringUtils.isNotEmpty(ebomVersion) && StringUtils.isNotEmpty(colorPartNumber)) {
            colorPartNubmer.append(colorPartNumber + ebomVersion + extendedColored);
            return true;
        }
        return false;
    }


    /**
     * 获取全属性的值
     *
     * @param ibaMap
     * @param ibaName
     * @return
     * @throws WTException
     */
    public static String getIBAValue(Map<String, Object> ibaMap, String ibaName) throws WTException {
        if (ibaMap != null && StringUtil.isNotEmpty(ibaName)) {
            if (ibaMap.containsKey(ibaName)) {
                String value = IBATool.getIBAValues(ibaMap, ibaName);
                if (value == null) {
                    value = "";
                }
                return value;
            }
        }
        return "";
    }

    /**
     * 发MDM SAP规则检查是否工厂视图
     * @param part
     * @return
     */
    public static boolean isFactoryPart(WTPart part){
        boolean result = false;
        String viewName = part.getView().getName();
        if(!(viewName.equalsIgnoreCase(ViewConstant.DESIGN) || viewName.equalsIgnoreCase(ViewConstant.MANUFACTURE)
                || viewName.equalsIgnoreCase(ViewConstant.PROCESS)
                || viewName.equalsIgnoreCase(ViewConstant.SERVICE))){
            result = true;
        }
        return result;
    }

    /**
     * 发MDM SAP规则检查是否设计视图
     * @param part
     * @return
     */
    public static boolean isDesignPart(WTPart part) {
        boolean result = false;
        String viewName = part.getView().getName();
        if (viewName.equalsIgnoreCase(ViewConstant.DESIGN)) {
            result = true;
        }
        return result;
    }
}
