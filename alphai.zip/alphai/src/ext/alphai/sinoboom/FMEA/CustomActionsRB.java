package ext.alphai.sinoboom.FMEA;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.sinoboom.FMEA.CustomActionsRB")
public class CustomActionsRB extends WTListResourceBundle {

    @RBEntry("Send Part To FEMA")
    public static final String PRIVATE_CONSTANT_01 ="FMEA.sendPart.description";

    @RBEntry("Send Part To FEMA")
    public static final String PRIVATE_CONSTANT_02 ="FMEA.sendPart.tooltip";


    @RBEntry("Send BOM To FEMA")
    public static final String PRIVATE_CONSTANT_03 ="FMEA.sendBOM.description";

    @RBEntry("Send BOM To FEMA")
    public static final String PRIVATE_CONSTANT_04 ="FMEA.sendBOM.tooltip";


    @RBEntry("FEMA Data")
    public static final String PRIVATE_CONSTANT_05 ="FEMAData.description";

    @RBEntry("FEMA Data")
    public static final String PRIVATE_CONSTANT_06 ="FEMAData.tooltip";

    @RBEntry("DFEMA Data")
    public static final String PRIVATE_CONSTANT_07 ="FMEA.DFEMAData.description";

    @RBEntry("DFEMA Data")
    public static final String PRIVATE_CONSTANT_08 ="FMEA.DFEMAData.tooltip";

    @RBEntry("PFEMA Data")
    public static final String PRIVATE_CONSTANT_09 ="FMEA.PFEMAData.description";

    @RBEntry("PFEMA Data")
    public static final String PRIVATE_CONSTANT_10 ="FMEA.PFEMAData.tooltip";


    @RBEntry("Send Date To FEMA")
    public static final String PRIVATE_CONSTANT_99 = "object.sendFEMADate.description";


    @RBEntry("DFEMA Report")
    public static final String DFEMAReport = "DFEMAReport";

    @RBEntry("PFEMA Report")
    public static final String PFEMAReport = "PFEMAReport";
}
