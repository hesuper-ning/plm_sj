package ext.alphai.sinoboom.FMEA;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.sinoboom.FMEA.CustomActionsRB_zh_CN")
public class CustomActionsRB_zh_CN extends WTListResourceBundle {


    @RBEntry("发送物料到FEMA")
    public static final String PRIVATE_CONSTANT_01 ="FMEA.sendPart.description";

    @RBEntry("发送物料到FEMA")
    public static final String PRIVATE_CONSTANT_02 ="FMEA.sendPart.tooltip";

    @RBEntry("发送BOM到FEMA")
    public static final String PRIVATE_CONSTANT_03 ="FMEA.sendBOM.description";

    @RBEntry("发送BOM到FEMA")
    public static final String PRIVATE_CONSTANT_04 ="FMEA.sendBOM.tooltip";

    @RBEntry("发送数据至FEMA")
    public static final String PRIVATE_CONSTANT_99 = "object.sendFEMADate.description";

    @RBEntry("FEMA 报表")
    public static final String PRIVATE_CONSTANT_05 ="FEMAData.description";

    @RBEntry("FEMA 报表")
    public static final String PRIVATE_CONSTANT_06 ="FEMAData.tooltip";


    @RBEntry("DFEMA 报表")
    public static final String PRIVATE_CONSTANT_07 ="FMEA.DFEMAData.description";

    @RBEntry("DFEMA 报表")
    public static final String PRIVATE_CONSTANT_08 ="FMEA.DFEMAData.tooltip";

    @RBEntry("PFEMA 报表")
    public static final String PRIVATE_CONSTANT_09 ="FMEA.PFEMAData.description";

    @RBEntry("PFEMA 报表")
    public static final String PRIVATE_CONSTANT_10 ="FMEA.PFEMAData.tooltip";


    @RBEntry("DFEMA 报表")
    public static final String DFEMAReport = "DFEMAReport";

    @RBEntry("PFEMA 报表")
    public static final String PFEMAReport = "PFEMAReport";
}
