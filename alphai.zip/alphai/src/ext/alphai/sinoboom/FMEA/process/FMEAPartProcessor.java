package ext.alphai.sinoboom.FMEA.process;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sinoboom.FMEA.service.FMEAPartService;
import ext.alphai.sinoboom.FMEA.util.CommonUtil;
import ext.alphai.sinoboom.FMEA.util.PropertiesUtil;
import ext.alphai.sinoboom.FMEA.vo.FMEABOMResponse;
import ext.alphai.sinoboom.FMEA.vo.Meta;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.Arrays;
import java.util.List;

/**
 * 向FMEA 发送BOM结构
 */
public class FMEAPartProcessor extends DefaultObjectFormProcessor {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        if(content instanceof WTPart){
            WTPart part = (WTPart) content;
            try {
                List<WTPart> parts = Arrays.asList(new WTPart[]{part});
                String fmeapartJson = FMEAPartService.getFMEAPartJson(parts);
                System.out.println("AI_发送Part到FMEA JSON："+fmeapartJson);
                String responseJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("FMEA.PART.URL"), "", fmeapartJson, "POST");
                System.out.println("AI_发送Part到FMEA 返回结果："+responseJson);
                FMEABOMResponse fmeabomResponse = objectMapper.readValue(responseJson, new TypeReference<FMEABOMResponse>() {});
                Meta meta = fmeabomResponse.getMeta();
                if(meta.getSuccess()){
                    formResult = new FormResult(FormProcessingStatus.SUCCESS);
                    formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null,null, new String[]{"部件同步FMEA成功!"}));
                }else {
                    formResult = new FormResult(FormProcessingStatus.FAILURE);
                    formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null,null, new String[]{meta.getMessage()}));
                }
            } catch (JsonProcessingException e) {
                throw new WTException(e);
            }

        }
        return formResult;
    }
}
