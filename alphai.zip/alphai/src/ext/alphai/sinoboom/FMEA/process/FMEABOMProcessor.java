package ext.alphai.sinoboom.FMEA.process;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sinoboom.FMEA.service.FMEABOMService;
import ext.alphai.sinoboom.FMEA.util.CommonUtil;
import ext.alphai.sinoboom.FMEA.util.PropertiesUtil;
import ext.alphai.sinoboom.FMEA.vo.Meta;
import wt.fc.ObjectReference;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;
import ext.alphai.sinoboom.FMEA.vo.FMEABOMResponse;
import java.util.List;

/**
 * 向FMEA 发送BOM结构
 */
public class FMEABOMProcessor extends DefaultObjectFormProcessor {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        if(content instanceof WTPart){
            WTPart part = (WTPart) content;
            try {
                String fmeabomJson = FMEABOMService.getFMEABOMJson(part);
                System.out.println("AI_发送BOM到FMEA JSON："+fmeabomJson);
                String responseJson = CommonUtil.sendRequest(PropertiesUtil.getValueByKey("FMEA.BOM.URL"), "", fmeabomJson, "POST");
                System.out.println("AI_发送BOM到FMEA 返回结果："+responseJson);
                FMEABOMResponse fmeabomResponse = objectMapper.readValue(responseJson, new TypeReference<FMEABOMResponse>() {});
                Meta meta = fmeabomResponse.getMeta();
                if(meta.getSuccess()){
                    formResult = new FormResult(FormProcessingStatus.SUCCESS);
                    formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null,null, new String[]{"BOM同步FMEA成功!"}));
                }else {
                    formResult = new FormResult(FormProcessingStatus.FAILURE);
                    formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null,null, new String[]{meta.getMessage()}));
                }
            } catch (JsonProcessingException e) {
                throw new WTException(e);
            }

        }
        return formResult;
    }
}
