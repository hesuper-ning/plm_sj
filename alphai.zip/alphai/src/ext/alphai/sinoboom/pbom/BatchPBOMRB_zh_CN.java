package ext.alphai.sinoboom.pbom;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;


@RBUUID("ext.alphai.sinoboom.pbom.BatchPBOMRB_zh_CN")
public class BatchPBOMRB_zh_CN extends WTListResourceBundle {

    @RBEntry("批量PBOM视图扩充")
    public static final String BATCH_PBOM_TITLE= "PBOM.batchCreatePBOM.title";

    @RBEntry("批量PBOM视图扩充")
    public static final String BATCH_PBOM_TOOLTIP = "PBOM.batchCreatePBOM.tooltip";

    @RBEntry("批量PBOM视图扩充")
    public static final String BATCH_PBOM_DES= "PBOM.batchCreatePBOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String BATCH_PBOM_ICON = "PBOM.batchCreatePBOM.icon";
}
