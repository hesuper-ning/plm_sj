package ext.alphai.sinoboom.pbom.bean;

import java.util.List;

public class PBOMInfoBean {
    private String oid; // oid
    private String partNumber; // 编号
    private String partName; // 名称
    private String partVersion;// 版本
    private String partState;//状态
    private String partSAPGroup;//SAP物料组
    private String phantom; // 虚拟制造部件
    private String partFactory;//工厂
    private String technologyType; //工艺类型
    private String source;//采购类型
    private List<PBOMInfoBean> sonPart;

    public String getPhantom() {
        return phantom;
    }

    public void setPhantom(String phantom) {
        this.phantom = phantom;
    }

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPartVersion() {
        return partVersion;
    }

    public void setPartVersion(String partVersion) {
        this.partVersion = partVersion;
    }

    public String getPartState() {
        return partState;
    }

    public void setPartState(String partState) {
        this.partState = partState;
    }

    public String getPartSAPGroup() {
        return partSAPGroup;
    }

    public void setPartSAPGroup(String partSAPGroup) {
        this.partSAPGroup = partSAPGroup;
    }



    public String getPartFactory() {
        return partFactory;
    }

    public void setPartFactory(String partFactory) {
        this.partFactory = partFactory;
    }

    public String getTechnologyType() {
        return technologyType;
    }

    public void setTechnologyType(String technologyType) {
        this.technologyType = technologyType;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public List<PBOMInfoBean> getSonPart() {
        return sonPart;
    }

    public void setSonPart(List<PBOMInfoBean> sonPart) {
        this.sonPart = sonPart;
    }
}
