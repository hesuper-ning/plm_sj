package ext.alphai.sinoboom.pbom.processor;

import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.sinoboom.pbom.bean.PBOMInfoBean;
import ext.cirpoint.mpm.common.constants.AttributesConstant;
import ext.cirpoint.mpm.common.constants.LifecycleConstant;
import ext.cirpoint.mpm.common.constants.ViewConstant;
import ext.cirpoint.mpm.common.util.IBAUtils;
import ext.cirpoint.mpm.common.util.PartUtils;
import ext.cirpoint.mpm.common.util.StringUtil;
import ext.cirpoint.mpm.common.util.ToolUtils;
import ext.cirpoint.mpm.pbom.resource.PartResource;
import ext.cirpoint.mpm.pbom.resource.ResourceInternational;
import ext.cirpoint.mpm.pbom.util.PBOMHelper;
import ext.cirpoint.mpm.pdf.card.function.Check;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.fc.PersistenceServerHelper;
import wt.inf.container.WTContainer;
import wt.part.*;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import java.lang.reflect.Type;
import java.util.*;

/**
 * PBOM批量创建执行类 - 支持多父部件多工厂批量扩充
 *
 * @version: 2026年
 */
public class BatchCreatePBOMProcessor extends DefaultObjectFormProcessor {

    private static final Logger logger = LogManager.getLogger(BatchCreatePBOMProcessor.class.getName());
    private static final Gson gson = new Gson();

    @Override
    public FormResult postProcess(NmCommandBean nmcommandbean, List list) throws WTException {
        FormResult result = super.postProcess(nmcommandbean, list);

        boolean bool = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            // 从前端获取PBOM结构JSON数据（包含多个父部件及其子部件结构）
            String pbomStructureJson = (String) nmcommandbean.getTextParameter("PBOMStructure");

            if (StringUtil.isEmpty(pbomStructureJson)) {
                throw new WTException("PBOM结构数据不能为空！");
            }

            logger.debug("PBOMStructure JSON: " + pbomStructureJson);

            // 解析PBOM结构JSON - 获取多个父部件列表
            List<PBOMInfoBean> parentPartList = parsePBOMStructure(pbomStructureJson);

            if (parentPartList == null || parentPartList.isEmpty()) {
                throw new WTException("PBOM结构数据解析失败或为空！");
            }

            // 校验整棵PBOM树所有部件是否都维护了工厂值
            validatePartFactoryForTree(parentPartList);

            logger.debug("共获取到 " + parentPartList.size() + " 个父部件");

            // 遍历每个父部件
            for (PBOMInfoBean parentBean : parentPartList) {
                processParentPart(parentBean);
            }

            result.setStatus(FormProcessingStatus.SUCCESS);
            result.setSkipPageRefresh(true);
            result.addFeedbackMessage(new FeedbackMessage(
                    FeedbackType.SUCCESS, null, null, null,
                    new String[] {ResourceInternational.prompt_15 + "，共处理PBOM：" + parentPartList.size() + "个"}
            ));

//            String jString = "window.close();";
//            result.setNextAction(FormResultAction.JAVASCRIPT);
//            result.setJavascript(jString);

        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
        } finally {
            SessionServerHelper.manager.setAccessEnforced(bool);
        }

        return result;
    }

    /**
     * 校验PBOM整棵树中所有部件是否都维护了工厂值
     */
    private void validatePartFactoryForTree(List<PBOMInfoBean> parentPartList) throws WTException {
        Set<String> missingPartNumbers = new LinkedHashSet<>();
        for (PBOMInfoBean parentBean : parentPartList) {
            collectMissingFactoryPartNumbers(parentBean, missingPartNumbers);
        }

        if (!missingPartNumbers.isEmpty()) {
            throw new WTException("以下部件未维护工厂，请先填写后再提交：" + String.join("、", missingPartNumbers));
        }

    }

    /**
     * 递归收集未维护工厂值的部件编号（包含子部件）
     */
    private void collectMissingFactoryPartNumbers(PBOMInfoBean bean, Set<String> missingPartNumbers) {
        if (bean == null) {
            return;
        }

        if (StringUtil.isEmpty(bean.getPartFactory())) {
            String partNumber = bean.getPartNumber();
            if (StringUtil.isEmpty(partNumber)) {
                partNumber = "[未知编号]";
            }
            missingPartNumbers.add(partNumber);
        }

        if (bean.getSonPart() != null && !bean.getSonPart().isEmpty()) {
            for (PBOMInfoBean sonBean : bean.getSonPart()) {
                collectMissingFactoryPartNumbers(sonBean, missingPartNumbers);
            }
        }
    }

    /**
     * 处理单个父部件及其子树
     */
    private void processParentPart(PBOMInfoBean parentBean) throws WTException {
        String parentOid = parentBean.getOid();
        if (StringUtil.isEmpty(parentOid)) {
            throw new WTException("父部件OID不能为空：" + parentBean.getPartNumber());
        }

        // 获取父部件对象
        WTPart parentPart = (WTPart) ToolUtils.getObjectByOid(parentOid);
        if (parentPart == null) {
            throw new WTException("未找到父部件，OID：" + parentOid);
        }

        logger.debug("处理父部件: " + parentPart.getNumber());

        WTContainer container = parentPart.getContainer();

        // 获取父部件零部件图号
        IBAUtils parentIba = new IBAUtils(parentPart);
        String remarks = parentIba.getIBAValue(AttributesConstant.IBA_DRAWING_NO);
        remarks = remarks == null ? "" : remarks;

        // 从当前父节点获取工厂列表（逗号分割）
        String partFactory = parentBean.getPartFactory();
        List<String> factoryList = getFactoryList(partFactory);
        if (factoryList.isEmpty()) {
            throw new WTException("父部件 " + parentPart.getNumber() + " 的工厂不能为空");
        }

        logger.debug("父部件 " + parentPart.getNumber() + " 的工厂列表: " + factoryList);

        // 收集当前父部件下的所有部件信息（包括自身和所有子部件，以及它们的工艺类型和采购类型）
        List<PartInfo> allPartInfoList = new ArrayList<>();
        collectAllPartInfo(parentBean, allPartInfoList);

        // 为每个工厂创建PBOM视图
        for (String factoryName : factoryList) {
            String taskName = parentPart.getNumber() + ResourceInternational.prompt_16;
            createPBOMForFactory(allPartInfoList, factoryName, container, taskName, remarks, parentPart);
        }
    }

    /**
     * 部件信息封装类
     */
    private static class PartInfo {
        String partNumber;
        String technologyType;  // 工艺类型
        String source;          // 采购类型/制造属性

        PartInfo(String partNumber, String technologyType, String source) {
            this.partNumber = partNumber;
            this.technologyType = technologyType;
            this.source = source;
        }
    }

    /**
     * 收集当前节点下的所有部件信息（包括自身）
     */
    private void collectAllPartInfo(PBOMInfoBean bean, List<PartInfo> resultList) {
        if (bean == null) {
            return;
        }

        // 添加当前部件信息
        String partNumber = bean.getPartNumber();
        String technologyType = bean.getTechnologyType();
        String source = bean.getSource();

        if (StringUtil.isNotEmpty(partNumber)) {
            resultList.add(new PartInfo(partNumber, technologyType, source));
        }

        // 递归处理子部件
        if (bean.getSonPart() != null && !bean.getSonPart().isEmpty()) {
            for (PBOMInfoBean sonBean : bean.getSonPart()) {
                collectAllPartInfo(sonBean, resultList);
            }
        }
    }

    /**
     * 为指定工厂创建PBOM视图
     */
    private void createPBOMForFactory(List<PartInfo> partInfoList,
                                      String factoryName,
                                      WTContainer container,
                                      String taskName,
                                      String remarks,
                                      WTPart parentPart) throws WTException {

        // 收集所有需要创建的部件
        List<WTPart> designParts = new ArrayList<>();
        Map<String, PartInfo> partInfoMap = new HashMap<>();

        for (PartInfo partInfo : partInfoList) {
            String partNumber = partInfo.partNumber;

            // 获取设计视图部件
            WTPart designPart = PartUtils.getPartByNumberAndView(partNumber, ViewConstant.DESIGN);
            if (designPart == null) {
                throw new WTException("未找到设计视图部件：" + partNumber);
            }

            designParts.add(designPart);
            partInfoMap.put(partNumber, partInfo);
        }

        if (designParts.isEmpty()) {
            logger.warn("工厂 " + factoryName + " 没有需要处理的部件");
            return;
        }

        // 验证所有部件状态（必须都是已发布状态）
        List<WTPart> invalidParts = Check.filter(designParts,
                part -> !LifecycleConstant.STATE_RELEASED.equals(part.getLifeCycleState().getValue()));

        if (!invalidParts.isEmpty()) {
            StringBuffer error = new StringBuffer();
            for (WTPart wtPart : invalidParts) {
                error.append(WTMessage.getLocalizedMessage(
                        PartResource.class.getName(),
                        PartResource.prompt_20,
                        new Object[]{wtPart.getNumber()},
                        SessionHelper.getLocale()
                )).append("\r\n");
            }
            throw new WTException(error.toString());
        }

        // 去重
        List<WTPart> uniqueParts = new ArrayList<>(
                Check.toMap(() -> designParts, WTPart::getNumber).values()
        );

        logger.debug("工厂 " + factoryName + " 需要创建视图的部件数量: " + uniqueParts.size());

        // 批量创建工厂视图部件
        Map<String, WTPart> newPartMap = new HashMap<>();
        String msg = PBOMHelper.createNewPartView(uniqueParts, factoryName, newPartMap);
        if (StringUtil.isNotEmpty(msg)) {
            throw new WTException(msg);
        }

        // 反写工艺类型和制造属性
        for (Map.Entry<String, WTPart> entry : newPartMap.entrySet()) {
            String partNumber = entry.getKey();
            WTPart newPart = entry.getValue();
            PartInfo partInfo = partInfoMap.get(partNumber);

            if (partInfo != null && newPart != null) {
                boolean needUpdate = false;

                // 设置工艺类型
                String technologyType = partInfo.technologyType;
                if (StringUtil.isNotEmpty(technologyType)) {
                    IBAUtils.setIBAStringValue(newPart, AttributesConstant.IBA_PROCESSTYPE, technologyType);
                    needUpdate = true;
                }

                // 设置采购类型（制造属性）
                String source = partInfo.source;
                if (StringUtil.isNotEmpty(source)) {
                    Source partSource = getSourceByValue(source);
                    if (partSource != null && !partSource.equals(newPart.getSource())) {
                        newPart.setSource(partSource);
                        needUpdate = true;
                    }
                }

                if (needUpdate) {
                    PersistenceServerHelper.manager.update(newPart);
                }
            }
        }

        // 收集需要分配任务的部件（自制件且非胶管总成、非料坯）
        List<WTPart> partsForTask = new ArrayList<>();
        for (WTPart newPart : newPartMap.values()) {
            IBAUtils newIba = new IBAUtils(newPart);

            // 胶管总成不生成工艺任务
            String hoseValue = newIba.getIBAValue(AttributesConstant.IBA_HOSE);
            if (hoseValue != null && "true".equalsIgnoreCase(hoseValue)) {
                continue;
            }

            // 查看是否为自制件
            if (newPart.getSource() != null && "make".equalsIgnoreCase(newPart.getSource().toString())) {
                // 料坯、毛坯不产生工艺任务
                String partType = newIba.getIBAValue(AttributesConstant.IBA_PARTTYPE1);
                List<String> excludePartTypes = PBOMHelper.getDifftypeList();
                if (("辅料".equals(partType)) || (excludePartTypes != null && excludePartTypes.contains(partType))) {
                    continue;
                }
                partsForTask.add(newPart);
            }
        }

        // 分配工艺任务
        if (!partsForTask.isEmpty()) {
            logger.debug("工厂 " + factoryName + " 需要分配任务的部件数量: " + partsForTask.size());
            PBOMHelper.PBOMAssigningTasks(partsForTask, taskName, container, factoryName, remarks);
        } else {
            logger.debug("工厂 " + factoryName + " 没有需要分配任务的自制件");
        }
    }

    /**
     * 从字符串解析工厂列表（逗号分割）
     */
    private List<String> getFactoryList(String partFactory) {
        List<String> factoryList = new ArrayList<>();
        if (StringUtil.isNotEmpty(partFactory)) {
            String[] factories = partFactory.split(",");
            for (String factory : factories) {
                String trimmedFactory = factory.trim();
                if (StringUtil.isNotEmpty(trimmedFactory)) {
                    factoryList.add(trimmedFactory);
                }
            }
        }
        return factoryList;
    }

    /**
     * 根据字符串值获取Source枚举
     */
    private Source getSourceByValue(String sourceValue) {
        if (StringUtil.isEmpty(sourceValue)) {
            return null;
        }

        Source[] sources = PartUtils.getSourceSet();
        for (Source source : sources) {
            if (source.toString().equals(sourceValue)) {
                return source;
            }
        }
        return null;
    }

    /**
     * 解析PBOM结构JSON
     */
    private List<PBOMInfoBean> parsePBOMStructure(String jsonStr) {
        try {
            Type listType = new TypeToken<List<PBOMInfoBean>>() {}.getType();
            List<PBOMInfoBean> result = gson.fromJson(jsonStr, listType);
            return result;
        } catch (Exception e) {
            logger.error("解析PBOM结构JSON失败: " + e.getMessage(), e);
            return null;
        }
    }
}