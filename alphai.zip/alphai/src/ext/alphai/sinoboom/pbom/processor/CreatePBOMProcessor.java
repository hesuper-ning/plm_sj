
package ext.alphai.sinoboom.pbom.processor;

import com.ptc.core.components.beans.TableDataManagerBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.forms.FormResultAction;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.cirpoint.mpm.common.constants.AttributesConstant;
import ext.cirpoint.mpm.common.constants.CommonConstant;
import ext.cirpoint.mpm.common.constants.LifecycleConstant;
import ext.cirpoint.mpm.common.constants.ViewConstant;
import ext.cirpoint.mpm.common.util.IBAUtils;
import ext.cirpoint.mpm.common.util.PartUtils;
import ext.cirpoint.mpm.common.util.StringUtil;
import ext.cirpoint.mpm.common.util.ToolUtils;
import ext.cirpoint.mpm.pbom.resource.PartResource;
import ext.cirpoint.mpm.pbom.resource.ResourceInternational;
import ext.cirpoint.mpm.pbom.util.PBOMHelper;
import ext.cirpoint.mpm.pdf.card.function.Check;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import wt.fc.Persistable;
import wt.fc.PersistenceServerHelper;
import wt.fc.ReferenceFactory;
import wt.inf.container.WTContainer;
import wt.part.*;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;
import wt.vc.VersionReference;

import java.util.*;

/**
 * PBOM扩展视图执行类
 * 
 * @version: 2018年8月7日
 * @author Houjs
 */
public class CreatePBOMProcessor extends DefaultObjectFormProcessor {

	private static final Logger logger = LogManager.getLogger(CreatePBOMProcessor.class.getName());

	@Override
	public FormResult doOperation(NmCommandBean nmcommandbean, List list)
			throws WTException {
		FormResult result = super.doOperation(nmcommandbean, list);

		boolean bool = SessionServerHelper.manager.setAccessEnforced(false);
		try {
			// SessionServerHelper.manager.setAccessEnforced(false);
			String factoryName = (String) nmcommandbean.getTextParameter("factoryNameId");
			String oid = (String) nmcommandbean.getRequest().getParameter("oid");
            //获取父部件
			WTPart parentPart = (WTPart) new NmOid(oid).getRefObject();
            //获取父部件容器
			WTContainer container = parentPart.getContainer();
            //父部件编号+prompt_16
			String taskName = parentPart.getNumber()+ ResourceInternational.prompt_16;

            //获取父部件零部件图号
			IBAUtils iba = new IBAUtils(parentPart);
            String remarks = iba.getIBAValue(AttributesConstant.IBA_DRAWING_NO);//胶管总成
            remarks = remarks==null?"":remarks;

            //获取PBOM结构  含父部件，子部件，替代料
			logger.debug("--->>>"+factoryName);
			Map<String, Map<String, String>> dataMap = getSelectedData(nmcommandbean, "ext.cirpoint.mpm.pbom.form.SetPBOMMsgTreeBuilder");
            System.out.println("ext.cirpoint.mpm.pbom.form.SetPBOMMsgTreeBuilder");
            // 遍历打印确保看到完整内容
            for (Map.Entry<String, Map<String, String>> entry : dataMap.entrySet()) {
                System.out.println("Key: " + entry.getKey());
                System.out.println("Value: " + entry.getValue());
            }
			Set<String> oidSet = dataMap.keySet();
			List<WTPart> partList = new ArrayList<WTPart>();
			Map<String, WTPart> designPartMap = new HashMap<String, WTPart>();
			for (String oidKey : oidSet) {
				Object obj = ToolUtils.getObjectByOid(oidKey);
				if (obj instanceof WTPart) {
					WTPart part = (WTPart) obj;
					part = PartUtils.getReleateDesignPartByNumber(part.getNumber());
					if(part!=null){
						partList.add(part);
						designPartMap.put(oidKey, part);
					}
				}else if (obj instanceof WTPartSubstituteLink) {
					WTPartSubstituteLink substituteLink = (WTPartSubstituteLink) obj;
					WTPartMaster subMaster = substituteLink.getSubstitutes();
					WTPart part = PartUtils.getReleateDesignPartByNumber(subMaster.getNumber());
					partList.add(part);
					designPartMap.put(oidKey, part);
				}else if (obj instanceof WTPartUsageLink) {
					WTPartUsageLink link = (WTPartUsageLink) obj;
					WTPartMaster subMaster = link.getUses();
					WTPart part = PartUtils.getReleateDesignPartByNumber(subMaster.getNumber());
					partList.add(part);
					designPartMap.put(oidKey, part);
				}
			}
			List<WTPart> filterList = Check.filter(partList,item -> !LifecycleConstant.STATE_RELEASED.equals(item.getLifeCycleState().getValue()));
			if(!filterList.isEmpty()){
				StringBuffer error = new StringBuffer();
				for (WTPart wtPart : filterList) {
					error.append(WTMessage.getLocalizedMessage(PartResource.class.getName(), PartResource.prompt_20, new Object[]{wtPart.getNumber()},
							SessionHelper.getLocale())).append("\r\n");
				}
				throw new WTException(error.toString());
			}
			Map<String, WTPart> newPartMap = new HashMap<String, WTPart>();
			//去重
			List<WTPart> wtParts = new ArrayList<>(Check.toMap(() -> partList, WTPart::getNumber).values());
			String msg = PBOMHelper.createNewPartView(wtParts, factoryName,newPartMap);
			if (StringUtil.isNotEmpty(msg)) {
				throw new WTException(msg);
			}

			List<WTPart> allParts = new ArrayList<WTPart>();
			List<WTPart> processParts = new ArrayList<WTPart>();
			List<String> newPartList = new ArrayList<String>(); 
			//反写“工艺类型”、“制造属性”
			for (String oidKey : oidSet) {
				WTPart part = null ; 
				if(designPartMap!=null){
				    part = designPartMap.get(oidKey);

				}

				if (part != null) {
				    String partNumber = part.getNumber();
					WTPart newPart = PartUtils.getPartByNumberAndView(partNumber,  ViewConstant.DESIGN);
					Map<String, String> valueMap = dataMap.get(oidKey);

					String technologyType = valueMap.get("technologyType");//工艺类型
					if (StringUtil.isNotEmpty(technologyType)) {
						IBAUtils.setIBAStringValue(newPart, AttributesConstant.IBA_PROCESSTYPE, technologyType);
					}
					WTPart newPart01 = newPartMap.get(partNumber);

					//采购类型
					String zz = valueMap.get("zz");//制造属性
					Source[] sources =  PartUtils.getSourceSet();
					Source partsource = null;
					if (StringUtil.isNotEmpty(zz)) {
						for (Source source : sources) {
							if (source.toString().equals(zz)) {
								partsource = source;
							}
						}
						if (partsource!=null) {
						    if(logger.isDebugEnabled()){
				                logger.debug("partsource: "+partsource.toString());
				            }
						    if(partsource!=null && newPart01!=null&& !partsource.equals(newPart01.getSource())){
						        newPart01.setSource(partsource);
				                PersistenceServerHelper.manager.update(newPart01);

				            }
							// if (CommonConstant.SOURCE_MAKE.equalsIgnoreCase(partsource.toString())) {
					            
					           // 胶管总成不生成 工艺任务
                                IBAUtils newiba = new IBAUtils(newPart01);
                                String ibavalue = newiba.getIBAValue(AttributesConstant.IBA_HOSE);//胶管总成
                                if (ibavalue != null && CommonConstant.TRUE.equalsIgnoreCase(ibavalue)) {
                                    continue;
                                }
                                // 料坯 毛坯不产生工艺任务
                                ibavalue = newiba.getIBAValue(AttributesConstant.IBA_PARTTYPE1);// 零部件类型
                                List<String> listpartType = PBOMHelper.getDifftypeList();
                                if ((!"辅料".equals(ibavalue)) && listpartType.contains(ibavalue)) {
                                    continue;
                                }
								allParts.add(newPart01);
                                
//								//String processType = iba.getIBAValue(AttributesConstant.IBA_PROCESSTYPE);//工艺类型
//								if(logger.isDebugEnabled()){
//	                                logger.debug("technologyType: "+technologyType);
//	                            }
//								if (AttributesConstant.IBA_KEY_ASSEMBLY.equals(technologyType)) {
//									assemblyParts.add(newPart01);
//								}else if (AttributesConstant.IBA_KEY_WELD.equals(technologyType)) {
//									processParts.add(newPart01);
//								}
							// }
							ReferenceFactory rf = new ReferenceFactory();
		                    VersionReference vr = VersionReference.newVersionReference(newPart01);
		                    String vroid = rf.getReferenceString(vr);
		                    if(!newPartList.contains(vroid)){
		                        newPartList.add(vroid);
		                    }
							//PersistenceServerHelper.manager.update(newPart01);
							//IBAUtils.setIBAStringValue(newPart, AttributesConstant.IBA_SOURCESTATE, "");//设置外协状态为空
							//DataImportUtil.updateDesignSourceState(newPart, newPart01.getViewName(), partsource);//外协状态回写
						}
					}
				}
			}
//			if(logger.isDebugEnabled()){
//			    logger.debug("assemblyParts: "+assemblyParts.size());
//			    logger.debug("processParts: "+processParts.size());
//			}
			PBOMHelper.PBOMAssigningTasks(allParts, taskName, container,factoryName,remarks);
			// 自动发送MDM创建工厂视图信息 2019-6-10 与业务讨论确认，页面扩充视图时，暂不扩充

			
			result.setStatus(FormProcessingStatus.SUCCESS);
			result.setSkipPageRefresh(true);
			result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, null, null, null, new String[] {ResourceInternational.prompt_15 }));
			String jString = "window.close();" ;
			result.setNextAction(FormResultAction.JAVASCRIPT);
			result.setJavascript(jString);
		} catch (JSONException e) {
			logger.error(e.getLocalizedMessage(), e);
		} finally {
			SessionServerHelper.manager.setAccessEnforced(bool);
		}
		String jString = "window.close();" ;
		result.setNextAction(FormResultAction.JAVASCRIPT);
		result.setJavascript(jString);

		return result;
	}



	/**
	 * 根据对象得到oid
	 * 
	 * @version: 2018年8月7日
	 * @author Houjs
	 */
	public static String getOidByObject(Persistable persistable) throws WTRuntimeException, WTException {
		String oid = "";
		ReferenceFactory refFactory = new ReferenceFactory();
		oid = refFactory.getReferenceString(persistable);
		return oid;
	}

	/**
	 * 根据nmcommandbean获取JS封装的数据
	 * 
	 * @version: 2018年8月7日
	 * @author Houjs
	 * @param nmcommandbean
	 * @throws WTException
	 * @throws JSONException
	 */
	public static Map<String, Map<String, String>> getSelectedData(NmCommandBean nmcommandbean, String tableId)
			throws WTException, JSONException {
		Map<String, Map<String, String>> result = new HashMap<String, Map<String, String>>();
		TableDataManagerBean tabledatamanagerbean = TableDataManagerBean.newInstance(nmcommandbean);
		List<NmOid> nmoids = null;
		try {
			nmoids = tabledatamanagerbean.getOids(tableId);
		} catch (Exception nmoidsExp) {
			nmoidsExp.printStackTrace();
		}
		if (nmoids != null) {
			for (NmOid nmOid : nmoids) {
				// logger.debug("nmOid=" + nmOid);
				Map<String, String> map = new HashMap<String, String>();
				if (nmOid != null) {
					Object parentListJSON = tabledatamanagerbean.getData("parentListJSON", tableId, nmOid);
					if (parentListJSON != null) {
						if (parentListJSON instanceof JSONObject) {
							JSONObject parentJSON = (JSONObject) parentListJSON;
							// outDebugInfo("parentJSON="+parentJSON.toJSONString());
							// parentJSON.getString(key)
							Iterator keys = parentJSON.keys();
							while (keys.hasNext()) {
								String key = (String) keys.next();
								String value = parentJSON.getString(key);
								map.put(key, value);
							}
						}
					}
				}
				result.put(nmOid.toString(), map);
			}
		}
		return result;
	}

}
