package ext.alphai.sinoboom.pbom.service;

import com.ptc.netmarkets.model.NmOid;
import ext.alphai.sinoboom.pbom.bean.PBOMInfoBean;
import ext.alphai.sinoboom.pbom.util.IBAUtil;
import ext.alphai.sinoboom.pbom.util.PartUtil;
import ext.alphai.sinoboom.pbom.vo.ResponseVo;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BatchPBOMService {

    static String SAP_MATERIAL_GROUP = "SapMaterialGroup";

    public static ResponseVo getPartStructure(String partNumber, boolean isSingle) throws Exception {
        WTPart wtPartByNumber = PartUtil.getLatestWTPart(partNumber, "Design");
        if (wtPartByNumber == null) {
            return ResponseVo.error(201, partNumber + "编号部件不存在");
        }

        //如果是单层
        PBOMInfoBean pbomStructure = new PBOMInfoBean();
        if (isSingle) {
            pbomStructure = getPBOMInfoByWTPart(wtPartByNumber);
        } else {
            pbomStructure = getPBOMStructure(wtPartByNumber);
        }

        return ResponseVo.success(pbomStructure);
    }

    /**
     * 根据跟部件获取子料以及子料替代料
     *
     * @param wtPart
     * @return
     * @throws Exception
     */
    public static PBOMInfoBean getPBOMStructure(WTPart wtPart) throws Exception {
        //搭建PBOM
        //获取父部件信息
        PBOMInfoBean pbomInfo = getPBOMInfoByWTPart(wtPart);

        //获取部件子料
        ArrayList<PBOMInfoBean> pbomInfoBeans = new ArrayList<>();
        List<WTPartUsageLink> partUsageLinks = PartUtil.getLinksByPart(wtPart);
        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            //获取最新子料
            WTPart part = (WTPart) PartUtil.getLatestObjectByMaster(partUsageLink.getUses());
            //转为pbom子料 pbomInfoBeans
            pbomInfoBeans.add(getPBOMInfoByWTPart(part));

            //获取替代料
            List<WTPartSubstituteLink> partSubstituteLinks = PartUtil.getWTPartSubstituteLinks(partUsageLink);
            for (WTPartSubstituteLink partSubstituteLink : partSubstituteLinks) {
                WTPart subPart = (WTPart) PartUtil.getLatestObjectByMaster(partSubstituteLink.getSubstitutes());
                pbomInfoBeans.add(getPBOMInfoByWTPart(subPart));
            }
        }
        pbomInfo.setSonPart(pbomInfoBeans);
        return pbomInfo;
    }


    /**
     * 转换部件为PBOMInfoBean
     *
     * @param wtPart
     * @return
     * @throws Exception
     */
    public static PBOMInfoBean getPBOMInfoByWTPart(WTPart wtPart) throws Exception {
        Locale locale = SessionHelper.getLocale();
        PBOMInfoBean fatherPart = new PBOMInfoBean();
//        String oid = String.valueOf(wtPart.getPersistInfo().getObjectIdentifier().getId());
        String oid = getOid(wtPart);
        String version = wtPart.getVersionIdentifier().getValue() + "." + wtPart.getIterationIdentifier().getValue() + "(" + wtPart.getViewName() + ")";
        IBAUtil ibaUtil = new IBAUtil(wtPart);
        //获取外部物料组
        String SapMaterialGroup = ibaUtil.getIBAValue(SAP_MATERIAL_GROUP);

        String sourceInter = wtPart.getSource().toString();
        String sourceDisplay = wtPart.getSource().getDisplay(locale);
        String source = sourceInter + "," + sourceDisplay;

        fatherPart.setOid(oid);
        fatherPart.setPartNumber(wtPart.getNumber());
        fatherPart.setPartName(wtPart.getName());
        fatherPart.setPartVersion(version);
        fatherPart.setPartState(wtPart.getLifeCycleState().getDisplay());
        fatherPart.setPartSAPGroup(SapMaterialGroup);
        fatherPart.setPhantom(wtPart.isPhantom() ? "是" : "否");
        fatherPart.setPartFactory("");
        //工艺类型
        fatherPart.setPartFactory("");
        fatherPart.setSource(source);

        return fatherPart;
    }

    /**
     *
     * 获取完整的OID字符串  OR:wt.part.WTPart:1096434
     *
     * @param persistable
     * @return
     * @throws WTException
     */
    public static String getOid(Persistable persistable) throws WTException {
        ReferenceFactory refFactory = new ReferenceFactory();
        return refFactory.getReferenceString(
                ObjectReference.newObjectReference((persistable.getPersistInfo().getObjectIdentifier())));
    }
}
