package ext.alphai.sinoboom.pbom.util;


import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import ext.alphai.sinoboom.colorpart.constants.ColorPartConstant;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import wt.configuration.TraceCode;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.epm.structure.EPMMemberLink;
import wt.fc.*;
import wt.folder.CabinetBased;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.State;
import wt.method.RemoteAccess;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.query.*;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.*;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.util.*;

public class PartUtil implements RemoteAccess {


    /**
     * 获取最新版本的对象
     *
     * @param master
     * @return RevisionControlled
     * @throws WTException
     */
    public static RevisionControlled getLatestObjectByMaster(Mastered master) throws WTException {
        if (master == null) {
            return null;
        } else {
            QueryResult queryResult = VersionControlHelper.service.allVersionsOf(master);
            return queryResult.hasMoreElements() ? (RevisionControlled) queryResult.nextElement() : null;
        }
    }


    /**
     * @author
     * @Description:根据物料编码、视图获取物料
     */
    public static WTPart getPartByNumberAndView(String partNumber, String viewName) throws WTException {
        if (partNumber == null || viewName == null) {
            return null;
        }
        WTPart part = null;
        View view = ViewHelper.service.getView(viewName);
        QuerySpec qs = new QuerySpec(WTPart.class);
        SearchCondition sc = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber);
        qs.appendWhere(sc, new int[] { 0 });
        qs.appendAnd();
        sc = new SearchCondition(WTPart.class, "containerReference.key.classname", SearchCondition.NOT_EQUAL, "wt.projmgmt.admin.Project2");
        qs.appendWhere(sc, new int[] { 0 });
        qs.appendAnd();
        sc = new SearchCondition(WTPart.class, "view.key.id", SearchCondition.EQUAL,
                view.getPersistInfo().getObjectIdentifier().getId());
        qs.appendWhere(sc, new int[] { 0 });
        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
        qr = new LatestConfigSpec().process(qr);
        if (qr.hasMoreElements()) {
            part = (WTPart) qr.nextElement();

        }
        return part;
    }


    /**
     * 根据部件于获取局部替代料的关联关系
     *
     * @param WTPart part
     * @return List<WTPartSubstituteLink>
     */
    public static List<WTPartSubstituteLink> getWTPartSubstituteLinks(WTPartUsageLink usageLink) {
        if (usageLink == null) {
            return null;
        }
        List<WTPartSubstituteLink> list = new ArrayList<WTPartSubstituteLink>();
        long masterId = PersistenceHelper.getObjectIdentifier(usageLink).getId();
        int[] index = { 0 };
        try {
            QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
            qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class, "roleAObjectRef.key.id",
                    SearchCondition.EQUAL, masterId), index);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            while (qr.hasMoreElements()) {
                WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr.nextElement();
                list.add(sLink);
            }
        } catch (QueryException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 获取部件与其所有子部件间的关联关系
     *
     * @param WTPart
     * @return List<WTPartUsageLink>
     */
    public static List<WTPartUsageLink> getLinksByPart(WTPart fatherPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                list.add(link);
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        System.out.println("listsize" + list.size());
        return list;
    }




    public static boolean isNeedCreateNewView(WTContained part) {
        boolean flag = true;
        if (part != null) {
            boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
            try {
                WTContainer container = null;
                if (part instanceof WTPart) {
                    container = part.getContainer();
                    WTPart wtPart = (WTPart) part;
                    String partSource = wtPart.getSource().toString();
                    if(ColorPartConstant.SOURCE_BUY.equals(partSource)){
                        return false;
                    }
                    String nubmerPrefix = ((WTPart) part).getNumber().substring(0,1);
                    if(!"1".equals(nubmerPrefix)){
                        return false;
                    }
                }
//				else if (part instanceof WTPartMaster) {
//					WTPart designpart = getPartByMasterAndView((WTPartMaster) part, ViewConstant.DESIGN);
//					if (designpart != null) {
//						container = designpart.getContainer();
//					}
//				}



//				if (container != null && container instanceof WTLibrary) {
//					String libName = ((WTLibrary) container).getName();
//					if (AttributesConstant.BZJLIBRARYNAME.equals(libName)
//							|| AttributesConstant.WGJLIBRARYNAME.equals(libName)
//							|| AttributesConstant.FZHCLIBRARYNAME.equals(libName)
//							|| AttributesConstant.YCLLIBRARYNAME.equals(libName)
//							|| AttributesConstant.TYJIBRARYNAME.equals(libName)
//							|| AttributesConstant.YFCLLIBRARYNAME.equals(libName)) {
//						flag = false;
//					}
//				}
            } finally {
                SessionServerHelper.manager.setAccessEnforced(enforce);
            }
        }
        return flag;
    }



    /**
     *   必须是设计视图，且不在项目下，状态包含发布、废弃、试制中
     * @param partNumber
     * @return
     * @throws WTException
     */
    public static WTPart getReleateDesignPartByNumber(String partNumber) throws WTException {
        if (partNumber == null) {
            return null;
        }
        WTPart part = null;
        View view = ViewHelper.service.getView("Design");
        QuerySpec qs = new QuerySpec(WTPart.class);
        SearchCondition sc = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber);
        qs.appendWhere(sc, new int[] { 0 });
        qs.appendAnd();
        sc = new SearchCondition(WTPart.class, "containerReference.key.classname", SearchCondition.NOT_EQUAL, "wt.projmgmt.admin.Project2");
        qs.appendWhere(sc, new int[] { 0 });
        qs.appendAnd();
        sc = new SearchCondition(WTPart.class, "view.key.id", SearchCondition.EQUAL,
                view.getPersistInfo().getObjectIdentifier().getId());
        qs.appendWhere(sc, new int[] { 0 });
        qs.appendAnd();
        sc = new SearchCondition(new ClassAttribute(WTPart.class, WTPart.LIFE_CYCLE_STATE), SearchCondition.IN,
                new ArrayExpression(
                        new String[] { ColorPartConstant.STATE_RELEASED, ColorPartConstant.STATE_OBSOLESCENCE,ColorPartConstant.STATE_TRIALPRODUCE }));
        qs.appendWhere(sc, new int[] { 0 });
        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
        qr = new LatestConfigSpec().process(qr);
        if (qr.hasMoreElements()) {
            part = (WTPart) qr.nextElement();
        }
        return part;
    }

    public static List<WTPart> getMaxVersionParts(List<WTPart> classPart) {
        // 使用 Map 存储每个编号对应的最大版本
        Map<String, WTPart> maxVersionMap = new HashMap<>();

        for (WTPart part : classPart) {
            String number = part.getNumber()+part.getView().getName();

            // 如果当前 Map 中没有该编号的部件，或者当前部件版本更大，则更新
            if (!maxVersionMap.containsKey(number) ||
                    compareVersion(part, maxVersionMap.get(number)) > 0) {
                maxVersionMap.put(number, part);
            }
        }

        // 返回每个编号最大版本的部件列表
        return new ArrayList<>(maxVersionMap.values());
    }



    // 用于比较版本大小
    private static int compareVersion(WTPart part1, WTPart part2) {
        String majorVersion1 = part1.getVersionIdentifier().getValue();
        String majorVersion2 = part2.getVersionIdentifier().getValue();

        // 比较大版本（字母）
        int compareMajor = majorVersion1.compareTo(majorVersion2);
        if (compareMajor != 0) {
            return compareMajor;  // 大版本不同则直接返回比较结果
        }

        // 如果大版本相同，比较小版本（数字）
        String minorVersion1 = part1.getIterationIdentifier().getValue();
        String minorVersion2 = part2.getIterationIdentifier().getValue();

        // 将小版本的字符串转换为整数进行比较
        int minor1 = Integer.parseInt(minorVersion1);
        int minor2 = Integer.parseInt(minorVersion2);

        return Integer.compare(minor1, minor2);
    }

        /**
         * 取得所有子部件的关联
         *
         * @param WTPart
         * @return Vector<WTPartUsageLink>
         */
    @SuppressWarnings("unchecked")
    public static Vector<WTPartUsageLink> getSubPartUsagelinks(WTPart parentPart) throws WTException {
        Vector<WTPartUsageLink> partlist = new Vector<>();
        QueryResult subParts = WTPartHelper.service.getUsesWTPartMasters(parentPart);
        while (subParts.hasMoreElements()) {
            WTPartUsageLink usagelink = (WTPartUsageLink) subParts.nextElement();
            partlist.addElement(usagelink);
        }
        return partlist;
    }

    /**
     * 根据编号查询part
     *
     * @param String
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static WTPart getWTPartByNumber(String number) {
        WTPart result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (WTPart) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    /**
     *   必须是设计视图
     * @param partNumber
     * @return
     * @throws WTException
     */
    public static WTPart getDesignPartByNumber(String partNumber) throws WTException {
        if (partNumber == null) {
            return null;
        }
        WTPart part = null;
        View view = ViewHelper.service.getView("Design");
        QuerySpec qs = new QuerySpec(WTPart.class);
        SearchCondition sc = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber);
        qs.appendWhere(sc, new int[] { 0 });

        qs.appendAnd();
        qs.appendWhere(new SearchCondition(WTPart.class, "containerReference.key.classname", SearchCondition.NOT_EQUAL, "wt.projmgmt.admin.Project2", false), new int[]{0});
        qs.appendAnd();
        sc = new SearchCondition(WTPart.class, "view.key.id", SearchCondition.EQUAL,
                view.getPersistInfo().getObjectIdentifier().getId());
        qs.appendWhere(sc, new int[] { 0 });

        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
        qr = new LatestConfigSpec().process(qr);
        if (qr.hasMoreElements()) {
            part = (WTPart) qr.nextElement();
        }
        return part;
    }

    /**
     * 根据部件编号、版本、视图获取最新版本部件
     */
    public static WTPart getLatestWTPart(String partNumber, String viewName) throws WTException {
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        if (StringUtils.isNotBlank(partNumber)) {
            partNumber = partNumber.trim();

            qs = new QuerySpec(WTPart.class);
            int[] index = new int[]{0};
            qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);
            qs.appendAnd();
            qs.appendWhere(new SearchCondition(WTPart.class, "containerReference.key.classname", SearchCondition.NOT_EQUAL, "wt.projmgmt.admin.Project2", false), index);

            if (StringUtils.isNotBlank(viewName)) {
                viewName = viewName.trim();
                View viewObj = ViewHelper.service.getView(viewName);
                if (viewObj == null)
                    return null;
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
            }

            configSpec = new LatestConfigSpec();
            configSpec.appendSearchCriteria(qs);
            qr = PersistenceHelper.manager.find((StatementSpec) qs);
            qr = configSpec.process(qr);
            if (qr.hasMoreElements()) {
                part = (WTPart) qr.nextElement();
            }
        }
        return part;
    }

    /**
     * 根据编号查询List
     *
     * @param String
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static List<WTPart> getWTPartListByNumber(String number) {
        List<WTPart> result = new ArrayList<WTPart>();
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            while (qr != null && qr.hasMoreElements()) {
                result.add((WTPart) qr.nextElement());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 不递归获取部件所有的子部件
     *
     * @param WTPart
     * @return List<WTPart>
     */
    public static List<WTPart> getBomByPart(WTPart ProductPart) {
        WTPart sPart = null;
        QueryResult qr2 = null;
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(ProductPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    list.add(sPart);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 递归获取部件的所有子部件
     *
     * @param WTPart
     * @return List<WTPart>
     */
    public static List<WTPart> getAllBomByPart(WTPart part) {
        List<WTPart> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        WTPart sPart = null;
        QueryResult qr2 = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    localList.add(sPart);

                    // 递归调用，将结果合并到局部列表
                    localList.addAll(getAllBomByPart(sPart));
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }

    /**
     * 修改部件编号
     *
     * @param WTPart
     * @param String
     */
    public static void changePartNumber(WTPart part, String newPartNumber) {
        try {
            part = (WTPart) PersistenceHelper.manager.refresh(part);
            Identified identified = (Identified) part.getMaster();
            WTPartMasterIdentity partIdentity = (WTPartMasterIdentity) identified.getIdentificationObject();
            partIdentity.setNumber(newPartNumber);
            identified = IdentityHelper.service.changeIdentity(identified, partIdentity);
            part = (WTPart) PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 修改部件名称
     *
     * @param WTPart
     * @param String
     */
    public static void changePartName(WTPart part, String newName) {
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();
            part = (WTPart) PersistenceHelper.manager.refresh(part);
            Identified identified = (Identified) part.getMaster();
            WTPartMasterIdentity partIdentity = (WTPartMasterIdentity) identified.getIdentificationObject();
            partIdentity.setName(newName);
            identified = IdentityHelper.service.changeIdentity(identified, partIdentity);
            part = (WTPart) PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (currentUser != null) {
                try {
                    SessionHelper.manager.setPrincipal(currentUser.getName());
                } catch (WTException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 获取原样位号
     *
     * @param WTPartUsageLink
     * @return String
     * @throws WTException
     */
    @SuppressWarnings({"unchecked", "deprecation"})
    public static String getPartUsesOccurrence(WTPartUsageLink useagelink) {
        String occurrenceStr = "";
        List listWTPart2 = new ArrayList();
        long linkid = PersistenceHelper.getObjectIdentifier(useagelink).getId();
        try {
            QuerySpec qs = new QuerySpec(PartUsesOccurrence.class);
            qs.appendWhere(new SearchCondition(PartUsesOccurrence.class, "linkReference.key.id", SearchCondition.EQUAL,
                    linkid));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            while (qr.hasMoreElements()) {
                PartUsesOccurrence occurrence = (PartUsesOccurrence) qr.nextElement();
                listWTPart2.add(occurrence.getName());
            }
            for (int i = 0; i < listWTPart2.size(); i++) {
                if (listWTPart2.get(i) != null) {
                    String ocName = listWTPart2.get(i).toString();
                    if (i == 0) {
                        occurrenceStr = ocName;
                    } else {
                        occurrenceStr = occurrenceStr + "," + ocName;
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return sortPlaceNumber(occurrenceStr);
    }

    // 对位号排序
    public static String sortPlaceNumber(String numberStr) {
        TreeMap<String, String> tm = new TreeMap<>();
        String[] s = numberStr.split(",");
        for (int i = 0; i < s.length; i++) {
            tm.put(s[i], s[i]);
        }
        Iterator it = tm.keySet().iterator();
        String number = "";
        int a = 0;
        while (it.hasNext()) {
            if (a == 0) {
                number = (String) it.next();
            } else {
                number = number + "," + (String) it.next();
            }
            a++;
        }
        return number;
    }


    /**
     * 修改部件生命周期状态
     *
     * @param WTPart
     * @param String
     * @return String
     * @throws WTPropertyVetoException
     * @throws WTException
     */
    public static String changePartState(WTPart part, String state) throws WTPropertyVetoException, WTException {
        String message = "";
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();

            part = (WTPart) wt.lifecycle.LifeCycleHelper.service.setLifeCycleState((wt.lifecycle.LifeCycleManaged) part,
                    State.toState(state));

            PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return message;
    }

    /**
     * 修改部件状态（直接使用State进行修改）
     *
     * @param WTPart
     * @param State
     * @return String
     * @throws WTPropertyVetoException
     * @throws WTException
     */
    public static String changePartState(WTPart part, State state) throws WTPropertyVetoException, WTException {
        String message = "";
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();

            part = (WTPart) wt.lifecycle.LifeCycleHelper.service.setLifeCycleState((wt.lifecycle.LifeCycleManaged) part,
                    state);

            PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return message;
    }

    /**
     * 通过说明文档找到部件
     *
     * @param WTDocument
     * @return List<WTPart>
     */
    public static List<WTPart> getPartByDescribesDoc(WTDocument doc) {
        QueryResult qr = null;
        WTPart part = null;
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            qr = WTPartHelper.service.getDescribesWTParts(doc);// 说明文档
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTPart) {
                    part = (WTPart) obj;
                    System.out.println("通过文档找到的部件名称为=" + part.getName());
                    list.add(part);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 获取参考文档关联的部件
     *
     * @param WTDocument
     * @param doc
     * @return List<WTPart>
     */
    public static List<WTPart> getPartByRefrenceDoc(EPMDocument doc) {
        QueryResult qr = null;
        WTPart part = null;
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            qr = StructHelper.service.navigateReferencedBy(doc.getMaster());// 参考关系
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTPart) {
                    part = (WTPart) obj;
                    list.add(part);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 获取部件间的关联关系
     *
     * @param WTPart
     * @param WTPart
     * @return WTPartUsageLink
     */
    public static WTPartUsageLink getLinkByPart(WTPart fatherPart, WTPart sonPart) {
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                WTPart part = getBomPartBylink(link);
                if (part.getNumber().equals(sonPart.getNumber())) {
                    return link;
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
     * 根据部件间的关联关系获取子部件
     *
     * @param WTPartUsageLink
     * @return WTPart
     */
    public static WTPart getBomPartBylink(WTPartUsageLink link) {
        try {
            QueryResult qr = VersionControlHelper.service.allVersionsOf(link.getUses());
            if (qr.hasMoreElements()) {
                WTPart part = (WTPart) qr.nextElement();
                return part;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
     * 获取部件的子部件和数量关系
     *
     * @param WTPart
     * @param List<Object[]>
     * @return List<Object [ ]>
     */
    public static List<Object[]> getAllBomByParentPart(WTPart parentPart, List<Object[]> list) {
        WTPart sPart = null;
        QueryResult qr2 = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(parentPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    boolean found = false;
                    for (Object[] old : list) {
                        WTPart object = (WTPart) old[0];
                        String number = object.getNumber();
                        if (sPart.getNumber().equalsIgnoreCase(number)) {
                            old[1] = (Double) old[1] + usageLink.getQuantity().getAmount();
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        list.add(new Object[]{sPart, usageLink.getQuantity().getAmount()});
                    }
                    getAllBomByParentPart(sPart, list);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 检入部件
     *
     * @param WTPart
     * @param String
     * @return WTPart
     * @throws WTException
     */
    public static WTPart checkinPart(WTPart partParentPrevious, String comment) throws WTException {
        WTPart part = null;
        if (partParentPrevious != null) {
            try {
                WTPrincipal wtprincipal = SessionHelper.manager.getPrincipal();
                if (WorkInProgressHelper.isCheckedOut((Workable) partParentPrevious, wtprincipal)) {
                    if (!WorkInProgressHelper.isWorkingCopy((Workable) partParentPrevious)) {
                        partParentPrevious = (WTPart) WorkInProgressHelper.service
                                .workingCopyOf((Workable) partParentPrevious);
                    }
                    part = (WTPart) WorkInProgressHelper.service.checkin((Workable) partParentPrevious, comment);
                }
            } catch (WTPropertyVetoException ex) {
                ex.printStackTrace();
            }
        }
        return part;
    }


    /**
     * 根据子部件获取所有父部件之间的关联
     *
     * @param WTPart
     * @return List<WTPartUsageLink>
     */
    @SuppressWarnings("deprecation")
    public static List<WTPartUsageLink> getBomLinkByChildPart(WTPart childPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 通过父部件和子部件获取部件之间使用关系
     *
     * @param fatherPart
     * @param childPart
     * @return
     */
    public static List<WTPartUsageLink> getWtPartUsageLink(WTPart fatherPart, WTPart childPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier(fatherPart)));
                queryspec.appendAnd();
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 复制一个新部件（名称与编号不同）
     *
     * @param WTPart
     * @param String
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static WTPart copyPart(WTPart part, String partName) {
        WTPart newPart = null;
        try {
            String number = part.getNumber();
            LifeCycleState state = part.getState();
            Source source = part.getSource();
            PartType partType = part.getPartType(); // 装配模式
            boolean endItem = part.isEndItem(); // 成品
            QuantityUnit defaultUnit = part.getDefaultUnit();// 单位
            boolean hidePartInStructure = part.getHidePartInStructure();// 收集部件
            TraceCode defaultTraceCode = part.getDefaultTraceCode(); // 默认追踪代码
            String location = FolderHelper.getLocation((CabinetBased) part);
            WTContainer container2 = WTContainerHelper.getContainer((WTContained) part);
            WTContainerRef containerRef = WTContainerRef.newWTContainerRef(container2);

            String newNumber = number.substring(0, number.length() - 1);
            String suffix = number.substring(number.length() - 1);

            if ("0".equals(suffix)) {
                newNumber += "1";
            } else if ("1".equals(suffix)) {
                newNumber += "0";
            }

            newPart = WTPart.newWTPart();
            newPart.setName(partName);
            newPart.setNumber(newNumber);
            newPart.setState(state);
            newPart.setSource(source);
            newPart.setPartType(partType);
            newPart.setEndItem(endItem);
            newPart.setHidePartInStructure(hidePartInStructure);
            newPart.setDefaultUnit(defaultUnit);
            newPart.setDefaultTraceCode(defaultTraceCode);
            newPart.setView(part.getView());
            FolderHelper.assignLocation((FolderEntry) newPart, location, containerRef);
            PersistenceHelper.manager.save(newPart);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return newPart;
    }


//    /**
//     * 根据url获取对应的wtpart对象
//     * http://plmtest.sinoboom.com.cn/Windchill/app/#ptc1/tcomp/infoPage?u8=1&oid=OR%3Awt.part.WTPart%3A804374507
//     * http://plmtest.sinoboom.com.cn/Windchill/app/#ptc1/tcomp/infoPage?oid=OR:wt.part.WTPart:1099247509
//     *
//     * @param String
//     * @return WTPart
//     */
//    public static WTPart getPartFromURL(String url) {
//        try {
//            Pattern pattern = Pattern.compile("(?<=WTPart)(%3A|:)([0-9]+)");
//            String oid = "";
//            Matcher matcher = pattern.matcher(url);
//            if (matcher.find()) {
//                oid = matcher.group(2);
//            }
//            WTPart part = (WTPart) PersistenceUtil.oid2Object(oid);
//            return part;
//        } catch (Exception e) {
//            System.out.println("系统未找到url指定的部件");
//            return null;
//        }
//    }
//
//
//    /**
//     * 根据部件的VR查找到部件的OR
//     *
//     * @param VR VR:wt.part.WTPart:569305
//     * @return OR OR:wt.part.WTPart:569306
//     */
//    public static String getORbyVR(String VR) {
//        VR = VR.split(":")[2];
//        String sql = "SELECT IDA2A2 FROM WTPART WHERE BRANCHIDITERATIONINFO = ?";
//        String OR = "";
//        try {
//            ResultSet resultSet = CommonUtil.excuteSelect(sql, VR);
//            while (resultSet.next()) {
//                OR = "OR:wt.part.WTPart:" + resultSet.getString("IDA2A2");
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return OR;
//    }
//
//
//
//    /**
//     * 通过部件编号修订到下一个大版本
//     * @param number
//     * @return
//     */
//    public static WTPart reviseWTPartByNumber(WTPart partByNumber) throws WTException, WTPropertyVetoException {
//        // 修订后的部件对象
//        WTPart afterReviseWTPart = null;
//        // 获取当前版本
//        RevisionControlled latestObjectByMaster = VersionUtil.getLatestObjectByMaster(partByNumber.getMaster());
//
//        String bigVersion = latestObjectByMaster.getVersionIdentifier().getValue();
//        System.out.println("当前部件的大版本为="+bigVersion);
//
//        char c = bigVersion.charAt(0);
//        String nextLetter = getNextLetter(c);
//        System.out.println("获得到下一大版本="+nextLetter);
//
//        // 修订
//        // 大版本设定
//        MultilevelSeries mls = MultilevelSeries.newMultilevelSeries ("wt.vc.VersionIdentifier", nextLetter);
//
//        // 小版本设定
//        VersionIdentifier vid = VersionIdentifier.newVersionIdentifier(mls);
//        IterationIdentifier iid = IterationIdentifier.newIterationIdentifier("1");
//
//        afterReviseWTPart = (WTPart) VersionControlHelper.service.newVersion(partByNumber,vid,iid);
//        afterReviseWTPart=(WTPart) PersistenceHelper.manager.save(afterReviseWTPart);
//
//        return afterReviseWTPart;
//    }


    /**
     * 传入一个版本字母 如A 返回下一版本如B
     *
     * @param letter
     * @return
     */
    public static String getNextLetter(char letter) {

        char nextChar = (char) (letter + 1);

        return String.valueOf(nextChar);
    }


    /**
     * 根据part得到其子部件link
     *
     * @param productPart
     * @return
     */
    public static List<WTPartUsageLink> getBomLinkByPart(WTPart productPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(productPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                list.add(usageLink);
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


//    /**
//     * 创建父子部件的连接关系
//     *
//     * @param parentPart
//     * @param sonPart
//     * @param qty        tarNum 工号
//     * @return
//     * @throws WTException
//     */
//    public static WTPartUsageLink newUsgeLink(WTPart parentPart, WTPartMaster sonPart, String qty, String tarNum, String isByCust, String IsCustomerService, String ItemNote, Long lineNumber, String BOMSkip) throws Exception {
//        WTPartUsageLink part_UsageLink = WTPartUsageLink.newWTPartUsageLink(parentPart, sonPart);
//        String unit = "ea";//bom单位默认ea  (自定义)
//        QuantityUnit qu = null;
//        qu = QuantityUnit.toQuantityUnit(unit);
//
//        qty = qty == null ? "0" : qty;
//        Quantity qa = Quantity.newQuantity(Double.parseDouble(qty), qu);// 设置数量
//
//        if (lineNumber == 0) {
//
//        } else {
//            part_UsageLink.setLineNumber(LineNumber.newLineNumber(lineNumber));
//        }
//        part_UsageLink.setQuantity(qa);
//
//        // 修改工号IBA属性
//        part_UsageLink = (WTPartUsageLink) PersistenceHelper.manager.save(part_UsageLink);
//        IBAUtil ibaUtil = new IBAUtil(part_UsageLink);
//        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.TAG_NUMBER, tarNum);
//
//        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.IS_BY_CUST, isByCust);
//        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.IS_CUSTOMER_SERVICE, IsCustomerService);
//        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.ITEM_NOTE, ItemNote);
//        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.BOM_SKIP, BOMSkip);
//
//        return part_UsageLink;
//    }
//
//
//    /**
//     * 创建父子部件的连接关系替换时使用
//     *
//     * @param parentPart
//     * @param sonPart
//     * @param beforeChildLinkQuantity tarNum 工号
//     * @return
//     * @throws WTException
//     */
//    public static WTPartUsageLink newUsgeLink(WTPart parentPart, WTPartMaster sonPart, Quantity beforeChildLinkQuantity, WTPartUsageLink beforeChildLink, String afterTarNum) throws Exception {
//        WTPartUsageLink part_UsageLink = WTPartUsageLink.newWTPartUsageLink(parentPart, sonPart);
//
//        // 获取旧有连接的工号
//        IBAUtil beforeLinkIBA = new IBAUtil(beforeChildLink);
//        Quantity qa = Quantity.newQuantity(beforeChildLinkQuantity.getAmount(), beforeChildLinkQuantity.getUnit());// 设置数量
//        part_UsageLink.setQuantity(qa);
//        part_UsageLink.setLineNumber(beforeChildLink.getLineNumber());
//
//        // 获取旧连接的自定义IBA属性
//        String isByCust = beforeLinkIBA.getIBAValue(ChangeBomConstant.IS_BY_CUST);
//        String isCustomService = beforeLinkIBA.getIBAValue(ChangeBomConstant.IS_CUSTOMER_SERVICE);
//        String itemNote = beforeLinkIBA.getIBAValue(ChangeBomConstant.ITEM_NOTE);
//        String BomSkip = beforeLinkIBA.getIBAValue(ChangeBomConstant.BOM_SKIP);
//
//        // 修改工号IBA属性
//        part_UsageLink = (WTPartUsageLink) PersistenceHelper.manager.save(part_UsageLink);
//        IBAUtil ibaUtil = new IBAUtil(part_UsageLink);
//        ibaUtil.setIBAValue(ChangeBomConstant.TAG_NUMBER, afterTarNum);
//
//        ibaUtil.setIBAValue(ChangeBomConstant.IS_BY_CUST, isByCust);
//        ibaUtil.setIBAValue(ChangeBomConstant.IS_CUSTOMER_SERVICE, isCustomService);
//        ibaUtil.setIBAValue(ChangeBomConstant.ITEM_NOTE, itemNote);
//        ibaUtil.setIBAValue(ChangeBomConstant.BOM_SKIP, BomSkip);
//
//
//        return part_UsageLink;
//    }
//
//    //02.零件号  返回 WTPartMaster 对象
//    public static WTPartMaster getWTPartMasterByNumber(String paramString)
//            throws WTException {
//        WTPartMaster localWTPartMaster = null;
//        QuerySpec localQuerySpec = null;
//        QueryResult localQueryResult = null;
//        localQuerySpec = new QuerySpec(WTPartMaster.class);
//
//        SearchCondition localSearchCondition = new SearchCondition(WTPartMaster.class, "number", "LIKE", paramString);
//        localQuerySpec.appendSearchCondition(localSearchCondition);
//        localQueryResult = PersistenceHelper.manager.find(localQuerySpec);
//        if (localQueryResult.hasMoreElements()) {
//            localWTPartMaster = (WTPartMaster) localQueryResult.nextElement();
//        }
//
//        return localWTPartMaster;
//    }

    /**
     * 获取父子部件的连接
     *
     * @param part
     * @param subMaster
     * @return
     */
    public static WTPartUsageLink findWTPartUsageLink(WTPart part, WTPartMaster subMaster) {
        WTPartUsageLink link = null;
        if (part == null || subMaster == null) {
            return link;
        }
        try {
            QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
            queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                    PersistenceHelper.getObjectIdentifier(part)), new int[]{});
            queryspec.appendAnd();
            queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                    PersistenceHelper.getObjectIdentifier(subMaster)), new int[]{});
            QueryResult qr = PersistenceHelper.manager.find(queryspec);
            if (qr != null && qr.hasMoreElements()) {
                link = (WTPartUsageLink) qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return link;
    }





    /**
     * 用于可能出现多个子项的BOM 通过工位精准查询到
     *
     * @param parent
     * @param tarNum
     * @return
     */
//    public static WTPartUsageLink getLinkByParentAndTarNum(WTPart parent, WTPartMaster partMaster, String tarNum) throws WTException {
//        WTPartUsageLink wtPartUsageLink = null;
//        List<WTPartUsageLink> linkByPart = getBomLinkByPart(parent);
//        HashMap<String, WTPartUsageLink> linkMap = new HashMap<>();
//        for (WTPartUsageLink link : linkByPart) {
//            WTPartMaster linkUsesMaster = link.getUses();
//            if (linkUsesMaster.equals(partMaster)) {
//                IBAUtil ibaUtil = new IBAUtil(link);
//                String tar = ibaUtil.getIBAValue(ChangeBomConstant.TAG_NUMBER);
//                linkMap.put(tar, link);
//            }
//        }
//        Set<Map.Entry<String, WTPartUsageLink>> entries = linkMap.entrySet();
//        if (linkMap.size() == 1) {
//            // 如果HashMap的长度为1，获取唯一的value赋值给wtPartUsageLink
//            for (Map.Entry<String, WTPartUsageLink> entry : entries) {
//                wtPartUsageLink = entry.getValue();
//                return wtPartUsageLink;
//            }
//        }
//
//
//        if (linkMap.size() > 1) {
//            System.out.println("传入的改前工位是=" + tarNum);
//            if (tarNum == null) {
//                tarNum = "";
//            }
//            System.out.println("得到的相同Master的Link个数为=" + linkMap.size());
//            for (Map.Entry<String, WTPartUsageLink> entry : entries) {
//                String key = entry.getKey();
//                System.out.println("得到的相同Master的Link个的工位有=" + key);
//                if (key.equals(tarNum)) {
//                    wtPartUsageLink = entry.getValue();
//                    break;
//                }
//            }
//        }
//        return wtPartUsageLink;
//    }


    /**
     * 由于未检出前的usageLink不能直接做删除 所以检出前的link只能作为一个找到Link的工具
     *
     * @param oldLink
     * @param parent
     * @return
     */
//    public static WTPartUsageLink getLinkByOldUsageLink(WTPartUsageLink oldLink, WTPart parent) throws WTException {
//        WTPartUsageLink wtPartUsageLink = null;
//        List<WTPartUsageLink> linkByPart = getBomLinkByPart(parent);
//        WTPartMaster oldLinkMaster = oldLink.getUses();
//        IBAUtil oldLinkIBA = new IBAUtil(oldLink);
//        String oldTarNum = oldLinkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
//        System.out.println("旧连接的工位为：" + oldTarNum);
//        HashMap<String, WTPartUsageLink> linkMap = new HashMap<>();
//
//        for (WTPartUsageLink link : linkByPart) {
//            WTPartMaster linkUses = link.getUses();
//            IBAUtil linkIBA = new IBAUtil(link);
//            String tarNum = linkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
//            if (linkUses.equals(oldLinkMaster)) {
//                System.out.println("当前查到的改前子项部件的编号为：" + linkUses.getNumber() + "工位为" + tarNum);
//                linkMap.put(tarNum, link);
//            }
//
//        }
//        Set<Map.Entry<String, WTPartUsageLink>> entries = linkMap.entrySet();
//        if (linkMap.size() == 1) {
//            for (Map.Entry<String, WTPartUsageLink> entry : entries) {
//                wtPartUsageLink = entry.getValue();
//                return wtPartUsageLink;
//            }
//        } else {
//            for (Map.Entry<String, WTPartUsageLink> entry : entries) {
//                String key = entry.getKey();
//                if (key.equals(oldTarNum)) {
//                    wtPartUsageLink = entry.getValue();
//                }
//            }
//        }
//        return wtPartUsageLink;
//    }


    /**
     * 检查传入的改后工位在BOM中是否存在重复
     * @param afterTarNum
     * @param parentPart
     * @param oldLink
     * @return
     */
//    public static String checkTarNumberInBOM(String afterTarNum,WTPart parentPart, WTPartUsageLink oldLink,List<String> itemAfterTarList, WTPartMaster sonMaster, List<WTPartUsageLinkChangeItem> items) throws WTException {
//        StringBuffer msg = new StringBuffer();
//        String[] afterTarNumArray = afterTarNum.trim().split("\\s+");
//        List<String> afterTarNumList = new ArrayList<>(Arrays.asList(afterTarNumArray));
//
//        List<String> allBomTarNum = new ArrayList<>(itemAfterTarList);
//
//        List<WTPartUsageLink> linksByPart = PartUtil.getLinksByPart(parentPart);
//        for(WTPartUsageLink link: linksByPart){
//            IBAUtil linkIBA = new IBAUtil(link);
//            String ibaTarNum = linkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
//            if(!ibaTarNum.isEmpty()){
//                String[] ibaTarNumArray = ibaTarNum.trim().split("\\s+");
//                // 将数组ibaTarNumArray里的数据放入allBomTarNum集合中null值除外
//                for (String num : ibaTarNumArray) {
//                    if (num != null && !num.isEmpty()) {
//                        allBomTarNum.add(num);
//                    }
//                }
//            }
//        }
//
//        // 传入的工位和旧有BOM中工位的重复值集合
//        Set<String> commonValues = new HashSet<>();
//
//
//
//        if(oldLink == null){
//            if(itemAfterTarList.size() == allBomTarNum.size()){
//                // 说明是BOM中不存在的料
//            }else {
//                // 说明是添加子项的 只需要比对传入的
//                for (String tarNum : afterTarNumList) {
//                    if (allBomTarNum.contains(tarNum)) {
//                        commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
//                    }
//                }
//            }
//        }else {
//            // 修改替换 需要排除旧连接的工位
//            IBAUtil oldLinkIBAutil = new IBAUtil(oldLink);
//            String oldTarNum = oldLinkIBAutil.getIBAValue(ChangeBomConstant.TAG_NUMBER);
//            if(oldTarNum != null){
//                String[] oldTarNumArray = oldTarNum.trim().split("\\s+");
//                // 排除掉旧链接里的工位
//                for (String old : oldTarNumArray){
//                    allBomTarNum.remove(old);
//                }
//            }
//
//            for (String tarNum : afterTarNumList) {
//                if (allBomTarNum.contains(tarNum)) {
//                    commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
//                }
//            }
//        }
//
//
//        // 相同子项下的工位
//        Set<String> sameNumPartTar = new HashSet<>();
//        for(WTPartUsageLink link: linksByPart){
//            if(link.getUses().equals(sonMaster)){
//                IBAUtil linkIBA = new IBAUtil(link);
//                String ibaTarNum = linkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
//                if(!ibaTarNum.isEmpty()){
//                    String[] ibaTarNumArray = ibaTarNum.trim().split("\\s+");
//                    for (String num : ibaTarNumArray) {
//                        if (num != null) {
//                            sameNumPartTar.add(num);
//                        }
//                    }
//                }else {
//                    sameNumPartTar.add(ibaTarNum);
//                }
//            }
//        }
//
//        // 如果变更项中相同改后子项的空工位情况
//        for (WTPartUsageLinkChangeItem item:items){
//            String afterChildMasterOR = item.getAfterChildMasterOR();
//            if(afterChildMasterOR !=null){
//                WTPartMaster afterMaster = (WTPartMaster) PersistenceUtil.oid2Object(afterChildMasterOR);
//                if(afterMaster.equals(sonMaster)){
//                    String tagNumber = item.getNewAMountA7TagNumber();
//                    if(tagNumber == null){
//                        sameNumPartTar.add("");
//                    }else {
//                        String[] ibaTarNumArray = tagNumber.trim().split("\\s+");
//                        sameNumPartTar.addAll(Arrays.asList(ibaTarNumArray));
//                    }
//                }
//            }
//        }
//
//        for (String tarNum : afterTarNumList) {
//            if (sameNumPartTar.contains(tarNum)) {
//                commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
//            }
//        }
//
//
//        // 判断重复工位集合是否为空 如果为空说明没有重复工位 反之需要报异常
//        if(commonValues.isEmpty()){
//            return null;
//        }else {
//            msg.append("以下工位在原BOM中已经存在重复请检查：");
//            for (String commonValue :commonValues){
//                msg.append(commonValue).append("、");
//            }
//            return msg.toString();
//        }
//
//    }


    /**
     * 检查传入的改后工位在BOM中是否存在重复 PCBA专用
     * @param afterTarNum
     * @param parentPart
     * @param oldLink
     * @return
     */
//    public static String checkTarNumberInBOM(String afterTarNum,WTPart parentPart, WTPartUsageLink oldLink,List<String> itemAfterTarList,List<WTPartUsageLinkChangeItem> items) throws WTException {
//        StringBuffer msg = new StringBuffer();
//        String[] afterTarNumArray = afterTarNum.trim().split("\\s+");
//        List<String> afterTarNumList = new ArrayList<>(Arrays.asList(afterTarNumArray));
//
//        List<String> allBomTarNum = new ArrayList<>(itemAfterTarList);
//
//        List<WTPartUsageLink> linksByPart = PartUtil.getLinksByPart(parentPart);
//        for(WTPartUsageLink link: linksByPart){
//            IBAUtil linkIBA = new IBAUtil(link);
//            String ibaTarNum = linkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
//            if(!ibaTarNum.isEmpty()){
//                String[] ibaTarNumArray = ibaTarNum.trim().split("\\s+");
//                // 将数组ibaTarNumArray里的数据放入allBomTarNum集合中null值除外
//                for (String num : ibaTarNumArray) {
//                    if (num != null && !num.isEmpty()) {
//                        allBomTarNum.add(num);
//                    }
//                }
//            }
//        }
//
//        // 传入的工位和旧有BOM中工位的重复值集合
//        Set<String> commonValues = new HashSet<>();
//
//
//
//        if(oldLink == null){
//            if(itemAfterTarList.size() == allBomTarNum.size()){
//                // 说明是BOM中不存在的料
//            }else {
//                // 说明是添加子项的 只需要比对传入的
//                for (String tarNum : afterTarNumList) {
//                    if (allBomTarNum.contains(tarNum)) {
//                        commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
//                    }
//                }
//            }
//        }else {
//            // 修改替换 需要排除旧连接的工位
//            IBAUtil oldLinkIBAutil = new IBAUtil(oldLink);
//            String oldTarNum = oldLinkIBAutil.getIBAValue(ChangeBomConstant.TAG_NUMBER);
//            if(oldTarNum != null){
//                String[] oldTarNumArray = oldTarNum.trim().split("\\s+");
//                // 排除掉旧链接里的工位
//                for (String old : oldTarNumArray){
//                    allBomTarNum.remove(old);
//                }
//            }
//
//            for (String tarNum : afterTarNumList) {
//                if (allBomTarNum.contains(tarNum)) {
//                    commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
//                }
//            }
//        }
//
//        // 判断重复工位集合是否为空 如果为空说明没有重复工位 反之需要报异常
//        if(commonValues.isEmpty()){
//            return null;
//        }else {
//            msg.append("以下工位在原BOM中已经存在重复请检查：");
//            for (String commonValue :commonValues){
//                msg.append(commonValue).append("、");
//            }
//            return msg.toString();
//        }
//
//    }


    /**
     * 传入一个父部件返回在table上可以点击的物料编号连接
     *
     * @param part
     * @return
     * @throws WTException
     */
    public static UrlDisplayComponent getPartUrlByPartNumber(WTPart part) throws WTException {
        NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();

        urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);

        NmOid contentOid = NmOid.newNmOid(part.getPersistInfo().getObjectIdentifier());

        String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null, true);

        UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent("", part.getNumber(), link);
        return urlDisplayComponent;
    }

    /**
     * 根据oid获取对应的用户
     *
     * @param oid
     * @return EPMDocument
     */
    @SuppressWarnings("deprecation")
    public static WTUser getWTUserByOid(String oid) {
        WTUser result = null;
        QueryResult qr = null;
        try {
            ReferenceFactory referencefactory = new ReferenceFactory();
            WTReference wtreference = referencefactory.getReference(oid);
            Persistable persistable = wtreference.getObject();
            if (persistable instanceof WTUser) {
                result = (WTUser) wtreference.getObject();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 根据名称获取对应的用户
     *
     * @param String
     * @return EPMDocument
     */
    @SuppressWarnings("deprecation")
    public static WTUser getWTUserByName(String name) {
        WTUser result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTUser.class);
            SearchCondition scnumber = new SearchCondition(WTUser.class, WTUser.NAME, SearchCondition.EQUAL,
                    name);
            qs.appendWhere(scnumber);
            qr = PersistenceHelper.manager.find(qs);
            if (qr != null && qr.hasMoreElements()) {
                result = (WTUser) qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 根据编号获取最新版本的EPM文档
     *
     * @param String
     * @return EPMDocument
     */
    @SuppressWarnings("deprecation")
    public static EPMDocument getEPMByNumber(String number) {
        try {
            if (StringUtils.isBlank(number)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(EPMDocument.class);
            qs.appendWhere(
                    new SearchCondition(EPMDocument.class, EPMDocument.NUMBER, SearchCondition.EQUAL, number));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            System.out.println("查询的相关个数是：" + qr.size());
            if (qr.hasMoreElements()) {
                EPMDocument doc = (EPMDocument) qr.nextElement();
                return doc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //获取关联部件
    public static boolean checkEPM(EPMDocument epm) throws Exception {
        QueryResult qr = PersistenceHelper.manager.navigate(epm, EPMBuildRule.BUILD_TARGET_ROLE, EPMBuildRule.class, true);
        while (qr.hasMoreElements()) {
            WTPart part = (WTPart) qr.nextElement();
            return true;
        }
        return false;
    }

    //解析json数据
    public static String getJsonParam(JSONObject json, String param) throws JSONException {
        if (StringUtils.isNotEmpty((String) json.get(param))) {
            return (String) json.get(param);
        }
        return null;
    }

    public static WTContainer getWTContainByName(String name) {
        WTContainer result = null;
        try {
            if (StringUtils.isBlank(name)) {
                return result;
            }
            QuerySpec qs = new QuerySpec(WTContainer.class);
            SearchCondition scnumber = new SearchCondition(WTContainer.class, WTContainer.NAME, SearchCondition.LIKE, name);
            qs.appendWhere(scnumber);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            if (qr != null && qr.hasMoreElements()) {
                result = (WTContainer) qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    //根据编号删除对应部件所有的link关系
    public static Boolean deleteLink(String number) throws WTException, WTPropertyVetoException {
        if (StringUtils.isEmpty(number))
            return false;
        WTPart parentPart = PartUtil.getWTPartByNumber(number);
        if (parentPart == null)
            throw new WTException("编号为" + number + "的部件不存在");
        try {
            if (!WorkInProgressHelper.isCheckedOut(parentPart)) {
                WorkInProgressHelper.service.checkout(parentPart, WorkInProgressHelper.service.getCheckoutFolder(), null);
            }
            if (!WorkInProgressHelper.isWorkingCopy(parentPart)) {
                parentPart = (WTPart) WorkInProgressHelper.service.workingCopyOf(parentPart);
            }
            Vector<WTPartUsageLink> parentLinks = PartUtil.getSubPartUsagelinks(parentPart);
            if (parentLinks.size() > 0) {
                for (WTPartUsageLink link : parentLinks) {

                    PersistenceHelper.manager.delete(link);
                }
            }
            WorkInProgressHelper.service.checkin(parentPart, null);
            return true;
        } catch (Exception e) {
            WorkInProgressHelper.service.checkin(parentPart, null);
            e.printStackTrace();
        }
        return false;
    }

    public static Vector<EPMMemberLink> getEPMMemberLink(EPMDocument doc) throws WTException {
        QueryResult qr = StructHelper.service.navigateUses(doc, EPMMemberLink.class, false);
        System.out.println("查询的link数量是："+qr.size());
        Vector<EPMMemberLink> epmMemberLinks = new Vector<>();
        while (qr.hasMoreElements()) {
            EPMMemberLink epmMemberLink = (EPMMemberLink) qr.nextElement();
            epmMemberLinks.addElement(epmMemberLink);
        }
        return epmMemberLinks;
    }

    /**
     * 根据编号获取最新版本的EPM文档
     *
     * @param number
     * @return EPMDocument
     */
    @SuppressWarnings("deprecation")
    public static EPMDocument getEPMByCADName(String number) {
        try {
            if (StringUtils.isBlank(number)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(EPMDocument.class);
            qs.appendWhere(
                    new SearchCondition(EPMDocument.class, EPMDocument.CADNAME, SearchCondition.EQUAL, number));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            System.out.println("查询的相关个数是：" + qr.size());
            if (qr.hasMoreElements()) {
                EPMDocument doc = (EPMDocument) qr.nextElement();
                return doc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取对象的oid
     *
     * @param obj
     * @return String
     */
    public static String object2Oid(WTObject obj) {
        String className = obj.getClass().getName();
        String oid = String.valueOf(obj.getPersistInfo().getObjectIdentifier().getId());
        return "OR:" + className + ":" + oid;
    }

    /**
     * 获取oid所对应的对象
     *
     * @param oid
     * @return WTObject
     * @throws WTException
     */
    public static WTObject oid2Object(String oid) {
        try {
            ReferenceFactory factory = new ReferenceFactory();
            return (WTObject) factory.getReference(oid).getObject();
        } catch (WTRuntimeException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取对象的IBA属性值
     *
     * @param oid
     * @return String
     * @throws WTException
     */
    public static String getIBA(Persistable persistable, String ibaName) throws WTException {

        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        Object result = normalizedObject.get(ibaName);
        return result == null ? null : result.toString();
    }


    public static void setIBA(Persistable persistable, String ibaName, Object value) throws WTException {

        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        normalizedObject.set(ibaName, value);
        persistable = normalizedObject.apply();
        PersistenceHelper.manager.modify(persistable);
    }


    /**
     * 根据部件编号、版本、视图获取最新版本部件
     */
    public static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName){
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        try {
            if (StringUtils.isNotBlank(partNumber)) {
                partNumber = partNumber.trim();

                qs = new QuerySpec(WTPart.class);
                int[] index = new int[] { 0 };
                qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);

                if (StringUtils.isNotBlank(version)) {
                    version = version.trim();
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

                    if (StringUtils.isNotBlank(iteration)) {
                        iteration = iteration.trim();
                        qs.appendAnd();
                        qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
                    } else {
                        qs.appendAnd();
                        qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
                    }
                }

                if (StringUtils.isNotBlank(viewName)) {
                    viewName = viewName.trim();
                    View viewObj = ViewHelper.service.getView(viewName);
                    if (viewObj == null)
                        return null;
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
                }

                configSpec = new LatestConfigSpec();
                configSpec.appendSearchCriteria(qs);
                qr = PersistenceHelper.manager.find((StatementSpec) qs);
                qr = configSpec.process(qr);
                if (qr.hasMoreElements()) {
                    part = (WTPart) qr.nextElement();
                }
            }
        }catch (WTException e){
            e.printStackTrace();
        }
        return part;
    }
}

