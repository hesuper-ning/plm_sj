package ext.alphai.sinoboom.pbom.util;

import wt.enterprise.RevisionControlled;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.series.MultilevelSeries;
import wt.util.WTException;
import wt.vc.*;

public class VersionUtil implements RemoteAccess {

    public static final String HDS = "wt.series.HarvardSeries.LogicDataCustom";

    /**
     * 获取最新版本的对象
     *
     * @param master
     * @return RevisionControlled
     * @throws WTException
     */
    public static RevisionControlled getLatestObjectByMaster(Mastered master) throws WTException {
        if (master == null) {
            return null;
        } else {
            QueryResult queryResult = VersionControlHelper.service.allVersionsOf(master);
            return queryResult.hasMoreElements() ? (RevisionControlled) queryResult.nextElement() : null;
        }
    }

    /**
     * 修改版本
     * @param persistable
     * @param version
     */
    public static void changeVersion(Versioned persistable, String version) throws Exception{
        MultilevelSeries multilevelseries = MultilevelSeries.newMultilevelSeries(HDS, version);
        VersionIdentifier ver = VersionIdentifier.newVersionIdentifier(multilevelseries);
        IterationIdentifier iid = IterationIdentifier.newIterationIdentifier("1");
        persistable = (Versioned) VersionControlHelper.service.newVersion(persistable);
        persistable.getMaster().setSeries(HDS);
        VersionControlHelper.setVersionIdentifier(persistable, ver);
        persistable = (Versioned) PersistenceHelper.manager.save(persistable);
    }
}
