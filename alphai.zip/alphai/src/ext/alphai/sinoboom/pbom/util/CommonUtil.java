package ext.alphai.sinoboom.pbom.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptc.core.lwc.common.view.EnumerationDefinitionReadView;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.sun.jndi.toolkit.chars.BASE64Encoder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.*;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import wt.change2.*;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.method.MethodContext;
import wt.method.RemoteAccess;
import wt.org.OrganizationServicesHelper;
import wt.org.WTUser;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommonUtil implements RemoteAccess {
    /**
     * 转换中文格式，避免中文乱码
     *
     * @param value
     * @return
     * @throws WTException
     */
    public static String formatString(String value) throws WTException {
        try {
            if (value != null && value.trim().length() > 0) {
                byte[] tembyte = value.getBytes("gb2312");
                return new String(tembyte);
            } else {
                return value;
            }
        } catch (Exception e) {
            throw new WTException(e);
        }
    }

    /**
     * 处理返回的json中的信息提取需要的错误信息
     *
     * @param json 返回的json
     * @return {@link String}
     */
    public static String processResult(String json) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode rootNode = objectMapper.readTree(json);
            JsonNode isSuccessNode = rootNode.path("Result").path("ResponseStatus").path("IsSuccess");
            if (!isSuccessNode.asBoolean()) {
                JsonNode errorsNode = rootNode.path("Result").path("ResponseStatus").path("Errors");
                if (errorsNode.isArray()) {
                    StringBuilder errorMessageBuilder = new StringBuilder();
                    for (JsonNode errorNode : errorsNode) {
                        String errorMessage = errorNode.path("Message").asText();
                        errorMessageBuilder.append(errorMessage).append("\n");
                    }
                    return errorMessageBuilder.toString();
                }
            } else {
                return "IsSuccess";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 将一个实体类中的所有字段转换为Map
     *
     * @param entity 实体类
     * @return 输出的Map
     */
    public static <T> Map<String, Object> entityToMap(T entity) {
        Map<String, Object> resultMap = new HashMap<>();

        // 使用反射获取类的所有字段
        Field[] fields = entity.getClass().getDeclaredFields();

        try {
            for (Field field : fields) {
                // 设置字段为可访问，以便获取私有字段的值
                field.setAccessible(true);

                // 将字段名和字段值添加到Map中
                resultMap.put(field.getName(), field.get(entity));
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        return resultMap;
    }





    /**
     * 根据用户名称/用户全名获取用户对象
     *
     * @param name
     * @param IsFull
     * @return WTUser
     */
    @SuppressWarnings("deprecation")
    public static WTUser getUserByName(String name, boolean IsFull) {
        String parm = IsFull ? WTUser.FULL_NAME : WTUser.NAME;
        if (StringUtils.isBlank(name)) {
            return null;
        }
        try {
            Enumeration enumUser = OrganizationServicesHelper.manager.findUser(parm, name.trim());
            while (enumUser.hasMoreElements()) {
                return (WTUser) enumUser.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
     * 从QueryResult中获取需要类型的对象数据
     *
     * @param <T>   泛型对象
     * @param qr
     * @param clazz
     * @return
     */
    public static <T> ArrayList<T> getListFromQR(QueryResult qr, Class<T> clazz) {
        ArrayList<T> list = new ArrayList<T>();
        while (qr.hasMoreElements()) {
            Object obj = qr.nextElement();
            if (clazz.isInstance(obj)) {
                T castedObj = clazz.cast(obj);
                list.add(castedObj);
            }
        }
        return list;
    }

    /**
     * 连接Windchill数据库来运行自定义sql
     *
     * @return WTConnection 数据库连接
     * @throws Exception
     */
    public static WTConnection getWTConnection() {
        WTConnection wtconnection = null;
        try {
            MethodContext methodcontext = MethodContext.getContext();
            wtconnection = (WTConnection) methodcontext.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtconnection;
    }

    /**
     * 执行查询的SQL语句并返回结果 SQL示例：SELECT WTPARTNUMBER FROM WTPARTMASTER WHERE
     * WTPARTNUMBER LIKE ?
     *
     * @param sql    SQL语句
     * @param params 参数集
     * @return ResultSet 返回结果集
     */
    public static ResultSet excuteSelect(String sql, String... params){
        WTConnection connection = CommonUtil.getWTConnection();
        PreparedStatement statement =null;
        ResultSet resultSet = null;
        try {
             statement = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                statement.setString(i + 1, params[i]);
            }
            // 输出当前执行查询操作的SQL语句
            String fullSql = sql;
            for (String param : params) {
                param = param.length() > 250 ? "此属性太长，不显示内容" : param;
                fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
            }
            System.out.println("--------当前执行查询操作的SQL语句为--------");
            System.out.println(fullSql);

            resultSet = statement.executeQuery();
            return resultSet;
        } catch (Exception e) {
            e.printStackTrace();
            // 8. 清理资源
            closeQuietly(resultSet);
            closeQuietly(statement);
        }
        return null;
    }



    /**
     * 将传入的PBO解析为方便处理的List<T>
     *
     * @param <T>        泛型
     * @param obj        PBO
     * @param targetType 结果的类型
     * @return
     */
    public static <T> List<T> getListFromPBO(WTObject obj, Class<T> targetType) {
        List<T> list = new ArrayList<>();
        try {
            if (targetType.isInstance(obj)) {
                list.add(targetType.cast(obj));
            } else if (obj instanceof PromotionNotice) {
                PromotionNotice pn = (PromotionNotice) obj;
                QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeOrder2) {
                WTChangeOrder2 co = (WTChangeOrder2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeablesAfter(co);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeActivity2) {
                WTChangeActivity2 eca = (WTChangeActivity2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeRequest2) {
                WTChangeRequest2 ecr = (WTChangeRequest2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeables((ChangeRequestIfc) ecr);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else {
                System.out.println("数据不正确!");
            }
        } catch (ChangeException2 e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }











    /**
     * 携带信息并用POST请求外部系统（如SAP，OA）中的某个接口 存在账户和密码时则设置验证否则不设置 map为添加到Headers上的内容，无则填null
     *
     * @param url      访问目标接口的URL
     * @param username 访问目标接口需要验证的用户名
     * @param password 访问目标接口需要验证的密码
     * @param json     携带的json信息
     * @param method   请求的方式 GET/POST
     * @param map      请求头中需要添加的信息,没有填null
     * @return 返回的json信息
     */
    public static String requestInterface(String url, String username, String password, String json, String method,
                                          HashMap<String, String> map) {
        // 输出日志文件
        System.out.println("--------当前执行的请求接口的参数列表--------");
        System.out.println("URL: " + url);
        System.out.println("USERNAME: " + username + " PASSWORD:" + password);
        System.out.println("JSON: " + json);
        System.out.println("METHOD: " + method);
        System.out.println("HEADERS: ");

        RestTemplate restTemplate = new RestTemplate();
        // 添加BASIC认证
        String auth = username + ":" + password;
        String encodedAuth = new BASE64Encoder().encode(auth.getBytes(StandardCharsets.UTF_8));
        String authHeader = "Basic " + encodedAuth;

        restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        // 自定义请求头,添加headers内容
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", authHeader);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAcceptCharset(Collections.singletonList(StandardCharsets.UTF_8));
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        if (map != null) {
            Set<String> set = map.keySet();
            if (!set.isEmpty()) {
                for (String key : set) {
                    String value = map.get(key);
                    System.out.println("key:" + key + " value:" + map.get(key));
                    headers.add(key, value);
                }
            }
        }
        // 添加json参数,设置请求的方法并获取返回的json信息
        HttpEntity<String> entity = new HttpEntity<>(json, headers);
        ResponseEntity<String> responseEntity = method.equalsIgnoreCase("GET")
                ? restTemplate.exchange(url, HttpMethod.GET, entity, String.class)
                : restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

        if (responseEntity == null) {
            return null;
        }
        String resultJson = responseEntity.getBody();
        System.out.println("RESULTJSON: " + resultJson);
        return resultJson;
    }




    /**
     * 将对象转换为json内容
     *
     * @param entity 对象
     * @return {@link String}
     */
    public static String parseJson(Object entity) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(entity);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static boolean isNumeric(String str) {
        // 使用正则表达式判断是否为数字，允许负号和正号开头，以及小数点
        return str.matches("-?\\d+(\\.\\d+)?");
    }


    /**
     * 浮点数转换为分数
     *
     * @param decimal 浮点数
     * @return {@link String[]}
     */
    public static String[] double2Fraction(double decimal) {
        String[] fraction = new String[2];
        BigDecimal bigDecimal = BigDecimal.valueOf(decimal);
        BigInteger numerator = bigDecimal.unscaledValue();
        BigInteger denominator = BigInteger.TEN.pow(bigDecimal.scale());
        BigInteger gcd = numerator.gcd(denominator);

        fraction[0] = String.valueOf(numerator.divide(gcd));
        fraction[1] = String.valueOf(denominator.divide(gcd));
        return fraction;
    }


    /**
     * 执行更新的SQL语句并返回被更新的条数 SQL示例：UPDATE WTPARTMASTER SET WTPARTNUMBER = ? WHERE
     * IDA2A2 = ?
     *
     * @param sql    SQL语句
     * @param params 参数集
     * @return int 数据库表被影响的行数
     */
    public static int excuteUpdate(String sql, String... params) throws SQLException {
        WTConnection connection = null;
        PreparedStatement statement = null;
        try {
            connection = CommonUtil.getWTConnection();
            statement = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                statement.setString(i + 1, params[i]);
            }

            // 输出当前执行更新操作的SQL语句
            String fullSql = sql;
            for (String param : params) {
                param = param.length() > 250 ? "此属性太长，不显示内容" : param;
                fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
            }
            System.out.println("--------当前执行更新操作的SQL语句为--------");
            System.out.println(fullSql);

            return statement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            statement.close();
        }
        return 0;
    }


    /**
     *
     * 在返回的String soid中得到部件OR
     * @param soid
     * @return
     */
    public static String getPartOR(String soid) {
        String pattern =null;
        if(soid.contains("VR:wt.part.WTPart:")){
            pattern = "VR:wt.part.WTPart:\\d+"; // 正则表达式匹配模式
        } else if(soid.contains("OR:wt.part.WTPart:")){
            pattern = "OR:wt.part.WTPart:\\d+"; // 正则表达式匹配模式
        }
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(soid);
        if (m.find()) {
            String partVROrOR = m.group(0);
            if(partVROrOR.contains("OR")){
                return partVROrOR;
            } else if (partVROrOR.contains("VR")){
                return getORbyVR(partVROrOR);
            }
        }
        return "";
    }


    public static String getSubfolderOR(String soid) {
        String pattern =null;
        if(soid.contains("OR:wt.folder.SubFolder:")){
            pattern = "OR:wt.folder.SubFolder:\\d+"; // 正则表达式匹配模式
        }
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(soid);
        if (m.find()) {
            String partVROrOR = m.group(0);
            if(partVROrOR.contains("OR")){
                return partVROrOR;
            }
        }
        return "";
    }

    /**
     * 根据部件的VR查找到部件的OR
     *
     * @param VR VR:wt.part.WTPart:569305
     * @return OR OR:wt.part.WTPart:569306
     */
    public static String getORbyVR(String VR) {
        VR = VR.split(":")[2];
        String sql = "SELECT IDA2A2 FROM WTPART WHERE BRANCHIDITERATIONINFO = ?";
        String OR = "";
        try {
            ResultSet resultSet = excuteSelect(sql, VR);
            while (resultSet.next()) {
                OR = "OR:wt.part.WTPart:" + resultSet.getString("IDA2A2");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return OR;
    }

    /**
     * 执行查询的SQL语句并返回结果集（改进版）
     *
     * 优化点：
     * 1. 使用 try-with-resources 自动管理资源
     * 2. 添加分页支持防止大数据集OOM
     * 3. 使用参数化日志记录防止日志注入
     * 4. 增强异常处理和连接管理
     * 5. 添加SQL执行时间监控
     *
     * @param sql    SQL语句
     * @param params 参数集
     * @return ResultSet 返回结果集（需由调用方关闭）
     * @throws SQLException 数据库异常
     */
    public static ResultSet executeQuery(String sql, String... params) throws SQLException {
        // 使用 try-with-resources 自动管理 Connection 和 Statement
        WTConnection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            long startTime = System.currentTimeMillis();
            connection = CommonUtil.getWTConnection();
            statement = connection.prepareStatement(sql);

            // 1. 设置查询超时防止长时间阻塞
            statement.setQueryTimeout(30); // 30秒超时

            // 2. 安全设置参数
            for (int i = 0; i < params.length; i++) {
                // 防止SQL注入
                statement.setString(i + 1, params[i]);
            }

            // 3. 安全的日志记录（使用参数化方式）
            logSafeSQL("执行查询操作", sql, params);

            // 4. 执行查询
            resultSet = statement.executeQuery();

            // 5. 添加基础分页保护
            if (!isSelectWithLimit(sql)) {
                // 对于非分页查询添加行数限制
                resultSet.setFetchSize(500); // 每次获取500行
            }

            long duration = System.currentTimeMillis() - startTime;
            System.out.printf("SQL执行完成 [耗时: %dms]%n", duration);

            // 6. 返回结果集（注意：调用方需负责关闭）
            return resultSet;
        } catch (SQLException e) {
            // 7. 异常处理增强
            System.err.println("SQL执行失败: " + e.getMessage());
            System.err.println("SQL: " + sql);
            System.err.println("参数: " + Arrays.toString(params));

            // 8. 清理资源
            closeQuietly(resultSet);
            closeQuietly(statement);
            throw e; // 重新抛出异常
        } finally {
            // 注意：连接不能在这里关闭！需要由调用方管理生命周期
            // 因为结果集在使用时需要连接保持打开状态
        }
    }

//=== 辅助方法 ===//

    /**
     * 安全记录SQL日志（防止日志注入和敏感数据泄露）
     */
    private static void logSafeSQL(String operation, String sql, String[] params) {
        System.out.println("-------- " + operation + " --------");
        System.out.println("SQL模板: " + sql);

        if (params != null && params.length > 0) {
            System.out.println("参数: ");
            for (int i = 0; i < params.length; i++) {
                String displayValue = params[i];

                // 敏感数据脱敏处理
                if (sql.toLowerCase().contains("password")) {
                    displayValue = "***MASKED***";
                }

                // 长文本截断
                if (displayValue.length() > 100) {
                    displayValue = displayValue.substring(0, 100) + "...[TRUNCATED]";
                }

                System.out.printf("  参数 %d: %s%n", i + 1, displayValue);
            }
        }
    }

    /**
     * 检查SQL是否包含分页限制
     */
    private static boolean isSelectWithLimit(String sql) {
        String cleanSql = sql.toLowerCase().replaceAll("\\s+", " ");
        return cleanSql.matches(".*\\b(rownum|rowid|fetch|limit|top)\\b.*");
    }

    /**
     * 安全关闭资源（忽略异常）
     */
    private static void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                // 静默关闭
            }
        }
    }


    /**
     * 根据全局枚举的内部名称获取其中所有的子枚举的内部名称与外部名称
     *
     * @param internalName
     * @return Map<String, String>
     */
    public static Map<String, String> getEnumTypeByInternalName(String internalName) {
        Map<String, String> map = new HashMap<>();
        try {
            EnumerationDefinitionReadView edr = TypeDefinitionServiceHelper.service.getEnumDefView(internalName);
            if (edr != null) {
                Map<String, EnumerationEntryReadView> views = edr.getAllEnumerationEntries();
                Set<String> keysOfView = views.keySet();
                for (String key : keysOfView) {
                    EnumerationEntryReadView view = views.get(key);
                    String enumKey = view.getName();
                    String enumName = view.getPropertyValueByName("displayName").getValue().toString();
                    // 此方法判断枚举值是否在可用列表
                    if (view.getPropertyValueByName("selectable").getValue().equals(true)) {
                        map.put(enumKey, enumName);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    public static String getEnumDisplayName(String enumInterName , String itemInterName){
        Map<String, String> enumTypeByInternalName = getEnumTypeByInternalName(enumInterName);

        return enumTypeByInternalName.get(itemInterName);
    }

}

