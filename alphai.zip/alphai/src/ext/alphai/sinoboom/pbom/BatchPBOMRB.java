package ext.alphai.sinoboom.pbom;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;


@RBUUID("ext.alphai.sinoboom.pbom.BatchPBOMRB")
public class BatchPBOMRB extends WTListResourceBundle {

    @RBEntry("Batch PBOM View Expansion")
    public static final String BATCH_PBOM_TITLE= "PBOM.batchCreatePBOM.title";

    @RBEntry("Batch PBOM View Expansion")
    public static final String BATCH_PBOM_TOOLTIP = "PBOM.batchCreatePBOM.tooltip";

    @RBEntry("Batch PBOM View Expansion")
    public static final String BATCH_PBOM_DES= "PBOM.batchCreatePBOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String BATCH_PBOM_ICON = "PBOM.batchCreatePBOM.icon";
}
