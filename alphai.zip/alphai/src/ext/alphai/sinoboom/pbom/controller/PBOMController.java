package ext.alphai.sinoboom.pbom.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.sinoboom.pbom.service.BatchPBOMService;
import ext.alphai.sinoboom.pbom.vo.ResponseVo;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Controller
@RequestMapping({"/pbom"})
public class PBOMController {
    static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 查询部件
     *
     * @param partNumber
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/selectPart", method = RequestMethod.GET)
    public void selectPart(@RequestParam("partNumber") String partNumber, @RequestParam("isSingle") String isSingle, HttpServletRequest request,
                           HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        ResponseVo vo = null;
        try {
            //会返回200或者201状态码对象   200说明结构正常  201说明没有当前部件
            if ("true".equals(isSingle)) {
                vo = BatchPBOMService.getPartStructure(partNumber, true);
            }else {
                vo = BatchPBOMService.getPartStructure(partNumber, false);
            }

        } catch (Exception e) {
            vo = ResponseVo.error(500, e.getMessage());
            e.printStackTrace();
        }

        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response, respJson);
    }

    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }
}
