package ext.alphai.getpartcadlink;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.structure.EPMReferenceLink;
import wt.epm.structure.EPMReferenceType;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.config.LatestConfigSpec;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

/**
 * 导出EPM文档的说明和参考关系
 */
public class GetEPMDocLinkFinal4 implements RemoteAccess, Serializable {
    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", GetEPMDocLinkFinal4.class.getName(), null, new Class[]{}, new Object[]{});
    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("PTCUser1");
        rms.setPassword("r4C9PZZcApYP!%m77Fk8");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }


    static DataFormatter dataFormatter = new DataFormatter();

    public static final String Reference = "Reference";
    public static final String ReferenceBy = "ReferenceBy";
    public static final String DRAWING = "DRAWING";
    public static final String INTERNAL = "INTERNAL";
    public static final String DRAWING_FORMAT = "DRAWING_FORMAT";


    public static String process() {
        String filePath = "D:\\ptc\\Windchill_12.0\\Windchill\\ExportCADToCADLink.xlsx";
        File excelFile = new File(filePath);

        List<EPMDocument> waits = new ArrayList<>();
        List<GetLink> partDocLinks = new ArrayList<>();
        Workbook workbook = null;
        InputStream inputStream = null;

        try {
            // 第一步：读取文件内容
            inputStream = new FileInputStream(excelFile);
            workbook = WorkbookFactory.create(inputStream);

            // 读取Sheet1（索引为1）
            Sheet partNumberSheet = workbook.getSheetAt(1);
            waits = readWaitPartNumbers(partNumberSheet);

            for (EPMDocument wait : waits) {
                String CADName = wait.getCADName();
                // 获取部件与文档的说明方文档
//                List<String> describes = getReferenceByLinkChildCADName((EPMDocumentMaster) wait.getMaster());
                // 获取部件与文档的参考方文档
                List<String> drawings = find3DFrom2D(wait, DRAWING);
                List<String> internals = find3DFrom2D(wait, INTERNAL);
                List<String> drawingFormats = find3DFrom2D(wait, DRAWING_FORMAT);
                if (drawings.isEmpty()) {
                    partDocLinks.add(new GetLink(CADName, null, null, ""));
                }


                for (String reference : drawings) {
                    partDocLinks.add(new GetLink(CADName, reference, Reference, DRAWING));
                }


                if (internals.isEmpty()) {
                    partDocLinks.add(new GetLink(CADName, null, null, ""));
                }


                for (String internal : internals) {
                    partDocLinks.add(new GetLink(CADName, internal, Reference, INTERNAL));
                }

                if (drawingFormats.isEmpty()) {
                    partDocLinks.add(new GetLink(CADName, null, null, ""));
                }


                for (String drawingFormat : drawingFormats) {
                    partDocLinks.add(new GetLink(CADName, drawingFormat, Reference, DRAWING_FORMAT));
                }
            }

            // 设置序号
            int index = 1;
            for (GetLink getLink : partDocLinks) {
                getLink.setIndex(index++);
            }
            System.out.println("使用关系总数为：" + partDocLinks.size());
            System.out.println("最后一条数据的index数为：" + index);

            // 第二步：写入Sheet0
            Sheet sheet0 = workbook.getSheetAt(0);

            // 清除旧数据（保留表头）
            int lastRow = sheet0.getLastRowNum();
            for (int i = lastRow; i >= 1; i--) { // 从最后一行开始删除，保留第0行（表头）
                Row row = sheet0.getRow(i);
                if (row != null) {
                    sheet0.removeRow(row);
                }
            }

            // 写入新数据
            int rowNum = 1; // 从第1行开始（表头在第0行）
            for (GetLink link : partDocLinks) {
                Row row = sheet0.createRow(rowNum++);
                row.createCell(0).setCellValue(link.getIndex());       // INDEX
                row.createCell(1).setCellValue(link.getPartNumber());  // WTPARTNUMBER

                // 处理可能为空的文档号
                Cell docCell = row.createCell(2);
                if (link.getDocNumber() != null) {
                    docCell.setCellValue(link.getDocNumber());         // DOCNUMBER
                } else {
                    docCell.setCellValue("null"); // 空值处理
                }
                Cell reCell = row.createCell(3);
                if (link.getLinkType() != null) {
                    reCell.setCellValue(link.getLinkType());         // TYPE
                } else {
                    reCell.setCellValue("null"); // 空值处理
                }
                row.createCell(4).setCellValue("");      // STATUS
                Cell typeCell = row.createCell(5);
                if (link.getStatus() != null) {
                    typeCell.setCellValue(link.getStatus());         // TYPE
                } else {
                    typeCell.setCellValue("null"); // 空值处理
                }
            }

            // 第三步：安全写入文件（先关闭输入流再写入）
            inputStream.close(); // 关闭原始输入流
            inputStream = null;  // 释放引用

            try (OutputStream out = new FileOutputStream(excelFile)) {
                workbook.write(out);
                System.out.println("成功写入 " + partDocLinks.size() + " 条数据到Sheet0");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 确保资源释放
            try {
                if (inputStream != null) inputStream.close();
                if (workbook != null) workbook.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        return null;
    }


    public static List<EPMDocument> readWaitPartNumbers(Sheet sheet) throws WTException {
        List<EPMDocument> waits = new ArrayList<>();
        for (Row row : sheet) {
            Cell classNameCell = row.getCell(0);
            if (classNameCell == null) continue;
            String cadName = dataFormatter.formatCellValue(classNameCell).trim();
            if (!cadName.isEmpty()) {
                EPMDocument epm = getDocByNumber(cadName);
                if (epm != null) {
                    waits.add(epm);
                } else {
                    System.out.println("文档CADName：" + cadName + "没找到EPM文档对象");
                }
            }
        }
        return waits;
    }


    /**
     * 根据编号获取对应最新版本的EPM文档
     *
     * @param number
     * @return
     */
    @SuppressWarnings("deprecation")
    public static EPMDocument getDocByNumber(String cadName) {
        try {
            if (StringUtils.isBlank(cadName)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(EPMDocument.class);
            qs.appendWhere(
                    new SearchCondition(EPMDocument.class, EPMDocument.CADNAME, SearchCondition.EQUAL, cadName.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                EPMDocument doc = (EPMDocument) qr.nextElement();
                return doc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 根据EPM文档对象获取参考方 对象文件名
     *
     * @param epm
     * @return
     * @throws WTException
     */
    public static List<String> find3DFrom2D(EPMDocument epm, String referenceType) throws WTException {
        List<String> epmsFileName = new ArrayList<>();
        QueryResult qur = PersistenceHelper.manager.navigate(epm, EPMReferenceLink.REFERENCES_ROLE,
                EPMReferenceLink.class, false);
//        System.out.println("Reference SIZE" + qur.size());
        while (qur.hasMoreElements()) {
            Object o = qur.nextElement();
            if (o instanceof EPMReferenceLink) {
                EPMReferenceLink link = (EPMReferenceLink) o;
                Persistable roleBObject = link.getRoleBObject();
//                System.out.println("参考方链接ROLEB类:" + roleBObject);
                if (EPMReferenceType.toEPMReferenceType(referenceType).equals(link.getReferenceType())){
                    if (roleBObject instanceof EPMDocument) {
                        EPMDocument childEpm = (EPMDocument) roleBObject;
                        epmsFileName.add(childEpm.getCADName());
                    } else if (roleBObject instanceof EPMDocumentMaster) {
                        EPMDocumentMaster ePMMaster = (EPMDocumentMaster) roleBObject;
                        epmsFileName.add(ePMMaster.getCADName());
                    }
                }
            }
        }
        return epmsFileName;
    }


}
