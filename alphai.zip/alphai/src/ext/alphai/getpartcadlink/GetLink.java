package ext.alphai.getpartcadlink;

public class GetLink {
    private int index;
    private String partNumber;
    private String docNumber;
    private String linkType;
    private String status;

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public String getLinkType() {
        return linkType;
    }

    public void setLinkType(String linkType) {
        this.linkType = linkType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public GetLink() {
    }

    public GetLink(String partNumber, String docNumber, String linkType, String status) {
        this.partNumber = partNumber;
        this.docNumber = docNumber;
        this.linkType = linkType;
        this.status = status;
    }
}
