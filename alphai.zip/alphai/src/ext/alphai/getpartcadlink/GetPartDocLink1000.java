package ext.alphai.getpartcadlink;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.*;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class GetPartDocLink1000 implements RemoteAccess, Serializable {
    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", GetPartDocLink1000.class.getName(), null, new Class[]{}, new Object[]{});
    }


    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("r4C9PZZcApYP!%m77Fk8");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }


    static DataFormatter dataFormatter = new DataFormatter();

    public static final String Reference = "Reference";
    public static final String Describe = "Describe";

    public static String process() {
        String filePath = "D:\\ptc\\Windchill_12.0\\Windchill\\ParDocLinkA1000.xlsx";
        File excelFile = new File(filePath);

        List<WTPart> waits = new ArrayList<>();
        List<GetLink> partDocLinks = new ArrayList<>();
        Workbook workbook = null;
        InputStream inputStream = null;

        try {
            // 第一步：读取文件内容
            inputStream = new FileInputStream(excelFile);
            workbook = WorkbookFactory.create(inputStream);

            // 读取Sheet1（索引为1）
            Sheet partNumberSheet = workbook.getSheetAt(1);
            waits = readWaitPartNumbers(partNumberSheet);

            for (WTPart wait : waits) {
                String partNumber = wait.getNumber();
                // 获取部件与文档的说明方文档
                List<WTDocument> describes = getDescOrRefByPart(wait, Describe);
                // 获取部件与文档的参考方文档
                List<WTDocument> references = getDescOrRefByPart(wait, Reference);

                if(describes.isEmpty()){
                    partDocLinks.add(new GetLink(partNumber, null, Describe, ""));
                }
                if(references.isEmpty()){
                    partDocLinks.add(new GetLink(partNumber, null, Reference, ""));
                }

                for (WTDocument describe : describes) {
                    partDocLinks.add(new GetLink(partNumber, describe.getNumber(), Describe, ""));
                }

                for (WTDocument reference : references) {  // 修正变量名错误
                    partDocLinks.add(new GetLink(partNumber, reference.getNumber(), Reference, ""));
                }
            }

            // 设置序号
            int index = 1;
            for (GetLink getLink : partDocLinks) {
                getLink.setIndex(index++);
            }
            System.out.println("使用关系总数为：" + partDocLinks.size());
            System.out.println("最后一条数据的index数为：" + index);

            // 第二步：写入Sheet0
            Sheet sheet0 = workbook.getSheetAt(0);

            // 清除旧数据（保留表头）
            int lastRow = sheet0.getLastRowNum();
            for (int i = lastRow; i >= 1; i--) { // 从最后一行开始删除，保留第0行（表头）
                Row row = sheet0.getRow(i);
                if (row != null) {
                    sheet0.removeRow(row);
                }
            }

            // 写入新数据
            int rowNum = 1; // 从第1行开始（表头在第0行）
            for (GetLink link : partDocLinks) {
                Row row = sheet0.createRow(rowNum++);
                row.createCell(0).setCellValue(link.getIndex());       // INDEX
                row.createCell(1).setCellValue(link.getPartNumber());  // WTPARTNUMBER

                // 处理可能为空的文档号
                Cell docCell = row.createCell(2);
                if (link.getDocNumber() != null) {
                    docCell.setCellValue(link.getDocNumber());         // DOCNUMBER
                } else {
                    docCell.setCellValue("null"); // 空值处理
                }

                row.createCell(3).setCellValue(link.getLinkType());    // LINKTYPE
                row.createCell(4).setCellValue(link.getStatus());      // STATUS
            }

            // 第三步：安全写入文件（先关闭输入流再写入）
            inputStream.close(); // 关闭原始输入流
            inputStream = null;  // 释放引用

            try (OutputStream out = new FileOutputStream(excelFile)) {
                workbook.write(out);
                System.out.println("成功写入 " + partDocLinks.size() + " 条数据到Sheet0");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 确保资源释放
            try {
                if (inputStream != null) inputStream.close();
                if (workbook != null) workbook.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public static List<WTPart> readWaitPartNumbers(Sheet sheet) throws WTException {
        List<WTPart> waits = new ArrayList<>();
        for (Row row : sheet) {
            Cell classNameCell = row.getCell(0);
            if (classNameCell == null) continue;
            String partNumber = dataFormatter.formatCellValue(classNameCell).trim();
            if (!partNumber.isEmpty()){
                WTPart latestWTPart = getLatestWTPart(partNumber, null, null, "Design");
                if(latestWTPart != null){
                    waits.add(latestWTPart);
                }else {
                    System.out.println("部件编号："+partNumber+"没找到设计视图最新版本对象");
                }

            }
        }
        return waits;
    }







    /**
     * 根据部件编号、版本、视图获取最新版本部件
     */
    public static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName) throws WTException {
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        if (StringUtils.isNotBlank(partNumber)) {
            partNumber = partNumber.trim();

            qs = new QuerySpec(WTPart.class);
            int[] index = new int[] { 0 };
            qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);

            if (StringUtils.isNotBlank(version)) {
                version = version.trim();
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

                if (StringUtils.isNotBlank(iteration)) {
                    iteration = iteration.trim();
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
                } else {
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
                }
            }

            if (StringUtils.isNotBlank(viewName)) {
                viewName = viewName.trim();
                View viewObj = ViewHelper.service.getView(viewName);
                if (viewObj == null)
                    return null;
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
            }

            configSpec = new LatestConfigSpec();
            configSpec.appendSearchCriteria(qs);
            qr = PersistenceHelper.manager.find((StatementSpec) qs);
            qr = configSpec.process(qr);
            if (qr.hasMoreElements()) {
                part = (WTPart) qr.nextElement();
            }
        }
        return part;
    }




    /**
     * 获取部件关联的说明方文档(Described)/参考文档(Reference)
     *
     * @param part
     * @param flag Described/Reference
     * @return List<WTDocument>
     */
    public static List<WTDocument> getDescOrRefByPart(WTPart part, String flag) {
        List<WTDocument> list = new ArrayList<WTDocument>();
        try {
            switch (flag) {
                case "Describe":
                    QueryResult qr = WTPartHelper.service.getDescribedByDocuments(part);// 普通说明文档
                    while (qr.hasMoreElements()) {
                        Object obj = qr.nextElement();
                        if (obj instanceof WTDocument) {
                            WTDocument doc = (WTDocument) obj;
                            list.add(doc);
                        }
                    }
                    break;
                case "Reference":
                    qr = WTPartHelper.service.getReferencesWTDocumentMasters(part);
                    while (qr.hasMoreElements()) {
                        Object obj = qr.nextElement();
                        if (obj instanceof WTDocumentMaster) {
                            WTDocumentMaster docmaster = (WTDocumentMaster) obj;
                            QueryResult qs = VersionControlHelper.service.allVersionsOf(docmaster);
                            WTDocument doc = (WTDocument) qs.nextElement();
                            list.add(doc);
                        }
                    }
                    break;
                default:
                    break;
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

}
