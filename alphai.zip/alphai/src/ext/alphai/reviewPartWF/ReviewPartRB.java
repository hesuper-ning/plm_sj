package ext.alphai.reviewPartWF;
import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.reviewPartWF.ReviewPartRB")
public class ReviewPartRB extends WTListResourceBundle {

    @RBEntry("Similar parts")
    public static final String countPart = "countPart";


    @RBEntry("Name CN")
    public static final String name_zn = "nameZn";

    @RBEntry("Name EN")
    public static final String name_en = "nameEn";

    @RBEntry("Similar parts")
    @RBComment("Similar parts action description")
    public static final String countPart_DESC = "reviewCountPart.countPart.description";
    @RBEntry("Similar parts")
    @RBComment("Similar parts")
    public static final String countPart_TOOLTIP = "reviewCountPart.countPart.tooltip";



}
