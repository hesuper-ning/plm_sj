package ext.alphai.reviewPartWF.builder;
import com.ptc.core.components.descriptor.DescriptorConstants;
import com.ptc.jca.mvc.components.JcaColumnConfig;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.reviewPartWF.ReviewPartRB;
import ext.alphai.reviewPartWF.service.ReviewPartService;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.util.WTException;
import wt.workflow.work.WorkItem;


 

@ComponentBuilder("ext.alphai.reviewPartWF.builder.HistoricalCountPartTable")
public class HistoricalCountPartTable extends AbstractComponentBuilder {
    public static final String RESOURCECLASS = ReviewPartRB.class.getName();

    private final ClientMessageSource messageSource = getMessageSource(ReviewPartRB.class.getName());

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig config = factory.newTableConfig();
//        Locale locale = SessionHelper.getLocale();
        config.setType(WTPart.class.getName());

        config.setLabel(messageSource.getMessage(ReviewPartRB.countPart));//table标题
        config.setSelectable(true);
        config.setShowCount(true);
        config.setShowCustomViewLink(true);
        config.setSelectable(true);


        //逻辑标识
//        config.addComponents(ItemIdVersion.getColumnConfigs(factory));
        //图标
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.ICON, true));
        //编号
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.NUMBER, true));

        ColumnConfig name = factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.NAME, true);
        //设置链接
        name.setInfoPageLink(true);
        config.addComponent(name);

        //中文名称
//        ColumnConfig nameZn = factory.newColumnConfig("nameZn", true);
//        nameZn.setLabel(messageSource.getMessage(ReviewPartRB.name_zn));
////        nameZn.setLabel(WTMessage.getLocalizedMessage(RESOURCECLASS,ReviewPartRB.name_zn,null,locale));
//        nameZn.setDataUtilityId("SimilarPartsDataUtility");
//        nameZn.setAutoSize(true);
//        config.addComponent(nameZn);

//        //英文名称
//        ColumnConfig nameEn = factory.newColumnConfig("nameEn", true);
//        nameEn.setLabel(messageSource.getMessage(ReviewPartRB.name_en));
////        nameEn.setLabel(WTMessage.getLocalizedMessage(RESOURCECLASS,ReviewPartRB.name_en,null,locale));
//        nameEn.setDataUtilityId("SimilarPartsDataUtility");
//        nameEn.setAutoSize(true);
//        config.addComponent(nameEn);

        //中文名称
        ColumnConfig JC_CNNAME = factory.newColumnConfig("JC_CNNAME", true);
        JC_CNNAME.setLabel(messageSource.getMessage(ReviewPartRB.name_zn));
        config.addComponent(JC_CNNAME);

        //英文名称
        ColumnConfig AI_NAME_EN = factory.newColumnConfig("AI_NAME_EN", true);
        AI_NAME_EN.setLabel(messageSource.getMessage(ReviewPartRB.name_en));
        config.addComponent(AI_NAME_EN);

        //版本
        JcaColumnConfig version = ((JcaColumnConfig)factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.VERSION, true));
        version.setDescriptorProperty("display", "VERSION");
        config.addComponent(version);
        //查看信息
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.INFO_ACTION, true));
        //生命周期
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.STATE, true));
        //修改者
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.MODIFIED_BY, true));

        return config;
    }


    //table数据
    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        JcaComponentParams jca_params = (JcaComponentParams) componentParams;
        NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
        NmOid primaryOid2 = cb.getPrimaryOid();
        WorkItem workItem = null;
        if (primaryOid2 == null)
            return null;
        Object content = primaryOid2.getRef();
        if (content instanceof WorkItem) {
            workItem = (WorkItem) content;
        }

        WTObject pbo = ReviewPartService.getPBOByWorkItem(workItem);

        return ReviewPartService.getPartListByPBO(pbo);
    }



}
