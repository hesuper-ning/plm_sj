package ext.alphai.reviewPartWF;
import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.reviewPartWF.ReviewPartRB_zh_CN")
public class ReviewPartRB_zh_CN extends WTListResourceBundle {

    @RBEntry("相似部件")
    public static final String countPart = "countPart";

    @RBEntry("中文名称")
    public static final String name_zn = "nameZn";

    @RBEntry("英文名称")
    public static final String name_en = "nameEn";

    @RBEntry("相似部件")
    @RBComment("相似部件 action description")
    public static final String countPart_DESC = "reviewCountPart.countPart.description";
    @RBEntry("相似部件")
    @RBComment("相似部件 action tooltip")
    public static final String countPart_TOOLTIP = "reviewCountPart.countPart.tooltip";

}
