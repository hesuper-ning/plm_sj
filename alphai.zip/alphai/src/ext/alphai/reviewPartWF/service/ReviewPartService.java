package ext.alphai.reviewPartWF.service;

import ext.alphai.reviewPartWF.util.PropertiesUtil;
import ext.util.CommonUtil;
import ext.util.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.fc.*;
import wt.maturity.MaturityHelper;
import wt.maturity.Promotable;
import wt.maturity.PromotionNotice;
import wt.maturity.PromotionTarget;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pom.WTConnection;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.workflow.work.WorkItem;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ReviewPartService {


    /**
     * 通过workitem获取pbo
     *
     * @param workItem
     * @return pbo
     */
    public static WTObject getPBOByWorkItem(WorkItem workItem) {
        WTObject pbo = null;
        boolean origEnforce = false;
        try {
            origEnforce = SessionServerHelper.manager.setAccessEnforced(false);
            pbo = (WTObject) workItem.getPrimaryBusinessObject().getObject();
        } catch (NullPointerException nex) {
            pbo = null;
        } finally {
            SessionServerHelper.manager.setAccessEnforced(origEnforce);
        }
        return pbo;
    }

    public static List<WTPart> getPartListByPBO(WTObject pbo) throws WTException {
        List<WTPart> wtParts = new ArrayList<>();
        //pbo--->ECA
        if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
            //获取产生对象的部件
            wtParts.addAll(getChangeablesAfterPartsByECA(eca));
        } else if (pbo instanceof PromotionNotice) {
            PromotionNotice pn = (PromotionNotice) pbo;
            //获取升级对象的部件
            wtParts.addAll(getTargerObjectByPromotionNotices(pn));
        }


        //获取历史防重技术号部件
        return  getHistoryCountPart(wtParts);
    }

    /**
     * 从PBO中获取升级请求
     *
     * @param primaryBusinessObject
     * @return
     */
    public static PromotionNotice getPromotionNotices(WTObject primaryBusinessObject) throws WTException {
        PromotionNotice pn = null;
        if (primaryBusinessObject instanceof PromotionNotice) {
            pn = (PromotionNotice) primaryBusinessObject;

        }
        return pn;
    }

    /**
     * 获取升级请求中被升级的对象 ---部件
     *
     * @return ArrayList<WTObject>
     * @throws WTException
     */
    public static List<WTPart> getTargerObjectByPromotionNotices(PromotionNotice pn) throws WTException {
        List<WTPart> list = new ArrayList<WTPart>();
        //pn获取升级对象
        QueryResult qr = MaturityHelper.service.getPromotionTargets(pn, false);
        while (qr.hasMoreElements()) {
            PromotionTarget pt = (PromotionTarget) qr.nextElement();
            Promotable ptObj = pt.getPromotable();
            if (ptObj instanceof  WTPart){
                list.add((WTPart) ptObj);
            }
        }
        return list;
    }

    /**
     * 获取产生对象的部件
     * @param eca
     * @return
     * @throws WTException
     */
    public static List<WTPart> getChangeablesAfterPartsByECA(WTChangeActivity2 eca) throws WTException {
        List<WTPart> wtParts = new ArrayList<>();
        //ECA获取产生对象  true是直接获取对象
        QueryResult links = ChangeHelper2.service.getChangeablesAfter(eca);
        while (links.hasMoreElements()) {
            Object obj = links.nextElement();
            //只获取部件
            if (obj instanceof WTPart) {
                wtParts.add((WTPart) obj);
            }
        }

        return wtParts;
    }


    /**
     *   获取 A版本且有防重技术号
     * @param parts
     * @return
     */
    public static List<WTPart>  getHistoryCountPart(List<WTPart> parts) throws WTException {
        String AI_CountKey = PropertiesUtil.getValueByKey("part.iba.AI_Count");
        String filterVersion = PropertiesUtil.getValueByKey("part.filter.version");
        String partCls = PropertiesUtil.getValueByKey("part.iba.MPartsClsNODE");
        List<WTPart> wtParts = new ArrayList<>();
        for (WTPart part : parts) {
            String version = part.getVersionIdentifier().getValue();
            IBAUtil ibaUtil = new IBAUtil(part);
            String AI_Count = ibaUtil.getIBAValue(AI_CountKey);

            //版本为A且防重技术号不为空
            if (filterVersion.equals(version) && StringUtils.isNotEmpty(AI_Count)){
                List<WTPart> wtPartListByName = getWTPartListByName(part, AI_Count);
                wtParts.addAll(wtPartListByName);
            }
        }

        return wtParts;
    }


    /**
     * 根据名称查询List
     *
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static List<WTPart> getWTPartListByName(WTPart part, String AI_Count) {
        List<WTPart> result = new ArrayList<WTPart>();
        String partName = part.getName();
        long partIda2a2 = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
        int length = partName.length();
        int countLength = AI_Count.length();

        String namePrefix = partName.substring(0, length - countLength);
        WTConnection conn = CommonUtil.getWTConnection();
        String sql = "SELECT * FROM WTPARTMASTER WHERE NAME LIKE ? AND LENGTH(NAME) = ?";
        // 创建PreparedStatement
        try (PreparedStatement stmt = conn.prepareStatement(sql);){
            stmt.setString(1, namePrefix + "%"); // 设置前缀匹配
            stmt.setInt(2, length); // 设置长度匹配

            // 执行查询
            ResultSet rs = stmt.executeQuery();

            // 输出查询结果
            while (rs.next()) {
                long dbIda2a2 = rs.getLong("IDA2A2");
                String dbPartName = rs.getString("NAME");
                //去掉相同的
//                if(dbIda2a2 == partIda2a2){
//                    continue;
//                }

                //获取后缀  大于  放重技术号的跳过
                String dbOrderNum = dbPartName.substring(length - countLength);
                if (isNumeric(dbOrderNum)) {
                    try {
                        int dbOrderValue = Integer.parseInt(dbOrderNum);
                        int countInt = Integer.parseInt(AI_Count);
                        //  只有后缀数字大于AI_Count时才跳过
                        if (dbOrderValue > countInt) {
                            continue; // 大于时跳过
                        }
                        // 小于等于时继续处理
                    } catch (NumberFormatException e) {
                        continue; // 数字转换失败时跳过
                    }
                } else {
                    continue; // 不是数字时跳过
                }
                //查的是master
                ReferenceFactory rf = new ReferenceFactory();
                WTReference reference =  rf.getReference("OR:wt.part.WTPartMaster:"+dbIda2a2);
                WTPartMaster partMaster = (WTPartMaster)reference.getObject();
                QueryResult queryResult = VersionControlHelper.service.allVersionsOf(partMaster);
                if (queryResult.hasMoreElements()) {
                    WTPart o =(WTPart) queryResult.nextElement();
                    result.add(o);
                }

            }
            rs.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }


    public static boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        try {
            Integer.parseInt(str); // 或者 Integer.parseInt(str)
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
