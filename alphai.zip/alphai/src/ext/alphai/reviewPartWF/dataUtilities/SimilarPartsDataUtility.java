package ext.alphai.reviewPartWF.dataUtilities;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import ext.alphai.reviewPartWF.util.PropertiesUtil;
import ext.util.IBAUtil;
import wt.part.WTPart;
import wt.util.WTException;

public class SimilarPartsDataUtility extends AbstractDataUtility {
    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        WTPart wtPart = (WTPart) o;
        if (wtPart == null) return null;
        IBAUtil ibaUtil = new IBAUtil(wtPart);

        String nameZn = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("part.iba.JC_CNNAME"));
        String nameEN = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("part.iba.AI_NAME_EN"));

        if ("nameZn".equals(s)){
            return nameZn;
        }else if ("nameEN".equals(s)){
            return nameEN;
        }
        return null;
    }
}




