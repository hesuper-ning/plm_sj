package ext.alphai.aistoneglobal.part.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.part.service.PartService;
import ext.alphai.globalPart.processor.AICreatePartProcessor;
import wt.part.WTPart;
import wt.util.WTException;

import java.sql.SQLException;
import java.util.List;

public class AICreatePartMoveProcessor extends AICreatePartProcessor {


    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = super.postProcess(nmCommandBean, list);

        System.out.println("移动文件夹位置");

        WTPart wtPartByBean = PartService.getWTPartByBean(list);

        if (wtPartByBean != null){
            try {
                System.out.println("开始移动"+wtPartByBean);
                PartService.partTOSpecifyThePath(wtPartByBean);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }


//        formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null, new String[] { "未指定关联部件，会创建文档但不会与部件关联！" }));

        return formResult;
    }




}
