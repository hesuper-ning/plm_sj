package ext.alphai.aistoneglobal.part.common;

public class AttributesConstant {

    public static final String IBA_CLSNODE = "AI_CLSNODE"; // 部件属性分类名称
    public static final String CLSNODE_IBA_GENERAL_PURPOSE_COMPONENT = "AI_GeneralPurposeComponent"; // 分类节点属性 通用件
}
