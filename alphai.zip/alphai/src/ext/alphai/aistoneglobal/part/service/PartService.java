package ext.alphai.aistoneglobal.part.service;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.lwc.server.LWCIBAAttDefinition;
import ext.alphai.aistoneglobal.part.common.AttributesConstant;
import ext.alphai.aistoneglobal.part.util.PropertiesUtil;
import ext.alphai.aistoneglobal.util.IBAUtil;
import ext.util.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.ObjectIdentifier;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.part.WTPart;
import wt.util.WTException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

public class PartService {

    public static void partTOSpecifyThePath (WTPart wtPart) throws WTException, SQLException {
        //获取iba属性内部值
        IBAUtil ibaUtil = new IBAUtil(wtPart);
        //用分类节点内部名获取分类节点的  iba属性通用件  -----注意  后面固定取英文的
        String generalPurposeComponent = ibaUtil.getIBAValue(AttributesConstant.CLSNODE_IBA_GENERAL_PURPOSE_COMPONENT);
        //判断是否移动   通过分类属性通用件判断
        if (PartService.isMove(generalPurposeComponent)) {
            //开始移动
            PartService.movePart(wtPart,ibaUtil);
        }
    }

    public static WTPart getWTPartByBean(List<ObjectBean> list){
        WTPart wtPart = (!list.isEmpty())
                ? (list.get(0).getObject() instanceof WTPart ? (WTPart) list.get(0).getObject() : null)
                : null;

        return wtPart;
    }


    public static boolean isMove(String generalPurposeComponent){
        boolean flag = false;
        if ("真".equals(generalPurposeComponent) || "True".equals(generalPurposeComponent)){
            flag = true;

        }
        return flag;
    }


    public static void movePart(WTPart wtPart ,  IBAUtil ibaUtil) throws SQLException, WTException {
        //获取分类节点内部名
        String clsNode = ibaUtil.getIBAValue(AttributesConstant.IBA_CLSNODE);

        String allPath = PropertiesUtil.getValueByKey("AI.PartFolderPath." + clsNode);//获取配置路径
        if (allPath == null) {
            System.out.println("未找到全路径!");
            return;
        }
        String[] split = allPath.split("/");
        //第一个/前是存储库
        String toLibrary = split[0];

        // 部件容器
        WTContainer container = wtPart.getContainer();
        // 目标存储库
        WTLibrary targetLib = getContainerByName(toLibrary);

        //若没有存储库
        if (targetLib == null) {
            System.out.println("未设置配置分类部件所属存储库" + toLibrary);
            return;
        }

        WTContainerRef c_ref = WTContainerRef.newWTContainerRef(targetLib);



        // 目标存储库的容器
        WTContainer libContainer = targetLib.getContainer();
        // 目标文件路径      Global Parts Library/分类英文显示名
        String foldPath = allPath.replaceFirst("^[^/]*/", "");
        String tarFolderPath = "/Default/" + foldPath;

        System.out.println("目标文件夹路径: " + tarFolderPath);

        // 校验是否已经根据分类英文名称创建文件夹
        QueryResult folderContents = FolderHelper.service.findFolderContents(targetLib.getDefaultCabinet());
        Vector vector = folderContents.getObjectVectorIfc().getVector();
        SubFolder currentFolder = null;

        String[] foldPathArr = foldPath.split("/");
        boolean pathExists = true;

        // 逐层查找文件夹
        for (int i = 0; i < foldPathArr.length && pathExists; i++) {
            String currentFolderName = foldPathArr[i];
            boolean foundCurrentLevel = false;

            System.out.println("查找第 " + (i+1) + " 层文件夹: " + currentFolderName);

            // 获取当前层的文件夹列表
            Vector currentLevelVector;
            if (i == 0) {
                // 第一层从容器的根目录开始
                currentLevelVector = vector;
            } else {
                // 后续层从当前文件夹的子文件夹开始
                if (currentFolder == null) {
                    pathExists = false;
                    break;
                }
                QueryResult subFolders = FolderHelper.service.findSubFolders(currentFolder);
                // 处理 subFolders 为空的情况
                if (subFolders == null || !subFolders.hasMoreElements()) {
                    System.out.println("文件夹 " + currentFolder.getName() + " 没有子文件夹");
                    pathExists = false;
                    break;
                }
                currentLevelVector = subFolders.getObjectVectorIfc().getVector();
            }

            // 在当前层查找匹配的文件夹
            for (Object o : currentLevelVector) {
                if (o instanceof SubFolder) {
                    SubFolder subFolder = (SubFolder) o;
                    String subFolderName = subFolder.getName();

                    System.out.println("当前层文件夹名称: " + subFolderName);

                    if (subFolderName.equals(currentFolderName)) {
                        currentFolder = subFolder;
                        foundCurrentLevel = true;
                        System.out.println("找到匹配文件夹: " + currentFolderName);
                        break;
                    }
                }
            }

            if (!foundCurrentLevel) {
                pathExists = false;
                System.out.println("未找到文件夹: " + currentFolderName);
                currentFolder = null;
            }
        }

        if (currentFolder != null) {
            System.out.println("完整路径存在，最终文件夹: " + currentFolder.getName());
            System.out.println("完整路径存在: " + currentFolder.getFolderPath());

        } else {
            System.out.println("完整路径不存在，需要创建文件夹");
        }

        //文件夹不存在直接跳过
        if (currentFolder ==null) {
            System.out.println("文件夹不存在！");
            return;
        }
        System.out.println("创建的容器："+container.getName()+",目标容器："+targetLib.getName()+",ref:"+c_ref.getName()+"目标存储库的容器："+libContainer.getName());
        if (container.equals(targetLib)) {
            // 如果是在同一个容器内 使用相同容器转移文件夹方法
            System.out.println("相同容器");
            FolderHelper.service.changeFolder((wt.folder.FolderEntry) wtPart, currentFolder);
        } else {
            // 不处于相同容器
            System.out.println("不相同容器");
            //直接移动到不同容器导致重命名失效，只能提示不允许在该容器创建
            throw new WTException("该分类的部件不允许在此容器创建，请在"+targetLib.getName()+"存储库创建部件！");
//            WTValuedMap objFolderMap = new WTValuedHashMap(1);
//
//            objFolderMap.put(wtPart, currentFolder);
//            WTCollection col = ContainerMoveHelper.service.moveAllVersions(objFolderMap);
        }


    }

    /**
     * 通过名称获取存储库对象
     *
     * @param containerName
     * @return
     */
    public static WTLibrary getContainerByName(String containerName) throws SQLException {
        WTLibrary container = null;
        String sql = "SELECT CLASSNAMEA2A2, IDA2A2 FROM WTLIBRARY WHERE NAMECONTAINERINFO = ?";
        ResultSet resultSet = null;
        try {
            resultSet = CommonUtil.excuteSelect(sql, containerName);
            while (resultSet.next()) {
                String CLASSNAMEA2A2 = resultSet.getString("CLASSNAMEA2A2");
                String IDA2A2 = resultSet.getString("IDA2A2");
                if (!StringUtils.isBlank(CLASSNAMEA2A2) && !StringUtils.isBlank(IDA2A2)) {
                    ObjectIdentifier oid = ObjectIdentifier.newObjectIdentifier(CLASSNAMEA2A2 + ":" + IDA2A2);
                    container = (WTLibrary) PersistenceHelper.manager.refresh(oid);
                }
            }
            resultSet.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (resultSet != null) {
                resultSet.close();
            }
        }

        return container;
    }











}
