package ext.alphai.aistoneglobal.workflow.util;

import wt.change2.ChangeException2;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.ObjectReference;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.util.WTException;
import wt.workflow.engine.WfActivity;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class WorkflowUtil {
    private static Map<String, String> roleCorrespondence = new HashMap<>();

    static {
        roleCorrespondence.put("CONUNTERSIGN", "会签人员");
        roleCorrespondence.put("AUDITOR", "审核者");
        roleCorrespondence.put("APPROVER", "批准者");
        roleCorrespondence.put("Normalizer", "标准化");
        roleCorrespondence.put("MANHOUR_ATOR", "工时定额员");
        roleCorrespondence.put("PROOFREADERS", "校对者");
        roleCorrespondence.put("Assessor", "审核者");
        roleCorrespondence.put("RECIPIENT", "计划收件人");
        roleCorrespondence.put("REVIEWER", "审阅者");
        roleCorrespondence.put("PROJECT MANAGER", "项目经理");
        roleCorrespondence.put("STANDARD_PROOFREADER", "标准化审阅者");
        roleCorrespondence.put("PROCESS_REVIEWER", "工艺化审阅者");
        roleCorrespondence.put("PLANNER", "计划人员");
        roleCorrespondence.put("Tooling_designer", "工装设计师");
        roleCorrespondence.put("FROCKMANAGER", "工装管理员");
        roleCorrespondence.put("DIRECTORSUPERVISOR", "工装所长、主管");
//        roleCorrespondence.put("STANDARD_PROOFREADER","标准化审阅者");
//        roleCorrespondence.put("STANDARD_PROOFREADER","标准化审阅者");

    }


    /**
     * 获得给定对象对应的流程
     *
     * @param self
     * @return WfProcess
     * @throws WTException
     */
    public static WfProcess getWfProcess(ObjectReference self) throws WTException {
        WfProcess process = null;
        try {
            if (self.getObject() instanceof WfActivity) {
                WfActivity wfactivity = (WfActivity) self.getObject();
                process = wfactivity.getParentProcess();
            } else if (self.getObject() instanceof WfProcess) {
                process = (WfProcess) self.getObject();
            } else if ((WfAssignedActivity.class).isAssignableFrom(self.getObject().getClass())) {
                process = ((WfAssignedActivity) self.getObject()).getParentProcess();
            } else if ((WfProcess.class).isAssignableFrom(self.getObject().getClass())) {
                process = (WfProcess) self.getObject();
            } else {
                throw new WTException("Get process from " + self.getObject().getClass().getName() + " is illegal.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        }

        return process;
    }


    public static String  getActivityName(ObjectReference self){
        String actName = "";
        if ((WfAssignedActivity.class).isAssignableFrom(self.getObject().getClass())) {
            WfAssignedActivity activity =  (WfAssignedActivity) self.getObject();
            actName = activity.getName();
        }
        return actName;
    }

    /**
     * 获取当前活动名称
     *
     * @param workItem
     * @return
     * @throws Exception
     */
    public static String getActivityName(WorkItem workItem) throws Exception {
        WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
        String actName = activity.getName();

        return actName;
    }

    /***
     * 获取审阅/变更目标对象
     *
     * @param <T>
     * @param primaryBusinessObject 流程的primaryBusinessObject
     * @param type   GetTargerObjectUtil.AffectedObjects受影响对象/GetTargerObjectUtil.ResultingObjects产生的对象
     * @param clazz    WTPart.class/WTDocument.class
     * @return ArrayList<T>
     */
    public static <T> ArrayList<T> getTargetObject(WTObject primaryBusinessObject, String type, Class<T> clazz) {
        ArrayList<T> list = new ArrayList<T>();

        if (!type.equals("AffectedObjects") && !type.equals("ResultingObjects")) {
            System.out.println("获取审阅/变更目标对象失败，只能指定为受影响对象或产生的对象");
            return list;
        }

        try {
//			if (primaryBusinessObject instanceof WTChangeReview) {
//				WTChangeReview review = (WTChangeReview) primaryBusinessObject;
//				QueryResult qr = ChangeHelper2.service.getChangeables(review);
//				list = CommonUtil.getListFromQR(qr, clazz);
//			} else
            if (primaryBusinessObject instanceof PromotionNotice) {

                PromotionNotice pn = (PromotionNotice) primaryBusinessObject;
                QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
                list =  CommonUtil.getListFromQR(qr, clazz);

            } else if (primaryBusinessObject instanceof WTChangeOrder2) {

                if (type.equals("AffectedObjects")) {
                    WTChangeOrder2 eco = (WTChangeOrder2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesBefore(eco);
                    list =  CommonUtil.getListFromQR(qr, clazz);
                } else if (type.equals("ResultingObjects")) {
                    WTChangeOrder2 eco = (WTChangeOrder2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eco);
                    list =  CommonUtil.getListFromQR(qr, clazz);
                }

            } else if (primaryBusinessObject instanceof WTChangeActivity2) {

                if (type.equals("AffectedObjects")) {
                    WTChangeActivity2 eca = (WTChangeActivity2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesBefore(eca);
                    list = CommonUtil.getListFromQR(qr, clazz);
                } else if (type.equals("ResultingObjects")) {
                    WTChangeActivity2 eca = (WTChangeActivity2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
                    list = CommonUtil.getListFromQR(qr, clazz);
                }

            }
        } catch (ChangeException2 e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

}