package ext.alphai.aistoneglobal.workflow.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FilenameFilter;
import java.util.*;
import java.util.regex.Pattern;

public class NetworkFolderUtil {

    private static final Logger logger = LogManager.getLogger(NetworkFolderUtil.class);

    /**
     * 获取指定网络路径下的所有子文件夹
     * @param networkPath 网络路径，如 //10.100.180.93/wvs_doc_temp_uat
     * @return 子文件夹名称列表，按字母排序
     */
    public static List<String> getSubFolders(String networkPath) {
        List<String> folderNames = new ArrayList<>();

        if (StringUtils.isBlank(networkPath)) {
            logger.error("网络路径为空");
            return folderNames;
        }

        try {
            // 标准化路径
            String normalizedPath = normalizeNetworkPath(networkPath);
            File directory = new File(normalizedPath);

            logger.info("扫描网络路径: {}", normalizedPath);

            // 检查路径是否存在
            if (!directory.exists()) {
                logger.error("网络路径不存在: {}", normalizedPath);
                return folderNames;
            }

            if (!directory.isDirectory()) {
                logger.error("路径不是目录: {}", normalizedPath);
                return folderNames;
            }

            if (!directory.canRead()) {
                logger.error("没有读取权限: {}", normalizedPath);
                return folderNames;
            }

            // 获取所有文件和文件夹
            File[] files = directory.listFiles();
            if (files == null) {
                logger.warn("目录为空或无法访问: {}", normalizedPath);
                return folderNames;
            }

            // 筛选出文件夹
            for (File file : files) {
                if (file.isDirectory()) {
                    folderNames.add(file.getName());
                }
            }

            // 按字母排序
            Collections.sort(folderNames);

            logger.info("找到 {} 个子文件夹", folderNames.size());

        } catch (SecurityException e) {
            logger.error("安全异常，无法访问网络路径: {} - {}", networkPath, e.getMessage());
        } catch (Exception e) {
            logger.error("获取子文件夹失败: {} - {}", networkPath, e.getMessage(), e);
        }

        return folderNames;
    }

    /**
     * 获取指定子文件夹中最新的PDF文件
     * @param networkPath 网络路径
     * @param subFolderName 子文件夹名称
     * @return 最新的PDF文件，如果没有返回null
     */
    public static File getLatestPDFInFolder(String networkPath, String subFolderName) {
        if (StringUtils.isBlank(networkPath) || StringUtils.isBlank(subFolderName)) {
            logger.error("参数不能为空");
            return null;
        }

        try {
            // 构建完整路径
            String normalizedPath = normalizeNetworkPath(networkPath);
            String fullPath = normalizedPath + File.separator + subFolderName;
            File folder = new File(fullPath);

            logger.info("扫描PDF文件，路径: {}", fullPath);

            // 验证文件夹
            if (!folder.exists() || !folder.isDirectory() || !folder.canRead()) {
                logger.error("文件夹无法访问: {}", fullPath);
                return null;
            }

            // 定义PDF文件过滤器
            FilenameFilter pdfFilter = (dir, name) -> {
                String lowerName = name.toLowerCase();
                return lowerName.endsWith(".pdf");
            };

            // 获取所有PDF文件
            File[] pdfFiles = folder.listFiles(pdfFilter);

            if (pdfFiles == null || pdfFiles.length == 0) {
                logger.info("文件夹中没有PDF文件: {}", subFolderName);
                return null;
            }

            logger.info("找到 {} 个PDF文件", pdfFiles.length);

            // 按修改时间排序，获取最新的
            Arrays.sort(pdfFiles, (f1, f2) -> {
                long time1 = f1.lastModified();
                long time2 = f2.lastModified();
                return Long.compare(time2, time1); // 降序排序
            });

            File latestPDF = pdfFiles[0];
            logger.info("最新PDF文件: {} (大小: {} bytes, 修改时间: {})",
                    latestPDF.getName(),
                    latestPDF.length(),
                    new Date(latestPDF.lastModified()));

            return latestPDF;

        } catch (Exception e) {
            logger.error("获取最新PDF失败: {}/{} - {}",
                    networkPath, subFolderName, e.getMessage(), e);
            return null;
        }
    }

    /**
     * 批量获取所有子文件夹的最新PDF文件
     * @param networkPath 网络路径
     * @return Map<子文件夹名称, 最新PDF文件>，如果没有PDF则为null
     */
    public static Map<String, File> getAllLatestPDFs(String networkPath) {
        Map<String, File> result = new LinkedHashMap<>();

        // 获取所有子文件夹
        List<String> subFolders = getSubFolders(networkPath);

        for (String folderName : subFolders) {
            File latestPDF = getLatestPDFInFolder(networkPath, folderName);
            result.put(folderName, latestPDF);
        }

        return result;
    }

    /**
     * 获取指定子文件夹中符合命名模式的PDF文件
     * @param networkPath 网络路径
     * @param subFolderName 子文件夹名称
     * @param patternRegex 文件名正则表达式，如 ".*图纸.*\\.pdf"
     * @return 匹配的最新PDF文件
     */
    public static File getLatestPDFByPattern(String networkPath, String subFolderName, String patternRegex) {
        if (StringUtils.isBlank(networkPath) || StringUtils.isBlank(subFolderName)) {
            return null;
        }

        try {
            String normalizedPath = normalizeNetworkPath(networkPath);
            String fullPath = normalizedPath + File.separator + subFolderName;
            File folder = new File(fullPath);

            if (!folder.exists() || !folder.isDirectory() || !folder.canRead()) {
                return null;
            }

            Pattern pattern = Pattern.compile(patternRegex, Pattern.CASE_INSENSITIVE);

            // 自定义过滤器
            File[] pdfFiles = folder.listFiles((dir, name) -> {
                String lowerName = name.toLowerCase();
                if (!lowerName.endsWith(".pdf")) {
                    return false;
                }
                return pattern.matcher(name).matches();
            });

            if (pdfFiles == null || pdfFiles.length == 0) {
                return null;
            }

            // 按修改时间排序
            Arrays.sort(pdfFiles, (f1, f2) ->
                    Long.compare(f2.lastModified(), f1.lastModified()));

            return pdfFiles[0];

        } catch (Exception e) {
            logger.error("按模式查找PDF失败: {}", e.getMessage(), e);
            return null;
        }
    }

    /**
     * 获取PDF文件信息
     * @param pdfFile PDF文件
     * @return 文件信息Map
     */
    public static Map<String, Object> getPDFInfo(File pdfFile) {
        Map<String, Object> info = new HashMap<>();

        if (pdfFile == null || !pdfFile.exists()) {
            return info;
        }

        try {
            info.put("name", pdfFile.getName());
            info.put("path", pdfFile.getAbsolutePath());
            info.put("size", pdfFile.length());
            info.put("sizeMB", String.format("%.2f MB", pdfFile.length() / (1024.0 * 1024.0)));
            info.put("lastModified", new Date(pdfFile.lastModified()));
            info.put("canRead", pdfFile.canRead());
            info.put("canWrite", pdfFile.canWrite());

        } catch (SecurityException e) {
            logger.error("获取文件信息失败: {}", e.getMessage());
        }

        return info;
    }

    /**
     * 标准化网络路径
     */
    private static String normalizeNetworkPath(String path) {
        if (StringUtils.isBlank(path)) {
            return path;
        }

        String normalized = path.trim();

        // 统一使用正斜杠
        normalized = normalized.replace("\\", "/");

        // 确保网络路径以//开头
        if (normalized.contains("//")) {
            if (!normalized.startsWith("//")) {
                // 移除内部的//，确保开头的//
                normalized = normalized.replace("//", "/");
                normalized = "//" + normalized;
            }
        } else if (normalized.matches("^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")) {
            // IP地址格式，添加//
            normalized = "//" + normalized;
        }

        // 移除末尾的斜杠
        if (normalized.endsWith("/")) {
            normalized = normalized.substring(0, normalized.length() - 1);
        }

        return normalized;
    }

    /**
     * 测试方法
     */
    public static void main(String[] args) {
        // 测试网络路径
        String networkPath = "//10.100.180.93/wvs_doc_temp_uat";

        System.out.println("=== 测试网络路径: " + networkPath + " ===");

        // 1. 获取所有子文件夹
        List<String> folders = getSubFolders(networkPath);
        System.out.println("\n1. 子文件夹列表 (" + folders.size() + " 个):");
        for (String folder : folders) {
            System.out.println("   - " + folder);
        }

        // 2. 获取第一个文件夹的最新PDF
        if (!folders.isEmpty()) {
            String firstFolder = folders.get(0);
            System.out.println("\n2. 获取文件夹 '" + firstFolder + "' 的最新PDF:");

            File latestPDF = getLatestPDFInFolder(networkPath, firstFolder);
            if (latestPDF != null) {
                Map<String, Object> info = getPDFInfo(latestPDF);
                System.out.println("   文件名: " + info.get("name"));
                System.out.println("   大小: " + info.get("sizeMB"));
                System.out.println("   修改时间: " + info.get("lastModified"));
                System.out.println("   路径: " + info.get("path"));
            } else {
                System.out.println("   没有找到PDF文件");
            }
        }

        // 3. 批量获取所有文件夹的最新PDF
        System.out.println("\n3. 批量获取所有文件夹的最新PDF:");
        Map<String, File> allPDFs = getAllLatestPDFs(networkPath);
        for (Map.Entry<String, File> entry : allPDFs.entrySet()) {
            System.out.print("   " + entry.getKey() + ": ");
            if (entry.getValue() != null) {
                System.out.println(entry.getValue().getName());
            } else {
                System.out.println("无PDF文件");
            }
        }
    }
}