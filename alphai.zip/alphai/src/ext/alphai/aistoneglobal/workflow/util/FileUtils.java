package ext.alphai.aistoneglobal.workflow.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

public class FileUtils {

    // 1. 添加日志记录器
    private static final Logger logger = LogManager.getLogger(FileUtils.class);


    /**
     * 在指定父文件夹中创建新文件夹（兼容网络驱动器）
     * @param parentPath 父文件夹路径
     * @param folderName 要创建的新文件夹名称
     * @return "success"表示成功，否则返回错误信息
     */
    public static String createFolderInParent(String parentPath, String folderName) {
        // 输入验证
        if (StringUtils.isBlank(parentPath)) {
            String error = "父文件夹路径为空";
            logger.error("创建文件夹失败：{}", error);
            return error;
        }

        if (StringUtils.isBlank(folderName)) {
            String error = "文件夹名称为空";
            logger.error("创建文件夹失败：{}", error);
            return error;
        }

        try {
            // 标准化路径：处理反斜杠转义
            String normalizedPath = parentPath.replace("\\\\", "\\");

            // 特殊处理：如果是网络驱动器根目录，检查其是否存在
            if (isNetworkDriveRoot(normalizedPath)) {
                File driveRoot = new File(normalizedPath);
                if (!driveRoot.exists() || !driveRoot.isDirectory()) {
                    String error = "网络驱动器不存在或不可访问：" + normalizedPath;
                    logger.error("创建文件夹失败：{}", error);
                    return error;
                }
            }

            // 使用File API（对网络驱动器兼容性更好）
            File parentDir = new File(normalizedPath);
            File targetDir = new File(parentDir, folderName);

            // 1. 检查目标文件夹是否已存在
            if (targetDir.exists() && targetDir.isDirectory()) {
                logger.info("文件夹已存在: {}", targetDir.getAbsolutePath());
                return "success";
            }

            // 2. 检查并创建父目录（如果是根目录则不创建）
            if (!parentDir.exists()) {
                // 如果是根目录，直接返回错误
                if (isRootDirectory(normalizedPath)) {
                    String error = "根目录不存在：" + normalizedPath;
                    logger.error("创建文件夹失败：{}", error);
                    return error;
                }

                logger.info("创建父目录: {}", normalizedPath);
                if (!parentDir.mkdirs()) {
                    String error = "无法创建父目录：" + normalizedPath;
                    logger.error("{}", error);
                    return error;
                }
            }

            // 3. 验证父目录
            if (!parentDir.isDirectory()) {
                String error = "父路径不是有效的目录：" + normalizedPath;
                logger.error("{}", error);
                return error;
            }

            if (!parentDir.canWrite()) {
                String error = "父目录没有写入权限：" + normalizedPath;
                logger.error("{}", error);
                return error;
            }

            // 4. 创建目标文件夹
            logger.debug("创建文件夹: {}", targetDir.getAbsolutePath());
            if (targetDir.mkdir()) {
                // 验证是否创建成功
                if (targetDir.exists() && targetDir.isDirectory()) {
                    logger.info("文件夹创建成功: {}", targetDir.getAbsolutePath());
                    return "success";
                } else {
                    String error = "文件夹创建后验证失败：" + targetDir.getAbsolutePath();
                    logger.error("{}", error);
                    return error;
                }
            } else {
                String error = "文件夹创建失败：" + targetDir.getAbsolutePath();
                logger.error("{}", error);
                return error;
            }

        } catch (SecurityException e) {
            String error = "权限不足：" + e.getMessage();
            logger.error("{} - 路径: {}/{}", error, parentPath, folderName);
            return error;
        } catch (Exception e) {
            String error = "创建文件夹失败：" + e.getMessage();
            logger.error("{} - 路径: {}/{}", error, parentPath, folderName);
            return error;
        }
    }

    /**
     * 检查是否为根目录
     */
    private static boolean isRootDirectory(String path) {
        if (StringUtils.isBlank(path)) {
            return false;
        }

        // Windows驱动器根目录，如 C:\、D:\、Z:\
        if (path.matches("^[A-Za-z]:\\\\$")) {
            return true;
        }

        // UNC路径根目录，如 \\server\share\
        if (path.matches("^\\\\\\\\[^\\\\]+\\\\[^\\\\]+\\\\$")) {
            return true;
        }

        // 检查路径是否只有驱动器盘符
        File file = new File(path);
        File parent = file.getParentFile();
        return parent == null;
    }

    /**
     * 检查是否为网络驱动器根目录
     */
    private static boolean isNetworkDriveRoot(String path) {
        if (StringUtils.isBlank(path)) {
            return false;
        }

        // 网络驱动器根目录，如 Z:\
        if (path.matches("^[A-Za-z]:\\\\$")) {
            File drive = new File(path);
            try {
                // 尝试获取文件系统信息来判断是否为网络驱动器
                // 这是一个简单的判断方法
                if (!drive.exists()) {
                    return false;
                }

                // 可以通过文件系统的类型来判断，但Java API有限
                // 这里假设Z:通常是网络驱动器
                return path.startsWith("Z:") || path.startsWith("X:") ||
                        path.startsWith("Y:") || path.startsWith("W:");
            } catch (Exception e) {
                return false;
            }
        }

        return false;
    }
}
