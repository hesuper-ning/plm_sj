package ext.alphai.aistoneglobal.workflow;

import ext.alphai.aistoneglobal.workflow.util.FileUtils;
import ext.alphai.aistoneglobal.workflow.util.PropertiesUtil;
import ext.alphai.aistoneglobal.workflow.util.WorkflowUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.WTObject;
import wt.part.WTPart;

import java.util.ArrayList;
import java.util.List;

public class PartApprovalWF {
    public static String createFolder(WTObject primaryBusinessObject) {
        StringBuilder resultBuilder = new StringBuilder();
        ArrayList<WTPart> parts = WorkflowUtil.getTargetObject(primaryBusinessObject, "AffectedObjects", WTPart.class);

        if (parts == null || parts.isEmpty()) {
            return "错误：未找到关联的WTPart对象";
        }

        String shareFolder = PropertiesUtil.getValueByKey("plm.service.shareFolder");
        if (StringUtils.isBlank(shareFolder)) {
            return "错误：配置项'plm.service.shareFolder'未设置或为空";
        }

        List<String> failedParts = new ArrayList<>();

        for (WTPart part : parts) {
            String partNumber = part.getNumber();
//            if (StringUtils.isBlank(partNumber)) {
//                failedParts.add("部件编号为空");
//                continue;
//            }

            String folderResult = FileUtils.createFolderInParent(shareFolder, partNumber);
            if (!"success".equals(folderResult)) {
                failedParts.add(partNumber + " - " + folderResult);
            }
        }

        if (failedParts.isEmpty()) {
            return "success";
        } else {
            return "以下部件文件夹创建失败：" + String.join("; ", failedParts);
        }
    }




}
