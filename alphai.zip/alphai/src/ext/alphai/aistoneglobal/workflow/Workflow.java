package ext.alphai.aistoneglobal.workflow;

import ext.alphai.aistoneglobal.workflow.util.PropertiesUtil;
import ext.alphai.aistoneglobal.workflow.util.WorkflowUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.ObjectReference;
import wt.project.Role;
import wt.session.SessionHelper;
import wt.team.Team;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;

import java.util.Enumeration;

public class Workflow {
    /**
     * ext.cirpoint.mpm.workflow.WorkflowUtil.checkWorkflowHaveMembers(self, new String[]{"","",""})
     * ###############################    必填角色内码填入数组中
     * 校验所有角色都必须设置了参与者
     *
     * @param
     * @return </pre>
     */
    public static void checkWorkflowHaveMembers(ObjectReference self) throws WTException {
        StringBuffer sbf = new StringBuffer();
        WfProcess process = WorkflowUtil.getWfProcess(self);
        //获取当前活动名称
        String activityName = WorkflowUtil.getActivityName(self);
        //获取流程模板名称
        String processName = process.getTemplate().getName();
        System.out.println("流程模板名称" + processName);
        System.out.println("当前活动名称" + activityName);

        String roleInternal = PropertiesUtil.getValueByKey("校验." + processName + "." + activityName);
        if (StringUtils.isBlank(roleInternal)) {
            System.out.println("配置值为空，跳过检查");
            return;  // 直接返回，不执行后续逻辑
        }
        String[] roleInternals = roleInternal.split(",");
        for (String roleName : roleInternals) {
            System.out.println("roleName: " + roleName);
            Role role = Role.toRole(roleName);
            Team team = (Team) process.getTeamId().getObject();
            Enumeration mems = team.getPrincipalTarget(role);
            //对应角色下没有用户
            if (!mems.hasMoreElements()) {
                String roleDisplayName = role.getDisplay(SessionHelper.getLocale());
                if (StringUtils.isBlank(roleDisplayName)) {
                    roleDisplayName = roleName;
                }

                sbf.append(roleDisplayName + " 未设置参与者,请确认!").append("\r\n");
            }
        }

        if (sbf.length() > 0) {
            throw new WTException(sbf.toString());
        }

    }
}
