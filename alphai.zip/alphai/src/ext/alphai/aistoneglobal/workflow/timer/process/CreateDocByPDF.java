package ext.alphai.aistoneglobal.workflow.timer.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.workflow.timer.service.TimerService;
import wt.util.WTException;

import java.util.List;

public class CreateDocByPDF extends DefaultObjectFormProcessor {
    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {

        TimerService.processShareFolderPDFs();

        return super.doOperation(nmCommandBean, list);
    }



}
