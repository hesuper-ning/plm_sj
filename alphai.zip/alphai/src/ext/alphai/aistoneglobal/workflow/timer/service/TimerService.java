package ext.alphai.aistoneglobal.workflow.timer.service;

import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.windchill.enterprise.copy.server.CoreMetaUtility;
import ext.alphai.aistoneglobal.util.IBAUtil;
import ext.alphai.aistoneglobal.util.PartUtil;
import ext.alphai.aistoneglobal.workflow.util.NetworkFolderUtil;
import ext.alphai.aistoneglobal.workflow.util.PropertiesUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.content.*;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTValuedHashMap;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

public class TimerService {
    private static final Logger logger = LogManager.getLogger(TimerService.class);
    public static final String FOLDER_DEFAULT = "/Default";
    public static final String AI_ApprovalDocument = "AI_ApprovalDocument";

    /**
     * 处理网络共享文件夹中的PDF文档
     */
    public static void processShareFolderPDFs() {
        logger.info("====== 开始处理共享文件夹PDF文档 ======");

        try {
            // 获取共享文件夹路径
            String shareFolder = PropertiesUtil.getValueByKey("plm.service.shareFolder");
            if (shareFolder == null || shareFolder.trim().isEmpty()) {
                logger.error("❌ 共享文件夹路径配置为空，请检查配置项: plm.service.shareFolder");
                return;
            }

            logger.info("📁 扫描路径: {}", shareFolder);
            logger.info("⏳ 开始扫描文件夹...");

            // 调用处理逻辑
            getWTPartByShareFolder(shareFolder);

            logger.info("✅ 共享文件夹PDF文档处理完成");

        } catch (Exception e) {
            logger.error("❌ 处理共享文件夹PDF文档失败", e);
        } finally {
            logger.info("====== 共享文件夹PDF文档处理结束 ======");
        }
    }

    /**
     * 处理网络共享文件夹中的PDF文档
     */
    public static void getWTPartByShareFolder(String shareFolder) {
        logger.info("🔄 开始获取共享文件夹中的部件和PDF文件");

        // 获取所有子文件夹
        List<String> subFolderNames = NetworkFolderUtil.getSubFolders(shareFolder);
        logger.debug("扫描到子文件夹列表: {}", subFolderNames);

        if (subFolderNames == null || subFolderNames.isEmpty()) {
            logger.info("📭 共享文件夹中无子文件夹");
            return;
        }

        logger.info("📊 发现 {} 个子文件夹", subFolderNames.size());
        logger.info("----------------------------------------");

        int successCount = 0;
        int updateCount = 0;  // 新增：更新计数
        int skipCount = 0;
        int errorCount = 0;

        for (int i = 0; i < subFolderNames.size(); i++) {
            String subFolderName = subFolderNames.get(i);
            logger.info("📋 处理文件夹 [{}/{}]: {}", i + 1, subFolderNames.size(), subFolderName);

            try {
                // 1. 根据文件夹名称查找部件
                logger.debug("🔍 正在根据文件夹名称查找部件: {}", subFolderName);
                WTPart wtPart = PartUtil.getWTPartByNumber(subFolderName);
                if (wtPart == null) {
                    logger.warn("⚠️ 无对应部件，跳过: {}", subFolderName);
                    skipCount++;
                    continue;
                }
                logger.info("✅ 找到部件: {} [{}]", wtPart.getNumber(), wtPart.getName());

                // 2. 获取最新PDF文件
                logger.debug("📄 正在查找PDF文件: {}/{}", shareFolder, subFolderName);
                File latestPDF = NetworkFolderUtil.getLatestPDFInFolder(shareFolder, subFolderName);
                if (latestPDF == null) {
                    logger.warn("⚠️ 无PDF文件，跳过: {}", subFolderName);
                    skipCount++;
                    continue;
                }
                logger.info("✅ 找到PDF文件: {} (大小: {} KB)",
                        latestPDF.getName(),
                        latestPDF.length() / 1024);

                // 3. 创建或更新文档
                logger.debug("📝 开始创建/更新文档...");
                WTDocument wtDocument = createWTDocument(wtPart, latestPDF);

                if (wtDocument != null) {
                    if (isDocumentUpdated(wtDocument, subFolderName)) {  // 假设有个方法判断是更新还是创建
                        updateCount++;
                        logger.info("🔄 文档更新成功: {} -> {} [{}]",
                                subFolderName, wtDocument.getName(), wtDocument.getNumber());
                    } else {
                        successCount++;
                        logger.info("✅ 文档创建成功: {} -> {} [{}]",
                                subFolderName, wtDocument.getName(), wtDocument.getNumber());
                    }
                } else {
                    updateCount++;
                    logger.info("⏭️ 文档已存在，已更新内容: {}", subFolderName);
                }

                logger.info("----------------------------------------");

            } catch (Exception e) {
                errorCount++;
                logger.error("❌ 处理文件夹 [{}] 失败", subFolderName, e);
                logger.info("----------------------------------------");
            }
        }

        // 输出统计信息
        logger.info("📈 ======== 处理统计 ========");
        logger.info("📈 总文件夹数: {}", subFolderNames.size());
        logger.info("✅ 文档创建数: {}", successCount);
        logger.info("🔄 文档更新数: {}", updateCount);
        logger.info("⏭️ 跳过处理数: {}", skipCount);
        logger.info("❌ 处理失败数: {}", errorCount);
        logger.info("📈 ===========================");
    }

    /**
     * 判断文档是新创建还是更新（辅助方法）
     */
    private static boolean isDocumentUpdated(WTDocument document, String folderName) {
        // 这里可以根据实际业务逻辑判断
        // 例如：检查文档的创建时间是否接近当前时间
        return false; // 简化处理，假设都是创建
    }

    /**
     * 创建WTDocument（如果已存在则更新内容）
     */
    public static WTDocument createWTDocument(WTPart wtPart, File pdfFile) throws Exception {
        logger.debug("📄 开始创建/更新文档...");
        logger.debug("📌 部件信息: {} [{}]", wtPart.getNumber(), wtPart.getName());
        logger.debug("📌 PDF文件: {} ({})", pdfFile.getName(), pdfFile.getAbsolutePath());

        if (wtPart == null || pdfFile == null || !pdfFile.exists()) {
            logger.error("❌ 创建文档参数无效");
            return null;
        }

        // 从配置获取参数
        logger.debug("⚙️ 正在读取配置参数...");
        String docFolder = PropertiesUtil.getValueByKey("doc.folderPath");
        String docType = PropertiesUtil.getValueByKey("doc.type.AI_PartDocument");
        String partNumber = PropertiesUtil.getValueByKey("part.iba.PART_NUMBER");
        String AI_DocType = PropertiesUtil.getValueByKey("part.iba.AI_DocType");

        // 使用默认值
        if (docFolder == null || docFolder.trim().isEmpty()) {
            docFolder = "/Default/C00_物料文档";
            logger.debug("⚙️ 使用默认文档文件夹: {}", docFolder);
        }
        if (docType == null || docType.trim().isEmpty()) {
            docType = "com.aistoneglobal.AI_PartDocument";
            logger.debug("⚙️ 使用默认文档类型: {}", docType);
        }
        if (partNumber == null || partNumber.trim().isEmpty()) {
            partNumber = "PART_NUMBER";
            logger.debug("⚙️ 使用默认部件编号属性名: {}", partNumber);
        }
        if (AI_DocType == null || AI_DocType.trim().isEmpty()) {
            AI_DocType = "AI_DocType";
            logger.debug("⚙️ 使用默认文档类型属性名: {}", AI_DocType);
        }

        String docName = StringUtils.substringBeforeLast(pdfFile.getName(), ".");
        logger.info("📝 文档名称: {}", docName);
        logger.info("📝 文档类型: {}", docType);

        // 检查是否已存在同名同类型文档
        logger.debug("🔍 正在检查是否已存在同名文档...");
        WTDocument wtDocByNameAndType = getWTDocByNameAndType(docName, docType);

        String modifierName = wtPart.getModifierName();
        WTPrincipal currentUser = null;
        boolean accessEnforcedFlag = false;

        logger.debug("👤 当前操作用户: {}", modifierName);

        try {
            // 保存当前用户和权限设置
            currentUser = SessionHelper.manager.getPrincipal();
            logger.debug("👤 原始用户: {}", currentUser.getName());

            // 忽略权限并切换为部件的修改者
            logger.debug("🔓 正在关闭权限检查...");
            accessEnforcedFlag = SessionServerHelper.manager.setAccessEnforced(false);
            logger.debug("👤 正在切换用户: {} -> {}", currentUser.getName(), modifierName);
            SessionHelper.manager.setPrincipal(modifierName);
            logger.debug("✅ 用户切换完成，当前用户: {}", SessionHelper.manager.getPrincipal().getName());

            // 1. 检查是否已存在同名同类型文档
            if (wtDocByNameAndType != null) {
                logger.info("📄 文档已存在，开始更新内容: {} [{}]",
                        wtDocByNameAndType.getName(), wtDocByNameAndType.getNumber());

                // 获取当前主要内容
                logger.debug("📤 正在获取文档当前内容...");
                ContentHolder contentHolder = ContentHelper.service.getContents(wtDocByNameAndType);
                ContentItem contentitem = ContentHelper.getPrimary((FormatContentHolder) contentHolder);
                ApplicationData applicationdata = (ApplicationData) contentitem;

                if (applicationdata==null){
                    logger.debug("📤 没有找到主要内容application，新建application..");
                    applicationdata = ApplicationData.newApplicationData(wtDocByNameAndType);
                }

                logger.debug("📝 设置文档内容属性...");
                applicationdata.setRole(ContentRoleType.PRIMARY);
                applicationdata.setFileName(pdfFile.getName());

                logger.debug("🔄 正在更新文档内容...");
                try (InputStream ins = new FileInputStream(pdfFile)) {
                    logger.info("📤 上传文件内容: {}", pdfFile.getName());
                    applicationdata = ContentServerHelper.service.updateContent(wtDocByNameAndType, applicationdata, ins);
                    logger.info("✅ 文件内容更新完成");
                }

                // 刷新文档
                logger.debug("🔄 正在刷新文档...");
                wtDocByNameAndType = (WTDocument) PersistenceServerHelper.manager.restore(wtDocByNameAndType);

                // 关联部件与文档
                logger.debug("🔗 正在关联部件与文档...");
                addDocAndWTPartLink(wtDocByNameAndType, wtPart);

                // 删除源文件
                logger.debug("🗑️ 正在删除源文件...");
                boolean deleted = pdfFile.delete();
                if (deleted) {
                    logger.info("✅ PDF源文件已删除: {}", pdfFile.getAbsolutePath());
                } else {
                    logger.warn("⚠️ PDF源文件删除失败: {}", pdfFile.getAbsolutePath());
                }

                logger.info("🔄 文档内容更新完成: {} [{}]",
                        wtDocByNameAndType.getName(), wtDocByNameAndType.getNumber());
                return null; // 文档已存在，返回null表示是更新操作
            }
            else {
                logger.info("🆕 创建新文档: {}", docName);

                // 获取容器
                logger.debug("📦 正在获取部件容器...");
                WTContainer container = wtPart.getContainer();
                WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(container);
                logger.debug("✅ 容器获取完成: {}", container.getName());

                // 获取文件夹位置
                logger.debug("📁 正在获取文档文件夹位置: {}", docFolder);
                Folder location;
                try {
                    location = FolderHelper.service.getFolder(docFolder, wtContainerRef);
                    logger.debug("✅ 文件夹位置获取完成: {}", docFolder);
                } catch (WTException e) {
                    logger.warn("⚠️ 文件夹 {} 不存在，使用默认文件夹", docFolder);
                    location = FolderHelper.service.getFolder(FOLDER_DEFAULT, wtContainerRef);
                    logger.debug("✅ 使用默认文件夹: {}", FOLDER_DEFAULT);
                }

                // 创建新文档
                logger.debug("📝 正在创建文档对象...");
                WTDocument newDoc = WTDocument.newWTDocument();
                TypeIdentifier id = TypeIdentifierHelper.getTypeIdentifier(docType);
                newDoc = (WTDocument) CoreMetaUtility.setType(newDoc, id);
                newDoc.setName(docName);
                newDoc.setContainerReference(wtContainerRef);
                logger.debug("📝 文档基础信息设置完成");

                // 设置文件夹位置
                if (location != null) {
                    logger.debug("📁 正在设置文档文件夹位置...");
                    WTValuedHashMap map = new WTValuedHashMap();
                    map.put(newDoc, location);
                    FolderHelper.assignLocations(map);
                    logger.debug("✅ 文件夹位置设置完成");
                }

                // 保存文档
                logger.debug("💾 正在保存文档...");
                newDoc = (WTDocument) PersistenceHelper.manager.save(newDoc);
                logger.info("✅ 文档保存成功: {} [{}]", newDoc.getName(), newDoc.getNumber());

                // 上传PDF内容
                logger.debug("📤 正在创建内容对象...");
                ApplicationData applicationdata = ApplicationData.newApplicationData(newDoc);
                applicationdata.setRole(ContentRoleType.PRIMARY);
                applicationdata.setFileName(pdfFile.getName());

                logger.debug("📤 正在上传PDF内容...");
                try (InputStream ins = new FileInputStream(pdfFile)) {
                    logger.info("📤 上传文件内容: {}", pdfFile.getName());
                    applicationdata = ContentServerHelper.service.updateContent(newDoc, applicationdata, ins);
                    logger.info("✅ 文件内容上传完成");
                }

                // 刷新文档
                logger.debug("🔄 正在刷新文档...");
                newDoc = (WTDocument) PersistenceServerHelper.manager.restore(newDoc);

                // 设置IBA属性
                logger.debug("🏷️ 正在设置IBA属性...");
                IBAUtil docIBA = new IBAUtil(newDoc);
                docIBA.setIBAAttribute4AllType(newDoc, partNumber, wtPart.getNumber());
                logger.debug("✅ 设置部件编号属性: {} = {}", partNumber, wtPart.getNumber());

                docIBA.setIBAAttribute4AllType(newDoc, AI_DocType, AI_ApprovalDocument);
                logger.debug("✅ 设置文档类型属性: {} = {}", AI_DocType, AI_ApprovalDocument);

                // 删除源文件
                logger.debug("🗑️ 正在删除源文件...");
                boolean deleted = pdfFile.delete();
                if (deleted) {
                    logger.info("✅ PDF源文件已删除: {}", pdfFile.getAbsolutePath());
                } else {
                    logger.warn("⚠️ PDF源文件删除失败: {}", pdfFile.getAbsolutePath());
                }

                // 关联部件与新文档
                logger.debug("🔗 正在关联部件与新文档...");
                addDocAndWTPartLink(newDoc, wtPart);
                logger.info("✅ 部件与文档关联成功");

                logger.info("🎉 新文档创建完成: {} [{}]", newDoc.getName(), newDoc.getNumber());
                return newDoc;
            }
        } catch (Exception e) {
            logger.error("❌ 创建/更新文档失败: {}", docName, e);
            throw e;
        } finally {
            // 恢复原始用户和权限设置
            logger.debug("🔄 正在恢复原始用户会话...");
            try {
                SessionServerHelper.manager.setAccessEnforced(accessEnforcedFlag);
                if (currentUser != null) {
                    SessionHelper.manager.setPrincipal(currentUser.getName());
                    logger.debug("✅ 用户会话已恢复: {}", currentUser.getName());
                }
            } catch (Exception e) {
                logger.warn("⚠️ 恢复用户会话失败", e);
            }
            logger.debug("✅ 文档创建/更新流程结束");
        }
    }

    /**
     * 根据名称和类型查找文档
     */
    public static WTDocument getWTDocByNameAndType(String docName, String type) {
        logger.debug("🔍 正在查询文档: 名称={}, 类型={}", docName, type);

        if (docName == null || docName.trim().isEmpty() || type == null || type.trim().isEmpty()) {
            logger.warn("⚠️ 查询文档参数无效");
            return null;
        }

        WTDocument result = null;
        QueryResult qr = null;

        try {
            logger.debug("🔍 构建查询条件...");
            QuerySpec qs = new QuerySpec(WTDocument.class);
            SearchCondition scNumber = new SearchCondition(WTDocument.class, WTDocument.NAME,
                    SearchCondition.EQUAL, docName);
            qs.appendSearchCondition(scNumber);

            logger.debug("🔍 执行文档查询...");
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);

            int count = 0;
            while (qr1 != null && qr1.hasMoreElements()) {
                WTDocument doc = (WTDocument) qr1.nextElement();
                count++;
                String externalTypeIdentifier = TypedUtilityServiceHelper.service.getExternalTypeIdentifier(doc);
                logger.debug("🔍 检查文档 {} [{}], 类型: {}",
                        doc.getName(), doc.getNumber(), externalTypeIdentifier);

                if (externalTypeIdentifier != null && externalTypeIdentifier.contains(type)) {
                    result = doc;
                    logger.debug("✅ 找到匹配文档: {} [{}]", doc.getName(), doc.getNumber());
                    break;
                }
            }

            if (result == null) {
                logger.debug("📭 未找到匹配文档: 名称={}, 类型={}", docName, type);
            } else {
                logger.debug("✅ 文档查询完成，共检查 {} 个文档", count);
            }

        } catch (Exception e) {
            logger.error("❌ 查询文档失败: 名称={}, 类型={}", docName, type, e);
        } finally {
            // 清理资源
            if (qr != null) {
                try {

                    logger.debug("✅ 查询资源已释放");
                } catch (Exception e) {
                    logger.warn("⚠️ 关闭查询结果失败", e);
                }
            }
        }

        return result;
    }

    /**
     * 文档与部件关联
     *
     * @param document
     * @param wtPart
     * @throws WTException
     */
    public static void addDocAndWTPartLink(WTDocument document, WTPart wtPart) throws WTException {
        logger.debug("🔗 开始关联文档与部件...");
        logger.debug("📄 文档: {} [{}]", document.getName(), document.getNumber());
        logger.debug("🔩 部件: {} [{}]", wtPart.getNumber(), wtPart.getName());

        try {
            WTPartDescribeLink link = WTPartDescribeLink.newWTPartDescribeLink(wtPart, document);
            logger.debug("🔗 创建关联链接...");

            PersistenceServerHelper.manager.insert(link);
            logger.debug("✅ 关联链接插入完成");

            PersistenceHelper.manager.refresh(link);
            logger.debug("✅ 关联链接刷新完成");

            logger.info("✅ 文档与部件关联成功: {} <-> {}",
                    document.getNumber(), wtPart.getNumber());

        } catch (WTException e) {
            logger.error("❌ 关联文档和部件失败", e);
            throw e;
        }
    }

    /**
     * 定时任务执行入口
     */
    public static void executeTimerTask() {
        logger.info("⏰ ====== 定时任务开始执行 ======");
        long startTime = System.currentTimeMillis();

        try {
            processShareFolderPDFs();

            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;
            logger.info("✅ 定时任务执行完成，耗时: {} 秒", duration / 1000.0);

        } catch (Exception e) {
            logger.error("❌ 定时任务执行异常", e);
        } finally {
            logger.info("⏰ ====== 定时任务执行结束 ======");
        }
    }
}