package ext.alphai.aistoneglobal.exportModel.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.exportModel.service.ExportService;
import org.apache.poi.ss.usermodel.*;
import wt.inf.library.WTLibrary;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.org.WTPrincipalReference;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;
import wt.project.Role;
import wt.util.WTException;
import wt.util.WTProperties;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

public class ExportProcessor extends DefaultObjectFormProcessor {
    private ExportService exportService = new ExportService();

    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("导出团队模板");
        WTProperties wtProperties = null;
        try {
            wtProperties = WTProperties.getLocalProperties();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        // 根目录/excelModel/
        String property = wtProperties.getProperty("wt.home") + "\\codebase\\ext\\alphai\\excelModel" + File.separator;
        String sourcePath = property + "TeamModel.xlsx";
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        HttpServletResponse response = nmCommandBean.getResponse();

        // 支持 PDMLinkProduct、WTLibrary 和 Project 容器
        ContainerTeam team = null;
        String containerName = "";

        if (content instanceof PDMLinkProduct) {
            PDMLinkProduct prod = (PDMLinkProduct) content;
            System.out.println("产品名称: " + prod.getName());
            containerName = prod.getName();
            team = ContainerTeamHelper.service.getContainerTeam(prod);
        } else if (content instanceof WTLibrary) {
            WTLibrary library = (WTLibrary) content;
            System.out.println("库名称: " + library.getName());
            containerName = library.getName();
            team = ContainerTeamHelper.service.getContainerTeam(library);
        } else if (content instanceof Project2) {
            Project2 project = (Project2) content;
            System.out.println("项目名称: " + project.getName());
            containerName = project.getName();
            team = ContainerTeamHelper.service.getContainerTeam(project);
        }

        if (team != null) {
            try {
                Map<Role, List<Map<String, String>>> roleUserMap = new LinkedHashMap<>();
                Vector roles = team.getRoles();

                // 收集角色和用户数据
                for (Object roleObj : roles) {
                    Role role = (Role) roleObj;
                    ArrayList principals = team.getAllPrincipalsForTarget(role);

                    List<Map<String, String>> usersInRole = new ArrayList<>();

                    for (Object principalObj : principals) {
                        WTPrincipalReference principalReference = (WTPrincipalReference) principalObj;

                        Map<String, String> userInfo = new HashMap<>();
                        userInfo.put("userId", principalReference.getIdentity());
                        userInfo.put("userName", principalReference.getFullName() != null ? principalReference.getFullName() : "");

                        usersInRole.add(userInfo);
                    }

                    // 无论是否有用户，都添加到map中
                    roleUserMap.put(role, usersInRole);
                }

                // 读取模板并填充数据
                exportService.fillExcelTemplateWithStyle(sourcePath, response, containerName, roleUserMap);


                return null;
            } catch (Exception e) {
                throw new WTException(e, "导出团队数据失败: " + e.getMessage());
            }
        } else {
            throw new WTException("不支持的容器类型或无法获取团队信息");
        }


    }
}