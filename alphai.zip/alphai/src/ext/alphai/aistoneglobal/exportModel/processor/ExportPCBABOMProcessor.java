package ext.alphai.aistoneglobal.exportModel.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.exportModel.Constant;
import ext.alphai.aistoneglobal.exportModel.entity.PCBABOMRowData;
import ext.alphai.aistoneglobal.exportModel.service.ExportService;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.part.WTPart;
import wt.util.WTException;

import java.io.InputStream;
import java.util.List;

public class ExportPCBABOMProcessor extends DefaultObjectFormProcessor {
    private ExportService exportService = new ExportService();

    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("导出PCBA BOM模板");

        Workbook workbook = null;
        InputStream templateStream = null;

        try {
            // 1. 获取当前操作的WTPart对象
            NmOid primaryOid = nmCommandBean.getPrimaryOid();
            Object content = primaryOid.getRef();

            if (!(content instanceof WTPart)) {
                throw new WTException("请选择部件进行BOM导出");
            }

            WTPart wtPart = (WTPart) content;
            String partNumber = wtPart.getNumber();
            System.out.println("正在导出PCBA BOM，部件编号: " + partNumber);

            // 2. 获取BOM数据
            List<PCBABOMRowData> bomDataList = exportService.getPCBABOMData(wtPart);

            if (bomDataList == null || bomDataList.isEmpty()) {
                throw new WTException("该部件没有BOM数据");
            }

            // 3. 获取BOM模板文件流
            templateStream = exportService.getBomExcelModel(Constant.PCBA_BOM_EXCEL_MODEL);
            if (templateStream == null) {
                throw new WTException("获取BOM模板失败，请检查模板文件是否存在");
            }

            // 4. 检测文件格式并创建工作簿
            workbook = createWorkbookByFormat(templateStream);
            System.out.println("工作簿类型: " + workbook.getClass().getSimpleName());

            // 5. 获取第一个工作表
            Sheet sheet = workbook.getSheetAt(0);
            if (sheet == null) {
                throw new WTException("模板文件中没有工作表");
            }

            // 6. 获取模板中示例行的样式（从第4行获取，如果不存在则使用第3行的样式）
            Row sampleRow = sheet.getRow(3); // 第4行（索引3）
            if (sampleRow == null) {
                sampleRow = sheet.getRow(2); // 尝试获取第3行
            }

            // 7. 填充数据（从第2行开始，索引1）
            int currentRowIndex = 1; // 索引1对应Excel的第2行
            for (PCBABOMRowData rowData : bomDataList) {
                Row dataRow = getOrCreateRow(sheet, currentRowIndex);
                fillRowData(dataRow, rowData, sampleRow);
                currentRowIndex++;
            }

            // 8. 自动调整列宽（7列：第1列到第19列中的7个有数据的列）
            // 列索引对应关系：0->第1列(父项料号), 6->第7列(行号), 8->第9列(子项料号),
            // 11->第12列(损耗率), 16->第17列(位号), 17->第18列(使用数量), 18->第19列(安装面)
            int[] columnIndexes = {0, 6, 8,9,10, 11,12,13,14,15, 16, 17, 18}; // 对应的Excel列索引（从0开始）
            for (int colIndex : columnIndexes) {
                sheet.autoSizeColumn(colIndex);
                // 设置最小列宽，避免列宽过窄
                int currentWidth = sheet.getColumnWidth(colIndex);
                if (currentWidth < 3000) {
                    sheet.setColumnWidth(colIndex, 3000);
                } else if (currentWidth > 15000) {
                    // 设置最大列宽，避免列宽过宽
                    sheet.setColumnWidth(colIndex, 15000);
                }
            }

            // 9. 设置响应头（根据工作簿类型）
            HttpServletResponse response = nmCommandBean.getResponse();
            String fileName = "PCBA_BOM_" + partNumber;

            if (workbook instanceof XSSFWorkbook) {
                fileName += ".xlsx";
                response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            } else if (workbook instanceof HSSFWorkbook) {
                fileName += ".xls";
                response.setContentType("application/vnd.ms-excel");
            } else {
                throw new WTException("不支持的Excel文件格式");
            }

            // 处理文件名中的特殊字符（中文、空格等）
            String encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8")
                    .replaceAll("\\+", "%20");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + encodedFileName + "\"");
            response.setHeader("Content-Transfer-Encoding", "binary");
            response.setHeader("Cache-Control", "no-cache");
            response.setHeader("Pragma", "no-cache");

            // 10. 输出Excel文件
            ServletOutputStream outputStream = response.getOutputStream();
            workbook.write(outputStream);
            outputStream.flush();

            System.out.println("PCBA BOM导出成功，共导出 " + bomDataList.size() + " 条记录，文件名: " + fileName);

        } catch (Exception e) {
            System.err.println("导出PCBA BOM失败: " + e.getMessage());
            e.printStackTrace();
            throw new WTException("导出PCBA BOM失败: " + e.getMessage());
        } finally {
            // 关闭资源
            try {
                if (workbook != null) {
                    workbook.close();
                }
                if (templateStream != null) {
                    templateStream.close();
                }
            } catch (Exception e) {
                System.err.println("关闭资源失败: " + e.getMessage());
            }
        }

        return null;
    }

    /**
     * 根据文件格式创建工作簿
     */
    private Workbook createWorkbookByFormat(InputStream inputStream) throws Exception {
        // 标记流位置
        if (!inputStream.markSupported()) {
            // 如果流不支持标记，直接使用WorkbookFactory
            return WorkbookFactory.create(inputStream);
        }

        // 标记当前位置
        inputStream.mark(8);

        // 读取文件头来判断格式
        byte[] header = new byte[8];
        int bytesRead = inputStream.read(header);

        // 重置流位置
        inputStream.reset();

        // 检查文件头
        // .xlsx 文件是 ZIP 格式，文件头为 PK (0x50 0x4B)
        // .xls 文件是 OLE2 格式，文件头为 D0 CF 11 E0
        boolean isXlsx = (bytesRead >= 2 && header[0] == 0x50 && header[1] == 0x4B);
        boolean isXls = (bytesRead >= 4 && header[0] == (byte) 0xD0 && header[1] == (byte) 0xCF &&
                header[2] == (byte) 0x11 && header[3] == (byte) 0xE0);

        if (isXlsx) {
            System.out.println("检测到XLSX格式文件");
            return new XSSFWorkbook(inputStream);
        } else if (isXls) {
            System.out.println("检测到XLS格式文件");
            return new HSSFWorkbook(inputStream);
        } else {
            // 默认使用WorkbookFactory尝试解析
            System.out.println("无法检测文件格式，尝试使用WorkbookFactory解析");
            return WorkbookFactory.create(inputStream);
        }
    }

    /**
     * 创建或获取行
     */
    private Row getOrCreateRow(Sheet sheet, int rowIndex) {
        Row row = sheet.getRow(rowIndex);
        if (row == null) {
            row = sheet.createRow(rowIndex);
        }
        return row;
    }

    /**
     * 创建或获取单元格，并复制样式
     */
    private Cell getOrCreateCellWithStyle(Row row, int cellIndex, Row sampleRow) {
        Cell cell = row.getCell(cellIndex);
        if (cell == null) {
            cell = row.createCell(cellIndex);

            // 从示例行复制样式
            if (sampleRow != null) {
                Cell sampleCell = sampleRow.getCell(cellIndex);
                if (sampleCell != null) {
                    CellStyle sampleStyle = sampleCell.getCellStyle();
                    if (sampleStyle != null) {
                        cell.setCellStyle(sampleStyle);
                    }
                }
            }
        }
        return cell;
    }

    /**
     * 填充数据行
     * 列对应关系（基于PCBABOMRowData实体类的注释）：
     * 0: 父项料号 (第1列)
     * 6: 行号 (第7列)
     * 8: 子项料号 (第9列)
     * 9: 子项描述 (第10列)
     * 10: 基本用量 (第11列)
     * 11: 损耗率 (第12列)
     * 12: 替代项目群组 (第13列)
     * 13: 优先级 (第14列)
     * 14: 策略 (第15列)
     * 15: 使用率 (第16列)
     * 16: 位号 (第17列)
     * 17: 使用数量 (第18列)
     * 18: 安装面 (第19列)
     */
    private void fillRowData(Row row, PCBABOMRowData rowData, Row sampleRow) {
        // 父项料号 (第1列, 索引0)
        Cell parentCell = getOrCreateCellWithStyle(row, 0, sampleRow);
        parentCell.setCellValue(rowData.parentNumber != null ? rowData.parentNumber : "");

        // 行号 (第7列, 索引6)
        Cell lineNumberCell = getOrCreateCellWithStyle(row, 6, sampleRow);
        lineNumberCell.setCellValue(rowData.lineNumber != null ? rowData.lineNumber : "");

        // 子项料号 (第9列, 索引8)
        Cell childCell = getOrCreateCellWithStyle(row, 8, sampleRow);
        childCell.setCellValue(rowData.childNumber != null ? rowData.childNumber : "");

        // 子项描述 (第10列, 索引9)
        Cell childNameCell = getOrCreateCellWithStyle(row, 9, sampleRow);
        childNameCell.setCellValue(rowData.childName != null ? rowData.childName : "");

        // 基本用量 (第11列, 索引10)
        Cell baseNumCell = getOrCreateCellWithStyle(row, 10, sampleRow);
        if (rowData.baseNum != null && !rowData.baseNum.isEmpty()) {
            try {
                double baseNum = Double.parseDouble(rowData.baseNum);
                baseNumCell.setCellValue(baseNum);
            } catch (NumberFormatException e) {
                baseNumCell.setCellValue(rowData.baseNum);
            }
        } else {
            baseNumCell.setCellValue("");
        }

        // 损耗率 (第12列, 索引11)
        Cell lossRateCell = getOrCreateCellWithStyle(row, 11, sampleRow);
        lossRateCell.setCellValue(rowData.lossRate != null ? rowData.lossRate : "");

        // 替代项目群组 (第13列, 索引12)
        Cell groupNumCell = getOrCreateCellWithStyle(row, 12, sampleRow);
        groupNumCell.setCellValue(rowData.groupNum != null ? rowData.groupNum : "");

        // 优先级 (第14列, 索引13)
        Cell priorityCell = getOrCreateCellWithStyle(row, 13, sampleRow);
        priorityCell.setCellValue(rowData.priority != null ? rowData.priority : "");

        // 策略 (第15列, 索引14)
        Cell strategyCell = getOrCreateCellWithStyle(row, 14, sampleRow);
        strategyCell.setCellValue(rowData.strategy != null ? rowData.strategy : "");

        // 使用率 (第16列, 索引15)
        Cell usageProbCell = getOrCreateCellWithStyle(row, 15, sampleRow);
        if (rowData.usageProb != null && !rowData.usageProb.isEmpty()) {
            try {
                double usageProb = Double.parseDouble(rowData.usageProb);
                usageProbCell.setCellValue(usageProb);
            } catch (NumberFormatException e) {
                usageProbCell.setCellValue(rowData.usageProb);
            }
        } else {
            usageProbCell.setCellValue("");
        }

        // 位号 (第17列, 索引16)
        Cell occurrenceCell = getOrCreateCellWithStyle(row, 16, sampleRow);
        occurrenceCell.setCellValue(rowData.occurrence != null ? rowData.occurrence : "");

        // 使用数量 (第18列, 索引17)
        Cell quantityCell = getOrCreateCellWithStyle(row, 17, sampleRow);
        if (rowData.quantity != null) {
            try {
                double quantity = Double.parseDouble(rowData.quantity);
                quantityCell.setCellValue(quantity);
            } catch (NumberFormatException e) {
                quantityCell.setCellValue(rowData.quantity);
            }
        } else {
            quantityCell.setCellValue("");
        }

        // 安装面 (第19列, 索引18)
        Cell placementSideCell = getOrCreateCellWithStyle(row, 18, sampleRow);
        placementSideCell.setCellValue(rowData.placementSide != null ? rowData.placementSide : "");
    }
}