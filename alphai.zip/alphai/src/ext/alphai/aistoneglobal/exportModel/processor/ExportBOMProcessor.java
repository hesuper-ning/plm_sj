package ext.alphai.aistoneglobal.exportModel.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.exportModel.Constant;
import ext.alphai.aistoneglobal.exportModel.entity.BOMRowData;
import ext.alphai.aistoneglobal.exportModel.service.ExportService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.part.WTPart;
import wt.util.WTException;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.List;

public class ExportBOMProcessor extends DefaultObjectFormProcessor {
    private ExportService exportService = new ExportService();

    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("导出BOM模板");


        Workbook workbook = null;
        InputStream templateStream = null;

        try {
            // 1. 获取当前操作的WTPart对象
            NmOid primaryOid = nmCommandBean.getPrimaryOid();
            HttpServletRequest request = nmCommandBean.getRequest();
            Object content = primaryOid.getRef();

            if (!(content instanceof WTPart)) {
                throw new WTException("请选择部件进行BOM导出");
            }

            WTPart wtPart = (WTPart) content;
            String partNumber = wtPart.getNumber();
            System.out.println("正在导出BOM，部件编号: " + partNumber);

            // 2. 获取BOM数据
            List<BOMRowData> bomDataList = exportService.getBOMData(wtPart);

            if (bomDataList == null || bomDataList.isEmpty()) {
                throw new WTException("该部件没有BOM数据");
            }

            // 3. 获取BOM模板文件流
            templateStream = exportService.getBomExcelModel(Constant.BOM_EXCEL_MODEL);
            if (templateStream == null) {
                throw new WTException("获取BOM模板失败，请检查模板文件是否存在");
            }

            // 4. 检测文件格式并创建工作簿
            workbook = createWorkbookByFormat(templateStream);
            System.out.println("工作簿类型: " + workbook.getClass().getSimpleName());

            // 5. 获取第一个工作表
            Sheet sheet = workbook.getSheetAt(0);
            if (sheet == null) {
                throw new WTException("模板文件中没有工作表");
            }

            // 6. 清空模板中可能存在的示例数据（从第4行开始，索引3）
            clearDataRows(sheet, 3); // 从第4行开始清空

            // 7. 创建样式
            CellStyle dataStyle = createDataStyle(workbook);
            CellStyle centeredStyle = createCenteredStyle(workbook);

            // 8. 填充数据（从第4行开始，索引3）
            int currentRowIndex = 3; // 索引3对应Excel的第4行
            for (BOMRowData rowData : bomDataList) {
                Row dataRow = getOrCreateRow(sheet, currentRowIndex);
                fillRowData(dataRow, rowData, dataStyle, centeredStyle);
                currentRowIndex++;
            }

            // 9. 自动调整列宽（7列：序号、父项料号、子项料号、使用数量、新行号、替代料、优先级）
            for (int i = 0; i < 7; i++) {
                sheet.autoSizeColumn(i);
                // 设置最小列宽，避免列宽过窄
                int currentWidth = sheet.getColumnWidth(i);
                if (currentWidth < 3000) {
                    sheet.setColumnWidth(i, 3000);
                } else if (currentWidth > 15000) {
                    // 设置最大列宽，避免列宽过宽
                    sheet.setColumnWidth(i, 15000);
                }
            }

            // 10. 设置响应头（根据工作簿类型）
            HttpServletResponse response = nmCommandBean.getResponse();
            String fileName = "BOM_" + partNumber;

            if (workbook instanceof XSSFWorkbook) {
                fileName += ".xlsx";
                response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            } else if (workbook instanceof HSSFWorkbook) {
                fileName += ".xls";
                response.setContentType("application/vnd.ms-excel");
            } else {
                throw new WTException("不支持的Excel文件格式");
            }

            // 处理文件名中的特殊字符（中文、空格等）
            String encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8")
                    .replaceAll("\\+", "%20");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + encodedFileName + "\"");
            response.setHeader("Content-Transfer-Encoding", "binary");
            response.setHeader("Cache-Control", "no-cache");
            response.setHeader("Pragma", "no-cache");

            // 11. 输出Excel文件
            ServletOutputStream outputStream = response.getOutputStream();
            workbook.write(outputStream);
            outputStream.flush();

            System.out.println("BOM导出成功，共导出 " + bomDataList.size() + " 条记录，文件名: " + fileName);

        } catch (Exception e) {
            System.err.println("导出BOM失败: " + e.getMessage());
            e.printStackTrace();
            throw new WTException("导出BOM失败: " + e.getMessage());
        } finally {
            // 关闭资源
            try {
                if (workbook != null) {
                    workbook.close();
                }
                if (templateStream != null) {
                    templateStream.close();
                }
            } catch (Exception e) {
                System.err.println("关闭资源失败: " + e.getMessage());
            }
        }

        return null;
    }

    /**
     * 根据文件格式创建工作簿
     */
    private Workbook createWorkbookByFormat(InputStream inputStream) throws Exception {
        // 标记流位置
        if (!inputStream.markSupported()) {
            // 如果流不支持标记，直接使用WorkbookFactory
            return WorkbookFactory.create(inputStream);
        }

        // 标记当前位置
        inputStream.mark(8);

        // 读取文件头来判断格式
        byte[] header = new byte[8];
        int bytesRead = inputStream.read(header);

        // 重置流位置
        inputStream.reset();

        // 检查文件头
        // .xlsx 文件是 ZIP 格式，文件头为 PK (0x50 0x4B)
        // .xls 文件是 OLE2 格式，文件头为 D0 CF 11 E0
        boolean isXlsx = (bytesRead >= 2 && header[0] == 0x50 && header[1] == 0x4B);
        boolean isXls = (bytesRead >= 4 && header[0] == (byte) 0xD0 && header[1] == (byte) 0xCF &&
                header[2] == (byte) 0x11 && header[3] == (byte) 0xE0);

        if (isXlsx) {
            System.out.println("检测到XLSX格式文件");
            return new XSSFWorkbook(inputStream);
        } else if (isXls) {
            System.out.println("检测到XLS格式文件");
            return new HSSFWorkbook(inputStream);
        } else {
            // 默认使用WorkbookFactory尝试解析
            System.out.println("无法检测文件格式，尝试使用WorkbookFactory解析");
            return WorkbookFactory.create(inputStream);
        }
    }

    /**
     * 清空数据行（从指定行开始删除所有行）
     */
    private void clearDataRows(Sheet sheet, int startRowIndex) {
        int lastRowNum = sheet.getLastRowNum();

        // 从后往前删除，避免索引变化
        for (int i = lastRowNum; i >= startRowIndex; i--) {
            Row row = sheet.getRow(i);
            if (row != null) {
                sheet.removeRow(row);
            }
        }

        System.out.println("已清空从第" + (startRowIndex + 1) + "行开始的数据");
    }

    /**
     * 创建或获取行
     */
    private Row getOrCreateRow(Sheet sheet, int rowIndex) {
        Row row = sheet.getRow(rowIndex);
        if (row == null) {
            row = sheet.createRow(rowIndex);
        }
        return row;
    }

    /**
     * 创建或获取单元格
     */
    private Cell getOrCreateCell(Row row, int cellIndex) {
        Cell cell = row.getCell(cellIndex);
        if (cell == null) {
            cell = row.createCell(cellIndex);
        }
        return cell;
    }

    /**
     * 填充数据行
     * 列对应关系：
     * 0: 序号
     * 1: 父项料号
     * 2: 父料名称（新增）
     * 3: 子项料号
     * 4: 子料名（新增）
     * 5: 使用数量
     * 6: 新行号
     * 7: 替代料
     * 8: 替代料名（新增）
     * 9: 优先级
     */
    private void fillRowData(Row row, BOMRowData rowData, CellStyle dataStyle, CellStyle centeredStyle) {
        // 序号（居中显示）
        Cell serialCell = getOrCreateCell(row, 0);
        serialCell.setCellValue(rowData.rowNum);
        serialCell.setCellStyle(centeredStyle);

        // 父项料号
        Cell parentCell = getOrCreateCell(row, 1);
        parentCell.setCellValue(rowData.parentNumber != null ? rowData.parentNumber : "");
        parentCell.setCellStyle(dataStyle);

        // 父料名称（新增）
        Cell parentNameCell = getOrCreateCell(row, 2);
        parentNameCell.setCellValue(rowData.parentName != null ? rowData.parentName : "");
        parentNameCell.setCellStyle(dataStyle);

        // 子项料号
        Cell childCell = getOrCreateCell(row, 3);
        childCell.setCellValue(rowData.childNumber != null ? rowData.childNumber : "");
        childCell.setCellStyle(dataStyle);

        // 子料名（新增）
        Cell childNameCell = getOrCreateCell(row, 4);
        childNameCell.setCellValue(rowData.childName != null ? rowData.childName : "");
        childNameCell.setCellStyle(dataStyle);

        // 使用数量
        Cell quantityCell = getOrCreateCell(row, 5);
        if (rowData.quantity != null) {
            try {
                double quantity = Double.parseDouble(rowData.quantity);
                quantityCell.setCellValue(quantity);
            } catch (NumberFormatException e) {
                quantityCell.setCellValue(rowData.quantity);
            }
        } else {
            quantityCell.setCellValue("");
        }
        quantityCell.setCellStyle(centeredStyle);

        // 新行号
        Cell lineNumberCell = getOrCreateCell(row, 6);
        lineNumberCell.setCellValue(rowData.lineNumber != null ? rowData.lineNumber : "");
        lineNumberCell.setCellStyle(centeredStyle);

        // 替代料
        Cell substituteCell = getOrCreateCell(row, 7);
        substituteCell.setCellValue(rowData.substituteNumber != null ? rowData.substituteNumber : "");
        substituteCell.setCellStyle(dataStyle);

        // 替代料名（新增）
        Cell substituteNameCell = getOrCreateCell(row, 8);
        substituteNameCell.setCellValue(rowData.substituteName != null ? rowData.substituteName : "");
        substituteNameCell.setCellStyle(dataStyle);

        // 优先级
        Cell priorityCell = getOrCreateCell(row, 9);
        priorityCell.setCellValue(rowData.priority != null ? rowData.priority : "");
        priorityCell.setCellStyle(centeredStyle);
    }

    /**
     * 创建数据样式（左对齐，带边框）
     */
    private CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);

        // 设置字体
        Font font = workbook.createFont();
        font.setFontName("宋体");
        font.setFontHeightInPoints((short) 11);
        style.setFont(font);

        return style;
    }

    /**
     * 创建居中样式（带边框）
     */
    private CellStyle createCenteredStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);

        // 设置字体
        Font font = workbook.createFont();
        font.setFontName("宋体");
        font.setFontHeightInPoints((short) 11);
        style.setFont(font);

        return style;
    }
}