package ext.alphai.aistoneglobal.exportModel;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.exportModel.ExportModelRB")
public class ExportModelRB extends WTListResourceBundle {

    @RBEntry("Export Team Model")
    public static final String E_T_M_TITLE = "excelModel.exportTeam.title";

    @RBEntry("Export Team Model")
    public static final String E_T_M_TOOLTIP = "excelModel.exportTeam.tooltip";

    @RBEntry("Export Team Model")
    public static final String E_T_M_DES = "excelModel.exportTeam.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String E_T_M_ICON = "excelModel.exportTeam.icon";


    @RBEntry("Import Team Model")
    public static final String I_T_M_TITLE = "excelModel.importTeam.title";

    @RBEntry("Import Team Model")
    public static final String I_T_M_TOOLTIP = "excelModel.importTeam.tooltip";

    @RBEntry("Import Team Model")
    public static final String I_T_M_DES = "excelModel.importTeam.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String I_T_M_ICON = "excelModel.importTeam.icon";

    @RBEntry("Import BOM")
    public static final String I_T_B_TITLE = "excelModel.importBOM.title";

    @RBEntry("Import BOM")
    public static final String I_T_B_TOOLTIP = "excelModel.importBOM.tooltip";

    @RBEntry("Import BOM")
    public static final String I_T_B_DES = "excelModel.importBOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String I_T_B_ICON = "excelModel.importBOM.icon";


    @RBEntry("Import PCBA BOM")
    public static final String I_T_PB_TITLE = "excelModel.importPCBABOM.title";

    @RBEntry("Import PCBA BOM")
    public static final String I_T_PB_TOOLTIP = "excelModel.importPCBABOM.tooltip";

    @RBEntry("Import PCBA BOM")
    public static final String I_T_PB_DES = "excelModel.importPCBABOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String I_T_PB_ICON = "excelModel.importPCBABOM.icon";


    @RBEntry("Import SubPart")
    public static final String I_T_S_TITLE = "excelModel.importSubPart.title";

    @RBEntry("Import SubPart")
    public static final String I_T_S_TOOLTIP = "excelModel.importSubPart.tooltip";

    @RBEntry("Import SubPart")
    public static final String I_T_S_DES = "excelModel.importSubPart.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String I_T_S_ICON = "excelModel.importSubPart.icon";



    @RBEntry("Export BOM")
    public static final String Export_BOM_TITLE = "excelModel.exportBOM.title";

    @RBEntry("Export BOM")
    public static final String Export_BOM_TOOLTIP = "excelModel.exportBOM.tooltip";

    @RBEntry("Export BOM")
    public static final String Export_BOM_DES = "excelModel.exportBOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String Export_BOM_ICON = "excelModel.exportBOM.icon";


    @RBEntry("Export PCBA BOM")
    public static final String Export_PCBA_BOM_TITLE = "excelModel.exportPCBABOM.title";

    @RBEntry("Export PCBA BOM")
    public static final String Export_PCBA_BOM_TOOLTIP = "excelModel.exportPCBABOM.tooltip";

    @RBEntry("Export PCBA BOM")
    public static final String Export_PCBA_BOM_DES = "excelModel.exportPCBABOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String Export_PCBA_BOM_ICON = "excelModel.exportPCBABOM.icon";
}
