package ext.alphai.aistoneglobal.exportModel;

public class Constant {

    public static final String AI_PROJECT_NAME = "AI_PROJECT_NAME";

    public static final String AI_CLSNODE = "AI_CLSNODE";

    public static final String AI_Placement_Side="AI_Placement_Side";

    public static final String AI_Priority="AI_Priority";

    public static final String AI_LineNumber="AI_LineNumber";

    public static final String AI_LossRate="AI_LossRate";

    public static final String ASY_PART="com.aistoneglobal.AI_ASMParts";

    public static final String BOM_EXCEL_MODEL = "BOM_EXCEL_MODEL";
    public static final String PCBA_BOM_EXCEL_MODEL = "PCBA_BOM_EXCEL_MODEL";


}
