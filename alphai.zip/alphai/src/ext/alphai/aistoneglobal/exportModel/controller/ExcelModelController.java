package ext.alphai.aistoneglobal.exportModel.controller;

import ext.alphai.aistoneglobal.exportModel.service.ExportService;
import ext.alphai.aistoneglobal.exportModel.vo.ResponseVo;
import org.apache.commons.fileupload2.core.DiskFileItemFactory;
import org.apache.commons.fileupload2.core.FileItem;
import org.apache.commons.fileupload2.core.FileUploadException;
import org.apache.commons.fileupload2.jakarta.servlet6.JakartaServletFileUpload;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/excel")
public class ExcelModelController {

    private ExportService exportService = new ExportService();

    /**
     * Excel文件上传接口 - 使用HttpServletRequest获取文件
     */
    @PostMapping("/import")
    public ResponseVo importExcel(HttpServletRequest request) {
        System.out.println("=== 后端开始处理文件上传请求 ===");

        String oid = null;
        FileItem excelFileItem = null;

        try {
            // 检查是否是multipart请求
            boolean isMultipart = JakartaServletFileUpload.isMultipartContent(request);
            System.out.println("是否是multipart请求: " + isMultipart);

            if (!isMultipart) {
                System.out.println("错误: 请求不是multipart类型");
                return ResponseVo.error(400, "请求类型错误，必须是multipart/form-data");
            }

            System.out.println("=== 开始解析multipart请求 ===");

            // 创建文件上传处理器 - 新版API使用builder模式
            // 修正：移除 setFileItemThreshold 方法，只使用 setBufferSize
            DiskFileItemFactory factory = DiskFileItemFactory.builder()
                    .setBufferSize(1024 * 1024) // 1MB内存缓冲区
                    .get();

            JakartaServletFileUpload upload = new JakartaServletFileUpload(factory);
            upload.setFileSizeMax(10 * 1024 * 1024); // 10MB，单个文件最大
            upload.setSizeMax(20 * 1024 * 1024); // 20MB，整个请求最大

            try {
                // 解析请求
                List<FileItem> items = upload.parseRequest(request);
                System.out.println("解析到的FileItem数量: " + items.size());

                for (FileItem item : items) {
                    if (item.isFormField()) {
                        // 普通表单字段
                        String fieldName = item.getFieldName();
                        String fieldValue = item.getString();
                        System.out.println("表单字段: " + fieldName + " = " + fieldValue);

                        if ("oid".equals(fieldName)) {
                            oid = fieldValue;
                        }
                    } else {
                        // 文件字段
                        String fieldName = item.getFieldName();
                        String fileName = item.getName();
                        long fileSize = item.getSize();
                        String contentType = item.getContentType();

                        System.out.println("文件字段: " + fieldName);
                        System.out.println("  文件名: " + fileName);
                        System.out.println("  文件大小: " + fileSize + " bytes");
                        System.out.println("  文件类型: " + contentType);

                        if ("excelFile".equals(fieldName)) {
                            excelFileItem = item;
                            System.out.println("成功获取excelFile文件");
                        }
                    }
                }

            } catch (FileUploadException e) {
                System.out.println("文件上传解析异常: " + e.getMessage());
                return ResponseVo.error(400, "文件上传解析失败: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("文件处理异常: " + e.getMessage());
                e.printStackTrace();
                return ResponseVo.error(500, "文件处理失败: " + e.getMessage());
            }

            System.out.println("=== 参数验证 ===");
            System.out.println("OID: " + oid);
            System.out.println("文件: " + (excelFileItem != null ? excelFileItem.getName() : "null"));

            // 参数验证
            if (oid == null || oid.trim().isEmpty()) {
                System.out.println("错误: OID参数为空");
                return ResponseVo.error(400, "产品OID不能为空");
            }

            if (excelFileItem == null) {
                System.out.println("错误: 文件参数为null");
                return ResponseVo.error(400, "请选择要上传的Excel文件");
            }

            if (excelFileItem.getSize() == 0) {
                System.out.println("错误: 文件为空");
                return ResponseVo.error(400, "上传的文件为空");
            }

            // 检查文件类型
            String originalFilename = excelFileItem.getName();
            if (originalFilename == null || !originalFilename.toLowerCase().endsWith(".xlsx")) {
                System.out.println("错误: 文件类型不支持: " + originalFilename);
                return ResponseVo.error(400, "只支持.xlsx格式的Excel文件");
            }

            System.out.println("=== 所有参数验证通过，开始处理业务逻辑 ===");

            // 注意：这里需要根据新版的FileItem调整ExportService中的方法
            // 新版FileItem的API可能有所不同
            String importResult = exportService.processImport(oid, excelFileItem);

            System.out.println("=== 导入完成 ===");
            System.out.println("导入结果: " + importResult);
            return ResponseVo.success(200, importResult);

        } catch (Exception e) {
            System.out.println("=== 发生异常 ===");
            e.printStackTrace();
            return ResponseVo.error(500, "导入失败: " + e.getMessage());
        } finally {
            System.out.println("=== 请求处理结束 ===\n");
        }
    }


    /**
     * Excel文件上传生成BOM
     */
    @PostMapping("/checkBOM")
    public ResponseVo checkBOM(HttpServletRequest request) {
        System.out.println("=== 后端开始处理文件上传请求 ===");

        String oid = null;
        FileItem excelFileItem = null;

        try {
            // 检查是否是multipart请求
            boolean isMultipart = JakartaServletFileUpload.isMultipartContent(request);
            System.out.println("是否是multipart请求: " + isMultipart);

            if (!isMultipart) {
                System.out.println("错误: 请求不是multipart类型");
                return ResponseVo.error(400, "请求类型错误，必须是multipart/form-data");
            }

            System.out.println("=== 开始解析multipart请求 ===");

            // 创建文件上传处理器 - 新版API使用builder模式
            // 修正：移除 setFileItemThreshold 方法，只使用 setBufferSize
            DiskFileItemFactory factory = DiskFileItemFactory.builder()
                    .setBufferSize(1024 * 1024) // 1MB内存缓冲区
                    .get();

            JakartaServletFileUpload upload = new JakartaServletFileUpload(factory);
            upload.setFileSizeMax(10 * 1024 * 1024); // 10MB，单个文件最大
            upload.setSizeMax(20 * 1024 * 1024); // 20MB，整个请求最大

            try {
                // 解析请求
                List<FileItem> items = upload.parseRequest(request);
                System.out.println("解析到的FileItem数量: " + items.size());

                for (FileItem item : items) {
                    if (item.isFormField()) {
                        // 普通表单字段
                        String fieldName = item.getFieldName();
                        String fieldValue = item.getString();
                        System.out.println("表单字段: " + fieldName + " = " + fieldValue);

                        if ("oid".equals(fieldName)) {
                            oid = fieldValue;
                        }
                    } else {
                        // 文件字段
                        String fieldName = item.getFieldName();
                        String fileName = item.getName();
                        long fileSize = item.getSize();
                        String contentType = item.getContentType();

                        System.out.println("文件字段: " + fieldName);
                        System.out.println("  文件名: " + fileName);
                        System.out.println("  文件大小: " + fileSize + " bytes");
                        System.out.println("  文件类型: " + contentType);

                        if ("excelFile".equals(fieldName)) {
                            excelFileItem = item;
                            System.out.println("成功获取excelFile文件");
                        }
                    }
                }

            } catch (FileUploadException e) {
                System.out.println("文件上传解析异常: " + e.getMessage());
                return ResponseVo.error(400, "文件上传解析失败: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("文件处理异常: " + e.getMessage());
                e.printStackTrace();
                return ResponseVo.error(500, "文件处理失败: " + e.getMessage());
            }

            System.out.println("=== 参数验证 ===");
            System.out.println("OID: " + oid);
            System.out.println("文件: " + (excelFileItem != null ? excelFileItem.getName() : "null"));

            // 参数验证
            if (oid == null || oid.trim().isEmpty()) {
                System.out.println("错误: OID参数为空");
                return ResponseVo.error(400, "产品OID不能为空");
            }

            if (excelFileItem == null) {
                System.out.println("错误: 文件参数为null");
                return ResponseVo.error(400, "请选择要上传的Excel文件");
            }

            if (excelFileItem.getSize() == 0) {
                System.out.println("错误: 文件为空");
                return ResponseVo.error(400, "上传的文件为空");
            }

            // 检查文件类型
            String originalFilename = excelFileItem.getName();
            if (originalFilename == null || !originalFilename.toLowerCase().endsWith(".xlsx")) {
                System.out.println("错误: 文件类型不支持: " + originalFilename);
                return ResponseVo.error(400, "只支持.xlsx格式的Excel文件");
            }

            System.out.println("=== 所有参数验证通过，开始处理业务逻辑 ===");

            // 注意：这里需要根据新版的FileItem调整ExportService中的方法
            // 新版FileItem的API可能有所不同
            String importResult = exportService.checkBOM(excelFileItem);

            System.out.println("=== 导入完成 ===");
            System.out.println("导入结果: " + importResult);
            return ResponseVo.success(200, importResult);

        } catch (Exception e) {
            System.out.println("=== 发生异常 ===");
            e.printStackTrace();
            return ResponseVo.error(500, "导入失败: " + e.getMessage());
        } finally {
            System.out.println("=== 请求处理结束 ===\n");
        }
    }

    /**
     * Excel文件上传生成BOM
     */
    @PostMapping("/createBOM")
    public ResponseVo createBOM(HttpServletRequest request) {
        System.out.println("=== 后端开始处理文件上传请求 ===");

        String oid = null;
        FileItem excelFileItem = null;

        try {
            // 检查是否是multipart请求
            boolean isMultipart = JakartaServletFileUpload.isMultipartContent(request);
            System.out.println("是否是multipart请求: " + isMultipart);

            if (!isMultipart) {
                System.out.println("错误: 请求不是multipart类型");
                return ResponseVo.error(400, "请求类型错误，必须是multipart/form-data");
            }

            System.out.println("=== 开始解析multipart请求 ===");

            // 创建文件上传处理器 - 新版API使用builder模式
            // 修正：移除 setFileItemThreshold 方法，只使用 setBufferSize
            DiskFileItemFactory factory = DiskFileItemFactory.builder()
                    .setBufferSize(1024 * 1024) // 1MB内存缓冲区
                    .get();

            JakartaServletFileUpload upload = new JakartaServletFileUpload(factory);
            upload.setFileSizeMax(10 * 1024 * 1024); // 10MB，单个文件最大
            upload.setSizeMax(20 * 1024 * 1024); // 20MB，整个请求最大

            try {
                // 解析请求
                List<FileItem> items = upload.parseRequest(request);
                System.out.println("解析到的FileItem数量: " + items.size());

                for (FileItem item : items) {
                    if (item.isFormField()) {
                        // 普通表单字段
                        String fieldName = item.getFieldName();
                        String fieldValue = item.getString();
                        System.out.println("表单字段: " + fieldName + " = " + fieldValue);

                        if ("oid".equals(fieldName)) {
                            oid = fieldValue;
                        }
                    } else {
                        // 文件字段
                        String fieldName = item.getFieldName();
                        String fileName = item.getName();
                        long fileSize = item.getSize();
                        String contentType = item.getContentType();

                        System.out.println("文件字段: " + fieldName);
                        System.out.println("  文件名: " + fileName);
                        System.out.println("  文件大小: " + fileSize + " bytes");
                        System.out.println("  文件类型: " + contentType);

                        if ("excelFile".equals(fieldName)) {
                            excelFileItem = item;
                            System.out.println("成功获取excelFile文件");
                        }
                    }
                }

            } catch (FileUploadException e) {
                System.out.println("文件上传解析异常: " + e.getMessage());
                return ResponseVo.error(400, "文件上传解析失败: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("文件处理异常: " + e.getMessage());
                e.printStackTrace();
                return ResponseVo.error(500, "文件处理失败: " + e.getMessage());
            }

            System.out.println("=== 参数验证 ===");
            System.out.println("OID: " + oid);
            System.out.println("文件: " + (excelFileItem != null ? excelFileItem.getName() : "null"));

            // 参数验证
            if (oid == null || oid.trim().isEmpty()) {
                System.out.println("错误: OID参数为空");
                return ResponseVo.error(400, "产品OID不能为空");
            }

            if (excelFileItem == null) {
                System.out.println("错误: 文件参数为null");
                return ResponseVo.error(400, "请选择要上传的Excel文件");
            }

            if (excelFileItem.getSize() == 0) {
                System.out.println("错误: 文件为空");
                return ResponseVo.error(400, "上传的文件为空");
            }

            // 检查文件类型
            String originalFilename = excelFileItem.getName();
            if (originalFilename == null || !originalFilename.toLowerCase().endsWith(".xlsx")) {
                System.out.println("错误: 文件类型不支持: " + originalFilename);
                return ResponseVo.error(400, "只支持.xlsx格式的Excel文件");
            }

            System.out.println("=== 所有参数验证通过，开始处理业务逻辑 ===");

            // 注意：这里需要根据新版的FileItem调整ExportService中的方法
            // 新版FileItem的API可能有所不同
            String importResult = exportService.readExcelToBOM(excelFileItem);

            if (importResult != null && importResult.contains("失败")) {
                System.out.println("=== 导入失败 ===");
                System.out.println("失败信息: " + importResult);
                return ResponseVo.error(400, importResult);
            }

            System.out.println("=== 导入完成 ===");
            System.out.println("导入结果: " + importResult);
            return ResponseVo.success(200, importResult);

        } catch (Exception e) {
            System.out.println("=== 发生异常 ===");
            e.printStackTrace();
            return ResponseVo.error(500, "导入失败: " + e.getMessage());
        } finally {
            System.out.println("=== 请求处理结束 ===\n");
        }
    }


    /**
     * Excel文件上传生成BOM
     */
    @PostMapping("/createPCBABOM")
    public ResponseVo createPCBABOM(HttpServletRequest request) {
        System.out.println("=== 后端开始处理文件上传请求 ===");

        String oid = null;
        FileItem excelFileItem = null;

        try {
            // 检查是否是multipart请求
            boolean isMultipart = JakartaServletFileUpload.isMultipartContent(request);
            System.out.println("是否是multipart请求: " + isMultipart);

            if (!isMultipart) {
                System.out.println("错误: 请求不是multipart类型");
                return ResponseVo.error(400, "请求类型错误，必须是multipart/form-data");
            }

            System.out.println("=== 开始解析multipart请求 ===");

            // 创建文件上传处理器 - 新版API使用builder模式
            // 修正：移除 setFileItemThreshold 方法，只使用 setBufferSize
            DiskFileItemFactory factory = DiskFileItemFactory.builder()
                    .setBufferSize(1024 * 1024) // 1MB内存缓冲区
                    .get();

            JakartaServletFileUpload upload = new JakartaServletFileUpload(factory);
            upload.setFileSizeMax(10 * 1024 * 1024); // 10MB，单个文件最大
            upload.setSizeMax(20 * 1024 * 1024); // 20MB，整个请求最大

            try {
                // 解析请求
                List<FileItem> items = upload.parseRequest(request);
                System.out.println("解析到的FileItem数量: " + items.size());

                for (FileItem item : items) {
                    if (item.isFormField()) {
                        // 普通表单字段
                        String fieldName = item.getFieldName();
                        String fieldValue = item.getString();
                        System.out.println("表单字段: " + fieldName + " = " + fieldValue);

                        if ("oid".equals(fieldName)) {
                            oid = fieldValue;
                        }
                    } else {
                        // 文件字段
                        String fieldName = item.getFieldName();
                        String fileName = item.getName();
                        long fileSize = item.getSize();
                        String contentType = item.getContentType();

                        System.out.println("文件字段: " + fieldName);
                        System.out.println("  文件名: " + fileName);
                        System.out.println("  文件大小: " + fileSize + " bytes");
                        System.out.println("  文件类型: " + contentType);

                        if ("excelFile".equals(fieldName)) {
                            excelFileItem = item;
                            System.out.println("成功获取excelFile文件");
                        }
                    }
                }

            } catch (FileUploadException e) {
                System.out.println("文件上传解析异常: " + e.getMessage());
                return ResponseVo.error(400, "文件上传解析失败: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("文件处理异常: " + e.getMessage());
                e.printStackTrace();
                return ResponseVo.error(500, "文件处理失败: " + e.getMessage());
            }

            System.out.println("=== 参数验证 ===");
            System.out.println("OID: " + oid);
            System.out.println("文件: " + (excelFileItem != null ? excelFileItem.getName() : "null"));

            // 参数验证
            if (oid == null || oid.trim().isEmpty()) {
                System.out.println("错误: OID参数为空");
                return ResponseVo.error(400, "产品OID不能为空");
            }

            if (excelFileItem == null) {
                System.out.println("错误: 文件参数为null");
                return ResponseVo.error(400, "请选择要上传的Excel文件");
            }

            if (excelFileItem.getSize() == 0) {
                System.out.println("错误: 文件为空");
                return ResponseVo.error(400, "上传的文件为空");
            }

            // 检查文件类型
            String originalFilename = excelFileItem.getName();
            if (originalFilename == null || !originalFilename.toLowerCase().endsWith(".xlsx")) {
                System.out.println("错误: 文件类型不支持: " + originalFilename);
                return ResponseVo.error(400, "只支持.xlsx格式的Excel文件");
            }

            System.out.println("=== 所有参数验证通过，开始处理业务逻辑 ===");

            // 注意：这里需要根据新版的FileItem调整ExportService中的方法
            // 新版FileItem的API可能有所不同
            String importResult = exportService.readExcelToPCBABOM(excelFileItem);
            if (importResult != null && importResult.contains("失败")) {
                System.out.println("=== 导入失败 ===");
                return ResponseVo.error(400, importResult);
            }

            System.out.println("=== 导入完成 ===");
            return ResponseVo.success(200, importResult);

        } catch (Exception e) {
            System.out.println("=== 发生异常 ===");
            e.printStackTrace();
            return ResponseVo.error(500, "导入失败: " + e.getMessage());
        } finally {
            System.out.println("=== 请求处理结束 ===\n");
        }
    }


    /**
     * Excel文件上传生成替代料
     */
    @PostMapping("/createSubPart")
    public ResponseVo createSubPart(HttpServletRequest request) {
        System.out.println("=== 后端开始处理文件上传请求 ===");

        String oid = null;
        FileItem excelFileItem = null;

        try {
            // 检查是否是multipart请求
            boolean isMultipart = JakartaServletFileUpload.isMultipartContent(request);
            System.out.println("是否是multipart请求: " + isMultipart);

            if (!isMultipart) {
                System.out.println("错误: 请求不是multipart类型");
                return ResponseVo.error(400, "请求类型错误，必须是multipart/form-data");
            }

            System.out.println("=== 开始解析multipart请求 ===");

            // 创建文件上传处理器 - 新版API使用builder模式
            // 修正：移除 setFileItemThreshold 方法，只使用 setBufferSize
            DiskFileItemFactory factory = DiskFileItemFactory.builder()
                    .setBufferSize(1024 * 1024) // 1MB内存缓冲区
                    .get();

            JakartaServletFileUpload upload = new JakartaServletFileUpload(factory);
            upload.setFileSizeMax(10 * 1024 * 1024); // 10MB，单个文件最大
            upload.setSizeMax(20 * 1024 * 1024); // 20MB，整个请求最大

            try {
                // 解析请求
                List<FileItem> items = upload.parseRequest(request);
                System.out.println("解析到的FileItem数量: " + items.size());

                for (FileItem item : items) {
                    if (item.isFormField()) {
                        // 普通表单字段
                        String fieldName = item.getFieldName();
                        String fieldValue = item.getString();
                        System.out.println("表单字段: " + fieldName + " = " + fieldValue);

                        if ("oid".equals(fieldName)) {
                            oid = fieldValue;
                        }
                    } else {
                        // 文件字段
                        String fieldName = item.getFieldName();
                        String fileName = item.getName();
                        long fileSize = item.getSize();
                        String contentType = item.getContentType();

                        System.out.println("文件字段: " + fieldName);
                        System.out.println("  文件名: " + fileName);
                        System.out.println("  文件大小: " + fileSize + " bytes");
                        System.out.println("  文件类型: " + contentType);

                        if ("excelFile".equals(fieldName)) {
                            excelFileItem = item;
                            System.out.println("成功获取excelFile文件");
                        }
                    }
                }

            } catch (FileUploadException e) {
                System.out.println("文件上传解析异常: " + e.getMessage());
                return ResponseVo.error(400, "文件上传解析失败: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("文件处理异常: " + e.getMessage());
                e.printStackTrace();
                return ResponseVo.error(500, "文件处理失败: " + e.getMessage());
            }

            System.out.println("=== 参数验证 ===");
            System.out.println("OID: " + oid);
            System.out.println("文件: " + (excelFileItem != null ? excelFileItem.getName() : "null"));

            // 参数验证
            if (oid == null || oid.trim().isEmpty()) {
                System.out.println("错误: OID参数为空");
                return ResponseVo.error(400, "产品OID不能为空");
            }

            if (excelFileItem == null) {
                System.out.println("错误: 文件参数为null");
                return ResponseVo.error(400, "请选择要上传的Excel文件");
            }

            if (excelFileItem.getSize() == 0) {
                System.out.println("错误: 文件为空");
                return ResponseVo.error(400, "上传的文件为空");
            }

            // 检查文件类型
            String originalFilename = excelFileItem.getName();
            if (originalFilename == null || !originalFilename.toLowerCase().endsWith(".xlsx")) {
                System.out.println("错误: 文件类型不支持: " + originalFilename);
                return ResponseVo.error(400, "只支持.xlsx格式的Excel文件");
            }

            System.out.println("=== 所有参数验证通过，开始处理业务逻辑 ===");

            // 注意：这里需要根据新版的FileItem调整ExportService中的方法
            // 新版FileItem的API可能有所不同
            String importResult = exportService.readExcelToSubPart(excelFileItem);

            System.out.println("=== 导入完成 ===");
            System.out.println("导入结果: " + importResult);
            return ResponseVo.success(200, importResult);

        } catch (Exception e) {
            System.out.println("=== 发生异常 ===");
            e.printStackTrace();
            return ResponseVo.error(500, "导入失败: " + e.getMessage());
        } finally {
            System.out.println("=== 请求处理结束 ===\n");
        }
    }
}