package ext.alphai.aistoneglobal.exportModel;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.exportModel.ExportModelRB_zh_CN")
public class ExportModelRB_zh_CN extends WTListResourceBundle {

    @RBEntry("导出团队模板")
    public static final String E_T_M_TITLE = "excelModel.exportTeam.title";

    @RBEntry("导出团队模板")
    public static final String E_T_M_TOOLTIP = "excelModel.exportTeam.tooltip";

    @RBEntry("导出团队模板")
    public static final String E_T_M_DES = "excelModel.exportTeam.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String E_T_M_ICON = "excelModel.exportTeam.icon";


    @RBEntry("导入团队模板")
    public static final String I_T_M_TITLE = "excelModel.importTeam.title";

    @RBEntry("导入团队模板")
    public static final String I_T_M_TOOLTIP = "excelModel.importTeam.tooltip";

    @RBEntry("导入团队模板")
    public static final String I_T_M_DES = "excelModel.importTeam.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String I_T_M_ICON = "excelModel.importTeam.icon";


    @RBEntry("导入BOM")
    public static final String I_T_B_TITLE = "excelModel.importBOM.title";

    @RBEntry("导入BOM")
    public static final String I_T_B_TOOLTIP = "excelModel.importBOM.tooltip";

    @RBEntry("导入BOM")
    public static final String I_T_B_DES = "excelModel.importBOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String I_T_B_ICON = "excelModel.importBOM.icon";


    @RBEntry("导入PCBA BOM")
    public static final String I_T_PB_TITLE = "excelModel.importPCBABOM.title";

    @RBEntry("导入PCBA BOM")
    public static final String I_T_PB_TOOLTIP = "excelModel.importPCBABOM.tooltip";

    @RBEntry("导入PCBA BOM")
    public static final String I_T_PB_DES = "excelModel.importPCBABOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String I_T_PB_ICON = "excelModel.importPCBABOM.icon";


    @RBEntry("导入替代料")
    public static final String I_T_S_TITLE = "excelModel.importSubPart.title";

    @RBEntry("导入替代料")
    public static final String I_T_S_TOOLTIP = "excelModel.importSubPart.tooltip";

    @RBEntry("导入替代料")
    public static final String I_T_S_DES = "excelModel.importSubPart.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String I_T_S_ICON = "excelModel.importSubPart.icon";


    @RBEntry("导出BOM")
    public static final String Export_BOM_TITLE = "excelModel.exportBOM.title";

    @RBEntry("导出BOM")
    public static final String Export_BOM_TOOLTIP = "excelModel.exportBOM.tooltip";

    @RBEntry("导出BOM")
    public static final String Export_BOM_DES = "excelModel.exportBOM.description";



    @RBEntry("导出PCBA BOM")
    public static final String Export_PCBA_BOM_TITLE = "excelModel.exportPCBABOM.title";

    @RBEntry("导出PCBA BOM")
    public static final String Export_PCBA_BOM_TOOLTIP = "excelModel.exportPCBABOM.tooltip";

    @RBEntry("导出PCBA BOM")
    public static final String Export_PCBA_BOM_DES = "excelModel.exportPCBABOM.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String Export_PCBA_BOM_ICON = "excelModel.exportPCBABOM.icon";


}
