package ext.alphai.aistoneglobal.exportModel.service;

import ext.alphai.aistoneglobal.exportModel.Constant;
import ext.alphai.aistoneglobal.exportModel.entity.BOMRowData;
import ext.alphai.aistoneglobal.exportModel.entity.PCBABOMRowData;
import ext.alphai.aistoneglobal.exportModel.util.*;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload2.core.FileItem;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.content.*;
import wt.doc.WTDocument;
import wt.fc.*;
import wt.folder.Folder;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.occurrence.OccurrenceHelper;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.project.Role;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.*;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewManageable;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ExportService {


    private static final Logger logger = LogManager.getLogger(ExportService.class);

    public void fillExcelTemplateWithStyle(String templatePath, HttpServletResponse response,
                                           String containerName, Map<Role, List<Map<String, String>>> roleUserMap) throws Exception {

        FileInputStream templateFile = null;
        Workbook workbook = null;
        ServletOutputStream outputStream = null;

        try {
            // 检查模板文件是否存在
            File templateFileObj = new File(templatePath);
            if (!templateFileObj.exists()) {
                throw new FileNotFoundException("Excel模板文件不存在: " + templatePath);
            }

            // 读取模板文件
            templateFile = new FileInputStream(templatePath);
            workbook = WorkbookFactory.create(templateFile);
            Sheet sheet = workbook.getSheetAt(0); // 获取第一个工作表

            // 获取或创建样式
            CellStyle headerStyle = getOrCreateHeaderStyle(workbook);
            CellStyle dataStyle = getOrCreateDataStyle(workbook);
            CellStyle centeredStyle = getOrCreateCenteredStyle(workbook);

            // 设置产品名称（第二行，第二列，即B2单元格）
            Row productNameRow = getOrCreateRow(sheet, 1);
            Cell productNameCell = getOrCreateCell(productNameRow, 1);
            productNameCell.setCellValue(containerName);
            productNameCell.setCellStyle(dataStyle);

            // 设置标题行样式（第三行）
            Row headerRow = getOrCreateRow(sheet, 2);
            for (int i = 0; i < 5; i++) { // A到E列
                Cell headerCell = getOrCreateCell(headerRow, i);
                headerCell.setCellStyle(headerStyle);
            }

            // 填充数据，从第4行开始（索引3）
            int currentRowIndex = 3; // 第四行开始
            int serialNumber = 1;

            for (Map.Entry<Role, List<Map<String, String>>> entry : roleUserMap.entrySet()) {
                Role role = entry.getKey();
                List<Map<String, String>> users = entry.getValue();

                if (users.isEmpty()) {
                    // 角色没有用户的情况
                    Row row = getOrCreateRow(sheet, currentRowIndex);
                    fillRowDataWithStyle(row, serialNumber++, role, null, null, dataStyle, centeredStyle);
                    currentRowIndex++;
                } else {
                    // 角色有用户的情况
                    for (Map<String, String> user : users) {
                        Row row = getOrCreateRow(sheet, currentRowIndex);
                        fillRowDataWithStyle(row, serialNumber++, role,
                                user.get("userId"), user.get("userName"), dataStyle, centeredStyle);
                        currentRowIndex++;
                    }
                }

                // 如果数据行数超过模板预设行数，确保有足够的行
                ensureEnoughRows(sheet, currentRowIndex + 10);
            }

            // 设置"以下空白"行
            setBlankRow(sheet, currentRowIndex, dataStyle);

            // 自动调整列宽
            autoSizeColumns(sheet, 5); // 调整A到E列

            // 设置响应头，强制下载
            setupResponseHeaders(response, containerName);

            // 输出Excel文件
            outputStream = response.getOutputStream();
            workbook.write(outputStream);
            outputStream.flush();

        } catch (Exception e) {
            // 记录错误日志
            System.err.println("导出Excel失败: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            // 关闭资源
            closeResources(workbook, templateFile, outputStream);
        }
    }

    public CellStyle getOrCreateHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();

        // 设置字体
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 11);
        font.setFontName("宋体");
        style.setFont(font);

        // 设置边框
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);

        // 设置背景色
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        // 设置对齐方式
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);

        return style;
    }

    public CellStyle getOrCreateDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();

        // 设置字体
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 10);
        font.setFontName("宋体");
        style.setFont(font);

        // 设置边框
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);

        // 设置对齐方式
        style.setVerticalAlignment(VerticalAlignment.CENTER);

        return style;
    }

    public CellStyle getOrCreateCenteredStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();

        // 复制数据样式
        CellStyle dataStyle = getOrCreateDataStyle(workbook);
        style.cloneStyleFrom(dataStyle);

        // 设置居中对齐
        style.setAlignment(HorizontalAlignment.CENTER);

        return style;
    }

    public Row getOrCreateRow(Sheet sheet, int rowIndex) {
        Row row = sheet.getRow(rowIndex);
        if (row == null) {
            row = sheet.createRow(rowIndex);
            // 设置行高
            row.setHeightInPoints(20);
        }
        return row;
    }

    public Cell getOrCreateCell(Row row, int cellIndex) {
        Cell cell = row.getCell(cellIndex);
        if (cell == null) {
            cell = row.createCell(cellIndex);
        }
        return cell;
    }

    public void fillRowDataWithStyle(Row row, int serialNumber, Role role,
                                     String userId, String userName,
                                     CellStyle dataStyle, CellStyle centeredStyle) {
        // 序号列 (A列) - 居中对齐
        Cell cell0 = getOrCreateCell(row, 0);
        cell0.setCellValue(serialNumber);
        cell0.setCellStyle(centeredStyle);

        // 角色ID列 (B列) - 左对齐
        Cell cell1 = getOrCreateCell(row, 1);
        cell1.setCellValue(role.getValue());
        cell1.setCellStyle(dataStyle);

        // 角色名称列 (C列) - 左对齐
        Cell cell2 = getOrCreateCell(row, 2);
        cell2.setCellValue(role.getDisplay());
        cell2.setCellStyle(dataStyle);

        // 用户ID列 (D列) - 左对齐
        Cell cell3 = getOrCreateCell(row, 3);
        if (userId != null && !userId.trim().isEmpty()) {
            cell3.setCellValue(userId);
        } else {
            cell3.setCellValue("");
        }
        cell3.setCellStyle(dataStyle);

        // 用户全名列 (E列) - 左对齐
        Cell cell4 = getOrCreateCell(row, 4);
        if (userName != null && !userName.trim().isEmpty()) {
            cell4.setCellValue(userName);
        } else {
            cell4.setCellValue("");
        }
        cell4.setCellStyle(dataStyle);
    }

    public void ensureEnoughRows(Sheet sheet, int requiredRows) {
        int lastRowNum = sheet.getLastRowNum();
        if (lastRowNum < requiredRows) {
            for (int i = lastRowNum + 1; i <= requiredRows; i++) {
                getOrCreateRow(sheet, i);
            }
        }
    }

    public void setBlankRow(Sheet sheet, int rowIndex, CellStyle dataStyle) {
        Row blankRow = getOrCreateRow(sheet, rowIndex);
        Cell blankCell = getOrCreateCell(blankRow, 0);
        blankCell.setCellValue("以下空白");
        blankCell.setCellStyle(dataStyle);

        // 合并单元格
        sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, 0, 4));
    }

    public void autoSizeColumns(Sheet sheet, int columnCount) {
        for (int i = 0; i < columnCount; i++) {
            sheet.autoSizeColumn(i);
            // 设置最小列宽
            int currentWidth = sheet.getColumnWidth(i);
            if (currentWidth < 2000) { // 约等于10个字符宽度
                sheet.setColumnWidth(i, 2000);
            }
        }
    }

    public void setupResponseHeaders(HttpServletResponse response, String containerName) {
        response.reset();
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

        // 文件名处理，移除特殊字符
        String safeProductName = containerName.replaceAll("[\\\\/:*?\"<>|]", "_");

        // 修改这里：设置您想要的文件名格式
        String fileName = safeProductName + "_团队模板" + ".xlsx";
        // 或者使用其他格式：

        // 设置文件名到响应头
        try {
            // 对文件名进行URL编码，确保中文正常显示
            String encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8")
                    .replaceAll("\\+", "%20");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + encodedFileName + "\"; filename*=UTF-8''" + encodedFileName);
        } catch (UnsupportedEncodingException e) {
            // 如果编码失败，使用原始文件名
            response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
        }

        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Expires", "0");
        response.setCharacterEncoding("UTF-8");
    }


    public void closeResources(Workbook workbook, FileInputStream templateFile, ServletOutputStream outputStream) {
        if (workbook != null) {
            try {
                workbook.close();
            } catch (IOException e) {
                System.err.println("关闭Workbook失败: " + e.getMessage());
            }
        }
        if (templateFile != null) {
            try {
                templateFile.close();
            } catch (IOException e) {
                System.err.println("关闭模板文件失败: " + e.getMessage());
            }
        }
        if (outputStream != null) {
            try {
                outputStream.close();
            } catch (IOException e) {
                System.err.println("关闭输出流失败: " + e.getMessage());
            }
        }
    }

    // 备用方法：如果模板不存在，创建基本模板
    public void createBasicTemplate(String templatePath) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        // 创建标题行
        Row titleRow = sheet.createRow(0);
        titleRow.createCell(0).setCellValue("智通PLM系统团队清单");
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 4));

        // 创建产品名称行
        Row productRow = sheet.createRow(1);
        productRow.createCell(0).setCellValue("产品名称");
        productRow.createCell(1).setCellValue("");
        productRow.createCell(2).setCellValue("UAT培训");

        // 创建表头行
        Row headerRow = sheet.createRow(2);
        String[] headers = {"序号", "角色id", "角色名称", "用户ID", "用户全名"};
        for (int i = 0; i < headers.length; i++) {
            headerRow.createCell(i).setCellValue(headers[i]);
        }

        // 创建数据行（空行）
        for (int i = 3; i < 35; i++) {
            sheet.createRow(i);
        }

        // 创建以下空白行
        Row blankRow = sheet.createRow(35);
        blankRow.createCell(0).setCellValue("以下空白");
        sheet.addMergedRegion(new CellRangeAddress(35, 35, 0, 4));

        // 保存模板
        try (FileOutputStream out = new FileOutputStream(templatePath)) {
            workbook.write(out);
        }

        workbook.close();
    }

    public String processImport(String oid, FileItem excelFile) throws Exception {
//        System.out.println("开始导入团队数据，产品OID: " + oid);

        // 获取产品对象
        ContainerTeamManaged prod = getProductByOid(oid);
        if (prod == null) {
            throw new Exception("未找到对应的产品，OID: " + oid);
        }

        // 读取Excel数据
        Map<String, List<Map<String, String>>> excelData = readExcelData(excelFile);

        // 获取当前团队数据
        ContainerTeam team = ContainerTeamHelper.service.getContainerTeam(prod);
        if (team == null) {
            throw new Exception("未找到产品的团队信息");
        }

        // 比较并添加新用户
        List<String> addedUsers = compareAndAddUsers(team, excelData);

        // 生成结果消息
        return generateResultMessage(addedUsers);
    }

    /**
     * 直接从MultipartFile读取Excel数据
     */
    private Map<String, List<Map<String, String>>> readExcelData(FileItem excelFile) throws Exception {
        Map<String, List<Map<String, String>>> excelData = new HashMap<>();
        DataFormatter formatter = new DataFormatter();

        Workbook workbook = null;

        try {
            // 直接从MultipartFile的InputStream创建Workbook
            workbook = WorkbookFactory.create(excelFile.getInputStream());
            Sheet sheet = workbook.getSheetAt(0);

            // 从第4行开始读取数据（跳过标题行）
            for (int i = 3; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                // 使用DataFormatter获取单元格值
                String serialNumber = formatter.formatCellValue(row.getCell(0)); // 序号
                String roleId = formatter.formatCellValue(row.getCell(1));      // 角色ID
                String roleName = formatter.formatCellValue(row.getCell(2));    // 角色名称
                String userId = formatter.formatCellValue(row.getCell(3));      // 用户ID
                String userName = formatter.formatCellValue(row.getCell(4));    // 用户全名

                // 跳过空行和结束行
                if ("end".equals(serialNumber) || "以下空白".equals(serialNumber) ||
                        serialNumber == null || serialNumber.trim().isEmpty()) {
                    continue;
                }

                if (roleId == null || roleId.trim().isEmpty() || userId == null || userId.trim().isEmpty()) {
                    continue;
                }

                // 按角色ID分组存储用户数据
                if (!excelData.containsKey(roleId)) {
                    excelData.put(roleId, new ArrayList<>());
                }

                Map<String, String> userData = new HashMap<>();
                userData.put("userId", userId.trim());
                userData.put("userName", userName.trim());
                userData.put("roleName", roleName.trim());

                excelData.get(roleId).add(userData);
            }

            System.out.println("从Excel读取到 " + excelData.size() + " 个角色的数据");

        } finally {
            if (workbook != null) {
                try {
                    workbook.close();
                } catch (IOException e) {
                }
            }
        }

        return excelData;
    }

    /**
     * 比较并添加新用户
     */
    private List<String> compareAndAddUsers(ContainerTeam team,
                                            Map<String, List<Map<String, String>>> excelData) throws WTException {
        List<String> addedUsers = new ArrayList<>();

        // 获取当前团队的所有角色和用户
        Map<String, Set<String>> currentUserRoles = getCurrentUserRoles(team);

        for (Map.Entry<String, List<Map<String, String>>> excelEntry : excelData.entrySet()) {
            String roleId = excelEntry.getKey();
            List<Map<String, String>> excelUsers = excelEntry.getValue();

            // 查找对应的角色
            Role targetRole = findRoleById(team, roleId);
            if (targetRole == null) {
                System.out.println("未找到角色ID: " + roleId);
                continue;
            }

            // 比较并添加新用户
            for (Map<String, String> excelUser : excelUsers) {
                String excelUserId = excelUser.get("userId");

                // 检查用户是否已存在于此角色
                boolean userExists = currentUserRoles.containsKey(excelUserId) &&
                        currentUserRoles.get(excelUserId).contains(roleId);

                // 如果用户不存在于此角色，添加到团队
                if (!userExists) {
                    try {
                        WTUser user = findUserById(excelUserId);
                        if (user != null) {
                            ContainerTeamHelper.service.addMember(team, targetRole, user);
                            addedUsers.add(excelUserId + " (" + excelUser.get("userName") + ") - 角色: " + excelUser.get("roleName"));
                            System.out.println("添加用户: " + excelUserId + " 到角色: " + targetRole.getDisplay());

                            // 更新当前用户角色映射
                            if (!currentUserRoles.containsKey(excelUserId)) {
                                currentUserRoles.put(excelUserId, new HashSet<>());
                            }
                            currentUserRoles.get(excelUserId).add(roleId);
                        } else {
                            // 用户不存在，尝试查找组
                            WTGroup group = queryGroupByName(excelUserId);
                            if (group != null) {
                                ContainerTeamHelper.service.addMember(team, targetRole, group);
                                addedUsers.add(excelUserId + " (" + excelUser.get("userName") + ") - 角色: " + excelUser.get("roleName") + " [组]");
                                System.out.println("添加组: " + excelUserId + " 到角色: " + targetRole.getDisplay());

                                // 更新当前用户角色映射
                                if (!currentUserRoles.containsKey(excelUserId)) {
                                    currentUserRoles.put(excelUserId, new HashSet<>());
                                }
                                currentUserRoles.get(excelUserId).add(roleId);
                            } else {
                                System.out.println("未找到用户或组: " + excelUserId);
                            }
                        }
                    } catch (Exception e) {
                        System.err.println("添加用户/组失败: " + excelUserId + ", 错误: " + e.getMessage());
                    }
                }
            }
        }

        return addedUsers;
    }

    /**
     * 获取当前团队的用户角色映射
     */
    private Map<String, Set<String>> getCurrentUserRoles(ContainerTeam team) throws WTException {
        Map<String, Set<String>> userRoles = new HashMap<>();
        Vector roles = team.getRoles();

        for (Object roleObj : roles) {
            Role role = (Role) roleObj;
            ArrayList principals = team.getAllPrincipalsForTarget(role);

            for (Object principalObj : principals) {
                WTPrincipalReference principal = (WTPrincipalReference) principalObj;
                String userId = principal.getName();

                if (!userRoles.containsKey(userId)) {
                    userRoles.put(userId, new HashSet<>());
                }
                userRoles.get(userId).add(role.getValue());
            }
        }

        return userRoles;
    }

    /**
     * 根据角色ID查找角色
     */
    private Role findRoleById(ContainerTeam team, String roleId) throws WTException {
        Vector roles = team.getRoles();
        for (Object roleObj : roles) {
            Role role = (Role) roleObj;
            if (roleId.equals(role.getValue())) {
                return role;
            }
        }
        return null;
    }

    /**
     * 根据用户号查找用户
     */
    private WTUser findUserById(String accountName) throws WTException {
        WTUser user = null;
        // Enumeration enumUser = OrganizationServicesHelper.manager.findUser(WTUser.NAME, accountName);

        Enumeration enumUser = OrganizationServicesHelper.manager.findUser(WTUser.NAME, accountName);
        if (enumUser.hasMoreElements()) {
            user = (WTUser) enumUser.nextElement();
        }

        //user = OrganizationServicesHelper.manager.getUser(WTUser.NAME, accountName);

        return user;
    }

    /**
     * 根据OID获取产品
     */
    private ContainerTeamManaged getProductByOid(String oid) throws WTException {
        try {
            ReferenceFactory rf = new ReferenceFactory();
            WTReference reference = rf.getReference(oid);
            Persistable object = reference.getObject();
            if (object instanceof ContainerTeamManaged) {
                return (ContainerTeamManaged) object;
            } else {
                return null;
            }

        } catch (Exception e) {
            throw new WTException("获取产品失败: " + e.getMessage());
        }
    }

    /**
     * 生成结果消息
     */
    private String generateResultMessage(List<String> addedUsers) {
        if (addedUsers.isEmpty()) {
            return "导入完成，没有新增用户。";
        } else {
            StringBuilder message = new StringBuilder("导入完成，成功添加 " + addedUsers.size() + " 个用户:\n");
            for (String user : addedUsers) {
                message.append(" ").append(user).append("\n");
            }
            return message.toString();
        }
    }

    public static WTGroup queryGroupByName(String groupName) {
        try {
            ChangeSession.administratorSession();
            if (StringUtils.isBlank(groupName)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(WTGroup.class);
            SearchCondition sc = new SearchCondition(WTGroup.class, WTGroup.NAME, SearchCondition.EQUAL,
                    groupName.trim());
            int[] index = {0};
            qs.appendWhere(sc, index);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            while (qr.hasMoreElements()) {
                WTGroup group = (WTGroup) qr.nextElement();
                return group;
            }
        } catch (WTException e) {
            e.printStackTrace();
        } finally {
            ChangeSession.goPreviousSession();
        }
        return null;
    }


//    /**
//     * 获取当前团队数据（用于导出）
//     */
//    public Map<Role, List<Map<String, String>>> getCurrentTeamData(String oid) throws WTException {
//        PDMLinkProduct prod = getProductByOid(oid);
//        ContainerTeam team = ContainerTeamHelper.service.getContainerTeam(prod);
//
//        Map<Role, List<Map<String, String>>> currentTeamData = new LinkedHashMap<>();
//        Vector roles = team.getRoles();
//
//        for (Object roleObj : roles) {
//            Role role = (Role) roleObj;
//            ArrayList principals = team.getAllPrincipalsForTarget(role);
//
//            List<Map<String, String>> usersInRole = new ArrayList<>();
//
//            for (Object principalObj : principals) {
//                WTPrincipalReference principal = (WTPrincipalReference) principalObj;
//
//                Map<String, String> userInfo = new HashMap<>();
//                userInfo.put("userId", principal.getName());
//                userInfo.put("userName", principal.getFullName() != null ? principal.getFullName() : "");
//
//                usersInRole.add(userInfo);
//            }
//
//            currentTeamData.put(role, usersInRole);
//        }
//
//        return currentTeamData;
//    }

//
//    public static String readExcelToBOM(FileItem excelFile) throws IOException {
//        String values = "完成";
//        try (Workbook workbook = WorkbookFactory.create(excelFile.getInputStream())) {
//            HashSet<String> wtParts = new HashSet<>();
//            // 遍历所有工作表
//            for (Sheet sheet : workbook) { // 获取第一个工作表
//                for (int rowNum = 3; rowNum <= sheet.getLastRowNum(); rowNum++) {
//                    Row row = sheet.getRow(rowNum);
//                    if (isRowEmpty(row)) {
//                        System.out.println("第 " + (rowNum + 1) + " 行为空，跳过");
//                        break;
//                    }
//                    String fNumber = getCellValueAsString(row.getCell(1));
//                    String cNumber = getCellValueAsString(row.getCell(3));
//                    String anZhuang = getCellValueAsString(row.getCell(5));
//                    String count = getCellValueAsString(row.getCell(6));
//                    String lineNumber = getCellValueAsString(row.getCell(7));
//                    String cLossRate = getCellValueAsString(row.getCell(8));
//                    String occurrence = getCellValueAsString(row.getCell(9));
//                    WTPart fPart = getWTPartByNumber(fNumber);
//                    WTPart cPart = getWTPartByNumber(cNumber);
//                    if (fPart == null || cPart == null)
//                        continue;
//                    if (!wtParts.contains(fNumber)) {
//                        if (!WorkInProgressHelper.isCheckedOut(fPart)) {
//                            WorkInProgressHelper.service.checkout(fPart, WorkInProgressHelper.service.getCheckoutFolder(), null);
//                            fPart = (WTPart) WorkInProgressHelper.service.workingCopyOf(fPart);
//                        }
//                        wtParts.add(fNumber);
//                    }
//                    WTPartUsageLink link = WTPartUsageLink.newWTPartUsageLink(fPart, cPart.getMaster());
//                    if (StringUtils.isNotBlank(count)) {
//                        Quantity qa = Quantity.newQuantity(Double.valueOf(count), QuantityUnit.EA);// 设置数量 和单位
//                        link.setQuantity(qa);
//
//                    }
//                    PersistenceServerHelper.manager.insert(link);
//                    System.out.println("设置位号为：" + occurrence);
//                    if (StringUtils.isNotBlank(occurrence)) {
//                        createOccurrence(link, occurrence);
//                    }
//                    IBAUtil ibaUtil = new IBAUtil(link);
//                    ibaUtil.setIBAAttribute4AllType(link, Constant.AI_Placement_Side, anZhuang);
//                    ibaUtil.setIBAAttribute4AllType(link, Constant.AI_LineNumber, lineNumber);
//                    ibaUtil.setIBAAttribute4AllType(link, Constant.AI_LossRate, cLossRate);
//                }
//                for (String number : wtParts) {
//                    WTPart fPart = getWTPartByNumber(number);
//                    if (WorkInProgressHelper.isCheckedOut(fPart)) {
//                        WorkInProgressHelper.service.checkin(fPart, "结构修改");
//                    }
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            values = "失败";
//        }
//
//        return values;
//    }


    /**
     * 导入PCBA BOM（包含主料和替代料）
     * Excel列说明：
     * 第1列(0): 父项料号
     * 第7列(6): 行号
     * 第9列(8): 子项料号（主料）
     * 第12列(11): 损耗率
     * 第17列(16): 位号
     * 第18列(17): 使用数量
     * 第19列(18): 安装面
     * <p>
     * 逻辑：
     * 1. 按父项料号分组，同一个父项只检出一次
     * 2. 先创建所有主料的UsageLink
     */
//    public static String readExcelToPCBABOM(FileItem excelFile) throws IOException, WTException, WTPropertyVetoException {
//        Transaction trx = null;
//        Set<String> checkedOutParts = new HashSet<>();  // 记录已检出的部件
//        List<String> errorMessages = new ArrayList<>(); // 错误信息收集
//        Map<String, WTPart> parentPartMap = new HashMap<>(); // 缓存父部件对象
//
//        try (Workbook workbook = WorkbookFactory.create(excelFile.getInputStream())) {
//
//            // ========== 第一步：预校验数据 ==========
//            logger.info("===== 开始预校验PCBA BOM数据 =====");
//            Map<String, List<PCBABOMRowData>> bomDataMap = preValidatePCBABOMData(workbook, errorMessages);
//
//            // ========== 添加：打印完整的BOM数据 ==========
//            logger.info("===== 预校验后的BOM数据详情 =====");
//            logger.info("共有 {} 个父项", bomDataMap.size());
//            for (Map.Entry<String, List<PCBABOMRowData>> entry : bomDataMap.entrySet()) {
//                String parentNumber = entry.getKey();
//                List<PCBABOMRowData> rows = entry.getValue();
//                logger.info("父项料号: {}, 子项数量: {}", parentNumber, rows.size());
//                for (PCBABOMRowData row : rows) {
//                    logger.info("  行号:{}, 子项料号:{}, 安装面:{}, 数量:{}, 位号:{}, 损耗率:{}",
//                            row.rowNum,
//                            row.childNumber,
//                            row.placementSide,
//                            row.quantity,
//                            row.occurrence,
//                            row.lossRate);
//                }
//            }
//            logger.info("===== BOM数据打印完成 =====");
//
//            // 如果有错误，直接返回
//            if (!errorMessages.isEmpty()) {
//                StringBuilder sb = new StringBuilder();
//                sb.append("导入失败，错误信息：\n");
//                for (int i = 0; i < errorMessages.size(); i++) {
//                    sb.append(errorMessages.get(i));
//                    if (i < errorMessages.size() - 1) {
//                        sb.append("\n");
//                    }
//                }
//                String result = sb.toString();
//                logger.error(result);
//                return result;
//            }
//
//            // ========== 第二步：开始事务处理 ==========
//            trx = new Transaction();
//            trx.start();
//            logger.info("事务已启动");
//
//            // 处理每个父项
//            for (Map.Entry<String, List<PCBABOMRowData>> entry : bomDataMap.entrySet()) {
//                String parentNumber = entry.getKey();
//                List<PCBABOMRowData> rows = entry.getValue();
//
//                try {
//                    logger.info("\n===== 处理父项: {} =====", parentNumber);
//
//                    // 2.1 获取并检出父部件（只检出一次）
//                    WTPart parentPart = getWTPartByNumber(parentNumber);
//                    if (parentPart == null) {
//                        errorMessages.add("父项部件不存在：" + parentNumber);
//                        logger.error("父项部件不存在：{}", parentNumber);
//                        continue;
//                    }
//
//                    // 检出父部件（如果还没检出）
//                    if (!checkedOutParts.contains(parentNumber)) {
//                        parentPart = checkoutPart(parentPart);
//                        if (parentPart == null) {
//                            errorMessages.add("检出父部件失败：" + parentNumber);
//                            logger.error("检出父部件失败：{}", parentNumber);
//                            continue;
//                        }
//                        checkedOutParts.add(parentNumber);
//                        parentPartMap.put(parentNumber, parentPart);
//                        logger.info("检出父部件: {}", parentNumber);
//                    } else {
//                        parentPart = parentPartMap.get(parentNumber);
//                    }
//
//                    // 2.2 删除所有现有的子项（包括替代料关系）
//                    deleteAllChildLinks(parentPart);
//
//                    // 2.3 创建所有主料的UsageLink
//                    for (int i = 0; i < rows.size(); i++) {
//                        PCBABOMRowData row = rows.get(i);
//
//                        // 获取子部件（主料）
//                        WTPart childPart = getWTPartByNumber(row.childNumber);
//                        if (childPart == null) {
//                            errorMessages.add("第 " + row.rowNum + " 行：子部件不存在：" + row.childNumber);
//                            logger.error("第 {} 行：子部件不存在：{}", row.rowNum, row.childNumber);
//                            continue;
//                        }
//
//                        try {
//                            WTPartUsageLink link  = WTPartUsageLink.newWTPartUsageLink(parentPart, childPart.getMaster());
//                            // 创建UsageLink
////                            link = getLinkByPartAndSide(parentPart, childPart, row.placementSide);
////                            if (link == null) {
////                                link = WTPartUsageLink.newWTPartUsageLink(parentPart, childPart.getMaster());
////                            }
//
//                            // 设置数量
//                            if (StringUtils.isNotBlank(row.quantity)) {
//                                try {
//                                    double qty = Double.parseDouble(row.quantity);
//                                    Quantity quantity = Quantity.newQuantity(qty, QuantityUnit.EA);
//                                    link.setQuantity(quantity);
//                                } catch (NumberFormatException e) {
//                                    errorMessages.add("第 " + row.rowNum + " 行：数量格式错误");
//                                    logger.error("第 {} 行：数量格式错误", row.rowNum);
//                                }
//                            }
//
//                            // 保存link
//                            link = (WTPartUsageLink) PersistenceHelper.manager.save(link);
//
//                            // 设置行号IBA属性
//                            if (StringUtils.isNotBlank(row.lineNumber)) {
//                                IBAUtil ibaUtil = new IBAUtil(link);
//                                // 格式化为4位数字，前面补零
//                                String formattedLineNumber = formatLineNumber(row.lineNumber);
//                                ibaUtil.setIBAAttribute4AllType(link, Constant.AI_LineNumber, formattedLineNumber);
//                                logger.info("设置行号: {} -> {}", row.lineNumber, formattedLineNumber);
//                            }
//
//                            // 设置安装面IBA属性
//                            if (StringUtils.isNotBlank(row.placementSide)) {
//                                IBAUtil ibaUtil = new IBAUtil(link);
//                                ibaUtil.setIBAAttribute4AllType(link, Constant.AI_Placement_Side, row.placementSide);
//                                logger.info("设置安装面: {}", row.placementSide);
//                            }
//
//                            // 设置损耗率IBA属性
//                            if (StringUtils.isNotBlank(row.lossRate)) {
//                                IBAUtil ibaUtil = new IBAUtil(link);
//                                ibaUtil.setIBAAttribute4AllType(link, Constant.AI_LossRate, row.lossRate);
//                                logger.info("设置损耗率: {}", row.lossRate);
//                            }
//
//                            // 创建位号
//                            if (StringUtils.isNotBlank(row.occurrence)) {
//                                createOccurrence(link, row.occurrence);
//                                logger.info("设置位号: {}", row.occurrence);
//                            }
//
//                            logger.info("创建主料: {}，行号：{}，安装面：{}，数量：{}",
//                                    row.childNumber, row.lineNumber, row.placementSide, row.quantity);
//
//                        } catch (Exception e) {
//                            errorMessages.add("第 " + row.rowNum + " 行：创建主料失败 - " + e.getMessage());
//                            logger.error("第 {} 行：创建主料失败", row.rowNum, e);
//                            throw e;
//                        }
//                    }
//
//                    logger.info("父项 {} 处理完成", parentNumber);
//
//                } catch (Exception e) {
//                    errorMessages.add("处理父项 " + parentNumber + " 时发生异常：" + e.getMessage());
//                    logger.error("处理父项 {} 时发生异常", parentNumber, e);
//                    throw e;
//                }
//            }
//
//            // ========== 第三步：检入所有部件（统一检入） ==========
//            if (errorMessages.isEmpty()) {
//                logger.info("\n===== 开始检入所有部件 =====");
//                for (String parentNumber : checkedOutParts) {
//                    WTPart parentPart = parentPartMap.get(parentNumber);
//                    if (parentPart != null && WorkInProgressHelper.isCheckedOut(parentPart)) {
//                        WorkInProgressHelper.service.checkin(parentPart, "PCBA BOM导入修改");
//                        logger.info("检入部件：{}", parentNumber);
//                    }
//                }
//                trx.commit();
//                trx = null;
//                String successMsg = "导入成功，共处理 " + bomDataMap.size() + " 个父项";
//                logger.info(successMsg);
//                return successMsg;
//            } else {
//                throw new WTException("导入失败，错误信息：" + String.join("; ", errorMessages));
//            }
//
//        } catch (Exception e) {
//            logger.error("导入过程中发生异常", e);
//            if (trx != null) {
//                try {
//                    trx.rollback();
//                    logger.info("事务已回滚");
//                } catch (Exception e2) {
//                    logger.error("回滚事务失败", e2);
//                }
//            }
//            // 强制检入已检出的部件
//            for (String parentNumber : checkedOutParts) {
//                WTPart parentPart = getWTPartByNumber(parentNumber);
//                if (parentPart != null && WorkInProgressHelper.isCheckedOut(parentPart)) {
//                    try {
//                        WorkInProgressHelper.service.checkin(parentPart, "异常回滚后强制检入");
//                        logger.info("强制检入部件：{}", parentNumber);
//                    } catch (Exception e2) {
//                        logger.error("强制检入部件 {} 失败", parentNumber, e2);
//                    }
//                }
//            }
//            return "导入失败：" + e.getMessage();
//        }
//    }


    /**
     * 导入PCBA BOM（包含主料和替代料）
     * Excel列说明：
     * 第1列(0): 父项料号
     * 第7列(6): 行号
     * 第9列(8): 子项料号（主料）
     * 第12列(11): 损耗率
     * 第17列(16): 位号
     * 第18列(17): 使用数量
     * 第19列(18): 安装面
     * <p>
     * 逻辑：
     * 1. 按父项料号分组，同一个父项只检出一次
     * 2. 先创建所有主料的UsageLink（行号以0结尾）
     * 3. 再创建替代料的SubstituteLink（行号不以0结尾，关联到对应的主料）
     * 注意：相同行号、不同安装面的主料，通过"行号!安装面"作为唯一标识来区分
     */
    public static String readExcelToPCBABOM(FileItem excelFile) throws IOException, WTException, WTPropertyVetoException {
        Transaction trx = null;
        Set<String> checkedOutParts = new HashSet<>();  // 记录已检出的部件
        List<String> errorMessages = new ArrayList<>(); // 错误信息收集
        Map<String, WTPart> parentPartMap = new HashMap<>(); // 缓存父部件对象

        try (Workbook workbook = WorkbookFactory.create(excelFile.getInputStream())) {

            // ========== 第一步：预校验数据 ==========
            logger.info("===== 开始预校验PCBA BOM数据 =====");
            Map<String, List<PCBABOMRowData>> bomDataMap = preValidatePCBABOMData(workbook, errorMessages);

            // ========== 添加：打印完整的BOM数据 ==========
            logger.info("===== 预校验后的BOM数据详情 =====");
            logger.info("共有 {} 个父项", bomDataMap.size());
            for (Map.Entry<String, List<PCBABOMRowData>> entry : bomDataMap.entrySet()) {
                String parentNumber = entry.getKey();
                List<PCBABOMRowData> rows = entry.getValue();
                logger.info("父项料号: {}, 子项数量: {}", parentNumber, rows.size());
                for (PCBABOMRowData row : rows) {
                    logger.info("  行号:{}, 子项料号:{}, 安装面:{}, 数量:{},优先级{}, 位号:{}, 损耗率:{}",
                            row.lineNumber,
                            row.childNumber,
                            row.placementSide,
                            row.quantity,
                            row.priority,
                            row.occurrence,
                            row.lossRate);
                }
            }
            logger.info("===== BOM数据打印完成 =====");

            // 如果有错误，直接返回
            if (!errorMessages.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                sb.append("导入失败，错误信息：\n");
                for (int i = 0; i < errorMessages.size(); i++) {
                    sb.append(errorMessages.get(i));
                    if (i < errorMessages.size() - 1) {
                        sb.append("\n");
                    }
                }
                String result = sb.toString();
                logger.error(result);
                return result;
            }

            // ========== 第二步：开始事务处理 ==========
            trx = new Transaction();
            trx.start();
            logger.info("事务已启动");

            // 处理每个父项
            for (Map.Entry<String, List<PCBABOMRowData>> entry : bomDataMap.entrySet()) {
                String parentNumber = entry.getKey();
                List<PCBABOMRowData> rows = entry.getValue();

                try {
                    logger.info("\n===== 处理父项: {} =====", parentNumber);

                    // 2.1 获取并检出父部件（只检出一次）
                    WTPart parentPart = getWTPartByNumber(parentNumber);
                    if (parentPart == null) {
                        errorMessages.add("父项部件不存在：" + parentNumber);
                        logger.error("父项部件不存在：{}", parentNumber);
                        continue;
                    }

                    // 检出父部件（如果还没检出）
                    if (!checkedOutParts.contains(parentNumber)) {
                        parentPart = checkoutPart(parentPart);
                        if (parentPart == null) {
                            errorMessages.add("检出父部件失败：" + parentNumber);
                            logger.error("检出父部件失败：{}", parentNumber);
                            continue;
                        }
                        checkedOutParts.add(parentNumber);
                        parentPartMap.put(parentNumber, parentPart);
                        logger.info("检出父部件: {}", parentNumber);
                    } else {
                        parentPart = parentPartMap.get(parentNumber);
                    }

                    // 2.2 删除所有现有的子项（包括替代料关系）
                    deleteAllChildLinks(parentPart);

                    // 2.3 分离主料和替代料
                    // 主料Map: key = "行号!安装面", value = PCBABOMRowData
                    Map<String, PCBABOMRowData> mainMaterialMap = new HashMap<>();
                    // 替代料List: 存储替代料数据
                    List<PCBABOMRowData> substituteList = new ArrayList<>();
                    // 用于记录主料的唯一标识，避免重复
                    Set<String> mainMaterialKeys = new HashSet<>();

                    for (PCBABOMRowData row : rows) {
                        String lineNumberStr = row.lineNumber;
                        if (isLong(lineNumberStr)) {
                            long lineNumber = Long.parseLong(lineNumberStr);
                            String placementSide = row.placementSide != null ? row.placementSide : "";
                            String childNumber = row.childNumber != null ? row.childNumber : "";

                            // 使用"行号!安装面"作为唯一标识
                            String uniqueKey = lineNumber + "!" + placementSide;

                            if (endsWithZero(lineNumber)) {
                                // 行号以0结尾的是主料
                                if (!mainMaterialKeys.contains(uniqueKey)) {
                                    mainMaterialMap.put(uniqueKey, row);
                                    mainMaterialKeys.add(uniqueKey);
                                    logger.info("识别为主料: 行号={}, 安装面={}, 料号={}", lineNumber, placementSide, childNumber);
                                } else {
                                    errorMessages.add("第 " + row.rowNum + " 行：主料重复 - 行号=" + lineNumber + ", 安装面=" + placementSide);
                                    logger.error("第 {} 行：主料重复", row.rowNum);
                                }
                            } else {
                                // 行号不以0结尾的是替代料
                                substituteList.add(row);
                                logger.info("识别为替代料: 行号={}, 安装面={}, 料号={}", lineNumber, placementSide, childNumber);
                            }
                        } else {
                            errorMessages.add("第 " + row.rowNum + " 行：行号格式错误，必须为数字");
                            logger.error("第 {} 行：行号格式错误", row.rowNum);
                        }
                    }

                    // 2.4 先创建所有主料的UsageLink
                    // 主料Link缓存: key = "行号!安装面", value = WTPartUsageLink
                    Map<String, WTPartUsageLink> mainLinkMap = new HashMap<>();

                    for (Map.Entry<String, PCBABOMRowData> mainEntry : mainMaterialMap.entrySet()) {
                        String key = mainEntry.getKey();
                        PCBABOMRowData row = mainEntry.getValue();

                        // 获取子部件（主料）
                        WTPart childPart = getWTPartByNumber(row.childNumber);
                        if (childPart == null) {
                            errorMessages.add("第 " + row.rowNum + " 行：子部件不存在：" + row.childNumber);
                            logger.error("第 {} 行：子部件不存在：{}", row.rowNum, row.childNumber);
                            continue;
                        }

                        try {
                            // 创建UsageLink
                            WTPartUsageLink link = WTPartUsageLink.newWTPartUsageLink(parentPart, childPart.getMaster());

                            // 设置数量
                            if (StringUtils.isNotBlank(row.quantity)) {
                                try {
                                    double qty = Double.parseDouble(row.quantity);
                                    Quantity quantity = Quantity.newQuantity(qty, QuantityUnit.EA);
                                    link.setQuantity(quantity);
                                } catch (NumberFormatException e) {
                                    errorMessages.add("第 " + row.rowNum + " 行：数量格式错误");
                                    logger.error("第 {} 行：数量格式错误", row.rowNum);
                                }
                            }

                            // 保存link
                            link = (WTPartUsageLink) PersistenceHelper.manager.save(link);

                            // 缓存主料Link
                            mainLinkMap.put(key, link);

                            // 设置行号IBA属性
                            if (StringUtils.isNotBlank(row.lineNumber)) {
                                IBAUtil ibaUtil = new IBAUtil(link);
                                String formattedLineNumber = formatLineNumber(row.lineNumber);
                                ibaUtil.setIBAAttribute4AllType(link, Constant.AI_LineNumber, formattedLineNumber);
                                logger.info("设置行号: {} -> {}", row.lineNumber, formattedLineNumber);
                            }

                            // 设置安装面IBA属性
                            if (StringUtils.isNotBlank(row.placementSide)) {
                                IBAUtil ibaUtil = new IBAUtil(link);
                                ibaUtil.setIBAAttribute4AllType(link, Constant.AI_Placement_Side, row.placementSide);
                                logger.info("设置安装面: {}", row.placementSide);
                            }

                            // 设置损耗率IBA属性
                            if (StringUtils.isNotBlank(row.lossRate)) {
                                IBAUtil ibaUtil = new IBAUtil(link);
                                ibaUtil.setIBAAttribute4AllType(link, Constant.AI_LossRate, row.lossRate);
                                logger.info("设置损耗率: {}", row.lossRate);
                            }

                            // 创建位号
                            if (StringUtils.isNotBlank(row.occurrence)) {
                                createOccurrence(link, row.occurrence);
                                logger.info("设置位号: {}", row.occurrence);
                            }

                            logger.info("创建主料: {}，行号：{}，安装面：{}，数量：{}",
                                    row.childNumber, row.lineNumber, row.placementSide, row.quantity);

                        } catch (Exception e) {
                            errorMessages.add("第 " + row.rowNum + " 行：创建主料失败 - " + e.getMessage());
                            logger.error("第 {} 行：创建主料失败", row.rowNum, e);
                            throw e;
                        }
                    }

                    // 2.5 创建替代料的SubstituteLink
                    // 按主料分组存储替代料
                    Map<String, List<PCBABOMRowData>> substituteByMainKey = new HashMap<>();

                    for (PCBABOMRowData substituteRow : substituteList) {
                        String lineNumberStr = substituteRow.lineNumber;
                        long lineNumber = Long.parseLong(lineNumberStr);
                        String placementSide = substituteRow.placementSide != null ? substituteRow.placementSide : "";

                        // 计算主料的行号（将最后一位设为0）
                        long mainLineNumber = setLastDigitToZero(lineNumber);
                        String mainKey = mainLineNumber + "!" + placementSide;

                        // 按主料分组存储替代料
                        substituteByMainKey.computeIfAbsent(mainKey, k -> new ArrayList<>()).add(substituteRow);
                    }

                    // 处理每个主料下的替代料
                    for (Map.Entry<String, List<PCBABOMRowData>> substituteEntry : substituteByMainKey.entrySet()) {
                        String mainKey = substituteEntry.getKey();
                        List<PCBABOMRowData> substituteRows = substituteEntry.getValue();

                        // 获取对应的主料Link
                        WTPartUsageLink mainLink = mainLinkMap.get(mainKey);

                        if (mainLink == null) {
                            for (PCBABOMRowData substituteRow : substituteRows) {
                                errorMessages.add("第 " + substituteRow.rowNum + " 行：找不到对应的主料（主料行号：" + mainKey + "）");
                                logger.error("第 {} 行：找不到对应的主料", substituteRow.rowNum);
                            }
                            continue;
                        }

                        // 获取主料编号
                        String mainPartNumber = getMainPartNumberFromLink(mainLink);

                        // 为每个替代料创建SubstituteLink
                        for (PCBABOMRowData substituteRow : substituteRows) {
                            long lineNumber = Long.parseLong(substituteRow.lineNumber);
                            String placementSide = substituteRow.placementSide != null ? substituteRow.placementSide : "";

                            // 获取替代料部件
                            WTPart substitutePart = getWTPartByNumber(substituteRow.childNumber);
                            if (substitutePart == null) {
                                errorMessages.add("第 " + substituteRow.rowNum + " 行：替代料部件不存在：" + substituteRow.childNumber);
                                logger.error("第 {} 行：替代料部件不存在：{}", substituteRow.rowNum, substituteRow.childNumber);
                                continue;
                            }

                            // 检查替代料是否和主料相同
//                            if (substituteRow.childNumber.equals(mainPartNumber)) {
//                                errorMessages.add("第 " + substituteRow.rowNum + " 行：替代料不能与主料相同：" + substituteRow.childNumber);
//                                logger.error("第 {} 行：替代料不能与主料相同：{}", substituteRow.rowNum, substituteRow.childNumber);
//                                continue;
//                            }

                            try {
                                // 创建替代料链接
                                WTPartSubstituteLink substituteLink = createSubstituteLink(mainLink, substitutePart.getMaster());

                                // 计算优先级（最后一位数字+1）
//                                String priority = "0" + substituteRow.priority;

                                // ✅ 处理优先级：如果Excel中有priority字段就用，否则按顺序生成
                                String priority = "";
                                if (StringUtils.isNotBlank(substituteRow.priority)) {
                                    // 使用Excel中填写的优先级
                                    priority = formatPriority(substituteRow.priority);
                                }

                                logger.info("主料 {} (行号={}, 安装面={}) 的替代料是：{}，优先级为：{}",
                                        mainPartNumber, setLastDigitToZero(lineNumber), placementSide,
                                        substituteRow.childNumber, priority);

                                // 设置优先级IBA属性
                                IBAUtil ibaUtil = new IBAUtil(substituteLink);
                                ibaUtil.setIBAAttribute4AllType(substituteLink, "AI_Priority", priority);

                                // 设置替代料的行号属性
                                if (StringUtils.isNotBlank(substituteRow.lineNumber)) {
                                    ibaUtil.setIBAAttribute4AllType(substituteLink, Constant.AI_LineNumber,
                                            formatLineNumber(substituteRow.lineNumber));
                                }

                                // 设置替代料的安装面属性
                                if (StringUtils.isNotBlank(substituteRow.placementSide)) {
                                    ibaUtil.setIBAAttribute4AllType(substituteLink, Constant.AI_Placement_Side,
                                            substituteRow.placementSide);
                                }

                                logger.info("创建替代料: {}，关联主料行号：{}，安装面：{}，优先级：{}",
                                        substituteRow.childNumber, setLastDigitToZero(lineNumber), placementSide, priority);

                            } catch (Exception e) {
                                errorMessages.add("第 " + substituteRow.rowNum + " 行：创建替代料失败 - " + e.getMessage());
                                logger.error("第 {} 行：创建替代料失败", substituteRow.rowNum, e);
                                throw e;
                            }
                        }
                    }

                    logger.info("父项 {} 处理完成", parentNumber);

                } catch (Exception e) {
                    errorMessages.add("处理父项 " + parentNumber + " 时发生异常：" + e.getMessage());
                    logger.error("处理父项 {} 时发生异常", parentNumber, e);
                    throw e;
                }
            }

            // ========== 第三步：检入所有部件（统一检入） ==========
            if (errorMessages.isEmpty()) {
                logger.info("\n===== 开始检入所有部件 =====");
                for (String parentNumber : checkedOutParts) {
                    WTPart parentPart = parentPartMap.get(parentNumber);
                    if (parentPart != null && WorkInProgressHelper.isCheckedOut(parentPart)) {
                        WorkInProgressHelper.service.checkin(parentPart, "PCBA BOM导入修改");
                        logger.info("检入部件：{}", parentNumber);
                    }
                }
                trx.commit();
                trx = null;
                String successMsg = "导入成功，共处理 " + bomDataMap.size() + " 个父项";
                logger.info(successMsg);
                return successMsg;
            } else {
                throw new WTException("导入失败，错误信息：" + String.join("; ", errorMessages));
            }

        } catch (Exception e) {
            logger.error("导入过程中发生异常", e);
            if (trx != null) {
                try {
                    trx.rollback();
                    logger.info("事务已回滚");
                } catch (Exception e2) {
                    logger.error("回滚事务失败", e2);
                }
            }
            // 强制检入已检出的部件
            for (String parentNumber : checkedOutParts) {
                WTPart parentPart = getWTPartByNumber(parentNumber);
                if (parentPart != null && WorkInProgressHelper.isCheckedOut(parentPart)) {
                    try {
                        WorkInProgressHelper.service.checkin(parentPart, "异常回滚后强制检入");
                        logger.info("强制检入部件：{}", parentNumber);
                    } catch (Exception e2) {
                        logger.error("强制检入部件 {} 失败", parentNumber, e2);
                    }
                }
            }
            return "导入失败：" + e.getMessage();
        }
    }


    /**
     * 格式化优先级（简洁版）
     * 输入：1 -> 输出：01
     * 输入：01 -> 输出：01
     * 输入：10 -> 输出：10
     */
    private static String formatPriority(String priority) {
        if (StringUtils.isBlank(priority)) {
            return "";
        }

        String trimmed = priority.trim();

        // 如果已经是两位数，直接返回
        if (trimmed.matches("\\d{2}")) {
            return trimmed;
        }

        // 如果是1-9的数字，补零
        try {
            int num = Integer.parseInt(trimmed);
            if (num >= 1 && num <= 9) {
                return String.format("%02d", num);
            }
        } catch (NumberFormatException e) {
            // 忽略，返回原值
        }

        return trimmed;
    }

    /**
     * 从WTPartUsageLink中获取主料编号
     */
    private static String getMainPartNumberFromLink(WTPartUsageLink link) {
        if (link != null && link.getUses() != null) {
            return link.getUses().getNumber();
        }
        return null;
    }

    /**
     * 判断字符串是否能解析为Long
     */
    public static boolean isLong(String str) {
        if (str == null || str.trim().isEmpty()) {
            return false;
        }
        String trimmed = str.trim();
        // 处理正负号
        if (trimmed.startsWith("+") || trimmed.startsWith("-")) {
            trimmed = trimmed.substring(1);
        }
        // 检查是否全为数字，且长度不超过19
        return trimmed.matches("\\d+") && trimmed.length() <= 19;
    }

    /**
     * 判断数字是否以0结尾
     */
    private static boolean endsWithZero(long number) {
        return number % 10 == 0;
    }

    /**
     * 获取数字的最后一位
     */
    private static int getLastDigit(long number) {
        return (int) Math.abs(number % 10);
    }

    /**
     * 将数字的最后一位设为0
     */
    private static long setLastDigitToZero(long number) {
        return (number / 10) * 10;
    }





    /**
     * 将行号格式化为4位数字，前面补零
     * 例如：10 -> 0010, 100 -> 0100, 1 -> 0001
     */
    private static String formatLineNumber(String lineNumber) {
        if (StringUtils.isBlank(lineNumber)) {
            return lineNumber;
        }

        try {
            // 尝试解析为数字
            int num = Integer.parseInt(lineNumber.trim());
            // 格式化为4位，前面补零
            return String.format("%04d", num);
        } catch (NumberFormatException e) {
            // 如果不是纯数字，返回原值
            logger.warn("行号不是纯数字，保持原值: {}", lineNumber);
            return lineNumber;
        }
    }


    /**
     * 预校验PCBA BOM数据
     */
    private static Map<String, List<PCBABOMRowData>> preValidatePCBABOMData(Workbook workbook, List<String> errorMessages) {
        Map<String, List<PCBABOMRowData>> bomDataMap = new LinkedHashMap<>();
        Set<String> allPartNumbers = new HashSet<>();

        Sheet sheet = workbook.getSheetAt(0);
        DataFormatter formatter = new DataFormatter();

        // 从第2行开始读取（0-based，所以索引1是第2行）
        for (int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++) {
            Row row = sheet.getRow(rowNum);
            if (isRowEmpty(row)) {
                logger.debug("第 {} 行为空，停止读取", rowNum + 1);
                break;
            }

            // 读取父项料号（第1列）
            String parentNumber = getCellValueAsString(row.getCell(0));

            // 如果父项料号为空，说明有效数据结束，停止读取
            if (StringUtils.isBlank(parentNumber)) {
                logger.info("第 {} 行父项料号为空，停止读取", rowNum + 1);
                break;
            }

            PCBABOMRowData rowData = new PCBABOMRowData();
            rowData.rowNum = rowNum + 1;  // Excel显示的行号

            // 读取各列数据（根据实际列位置）
            rowData.parentNumber = parentNumber;
            rowData.lineNumber = getCellValueAsString(row.getCell(6));     // 第7列：行号
            rowData.childNumber = getCellValueAsString(row.getCell(8));    // 第9列：子项料号
            rowData.lossRate = getCellValueAsString(row.getCell(11));      // 第12列：损耗率
            rowData.priority = getCellValueAsString(row.getCell(13));      // 第14列：优先级
            rowData.occurrence = getCellValueAsString(row.getCell(16));    // 第17列：位号
            rowData.quantity = getCellValueAsString(row.getCell(17));      // 第18列：使用数量
            rowData.placementSide = getCellValueAsString(row.getCell(18)); // 第19列：安装面

            logger.debug("读取行{}: {}", rowData.rowNum, rowData);

            // 基础校验
            if (StringUtils.isBlank(rowData.childNumber)) {
                errorMessages.add("第 " + rowData.rowNum + " 行：子项料号不能为空");
                logger.error("第 {} 行：子项料号不能为空", rowData.rowNum);
                continue;
            }

            // 数量校验（如果填写了数量）
            if (StringUtils.isNotBlank(rowData.quantity)) {
                try {
                    Double.parseDouble(rowData.quantity);
                } catch (NumberFormatException e) {
                    errorMessages.add("第 " + rowData.rowNum + " 行：数量格式错误，必须为数字");
                    logger.error("第 {} 行：数量格式错误，必须为数字", rowData.rowNum);
                }
            }

            // 收集所有部件编号
            allPartNumbers.add(rowData.parentNumber);
            allPartNumbers.add(rowData.childNumber);

            // 按父项分组
            bomDataMap.computeIfAbsent(rowData.parentNumber, k -> new ArrayList<>()).add(rowData);
        }

        // 如果有错误，直接返回
        if (!errorMessages.isEmpty()) {
            return bomDataMap;
        }

        // 校验所有部件是否存在
        logger.info("开始校验部件是否存在...");
        for (String partNumber : allPartNumbers) {
            try {
                WTPart part = getWTPartByNumber(partNumber);
                if (part == null) {
                    errorMessages.add("部件不存在：" + partNumber);
                    logger.error("部件不存在：{}", partNumber);
                }
            } catch (Exception e) {
                errorMessages.add("校验部件 " + partNumber + " 时发生异常：" + e.getMessage());
                logger.error("校验部件 {} 时发生异常", partNumber, e);
            }
        }

        String[] noAllowStates = PropertiesUtil.getValueByKey("ai.noAllowRevision.state").split(",");
        // 校验父项部件状态
        for (String parentNumber : bomDataMap.keySet()) {
            try {
                WTPart parentPart = getWTPartByNumber(parentNumber);
                if (parentPart == null) {
                    errorMessages.add("父项部件不存在：" + parentNumber);
                    logger.error("父项部件不存在：{}", parentNumber);
                    continue;
                }

                // 检出校验
                if (WorkInProgressHelper.isCheckedOut(parentPart)) {
                    errorMessages.add("父项部件 " + parentNumber + " 已被他人检出，请稍后重试");
                    logger.error("父项部件 {} 已被他人检出，请稍后重试", parentNumber);
                }

                String state = parentPart.getState().toString();
                String display = parentPart.getLifeCycleState().getDisplay();
                for (String noAllowState : noAllowStates) {
                    if (noAllowState.equals(state)) {
                        errorMessages.add("父项部件 " + parentNumber + ", 状态 :" + display + " 禁止创建或修改BOM");
                        logger.error("父项部件 {}, 状态 :{} 禁止创建或修改BOM", parentNumber, display);
                    }
                }

            } catch (Exception e) {
                errorMessages.add("校验父项 " + parentNumber + " 状态时发生异常：" + e.getMessage());
                logger.error("校验父项 {} 状态时发生异常", parentNumber, e);
            }
        }

        // 校验子项部件状态
        String[] sonNoAllowStates = PropertiesUtil.getValueByKey("ai.sonNoAllowRevision.state").split(",");
        Set<String> validatedChildParts = new HashSet<>();  // 避免重复校验同一个子部件

        for (List<PCBABOMRowData> bomRows : bomDataMap.values()) {
            for (PCBABOMRowData rowData : bomRows) {
                // 校验子项
                if (StringUtils.isNotBlank(rowData.childNumber) && !validatedChildParts.contains(rowData.childNumber)) {
                    validatedChildParts.add(rowData.childNumber);
                    try {
                        WTPart childPart = getWTPartByNumber(rowData.childNumber);
                        if (childPart != null) {
                            String state = childPart.getState().toString();
                            String display = childPart.getLifeCycleState().getDisplay();
                            for (String noAllowState : sonNoAllowStates) {
                                if (noAllowState.equals(state)) {
                                    errorMessages.add("子项部件 " + rowData.childNumber + ", 状态 :" + display + " 不允许作为BOM子项");
                                    logger.error("子项部件 {}, 状态 :{} 不允许作为BOM子项", rowData.childNumber, state);
                                }
                            }
                        }
                    } catch (Exception e) {
                        errorMessages.add("校验子项 " + rowData.childNumber + " 状态时发生异常：" + e.getMessage());
                        logger.error("校验子项 {} 状态时发生异常", rowData.childNumber, e);
                    }
                }
            }
        }

        return bomDataMap;
    }


    /**
     * 根据父部件、子部件和安装面获取对应的UsageLink
     *
     * @param fatherPart    父部件
     * @param sonPart       子部件
     * @param placementSide 安装面（TOP/BOTTOM）
     * @return WTPartUsageLink
     */
    public static WTPartUsageLink getLinkByPartAndSide(WTPart fatherPart, WTPart sonPart, String placementSide) {
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                WTPart part = getBomPartBylink(link);

                // 先匹配部件号
                if (part.getNumber().equals(sonPart.getNumber())) {
                    // 如果不需要匹配安装面，直接返回
                    if (placementSide == null || placementSide.isEmpty()) {
                        return link;
                    }

                    // 获取link上的安装面IBA属性
                    ext.util.IBAUtil ibaUtil = new ext.util.IBAUtil(link);
                    String linkPlacementSide = ibaUtil.getIBAValue("AI_Placement_Side");

                    // 匹配安装面
                    if (placementSide.equals(linkPlacementSide)) {
                        return link;
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * PCBA BOM数据行对象（内部类）
     */


    public static void createOccurrence(WTPartUsageLink usagelink, String occurrences) throws WTException {
        try {
            OccurrenceHelper.service.setSkipValidation(true);
            if (occurrences != null && !"".equals(occurrences)) {
                StringTokenizer occstrs = new StringTokenizer(occurrences, ",");
                String curoccstr = null;

                while (occstrs.hasMoreTokens()) {
                    curoccstr = occstrs.nextToken();
                    if (curoccstr != null && curoccstr.length() > 0) {
                        PartUsesOccurrence newOccurrence = PartUsesOccurrence.newPartUsesOccurrence(usagelink);
                        newOccurrence.setName(curoccstr);
                        OccurrenceHelper.service.saveUsesOccurrenceAndData(newOccurrence, (Vector) null);
                    }
                }
            }
        } catch (Exception var8) {
            throw new WTException(var8);
        } finally {
            OccurrenceHelper.service.setSkipValidation(false);
        }

    }

    /**
     * 根据编号查询part
     *
     * @param String
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static WTPart getWTPartByNumber(String number) {
        WTPart result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (WTPart) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    // 位置：在 ExportService 类中，找到这个方法并替换
    private static String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }

        String value = "";
        switch (cell.getCellType()) {
            case STRING:
                value = cell.getStringCellValue();
                break;
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    // 日期格式处理
                    Date date = cell.getDateCellValue();
                    if (date != null) {
                        value = new java.text.SimpleDateFormat("yyyy-MM-dd").format(date);
                    }
                } else {
                    // 避免数值类型显示为科学计数法或带小数
                    double numericValue = cell.getNumericCellValue();
                    if (numericValue == (long) numericValue) {
                        value = String.valueOf((long) numericValue);
                    } else {
                        value = String.valueOf(numericValue);
                    }
                }
                break;
            case BOOLEAN:
                value = String.valueOf(cell.getBooleanCellValue());
                break;
            case FORMULA:
                try {
                    value = cell.getStringCellValue();
                } catch (Exception e) {
                    try {
                        value = String.valueOf(cell.getNumericCellValue());
                    } catch (Exception e2) {
                        value = "";
                    }
                }
                break;
            case BLANK:
                value = "";
                break;
            default:
                value = "";
        }

        // 【修改点1】去除首尾空格，并将多个连续空格替换为单个空格
        if (value != null) {
            value = value.trim().replaceAll("\\s+", " ");
        }

        return value;
    }


    public static Map<String, String> readProperties(String propertiesFilePath) {
        Properties properties = new Properties();
        Map<String, String> map = new LinkedHashMap<>(); // 保持插入顺序

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(propertiesFilePath),
                        StandardCharsets.UTF_8))) {

            properties.load(reader);

            // 处理可能的编码问题（双重保障）
            properties.forEach((k, v) -> {
                String key = transcodeIfNeeded((String) k);
                String value = transcodeIfNeeded((String) v);
                map.put(key, value);
            });

        } catch (IOException ex) {
            System.err.println("读取配置文件失败: " + propertiesFilePath);
            ex.printStackTrace();
        }

        System.out.println("解析结果: " + map);
        return map;
    }

    /**
     * 编码纠正方法（处理被错误解析的UTF-8字符串）
     */
    private static String transcodeIfNeeded(String str) {
        try {
            // 尝试检测是否是ISO-8859-1误读的UTF-8
            if (str != null && !str.equals(new String(str.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.ISO_8859_1))) {
                return new String(str.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
            }
            return str;
        } catch (Exception e) {
            return str;
        }
    }

    // 检查整行是否为空
    private static boolean isRowEmpty(Row row) {
        if (row == null) {
            return true;
        }

        for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
            if (cell != null) {
                return false;
            }
        }
        return true;
    }

    public static String readExcelToSubPart(FileItem excelFile) throws IOException {
        String values = "完成";
        try (Workbook workbook = WorkbookFactory.create(excelFile.getInputStream())) {
            HashSet<String> wtParts = new HashSet<>();
            // 遍历所有工作表
            for (Sheet sheet : workbook) { // 获取第一个工作表
                for (int rowNum = 3; rowNum <= sheet.getLastRowNum(); rowNum++) {
                    Row row = sheet.getRow(rowNum);
                    if (isRowEmpty(row)) {
                        System.out.println("第 " + (rowNum + 1) + " 行为空，跳过");
                        break;
                    }
                    String fNumber = getCellValueAsString(row.getCell(1));
                    String cNumber = getCellValueAsString(row.getCell(3));
                    String sNumber = getCellValueAsString(row.getCell(5));
                    String excelPriority = getCellValueAsString(row.getCell(6));
                    WTPart fPart = getWTPartByNumber(fNumber);
                    WTPart cPart = getWTPartByNumber(cNumber);
                    WTPart sPart = getWTPartByNumber(sNumber);
                    if (fPart == null || cPart == null || sPart == null)
                        continue;
                    List<WTPartUsageLink> usageLinks = getLinkByPart(fPart, cPart);
                    System.out.println("使用关系数量：" + usageLinks.size());
                    if (usageLinks.size() >= 1) {
                        //判断是否存在这替代料

                        for (WTPartUsageLink usageLink : usageLinks) {
                            WTPartSubstituteLink substituteLink = isExistSubPart(usageLink, sNumber);

                            //没有就创建
                            if (substituteLink == null) {
                                substituteLink = createSubstituteLink(usageLink, sPart.getMaster());
                            }
                            IBAUtil subIBAUtil = new IBAUtil(substituteLink);
                            String priority = "0" + excelPriority;
                            subIBAUtil.setIBAAttribute4AllType(substituteLink, "AI_Priority", priority);
                        }


                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            values = "失败";
        }

        return values;
    }


    /**
     * 创建替代料链接
     */
    public static WTPartSubstituteLink createSubstituteLink(WTPartUsageLink link, WTPartMaster master) throws WTException {
        if (link != null && master != null) {
            WTPartSubstituteLink substLink = WTPartSubstituteLink.newWTPartSubstituteLink(link, master);
            PersistenceServerHelper.manager.insert(substLink);
            return (WTPartSubstituteLink) PersistenceHelper.manager.refresh(substLink);
        } else {
            return null;
        }
    }



//
//    private static WTPartSubstituteLink createSubstituteLink(WTPartUsageLink parentLink, WTPartMaster substituteMaster)
//            throws WTException {
//        // 创建替代料链接
//        WTPartSubstituteLink substituteLink = WTPartSubstituteLink.newWTPartSubstituteLink(parentLink, substituteMaster);
//        substituteLink = (WTPartSubstituteLink) PersistenceHelper.manager.save(substituteLink);
//        return substituteLink;
//    }

    /**
     * @param fatherPart, WTPart sonPart 根据父部件和子部件获取 link
     * @return WTPart
     * @throws Exception
     */
    public static List<WTPartUsageLink> getLinkByPart(WTPart fatherPart, WTPart sonPart) {
        List<WTPartUsageLink> wtPartUsageLinks = new ArrayList<>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                WTPart part = getBomPartBylink(link);
                if (part.getNumber().equals(sonPart.getNumber())) {
                    wtPartUsageLinks.add(link);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return wtPartUsageLinks;
    }


    /**
     * @param link 得到link对应的bom子部件
     * @return WTPart
     * @throws Exception
     */
    public static WTPart getBomPartBylink(WTPartUsageLink link) {
        try {
            QueryResult qr = VersionControlHelper.service.allVersionsOf(link.getUses());
            //System.out.println("getBomPartBylink----->"+ qr.size());
            if (qr.hasMoreElements()) {
                WTPart part = (WTPart) qr.nextElement();
                //System.out.println("part----->"+ part.getNumber());
                return part;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 根据部件于获取局部替代料的关联关系
     *
     * @param WTPart part
     * @return List<WTPartSubstituteLink>
     */
    public static List<WTPartSubstituteLink> getWTPartSubstituteLinks(WTPartUsageLink usageLink) {
        if (usageLink == null) {
            return null;
        }
        List<WTPartSubstituteLink> list = new ArrayList<WTPartSubstituteLink>();
        long masterId = PersistenceHelper.getObjectIdentifier(usageLink).getId();
        int[] index = {0};
        try {
            QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
            qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class, "roleAObjectRef.key.id",
                    SearchCondition.EQUAL, masterId), index);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            while (qr.hasMoreElements()) {
                WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr.nextElement();
                list.add(sLink);
            }
        } catch (QueryException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 判断特定替代料是否含有这个物料  存在返回link  否则返回null
     *
     * @param link
     * @param subPartNumber
     * @return
     */
    public static WTPartSubstituteLink isExistSubPart(WTPartUsageLink link, String subPartNumber) {
        WTPartSubstituteLink result = null;

        //获取替代料
        List<WTPartSubstituteLink> partSubstituteLinks = getWTPartSubstituteLinks(link);
        for (WTPartSubstituteLink partSubstituteLink : partSubstituteLinks) {
            //存在替代料
            if (partSubstituteLink.getSubstitutes().getNumber().equals(subPartNumber)) {
                result = partSubstituteLink;
                break;
            }
        }
        return result;
    }


    /**
     * 根据部件编号、版本、视图获取最新版本部件
     */
    public static WTPart getLatestWTPart(String partNumber, String version, String iteration, String viewName) throws WTException {
        WTPart part = null;
        LatestConfigSpec configSpec = null;
        QuerySpec qs = null;
        QueryResult qr = null;
        if (StringUtils.isNotBlank(partNumber)) {
            partNumber = partNumber.trim();

            qs = new QuerySpec(WTPart.class);
            int[] index = new int[]{0};
            qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, partNumber.toUpperCase(), false), index);

            if (StringUtils.isNotBlank(version)) {
                version = version.trim();
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, Versioned.VERSION_INFO + "." + VersionInfo.IDENTIFIER + "." + "versionId", SearchCondition.EQUAL, version, false), index);

                if (StringUtils.isNotBlank(iteration)) {
                    iteration = iteration.trim();
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.IDENTIFIER + "." + "iterationId", SearchCondition.EQUAL, iteration, false), index);
                } else {
                    qs.appendAnd();
                    qs.appendWhere(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE), index);
                }
            }

            if (StringUtils.isNotBlank(viewName)) {
                viewName = viewName.trim();
                View viewObj = ViewHelper.service.getView(viewName);
                if (viewObj == null)
                    return null;
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(WTPart.class, ViewManageable.VIEW + "." + ObjectReference.KEY, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(viewObj)), index);
            }

            configSpec = new LatestConfigSpec();
            configSpec.appendSearchCriteria(qs);
            qr = PersistenceHelper.manager.find((StatementSpec) qs);
            qr = configSpec.process(qr);
            if (qr.hasMoreElements()) {
                part = (WTPart) qr.nextElement();
            }
        }
        return part;
    }


    public static String checkBOM(FileItem excelFile) throws IOException, WTException, WTPropertyVetoException {
        Transaction trx = null;
        Set<String> checkedOutParts = new HashSet<>();  // 记录已检出的部件
        List<String> errorMessages = new ArrayList<>(); // 错误信息收集
        Map<String, WTPart> parentPartMap = new HashMap<>(); // 缓存父部件对象

        try (Workbook workbook = WorkbookFactory.create(excelFile.getInputStream())) {
            Map<String, List<BOMRowData>> bomDataMap = preValidateBOMData(workbook, errorMessages);
            if (!errorMessages.isEmpty()) {
                StringBuilder sb = new StringBuilder("导入失败，错误信息：\n");
                for (String msg : errorMessages) {
                    sb.append(msg).append("\n");
                }
                return sb.toString();
            }
        } catch (Exception e) {

        }
        // 如果有错误，直接返回
        return "校验通过，请点击开始导入！";
    }

    /**
     * 导入BOM（包含主料和替代料）
     * Excel列说明：
     * 序号 | 父项料号 | 子项料号 | 使用数量 | 新行号 | 替代料 | 优先级
     * <p>
     * 逻辑：
     * 1. 按父项料号分组，同一个父项只检出一次
     * 2. 先创建所有主料的UsageLink
     * 3. 再为每个主料创建替代料关系
     */
    public static String readExcelToBOM(FileItem excelFile) throws IOException, WTException, WTPropertyVetoException {
        Transaction trx = null;
        Set<String> checkedOutParts = new HashSet<>();  // 记录已检出的部件
        List<String> errorMessages = new ArrayList<>(); // 错误信息收集
        Map<String, WTPart> parentPartMap = new HashMap<>(); // 缓存父部件对象

        try (Workbook workbook = WorkbookFactory.create(excelFile.getInputStream())) {

            // ========== 第一步：预校验数据 ==========
            logger.info("===== 开始预校验数据 =====");
            Map<String, List<BOMRowData>> bomDataMap = preValidateBOMData(workbook, errorMessages);

            // 如果有错误，直接返回
            if (!errorMessages.isEmpty()) {
                StringBuilder sb = new StringBuilder("导入失败，错误信息：\n");
                for (String msg : errorMessages) {
                    sb.append(msg).append("\n");
                    logger.error(msg);
                }
                return sb.toString();
            }

            // ========== 第二步：开始事务处理 ==========
            trx = new Transaction();
            trx.start();
            logger.info("事务已启动");

            // 处理每个父项
            for (Map.Entry<String, List<BOMRowData>> entry : bomDataMap.entrySet()) {
                String parentNumber = entry.getKey();
                List<BOMRowData> rows = entry.getValue();

                try {
                    logger.info("\n===== 处理父项: {} =====", parentNumber);

                    // 2.1 获取并检出父部件（只检出一次）
                    WTPart parentPart = getWTPartByNumber(parentNumber);
                    if (parentPart == null) {
                        errorMessages.add("父项部件不存在：" + parentNumber);
                        logger.error("父项部件不存在：{}", parentNumber);
                        continue;
                    }

                    // 检出父部件（如果还没检出）
                    if (!checkedOutParts.contains(parentNumber)) {
                        parentPart = checkoutPart(parentPart);
                        if (parentPart == null) {
                            errorMessages.add("检出父部件失败：" + parentNumber);
                            logger.error("检出父部件失败：{}", parentNumber);
                            continue;
                        }
                        checkedOutParts.add(parentNumber);
                        parentPartMap.put(parentNumber, parentPart);
                        logger.info("检出父部件: {}", parentNumber);
                    } else {
                        parentPart = parentPartMap.get(parentNumber);
                    }

                    // 2.2 删除所有现有的子项（包括替代料关系）
                    deleteAllChildLinks(parentPart);

                    // 2.3 先创建所有主料的UsageLink，并记录每个主料的link
                    Map<String, WTPartUsageLink> mainPartLinks = new LinkedHashMap<>(); // key: 行号
                    Map<Integer, WTPartUsageLink> rowIndexToLinkMap = new LinkedHashMap<>(); // 记录每行创建的link

                    // 第一遍循环：创建所有主料
                    for (int i = 0; i < rows.size(); i++) {
                        BOMRowData row = rows.get(i);

                        // 获取子部件（主料）
                        WTPart childPart = getWTPartByNumber(row.childNumber);
                        if (childPart == null) {
                            errorMessages.add("第 " + row.rowNum + " 行：子部件不存在：" + row.childNumber);
                            logger.error("第 {} 行：子部件不存在：{}", row.rowNum, row.childNumber);
                            continue;
                        }

                        try {
                            WTPartUsageLink link = null;
                            // 创建UsageLink
                            List<WTPartUsageLink> linkByPart = getLinkByPart(parentPart, childPart);
                            if (linkByPart.size() > 0) {
                                link = linkByPart.get(0);
                                logger.debug("使用已存在的link");
                            } else {
                                link = WTPartUsageLink.newWTPartUsageLink(parentPart, childPart.getMaster());
                            }

                            // 设置数量
                            if (StringUtils.isNotBlank(row.quantity)) {
                                try {
                                    double qty = Double.parseDouble(row.quantity);
                                    Quantity quantity = Quantity.newQuantity(qty, QuantityUnit.EA);
                                    link.setQuantity(quantity);
                                } catch (NumberFormatException e) {
                                    errorMessages.add("第 " + row.rowNum + " 行：数量格式错误");
                                    logger.error("第 {} 行：数量格式错误", row.rowNum);
                                }
                            }

                            // 保存link
                            link = (WTPartUsageLink) PersistenceHelper.manager.save(link);

                            // 设置行号IBA属性（如果有）
                            if (StringUtils.isNotBlank(row.lineNumber)) {
                                IBAUtil ibaUtil = new IBAUtil(link);

                                // 格式化为4位数字，前面补零
                                String formattedLineNumber = formatLineNumber(row.lineNumber);

                                ibaUtil.setIBAAttribute4AllType(link, Constant.AI_LineNumber, formattedLineNumber);
                                logger.info("设置行号: {} -> {}", row.lineNumber, formattedLineNumber);
                            }
                            // 记录这个link
                            if (StringUtils.isNotBlank(row.lineNumber)) {
                                mainPartLinks.put(row.lineNumber, link);
                            }
                            rowIndexToLinkMap.put(i, link);

                            logger.info("创建主料: {}，行号：{}", row.childNumber, row.lineNumber);

                        } catch (Exception e) {
                            errorMessages.add("第 " + row.rowNum + " 行：创建主料失败 - " + e.getMessage());
                            logger.error("第 {} 行：创建主料失败", row.rowNum, e);
                            throw e;
                        }
                    }

                    // 第二遍循环：创建替代料关系
                    for (int i = 0; i < rows.size(); i++) {
                        BOMRowData row = rows.get(i);

                        // 如果这一行有替代料
                        if (StringUtils.isNotBlank(row.substituteNumber)) {
                            try {
                                // 找到这个替代料对应的主料Link
                                WTPartUsageLink mainLink = rowIndexToLinkMap.get(i);

                                if (mainLink == null) {
                                    errorMessages.add("第 " + row.rowNum + " 行：找不到对应的主料Link");
                                    logger.error("第 {} 行：找不到对应的主料Link", row.rowNum);
                                    continue;
                                }

                                // 获取替代料部件
                                WTPart subPart = getWTPartByNumber(row.substituteNumber);
                                if (subPart == null) {
                                    errorMessages.add("第 " + row.rowNum + " 行：替代料不存在：" + row.substituteNumber);
                                    logger.error("第 {} 行：替代料不存在：{}", row.rowNum, row.substituteNumber);
                                    continue;
                                }

                                // 检查替代料关系是否已存在
                                WTPartSubstituteLink subLink = isExistSubPart(mainLink, row.substituteNumber);
                                if (subLink == null) {
                                    // 创建替代料关系
                                    subLink = WTPartSubstituteLink.newWTPartSubstituteLink(mainLink, subPart.getMaster());
                                    PersistenceServerHelper.manager.insert(subLink);
                                    subLink = (WTPartSubstituteLink) PersistenceHelper.manager.refresh(subLink);
                                    logger.info("创建替代料关系: {} 为主料 {} 的替代料", row.substituteNumber, row.childNumber);
                                } else {
                                    logger.info("替代料关系已存在: {}", row.substituteNumber);
                                }

                                // 设置优先级
                                if (StringUtils.isNotBlank(row.priority)) {
                                    IBAUtil ibaUtil = new IBAUtil(subLink);
                                    // 格式化为两位数
                                    String priorityValue = String.format("%02d", Integer.parseInt(row.priority));
                                    ibaUtil.setIBAAttribute4AllType(subLink, "AI_Priority", priorityValue);
                                    logger.info("设置优先级: {}", priorityValue);
                                }

                            } catch (Exception e) {
                                errorMessages.add("第 " + row.rowNum + " 行：创建替代料失败 - " + e.getMessage());
                                logger.error("第 {} 行：创建替代料失败", row.rowNum, e);
                                throw e;
                            }
                        }
                    }

                    logger.info("父项 {} 处理完成", parentNumber);

                } catch (Exception e) {
                    errorMessages.add("处理父项 " + parentNumber + " 时发生异常：" + e.getMessage());
                    logger.error("处理父项 {} 时发生异常", parentNumber, e);
                    throw e;
                }
            }

            // ========== 第三步：检入所有部件（统一检入） ==========
            if (errorMessages.isEmpty()) {
                logger.info("\n===== 开始检入所有部件 =====");
                for (String parentNumber : checkedOutParts) {
                    WTPart parentPart = parentPartMap.get(parentNumber);
                    if (parentPart != null && WorkInProgressHelper.isCheckedOut(parentPart)) {
                        WorkInProgressHelper.service.checkin(parentPart, "BOM导入修改（含替代料）");
                        logger.info("检入部件：{}", parentNumber);
                    }
                }
                trx.commit();
                trx = null;
                String successMsg = "导入成功，共处理 " + bomDataMap.size() + " 个父项";
                logger.info(successMsg);
                return successMsg;
            } else {
                throw new WTException("导入失败，错误信息：" + String.join("; ", errorMessages));
            }

        } catch (Exception e) {
            logger.error("导入过程中发生异常", e);
            if (trx != null) {
                try {
                    trx.rollback();
                    logger.info("事务已回滚");
                } catch (Exception e2) {
                    logger.error("回滚事务失败", e2);
                }
            }
            // 强制检入已检出的部件
            for (String parentNumber : checkedOutParts) {
                WTPart parentPart = getWTPartByNumber(parentNumber);
                if (parentPart != null && WorkInProgressHelper.isCheckedOut(parentPart)) {
                    try {
                        WorkInProgressHelper.service.checkin(parentPart, "异常回滚后强制检入");
                        logger.info("强制检入部件：{}", parentNumber);
                    } catch (Exception e2) {
                        logger.error("强制检入部件 {} 失败", parentNumber, e2);
                    }
                }
            }
            return "导入失败：" + e.getMessage();
        }
    }

    /**
     * 预校验BOM数据
     */
    private static Map<String, List<BOMRowData>> preValidateBOMData(Workbook workbook, List<String> errorMessages) {
        Map<String, List<BOMRowData>> bomDataMap = new LinkedHashMap<>();
        Set<String> allPartNumbers = new HashSet<>();

        Sheet sheet = workbook.getSheetAt(0);
        DataFormatter formatter = new DataFormatter();

        // 从第4行开始读取（0-based，所以索引3是第4行）
        for (int rowNum = 3; rowNum <= sheet.getLastRowNum(); rowNum++) {
            Row row = sheet.getRow(rowNum);
            if (isRowEmpty(row)) {
                logger.debug("第 {} 行为空，停止读取", rowNum + 1);
                break;
            }

            BOMRowData rowData = new BOMRowData();
            rowData.rowNum = rowNum + 1;  // Excel显示的行号

            // 读取各列数据
//            rowData.parentNumber = getCellValueAsString(row.getCell(1));  // B列：父项料号
//            rowData.childNumber = getCellValueAsString(row.getCell(2));   // C列：子项料号
//            rowData.quantity = getCellValueAsString(row.getCell(3));      // D列：使用数量
//            rowData.lineNumber = getCellValueAsString(row.getCell(4));    // E列：新行号
//            rowData.substituteNumber = getCellValueAsString(row.getCell(5)); // F列：替代料
//            rowData.priority = getCellValueAsString(row.getCell(6));      // G列：优先级

            rowData.parentNumber = getCellValueAsString(row.getCell(1));   // B列：父项料号
            rowData.parentName = getCellValueAsString(row.getCell(2));     // C列：父料名称
            rowData.childNumber = getCellValueAsString(row.getCell(3));    // D列：子项料号
            rowData.childName = getCellValueAsString(row.getCell(4));      // E列：子料名
            rowData.quantity = getCellValueAsString(row.getCell(5));       // F列：使用数量
            rowData.lineNumber = getCellValueAsString(row.getCell(6));     // G列：新行号
            rowData.substituteNumber = getCellValueAsString(row.getCell(7)); // H列：替代料号
            rowData.substituteName = getCellValueAsString(row.getCell(8));   // I列：替代料名
            rowData.priority = getCellValueAsString(row.getCell(9));       // J列：优先级




            logger.debug("读取行{}: {}", rowData.rowNum, rowData);

            // 基础校验
            if (StringUtils.isBlank(rowData.parentNumber)) {
                errorMessages.add("第 " + rowData.rowNum + " 行：父项料号不能为空");
                logger.error("第 {} 行：父项料号不能为空", rowData.rowNum);
                continue;
            }

            if (StringUtils.isBlank(rowData.childNumber)) {
                errorMessages.add("第 " + rowData.rowNum + " 行：子项料号不能为空");
                logger.error("第 {} 行：子项料号不能为空", rowData.rowNum);
                continue;
            }

            // 如果这一行有替代料，校验优先级
            if (StringUtils.isNotBlank(rowData.substituteNumber)) {
                if (StringUtils.isBlank(rowData.priority)) {
                    errorMessages.add("第 " + rowData.rowNum + " 行：替代料必须填写优先级");
                    logger.error("第 {} 行：替代料必须填写优先级", rowData.rowNum);
                } else {
                    try {
                        int priority = Integer.parseInt(rowData.priority);
                        if (priority < 1 || priority > 99) {
                            errorMessages.add("第 " + rowData.rowNum + " 行：优先级必须在1-99之间");
                            logger.error("第 {} 行：优先级必须在1-99之间", rowData.rowNum);
                        }
                    } catch (NumberFormatException e) {
                        errorMessages.add("第 " + rowData.rowNum + " 行：优先级必须是数字");
                        logger.error("第 {} 行：优先级必须是数字", rowData.rowNum);
                    }
                }
            }

            // 收集所有部件编号
            allPartNumbers.add(rowData.parentNumber);
            allPartNumbers.add(rowData.childNumber);
            if (StringUtils.isNotBlank(rowData.substituteNumber)) {
                allPartNumbers.add(rowData.substituteNumber);
            }

            // 按父项分组
            bomDataMap.computeIfAbsent(rowData.parentNumber, k -> new ArrayList<>()).add(rowData);
        }

        // 如果有错误，直接返回
        if (!errorMessages.isEmpty()) {
            return bomDataMap;
        }

        // 校验所有部件是否存在
        logger.info("开始校验部件是否存在...");
        for (String partNumber : allPartNumbers) {
            try {
                WTPart part = getWTPartByNumber(partNumber);
                if (part == null) {
                    errorMessages.add("部件不存在：" + partNumber);
                    logger.error("部件不存在：{}", partNumber);
                }
            } catch (Exception e) {
                errorMessages.add("校验部件 " + partNumber + " 时发生异常：" + e.getMessage());
                logger.error("校验部件 {} 时发生异常", partNumber, e);
            }
        }

        String[] noAllowStates = PropertiesUtil.getValueByKey("ai.noAllowRevision.state").split(",");
        // 校验父项部件状态
        for (String parentNumber : bomDataMap.keySet()) {
            try {
                WTPart parentPart = getWTPartByNumber(parentNumber);
                if (parentPart == null) {
                    errorMessages.add("父项部件不存在：" + parentNumber);
                    logger.error("父项部件不存在：{}", parentNumber);
                    continue;
                }

                // 检出校验
                if (WorkInProgressHelper.isCheckedOut(parentPart)) {
                    errorMessages.add("父项部件 " + parentNumber + " 已被他人检出，请稍后重试");
                    logger.error("父项部件 {} 已被他人检出，请稍后重试", parentNumber);
                }

                String state = parentPart.getState().toString();
                String display = parentPart.getLifeCycleState().getDisplay();
                for (String noAllowState : noAllowStates) {
                    if (noAllowState.equals(state)) {
                        errorMessages.add("父项部件 " + parentNumber + ", 状态 :" + display + " 禁止创建或修改BOM");
                        logger.error("父项部件 {}, 状态 :{} 禁止创建或修改BOM", parentNumber, state);
                    }
                }

            } catch (Exception e) {
                errorMessages.add("校验父项 " + parentNumber + " 状态时发生异常：" + e.getMessage());
                logger.error("校验父项 {} 状态时发生异常", parentNumber, e);
            }
        }

        // 校验子项部件状态
        String[] sonNoAllowStates = PropertiesUtil.getValueByKey("ai.sonNoAllowRevision.state").split(",");
        Set<String> validatedChildParts = new HashSet<>();  // 避免重复校验同一个子部件

        for (List<BOMRowData> bomRows : bomDataMap.values()) {
            for (BOMRowData rowData : bomRows) {
                // 校验子项
                if (StringUtils.isNotBlank(rowData.childNumber) && !validatedChildParts.contains(rowData.childNumber)) {
                    validatedChildParts.add(rowData.childNumber);
                    try {
                        WTPart childPart = getWTPartByNumber(rowData.childNumber);
                        if (childPart != null) {
                            String state = childPart.getState().toString();
                            String display = childPart.getLifeCycleState().getDisplay();
                            for (String noAllowState : sonNoAllowStates) {
                                if (noAllowState.equals(state)) {
                                    errorMessages.add("子项部件 " + rowData.childNumber + ", 状态 :" + display + " 不允许作为BOM子项");
                                    logger.error("子项部件 {}, 状态 :{} 不允许作为BOM子项", rowData.childNumber, state);
                                }
                            }
                        }
                    } catch (Exception e) {
                        errorMessages.add("校验子项 " + rowData.childNumber + " 状态时发生异常：" + e.getMessage());
                        logger.error("校验子项 {} 状态时发生异常", rowData.childNumber, e);
                    }
                }

                // 校验替代料
                if (StringUtils.isNotBlank(rowData.substituteNumber) && !validatedChildParts.contains(rowData.substituteNumber)) {
                    validatedChildParts.add(rowData.substituteNumber);
                    try {
                        WTPart substitutePart = getWTPartByNumber(rowData.substituteNumber);
                        if (substitutePart != null) {
                            String state = substitutePart.getState().toString();
                            String display = substitutePart.getLifeCycleState().getDisplay();
                            for (String noAllowState : sonNoAllowStates) {
                                if (noAllowState.equals(state)) {
                                    errorMessages.add("替代料部件 " + rowData.substituteNumber + ", 状态 :" + display + " 不允许作为BOM子项");
                                    logger.error("替代料部件 {}, 状态 :{} 不允许作为BOM子项", rowData.substituteNumber, state);
                                }
                            }
                        }
                    } catch (Exception e) {
                        errorMessages.add("校验替代料 " + rowData.substituteNumber + " 状态时发生异常：" + e.getMessage());
                        logger.error("校验替代料 {} 状态时发生异常", rowData.substituteNumber, e);
                    }
                }
            }
        }

        return bomDataMap;
    }

    /**
     * 删除所有现有的子项关系（包括替代料）
     */
    private static void deleteAllChildLinks(WTPart parentPart) throws Exception {
        QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(parentPart);
        List<WTPartUsageLink> linksToDelete = new ArrayList<>();

        while (qr.hasMoreElements()) {
            WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
            linksToDelete.add(link);
        }

        for (WTPartUsageLink link : linksToDelete) {
            // 先删除替代料关系
            List<WTPartSubstituteLink> subLinks = getWTPartSubstituteLinks(link);
            for (WTPartSubstituteLink subLink : subLinks) {
                PersistenceServerHelper.manager.remove(subLink);
                logger.debug("删除替代料关系");
            }

            // 删除UsageLink
            PersistenceServerHelper.manager.remove(link);
        }

        logger.info("删除父项 {} 的所有子项，共 {} 个", parentPart.getNumber(), linksToDelete.size());
    }




    /**
     * 检出部件
     */
    private static WTPart checkoutPart(WTPart part) throws Exception {
        if (part == null) return null;

        // 如果已经是工作副本，直接返回
        if (WorkInProgressHelper.isWorkingCopy(part)) {
            return part;
        }

        // 检出部件
        Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
        CheckoutLink checkoutLink = WorkInProgressHelper.service.checkout(part, checkoutFolder, "BOM导入检出");
        return (WTPart) checkoutLink.getWorkingCopy();
    }


    //导出BOM  WTPart转换成对象
    public static List<BOMRowData> getBOMData(WTPart part) throws Exception {
        List<BOMRowData> bomRowDataList = new ArrayList<>();


        String parentNumber = part.getNumber();
        String parentName = part.getName();
        int rowNum = 0;
        //获取子料
        List<WTPartUsageLink> partUsageLinks = PartUtil.getSortLinksByPart(part);

        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            rowNum++;
            BOMRowData bomRowDataMain = new BOMRowData();
            WTPartMaster childMaster = partUsageLink.getUses();
            String childNumber = childMaster.getNumber();
            String childName = childMaster.getName();
            String amount = String.valueOf(partUsageLink.getQuantity().getAmount());
            IBAUtil usageLinkIba = new IBAUtil(partUsageLink);
            String lineNumber = usageLinkIba.getIBAValue(Constant.AI_LineNumber);


            bomRowDataMain.rowNum = rowNum;
            bomRowDataMain.parentNumber = cleanString(parentNumber);
            bomRowDataMain.parentName = cleanString(parentName);
            bomRowDataMain.childNumber = cleanString(childNumber);
            bomRowDataMain.childName = cleanString(childName);
            bomRowDataMain.quantity = cleanString(amount);
            bomRowDataMain.lineNumber = cleanString(lineNumber);

            //添加到集合
            bomRowDataList.add(bomRowDataMain);

            List<WTPartSubstituteLink> wtPartSubstituteLinks = sortSubstituteLinksByPriority(PartUtil.getWTPartSubstituteLinks(partUsageLink));
            //生成替代料行
            for (WTPartSubstituteLink wtPartSubstituteLink : wtPartSubstituteLinks) {

                rowNum++;
                BOMRowData bomRowDataSubstitute = new BOMRowData();

                WTPartMaster substitutesMaster = wtPartSubstituteLink.getSubstitutes();
                String substitutesNumber = substitutesMaster.getNumber();
                String substitutesName = substitutesMaster.getName();
                IBAUtil substitutesLinkIBA = new IBAUtil(wtPartSubstituteLink);
                String priority = substitutesLinkIBA.getIBAValue(Constant.AI_Priority);

                bomRowDataSubstitute.rowNum = rowNum;
                bomRowDataSubstitute.parentNumber =cleanString(parentNumber);
                bomRowDataSubstitute.parentName = cleanString(parentName);
                bomRowDataSubstitute.childNumber =  cleanString(childNumber);
                bomRowDataSubstitute.childName = cleanString(childName);
                bomRowDataSubstitute.quantity = cleanString(amount);
                bomRowDataSubstitute.substituteNumber = cleanString(substitutesNumber);
                bomRowDataSubstitute.substituteName = cleanString(substitutesName);
//                bomRowDataMain.lineNumber = lineNumber;
                bomRowDataSubstitute.priority = cleanString(priority);



                //添加替代料到集合
                bomRowDataList.add(bomRowDataSubstitute);

            }

        }
        return bomRowDataList;

    }


    public static List<PCBABOMRowData> getPCBABOMData(WTPart part) throws Exception {
        List<PCBABOMRowData> bomRowDataList = new ArrayList<>();

        String parentNumber = part.getNumber();
        int groupCounter = 1; // 替代料群组计数器
        int excelRowIndex = 2; // Excel实际行号（从2开始，假设第1行是表头）

        // 获取子料
        List<WTPartUsageLink> partUsageLinks = PartUtil.getSortLinksByPart(part);

        // 第一步：先收集所有主料数据，只对纯数字行号分组计算基本用量
        Map<String, List<WTPartUsageLink>> lineNumberGroupMap = new HashMap<>();

        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            IBAUtil usageLinkIba = new IBAUtil(partUsageLink);
            String lineNumber = usageLinkIba.getIBAValue(Constant.AI_LineNumber);

            // 只对纯数字行号进行分组
            if (isNumericLineNumber(lineNumber)) {
                if (!lineNumberGroupMap.containsKey(lineNumber)) {
                    lineNumberGroupMap.put(lineNumber, new ArrayList<>());
                }
                lineNumberGroupMap.get(lineNumber).add(partUsageLink);
            }
        }

        // 第二步：计算每个纯数字行号的基本用量总和
        Map<String, Double> lineNumberBaseNumMap = new HashMap<>();
        for (Map.Entry<String, List<WTPartUsageLink>> entry : lineNumberGroupMap.entrySet()) {
            String lineNumber = entry.getKey();
            List<WTPartUsageLink> links = entry.getValue();
            double sum = 0;
            for (WTPartUsageLink link : links) {
                sum += link.getQuantity().getAmount();
            }
            lineNumberBaseNumMap.put(lineNumber, sum);
        }

        // 第三步：生成数据
        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            PCBABOMRowData bomRowDataMain = new PCBABOMRowData();
            WTPartMaster childMaster = partUsageLink.getUses();
            String childNumber = childMaster.getNumber();
            String childName = childMaster.getName();
            String quantity = String.valueOf(partUsageLink.getQuantity().getAmount());
            IBAUtil usageLinkIba = new IBAUtil(partUsageLink);
            String lineNumber = usageLinkIba.getIBAValue(Constant.AI_LineNumber);
            String placementSide = usageLinkIba.getIBAValue(Constant.AI_Placement_Side);
            String lossRate = usageLinkIba.getIBAValue(Constant.AI_LossRate);
            String occurrence = PartUtil.getUsageLinkPartUsesOccurrence(partUsageLink);

            // 获取替代料列表，并按优先级排序
            List<WTPartSubstituteLink> substituteLinks = PartUtil.getWTPartSubstituteLinks(partUsageLink);
            if (substituteLinks != null && !substituteLinks.isEmpty()) {
                substituteLinks = sortSubstituteLinksByPriority(substituteLinks);
            }

            // 判断是否有替代料
            boolean hasSubstitute = substituteLinks != null && !substituteLinks.isEmpty();

            // 计算群组号
            String groupNum = "";
            if (hasSubstitute) {
                groupNum = getGroupNumber(groupCounter);
                groupCounter++;
            }

            // 基本用量：只有纯数字行号才从Map中获取
            String baseNum = "";
            if (isNumericLineNumber(lineNumber)) {
                baseNum = String.valueOf(lineNumberBaseNumMap.get(lineNumber));
            }else{
                // 非纯数字行号，基本用量可以设置为空字符串或者自身的quantity
//                baseNum = ""; // 或者 baseNum = quantity;
                baseNum = quantity;
            }

            // 设置主料数据
            bomRowDataMain.rowNum = excelRowIndex;
            bomRowDataMain.parentNumber = cleanString(parentNumber);
            bomRowDataMain.childNumber = cleanString(childNumber);
            bomRowDataMain.childName = cleanString(childName);
            bomRowDataMain.quantity = cleanString(quantity);
            bomRowDataMain.lineNumber = cleanString(lineNumber); // 主料业务行号保持不变
            bomRowDataMain.placementSide = cleanString(placementSide);
            bomRowDataMain.lossRate = cleanString(lossRate);
            bomRowDataMain.occurrence = cleanString(occurrence);
            bomRowDataMain.baseNum = cleanString(baseNum);
            bomRowDataMain.groupNum = cleanString(groupNum);
            bomRowDataMain.priority = hasSubstitute ? "01" : "";
            bomRowDataMain.strategy = hasSubstitute ? "1" : "";
            bomRowDataMain.usageProb = hasSubstitute ? "100" : "";

            // 添加到集合
            bomRowDataList.add(bomRowDataMain);

            // Excel行号递增
            excelRowIndex++;

            // 生成替代料行（如果有）
            if (hasSubstitute) {
                // 解析主料的业务行号，用于生成替代料的业务行号
                int mainLineNumber = 0;
                try {
                    mainLineNumber = Integer.parseInt(lineNumber);
                } catch (NumberFormatException e) {
                    // 如果主料行号不是数字，则从1开始
                    mainLineNumber = 0;
                }

                int substituteLineNumberCounter = 1; // 替代料业务行号计数器

                for (WTPartSubstituteLink substituteLink : substituteLinks) {
                    PCBABOMRowData bomRowDataSubstitute = new PCBABOMRowData();

                    WTPartMaster substituteMaster = substituteLink.getSubstitutes();
                    String substituteNumber = substituteMaster.getNumber();
                    String substituteName = substituteMaster.getName();
                    IBAUtil substituteLinkIBA = new IBAUtil(substituteLink);
                    String priority = substituteLinkIBA.getIBAValue(Constant.AI_Priority);

                    // 生成替代料的业务行号：主料行号 + 计数器
                    String substituteLineNumber = String.format("%04d", mainLineNumber + substituteLineNumberCounter);

                    bomRowDataSubstitute.rowNum = excelRowIndex;
                    bomRowDataSubstitute.parentNumber = cleanString(parentNumber);
                    bomRowDataSubstitute.childNumber = cleanString(substituteNumber);
                    bomRowDataSubstitute.childName = cleanString(substituteName);
                    bomRowDataSubstitute.quantity = cleanString(quantity);
                    bomRowDataSubstitute.lineNumber = substituteLineNumber; // 替代料业务行号递增
                    bomRowDataSubstitute.placementSide = cleanString(placementSide);
                    bomRowDataSubstitute.lossRate = cleanString(lossRate);
                    bomRowDataSubstitute.occurrence = cleanString(occurrence);
                    bomRowDataSubstitute.baseNum = cleanString(baseNum);
                    bomRowDataSubstitute.groupNum = cleanString(groupNum);
                    bomRowDataSubstitute.priority = cleanString(priority);
                    bomRowDataSubstitute.strategy = "1"; // 替代料策略为空
                    bomRowDataSubstitute.usageProb = "0"; // 替代料使用率为0

                    bomRowDataList.add(bomRowDataSubstitute);

                    // 计数器递增
                    substituteLineNumberCounter++;
                    excelRowIndex++;
                }
            }
        }
        return bomRowDataList;
    }




    /**
     * 生成替代项目群组编号
     */
    private static String getGroupNumber(int counter) {
        if (counter <= 99) {
            return String.format("%02d", counter);
        }

        int adjusted = counter - 99;
        if (adjusted <= 9 * 26) {
            int num = (adjusted - 1) / 26;
            int letter = (adjusted - 1) % 26;
            return (num + 1) + String.valueOf((char) ('A' + letter));
        }

        adjusted = adjusted - 9 * 26;
        int firstLetter = (adjusted - 1) / 26;
        int secondLetter = (adjusted - 1) % 26;
        return String.valueOf((char) ('A' + firstLetter)) +
                String.valueOf((char) ('A' + secondLetter));
    }
    /**
     * 判断行号是否为纯数字
     */
    private static boolean isNumericLineNumber(String lineNumber) {
        if (lineNumber == null || lineNumber.isEmpty()) {
            return false;
        }
        // 去除空格后判断是否全为数字
        return lineNumber.trim().matches("\\d+");
    }


    /**
     * 对替代料列表按优先级排序
     *
     * @param partSubstituteLinks 替代料链接列表
     * @return 排序后的替代料列表
     */
    private static List<WTPartSubstituteLink> sortSubstituteLinksByPriority(List<WTPartSubstituteLink> partSubstituteLinks) {
        if (partSubstituteLinks == null || partSubstituteLinks.isEmpty()) {
            return partSubstituteLinks;
        }

        Collections.sort(partSubstituteLinks, new Comparator<WTPartSubstituteLink>() {
            @Override
            public int compare(WTPartSubstituteLink o1, WTPartSubstituteLink o2) {
                try {
                    IBAUtil iba1 = new IBAUtil(o1);
                    IBAUtil iba2 = new IBAUtil(o2);

                    String priority1 = iba1.getIBAValue(Constant.AI_Priority);
                    String priority2 = iba2.getIBAValue(Constant.AI_Priority);

                    // 处理空优先级（空值排在最后）
                    if (StringUtils.isBlank(priority1) && StringUtils.isBlank(priority2)) {
                        return 0;
                    } else if (StringUtils.isBlank(priority1)) {
                        return 1;
                    } else if (StringUtils.isBlank(priority2)) {
                        return -1;
                    }

                    // 都是数字，按数值比较
                    try {
                        int p1 = Integer.parseInt(priority1);
                        int p2 = Integer.parseInt(priority2);
                        return Integer.compare(p1, p2);
                    } catch (NumberFormatException e) {
                        return priority1.compareTo(priority2);
                    }
                } catch (WTException e) {
                    return 0;
                }
            }
        });

        return partSubstituteLinks;
    }


    //获取系统BOM模板
    public InputStream getBomExcelModel(String docNumber) throws WTException {
        WTDocument document = (WTDocument) WTDocumentUtil.getObjByNumber(docNumber, WTDocument.class);
        ApplicationData applicationData = WTDocumentUtil.getWTDocPrimary(document);
        InputStream is = ContentServerHelper.service.findContentStream(applicationData);

        return is;
    }


    // 位置：在 ExportService 类末尾添加这个方法
    /**
     * 清洗字符串：去除首尾空格，处理特殊字符
     * 【修改点5】可选的数据清洗方法，用于更严格的清洗
     */
    private static String cleanString(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }

        // 1. 去除首尾空格
        String cleaned = input.trim();

        // 2. 将多个连续空格替换为单个空格
        cleaned = cleaned.replaceAll("\\s+", " ");

        // 3. 去除不可见字符（如制表符、换行符等）
        cleaned = cleaned.replaceAll("[\\t\\n\\r]", "");

        return cleaned;
    }


}
