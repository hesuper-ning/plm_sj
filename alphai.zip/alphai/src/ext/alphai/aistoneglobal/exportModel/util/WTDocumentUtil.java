package ext.alphai.aistoneglobal.exportModel.util;

import org.apache.commons.lang3.StringUtils;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;

import java.beans.PropertyVetoException;

public class WTDocumentUtil {

    /**
     * 根据编号获取对象
     *
     * @param number
     * @param Class
     * @return Object
     */
    @SuppressWarnings("deprecation")
    public static Object getObjByNumber(String number, Class queryClass) {
        try {
            if (StringUtils.isBlank(number)) {
                return null;
            }

            QuerySpec qs = new QuerySpec(queryClass);
            qs.appendWhere(new SearchCondition(queryClass, "master>number", SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                return qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取文档主要内容
     * @param document
     * @return
     */
    public static ApplicationData getWTDocPrimary(WTDocument document) {


        ApplicationData appData = new ApplicationData();
        try {

            ContentHolder contentHolder = ContentHelper.service.getContents(document);
            //然后获取主文件
            QueryResult qr = ContentHelper.service.getContentsByRole(contentHolder, ContentRoleType.PRIMARY);
            if (qr != null && qr.hasMoreElements()) {
                appData = (ApplicationData) qr.nextElement();
            }
        } catch (WTException e) {
            e.printStackTrace();
        } catch (PropertyVetoException e) {
            e.printStackTrace();
        }
        return appData;
    }
}
