package ext.alphai.aistoneglobal.exportModel.entity;

public class BOMRowData {

    public int rowNum;              // Excel行号
    public String parentNumber;     // 父项料号
    public String parentName;     // 父项料号
    public String childNumber;      // 子项料号（主料）
    public String childName;      // 子项料号（主料）
    public String quantity;         // 使用数量
    public String lineNumber;       // 新行号（可选）
    public String substituteNumber; // 替代料料号
    public String substituteName; // 替代料料号
    public String priority;         // 优先级

    @Override
    public String toString() {
        return "BOMRowData{" +
                "rowNum=" + rowNum +
                ", parentNumber='" + parentNumber + '\'' +
                ", parentName='" + parentName + '\'' +
                ", childNumber='" + childNumber + '\'' +
                ", childName='" + childName + '\'' +
                ", quantity='" + quantity + '\'' +
                ", lineNumber='" + lineNumber + '\'' +
                ", substituteNumber='" + substituteNumber + '\'' +
                ", substituteName='" + substituteName + '\'' +
                ", priority='" + priority + '\'' +
                '}';
    }
}
