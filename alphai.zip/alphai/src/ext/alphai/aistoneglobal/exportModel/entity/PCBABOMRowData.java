package ext.alphai.aistoneglobal.exportModel.entity;

public class PCBABOMRowData {
    public int rowNum;              // Excel行号
    public String parentNumber;     // 父项料号 (第1列)
    public String lineNumber;       // 行号 (第7列)
    public String childNumber;      // 子项料号 (第9列)
    public String childName;      // 子项描述 (第10列)
    public String baseNum;      // 基本用量 (第11列)
    public  String lossRate;         // 损耗率 (第12列)
    public  String groupNum;         // 替代项目群组 (第13列)
    public String priority;       // 优先级 (第14列)
    public String strategy;       // 策略 (第15列)
    public String usageProb;       // 使用率 (第16列)
    public String occurrence;       // 位号 (第17列)
    public String quantity;         // 使用数量 (第18列)
    public  String placementSide;    // 安装面 (第19列)


}
