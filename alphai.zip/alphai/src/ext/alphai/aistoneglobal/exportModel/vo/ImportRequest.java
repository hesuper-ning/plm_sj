package ext.alphai.aistoneglobal.exportModel.vo;

import org.springframework.web.multipart.MultipartFile;

public  class ImportRequest {
    private String oid;
    private MultipartFile excelFile;

    // 必须有无参构造函数
    public ImportRequest() {
    }

    public ImportRequest(String oid, MultipartFile excelFile) {
        this.oid = oid;
        this.excelFile = excelFile;
    }

    // getter 和 setter
    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public MultipartFile getExcelFile() {
        return excelFile;
    }

    public void setExcelFile(MultipartFile excelFile) {
        this.excelFile = excelFile;
    }
}