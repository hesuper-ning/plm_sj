package ext.alphai.aistoneglobal.document.process;

import com.ptc.core.components.forms.EditWorkableFormProcessor;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.doc.forms.CreateDocFormProcessor;
import ext.alphai.aistoneglobal.document.service.DocRelationship;
import ext.alphai.aistoneglobal.document.util.IBAUtil;
import ext.alphai.aistoneglobal.document.util.PropertiesUtil;
import org.apache.commons.lang3.StringUtils;
import wt.change2.WTChangeReview;
import wt.doc.WTDocument;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.List;


public class CusEditWorkableFormProcessor extends EditWorkableFormProcessor {

    public final String PART_TYPE = "WTPart";
    public final String REVIEW_TYPE = "WTChangeReview";


    public final String DOC_IBA_AI_DOCTYPE = "AI_DocType";//文档类型


    public static DocRelationship docRelationship = new DocRelationship();


    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = super.postProcess(nmCommandBean, list);
        //新建的文档
        WTDocument doc = docRelationship.getWTDocByBean(list);
        //获取当前用户
        WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
        try {
            //映射配置
            String docMapping = PropertiesUtil.getValueByKey("doc.mapping");
//            String[] allowRelationDocTypes = PropertiesUtil.getValueByKey("doc_relationDocType_Value").split(",");
            //需要执行的映射
            String[] relationMapping = docRelationship.relationMapping(doc, docMapping);
            if (StringUtils.isNotBlank(docMapping) && relationMapping != null) {
                //
                IBAUtil docIBAUtil = new IBAUtil(doc);
                //  关联的部件/审阅的编号
                String associatedTypeNumber = docIBAUtil.getIBAValue(relationMapping[1]);//被关联类型的编号
                //文档属性：文档类型
//                String docType = docIBAUtil.getIBAValue(DOC_IBA_AI_DOCTYPE);

                //被关联的，系统已经校验
//                if (StringUtils.isBlank(associatedTypeNumber) && docRelationship.isRelationDocType(allowRelationDocTypes,docType)) {
//                    //iba属性在类型上的显示名称
//                    String internalDisplayName = docIBAUtil.getInternalDisplayName(relationMapping[1]);
//                    throw new WTException(internalDisplayName + "必填！");
//                }

                //切换成管理员
                SessionHelper.manager.setAdministrator();
                if (StringUtils.isNotBlank(associatedTypeNumber)) {
                    if (relationMapping[2].equals(PART_TYPE)) {
                        //文档属性文档类型是允许关联审阅
//                    if (docRelationship.isRelationDocType(allowRelationDocTypes,docType)) {
                        WTPart wtPartByNumber = docRelationship.getWTPartByNumber(associatedTypeNumber);
                        // 部件不为空，关联文档与部件
                        if (wtPartByNumber != null) {
                            docRelationship.updateDocAndWTPartLink(doc, wtPartByNumber);
                        } else {
                            throw new WTException("未找到编号：" + associatedTypeNumber + "部件！");
//                        }
                        }

                    }
//                    else if (relationMapping[2].equals(REVIEW_TYPE)) {
//                        WTChangeReview wtChangeReviewByNumber = docRelationship.getWTChangeReviewByNumber(associatedTypeNumber);
//                        if (wtChangeReviewByNumber != null) {
//                            docRelationship.addDocAndWTChangeReviewLink(doc, wtChangeReviewByNumber);
//                        } else {
//                            throw new WTException("未找到编号：" + associatedTypeNumber + "审阅！");
//                        }
//                    }
                    else {
                        // 如果relationMapping[2]既不是PART_TYPE也不是REVIEW_TYPE
                        throw new WTException("未知的关系类型,请检查配置文件是否对应WTPart/WTChangeReview：" + relationMapping[2]);
                    }
                }

            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            //切回当前用户
            SessionHelper.manager.setPrincipal(currentUser.getName());
        }
        return formResult;
    }
}
