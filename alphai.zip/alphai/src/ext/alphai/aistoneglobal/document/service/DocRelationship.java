package ext.alphai.aistoneglobal.document.service;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeReviewItemLink;
import wt.change2.WTChangeReview;
import wt.doc.WTDocument;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.*;
import wt.fc.collections.WTHashSet;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartMaster;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class DocRelationship {

    public WTDocument getWTDocByBean(List<ObjectBean> list){
        WTDocument doc = (!list.isEmpty())
                ? (list.get(0).getObject() instanceof WTDocument ? (WTDocument) list.get(0).getObject() : null)
                : null;

        return doc;
    }

    /**
     * 校验 文档是否为指定  添加 说明部件的文档类型
     * @param doc
     * @return
     */
    public String [] relationMapping(WTDocument doc,  String docMapping){
        String [] relationType = null;
        String [] docTypes = docMapping.split(";");
        //获取文档子类型
        String docInterName = getDocTypeInternalName(doc);
        for (String docType : docTypes) {
            String[] mapping = docType.split("," );
            //0是待关联的文档子类型类型   1是文档子类型   2是与文档关联的部件/审阅
            if (mapping[0].equals(docInterName)){
                relationType = mapping;
            }
        }
        return relationType;
    }

    /**
     * 文档与审阅关联
     * @param document
     * @param changeReview
     * @throws WTException
     */

    public void addDocAndWTChangeReviewLink(WTDocument document , WTChangeReview changeReview) throws WTException {
        WTHashSet links = new WTHashSet();
        ChangeReviewItemLink changeReviewItemLink = ChangeReviewItemLink.newChangeReviewItemLink(document, changeReview);
        links.add(changeReviewItemLink);
        ChangeHelper2.service.storeAssociations(changeReview,links);
    }


    /**
     * 文档与审阅关联
     * @param document
     * @param changeReview
     * @throws WTException
     */
    public void updateDocAndWTChangeReviewLink(WTDocument document , WTChangeReview changeReview) throws WTException {
        WTHashSet links = new WTHashSet();
        ChangeReviewItemLink changeReviewItemLink = ChangeReviewItemLink.newChangeReviewItemLink(document, changeReview);
        links.add(changeReviewItemLink);
        ChangeHelper2.service.storeAssociations(changeReview,links);
    }

    //文档找审阅
    public static List<ChangeReviewItemLink> findChangeReviewItemLink(WTDocument doc) throws WTException {
        List<ChangeReviewItemLink> links = new ArrayList<>();

        QuerySpec querySpec = new QuerySpec(ChangeReviewItemLink.class);
        String role = BinaryLink.ROLE_BOBJECT_REF + "." + ObjectReference.KEY + "." + ObjectIdentifier.ID;
        long id = PersistenceHelper.getObjectIdentifier(doc).getId();
        SearchCondition sc = new SearchCondition(ChangeReviewItemLink.class, role, SearchCondition.EQUAL, id);
        querySpec.appendWhere(sc, new int[]{0});
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);

        while (queryResult.hasMoreElements()) {
            Object o = queryResult.nextElement();
            if (o instanceof WTPartDescribeLink) {
                ChangeReviewItemLink link = (ChangeReviewItemLink) o;
                links.add(link);
            }
        }
        return links;
    }



    /**
     * 文档与部件关联
     * @param document
     * @param wtPart
     * @throws WTException
     */
    public void addDocAndWTPartLink(WTDocument document , WTPart wtPart) throws WTException {


        WTPartDescribeLink link = WTPartDescribeLink.newWTPartDescribeLink(wtPart, document);
        PersistenceServerHelper.manager.insert(link);
        PersistenceHelper.manager.refresh(link);
    }




    /**
     * 文档与部件关联
     * @param document
     * @param wtPart
     * @throws WTException
     */
    /**
     * 文档与部件关联
     * @param document
     * @param wtPart 最新版本的部件
     * @throws WTException
     */
    public void updateDocAndWTPartLink(WTDocument document, WTPart wtPart) throws WTException {
        // 获取最新版本部件的master
        WTPartMaster latestMaster = wtPart.getMaster();

        // 查找文档与部件所有的关联关系
        List<WTPartDescribeLink> wtPartDescribeLinks = findWTPartDescribeLink(document);

        // 用于标记最新版本关联是否存在
        boolean latestLinkExists = false;

        System.out.println("updateDocAndWTPartLink001---获取全部说明部件");
        // 遍历所有关联
        for (WTPartDescribeLink partDescribeLink : wtPartDescribeLinks) {
            WTPart linkedPart = (WTPart) partDescribeLink.getRoleAObject();
            WTPartMaster linkedMaster = linkedPart.getMaster();

            System.out.println("updateDocAndWTPartLink002---说明部件："+linkedPart.getIdentity());


            System.out.println("updateDocAndWTPartLink002---传入的部件masterIda2a2："+latestMaster.getPersistInfo().getObjectIdentifier());
            System.out.println("updateDocAndWTPartLink002---说明部件的masterIda2a2："+linkedMaster.getPersistInfo().getObjectIdentifier());



            // 检查是否为最新版本
            if (linkedMaster.equals(latestMaster)) {
                latestLinkExists = true; // 最新版本关联已存在
                continue; // 跳过，不删除最新版本
            }

            // 如果不是最新版本的master，则删除该关联
            PersistenceServerHelper.manager.remove(partDescribeLink);
        }

        // 如果最新版本的关联不存在，则创建新的关联
        if (!latestLinkExists) {
            WTPartDescribeLink link = WTPartDescribeLink.newWTPartDescribeLink(wtPart, document);
            PersistenceServerHelper.manager.insert(link);
        }
    }
    //从文档找到说明部件
    public static List<WTPartDescribeLink> findWTPartDescribeLink(WTDocument doc) throws WTException {
        List<WTPartDescribeLink> links = new ArrayList<>();

        QuerySpec querySpec = new QuerySpec(WTPartDescribeLink.class);
        String role = BinaryLink.ROLE_BOBJECT_REF + "." + ObjectReference.KEY + "." + ObjectIdentifier.ID;
        long id = PersistenceHelper.getObjectIdentifier(doc).getId();
        SearchCondition sc = new SearchCondition(WTPartDescribeLink.class, role, SearchCondition.EQUAL, id);
        querySpec.appendWhere(sc, new int[]{0});
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);

        while (queryResult.hasMoreElements()) {
            Object o = queryResult.nextElement();
            if (o instanceof WTPartDescribeLink) {
                WTPartDescribeLink link = (WTPartDescribeLink) o;
                links.add(link);
            }
        }
        return links;
    }





    /**
     * 根据编号查询WTChangeReview
     *
     * @param
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public  WTChangeReview getWTChangeReviewByNumber(String number) {
        WTChangeReview result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTChangeReview.class);
            SearchCondition scnumber = new SearchCondition(WTChangeReview.class, WTChangeReview.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTChangeReview.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (WTChangeReview) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 根据编号查询part
     *
     * @param
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public  WTPart getWTPartByNumber(String number) {
        WTPart result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (WTPart) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    /**
     * 全路径从顶层类型开始|子类型
     * @param persistable
     * @return
     */
    public static String getTypeIdentifier(Persistable persistable) {
        try {
            return TypedUtilityServiceHelper.service.getExternalTypeIdentifier(persistable);
        } catch (WTException var2) {
            var2.printStackTrace();
        } catch (RemoteException var3) {
            var3.printStackTrace();
        }

        return null;
    }


    /**
     * 子类型
     * @param doc
     * @return
     */
    public static String getDocTypeInternalName(WTDocument doc) {
        String InternalName = null;
        TypeDefinitionReference ref = (doc).getTypeDefinitionReference();
        try {
            TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities.getTypeDefinition(ref);
            WTTypeDefinition definition = (WTTypeDefinition) PersistenceHelper.manager.refresh(view.getObjectID());
            InternalName = definition.getName();
        } catch (WTException e) {
            System.out.println("获取文档子类型内部名称出错" + e.getMessage() + e);
        }
        return InternalName;
    }


    public  boolean isRelationDocType(String[]  allowRelationDocTypes, String docType){
        boolean flag = false;

        for (String waitRelationDocType : allowRelationDocTypes) {
            if (waitRelationDocType.equals(docType)) {
                flag = true;
            }
        }
        return flag;
    }
}
