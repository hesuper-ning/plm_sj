package ext.alphai.aistoneglobal.sap.vo;

import com.ptc.windchill.option.model.ChoiceMaster;
import com.ptc.windchill.option.model.Option;
import com.ptc.windchill.option.model.OptionChoiceMasterLink;

import java.util.List;

/**
 * 选项结构类
 */
public class OptionStructureVo {
    public OptionStructureVo() {
    }

    public OptionStructureVo(Option options, List<OptionChoiceMasterLink> optionChoiceMasterLinks, List<ChoiceMaster> choiceMasters) {
        this.options = options;
        this.optionChoiceMasterLinks = optionChoiceMasterLinks;
        this.choiceMasters = choiceMasters;
    }

    public Option getOptions() {
        return options;
    }

    public void setOptions(Option options) {
        this.options = options;
    }

    private Option options;

    private List<OptionChoiceMasterLink> optionChoiceMasterLinks;

    private List<ChoiceMaster>  choiceMasters;
    // 发送结果
    private String type;
    // 发送返回结果
    private String message;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<OptionChoiceMasterLink> getOptionChoiceMasterLinks() {
        return optionChoiceMasterLinks;
    }

    public void setOptionChoiceMasterLinks(List<OptionChoiceMasterLink> optionChoiceMasterLinks) {
        this.optionChoiceMasterLinks = optionChoiceMasterLinks;
    }

    public List<ChoiceMaster> getChoiceMasters() {
        return choiceMasters;
    }

    public void setChoiceMasters(List<ChoiceMaster> choiceMasters) {
        this.choiceMasters = choiceMasters;
    }
}
