package ext.alphai.aistoneglobal.sap.vo;

import java.util.List;

public class BOMItem {
    public String id; //partNumber+lineNumber+UPTXT
    public String bomNum; //
    public String factory;
    public String STLAN="3";
    public String STLAL="1";
    public String STATUS="1";
    public String DATUV;
    public String BASE_QUNA="1";
    public String lineNumber;
    public String ITEM_CATEG="L";
    public String partNumber;
    public String quantity;//子料数量
    public String unit;//单位
    public String lossRate;//损耗率
    public String group;//替代组
    public String priority;//优先级
    public String strategy;//有替代料固定值：1  没有不填
    public String usageProb; //使用策略
    public String ebort;
    public String upmng;
    public String uptxt;
    public String scode;
    public List<BOMItem> substitutePart;
    public String  option;

    @Override
    public String toString() {
        return "BOMItem{" +
                "id='" + id + '\'' +
                ", bomNum='" + bomNum + '\'' +
                ", factory='" + factory + '\'' +
                ", STLAN='" + STLAN + '\'' +
                ", STLAL='" + STLAL + '\'' +
                ", STATUS='" + STATUS + '\'' +
                ", DATUV='" + DATUV + '\'' +
                ", BASE_QUNA='" + BASE_QUNA + '\'' +
                ", lineNumber='" + lineNumber + '\'' +
                ", ITEM_CATEG='" + ITEM_CATEG + '\'' +
                ", partNumber='" + partNumber + '\'' +
                ", quantity='" + quantity + '\'' +
                ", unit='" + unit + '\'' +
                ", lossRate='" + lossRate + '\'' +
                ", group='" + group + '\'' +
                ", priority='" + priority + '\'' +
                ", strategy='" + strategy + '\'' +
                ", usageProb='" + usageProb + '\'' +
                ", ebort='" + ebort + '\'' +
                ", upmng='" + upmng + '\'' +
                ", uptxt='" + uptxt + '\'' +
                ", scode='" + scode + '\'' +
                ", substitutePart=" + substitutePart +
                ", option='" + option + '\'' +
                '}';
    }

    public List<BOMItem> getSubstitutePart() {
        return substitutePart;
    }

    public void setSubstitutePart(List<BOMItem> substitutePart) {
        this.substitutePart = substitutePart;
    }

    public String getOption() {
        return option;
    }

    public void setOption(String option) {
        this.option = option;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBomNum() {
        return bomNum;
    }

    public void setBomNum(String bomNum) {
        this.bomNum = bomNum;
    }

    public String getFactory() {
        return factory;
    }

    public void setFactory(String factory) {
        this.factory = factory;
    }

    public String getSTLAN() {
        return STLAN;
    }

    public void setSTLAN(String STLAN) {
        this.STLAN = STLAN;
    }

    public String getSTLAL() {
        return STLAL;
    }

    public void setSTLAL(String STLAL) {
        this.STLAL = STLAL;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getDATUV() {
        return DATUV;
    }

    public void setDATUV(String DATUV) {
        this.DATUV = DATUV;
    }

    public String getBASE_QUNA() {
        return BASE_QUNA;
    }

    public void setBASE_QUNA(String BASE_QUNA) {
        this.BASE_QUNA = BASE_QUNA;
    }

    public String getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getITEM_CATEG() {
        return ITEM_CATEG;
    }

    public void setITEM_CATEG(String ITEM_CATEG) {
        this.ITEM_CATEG = ITEM_CATEG;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getLossRate() {
        return lossRate;
    }

    public void setLossRate(String lossRate) {
        this.lossRate = lossRate;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public String getUsageProb() {
        return usageProb;
    }

    public void setUsageProb(String usageProb) {
        this.usageProb = usageProb;
    }

    public String getEbort() {
        return ebort;
    }

    public void setEbort(String ebort) {
        this.ebort = ebort;
    }

    public String getUpmng() {
        return upmng;
    }

    public void setUpmng(String upmng) {
        this.upmng = upmng;
    }

    public String getUptxt() {
        return uptxt;
    }

    public void setUptxt(String uptxt) {
        this.uptxt = uptxt;
    }

    public String getScode() {
        return scode;
    }

    public void setScode(String scode) {
        this.scode = scode;
    }
}