package ext.alphai.aistoneglobal.sap.vo;

import com.ptc.windchill.option.model.Option;
import com.ptc.windchill.option.model.OptionSet;

import java.util.List;

/**
 * 选项集结构对象
 */
public class OptionSetStructureVo {
    private OptionSet optionSet;
    private List<OptionStructureVo> structureVos;
    // 发送结果
    private String type;
    // 发送返回结果
    private String message;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public OptionSetStructureVo() {
    }

    public OptionSetStructureVo(OptionSet optionSet, List<OptionStructureVo> structureVos) {
        this.optionSet = optionSet;
        this.structureVos = structureVos;
    }

    public OptionSet getOptionSet() {
        return optionSet;
    }

    public void setOptionSet(OptionSet optionSet) {
        this.optionSet = optionSet;
    }

    public List<OptionStructureVo> getStructureVos() {
        return structureVos;
    }

    public void setStructureVos(List<OptionStructureVo> structureVos) {
        this.structureVos = structureVos;
    }
}
