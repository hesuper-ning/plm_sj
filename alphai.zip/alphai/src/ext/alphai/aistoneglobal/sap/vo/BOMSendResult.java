package ext.alphai.aistoneglobal.sap.vo;

import wt.part.WTPart;

/**
 * 发BOM的返回结果
 */
public class BOMSendResult {
    private boolean success;
    private String errorMessage;
    private WTPart part;

    public BOMSendResult(boolean success, String errorMessage, WTPart part) {
        this.success = success;
        this.errorMessage = errorMessage;
        this.part = part;
    }

    // getter 和 setter 方法
    public boolean isSuccess() { return success; }
    public String getErrorMessage() { return errorMessage; }
    public WTPart getPart() { return part; }
}
