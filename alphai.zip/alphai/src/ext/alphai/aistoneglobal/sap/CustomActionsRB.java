package ext.alphai.aistoneglobal.sap;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.sap.CustomActionsRB")
public class CustomActionsRB extends WTListResourceBundle {

    @RBEntry("Send Part To SAP")
    public static final String PRIVATE_CONSTANT_01 ="SAP.sendPart.description";

    @RBEntry("Send Part To SAP")
    public static final String PRIVATE_CONSTANT_02 ="SAP.sendPart.tooltip";


    @RBEntry("Send OptionSet To SAP")
    public static final String PRIVATE_CONSTANT_03 ="SAP.sendOptionSet.description";

    @RBEntry("Send OptionSet To SAP")
    public static final String PRIVATE_CONSTANT_04 ="SAP.sendOptionSet.tooltip";

    @RBEntry("Send BOM To SAP")
    public static final String PRIVATE_CONSTANT_05 ="SAP.sendBOMWizard.description";

    @RBEntry("Send BOM To SAP")
    public static final String PRIVATE_CONSTANT_06 ="SAP.sendBOMWizard.tooltip";


    @RBEntry("Send BOM To SAP")
    public static final String PRIVATE_CONSTANT_07 ="SAP.sendBOM.description";

    @RBEntry("Send BOM To SAP")
    public static final String PRIVATE_CONSTANT_08 ="SAP.sendBOM.tooltip";
}
