package ext.alphai.aistoneglobal.sap;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.sap.CustomActionsRB_zh_CN")
public class CustomActionsRB_zh_CN extends WTListResourceBundle {


    @RBEntry("发送部件到SAP")
    public static final String PRIVATE_CONSTANT_01 ="SAP.sendPart.description";

    @RBEntry("发送部件到SAP")
    public static final String PRIVATE_CONSTANT_02 ="SAP.sendPart.tooltip";



    @RBEntry("发送选项集到SAP")
    public static final String PRIVATE_CONSTANT_03 ="SAP.sendOptionSet.description";

    @RBEntry("发送选项集到SAP")
    public static final String PRIVATE_CONSTANT_04 ="SAP.sendOptionSet.tooltip";

    @RBEntry("发送BOM到SAP")
    public static final String PRIVATE_CONSTANT_05 ="SAP.sendBOMWizard.description";

    @RBEntry("发送BOM到SAP")
    public static final String PRIVATE_CONSTANT_06 ="SAP.sendBOMWizard.tooltip";

    @RBEntry("发送BOM到SAP")
    public static final String PRIVATE_CONSTANT_07 ="SAP.sendBOM.description";

    @RBEntry("发送BOM到SAP")
    public static final String PRIVATE_CONSTANT_08 ="SAP.sendBOM.tooltip";
}
