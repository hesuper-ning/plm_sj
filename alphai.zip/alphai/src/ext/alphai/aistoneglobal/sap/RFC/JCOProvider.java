package ext.alphai.aistoneglobal.sap.RFC;

import com.sap.conn.jco.ext.DataProviderException;
import com.sap.conn.jco.ext.DestinationDataEventListener;
import com.sap.conn.jco.ext.DestinationDataProvider;

import java.util.HashMap;
import java.util.Properties;

public class JCOProvider implements DestinationDataProvider {
    private HashMap<String, Properties> secureDBStorage =
            new HashMap<String, Properties>();
    private DestinationDataEventListener eL;

    @Override
    public Properties getDestinationProperties(String destinationName) {
        try {
            //read destination from DB
            Properties props = secureDBStorage.get(destinationName);
            if (props != null) {
                //check is correct
                if (props.isEmpty())
                    throw new DataProviderException(DataProviderException.Reason.INVALID_CONFIGURATION,"Destination configuration is incorrect",null);
                    return props;
            }
            return null;
        }catch (RuntimeException re){
            throw new DataProviderException(DataProviderException.Reason.INTERNAL_ERROR,re);
        }
    }

    @Override
    public void setDestinationDataEventListener(DestinationDataEventListener eventListener) {
        this.eL = eventListener;
    }

    @Override
    public  boolean supportsEvents(){
        return true;
    }

    //implementation that saves the properties
    public void  changePropertiesForAbap_AS(String destName,
                                            Properties properties){
        synchronized (secureDBStorage) {
            if (properties == null) {
                if (secureDBStorage.remove(destName)!=null) {
                    eL.deleted(destName);
                }
            }else {
                secureDBStorage.put(destName, properties);
                eL.updated(destName);
            }
        }
    }
}
