package ext.alphai.aistoneglobal.sap.RFC;

import java.io.IOException;
import java.util.Properties;

//import org.apache.log4j.Logger;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.ext.Environment;
//import com.shany.common.util.StringUtil;

import org.apache.commons.lang3.exception.ExceptionUtils;

public class ComManager {
//    private static Logger logger = Logger.getLogger(RfcManager.class);
    private static String ABAP_AS_POOLED = "DstName";

    private static JCOProvider provider = null;

    private static JCoDestination destination = null;

    static {
        Properties properties = loadProperties();

        provider = new JCOProvider();

        // catch IllegalStateException if an instance is already registered
        try {
            Environment.registerDestinationDataProvider(provider);
        } catch (IllegalStateException e) {
//            logger.debug(e);
//            e.printStackTrace();
            System.out.println(
                    "----------registerDestinationDataProvider" +
                            "----------");
            System.out.println(ExceptionUtils.getStackTrace(e));
            System.out.println("----------registerDestinationDataProvider-END" +
                    "----------");
        }
        provider.changePropertiesForAbap_AS(ABAP_AS_POOLED, properties);
    }

    public static Properties loadProperties() {
        RfcManager manager = new RfcManager();
        Properties prop = new Properties();
        try {
            prop.load(manager.getClass().getResourceAsStream(
                    "/sap_s4t_conf.properties"));
        } catch (IOException e) {
//            logger.debug(e);
//            e.printStackTrace();
            System.out.println("---loadProperties---");
            System.out.println(ExceptionUtils.getStackTrace(e));
            System.out.println("---loadProperties-END---");
        }
        return prop;
    }

    public static JCoDestination getDestination() throws JCoException {
        if (destination == null) {
            destination = JCoDestinationManager.getDestination(ABAP_AS_POOLED);
        }
        return destination;
    }

    public static JCoFunction getFunction(String functionName) {
        JCoFunction function = null;
        try {
            function = getDestination().getRepository()
                    .getFunctionTemplate(functionName).getFunction();
        } catch (JCoException e) {
//            logger.error(e);
//            e.printStackTrace();
            System.out.println("---getFunction---");
            System.out.println(ExceptionUtils.getStackTrace(e));
            System.out.println("---getFunction-END---");
        } catch (NullPointerException e) {
//            logger.error(e);
//            e.printStackTrace();
            System.out.println("---getFunction---");
            System.out.println(ExceptionUtils.getStackTrace(e));
            System.out.println("---getFunction-END---");
        }
        return function;
    }

    public static void execute(JCoFunction function) {
//        logger.debug("SAP Function Name : " + function.getName());
        System.out.println("Executing function: " + function.getName());
        JCoParameterList paramList = function.getImportParameterList();

        if (paramList != null) {
//            logger.debug("Function Import Structure : " + paramList.toString());
            System.out.println("Function Import Structure : " + paramList.toString());
        }

        try {
            function.execute(getDestination());
//        } catch (JCoException e) {
        } catch (JCoException e) {
//            logger.error(e);
//            e.printStackTrace();
            System.out.println("---execute---");
            System.out.println(ExceptionUtils.getStackTrace(e));
            System.out.println("---execute-END---");
        }
        paramList = function.getExportParameterList();

        if (paramList != null) {
//            logger.debug("Function Export Structure : " + paramList.toString());
            System.out.println("Function Export Structure : " + paramList.toString());
        }
    }

    /*
     * SAP ping test
     */
    public static String ping() {
        String msg = null;
        try {
            getDestination().ping();
            msg = "Destination " + ABAP_AS_POOLED + " is ok";
        } catch (JCoException ex) {
//            msg = StringUtil.getExceptionTrace(ex);
            msg = ExceptionUtils.getStackTrace(ex);
        }
//        logger.debug(msg);
        System.out.println(msg);
        return msg;
    }

    public static void main(String[] args) {
        RfcManager.ping();
    }
}


