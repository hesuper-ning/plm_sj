package ext.alphai.aistoneglobal.sap.service;



import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import ext.alphai.aistoneglobal.sap.utils.CommonUtil;
import ext.alphai.aistoneglobal.sap.utils.IBAUtil;
import ext.alphai.aistoneglobal.sap.utils.PersistenceUtil;
import ext.alphai.aistoneglobal.sap.utils.PropertiesUtil;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.HashMap;
import java.util.Map;

/**
 * 调用RFC接口 在SAP创建部件
 */
public class CreateRFCMaterialPart {


    /**
     * 创建部件
     * @param part
     * @param plant  工厂
     * @return
     */
    public static Map<String, String> RFCCreatePart(WTPart part,String plant) throws WTException {
        IBAUtil iba = new IBAUtil(part);
        String subTypeInternal = PersistenceUtil.getSubTypeInternal(part);
        Map<String, String> map = new HashMap<String, String>();
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_CREATE_MATERIAL);
        // 设置import 参数
        // IMPORT PARAM
        JCoParameterList importParam = function.getImportParameterList();
        importParam.setValue(Constant.I_MBRSH, "H");  // 常量,必填
        String I_MATKL = CreateOrUpdateMaterialSer.getMaterialGroup(part, iba, subTypeInternal);
        importParam.setValue(Constant.I_MATKL, I_MATKL); // 变量EE,MM,KP & 机种 ,必填
        // 取分类属性的AI_SAP_PartType
        importParam.setValue(Constant.I_MTART, iba.getIBAValue("AI_SAP_PartType")); // 变量ROH,FERT,HALB ... ,必填
        JCoTable T_MARA = function.getTableParameterList().getTable(Constant.T_MARA);
        T_MARA.appendRow();
        T_MARA.setValue(Constant.WERKS, plant);
        T_MARA.setValue(Constant.MATNR, part.getNumber());
        T_MARA.setValue(Constant.MAKTX, part.getName());
        T_MARA.setValue(Constant.MEINS, CommonUtil.convertUnit( part.getDefaultUnit().getValue().toUpperCase()));
        T_MARA.setValue(Constant.ZVALUED, "");
        T_MARA.setValue(Constant.REQUESTOR, part.getModifierFullName());
        // 如果部件子类型是电子部件 则取分类属性的Value值 IBA 为AI_0001
        // 处理电子部件的EE_VALUE
        CreateOrUpdateMaterialSer.setEEValues(T_MARA, part, subTypeInternal, iba);

//        String EE_VALUE = "";
//        if("com.ptc.ElectricalPart".equalsIgnoreCase(subTypeInternal)){
//            EE_VALUE = iba.getIBAValue("AI_0001");
//        }
//        if (EE_VALUE != null && !EE_VALUE.isEmpty()) {
//            int chunkSize = 30; // 每段30个字符
//            int totalLength = EE_VALUE.length();
//
//            for (int i = 0; i * chunkSize < totalLength; i++) {
//                int start = i * chunkSize;
//                int end = Math.min((i + 1) * chunkSize, totalLength);
//                String chunk = EE_VALUE.substring(start, end);
//
//                String fieldName = "EE_VALUE" + (i + 1);
//                T_MARA.setValue(fieldName, chunk);
//            }
//        }

        // 执行RFC
        RfcManager.execute(function);

        // 获取RFC返回的字段值
        JCoParameterList exportParam = function.getExportParameterList();
        String exParamA = exportParam.getString(Constant.E_TYPE);
        String exParamB = exportParam.getString(Constant.E_MESSAGE);
        JCoTable exportTable = function.getTableParameterList().getTable(Constant.T_MARA);
        System.out.println("创建部件返回TABLE:"+exportTable);
        map.put(Constant.E_TYPE, exParamA);
        map.put(Constant.E_MESSAGE, exParamB);
        return map;
    }



}
