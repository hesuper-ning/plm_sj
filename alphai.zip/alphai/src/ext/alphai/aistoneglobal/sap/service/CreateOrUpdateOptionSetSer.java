package ext.alphai.aistoneglobal.sap.service;

import com.ptc.windchill.option.model.ChoiceMaster;
import com.ptc.windchill.option.model.Option;
import com.ptc.windchill.option.model.OptionSet;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import ext.alphai.aistoneglobal.sap.utils.OptionSetUtil;
import ext.alphai.aistoneglobal.sap.vo.OptionSetStructureVo;
import ext.alphai.aistoneglobal.sap.vo.OptionStructureVo;
import org.apache.commons.lang3.StringUtils;
import wt.part.WTPart;
import wt.util.WTException;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 创建或修改选项集
 */
public class CreateOrUpdateOptionSetSer {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    /**
     * 批量发送选项集
     * 由于选项集和选择的结构特性需要在查询时就执行是否创建以及修改
     * @param optionSets
     * @throws WTException
     */
    public static List<OptionSetStructureVo> sendOptionSetsToSAP(List<OptionSet> optionSets) throws WTException {
        List<OptionSetStructureVo> optionSetsStructure = getOptionSetsStructure(optionSets);

        for (OptionSetStructureVo optionSetStructureVo : optionSetsStructure) {
            OptionSet optionSet = optionSetStructureVo.getOptionSet();
            List<OptionStructureVo> structureVos = optionSetStructureVo.getStructureVos();
            // 获取RFC 对象
            JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_CLASS);

            // 设置import 参数
            JCoParameterList importParam = function.getImportParameterList();
            importParam.setValue(Constant.I_FLAG, "3");
            // 设置查询条件表 T_MARA
            JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_CLASS);
            inputTable.appendRow();
            inputTable.setValue(Constant.CLASSTYPE, "300");
            String optionSetName = optionSet.getName();
            inputTable.setValue(Constant.CLASSNUM, optionSetName);
            // 执行RFC
            RfcManager.execute(function);
            // 获取全局返回参数
            JCoParameterList exportParam = function.getExportParameterList();

            String globalType = exportParam.getString(Constant.E_TYPE);
            String globalMessage = exportParam.getString(Constant.E_MESSAGE);

            // 获取表返回结果
            JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_CLASS);
            System.out.println("查询选项集返回结果TYPE:"+globalType);
            System.out.println("查询选项集返回结果MESSAGE:"+globalMessage);
            System.out.println("查询选项集返回结果TABLE:"+returnTable);
            String operation = "1";
            if(globalType.equals(Constant.S)) {

                for (int i = 0; i < returnTable.getNumRows(); i++) {
                    returnTable.setRow(i);
                    String optionSetNameResult = returnTable.getString(Constant.CLASSNUM);
                    if(optionSetName.equals(optionSetNameResult)){
                        operation = "2";
                        break;
                    }
                }
            } else if (globalType.equals(Constant.E)) {
                // SAP报错

            }
            if(StringUtils.isNotBlank(operation)){
                createOptionSetsToSAP(operation, optionSetStructureVo);
            }
        }
        return optionSetsStructure;
    }


    /**
     * 创建选项集
     * @param optionSetStructureVo
     */
    public static void createOptionSetsToSAP(String operation, OptionSetStructureVo optionSetStructureVo){
        OptionSet optionSet = optionSetStructureVo.getOptionSet();
        List<OptionStructureVo> structureVos = optionSetStructureVo.getStructureVos();

        // 先发送选项下的选择
        sendOptionToSAP(structureVos);
        // 在发送选项集前先发送选项
        List<Option> options = new ArrayList<>();
        for (OptionStructureVo structureVo : structureVos) {
            options.add(structureVo.getOptions());
        }

        String optionSetName = optionSet.getName();
        Timestamp updateTimestamp = optionSet.getModifyTimestamp();
        String updateTimeStr = sdf.format(updateTimestamp);
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_CLASS);
        // 设置import 参数
        JCoParameterList importParam = function.getImportParameterList();
        importParam.setValue(Constant.I_FLAG, operation);

        JCoTable T_CLASS = function.getTableParameterList().getTable(Constant.T_CLASS);

        for (Option option : options) {
            T_CLASS.appendRow();
            T_CLASS.setValue("CLASSTYPE", "300");
            T_CLASS.setValue("CLASSNUM", optionSetName);
            T_CLASS.setValue("LANGUINT", "EN");
            T_CLASS.setValue("VALID_FROM", updateTimeStr);
            T_CLASS.setValue("CATCHWORD", optionSet.getDescription());
            T_CLASS.setValue("NAME_CHAR", option.getNumber());
        }
        // 执行RFC
        RfcManager.execute(function);
        // 处理发送结果
        // 获取全局返回参数
        JCoParameterList exportParam = function.getExportParameterList();

        String createOptionSetGlobalType = exportParam.getString(Constant.E_TYPE);
        String createOptionSetGlobalMessage = exportParam.getString(Constant.E_MESSAGE);
        JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_CLASS);

        System.out.println("标识:"+operation+"  发送选项集返回结果TYPE:"+createOptionSetGlobalType);
        System.out.println("标识:"+operation+"  发送选项集返回结果MESSAGE:"+createOptionSetGlobalMessage);
        System.out.println("标识:"+operation+"  发送选项集返回结果TABLE:"+returnTable);

        optionSetStructureVo.setType(createOptionSetGlobalType);
        optionSetStructureVo.setMessage(createOptionSetGlobalMessage);

    }
    /**
     * 修改选项集结构到sap
     * @param returnTable
     * @throws WTException
     */
    public static void updateOptionSetsToSAP(JCoTable returnTable, OptionSetStructureVo optionSetStructureVo) throws WTException {
        List<OptionStructureVo> structureVos = optionSetStructureVo.getStructureVos();
        // 当前选项集结构下的选项编号集合
        List<String> optionNumbers = new ArrayList<>();
        for (OptionStructureVo structureVo : structureVos) {
            optionNumbers.add(structureVo.getOptions().getNumber());
        }
        // 拆解选项集结构查询后的每一项
        // 处理查询结果
        // 当前选项集在SAP已存在的选项编号集合
        List<String> sapOptionNumbers = new ArrayList<>();
        for (int i = 0; i < returnTable.getNumRows(); i++) {
            returnTable.setRow(i);
            String optionNumber = returnTable.getString(Constant.NAME_CHAR);
            sapOptionNumbers.add(optionNumber);
        }

    }


    /**
     * 查询并 创建或者修改选项结构到SAP
     * @param structureVos
     */
    public static void sendOptionToSAP(List<OptionStructureVo> structureVos){
        for (OptionStructureVo structureVo : structureVos) {
            Option options = structureVo.getOptions();
            String optionsNumber = options.getNumber();

            // 查询选项是否于SAP中已经存在
            JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_CHARACT);

            // 设置import 参数
            JCoParameterList importParam = function.getImportParameterList();
            importParam.setValue(Constant.I_FLAG, "3");
            // 设置查询条件表 T_MARA
            JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_CHARACT);
            inputTable.appendRow();
            inputTable.setValue(Constant.ATNAM, optionsNumber);
            // 执行RFC
            RfcManager.execute(function);
            // 获取全局返回参数
            JCoParameterList exportParam = function.getExportParameterList();

            String globalType = exportParam.getString(Constant.E_TYPE);
            String globalMessage = exportParam.getString(Constant.E_MESSAGE);

            // 获取表返回结果
            JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_CHARACT);

            System.out.println("查询选项返回结果TYPE:"+globalType);
            System.out.println("查询选项返回结果MESSAGE:"+globalMessage);
            System.out.println("查询选项返回结果TABLE:"+returnTable);

            String  operation = "1";
            if(globalType.equals(Constant.S)) {
                // 已经存在选项 进行修改
//                updateOptionsToSAP(returnTable, structureVo);

                for (int i = 0; i < returnTable.getNumRows(); i++) {
                    returnTable.setRow(i);
                    String optionNumberResult = returnTable.getString(Constant.ATNAM);
                    if(optionsNumber.equals(optionNumberResult)){
                        operation = "2";
                        break;
                    }
                }

            } else if (globalType.equals(Constant.E)) {
                // SAP没有选项直接添加

            }
            if(StringUtils.isNotBlank(operation)){
                createOptionsToSAP(operation, structureVo);
            }
        }
    }


    /**
     * 创建已存在的选项
     * @param structureVo
     * 返回发生时选项结构的结果  map key为选项编号  value为结果
     */
    public static void createOptionsToSAP(String operation,OptionStructureVo structureVo){

        Option options = structureVo.getOptions();
        Timestamp updateTimestamp = options.getModifyTimestamp();
        String updateTimeStr = sdf.format(updateTimestamp);
        String optionsNumber = options.getNumber();
        String optionsName = options.getName();
        List<ChoiceMaster> choiceMasters = structureVo.getChoiceMasters();
        // 查询选项是否于SAP中已经存在
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_CHARACT);

        // 设置import 参数
        JCoParameterList importParam = function.getImportParameterList();
        importParam.setValue(Constant.I_FLAG, operation);
        JCoTable T_CLASS = function.getTableParameterList().getTable(Constant.T_CHARACT);
        for (ChoiceMaster choiceMaster : choiceMasters) {
            T_CLASS.appendRow();
            T_CLASS.setValue(Constant.ATNAM, optionsNumber);
            T_CLASS.setValue(Constant.DATUV, updateTimeStr);
            T_CLASS.setValue(Constant.ATBEZ, optionsName);
            T_CLASS.setValue(Constant.ATUDF, "CHAR");
            T_CLASS.setValue(Constant.ANZST, "8");
            T_CLASS.setValue(Constant.ATWRT, choiceMaster.getNumber());
            T_CLASS.setValue(Constant.ATWTB, choiceMaster.getName());
        }
        // 执行RFC
        RfcManager.execute(function);
        // 处理发送结果
        // 获取全局返回参数
        JCoParameterList exportParam = function.getExportParameterList();

        String createOptionGlobalType = exportParam.getString(Constant.E_TYPE);
        String createOptionGlobalMessage = exportParam.getString(Constant.E_MESSAGE);
        // 获取表返回结果
        JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_CHARACT);

        System.out.println("标识:"+operation+"  发送选项返回结果TYPE:"+createOptionGlobalType);
        System.out.println("标识:"+operation+"  发送选项返回结果MESSAGE:"+createOptionGlobalMessage);
        System.out.println("标识:"+operation+"  发送选项返回结果TABLE:"+returnTable);

        structureVo.setType(createOptionGlobalType);
        structureVo.setMessage(createOptionGlobalMessage);
    }

    /**
     * 获取选项集完整结构
     * @param optionSets
     * @return
     */
    private static List<OptionSetStructureVo> getOptionSetsStructure(List<OptionSet> optionSets) throws WTException {
        List<OptionSetStructureVo> vos = new ArrayList<>();
        for (OptionSet optionSet : optionSets) {
            List<Option> optionByOptionSet = OptionSetUtil.getOptionByOptionSet(optionSet);
            List<OptionStructureVo> optionStructureVos = new ArrayList<>();
            for (Option option : optionByOptionSet) {
                OptionStructureVo optionStructureVo = new OptionStructureVo();
                optionStructureVo.setOptions(option);
                optionStructureVo.setOptionChoiceMasterLinks(OptionSetUtil.getOptionChoiceMasterLinkByOption(option));
                optionStructureVo.setChoiceMasters(OptionSetUtil.getChoiceMasterByOption(option));
                optionStructureVos.add(optionStructureVo);
            }
            OptionSetStructureVo vo = new OptionSetStructureVo(optionSet, optionStructureVos);
            vos.add(vo);
        }
        return vos;
    }

}
