package ext.alphai.aistoneglobal.sap.service;

import com.sap.conn.jco.*;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import ext.alphai.aistoneglobal.sap.utils.CommonUtil;
import ext.alphai.aistoneglobal.sap.utils.IBAUtil;
import ext.alphai.aistoneglobal.sap.utils.PersistenceUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 创建或更新部件
 */
public class CreateOrUpdateMaterialSer {
    private static final Logger logger = LogManager.getLogger(CreateOrUpdateMaterialSer.class);
    /**
     * 批量创建或更新部件到SAP
     * @param parts 部件列表
     * @return 包含每个部件执行结果的Map列表
     */
    public static List<Map<String, String>> RFCCreateOrUpdatePartsBatch(List<WTPart> parts) throws WTException {
        List<Map<String, String>> results = new ArrayList<>();

        // 1. 批量查询SAP中是否存在这些部件
        List<String> partNumbers = parts.stream()
                .map(WTPart::getNumber)
                .collect(Collectors.toList());

        Map<String, Map<String, String>> queryResults = RFCQueryPartsBatch(partNumbers);

        // 2. 根据查询结果分别进行创建或更新
        Map<String, List<WTPart>> partsToCreate = new HashMap<>();
        Map<String, List<WTPart>> partsToUpdate = new HashMap<>();

        for (WTPart part : parts) {
            String partNumber = part.getNumber();
            Map<String, String> queryResult = queryResults.get(partNumber);

            if (queryResult != null && "true".equals(queryResult.get("EXISTS"))) {
                // 部件存在，需要更新
                if (!partsToUpdate.containsKey(partNumber)) {
                    partsToUpdate.put(partNumber, new ArrayList<>());
                }
                partsToUpdate.get(partNumber).add(part);
            } else {
                // 部件不存在，需要创建
                if (!partsToCreate.containsKey(partNumber)) {
                    partsToCreate.put(partNumber, new ArrayList<>());
                }
                partsToCreate.get(partNumber).add(part);
            }
        }

        // 3. 批量创建部件
        if (!partsToCreate.isEmpty()) {
            List<WTPart> createParts = partsToCreate.values().stream()
                    .flatMap(List::stream)
                    .collect(Collectors.toList());
            List<Map<String, String>> createResults = RFCCreatePartsBatch(createParts);
            results.addAll(createResults);
        }

        // 4. 批量更新部件
        if (!partsToUpdate.isEmpty()) {
            List<WTPart> updateParts = partsToUpdate.values().stream()
                    .flatMap(List::stream)
                    .collect(Collectors.toList());
            List<Map<String, String>> updateResults = RFCUpdatePartsBatch(updateParts);
            results.addAll(updateResults);
        }

        return results;
    }

    /**
     * 批量创建部件
     */
    public static List<Map<String, String>> RFCCreatePartsBatch(List<WTPart> parts) throws WTException {
        List<Map<String, String>> results = new ArrayList<>();

        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_CREATE_MATERIAL);

        // 设置import 参数
        JCoParameterList importParam = function.getImportParameterList();
        importParam.setValue(Constant.I_MBRSH, "H");

        JCoTable T_MARA = function.getTableParameterList().getTable(Constant.T_MARA);

        // 准备批量数据
        for (WTPart part : parts) {
            IBAUtil iba = new IBAUtil(part);
            String subTypeInternal = PersistenceUtil.getSubTypeInternal(part);





            // 设置物料组
            String I_MATKL = getMaterialGroup(part, iba, subTypeInternal);
            importParam.setValue(Constant.I_MATKL, I_MATKL);
            importParam.setValue(Constant.I_MTART, iba.getIBAValue("AI_SAP_PartType"));

            // 添加物料数据
            T_MARA.appendRow();
            T_MARA.setValue(Constant.WERKS, "6020");
            T_MARA.setValue(Constant.MATNR, part.getNumber());
            T_MARA.setValue(Constant.MAKTX, part.getName());
            T_MARA.setValue(Constant.MEINS, CommonUtil.convertUnit( part.getDefaultUnit().getValue().toUpperCase()));
            T_MARA.setValue(Constant.ZVALUED, "");
            T_MARA.setValue(Constant.REQUESTOR, part.getModifierFullName());

            // 处理电子部件的EE_VALUE
            setEEValues(T_MARA, part, subTypeInternal, iba);
        }

        // 执行RFC
        RfcManager.execute(function);




        // 处理返回结果
        return processBatchResults(function, parts, "CREATE");
    }

    /**
     * 批量更新部件
     */
    public static List<Map<String, String>> RFCUpdatePartsBatch(List<WTPart> parts) throws WTException {
        List<Map<String, String>> results = new ArrayList<>();

        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_UPDATE_MATERIAL);
        JCoTable T_MARA = function.getTableParameterList().getTable(Constant.T_MARA);

        // 准备批量数据
        for (WTPart part : parts) {
            IBAUtil iba = new IBAUtil(part);
            String subTypeInternal = PersistenceUtil.getSubTypeInternal(part);

            T_MARA.appendRow();
            T_MARA.setValue(Constant.MATNR, part.getNumber());
            T_MARA.setValue(Constant.MAKTX, part.getName());

            String MATKL = getMaterialGroup(part, iba, subTypeInternal);
            T_MARA.setValue(Constant.MATKL, MATKL);
            T_MARA.setValue(Constant.MEINS, CommonUtil.convertUnit( part.getDefaultUnit().getValue().toUpperCase()));

            // 可以根据需要设置其他更新字段
            // T_MARA.setValue(Constant.ZVALUED, "");
            // T_MARA.setValue(Constant.MSTAE, "");
        }

        // 执行RFC
        RfcManager.execute(function);

        // 处理返回结果
        return processBatchResults(function, parts, "UPDATE");
    }

    /**
     * 处理批量操作返回结果
     */
    private static List<Map<String, String>> processBatchResults(JCoFunction function, List<WTPart> parts, String operationType) {
        List<Map<String, String>> results = new ArrayList<>();


        JCoParameterList importParam = function.getImportParameterList();
        // 获取全局返回参数
        JCoParameterList exportParam = function.getExportParameterList();
        String globalType = exportParam.getString(Constant.E_TYPE);
        String globalMessage = exportParam.getString(Constant.E_MESSAGE);

        // 获取表返回结果
        JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_MARA);

        logReturnTable(function);
//        System.out.println("当前发送部件的操作是:"+operationType);
//        System.out.println("当前发送部件的操作结果是globalType:"+globalType);
//        System.out.println("当前发送部件的操作结果是globalMessage:"+globalMessage);
//        System.out.println("当前发送部件返回table是:"+returnTable);
        // 处理每条物料的返回结果
        for (int i = 0; i < returnTable.getNumRows(); i++) {
            returnTable.setRow(i);
            Map<String, String> resultMap = new HashMap<>();

            String materialNumber = returnTable.getString(Constant.MATNR);
            String messageType = returnTable.getString(Constant.TYPE);
            String messageText = returnTable.getString(Constant.MESSAGE);

            resultMap.put("MATNR", materialNumber);
            resultMap.put("TYPE", messageType);
            resultMap.put("MESSAGE", messageText);
            resultMap.put("OPERATION", operationType);
            resultMap.put("GLOBAL_TYPE", globalType);
            resultMap.put("GLOBAL_MESSAGE", globalMessage);
            resultMap.put("SUCCESS", "S".equalsIgnoreCase(messageType) ? "true" : "false");

            results.add(resultMap);
        }

        // 处理未返回的物料（理论上不应该发生）
        Set<String> returnedMaterials = results.stream()
                .map(result -> result.get("MATNR"))
                .collect(Collectors.toSet());

        for (WTPart part : parts) {
            if (!returnedMaterials.contains(part.getNumber())) {
                Map<String, String> errorResult = new HashMap<>();
                errorResult.put("MATNR", part.getNumber());
                errorResult.put("TYPE", "E");
                errorResult.put("MESSAGE", "No response from SAP for " + operationType);
                errorResult.put("OPERATION", operationType);
                errorResult.put("GLOBAL_TYPE", globalType);
                errorResult.put("GLOBAL_MESSAGE", globalMessage);
                errorResult.put("SUCCESS", "false");
                results.add(errorResult);
            }
        }

        printCreateResults(results);

        return results;
    }

    /**
     * 获取物料组
     */
    public static String getMaterialGroup(WTPart part, IBAUtil iba, String subTypeInternal) throws WTException {
        if (part.isEndItem()) {
            return iba.getIBAValue("AI_PROJECT_NAME");
        } else {
            switch (subTypeInternal) {
                case "com.ptc.ElectricalPart":
                    return "EE";
                case "com.aistoneglobal.AI_MechnicalPart":
                    return "ME";
                case "com.aistoneglobal.AI_KeyParts":
                    return "KP";
                case "com.ptc.swlink.SoftwarePart":
                    return "KP";
                case "com.aistoneglobal.AI_ASMParts":
                    // 尝试获取AI_PROJECT_NAME，如果为空则从部件编号截取
                    String projectName = iba.getIBAValue("AI_PROJECT_NAME");
                    if (projectName != null && !projectName.trim().isEmpty()) {
                        return projectName;
                    } else {
                        return extractMaterialGroupFromPartNumber(part.getNumber());
                    }
                default:
                    return iba.getIBAValue("AI_PROJECT_NAME");
            }
        }
    }

    /**
     * 从部件编号中提取物料组
     * 格式如：ASYX5PTL56H-12 -> 提取 X5PTL56H
     */
    private static String extractMaterialGroupFromPartNumber(String partNumber) {
        if (partNumber == null || partNumber.isEmpty()) {
            return "";
        }

        // 查找连字符的位置
        int hyphenIndex = partNumber.indexOf('-');
        if (hyphenIndex > 3) { // 确保长度足够
            // 从第4个字符开始截取（索引3），到连字符结束
            return partNumber.substring(3, hyphenIndex);
        } else if (partNumber.length() > 3) {
            // 如果没有连字符，从第4个字符截取到末尾
            return partNumber.substring(3);
        }

        return partNumber;
    }
    /**
     * 设置EE_VALUE值
     */
    public static void setEEValues(JCoTable T_MARA, WTPart part, String subTypeInternal, IBAUtil iba) throws WTException {
        String EE_VALUE = "";
        if ("com.ptc.ElectricalPart".equalsIgnoreCase(subTypeInternal)) {
            EE_VALUE = iba.getIBAValue("AI_0001");
        }

        if (EE_VALUE != null && !EE_VALUE.isEmpty()) {
            int chunkSize = 30;
            int totalLength = EE_VALUE.length();

            for (int i = 0; i * chunkSize < totalLength; i++) {
                int start = i * chunkSize;
                int end = Math.min((i + 1) * chunkSize, totalLength);
                String chunk = EE_VALUE.substring(start, end);

                String fieldName = "EE_VALUE" + (i + 1);
                T_MARA.setValue(fieldName, chunk);
            }
        }
    }


    /**
     * 单条创建或更新部件（兼容原有方法）
     */
    public static Map<String, String> RFCCreateOrUpdatePart(WTPart part) throws WTException {
        List<WTPart> singlePartList = new ArrayList<>();
        singlePartList.add(part);

        List<Map<String, String>> batchResults = RFCCreateOrUpdatePartsBatch(singlePartList);

        if (!batchResults.isEmpty()) {
            return batchResults.get(0);
        } else {
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put(Constant.E_TYPE, "E");
            errorMap.put(Constant.E_MESSAGE, "No response from SAP");
            return errorMap;
        }
    }

    /**
     * 单条创建部件（保持原有方法）
     */
    public static Map<String, String> RFCCreatePart(WTPart part) throws WTException {
        return RFCCreateOrUpdatePart(part);
    }

    /**
     * 单条更新部件（保持原有方法）
     */
    public static Map<String, String> RFCUpdatePart(WTPart part) throws WTException {
        return RFCCreateOrUpdatePart(part);
    }


    /**
     * 批量查询部件
     * @param partsNumber 部件编号列表
     * @return 包含每个部件查询结果的Map，key为部件号，value为查询结果详情
     */
    public static Map<String, Map<String, String>> RFCQueryPartsBatch(List<String> partsNumber) {
        Map<String, Map<String, String>> resultMap = new HashMap<>();

        try {
            // 获取RFC 对象
            JCoFunction function = RfcManager.getFunction(Constant.ZRFC_QUERY_MATERIAL);

            // 设置import 参数
            JCoParameterList importParam = function.getImportParameterList();
            importParam.setValue(Constant.I_WERKS, "6020");            // 工厂 默认6020 ,必填
            importParam.setValue(Constant.I_ERSDA_FROM, "");   // 开始日期,可选
            importParam.setValue(Constant.I_ERSDA_TO, "");             // 结束日期,可选

            // 设置查询条件表 T_MARA
            JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_MARA);

            // 批量添加查询条件
            for (String partNumber : partsNumber) {
                inputTable.appendRow();
                inputTable.setValue(Constant.MATNR, partNumber);
                // 可以设置其他查询条件
            }

            // 执行RFC
            RfcManager.execute(function);

            // 获取全局返回结果
            JCoParameterList exportParam = function.getExportParameterList();
            String globalType = exportParam.getString(Constant.E_TYPE);
            String globalMessage = exportParam.getString(Constant.E_MESSAGE);

            // 获取查询结果表
            JCoTable outputTable = function.getTableParameterList().getTable(Constant.T_MARA);

            // 处理查询结果
            for (int i = 0; i < outputTable.getNumRows(); i++) {
                outputTable.setRow(i);

                Map<String, String> partResult = new HashMap<>();
                String materialNumber = outputTable.getString(Constant.MATNR);

                if (materialNumber != null && !materialNumber.trim().isEmpty()) {
                    // 收集所有返回字段信息
                    partResult.put("MATNR", materialNumber);
                    partResult.put("MAKTX", outputTable.getString(Constant.MAKTX));
                    partResult.put("WERKS", outputTable.getString(Constant.WERKS));
                    partResult.put("MEINS", outputTable.getString(Constant.MEINS));
                    partResult.put("ZVALUED", outputTable.getString(Constant.ZVALUED));
                    partResult.put("MSTAE", outputTable.getString("MSTAE"));
                    partResult.put("TYPE", outputTable.getString(Constant.TYPE));
                    partResult.put("MESSAGE", outputTable.getString(Constant.MESSAGE));
                    partResult.put("REQUESTOR", outputTable.getString(Constant.REQUESTOR));
                    partResult.put("GPM_STATUS", outputTable.getString("GPM_STATUS"));
                    partResult.put("PROJECT_STATUS", outputTable.getString("PROJECT_STATUS"));
                    partResult.put("GLOBAL_TYPE", globalType);
                    partResult.put("GLOBAL_MESSAGE", globalMessage);
                    partResult.put("EXISTS", "true");

                    resultMap.put(materialNumber, partResult);
                }
            }

            // 处理未返回的物料（查询不到的物料）
            for (String partNumber : partsNumber) {
                if (!resultMap.containsKey(partNumber)) {
                    Map<String, String> notFoundResult = new HashMap<>();
                    notFoundResult.put("MATNR", partNumber);
                    notFoundResult.put("EXISTS", "false");
                    notFoundResult.put("TYPE", "E");
                    notFoundResult.put("MESSAGE", "Material not found in SAP");
                    notFoundResult.put("GLOBAL_TYPE", globalType);
                    notFoundResult.put("GLOBAL_MESSAGE", globalMessage);
                    resultMap.put(partNumber, notFoundResult);
                }
            }

        } catch (Exception e) {
            // 异常处理：为所有物料设置错误结果
            for (String partNumber : partsNumber) {
                Map<String, String> errorResult = new HashMap<>();
                errorResult.put("MATNR", partNumber);
                errorResult.put("EXISTS", "false");
                errorResult.put("TYPE", "E");
                errorResult.put("MESSAGE", "RFC query failed: " + e.getMessage());
                errorResult.put("GLOBAL_TYPE", "E");
                errorResult.put("GLOBAL_MESSAGE", e.getMessage());
                resultMap.put(partNumber, errorResult);
            }
        }
        printResultMap(resultMap);

        return resultMap;
    }

    /**
     * 判断物料是否存在（根据返回数据判断）
     */
    private static boolean isMaterialExists(JCoTable outputTable) {
        String materialNumber = outputTable.getString(Constant.MATNR);
        String messageType = outputTable.getString(Constant.TYPE);

        // 如果物料号不为空且消息类型不是错误，则认为物料存在
        return materialNumber != null && !materialNumber.trim().isEmpty()
                && !"E".equals(messageType) && !"A".equals(messageType);
    }
    public static void printResultMap(Map<String, Map<String, String>> resultMap) {
        if (resultMap == null) {
            logger.warn("结果Map为空");
            return;
        }

        logger.info("=== 开始打印SAP查询结果 ===");
        logger.info("总计: {} 个物料", resultMap.size());

        // 遍历外层Map
        for (Map.Entry<String, Map<String, String>> entry : resultMap.entrySet()) {
            String materialNo = entry.getKey();
            Map<String, String> detail = entry.getValue();

            logger.info("物料号: {}", materialNo);

            // 遍历内层Map
            for (Map.Entry<String, String> detailEntry : detail.entrySet()) {
                logger.info("  {} = {}", detailEntry.getKey(), detailEntry.getValue());
            }

            logger.info("----------------------");
        }

        logger.info("=== 打印完成 ===");
    }


    /**
     * 简单打印ReturnTable - key = value格式
     */
    private static void logReturnTable(JCoFunction function) {
        JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_MARA);
        JCoParameterList importList = function.getImportParameterList();


        if (importList != null) {
            logger.info("Import参数:");
            JCoMetaData importMeta = importList.getMetaData();
            for (int i = 0; i < importMeta.getFieldCount(); i++) {
                String fieldName = importMeta.getName(i);
                String value = importList.getString(fieldName);
                logger.info("  {} = {}", fieldName, value);
            }
        }

        if (returnTable == null) {
            logger.info("returnTable = null");
            return;
        }
        logger.info("returnTable行数 = {}", returnTable.getNumRows());

        if (returnTable.getNumRows() == 0) {
            logger.info("表格为空");
            return;
        }

        // 打印每一行
        for (int i = 0; i < returnTable.getNumRows(); i++) {
            returnTable.setRow(i);

            logger.info("第{}行:", i+1);

            // 使用字段迭代器遍历所有字段
            JCoRecordFieldIterator iterator = returnTable.getRecordFieldIterator();
            while (iterator.hasNextField()) {
                JCoField field = iterator.nextField();
                String key = field.getName();
                String value = field.getString();

                // 直接打印 key = value
                logger.info("  {} = {}", key, value);
            }
        }
    }

    /**
     * 打印创建结果
     */
    private static void printCreateResults(List<Map<String, String>> results) {

        if (results == null || results.isEmpty()) {
            logger.info("创建结果为空");
            return;
        }

        logger.info("=== 批量创建部件结果 ===");
        logger.info("总共处理: {} 个部件", results.size());

        int successCount = 0;
        int errorCount = 0;
        int warningCount = 0;

        for (int i = 0; i < results.size(); i++) {
            Map<String, String> result = results.get(i);

            logger.info("【第 {} 个】", i + 1);

            // 遍历Map中的所有值
            for (Map.Entry<String, String> entry : result.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                logger.info("  {}: {}", key, value);
            }

            // 统计
            String type = result.get("TYPE");
            if ("S".equals(type)) {
                successCount++;
                logger.info("  状态: ✅ 成功");
            } else if ("E".equals(type)) {
                errorCount++;
                logger.info("  状态: ❌ 失败");
            } else if ("W".equals(type)) {
                warningCount++;
                logger.info("  状态: ⚠️ 警告");
            }

            logger.info("----------------------");
        }

        logger.info("【统计】成功: {}, 警告: {}, 失败: {}",
                successCount, warningCount, errorCount);
        logger.info("=== 打印完成 ===");
    }

}
