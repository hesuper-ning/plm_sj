package ext.alphai.aistoneglobal.sap.service;

import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import ext.alphai.aistoneglobal.sap.utils.*;
import ext.alphai.aistoneglobal.sap.vo.BOMItem;
import ext.alphai.aistoneglobal.sap.vo.BOMSendResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrder2;
import wt.fc.QueryResult;
import wt.part.*;
import wt.util.WTException;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * RFC创建和修改BOM方法
 */
public class CreateOrUpdateBOMSer {



    static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    private static final Logger logger = LogManager.getLogger(CreateOrUpdateBOMSer.class);

    /**
     * 批量发送BOM到SAP
     *
     * @param boms          传入的待发送的BOM对象
     * @param targetFactory 待发送的目标工厂
     */
//    public static Map<WTPart, Map<WTPart,Boolean>> sendOptionSetsToSAP(List<WTPart> boms, String targetFactory) throws WTException {
//        // 最外面的map key为BOM头   里面的map 为BOM下各个需要发送的子bom  value 代表子BOM成功失败
//        Map<WTPart, Map<WTPart,Boolean>> sendResultMap = new HashMap<>();
//        // 需要校验是需要创建还是更新的所有BOM对象
//        Map<WTPart, List<WTPart>> wtPartListMap = queryALLWaitSendBOMFromSAP(boms);
//        Set<Map.Entry<WTPart, List<WTPart>>> entries = wtPartListMap.entrySet();
//        for (Map.Entry<WTPart, List<WTPart>> entry : entries) {
//            // BOM头 顶层
//            WTPart bomHead = entry.getKey();
//            // BOM 头下所有使用到子项BOM
//            List<WTPart> bomChild = entry.getValue();
//            bomChild.add(bomHead);
//            // 创建或更新BOM结果
//            Map<WTPart,Boolean> childSendResultMap = new HashMap<>();
//            for (WTPart child : bomChild) {
//                Boolean createOrUpdateBOMIndex = queryBOMWillCreateOrUpdate(child, targetFactory);
//                String sapSign = "";
//                if(createOrUpdateBOMIndex){
//                    // 修改BOM
//                    sapSign = "2";
//                }else {
//                    // 创建BOM
//                    sapSign = "1";
//                }
//                Boolean sendSingleBom = sendSingleBom(child, targetFactory, sapSign);
//                if(sendSingleBom == null){
//                    // 该子料不是bom
//                }else {
//                    childSendResultMap.put(child, sendSingleBom);
//                }
//            }
//            sendResultMap.put(bomHead, childSendResultMap);
//        }
//        return sendResultMap;
//    }


    //发送所有子项  禁用
    public static Map<WTPart, Map<WTPart, BOMSendResult>> sendBOMToSAP(List<WTPart> boms, String targetFactory) throws WTException {
        Map<WTPart, Map<WTPart, BOMSendResult>> sendResultMap = new HashMap<>();
        Map<WTPart, List<WTPart>> wtPartListMap = queryALLWaitSendBOMFromSAP(boms);

        Set<Map.Entry<WTPart, List<WTPart>>> entries = wtPartListMap.entrySet();
        for (Map.Entry<WTPart, List<WTPart>> entry : entries) {
            WTPart bomHead = entry.getKey();
            List<WTPart> bomChild = entry.getValue();
            bomChild.add(bomHead);

            Map<WTPart, BOMSendResult> childSendResultMap = new HashMap<>();
            for (WTPart child : bomChild) {
                Boolean createOrUpdateBOMIndex = queryBOMWillCreateOrUpdate(child, targetFactory);
                String sapSign = createOrUpdateBOMIndex ? "2" : "1";

                BOMSendResult sendResult = sendSingleBom(child, targetFactory, sapSign);
                if (sendResult.getPart() != null) { // 如果是BOM才记录结果
                    childSendResultMap.put(child, sendResult);
                }
            }
            sendResultMap.put(bomHead, childSendResultMap);
        }
        return sendResultMap;
    }


    //发送一层子项
    public static Map<WTPart, Map<WTPart, BOMSendResult>> sendSingleBOMToSAP(List<WTPart> boms, String targetFactory, String option) throws WTException {
        Map<WTPart, Map<WTPart, BOMSendResult>> sendResultMap = new HashMap<>();
//        Map<WTPart, List<WTPart>> wtPartListMap = querySingleWaitSendBOMFromSAP(boms);

//        Set<Map.Entry<WTPart, List<WTPart>>> entries = wtPartListMap.entrySet();
//        for (Map.Entry<WTPart, List<WTPart>> entry : entries) {
//            WTPart bomHead = entry.getKey();
//            List<WTPart> bomChild = entry.getValue();
//            bomChild.add(bomHead);
//
//            Map<WTPart, BOMSendResult> childSendResultMap = new HashMap<>();
//            for (WTPart child : bomChild) {
//                Boolean createOrUpdateBOMIndex = queryBOMWillCreateOrUpdate(child, targetFactory);
//                String sapSign = createOrUpdateBOMIndex ? "2" : "1";
//
//                BOMSendResult sendResult = sendSingleBom(child, targetFactory, sapSign);
//                if(sendResult.getPart() != null) { // 如果是BOM才记录结果
//                    childSendResultMap.put(child, sendResult);
//                }
//            }
        for (WTPart bomHead : boms) {
            Boolean createOrUpdateBOMIndex = queryBOMWillCreateOrUpdate(bomHead, targetFactory);
            String sapSign = createOrUpdateBOMIndex ? "2" : "1";
            Map<WTPart, BOMSendResult> childSendResultMap = new HashMap<>();
//            for (WTPart child : bomChild) {
//            BOMSendResult sendResult = sendSingleBom(bomHead, targetFactory, sapSign);
            //设置行号校验

            Map<WTPart, List<BOMItem>> convertToBomItem = bomConvertToBomItem(bomHead, targetFactory, option);
            //存在空行号,不发sap
            if (!checkBOMLineNumber(convertToBomItem)) {
                BOMSendResult bomSendResult = new BOMSendResult(false, Constant.LINE_NUMBER_ERR_MSG, bomHead);
                childSendResultMap.put(bomHead, bomSendResult);
                sendResultMap.put(bomHead, childSendResultMap);
                break;
            }


            BOMSendResult sendResult = sendSingleBom(convertToBomItem, targetFactory, sapSign);
            if (sendResult.getPart() != null) { // 如果是BOM才记录结果
                childSendResultMap.put(bomHead, sendResult);
            }
//            }
            sendResultMap.put(bomHead, childSendResultMap);
        }
        return sendResultMap;
    }


    /**
     * 校验BOM行号
     * 都有值返回 true  否则false
     *
     * @param bom
     * @return
     */
    public static boolean checkBOMLineNumber(Map<WTPart, List<BOMItem>> bom) {
        boolean flag = true;
        Map.Entry<WTPart, List<BOMItem>> firstEntry = bom.entrySet().iterator().next();
        WTPart bomHead = firstEntry.getKey();
        List<BOMItem> bomChild = firstEntry.getValue();

        //若有行号为空就跳过
        for (BOMItem bomItem : bomChild) {
            if (StringUtils.isBlank(bomItem.getLineNumber())) {
                flag = false;
                break;
            }
        }

        return flag;

//        if (flag) {
//            return new BOMSendResult(true, null, bomHead);
//        }  else {
//            return new BOMSendResult(true, "BOM存在空行号,请检查！", bomHead);
//        }
    }


    //比较BOM差异SAP
    public static Map<WTPart, BOMSendResult> sendSingleBOMToSAP(WTPart beforeWTPart, WTPart afterWTPart, String targetFactory) throws WTException {
        //标记具体BOM返回信息
        Map<WTPart, BOMSendResult> sendResultMap = new HashMap<>();
        //查询BOM，有就更新---2  没有就新建---1
        Boolean createOrUpdateBOMIndex = queryBOMWillCreateOrUpdate(afterWTPart, targetFactory);
        String sapSign = createOrUpdateBOMIndex ? "2" : "1";

        //获取转换后的受影响和产生后BOM   option 为wf  不用弹出行号错误
        Map<WTPart, List<BOMItem>> beforeWTPartListMap = bomConvertToBomItem(beforeWTPart, targetFactory, Constant.WORKFLOW);
        Map<WTPart, List<BOMItem>> afterWTPartListMap = bomConvertToBomItem(afterWTPart, targetFactory, Constant.WORKFLOW);

        //比较完成记录前后差异的BOM
        Map<WTPart, List<BOMItem>> wtPartListMap = compareBOMItems(beforeWTPartListMap, afterWTPartListMap);



        //若是没有行号  直接return
        if (!checkBOMLineNumber(wtPartListMap)) {
            BOMSendResult bomSendResult = new BOMSendResult(false, Constant.LINE_NUMBER_ERR_MSG, afterWTPart);
            sendResultMap.put(afterWTPart, bomSendResult);
            return sendResultMap;
        }

        //发送差异记录BOM，返回的信息
        BOMSendResult sendResult = sendSingleBom(wtPartListMap, targetFactory, sapSign);


        //sendResult.getPart()存的是产生后的BOM部件
        if (sendResult.getPart() != null) { // 如果是BOM才记录结果
            sendResultMap.put(sendResult.getPart(), sendResult);
        }
        return sendResultMap;
    }


    /**
     * 将WindchillBOM转换为BOMItem类
     *
     * @param wtPart
     * @param targetFactory
     * @returnthrows WTException
     * @throws WTException
     */
    public static Map<WTPart, List<BOMItem>> bomConvertToBomItem(WTPart wtPart, String targetFactory, String option) throws WTException {

        Map<WTPart, List<BOMItem>> bomItemMap = new HashMap<>();
        List<BOMItem> bomItemList = new ArrayList<>();

        //子料
        List<WTPartUsageLink> partUsageLinks = PartUtil.getSortLinksByPart(wtPart);


        String BOMNumber = wtPart.getNumber();
        Timestamp modifyTimestamp = wtPart.getModifyTimestamp();
        int substituteGroupCounter = 1;

        // 用于存储每个需要累加的纯数字行号对应的总数量
        Map<String, BigDecimal> lineNumberSumMap = new HashMap<>();
        // 用于存储每个行号+物料号对应的替代组号
        Map<String, String> lineNumberPartGroupMap = new HashMap<>();

        // 第一步：先遍历所有link，计算每个纯数字行号的数量总和，并确定替代组号
        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            IBAUtil usageLinkIBA = new IBAUtil(partUsageLink);
            // 去掉空格
            String primaryPartLineNumberStr = StringUtils.deleteWhitespace(usageLinkIBA.getIBAValue(Constant.AI_LineNumber));
            WTPartMaster childMaster = partUsageLink.getUses();
            String partNumber = childMaster.getNumber();

            if (StringUtils.isBlank(primaryPartLineNumberStr) && Constant.PROCESS.equals(option)) {
                throw new WTException("BOM :" + wtPart.getNumber() + " 发现空行号请检查");
            }

            // 判断是否为纯数字
            boolean isNumeric = primaryPartLineNumberStr.matches("\\d+");

            // 格式化行号
            String primaryPartLineNumberStrRepairZero;
            if (isNumeric) {
                long primaryPartLineNumberStrLong = Long.parseLong(primaryPartLineNumberStr);
                primaryPartLineNumberStrRepairZero = String.format("%04d", primaryPartLineNumberStrLong);
            } else {
                primaryPartLineNumberStrRepairZero = primaryPartLineNumberStr;
            }

            // 创建组合key：行号 + 物料号
            String lineNumberPartKey = primaryPartLineNumberStrRepairZero + "_" + partNumber;

            // 只有纯数字的行号才累加数量
            if (isNumeric) {
                Quantity amount = partUsageLink.getQuantity();
                if (amount != null) {
                    BigDecimal qty = BigDecimal.valueOf(amount.getAmount());
                    lineNumberSumMap.merge(primaryPartLineNumberStrRepairZero, qty, BigDecimal::add);
                }
            }

            // 分配替代组号（每个行号+物料号只分配一次）
            List<WTPartSubstituteLink> partSubstituteLinks = PartUtil.getWTPartSubstituteLinks(partUsageLink);
            if (!partSubstituteLinks.isEmpty() && !lineNumberPartGroupMap.containsKey(lineNumberPartKey)) {
//                lineNumberPartGroupMap.put(lineNumberPartKey, String.format("%02d", substituteGroupCounter));
//                substituteGroupCounter++;

                String groupNumber = convertToSapGroupNumber(substituteGroupCounter);
                lineNumberPartGroupMap.put(lineNumberPartKey, groupNumber);
                substituteGroupCounter++;
            }
        }

        // 第二步：原来的循环逻辑
        for (int i = 0; i < partUsageLinks.size(); i++) {
            WTPartUsageLink partUsageLink = partUsageLinks.get(i);
            IBAUtil usageLinkIBA = new IBAUtil(partUsageLink);
            WTPartMaster childMaster = partUsageLink.getUses();

            BOMItem masterWTPart = new BOMItem();
            String primaryPartLineNumberStr =StringUtils.deleteWhitespace(usageLinkIBA.getIBAValue(Constant.AI_LineNumber));
            String partNumber = childMaster.getNumber();
            String placementSlde = usageLinkIBA.getIBAValue(Constant.AI_Placement_Side);
            String ebortValue = PartUtil.getUsageLinkPartUsesOccurrence(partUsageLink);

            // 判断是否为纯数字
            boolean isNumeric = primaryPartLineNumberStr.matches("\\d+");

            // 格式化行号（用于显示）
            String primaryPartLineNumberStrRepairZero;
            if (isNumeric) {
                long primaryPartLineNumberStrLong = Long.parseLong(primaryPartLineNumberStr);
                primaryPartLineNumberStrRepairZero = String.format("%04d", primaryPartLineNumberStrLong);
            } else {
                primaryPartLineNumberStrRepairZero = primaryPartLineNumberStr;
            }

            // 创建组合key：行号 + 物料号
            String lineNumberPartKey = primaryPartLineNumberStrRepairZero + "_" + partNumber;

            // 获取替代料并排序（关键修改：按物料号排序）
            List<WTPartSubstituteLink> partSubstituteLinks = PartUtil.getWTPartSubstituteLinks(partUsageLink);
            if (!partSubstituteLinks.isEmpty()) {
                // 对替代料按优先级排序
                Collections.sort(partSubstituteLinks, new Comparator<WTPartSubstituteLink>() {
                    @Override
                    public int compare(WTPartSubstituteLink o1, WTPartSubstituteLink o2) {
                        try {
                            IBAUtil iba1 = new IBAUtil(o1);
                            IBAUtil iba2 = new IBAUtil(o2);

                            String priority1 = iba1.getIBAValue(Constant.AI_Priority);
                            String priority2 = iba2.getIBAValue(Constant.AI_Priority);

                            // 处理空优先级（空值排在最后）
                            if (StringUtils.isBlank(priority1) && StringUtils.isBlank(priority2)) {
                                return 0;
                            } else if (StringUtils.isBlank(priority1)) {
                                return 1;
                            } else if (StringUtils.isBlank(priority2)) {
                                return -1;
                            }

                            // 都是数字，按数值比较
                            try {
                                int p1 = Integer.parseInt(priority1);
                                int p2 = Integer.parseInt(priority2);
                                return Integer.compare(p1, p2);
                            } catch (NumberFormatException e) {
                                return priority1.compareTo(priority2);
                            }
                        } catch (WTException e) {
                            return 0;
                        }
                    }
                });
            }

            // 处理替代料组号
            String substitutePartGroupStr = lineNumberPartGroupMap.get(lineNumberPartKey);
            String AI_PRIO = "";
            String AI_STRATEG = "";
            String USAGE_PROB = "";

            // 如果该组合有替代料，设置替代料相关属性
            if (substitutePartGroupStr != null && !substitutePartGroupStr.isEmpty()) {
                AI_PRIO = "01";
                AI_STRATEG = "1";
                USAGE_PROB = "100";
            } else {
                substitutePartGroupStr = "";  // 没有替代料时组号为空
            }

            masterWTPart.setBomNum(BOMNumber);
            masterWTPart.setFactory(targetFactory);
            masterWTPart.setDATUV(sdf.format(modifyTimestamp));
            masterWTPart.setLineNumber(primaryPartLineNumberStrRepairZero);
            masterWTPart.setPartNumber(partNumber);

            // 根据是否为纯数字决定使用总和还是原始数量
            Quantity amount = partUsageLink.getQuantity();
            String originalQuantity = amount != null ? String.valueOf(amount.getAmount()) : "";

            if (isNumeric) {
                // 纯数字行号从lineNumberSumMap中获取该行号的总数量
                BigDecimal totalQuantity = lineNumberSumMap.get(primaryPartLineNumberStrRepairZero);
                masterWTPart.setQuantity(totalQuantity != null ? totalQuantity.toString() : originalQuantity);
            } else {
                // 非纯数字行号使用原始数量
                masterWTPart.setQuantity(originalQuantity);
            }

            //变为大写
            String partUsageLinkUint = CommonUtil.convertUnit(partUsageLink.getQuantity().getUnit().getValue().toUpperCase());
            masterWTPart.setUnit(partUsageLinkUint);
            // 损耗率
            String lossRate = usageLinkIBA.getIBAValue(Constant.AI_LossRate);
            masterWTPart.setLossRate(lossRate);
            // 替代料组 - 使用统一的组号（基于行号+物料号）
            masterWTPart.setGroup(substitutePartGroupStr);
            masterWTPart.setPriority(AI_PRIO);
            masterWTPart.setStrategy(AI_STRATEG);
            masterWTPart.setUsageProb(USAGE_PROB);

            // 获取位号,号隔开
            masterWTPart.setEbort(ebortValue);

            if (ebortValue != null && !ebortValue.trim().isEmpty()) {
                masterWTPart.setUpmng(originalQuantity);  // upmng保持原来的单个数量
                masterWTPart.setUptxt(placementSlde);
            } else {
                masterWTPart.setUpmng("");
                masterWTPart.setUptxt("");
            }
            //超级BOM传入数据
            masterWTPart.setScode("");

            //设置id
            masterWTPart.setId(BOMNumber + primaryPartLineNumberStrRepairZero + placementSlde);

            //返回的BOMList
            bomItemList.add(masterWTPart);

            List<BOMItem> subWTPart = new ArrayList<>();

            // 处理替代料 - 使用排序后的列表
            for (int j = 0; j < partSubstituteLinks.size(); j++) {
                WTPartSubstituteLink partSubstituteLink = partSubstituteLinks.get(j);
                IBAUtil partSubstituteLinkIBA = new IBAUtil(partSubstituteLink);
                WTPartMaster substitutes = partSubstituteLink.getSubstitutes();

                BOMItem substituteWTPart = new BOMItem();
                subWTPart.add(substituteWTPart);

                substituteWTPart.setBomNum(BOMNumber);
                substituteWTPart.setFactory(targetFactory);
                substituteWTPart.setDATUV(sdf.format(modifyTimestamp));

                // 生成替代料行号（使用排序后的索引j，确保相同物料得到相同行号）
                String substituteLineNumber;
                if (isNumeric) {
                    long baseLineNumber = Long.parseLong(primaryPartLineNumberStr);
                    long substituteLineNumberLong = baseLineNumber + j + 1L;
                    substituteLineNumber = String.format("%04d", substituteLineNumberLong);
                } else {
                    substituteLineNumber = primaryPartLineNumberStr + "_" + (j + 1);
                }

                substituteWTPart.setLineNumber(substituteLineNumber);
                substituteWTPart.setPartNumber(substitutes.getNumber());

                // 替代料的quantity根据主料是否为纯数字决定
                if (isNumeric) {
                    BigDecimal totalQuantity = lineNumberSumMap.get(primaryPartLineNumberStrRepairZero);
                    substituteWTPart.setQuantity(totalQuantity != null ? totalQuantity.toString() : originalQuantity);
                } else {
                    substituteWTPart.setQuantity(originalQuantity);
                }

                substituteWTPart.setUnit(partUsageLinkUint);
                // 损耗率
                substituteWTPart.setLossRate(lossRate);
                // 替代料使用与主料相同的组号（基于行号+物料号）
                substituteWTPart.setGroup(substitutePartGroupStr);
                substituteWTPart.setPriority(partSubstituteLinkIBA.getIBAValue(Constant.AI_Priority));
                substituteWTPart.setStrategy("1");
                substituteWTPart.setUsageProb("0");

                // 替代料的安装面与主料相同
                substituteWTPart.setEbort(ebortValue);
                if (ebortValue != null && !ebortValue.trim().isEmpty()) {
                    substituteWTPart.setUpmng(originalQuantity);
                    substituteWTPart.setUptxt(placementSlde);
                } else {
                    substituteWTPart.setUpmng("");
                    substituteWTPart.setUptxt("");
                }
                //超级BOM传入数据
                substituteWTPart.setScode("");

                //替代料ID
                substituteWTPart.setId(BOMNumber + substituteLineNumber + placementSlde);

                bomItemList.add(substituteWTPart);
            }

            //存储替代料
            masterWTPart.setSubstitutePart(subWTPart);
        }

        // 第三步：对bomItemList进行排序
        Collections.sort(bomItemList, BOM_ITEM_COMPARATOR);

        bomItemMap.put(wtPart, bomItemList);
        return bomItemMap;
    }

    /**
     * 将替代组序号转换为SAP支持的2位格式
     *
     * 第一级 1-99: 01-99（纯数字）
     * 第二级 100-333: 1A-9Z（数字+字母，共9*26=234个）
     * 第三级 334-1009: AA-ZZ（纯字母，共26*26=676个）
     *
     * 最大支持：99 + 234 + 676 = 1009组
     *
     * 映射规则：
     * 1-99 -> 01-99
     * 100-125 -> 1A-1Z
     * 126-151 -> 2A-2Z
     * ...
     * 308-333 -> 9A-9Z
     * 334-359 -> AA-AZ
     * 360-385 -> BA-BZ
     * ...
     * 1009 -> ZZ
     *
     * @param groupCounter 组序号（从1开始）
     * @return 2位格式的组号
     */
    public static String convertToSapGroupNumber(int groupCounter) {
        // 参数校验
        if (groupCounter < 1) {
            throw new IllegalArgumentException("组序号必须大于0，当前值：" + groupCounter);
        }

        // 第一级：1-99 使用数字格式
        if (groupCounter <= 99) {
            return String.format("%02d", groupCounter);
        }

        // 第二级：100-333 使用数字+字母格式（1A-9Z）
        int secondLevelStart = 100;
        int secondLevelEnd = 99 + 9 * 26; // 333
        if (groupCounter <= secondLevelEnd) {
            int alphaIndex = groupCounter - secondLevelStart;
            int numberPart = alphaIndex / 26 + 1;   // 数字部分 1-9
            int letterIndex = alphaIndex % 26;       // 字母索引 0-25
            char letter = (char) ('A' + letterIndex);
            return numberPart + String.valueOf(letter);
        }

        // 第三级：334-1009 使用纯字母格式（AA-ZZ）
        int thirdLevelStart = secondLevelEnd + 1; // 334
        int maxGroup = thirdLevelStart + 26 * 26 - 1; // 1009
        if (groupCounter > maxGroup) {
            throw new RuntimeException("替代料组数超过最大限制" + maxGroup + "组，当前第" + groupCounter + "组");
        }

        int alphaIndex = groupCounter - thirdLevelStart;
        int firstLetterIndex = alphaIndex / 26;   // 第一个字母索引 0-25
        int secondLetterIndex = alphaIndex % 26;  // 第二个字母索引 0-25

        char firstLetter = (char) ('A' + firstLetterIndex);
        char secondLetter = (char) ('A' + secondLetterIndex);

        return String.valueOf(firstLetter) + String.valueOf(secondLetter);
    }

    /**
     * 反向解析：将SAP组号转换回序号（用于调试或反向转换）
     *
     * @param sapGroupNumber SAP组号（2位字符）
     * @return 组序号
     */
    public static int parseSapGroupNumber(String sapGroupNumber) {
        if (sapGroupNumber == null || sapGroupNumber.length() != 2) {
            throw new IllegalArgumentException("SAP组号必须是2位字符，当前值：" + sapGroupNumber);
        }

        char firstChar = sapGroupNumber.charAt(0);
        char secondChar = sapGroupNumber.charAt(1);

        // 第一级：纯数字格式 01-99
        if (firstChar >= '0' && firstChar <= '9' && secondChar >= '0' && secondChar <= '9') {
            return Integer.parseInt(sapGroupNumber);
        }

        // 第二级：数字+字母格式 1A-9Z
        if (firstChar >= '1' && firstChar <= '9' && secondChar >= 'A' && secondChar <= 'Z') {
            int numberPart = firstChar - '0';
            int letterIndex = secondChar - 'A';
            return 100 + (numberPart - 1) * 26 + letterIndex;
        }

        // 第三级：纯字母格式 AA-ZZ
        if (firstChar >= 'A' && firstChar <= 'Z' && secondChar >= 'A' && secondChar <= 'Z') {
            int firstIndex = firstChar - 'A';
            int secondIndex = secondChar - 'A';
            int thirdLevelStart = 99 + 9 * 26 + 1; // 334
            return thirdLevelStart + firstIndex * 26 + secondIndex;
        }

        throw new IllegalArgumentException("无效的SAP组号格式：" + sapGroupNumber);
    }


    // 在类中定义一个静态的比较器
    private static final Comparator<BOMItem> BOM_ITEM_COMPARATOR = new Comparator<BOMItem>() {
        @Override
        public int compare(BOMItem o1, BOMItem o2) {
            // 1. 先按行号排序
            String lineNumber1 = o1.getLineNumber();
            String lineNumber2 = o2.getLineNumber();

            int lineCompare = compareLineNumbers(lineNumber1, lineNumber2);
            if (lineCompare != 0) {
                return lineCompare;
            }

            // 2. 行号相同，按物料号排序
            String partNumber1 = o1.getPartNumber();
            String partNumber2 = o2.getPartNumber();

            if (partNumber1 == null && partNumber2 == null) {
                // 继续比较下一项
            } else if (partNumber1 == null) {
                return -1;
            } else if (partNumber2 == null) {
                return 1;
            } else {
                int partCompare = partNumber1.compareTo(partNumber2);
                if (partCompare != 0) {
                    return partCompare;
                }
            }

            // 3. 行号和物料号都相同，按安装面排序
            String uptxt1 = o1.getUptxt();
            String uptxt2 = o2.getUptxt();

            if (uptxt1 == null && uptxt2 == null) {
                // 继续比较下一项
            } else if (uptxt1 == null) {
                return -1;
            } else if (uptxt2 == null) {
                return 1;
            } else {
                int uptxtCompare = uptxt1.compareTo(uptxt2);
                if (uptxtCompare != 0) {
                    return uptxtCompare;
                }
            }

            // 4. 行号、物料号、安装面都相同，按优先级排序（空值排在后面）
            String priority1 = o1.getPriority();
            String priority2 = o2.getPriority();

            if (priority1 == null && priority2 == null) {
                return 0;
            } else if (priority1 == null) {
                return 1;
            } else if (priority2 == null) {
                return -1;
            } else {
                return priority1.compareTo(priority2);
            }
        }

        /**
         * 比较行号的方法
         */
        private int compareLineNumbers(String line1, String line2) {
            if (line1 == null && line2 == null) {
                return 0;
            } else if (line1 == null) {
                return -1;
            } else if (line2 == null) {
                return 1;
            }

            boolean isNumeric1 = line1.matches("\\d+");
            boolean isNumeric2 = line2.matches("\\d+");

            if (isNumeric1 && isNumeric2) {
                Long num1 = Long.parseLong(line1);
                Long num2 = Long.parseLong(line2);
                return num1.compareTo(num2);
            } else if (isNumeric1) {
                return -1;
            } else if (isNumeric2) {
                return 1;
            } else {
                return line1.compareTo(line2);
            }
        }
    };



    /**
     * 发送单层差异BOM
     *
     * @param bom
     * @param targetFactory
     * @param sign
     */
    public static BOMSendResult sendSingleBom(Map<WTPart, List<BOMItem>> bom, String targetFactory, String sign) throws WTException {

        Map.Entry<WTPart, List<BOMItem>> firstEntry = bom.entrySet().iterator().next();
        WTPart bomHead = firstEntry.getKey();
        List<BOMItem> bomChild = firstEntry.getValue();


        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_BOM);
        JCoParameterList importParam = function.getImportParameterList();
        importParam.setValue(Constant.I_FLAG, sign);
        if ("2".equals(sign)) {
            // 修改时的默认ECN编号
            String changeNumber = getBOMLasterECNNumber(bomHead);
            // 如果我修改bom必须要ECNid
            importParam.setValue("I_CHANGE_NO", changeNumber);
        }

        JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_BOM);

        for (BOMItem bomItem : bomChild) {

            inputTable.appendRow();
            inputTable.setValue(Constant.MATNR, bomItem.getBomNum());
            inputTable.setValue(Constant.WERKS, targetFactory);
            inputTable.setValue(Constant.STLAN, bomItem.getSTLAN());
            inputTable.setValue(Constant.STLAL, bomItem.getSTLAL());
            inputTable.setValue(Constant.STATUS, bomItem.getSTATUS());
            inputTable.setValue(Constant.DATUV, bomItem.getDATUV());
            inputTable.setValue(Constant.BASE_QUAN, bomItem.getBASE_QUNA());//基本数量
            inputTable.setValue(Constant.ITEM_NO, bomItem.getLineNumber());
            inputTable.setValue(Constant.ITEM_CATEG, bomItem.getITEM_CATEG());
            inputTable.setValue(Constant.COMPONENT, bomItem.getPartNumber());
            inputTable.setValue(Constant.COMP_QTY, bomItem.getQuantity());//组件数量
            //变为大写
            inputTable.setValue(Constant.COMP_UNIT, bomItem.getUnit());//
            // 损耗率
            inputTable.setValue(Constant.COMP_SCRAP, bomItem.getLossRate());
            // 替代料组 - 只有有替代料时才有值
            inputTable.setValue(Constant.AI_GROUP, bomItem.getGroup());
            inputTable.setValue(Constant.AI_PRIO, bomItem.getPriority());
            inputTable.setValue(Constant.AI_STRATEG, bomItem.getStrategy());
            inputTable.setValue(Constant.USAGE_PROB, bomItem.getUsageProb());

            // 获取位号,号隔开

            inputTable.setValue(Constant.EBORT, bomItem.getEbort());
            inputTable.setValue(Constant.UPMNG, bomItem.getUpmng());//Sub-item quantity (BTCI)
            inputTable.setValue(Constant.UPTXT, bomItem.getUptxt());
            //超级BOM传入数据
            inputTable.setValue(Constant.SCODE, bomItem.getScode());
            inputTable.setValue(Constant.FLDELETE, bomItem.getOption());
        }

        // 执行RFC
        RfcManager.execute(function);

        // 处理发送结果
        JCoParameterList exportParam = function.getExportParameterList();
        String globalType = exportParam.getString(Constant.E_TYPE);
        String globalMessage = exportParam.getString(Constant.E_MESSAGE);

        System.out.println("BOM操作:" + sign);
        System.out.println("当前操作的BOM是:" + bomHead);
        System.out.println("BOM操作返回的E_TYPE:" + globalType);
        System.out.println("BOM操作返回的E_MESSAGE:" + globalMessage);
        // 详细输出输入表内容
        System.out.println("\n========== 输入表数据详情 ==========");
        if (inputTable != null && inputTable.getNumRows() > 0) {
            inputTable.firstRow();
            int rowCount = 0;

            do {
                rowCount++;
                System.out.println("--- 第 " + rowCount + " 行 ---");
                System.out.println("  物料编码(MATNR): " + inputTable.getString(Constant.MATNR));
                System.out.println("  工厂(WERKS): " + inputTable.getString(Constant.WERKS));
                System.out.println("  行号(ITEM_NO): " + inputTable.getString(Constant.ITEM_NO));
                System.out.println("  项目类别(ITEM_CATEG): " + inputTable.getString(Constant.ITEM_CATEG));
                System.out.println("  组件(COMPONENT): " + inputTable.getString(Constant.COMPONENT));
                System.out.println("  数量(COMP_QTY): " + inputTable.getString(Constant.COMP_QTY));
                System.out.println("  单位(COMP_UNIT): " + inputTable.getString(Constant.COMP_UNIT));
                System.out.println("  损耗率(COMP_SCRAP): " + inputTable.getString(Constant.COMP_SCRAP));
                System.out.println("  生效日期(DATUV): " + inputTable.getString(Constant.DATUV));
                System.out.println("  基本数量(BASE_QUAN): " + inputTable.getString(Constant.BASE_QUAN));
                System.out.println("  状态(STATUS): " + inputTable.getString(Constant.STATUS));
                System.out.println("  BOM用途(STLAN): " + inputTable.getString(Constant.STLAN));
                System.out.println("  可选的BOM(STLAL): " + inputTable.getString(Constant.STLAL));
                System.out.println("  替代料组(AI_GROUP): " + inputTable.getString(Constant.AI_GROUP));
                System.out.println("  优先级(AI_PRIO): " + inputTable.getString(Constant.AI_PRIO));
                System.out.println("  策略(AI_STRATEG): " + inputTable.getString(Constant.AI_STRATEG));
                System.out.println("  使用概率(USAGE_PROB): " + inputTable.getString(Constant.USAGE_PROB));
                System.out.println("  位号(EBORT): " + inputTable.getString(Constant.EBORT));
                System.out.println("  位号数量(UPMNG): " + inputTable.getString(Constant.UPMNG));
                System.out.println("  安装面(UPTXT): " + inputTable.getString(Constant.UPTXT));
                System.out.println("  超级BOM代码(SCODE): " + inputTable.getString(Constant.SCODE));
                System.out.println("  OPTION(FLDELETE): " + inputTable.getString(Constant.FLDELETE));

                // 添加空行便于阅读
                System.out.println("\n");
            } while (inputTable.nextRow());

            System.out.println("总计行数: " + rowCount + " 行");
        } else {
            System.out.println("输入表为空或未找到数据");
        }

        if (Constant.S.equals(globalType)) {
            return new BOMSendResult(true, null, bomHead);
        } else if (Constant.E.equals(globalType)) {
            return new BOMSendResult(false, globalMessage, bomHead);
        } else {
            return new BOMSendResult(true, globalMessage, bomHead);
        }

    }


//    /**
//     * 创建或修改单个BOM
//     * @param bom
//     * @param targetFactory
//     * @param sign
//     */
//    public static Boolean sendSingleBom(WTPart bom, String targetFactory, String sign) throws WTException {
//        Boolean result = false;
//        List<WTPartUsageLink> partUsageLinks = PartUtil.getLinksByPart(bom);
//        if(partUsageLinks.isEmpty()){
//            // 不是BOM
//            // 调用SAP删除功能删掉
//
//            return null;
//        }
//        String BOMNumber = bom.getNumber();
//        Timestamp modifyTimestamp = bom.getModifyTimestamp();
//        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_BOM);
//        // 设置import 参数
//        JCoParameterList importParam = function.getImportParameterList();
//        importParam.setValue(Constant.I_FLAG, sign);
//
//        JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_BOM);
//        for (int i = 0; i < partUsageLinks.size(); i++) {
//            WTPartUsageLink partUsageLink = partUsageLinks.get(i);
//            // BOM 替代物料组
//            int substitutePartGroup = i+1;
//            IBAUtil usageLinkIBA = new IBAUtil(partUsageLink);
//            WTPartMaster childMaster = partUsageLink.getUses();
//            inputTable.appendRow();
//            inputTable.setValue(Constant.MATNR, BOMNumber);
//            inputTable.setValue(Constant.WERKS, targetFactory);
//            inputTable.setValue(Constant.STLAN, "3");
//            inputTable.setValue(Constant.STLAL, "1");
//            inputTable.setValue(Constant.STATUS, "1");
//            inputTable.setValue(Constant.DATUV, sdf.format(modifyTimestamp));
//            inputTable.setValue(Constant.BASE_QUAN, "1");
//            // 主料行号字符串
//            String primaryPartLineNumberStr = partUsageLink.getLineNumber().toString();
//            // 主料行号字符串long类型
//            long primaryPartLineNumberStrLong = partUsageLink.getLineNumber().getValue();
//            String primaryPartLineNumberStrRepairZero= String.format("%04d", primaryPartLineNumberStrLong);
//            inputTable.setValue(Constant.ITEM_NO, primaryPartLineNumberStrRepairZero);
//            inputTable.setValue(Constant.ITEM_CATEG, "L");
//            inputTable.setValue(Constant.COMPONENT, childMaster.getNumber());
//            inputTable.setValue(Constant.COMP_QTY, partUsageLink.getQuantity().getAmount());
////            System.out.println("使用单位:"+Constant.COMP_UNIT+"的值是:"+partUsageLink.getQuantity().getUnit().getValue());
//            inputTable.setValue(Constant.COMP_UNIT, partUsageLink.getQuantity().getUnit().getValue());
//            // 损耗率
//            inputTable.setValue(Constant.COMP_SCRAP, usageLinkIBA.getIBAValue(Constant.AI_LossRate));
//            String substitutePartGroupStr = String.format("%02d", substitutePartGroup);
//            inputTable.setValue(Constant.AI_GROUP, substitutePartGroupStr);
//            inputTable.setValue(Constant.AI_PRIO, "01");
//            inputTable.setValue(Constant.AI_STRATEG, "1");
//            inputTable.setValue(Constant.USAGE_PROB, "100");
//            // 获取位号,号隔开
//            inputTable.setValue(Constant.EBORT, PartUtil.getUsageLinkPartUsesOccurrence(partUsageLink));
//            inputTable.setValue(Constant.UPMNG, partUsageLink.getQuantity().getAmount());
//            inputTable.setValue(Constant.UPTXT, usageLinkIBA.getIBAValue("AI_PlacementSide"));
//            inputTable.setValue(Constant.SCODE, "");
//
//            List<WTPartSubstituteLink> partSubstituteLinks = PartUtil.getWTPartSubstituteLinks(partUsageLink);
//            for (int j = 0; j < partSubstituteLinks.size(); j++) {
//                WTPartSubstituteLink partSubstituteLink = partSubstituteLinks.get(j);
//                IBAUtil partSubstituteLinkIBA = new IBAUtil(partSubstituteLink);
//                WTPartMaster substitutes = partSubstituteLink.getSubstitutes();
//
//                inputTable.appendRow();
//                inputTable.setValue(Constant.MATNR, BOMNumber);
//                inputTable.setValue(Constant.WERKS, targetFactory);
//                inputTable.setValue(Constant.STLAN, "3");
//                inputTable.setValue(Constant.STLAL, "1");
//                inputTable.setValue(Constant.STATUS, "1");
//                inputTable.setValue(Constant.DATUV, sdf.format(modifyTimestamp));
//                inputTable.setValue(Constant.BASE_QUAN, "1");
//                long nextSubPartLineNumberStrLong = primaryPartLineNumberStrLong+j+1L;
//                String nextSubPartLineNumberStrLongRepairZero= String.format("%04d", nextSubPartLineNumberStrLong);
//                inputTable.setValue(Constant.ITEM_NO, nextSubPartLineNumberStrLongRepairZero);
//                inputTable.setValue(Constant.ITEM_CATEG, "L");
//                inputTable.setValue(Constant.COMPONENT, substitutes.getNumber());
//                inputTable.setValue(Constant.COMP_QTY, partUsageLink.getQuantity().getAmount());
//                inputTable.setValue(Constant.COMP_UNIT, partUsageLink.getQuantity().getUnit().getValue());
//                // 损耗率
//                inputTable.setValue(Constant.COMP_SCRAP, usageLinkIBA.getIBAValue(Constant.AI_LossRate));
//                inputTable.setValue(Constant.AI_GROUP, substitutePartGroupStr);
//                inputTable.setValue(Constant.AI_PRIO, partSubstituteLinkIBA.getIBAValue(Constant.AI_Priority));
//                inputTable.setValue(Constant.AI_STRATEG, "1");
//                inputTable.setValue(Constant.USAGE_PROB, "0");
//                // 获取位号,号隔开
//                inputTable.setValue(Constant.EBORT, PartUtil.getUsageLinkPartUsesOccurrence(partUsageLink));
//                inputTable.setValue(Constant.UPMNG, partUsageLink.getQuantity().getAmount());
//                inputTable.setValue(Constant.UPTXT, usageLinkIBA.getIBAValue("AI_PlacementSide"));
//                inputTable.setValue(Constant.SCODE, "");
//            }
//
//        }
//       logger.debug("待发送TABLE:"+inputTable);
//
//        // 执行RFC
//        RfcManager.execute(function);
//        // 处理发送结果
//        // 获取全局返回参数
//        JCoParameterList exportParam = function.getExportParameterList();
//
//        String globalType = exportParam.getString(Constant.E_TYPE);
//        String globalMessage = exportParam.getString(Constant.E_MESSAGE);
//        JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_BOM);
//        JCoTable tReturn = function.getTableParameterList().getTable("T_RETURN");
//       logger.debug("BOM操作:"+sign);
//       logger.debug("BOM操作返回的E_TYPE:"+globalType);
//       logger.debug("BOM操作返回的E_MESSAGE:"+globalMessage);
//       logger.debug("BOM操作返回的结果table:"+returnTable);
//       logger.debug("BOM操作返回的tReturn结果table:"+tReturn);
//        if(Constant.S.equals(globalType)){
//            result = true;
//        }else {
//            result = false;
//        }
//
//        return  result;
//    }


    /**
     * 创建或修改单个BOM  禁用  行号存在非数字问题没改，
     *
     * @param bom
     * @param targetFactory
     * @param sign
     */
    public static BOMSendResult sendSingleBom(WTPart bom, String targetFactory, String sign) throws WTException {
        List<WTPartUsageLink> partUsageLinks = PartUtil.getSortLinksByPart(bom);

        // 以当前BOM为条件查询以它为产生的对象 的ECN编号 若有多个取最新ECN
        if (partUsageLinks.isEmpty()) {
            // 不是BOM
//            return new BOMSendResult(false, "该部件不是BOM结构", bom);
        }

        String BOMNumber = bom.getNumber();
        Timestamp modifyTimestamp = bom.getModifyTimestamp();
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_BOM);

        // 设置import 参数
        JCoParameterList importParam = function.getImportParameterList();
        importParam.setValue(Constant.I_FLAG, sign);
        //超级BOM传入的标识
//        importParam.setValue(Constant.I_CLASS, "X");
        if ("2".equals(sign)) {
            // 修改时的默认ECN编号
            String changeNumber = getBOMLasterECNNumber(bom);
            // 如果我修改bom必须要ECNid
            importParam.setValue("I_CHANGE_NO", changeNumber);
        }

        JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_BOM);

        // 用于记录每个主料行的替代料组号
        int substituteGroupCounter = 1;

        for (int i = 0; i < partUsageLinks.size(); i++) {
            WTPartUsageLink partUsageLink = partUsageLinks.get(i);
            IBAUtil usageLinkIBA = new IBAUtil(partUsageLink);
            WTPartMaster childMaster = partUsageLink.getUses();

            String primaryPartLineNumberStr = usageLinkIBA.getIBAValue(Constant.AI_LineNumber);
            if (StringUtils.isBlank(primaryPartLineNumberStr)) {
                throw new WTException("BOM :" + bom.getNumber() + " 发现空行号请检查");
            }

            // 判断是否为纯数字
            String primaryPartLineNumberStrRepairZero;
            boolean isNumeric = primaryPartLineNumberStr.matches("\\d+");

            if (isNumeric) {
                // 如果是数字，转换为long再格式化为4位
                long primaryPartLineNumberStrLong = Long.parseLong(primaryPartLineNumberStr);
                primaryPartLineNumberStrRepairZero = String.format("%04d", primaryPartLineNumberStrLong);
            } else {
                // 如果不是数字，直接使用原字符串值
                primaryPartLineNumberStrRepairZero = primaryPartLineNumberStr;
            }
            List<WTPartSubstituteLink> partSubstituteLinks = PartUtil.getWTPartSubstituteLinks(partUsageLink);

            // 处理替代料组号 - 只有有替代料时才分配组号
            String substitutePartGroupStr = "";
            String AI_PRIO = "";
            String AI_STRATEG = "";
            String USAGE_PROB = "";
            //存在替代料
            if (!partSubstituteLinks.isEmpty()) {
                substitutePartGroupStr = String.format("%02d", substituteGroupCounter);
                substituteGroupCounter++;
                AI_PRIO = "01";
                AI_STRATEG = "1";
                USAGE_PROB = "100";
            }

            // 添加主料行
            inputTable.appendRow();
            inputTable.setValue(Constant.MATNR, BOMNumber);
            inputTable.setValue(Constant.WERKS, targetFactory);
            inputTable.setValue(Constant.STLAN, "3");
            inputTable.setValue(Constant.STLAL, "1");
            inputTable.setValue(Constant.STATUS, "1");
            inputTable.setValue(Constant.DATUV, sdf.format(modifyTimestamp));
            inputTable.setValue(Constant.BASE_QUAN, "1");
            String partUsageLinkPrimaryPartLineNumberStrRepairZero = String.format("%04d", primaryPartLineNumberStrRepairZero);
            inputTable.setValue(Constant.ITEM_NO, partUsageLinkPrimaryPartLineNumberStrRepairZero);
            inputTable.setValue(Constant.ITEM_CATEG, "L");
            inputTable.setValue(Constant.COMPONENT, childMaster.getNumber());
            inputTable.setValue(Constant.COMP_QTY, partUsageLink.getQuantity().getAmount());
            //变为大写
            String partUsageLinkUint = CommonUtil.convertUnit(partUsageLink.getQuantity().getUnit().getValue().toUpperCase());
            inputTable.setValue(Constant.COMP_UNIT, partUsageLinkUint);
            // 损耗率
            inputTable.setValue(Constant.COMP_SCRAP, usageLinkIBA.getIBAValue(Constant.AI_LossRate));
            // 替代料组 - 只有有替代料时才有值
            inputTable.setValue(Constant.AI_GROUP, substitutePartGroupStr);
            inputTable.setValue(Constant.AI_PRIO, AI_PRIO);
            inputTable.setValue(Constant.AI_STRATEG, AI_STRATEG);
            inputTable.setValue(Constant.USAGE_PROB, USAGE_PROB);

            // 获取位号,号隔开
            String ebortValue = PartUtil.getUsageLinkPartUsesOccurrence(partUsageLink);
            inputTable.setValue(Constant.EBORT, ebortValue);
            if (ebortValue != null && !ebortValue.trim().isEmpty()) {
                inputTable.setValue(Constant.UPMNG, partUsageLink.getQuantity().getAmount());
                inputTable.setValue(Constant.UPTXT, usageLinkIBA.getIBAValue(Constant.AI_Placement_Side));
            } else {
                inputTable.setValue(Constant.UPMNG, "");
                inputTable.setValue(Constant.UPTXT, "");
            }
            //超级BOM传入数据
            inputTable.setValue(Constant.SCODE, "");

            // 处理替代料
            for (int j = 0; j < partSubstituteLinks.size(); j++) {
                WTPartSubstituteLink partSubstituteLink = partSubstituteLinks.get(j);
                IBAUtil partSubstituteLinkIBA = new IBAUtil(partSubstituteLink);
                WTPartMaster substitutes = partSubstituteLink.getSubstitutes();

                inputTable.appendRow();
                inputTable.setValue(Constant.MATNR, BOMNumber);
                inputTable.setValue(Constant.WERKS, targetFactory);
                inputTable.setValue(Constant.STLAN, "3");
                inputTable.setValue(Constant.STLAL, "1");
                inputTable.setValue(Constant.STATUS, "1");
                inputTable.setValue(Constant.DATUV, sdf.format(modifyTimestamp));
                inputTable.setValue(Constant.BASE_QUAN, "1");
                String nextSubPartLineNumberStr;
                if (isNumeric) {
                    // 如果主料行号是数字，数字+1
                    long primaryPartLineNumberStrLong = Long.parseLong(primaryPartLineNumberStr);
                    long nextSubPartLineNumberStrLong = primaryPartLineNumberStrLong + j + 1L;
                    nextSubPartLineNumberStr = String.format("%04d", nextSubPartLineNumberStrLong);
                } else {
                    // 如果主料行号不是数字，主料行号 + 后缀
                    nextSubPartLineNumberStr = primaryPartLineNumberStr + "_" + (j + 1);
                }
//                long nextSubPartLineNumberStrLong = primaryPartLineNumberStrLong + j + 1L;
                String nextSubPartLineNumberStrLongRepairZero = String.format("%04d", nextSubPartLineNumberStr);
                inputTable.setValue(Constant.ITEM_NO, nextSubPartLineNumberStrLongRepairZero);
                inputTable.setValue(Constant.ITEM_CATEG, "L");
                inputTable.setValue(Constant.COMPONENT, substitutes.getNumber());
                inputTable.setValue(Constant.COMP_QTY, partUsageLink.getQuantity().getAmount());
                inputTable.setValue(Constant.COMP_UNIT, partUsageLinkUint);
                // 损耗率
                inputTable.setValue(Constant.COMP_SCRAP, usageLinkIBA.getIBAValue(Constant.AI_LossRate));
                // 替代料使用与主料相同的组号


                inputTable.setValue(Constant.AI_GROUP, substitutePartGroupStr);
                inputTable.setValue(Constant.AI_PRIO, partSubstituteLinkIBA.getIBAValue(Constant.AI_Priority));
                inputTable.setValue(Constant.AI_STRATEG, "1");
                inputTable.setValue(Constant.USAGE_PROB, "0");


                // 获取位号,号隔开
                inputTable.setValue(Constant.EBORT, ebortValue);
                if (ebortValue != null && !ebortValue.trim().isEmpty()) {
                    inputTable.setValue(Constant.UPMNG, partUsageLink.getQuantity().getAmount());
                    inputTable.setValue(Constant.UPTXT, usageLinkIBA.getIBAValue(Constant.AI_Placement_Side));
                } else {
                    inputTable.setValue(Constant.UPMNG, "");
                    inputTable.setValue(Constant.UPTXT, "");
                }
                //超级BOM传入数据
                inputTable.setValue(Constant.SCODE, "");
            }
        }

        // 执行RFC
        RfcManager.execute(function);

        // 处理发送结果
        JCoParameterList exportParam = function.getExportParameterList();
        String globalType = exportParam.getString(Constant.E_TYPE);
        String globalMessage = exportParam.getString(Constant.E_MESSAGE);


        System.out.println("BOM操作:" + sign);
        System.out.println("当前操作的BOM是:" + BOMNumber);
        System.out.println("BOM操作返回的E_TYPE:" + globalType);
        System.out.println("BOM操作返回的E_MESSAGE:" + globalMessage);
        // 详细输出输入表内容
        System.out.println("\n========== 输入表数据详情 ==========");
        if (inputTable != null && inputTable.getNumRows() > 0) {
            inputTable.firstRow();
            int rowCount = 0;

            do {
                rowCount++;
                System.out.println("--- 第 " + rowCount + " 行 ---");
                System.out.println("  物料编码(MATNR): " + inputTable.getString(Constant.MATNR));
                System.out.println("  工厂(WERKS): " + inputTable.getString(Constant.WERKS));
                System.out.println("  行号(ITEM_NO): " + inputTable.getString(Constant.ITEM_NO));
                System.out.println("  项目类别(ITEM_CATEG): " + inputTable.getString(Constant.ITEM_CATEG));
                System.out.println("  组件(COMPONENT): " + inputTable.getString(Constant.COMPONENT));
                System.out.println("  数量(COMP_QTY): " + inputTable.getString(Constant.COMP_QTY));
                System.out.println("  单位(COMP_UNIT): " + inputTable.getString(Constant.COMP_UNIT));
                System.out.println("  损耗率(COMP_SCRAP): " + inputTable.getString(Constant.COMP_SCRAP));
                System.out.println("  生效日期(DATUV): " + inputTable.getString(Constant.DATUV));
                System.out.println("  基本数量(BASE_QUAN): " + inputTable.getString(Constant.BASE_QUAN));
                System.out.println("  状态(STATUS): " + inputTable.getString(Constant.STATUS));
                System.out.println("  BOM用途(STLAN): " + inputTable.getString(Constant.STLAN));
                System.out.println("  可选的BOM(STLAL): " + inputTable.getString(Constant.STLAL));
                System.out.println("  替代料组(AI_GROUP): " + inputTable.getString(Constant.AI_GROUP));
                System.out.println("  优先级(AI_PRIO): " + inputTable.getString(Constant.AI_PRIO));
                System.out.println("  策略(AI_STRATEG): " + inputTable.getString(Constant.AI_STRATEG));
                System.out.println("  使用概率(USAGE_PROB): " + inputTable.getString(Constant.USAGE_PROB));
                System.out.println("  位号(EBORT): " + inputTable.getString(Constant.EBORT));
                System.out.println("  位号数量(UPMNG): " + inputTable.getString(Constant.UPMNG));
                System.out.println("  备注(UPTXT): " + inputTable.getString(Constant.UPTXT));
                System.out.println("  超级BOM代码(SCODE): " + inputTable.getString(Constant.SCODE));

                // 添加空行便于阅读
                System.out.println("\n");
            } while (inputTable.nextRow());

            System.out.println("总计行数: " + rowCount + " 行");
        } else {
            System.out.println("输入表为空或未找到数据");
        }

        if (Constant.S.equals(globalType)) {
            return new BOMSendResult(true, null, bom);
        } else if (Constant.E.equals(globalType)) {
            return new BOMSendResult(false, globalMessage, bom);
        } else {
            return new BOMSendResult(true, globalMessage, bom);
        }
    }


    /**
     * 调用接口删除BOM
     *
     * @param part
     * @param targetFactory
     */
    public static void deleteBOMFromSAP(WTPart part, String targetFactory) {

    }


    /**
     *
     * 逐一调用检查部件  是创建还是修改BOM  返回true代表SAP存在相关BOM 需要更新   反之为需要创建BOM
     *
     * @param bom
     * @param targetFactory
     * @return
     */
    private static Boolean queryBOMWillCreateOrUpdate(WTPart bom, String targetFactory) {
        Boolean result = false;
        String BOMNumber = bom.getNumber();
        // 查询选项是否于SAP中已经存在
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_BOM);

        // 设置import 参数
        JCoParameterList importParam = function.getImportParameterList();
        importParam.setValue(Constant.I_FLAG, "3");
        // 设置查询条件表 T_MARA
        JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_BOM);
        inputTable.appendRow();
        inputTable.setValue(Constant.MATNR, BOMNumber);
        inputTable.setValue(Constant.WERKS, targetFactory);
        inputTable.setValue(Constant.STLAN, "3");
        inputTable.setValue(Constant.STLAL, "1");
        // 执行RFC
        RfcManager.execute(function);
        // 获取全局返回参数
        JCoParameterList exportParam = function.getExportParameterList();

        String globalType = exportParam.getString(Constant.E_TYPE);
        String globalMessage = exportParam.getString(Constant.E_MESSAGE);

        // 获取表返回结果
        JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_BOM);
        System.out.println("当前查询的BOM是：" + BOMNumber);
        System.out.println("查询BOM返回结果TYPE:" + globalType);
        System.out.println("查询BOM返回结果MESSAGE:" + globalMessage);
//       logger.debug("查询BOM返回结果TABLE:"+returnTable);
        if (globalType.equals(Constant.S)) {
//            for (int i = 0; i < returnTable.getNumRows(); i++) {
//                returnTable.setRow(i);
//                // 从返回结果中检查是否有相同编号的BOM在SAP中
//                String MATNR = returnTable.getString(Constant.MATNR);
//                if(BOMNumber.equals(MATNR)){
//                    result = true;
//                    break;
//                }
//            }
            result = true;
        }
        return result;
    }


    /**
     * 递归获取所有待发送BOM的结构
     *
     * @param boms
     * @return
     */
    public static Map<WTPart, List<WTPartUsageLink>> getWaitSendBOMUsageLink(List<WTPart> boms) {
        Map<WTPart, List<WTPartUsageLink>> map = new HashMap<>();


        return map;
    }

    /**
     * 递归获取待发送BOM下的所有相关子项WTPart 用于发送检查是创建还是修改BOM
     *
     * @param boms
     * @return
     */
    public static Map<WTPart, List<WTPart>> queryALLWaitSendBOMFromSAP(List<WTPart> boms) {
        Map<WTPart, List<WTPart>> map = new HashMap<>();
        for (WTPart bom : boms) {
            List<WTPart> allBomByPart = PartUtil.getAllBomByPart(bom);
            map.put(bom, allBomByPart);
        }
        return map;
    }


    /**
     * 获取待发送BOM下的一层相关子项WTPart 用于发送检查是创建还是修改BOM
     *
     * @param boms
     * @return
     */
    public static Map<WTPart, List<WTPart>> querySingleWaitSendBOMFromSAP(List<WTPart> boms) {
        Map<WTPart, List<WTPart>> map = new HashMap<>();
        for (WTPart bom : boms) {
            List<WTPart> allBomByPart = PartUtil.getSingleBomByPart(bom);
            map.put(bom, allBomByPart);
        }
        return map;
    }


    /**
     * 查询当前这个BOM产生的对象的ECN对象，取时间最新的ECN编号返回
     *
     * @param bom
     * @return
     */
    private static String getBOMLasterECNNumber(WTPart bom) {

        String ECNNumber = PropertiesUtil.getValueByKey("PLMToSAP.default.ECNNumber");
        try {
            QueryResult qr = ChangeHelper2.service.getUniqueImplementedChangeOrders(bom);
            List<ChangeOrder2> ecnList = new ArrayList<>();

            while (qr.hasMoreElements()) {
                ecnList.add((ChangeOrder2) qr.nextElement());
            }

            // 使用Stream找到修改时间最新的ECN
            Optional<ChangeOrder2> latestECN = ecnList.stream()
                    .max(Comparator.comparing(ChangeOrder2::getModifyTimestamp));

            return latestECN.map(ChangeOrder2::getNumber)
                    .orElse(ECNNumber); // 如果没找到返回默认值

        } catch (WTException e) {
            e.printStackTrace();
            return ECNNumber;
        }
    }


    /**
     * 比较受影响和产生BOM
     *
     * @param beforeMap
     * @param afterMap
     * @return
     */
    public static Map<WTPart, List<BOMItem>> compareBOMItems(Map<WTPart, List<BOMItem>> beforeMap,
                                                             Map<WTPart, List<BOMItem>> afterMap) {
        // 假设每个Map只有一个WTPart，获取第一个
        WTPart beforePart = beforeMap.keySet().iterator().next();
        WTPart afterPart = afterMap.keySet().iterator().next();

        List<BOMItem> beforeList = beforeMap.get(beforePart);
        List<BOMItem> afterList = afterMap.get(afterPart);

        // 创建before项的Map，便于查找
        Map<String, BOMItem> beforeItemMap = new HashMap<>();
        for (BOMItem item : beforeList) {
            System.out.println("受影响BOM"+item.toString());
            beforeItemMap.put(item.id, item);
        }

        List<BOMItem> resultList = new ArrayList<>();

        // 步骤1: 处理after中的项（新增或修改）
        for (BOMItem afterItem : afterList) {
            BOMItem beforeItem = beforeItemMap.get(afterItem.id);
            System.out.println("产生BOM"+afterItem.toString());

            if (beforeItem == null) {
                // 新增项
                afterItem.option = "A";
                // 如果新增项有替代料，设置替代料为A
                setSubstituteOption(afterItem.substitutePart, "A");
                resultList.add(afterItem);
            } else {
                // 找到匹配项，对比字段
                if (isItemChanged(beforeItem, afterItem)) {
                    // 修改项
                    afterItem.option = "M";
                    resultList.add(afterItem);
                } else {
                    // 未改变项
                    afterItem.option = ""; // 或者设置为null
                    resultList.add(afterItem);
                }
                // 从beforeMap中移除已处理的项
                beforeItemMap.remove(afterItem.id);
            }
        }

        // 步骤3: 处理剩余项（删除项）
        for (BOMItem deletedItem : beforeItemMap.values()) {
            deletedItem.option = "D";
            deletedItem.setGroup("");
            deletedItem.setPriority("");
            deletedItem.setStrategy("");
            deletedItem.setUsageProb("");
            resultList.add(deletedItem);
        }

        // 按照ID排序
        Collections.sort(resultList, BOM_ITEM_COMPARATOR);



        Map<WTPart, List<BOMItem>> resultMap = new HashMap<>();
        resultMap.put(afterPart, resultList);
        return resultMap;
    }

    /**
     * 比较两个BOMItem的字段是否发生变化
     */
    private static boolean isItemChanged(BOMItem before, BOMItem after) {
        // 比较所有需要对比的字段
        if (!Objects.equals(before.quantity, after.quantity)) return true;
        if (!Objects.equals(before.lossRate, after.lossRate)) return true;
        if (!Objects.equals(before.ebort, after.ebort)) return true;
//        if (!Objects.equals(before.group, after.group)) return true;
//        if (!Objects.equals(before.priority, after.priority)) return true;
//        if (!Objects.equals(before.strategy, after.strategy)) return true;
//        if (!Objects.equals(before.usageProb, after.usageProb)) return true;
//        if (!Objects.equals(before.upmng, after.upmng)) return true;
//        if (!Objects.equals(before.unit, after.unit)) return true;

        // 还可以添加其他需要对比的字段

        // 检查替代料是否有变化（增删）
        return hasSubstituteChanged(before.substitutePart, after.substitutePart);
    }

    /**
     * 检查替代料是否有变化（增删）
     */
    private static boolean hasSubstituteChanged(List<BOMItem> beforeSubstitutes,
                                                List<BOMItem> afterSubstitutes) {
        // 两个都为空，没有变化
        if (beforeSubstitutes == null && afterSubstitutes == null) return false;

        // 一个为空一个不为空，有变化
        if (beforeSubstitutes == null && afterSubstitutes != null) return true;
        if (afterSubstitutes == null && beforeSubstitutes != null) return true;

        // 两个都不为空，继续检查数量变化和ID变化
        if (beforeSubstitutes.size() != afterSubstitutes.size()) return true;

        // 检查是否有ID不同的项
        Set<String> beforeIds = new HashSet<>();
        for (BOMItem sub : beforeSubstitutes) {
            if (sub.id != null) {
                beforeIds.add(sub.id);
            } else {
                beforeIds.add(sub.partNumber + sub.lineNumber + sub.getEbort());
            }
        }

        Set<String> afterIds = new HashSet<>();
        for (BOMItem sub : afterSubstitutes) {
            if (sub.id != null) {
                afterIds.add(sub.id);
            } else {
                afterIds.add(sub.partNumber + sub.lineNumber + sub.getEbort());
            }
        }

        return !beforeIds.equals(afterIds);
    }

    /**
     * 如果你的ID需要动态生成，可以使用这个方法
     */
    private String generateItemId(BOMItem item) {
        if (item.uptxt == null || item.uptxt.trim().isEmpty()) {
            return item.partNumber + item.lineNumber;
        } else {
            return item.partNumber + item.lineNumber + item.uptxt;
        }
    }

    /**
     * 如果ID不是预先生成的，可以使用这个方法先为所有项设置ID
     */
    public void generateIdsForItems(List<BOMItem> items) {
        for (BOMItem item : items) {
            item.id = generateItemId(item);
        }
    }

    /**
     * 设置替代料的option
     */
    private static void setSubstituteOption(List<BOMItem> substitutes, String option) {
        if (substitutes == null) return;
        for (BOMItem sub : substitutes) {
            sub.option = option;
        }
    }
}
