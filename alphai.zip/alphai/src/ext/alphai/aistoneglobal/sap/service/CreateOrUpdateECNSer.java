package ext.alphai.aistoneglobal.sap.service;

import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import ext.alphai.aistoneglobal.sap.utils.IBAUtil;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import org.apache.commons.lang3.StringUtils;
import wt.change2.WTChangeOrder2;
import wt.part.WTPart;
import wt.util.WTException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CreateOrUpdateECNSer {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    static SimpleDateFormat windchillDF = new SimpleDateFormat("yyyy/MM/dd");


    public static Map<String, String> RFCCreateOrUpdateECN(List<WTPart> wtParts, WTChangeOrder2 ecn, String factoryView) throws WTException, ParseException {
        Map<String, String> map = new HashMap<String, String>();
        //获取第一个部件的ECN
//        WTChangeOrder2 ecn = (WTChangeOrder2) WorkflowUtil.getBOMLatestECN(wtParts.get(0));

        Map<String, String> queryECN = RFCQueryECN(ecn);
        if ("S".equals(queryECN.get(Constant.E_TYPE))) {

            map.put(Constant.E_TYPE, "E");
            map.put(Constant.E_MESSAGE, "ECN在sap已存在，请重新创建！");
        }else{
            map = RFCCreateECN(wtParts ,ecn,factoryView);
        }
        return map;
    }


    public static Map<String, String> RFCCreateECN(List<WTPart> wtParts, WTChangeOrder2 ecn, String factoryView) throws WTException, ParseException {
        Map<String, String> map = new HashMap<String, String>();
        //获取第一个部件的ECN
        if (ecn == null) {
            System.out.println("ecn is null");
            return map;
        }
        String ecnNumber = ecn.getNumber();
        String ecnName = ecn.getName();
        IBAUtil ibaUtil = new IBAUtil(ecn);
//        String effectiveDate = ibaUtil.getIBAValue("AI_Effective_Date");
        String ecnCreatorFullName = ecn.getCreatorFullName();
        String plainText = ecn.getLongDescription() == null ? "" : ecn.getLongDescription().getPlainText();

        // 获取RFC 对象
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_CREATE_ECN);
        JCoTable T_ECN = function.getTableParameterList().getTable(Constant.T_ECN);
        for (WTPart wtPart : wtParts) {

            String partNumber = wtPart.getNumber();

            T_ECN.appendRow();
            T_ECN.setValue(Constant.AENNR, ecnNumber);                                //必填
            T_ECN.setValue(Constant.AETXT, ecnName);                                    //必填
//            T_ECN.setValue(Constant.DATUV, sdf.format(windchillDF.parse(effectiveDate)));                                    //必填
            String formatted = sdf.format(new Date());
            T_ECN.setValue(Constant.DATUV, formatted);                                    //必填
            T_ECN.setValue(Constant.AEGRU, plainText);                                            //选填
            T_ECN.setValue(Constant.WERKS, factoryView);                                        //必填
            T_ECN.setValue(Constant.MATNR, partNumber);                             //必填
            T_ECN.setValue(Constant.OITXT, ecnCreatorFullName);


            System.out.println("\n===== 第 " + T_ECN.getNumRows() + " 行数据 =====");
            for (int i = 0; i < T_ECN.getMetaData().getFieldCount(); i++) {
                String fieldName = T_ECN.getMetaData().getName(i);
                Object value = T_ECN.getValue(fieldName);
                System.out.println(String.format("%-20s: %s", fieldName, value));
            }

        }

        // 执行RFC
        return executeRFC(function, ecn);
    }


    public static Map<String, String> RFCUpdateECNToSAP(WTChangeOrder2 ecn) throws WTException {
        Map<String, String> map = new HashMap<String, String>();
        //获取第一个部件的ECN
        if (ecn == null) {
            System.out.println("ecn is null");
            return map;
        }
        String ecnNumber = ecn.getNumber();
        String ecnName = ecn.getName();
        IBAUtil ibaUtil = new IBAUtil(ecn);
        String effectiveDate = ibaUtil.getIBAValue("AI_Effective_Date");
        String plainText = ecn.getLongDescription().getPlainText() == null ? "" : ecn.getLongDescription().getPlainText();

        // 获取RFC 对象
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_CHANGE_ECNHEADER);
        JCoTable T_CTO = function.getTableParameterList().getTable(Constant.T_ECN);
        String state = ecn.getLifeCycleState().getDisplay();


        T_CTO.setValue(Constant.CHANGE_NO, ecnNumber);                                //必填
        T_CTO.setValue(Constant.STATUS, state);                                    //必填
//        T_CTO.setValue(Constant.VALID_FROM, sdf.format(windchillDF.parse(effectiveDate)));                                    //必填
        T_CTO.setValue(Constant.VALID_FROM, sdf.format(new Date()));                                    //必填
        T_CTO.setValue(Constant.DESCRIPT, ecnName);                                            //选填
        T_CTO.setValue(Constant.REASON_CHG, plainText);                                        //必填
        T_CTO.setValue(Constant.DELETION_MARK, "");                             //必填


        // 执行RFC
        return executeRFC(function, ecn);
    }


    public static Map<String, String> RFCQueryECN(WTChangeOrder2 ecn) throws WTException {

        Map<String, String> map = new HashMap<String, String>();
        if (ecn == null) {
            return map;
        }
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_GET_ECNHEADER);
        JCoParameterList importParam = function.getImportParameterList();
        String ecnNumber = ecn.getNumber();
        importParam.setValue(Constant.I_CHANGE_NO, ecnNumber);
        // 执行RFC
        RfcManager.execute(function);

        // 获取RFC返回的字段值
        JCoParameterList exportParam = function.getExportParameterList();
        String exParamA = exportParam.getString(Constant.E_TYPE);
        String exParamB = exportParam.getString(Constant.E_MESSAGE);
        System.out.println("查询ECN返回Type "+ exParamA);
        System.out.println("查询ECN返回Message "+ exParamB);
        map.put(Constant.E_TYPE, exParamA);
        map.put(Constant.E_MESSAGE, exParamB);
        return map;
    }


    public static Map<String, String> executeRFC(JCoFunction function, WTChangeOrder2 ecn) throws WTException {
        Map<String, String> map = new HashMap<String, String>();
        //获取第一个部件的ECN
        RfcManager.execute(function);

        JCoParameterList exportParam = function.getExportParameterList();

        String exParamA = exportParam.getString(Constant.E_TYPE);
        String exParamB = exportParam.getString(Constant.E_MESSAGE);
        JCoTable exportTable = function.getTableParameterList().getTable(Constant.T_RETURN);

        String type = exportTable.getString("TYPE");
        String message = exportTable.getString("MESSAGE");

        System.out.println("当前查询的ECN是：" + ecn.getNumber());
        System.out.println("当前查询的ECN的exParamA：" + exParamA);
        System.out.println("当前查询的ECN的exParamB：" + exParamB);
        System.out.println("当前查询的ECN的type：" + type);
        System.out.println("当前查询的ECN的message：" + message);
//        System.out.println("创建部件返回TABLE:"+exportTable);
        if (StringUtils.isBlank(exParamA)) {
            map.put(Constant.E_TYPE, type);  // A为空，用Type
        } else {
            map.put(Constant.E_TYPE, exParamA);  // A不为空，用exParamA
        }

        if (StringUtils.isBlank(exParamB)) {
            map.put(Constant.E_MESSAGE, message);  // B为空，用Message
        } else {
            map.put(Constant.E_MESSAGE, exParamB);  // B不为空，用exParamB
        }

        return map;
    }

}
