package ext.alphai.aistoneglobal.sap.service;

import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import ext.alphai.aistoneglobal.sap.Constant;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 根据部件编号调用RFC接口查询部件编号是否在SAP存在
 */
public class QueryPFCPartNumber {
    /**
     * 根据部件集合查询
     * @param partsNumber
     * @return
     */
    public static Map<String, Boolean> RFCQueryParts(List<String> partsNumber){
        Map<String, Boolean> map = new HashMap<>();
        for (String partNumber : partsNumber) {
            Boolean selectSAPPartResult = selectSAPPart(partNumber);
            map.put(partNumber, selectSAPPartResult);
        }
        return map;
    }

    /**
     * 根据编号查询SAP
     * @param partNumber
     * @return
     */
    public static Boolean selectSAPPart(String partNumber){
        Boolean result = false;
        // 获取RFC 对象
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_QUERY_MATERIAL);
        // 设置import 参数
        // IMPORT PARAM
        JCoParameterList importParam = function.getImportParameterList();
        //1. 如果只填开始日期,则查询当天的物料
        //2. 如果只填结束日期,则查询结束日期之前的所有物料
        //3. 如果开始日期和结束日期都不填,则查询所有物料
        importParam.setValue(Constant.I_WERKS, "6020");            // 工厂 默认6020 ,必填
        importParam.setValue(Constant.I_ERSDA_FROM, "");   // 开始日期,可选
        importParam.setValue(Constant.I_ERSDA_TO, "");             // 结束日期,可选
        // IMPORT STRUCT 参数
        // IMPORT TABLE
        JCoTable T_MARA = function.getTableParameterList().getTable(Constant.T_MARA); //必填,table的形式进行分类
        T_MARA.appendRow();
        T_MARA.setValue(Constant.MATNR, partNumber);
        // 执行RFC
        RfcManager.execute(function);
        // 获取RFC返回的字段值
        JCoParameterList exportParam = function.getExportParameterList();
        String exParamA = exportParam.getString(Constant.E_TYPE);
        String exParamB = exportParam.getString(Constant.E_MESSAGE);
        JCoTable exportTable = function.getTableParameterList().getTable(Constant.T_MARA);
        if(Constant.S.equalsIgnoreCase(exParamA)){
            result = true;
        } else if (Constant.E.equalsIgnoreCase(exParamA)) {
            result = false;
        }
        return result;
    }
}
