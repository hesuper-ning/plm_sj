package ext.alphai.aistoneglobal.sap.service;

import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import ext.alphai.aistoneglobal.sap.utils.CommonUtil;
import ext.alphai.aistoneglobal.sap.utils.IBAUtil;
import ext.alphai.aistoneglobal.sap.utils.PersistenceUtil;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.HashMap;
import java.util.Map;
/**
 * 调用RFC接口 在SAP更新部件
 */
public class UpdateRFCMaterialPart {

    /**
     * 更新部件
     * @param part
     * @return
     */
    public static Map<String, String> RFCCreatePart(WTPart part) throws WTException {
        IBAUtil iba = new IBAUtil(part);
        String subTypeInternal = PersistenceUtil.getSubTypeInternal(part);
        Map<String, String> map = new HashMap<String, String>();
        JCoFunction function = RfcManager.getFunction(Constant.ZRFC_UPDATE_MATERIAL);
        JCoTable T_MARA = function.getTableParameterList().getTable(Constant.T_MARA);
        T_MARA.appendRow();

        T_MARA.setValue(Constant.MATNR, part.getNumber()); //编号
        T_MARA.setValue(Constant.MAKTX, part.getName()); //名称

        String MATKL = CreateOrUpdateMaterialSer.getMaterialGroup(part, iba, subTypeInternal);
        // 产品组
        T_MARA.setValue(Constant.MATKL, MATKL); // 变量EE,MM,KP & 机种 ,必填
        // 单位
        T_MARA.setValue(Constant.MEINS, CommonUtil.convertUnit( part.getDefaultUnit().getValue().toUpperCase()));
        // 执行RFC
        RfcManager.execute(function);
        // 获取RFC返回的字段值
        JCoParameterList exportParam = function.getExportParameterList();
        String exParamA = exportParam.getString(Constant.E_TYPE);
        String exParamB = exportParam.getString(Constant.E_MESSAGE);
        JCoTable exportTable = function.getTableParameterList().getTable(Constant.T_MARA);
        System.out.println("更新部件返回TABLE:"+exportTable);
        map.put(Constant.E_TYPE, exParamA);
        map.put(Constant.E_MESSAGE, exParamB);
        return map;
    }
}
