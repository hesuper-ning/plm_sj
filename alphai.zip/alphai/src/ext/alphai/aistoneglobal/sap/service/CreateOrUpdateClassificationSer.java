package ext.alphai.aistoneglobal.sap.service;

import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * RFC创建和修改分类方法
 */
public class CreateOrUpdateClassificationSer {

    private static final Logger logger = LogManager.getLogger(CreateOrUpdateClassificationSer.class);

    private static void printInputTableToLog(JCoTable table) {
        System.out.println("承认书输入标"+table);
        if (table == null) {
            System.out.println("输入表为空");
            return;
        }

        int rowCount = table.getNumRows();
        System.out.println("输入表 T_CLASSIFICATION 总行数: " + rowCount);

        if (rowCount == 0) {
            System.out.println("输入表无数据");
            return;
        }

        // 详细输出输入表内容
        System.out.println("\n========== 输入表数据详情 ==========");

        table.firstRow();
        int rowNum = 0;

        do {
            rowNum++;
            System.out.println("--- 第 " + rowNum + " 行 ---");
            System.out.println("  物料(MATNR): " + getStringValue(table, Constant.MATNR));
            System.out.println("  申请人(REQUESTOR): " + getStringValue(table, Constant.REQUESTOR));
            System.out.println("  EE值1(EE_VALUE1): " + getStringValue(table, Constant.EE_VALUE1));
            System.out.println("  EE值2(EE_VALUE2): " + getStringValue(table, Constant.EE_VALUE2));
            System.out.println("  GPM状态(GPM_STATUS): " + getStringValue(table, Constant.GPM_STATUS));
            System.out.println("  项目状态(PROJECT_STATUS): " + getStringValue(table, Constant.PROJECT_STATUS));
            System.out.println("  产品状态(PRODUCT_STATUS): " + getStringValue(table, Constant.PRODUCT_STATUS));
            System.out.println("  类型(TYPE): " + getStringValue(table, Constant.TYPE));
            System.out.println("  消息(MESSAGE): " + getStringValue(table, Constant.MESSAGE));

            // 添加空行便于阅读
            System.out.println("\n");
        } while (table.nextRow());

        System.out.println("总计行数: " + rowNum + " 行");
        System.out.println("====================================\n");
    }

    // 辅助方法：安全获取字符串值
    private static String getStringValue(JCoTable table, String fieldName) {
        try {
            String value = table.getString(fieldName);
            return value != null ? value : "";
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * 统一的分类更新方法
     * @param parts 部件列表
     * @param flag 操作标志
     * @param classificationType 分类类型：ZNPI_STATUS 或 Z_APPROVE_STATUS
     * @param sign 签名/状态（仅用于Z_APPROVE_STATUS类型）
     * @param projectStatus 项目状态（仅用于ZNPI_STATUS类型）
     * @return 操作结果
     */
    private static Map<String, String> UpdateClassification(List<WTPart> parts, String flag, String classificationType,
                                                            String sign, String projectStatus) {
        Map<String, String> resultMap = new HashMap<>();

        try {
            // 查询选项是否于SAP中已经存在
            JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_CLASSIFICATION);
            if (function == null) {
                resultMap.put("globalType", "E");
                resultMap.put("globalMessage", "获取RFC函数失败");
                return resultMap;
            }

            // 设置import 参数
            JCoParameterList importParam = function.getImportParameterList();
            importParam.setValue(Constant.I_FLAG, flag);
            importParam.setValue(Constant.I_TYPE, "001");
            importParam.setValue(Constant.I_CLASSFICATION, classificationType);

            // 设置查询条件表 T_MARA
            JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_CLASSIFICATION);

            for (WTPart part : parts) {
                String partNumber = part.getNumber();
                inputTable.appendRow();
                inputTable.setValue(Constant.MATNR, partNumber);
                inputTable.setValue(Constant.REQUESTOR, "");
                inputTable.setValue(Constant.EE_VALUE1, "");
                inputTable.setValue(Constant.EE_VALUE2, "");
                inputTable.setValue(Constant.GPM_STATUS, sign != null ? sign : "");
                inputTable.setValue(Constant.PROJECT_STATUS, projectStatus != null ? projectStatus : "");
                inputTable.setValue(Constant.PRODUCT_STATUS, "");
                inputTable.setValue(Constant.TYPE, "");
                inputTable.setValue(Constant.MESSAGE, "");
            }

            // 打印输入表到日志
            printInputTableToLog(inputTable);

            // 执行RFC
            RfcManager.execute(function);

            // 获取全局返回参数
            JCoParameterList exportParam = function.getExportParameterList();
            String globalType = exportParam.getString(Constant.E_TYPE);
            String globalMessage = exportParam.getString(Constant.E_MESSAGE);

            resultMap.put("globalType", globalType);
            resultMap.put("globalMessage", globalMessage);

        } catch (Exception e) {
            resultMap.put("globalType", "E");
            resultMap.put("globalMessage", "执行异常: " + e.getMessage());
        }

        return resultMap;
    }

    /**
     * 成品料号状态更新
     * @param parts 部件列表
     * @param flag 操作标志
     * @return 操作结果
     */
    public static Map<String, String> updateNPIClassification(List<WTPart> parts, String flag) {
        return UpdateClassification(parts, flag, Constant.ZNPI_STATUS, "", "NPI");
    }

    /**
     * PLM承认流程  ---  产生对象是文档，然后在文档说明部件找部件，
     * @param parts 部件列表
     * @param flag 操作标志
     * @param sign 签名状态
     * @return 操作结果
     */
    public static Map<String, String> updateApproveClassification(List<WTPart> parts, String flag, String sign) {
        return UpdateClassification(parts, flag, Constant.Z_APPROVE_STATUS, sign, "");
    }



//    public static List<WTPart>  getWTPartListByDocumentId(List<WTDocument> documents) {
//        List<WTPart> parts = new ArrayList<>();
//        for (WTDocument document : documents) {
//            List<WTPart> partByDescribesDoc = getPartByDescribesDoc(document);
//            parts.addAll(partByDescribesDoc);
//        }
//        return parts;
//    }


}