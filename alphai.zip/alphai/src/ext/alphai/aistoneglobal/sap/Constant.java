package ext.alphai.aistoneglobal.sap;

/**
 * 智通SAP 集成常量
 */
public class Constant {

    //IBA

    public static String AI_Placement_Side="AI_Placement_Side";
    public static String AI_Priority="AI_Priority";
    public static String AI_LineNumber="AI_LineNumber";
    public static String AI_LossRate="AI_LossRate";

    // RFC 查询接口标识符
    public static String ZRFC_QUERY_MATERIAL="ZRFC_QUERY_MATERIAL";
    // 创建部件RFC 接口参数
    public static String ZRFC_CREATE_MATERIAL="ZRFC_CREATE_MATERIAL";
    // 更新部件RFC 接口参数
    public static String ZRFC_UPDATE_MATERIAL="ZRFC_UPDATE_MATERIAL";

    // 分类  选项集接口
    public static String ZRFC_MAINTAIN_CLASS="ZRFC_MAINTAIN_CLASS";
    // 特性  选项接口
    public static String ZRFC_MAINTAIN_CHARACT="ZRFC_MAINTAIN_CHARACT";
    // BOM相关接口
    public static String ZRFC_MAINTAIN_BOM="ZRFC_MAINTAIN_BOM";
    //分类视图
    public static String ZRFC_MAINTAIN_CLASSIFICATION="ZRFC_MAINTAIN_CLASSIFICATION";


    public static String S="S";
    public static String E="E";

    public static String I_WERKS="I_WERKS";
    public static String I_ERSDA_FROM="I_ERSDA_FROM";
    public static String I_ERSDA_TO="I_ERSDA_TO";

    public static String T_MARA="T_MARA";
    public static String MATNR="MATNR";
    public static String E_TYPE="E_TYPE";
    public static String E_MESSAGE="E_MESSAGE";

    public static String I_MBRSH="I_MBRSH";
    public static String I_MATKL="I_MATKL";
    public static String I_MTART="I_MTART";
    public static String WERKS="WERKS";
    public static String MAKTX="MAKTX";
    public static String MEINS="MEINS";
    public static String ZVALUED="ZVALUED";
    public static String REQUESTOR="REQUESTOR";

    public static String MATKL="MATKL";

    public static String TYPE="TYPE";

    public static String MESSAGE="MESSAGE";


    public static String I_FLAG="I_FLAG";
    public static String T_CLASS="T_CLASS";
    public static String CLASSTYPE="CLASSTYPE";
    public static String CLASSNUM="CLASSNUM";
    public static String ATNAM="ATNAM";
    public static String DATUV="DATUV";
    public static String ATBEZ="ATBEZ";
    public static String ATUDF="ATUDF";
    public static String ANZST="ANZST";
    public static String ATWRT="ATWRT";
    public static String ATWTB="ATWTB";
    public static String NAME_CHAR="NAME_CHAR";

    public static String T_CHARACT="T_CHARACT";

    public static String T_BOM="T_BOM";
    //分类
    public static String T_CLASSIFICATION="T_CLASSIFICATION";


    public static String STLAN="STLAN";
    public static String STLAL="STLAL";
    public static String STATUS="STATUS";
    public static String BASE_QUAN="BASE_QUAN";
    public static String ITEM_NO="ITEM_NO";
    public static String ITEM_CATEG="ITEM_CATEG";

    public static String COMPONENT="COMPONENT";
    public static String COMP_QTY="COMP_QTY";


    public static String COMP_UNIT="COMP_UNIT";
    public static String COMP_SCRAP="COMP_SCRAP";
    public static String AI_GROUP="AI_GROUP";
    public static String AI_PRIO="AI_PRIO";
    public static String AI_STRATEG="AI_STRATEG";
    public static String USAGE_PROB="USAGE_PROB";
    public static String EBORT="EBORT";
    public static String UPMNG="UPMNG";
    public static String UPTXT="UPTXT";
    public static String SCODE="SCODE";
    public static String FLDELETE="FLDELETE";




    //创建ECN 接口参数
    public static String ZRFC_CREATE_ECN="ZRFC_CREATE_ECN";
    //查询ECN
    public static String ZRFC_GET_ECNHEADER="ZRFC_GET_ECNHEADER";
    //修改
    public static String ZRFC_CHANGE_ECNHEADER="ZRFC_CHANGE_ECNHEADER";
    //ECN Table
    public static String T_ECN="T_ECN";
    //ecn参数
    public static String AENNR="AENNR";
    public static String AEGRU="AEGRU";
    public static String AETXT="AETXT";
    public static String OITXT="OITXT";
    public static String T_RETURN="T_RETURN";

    //ENC编号
    public static String I_CHANGE_NO="I_CHANGE_NO";
    public static String CHANGE_NO="CHANGE_NO";
    public static String VALID_FROM="VALID_FROM";
    public static String DESCRIPT="DESCRIPT";
    public static String REASON_CHG="REASON_CHG";
    public static String DELETION_MARK="DELETION_MARK";

    //成品料号状态更新
    public static String ZNPI_STATUS="ZNPI_STATUS";
    //PLM承认流程
    public static String Z_APPROVE_STATUS="Z_APPROVE_STATUS";

    public static String I_TYPE="I_TYPE";
    public static String I_CLASSFICATION="I_CLASSFICATION";
    public static String EE_VALUE1="EE_VALUE1";
    public static String EE_VALUE2="EE_VALUE2";
    public static String GPM_STATUS="GPM_STATUS";
    public static String PROJECT_STATUS="PROJECT_STATUS";
    public static String PRODUCT_STATUS="PRODUCT_STATUS";


    public static String LINE_NUMBER_ERR_MSG="BOM存在空行号,请检查！";
    public static String WORKFLOW="WORKFLOW";
    public static String PROCESS="PROCESS";

    //



}

