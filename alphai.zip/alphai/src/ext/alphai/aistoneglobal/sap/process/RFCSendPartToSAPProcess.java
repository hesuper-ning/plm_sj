package ext.alphai.aistoneglobal.sap.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateMaterialSer;
import ext.alphai.aistoneglobal.sap.service.CreateRFCMaterialPart;
import ext.alphai.aistoneglobal.sap.service.QueryPFCPartNumber;
import ext.alphai.aistoneglobal.sap.service.UpdateRFCMaterialPart;
import org.apache.commons.lang3.StringUtils;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class RFCSendPartToSAPProcess extends DefaultObjectFormProcessor {
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;

        try {
            // 支持批量处理
            List<WTPart> partsToProcess = new ArrayList<>();

            // 获取主要部件
            NmOid primaryOid = nmCommandBean.getPrimaryOid();
            Object content = primaryOid.getRef();
            if (content instanceof WTPart) {
                partsToProcess.add((WTPart) content);
            }



            if (!partsToProcess.isEmpty()) {
                // 批量创建或更新部件
                List<Map<String, String>> results = CreateOrUpdateMaterialSer.RFCCreateOrUpdatePartsBatch(partsToProcess);

                // 处理返回结果
                boolean allSuccess = true;
                boolean hasFailure = false;
                List<String> successMessages = new ArrayList<>();
                List<String> failureMessages = new ArrayList<>();

                for (Map<String, String> result : results) {
                    String materialNumber = result.get("MATNR");
                    String messageType = result.get("TYPE");
                    String messageText = result.get("MESSAGE");
                    if (StringUtils.isBlank(messageText)){
                        messageText = result.get("GLOBAL_MESSAGE");
                    }
                    String operation = result.get("OPERATION");

                    String message = "物料 " + materialNumber + " " +
                            ("CREATE".equals(operation) ? "创建" : "更新") + " " +
                            ("S".equalsIgnoreCase(messageType) ? "成功" : "失败") + ": " + messageText;

                    if ("S".equalsIgnoreCase(messageType)) {
                        successMessages.add(message);
                    } else {
                        failureMessages.add(message);
                        allSuccess = false;
                        hasFailure = true;
                    }
                }

                // 设置返回结果
                formResult = new FormResult(FormProcessingStatus.SUCCESS);

                if (allSuccess) {
                    // 全部成功
                    for (String msg : successMessages) {
                        formResult.addFeedbackMessage(new FeedbackMessage(
                                FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null, new String[]{msg}));
                    }
                } else if (hasFailure) {
                    // 有失败情况
                    formResult = new FormResult(FormProcessingStatus.FAILURE);
                    for (String msg : failureMessages) {
                        formResult.addFeedbackMessage(new FeedbackMessage(
                                FeedbackType.FAILURE, SessionHelper.getLocale(), null, null, new String[]{msg}));
                    }
                    // 同时显示成功的信息
                    for (String msg : successMessages) {
                        formResult.addFeedbackMessage(new FeedbackMessage(
                                FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null, new String[]{msg}));
                    }
                }
            }

        } catch (Exception e) {
//            formResult = new FormResult(FormProcessingStatus.FAILURE);
//            formResult.addFeedbackMessage(new FeedbackMessage(
//                    FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
//                    new String[]{"处理失败: " + e.getMessage()}));
            e.printStackTrace();
            throw new WTException(e.getMessage());
        }

        return formResult;
    }


// 废弃 单个查询单个创建 单个修改
//    @Override
//    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
//        FormResult formResult = null;
//        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
//        Object content = primaryOid2.getRef();
//        if(content instanceof WTPart){
//            WTPart part = (WTPart) content;
//            Boolean selectSAPPart = QueryPFCPartNumber.selectSAPPart(part.getNumber());
//            Map<String, String> stringStringMap = null;
//            if(selectSAPPart){
//                // 修改部件
//                stringStringMap = UpdateRFCMaterialPart.RFCCreatePart(part);
//            }else {
//                // 创建部件
//                stringStringMap = CreateRFCMaterialPart.RFCCreatePart(part);
//            }
//
//            String code = stringStringMap.get(Constant.E_TYPE);
//            String msg = stringStringMap.get(Constant.E_MESSAGE);
//            if(Constant.S.equalsIgnoreCase(code)){
//                // 成功
//                formResult = new FormResult(FormProcessingStatus.SUCCESS);
//                formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null,null, new String[]{msg}));
//            } else if (Constant.E.equalsIgnoreCase(code)) {
//                // 失败
//                formResult = new FormResult(FormProcessingStatus.FAILURE);
//                formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null,null, new String[]{msg}));
//            }
//        }
//        return formResult;
//    }
}
