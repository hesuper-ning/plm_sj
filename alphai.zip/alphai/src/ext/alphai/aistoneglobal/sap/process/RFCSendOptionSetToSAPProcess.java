package ext.alphai.aistoneglobal.sap.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.option.model.OptionSet;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateOptionSetSer;
import ext.alphai.aistoneglobal.sap.vo.OptionSetStructureVo;
import ext.alphai.aistoneglobal.sap.vo.OptionStructureVo;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;

public class RFCSendOptionSetToSAPProcess extends DefaultObjectFormProcessor {

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = null;

        try {
            String optionSetName = "";
            // 支持批量处理
            List<OptionSet> optionSetsToProcess = new ArrayList<>();

            // 获取主要部件
            NmOid primaryOid = nmCommandBean.getPrimaryOid();
            Object content = primaryOid.getRef();
            if (content instanceof OptionSet) {
                OptionSet optionSet = (OptionSet) content;
                optionSetName =  optionSet.getName();
                optionSetsToProcess.add(optionSet);
            }

            List<OptionSetStructureVo> optionSetStructureVos = CreateOrUpdateOptionSetSer.sendOptionSetsToSAP(optionSetsToProcess);
            for (OptionSetStructureVo optionSetStructureVo : optionSetStructureVos) {
                String optionSetNameVo = optionSetStructureVo.getOptionSet().getName();
                if(optionSetNameVo.equals(optionSetName)){
                    String optionSetType = optionSetStructureVo.getType();
                    if(Constant.S.equals(optionSetType)){
                        // 选项集发送成功
                        List<OptionStructureVo> structureVos = optionSetStructureVo.getStructureVos();
                        // 选项是否全发送成功
                        boolean isAllOK = true;
                        for (OptionStructureVo structureVo : structureVos) {
                            String optionType = structureVo.getType();
                            if (Constant.E.equals(optionType)){
                                // 有一个失败代表结构发送失败不完整
                                isAllOK = false;
                                break;
                            }
                        }
                        if(isAllOK){
                            // 全部发送成功
                            formResult = new FormResult(FormProcessingStatus.SUCCESS);
                            formResult.addFeedbackMessage(new FeedbackMessage(
                                    FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null,
                                    new String[]{"选项集:"+optionSetName+"发送成功"}));
                        }else {
                            // 有一条失败 整体看作一个事务 全部失败
                            // 直接失败
                            formResult = new FormResult(FormProcessingStatus.FAILURE);
                            formResult.addFeedbackMessage(new FeedbackMessage(
                                    FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
                                    new String[]{"选项集:"+optionSetName+"发送失败"}));
                        }


                    } else if (Constant.E.equals(optionSetType)) {
                        // 直接失败
                        formResult = new FormResult(FormProcessingStatus.FAILURE);
                        formResult.addFeedbackMessage(new FeedbackMessage(
                                FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
                                new String[]{"选项集:"+optionSetName+"发送失败"}));
                    }
                }
            }


        } catch (Exception e) {
//            formResult = new FormResult(FormProcessingStatus.FAILURE);
//            formResult.addFeedbackMessage(new FeedbackMessage(
//                    FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
//                    new String[]{"选项集发送失败: " + e.getMessage()}));
            throw new WTException(e);
        }

        return formResult;
    }

}
