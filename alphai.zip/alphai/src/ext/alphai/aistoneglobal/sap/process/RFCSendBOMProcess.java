package ext.alphai.aistoneglobal.sap.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateBOMSer;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateMaterialSer;
import ext.alphai.aistoneglobal.sap.utils.PartUtil;
import ext.alphai.aistoneglobal.sap.vo.BOMSendResult;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 点击发送BOM按键处理
 */
public class RFCSendBOMProcess extends DefaultObjectFormProcessor {

//    @Override
//    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
//        FormResult formResult = null;
//        try {
//            // 支持批量处理
//            List<WTPart> partsToProcess = new ArrayList<>();
//            // 获取主要部件
//            NmOid primaryOid = nmCommandBean.getPrimaryOid();
//            Object content = primaryOid.getRef();
//            WTPart part = null;
//            if (content instanceof WTPart) {
//                part = (WTPart) content;
//                partsToProcess.add(part);
//            }
//            // 获取所选的目标工厂
//            String factoryView = nmCommandBean.getTextParameter("factoryView");
//            // 先发送所有会用到的WTPart到SAP
//            List<WTPart> allBomByPart = PartUtil.getAllBomByPart(part);
//            CreateOrUpdateMaterialSer.RFCCreateOrUpdatePartsBatch(allBomByPart);
//
//            // 再发送BOM
//            Map<WTPart, Map<WTPart, Boolean>> wtPartMapMap = CreateOrUpdateBOMSer.sendOptionSetsToSAP(partsToProcess, factoryView);
//            Map<WTPart, Boolean> wtPartBooleanMap = wtPartMapMap.get(part);
//
//            // 收集发送失败的子项
//            List<String> failedPartNumbers = new ArrayList<>();
//            boolean isAllOK = true;
//
//            for (Map.Entry<WTPart, Boolean> wtPartBooleanEntry : wtPartBooleanMap.entrySet()) {
//                WTPart key = wtPartBooleanEntry.getKey();
//                String partNumber = key.getNumber();
//                Boolean value = wtPartBooleanEntry.getValue();
//                if (!value) {
//                    isAllOK = false;
//                    failedPartNumbers.add(partNumber);
//                }
//            }
//
//            if (isAllOK) {
//                // 全部发送成功
//                formResult = new FormResult(FormProcessingStatus.SUCCESS);
//                formResult.addFeedbackMessage(new FeedbackMessage(
//                        FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null,
//                        new String[]{"BOM:" + part.getNumber() + "发送成功"}));
//            } else {
//                // 有一条失败 整体看作一个事务 全部失败
//                // 构建详细的错误信息
//                StringBuilder errorMsg = new StringBuilder();
//                errorMsg.append("BOM:").append(part.getNumber()).append("发送失败");
//
//                if (!failedPartNumbers.isEmpty()) {
//                    errorMsg.append("\n发送失败的下层BOM编号：");
//                    for (int i = 0; i < failedPartNumbers.size(); i++) {
//                        if (i > 0) {
//                            errorMsg.append(", ");
//                        }
//                        errorMsg.append(failedPartNumbers.get(i));
//                    }
//                }
//
//                formResult = new FormResult(FormProcessingStatus.FAILURE);
//                formResult.addFeedbackMessage(new FeedbackMessage(
//                        FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
//                        new String[]{errorMsg.toString()}));
//            }
//
//        } catch (Exception e) {
//            // 按照您提供的模式返回失败信息
//            formResult = new FormResult(FormProcessingStatus.FAILURE);
//            formResult.addFeedbackMessage(new FeedbackMessage(
//                    FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
//                    new String[]{"BOM发送失败:" + e.getMessage()}));
//            e.printStackTrace();
//            throw new WTException(e.getMessage());
//        }
//        return formResult;
//    }

    

@Override
public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
    FormResult formResult = null;
    try {
        // 支持批量处理
        List<WTPart> partsToProcess = new ArrayList<>();
        NmOid primaryOid = nmCommandBean.getPrimaryOid();
        Object content = primaryOid.getRef();
        WTPart part = null;
        if (content instanceof WTPart) {
            part = (WTPart) content;
            partsToProcess.add(part);
        }

        String factoryView = nmCommandBean.getTextParameter("factoryView");

//        // 先发送所有会用到的WTPart到SAP
//        List<WTPart> allBomByPart = getAllBomByPart(part);
//
//        // 发送物料并获取结果
//        List<Map<String, String>> materialResults = CreateOrUpdateMaterialSer.RFCCreateOrUpdatePartsBatch(allBomByPart);
//
//        // 检查物料发送结果，如果有失败直接返回错误信息
//        boolean allMaterialSuccess = true;
//        List<String> materialFailureMessages = new ArrayList<>();
//
//        for (Map<String, String> result : materialResults) {
//            String materialNumber = result.get("MATNR");
//            String messageType = result.get("TYPE");
//            String messageText = result.get("MESSAGE");
//            String operation = result.get("OPERATION");
//
//            if (!"S".equalsIgnoreCase(messageType)) {
//                String message = "物料 " + materialNumber + " " +
//                        ("CREATE".equals(operation) ? "创建" : "更新") + "失败: " + messageText;
//                materialFailureMessages.add(message);
//                allMaterialSuccess = false;
//            }
//        }
//
//        // 如果物料发送有失败，直接返回错误信息，不继续发BOM
//        if (!allMaterialSuccess) {
//            StringBuilder errorMsg = new StringBuilder();
//            errorMsg.append("物料发送失败，BOM发送中止\n");
//
//            // 只添加失败的物料信息
//            for (String msg : materialFailureMessages) {
//                errorMsg.append("- ").append(msg).append("\n");
//            }
//
//            formResult = new FormResult(FormProcessingStatus.FAILURE);
//            formResult.addFeedbackMessage(new FeedbackMessage(
//                    FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
//                    new String[]{errorMsg.toString()}));
//            return formResult; // 直接返回，不执行后续的BOM发送
//        }

        // 只有所有物料都发送成功，才继续发送BOM
        Map<WTPart, Map<WTPart, BOMSendResult>> wtPartMapMap = CreateOrUpdateBOMSer.sendSingleBOMToSAP(partsToProcess, factoryView, Constant.PROCESS);
        Map<WTPart, BOMSendResult> wtPartResultMap = wtPartMapMap.get(part);

        // 收集发送失败的子项和错误信息
        List<String> failedPartNumbers = new ArrayList<>();
        List<String> errorMessages = new ArrayList<>();
        boolean isAllOK = true;

        for (Map.Entry<WTPart, BOMSendResult> entry : wtPartResultMap.entrySet()) {
            WTPart key = entry.getKey();
            BOMSendResult result = entry.getValue();

            if (!result.isSuccess()) {
                isAllOK = false;
                failedPartNumbers.add(key.getNumber());
                if (result.getErrorMessage() != null) {
                    errorMessages.add(key.getNumber() + ": " + result.getErrorMessage());
                }
            }
        }

        if (isAllOK) {
            // 全部发送成功
            formResult = new FormResult(FormProcessingStatus.SUCCESS);
            formResult.addFeedbackMessage(new FeedbackMessage(
                    FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null,
                    new String[]{"BOM发送成功"}));
        } else {
            // 构建详细的错误信息
            StringBuilder errorMsg = new StringBuilder();
            errorMsg.append("BOM发送失败");

            if (!failedPartNumbers.isEmpty()) {
                errorMsg.append("\n发送失败的下层BOM编号：");
                for (int i = 0; i < failedPartNumbers.size(); i++) {
                    if (i > 0) {
                        errorMsg.append(", ");
                    }
                    errorMsg.append(failedPartNumbers.get(i));
                }
            }

            // 添加具体的错误消息
            if (!errorMessages.isEmpty()) {
                errorMsg.append("\n错误详情：");
                for (String msg : errorMessages) {
                    errorMsg.append("\n- ").append(msg);
                }
            }

            formResult = new FormResult(FormProcessingStatus.FAILURE);
            formResult.addFeedbackMessage(new FeedbackMessage(
                    FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
                    new String[]{errorMsg.toString()}));
        }

    } catch (Exception e) {
        e.printStackTrace();
        throw new WTException(e.getMessage());
    }
    return formResult;
}



    /**
     * 递归获取部件的所有子部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getAllBomByPart(WTPart part) {
        List<WTPart> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        WTPart sPart = null;
        QueryResult qr2 = null;
        QueryResult qrSub = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                List<WTPartSubstituteLink> partSubstituteLinks = PartUtil.getWTPartSubstituteLinks(usageLink);
                for (WTPartSubstituteLink partSubstituteLink : partSubstituteLinks) {
                    qrSub = VersionControlHelper.service.allVersionsOf(partSubstituteLink.getSubstitutes());
                    if (qrSub.hasMoreElements()) {
                        WTPart subPart = (WTPart) qrSub.nextElement();
                        // 可能需要指定部件的视图
                        localList.add(subPart);
                    }
                }

                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    // 可能需要指定部件的视图
                    localList.add(sPart);
                    // 递归调用，将结果合并到局部列表
                    localList.addAll(getAllBomByPart(sPart));
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }

}
