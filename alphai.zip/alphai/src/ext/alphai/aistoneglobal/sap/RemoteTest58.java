package ext.alphai.aistoneglobal.sap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import ext.alphai.aistoneglobal.sap.RFC.RfcManager;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateBOMSer;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.occurrence.OccurrenceHelper;
import wt.occurrence.OccurrenceableLink;
import wt.part.*;
import wt.util.WTException;
import wt.util.WTRuntimeException;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.*;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 * ant -f bin/tools.xml class -Dclass.includes=ext/alphai/aistoneglobal/sap/RemoteTest58.java
 * windchill ext.alphai.aistoneglobal.sap.RemoteTest58
 */
//import ext.techsoft.logicdata.datautility.EditSAPMaterialNumberDataUtility
public class RemoteTest58 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;


    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", RemoteTest58.class.getName(), null, new Class[]{}, new Object[]{});
    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }
    static ObjectMapper objectMapper = new ObjectMapper();
    static ReferenceFactory rf = new ReferenceFactory();
    /**
     * 测试导入excel
     * @return
     */
    public static String process() {
        try {
            WTPart bom = (WTPart) rf.getReference("OR:wt.part.WTPart:568704").getObject();
            CreateOrUpdateBOMSer.sendSingleBom(bom, "6020", "2");
//
//            JCoFunction function = RfcManager.getFunction(Constant.ZRFC_MAINTAIN_BOM);
//
//            // 设置import 参数
//            JCoParameterList importParam = function.getImportParameterList();
//            importParam.setValue(Constant.I_FLAG, "3");
//            // 设置查询条件表 T_MARA
//            JCoTable inputTable = function.getTableParameterList().getTable(Constant.T_BOM);
//            inputTable.appendRow();
//            inputTable.setValue(Constant.MATNR, "ASYX6AR558W-004");
//            inputTable.setValue(Constant.WERKS, "6020");
//            inputTable.setValue(Constant.STLAN, "3");
//            inputTable.setValue(Constant.STLAL, "1");
//            // 执行RFC
//            RfcManager.execute(function);
//            // 获取全局返回参数
//            JCoParameterList exportParam = function.getExportParameterList();
//
//            String globalType = exportParam.getString(Constant.E_TYPE);
//            String globalMessage = exportParam.getString(Constant.E_MESSAGE);
//
//            // 获取表返回结果
//            JCoTable returnTable = function.getTableParameterList().getTable(Constant.T_BOM);
//
//            System.out.println("查询BOM返回结果TYPE:"+globalType);
//            System.out.println("查询BOM返回结果MESSAGE:"+globalMessage);
//            System.out.println("查询BOM返回结果TABLE:"+returnTable);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    public static void selectSAPPart(){
        // 获取RFC 对象
        JCoFunction function = RfcManager.getFunction("ZRFC_QUERY_MATERIAL");
        // 设置import 参数
        // IMPORT PARAM
        JCoParameterList importParam = function.getImportParameterList();
        //1. 如果只填开始日期,则查询当天的物料
        //2. 如果只填结束日期,则查询结束日期之前的所有物料
        //3. 如果开始日期和结束日期都不填,则查询所有物料
        importParam.setValue("I_WERKS", "6020");            // 工厂 默认6020 ,必填
        importParam.setValue("I_ERSDA_FROM", "");   // 开始日期,可选
        importParam.setValue("I_ERSDA_TO", "");             // 结束日期,可选

        // IMPORT STRUCT 参数
//        JCoStructure CHANGE_HEADER = function.getImportParameterList().getStructure("CHANGE_HEADER");
//        CHANGE_HEADER.setValue("CHANGE_NO","E2410120006");
//        CHANGE_HEADER.setValue("DESCRIPT","GM5BG5E  业务行销处／海外订单商务部  蔡");
//        CHANGE_HEADER.setValue("VALID_FROM","2024/10/16");
//        CHANGE_HEADER.setValue("VALID_FROM","1231321231");
//        CHANGE_HEADER.setValue("STATUS","01");

        // IMPORT TABLE
        JCoTable T_MARA = function.getTableParameterList().getTable("T_MARA"); //必填,table的形式进行分类
//        T_MARA.appendRow();
//        T_MARA.setValue("MATNR", "CPUR778400-3AS1SOB");
        T_MARA.appendRow();
        T_MARA.setValue("MATNR", "CPUR778400-3AS1SOBa");

        // 执行RFC
        RfcManager.execute(function);

        // 获取RFC返回的字段值
        JCoParameterList exportParam = function.getExportParameterList();
        String exParamA = exportParam.getString("E_TYPE");
        String exParamB = exportParam.getString("E_MESSAGE");
        JCoTable exportTable = function.getTableParameterList().getTable("T_MARA");

        // 遍历RFC返回的表对象
//        JCoTable tb = function.getTableParameterList().getTable("T_MARD");
        System.out.println("---------------------------------------");
        System.out.println(exParamA);
        System.out.println(exParamB);
        System.out.println(exportTable);
    }



}
