package ext.alphai.aistoneglobal.sap.utils;

import wt.change2.*;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.vc.baseline.BaselineHelper;
import wt.vc.baseline.ManagedBaseline;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class WorkflowUtil {


    /**
     * 获取升级请求中被升级的对象
     *
     * @param pn
     * @return ArrayList<WTObject>
     * @throws WTException
     */
    public static List<WTPart> getTargerObjectByPromotionNotices(PromotionNotice pn) throws WTException {
        List<WTPart> list = new ArrayList<>();
        QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
        while (qr.hasMoreElements()) {
            Object o = qr.nextElement();
            if (o instanceof WTPart) {
                list.add((WTPart) o);
            }

        }
        return list;
    }

    /***
     * 获取审阅单下的受影响部件、变更通知/变更任务的产生的对象、基线的部件
     *
     * @param primaryBusinessObject
     * @return
     * @throws WTException
     * @throws ChangeException2
     */
    public static List<WTPart> getTargetParts(WTObject primaryBusinessObject) throws Exception {
        List<WTPart> list = new ArrayList<>();

//        if (primaryBusinessObject instanceof WTChangeReview) {
//            WTChangeReview review = (WTChangeReview) primaryBusinessObject;
//            QueryResult qr = ChangeHelper2.service.getChangeables(review);
//            while (qr.hasMoreElements()) {
//                Object obj = qr.nextElement();
//                if (clazz.isInstance(obj)) {
//                    list.add(clazz.cast(obj));
//                }
//            }
//        } else
        if (primaryBusinessObject instanceof WTChangeOrder2) {
            WTChangeOrder2 eco = (WTChangeOrder2) primaryBusinessObject;
            QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eco);
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTPart) {
                    list.add((WTPart) obj);
                }
            }
        } else if (primaryBusinessObject instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) primaryBusinessObject;
            QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTPart) {
                    list.add((WTPart) obj);
                }
            }
        } else if (primaryBusinessObject instanceof ManagedBaseline) {
            ManagedBaseline baseLine = (ManagedBaseline) primaryBusinessObject;
            QueryResult qr = BaselineHelper.service.getBaselineItems(baseLine);
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTPart) {
                    list.add((WTPart) obj);
                }
            }
        }

        return list;
    }

    /**
     * 获取eca产生对象
     *
     * @param eca
     * @return ArrayList<WTObject>
     * @throws WTException
     */
    public static List<WTPart> getTargetObjectByECA(WTChangeActivity2 eca) throws WTException {
        List<WTPart> list = new ArrayList<>();

        QueryResult links = ChangeHelper2.service.getChangeablesAfter(eca);
        while (links.hasMoreElements()) {
            Object obj = links.nextElement();
            if (obj instanceof WTPart) {
                list.add((WTPart) obj);

            }
        }


        return list;
    }


    /**
     * 获取eca
     *
     * @param eca
     * @return ArrayList<WTObject>
     * @throws WTException
     */
    public static List<WTPart> getTargetObjectByECA(WTChangeActivity2 eca ,String type) throws WTException {
        List<WTPart> list = new ArrayList<>();
        if (!type.equals("AffectedObjects") && !type.equals("ResultingObjects")) {
            System.out.println("获取审阅/变更目标对象失败，只能指定为受影响对象或产生的对象");
            return list;
        }
        QueryResult links = null;
        if (type.equals("AffectedObjects")) {
            links = ChangeHelper2.service.getChangeablesBefore(eca);
        } else if (type.equals("ResultingObjects")) {
            links = ChangeHelper2.service.getChangeablesAfter(eca);
        }
        while (links.hasMoreElements()) {
            Object obj = links.nextElement();
            if (obj instanceof WTPart) {
                list.add((WTPart) obj);

            }
        }
        return list;
    }


    /**
     * 获取ecn产生对象
     *
     * @param ecn
     * @return
     * @throws WTException
     */
    public static List<WTPart> getTargetObjectByECN(WTChangeOrder2 ecn) throws WTException {
        List<WTPart> list = new ArrayList<>();

        QueryResult links = ChangeHelper2.service.getChangeablesAfter(ecn);
        while (links.hasMoreElements()) {
            Object obj = links.nextElement();
            if (obj instanceof WTPart) {
                list.add((WTPart) obj);
            }
        }
        return list;
    }


    /**
     * 获取ecn产生对象
     *
     * @param ecn
     * @return
     * @throws WTException
     */
    public static List<WTPart> getTargetObjectByECN(WTChangeOrder2 ecn,String type) throws WTException {
        List<WTPart> list = new ArrayList<>();
        if (!type.equals("AffectedObjects") && !type.equals("ResultingObjects")) {
            System.out.println("获取审阅/变更目标对象失败，只能指定为受影响对象或产生的对象");
            return list;
        }
        QueryResult links = null;
        if (type.equals("AffectedObjects")) {
            links = ChangeHelper2.service.getChangeablesBefore(ecn);
        } else if (type.equals("ResultingObjects")) {
            links = ChangeHelper2.service.getChangeablesAfter(ecn);
        }
        while (links.hasMoreElements()) {
            Object obj = links.nextElement();
            if (obj instanceof WTPart) {
                list.add((WTPart) obj);

            }
        }
        return list;
    }

    /**
     * 查询当前这个BOM产生的对象的ECN对象，取时间最新的ECN返回
     *
     * @param bom 要查询的BOM对象
     * @return 最新的ChangeOrder2对象，如果没找到则返回null
     */
    public static ChangeOrder2 getBOMLatestECN(WTPart bom) {
        try {
            QueryResult qr = ChangeHelper2.service.getUniqueImplementedChangeOrders(bom);
            List<ChangeOrder2> ecnList = new ArrayList<>();

            while (qr.hasMoreElements()) {
                ecnList.add((ChangeOrder2) qr.nextElement());
            }

            // 使用Stream找到修改时间最新的ECN
            Optional<ChangeOrder2> latestECN = ecnList.stream()
                    .max(Comparator.comparing(ChangeOrder2::getModifyTimestamp));

            return latestECN.orElse(null); // 如果没找到返回null

        } catch (WTException e) {
            e.printStackTrace();
            return null;
        }
    }


    public static List<WTChangeOrder2> getECNListByECA(WTChangeActivity2 eca) {
        boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
        List<WTChangeOrder2> ecn = new ArrayList<>();
        try {

            QueryResult qur = ChangeHelper2.service.getChangeOrder(eca);

            while (qur.hasMoreElements()) {

                WTChangeOrder2 cho = (WTChangeOrder2) qur.nextElement();

                if (!ecn.contains(cho)) {
                    ecn.add(cho);
                }

            }

        } catch (ChangeException2 e) {
            throw new RuntimeException(e);
        } catch (WTException e) {
            throw new RuntimeException(e);
        } finally {

            SessionServerHelper.manager.setAccessEnforced(enforce);

        }
        return ecn;
    }

    public static WTChangeOrder2 getECALatestECN(WTChangeActivity2 eca) {
        boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
        WTChangeOrder2 ecn = null;

        try {

            QueryResult qur = ChangeHelper2.service.getChangeOrder(eca);

            while (qur.hasMoreElements()) {
                ecn = (WTChangeOrder2) qur.nextElement();
            }

        } catch (ChangeException2 e) {
            throw new RuntimeException(e);
        } catch (WTException e) {
            throw new RuntimeException(e);
        } finally {

            SessionServerHelper.manager.setAccessEnforced(enforce);

        }
        return ecn;
    }


    /***
     * 获取审阅/变更目标对象
     *
     * @param <T>
     * @param primaryBusinessObject 流程的primaryBusinessObject
     * @param type   GetTargerObjectUtil.AffectedObjects受影响对象/GetTargerObjectUtil.ResultingObjects产生的对象
     * @param clazz    WTPart.class/WTDocument.class
     * @return ArrayList<T>
     */
    public static <T> ArrayList<T> getTargetObject(WTObject primaryBusinessObject, String type, Class<T> clazz) {
        ArrayList<T> list = new ArrayList<T>();

        if (!type.equals("AffectedObjects") && !type.equals("ResultingObjects")) {
            System.out.println("获取审阅/变更目标对象失败，只能指定为受影响对象或产生的对象");
            return list;
        }

        try {
//			if (primaryBusinessObject instanceof WTChangeReview) {
//				WTChangeReview review = (WTChangeReview) primaryBusinessObject;
//				QueryResult qr = ChangeHelper2.service.getChangeables(review);
//				list = CommonUtil.getListFromQR(qr, clazz);
//			} else
            if (primaryBusinessObject instanceof PromotionNotice) {

                PromotionNotice pn = (PromotionNotice) primaryBusinessObject;
                QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
                list = CommonUtil.getListFromQR(qr, clazz);

            } else if (primaryBusinessObject instanceof WTChangeOrder2) {

                if (type.equals("AffectedObjects")) {
                    WTChangeOrder2 eco = (WTChangeOrder2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesBefore(eco);
                    list = CommonUtil.getListFromQR(qr, clazz);
                } else if (type.equals("ResultingObjects")) {
                    WTChangeOrder2 eco = (WTChangeOrder2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eco);
                    list = CommonUtil.getListFromQR(qr, clazz);
                }

            } else if (primaryBusinessObject instanceof WTChangeActivity2) {

                if (type.equals("AffectedObjects")) {
                    WTChangeActivity2 eca = (WTChangeActivity2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesBefore(eca);
                    list = CommonUtil.getListFromQR(qr, clazz);
                } else if (type.equals("ResultingObjects")) {
                    WTChangeActivity2 eca = (WTChangeActivity2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
                    list =  CommonUtil.getListFromQR(qr, clazz);
                }

            }
        } catch (ChangeException2 e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }
}
