package ext.alphai.aistoneglobal.sap.work;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.service.CreateRFCMaterialPart;
import ext.alphai.aistoneglobal.sap.service.QueryPFCPartNumber;
import ext.alphai.aistoneglobal.sap.service.UpdateRFCMaterialPart;
import ext.alphai.aistoneglobal.sap.utils.PersistenceUtil;
import ext.alphai.aistoneglobal.sap.utils.WorkflowUtil;
import org.apache.commons.lang3.StringUtils;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.Promotable;
import wt.maturity.PromotionNotice;
import wt.maturity.PromotionTarget;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 升级请求发送部件到SAP
 */
public class RFCSendPartToSAPWork {
    static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 执行发送部件
     * @param pbo
     * @return
     */
    public static String processRFCToSAPWork(WTObject pbo) throws WTException, JsonProcessingException {
        //以前的流程默认工厂 6020
        String plant = "6020";
        String result="";
        List<RFCSendPartResultVo> resultMap = new ArrayList<>();
        List<WTPart> wtParts = null;
        if(pbo instanceof PromotionNotice){
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            wtParts = WorkflowUtil.getTargerObjectByPromotionNotices(promotionNotice);
        }else if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
            wtParts = WorkflowUtil.getTargetObjectByECA(eca);
        }else if (pbo instanceof WTChangeOrder2){
            WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
            wtParts = WorkflowUtil.getTargetObjectByECN(ecn);
        }

        for (WTPart part : wtParts) {
            Boolean selectSAPPart = QueryPFCPartNumber.selectSAPPart(part.getNumber());
            Map<String, String> stringStringMap = null;
            if(selectSAPPart){
                // 修改部件
                stringStringMap = UpdateRFCMaterialPart.RFCCreatePart(part);
            }else {
                // 创建部件
                stringStringMap = CreateRFCMaterialPart.RFCCreatePart(part,plant);
            }
            RFCSendPartResultVo resultVo = new RFCSendPartResultVo();
            resultVo.setPartOR(part.getNumber());
            String key = stringStringMap.get(Constant.E_TYPE);
            if(Constant.S.equals(key)){
                resultVo.setResult(true);
            } else if (Constant.E.equals(key)) {
                resultVo.setResult(false);
            }
            resultVo.setMsg(stringStringMap.get(Constant.E_MESSAGE));
            resultMap.add(resultVo);
        }
        result = objectMapper.writeValueAsString(resultMap);
        return result;
    }


    /**
     * 执行发送部件
     * @param pbo
     * @return
     */
    public static String processRFCToSAPWork(WTObject pbo , String plant) throws WTException, JsonProcessingException {
        //流程默认工厂 6020
        if (StringUtils.isEmpty(plant)) {
            plant="6020";
        }
        String result="";
        List<RFCSendPartResultVo> resultMap = new ArrayList<>();
        List<WTPart> wtParts = null;
        if(pbo instanceof PromotionNotice){
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            wtParts = WorkflowUtil.getTargerObjectByPromotionNotices(promotionNotice);
        }else if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
            wtParts = WorkflowUtil.getTargetObjectByECA(eca);
        }else if (pbo instanceof WTChangeOrder2){
            WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
            wtParts = WorkflowUtil.getTargetObjectByECN(ecn);
        }

        for (WTPart part : wtParts) {
            Boolean selectSAPPart = QueryPFCPartNumber.selectSAPPart(part.getNumber());
            Map<String, String> stringStringMap = null;
            if(selectSAPPart){
                // 修改部件
                stringStringMap = UpdateRFCMaterialPart.RFCCreatePart(part);
            }else {
                // 创建部件
                stringStringMap = CreateRFCMaterialPart.RFCCreatePart(part,plant);
            }
            RFCSendPartResultVo resultVo = new RFCSendPartResultVo();
            resultVo.setPartOR(part.getNumber());
            String key = stringStringMap.get(Constant.E_TYPE);
            if(Constant.S.equals(key)){
                resultVo.setResult(true);
            } else if (Constant.E.equals(key)) {
                resultVo.setResult(false);
            }
            resultVo.setMsg(stringStringMap.get(Constant.E_MESSAGE));
            resultMap.add(resultVo);
        }
        result = objectMapper.writeValueAsString(resultMap);
        return result;
    }

    /**
     * 检查发送是否成功
     * @param resultJson
     * @return
     */
    public static String checkSendPartResult(String resultJson) throws JsonProcessingException {
        String result="";
        List<RFCSendPartResultVo> rfcSendPartResultVos = objectMapper.readValue(resultJson, new TypeReference<List<RFCSendPartResultVo>>() {
        });
        boolean isError = false;
        for (RFCSendPartResultVo rfcSendPartResultVo : rfcSendPartResultVos) {
            boolean result1 = rfcSendPartResultVo.isResult();
            if(!result1){
                isError = true;
            }
        }
        if(isError){
            result = "ERROR";
        }else {
            result = "OK";
        }

        return result;
    }




}
