package ext.alphai.aistoneglobal.sap.work;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateBOMSer;
import ext.alphai.aistoneglobal.sap.utils.PartUtil;
import ext.alphai.aistoneglobal.sap.utils.WorkflowUtil;
import ext.alphai.aistoneglobal.sap.vo.BOMSendResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.WTObject;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 升级请求发送部件到SAP
 */
public class RFCSendBOMToSAPWork {
    static final ObjectMapper objectMapper = new ObjectMapper();

    private static final Logger logger = LogManager.getLogger(RFCSendBOMToSAPWork.class);
    static String AffectedObjects = "AffectedObjects";//受影响
    static String ResultingObjects = "ResultingObjects";//产生

    /**
     * 执行发送部件
     *
     * @param pbo
     * @return
     */
    public static String processRFCToSAPWork(WTObject pbo, String factoryView) throws WTException, JsonProcessingException {
        String result = "";
        List<RFCSendPartResultVo> resultMap = new ArrayList<>();
        List<WTPart> wtParts = null;
        if (pbo instanceof PromotionNotice) {
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            wtParts = WorkflowUtil.getTargerObjectByPromotionNotices(promotionNotice);
        } else if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
            wtParts = WorkflowUtil.getTargetObjectByECA(eca);
        } else if (pbo instanceof WTChangeOrder2) {
            WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
            wtParts = WorkflowUtil.getTargetObjectByECN(ecn);
        }

        //去掉物料或者物料
        if (wtParts != null) {
            wtParts.removeIf(wtPart -> {
                // 直接调用，不捕获异常
                return PartUtil.getLinksByPart(wtPart).isEmpty() || wtPart.isEndItem();
            });
        }

        System.out.println("测试"+wtParts.toString());



        for (WTPart part : wtParts) {

//            //
//            if (isInitialVersion(part)) {
//
//                continue;
//            }

            List<WTPart> partsToProcess = new ArrayList<>();
            partsToProcess.add(part);

            Map<WTPart, Map<WTPart, BOMSendResult>> wtPartMapMap = CreateOrUpdateBOMSer.sendSingleBOMToSAP(partsToProcess, factoryView, Constant.WORKFLOW);
            Map<WTPart, BOMSendResult> wtPartResultMap = wtPartMapMap.get(part);
            // 收集发送失败的子项和错误信息
            List<String> failedPartNumbers = new ArrayList<>();
            List<String> errorMessages = new ArrayList<>();
            boolean isAllOK = true;

            for (Map.Entry<WTPart, BOMSendResult> entry : wtPartResultMap.entrySet()) {
                WTPart key = entry.getKey();
                BOMSendResult bomSendResult = entry.getValue();

                if (!bomSendResult.isSuccess()) {
                    isAllOK = false;
                    failedPartNumbers.add(key.getNumber());
                    if (bomSendResult.getErrorMessage() != null) {
                        errorMessages.add(key.getNumber() + ": " + bomSendResult.getErrorMessage());
                    }
                }
            }

            resultMap = convertToRFCSendPartResultVo(wtPartMapMap);
        }


        result = objectMapper.writeValueAsString(resultMap);
        return result;
    }


    /**
     * 执行发送部件
     *
     * @param pbo
     * @return
     */
    public static String processRFCToSAPWorkDifferent(WTObject pbo, String factoryView) throws WTException, JsonProcessingException {
        String result = "";
        List<RFCSendPartResultVo> resultMap = new ArrayList<>();
        List<WTPart> beforeWTParts = null;
        List<WTPart> afterWTParts = null;
        if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
            beforeWTParts = WorkflowUtil.getTargetObjectByECA(eca, AffectedObjects);
            afterWTParts = WorkflowUtil.getTargetObjectByECA(eca, ResultingObjects);
        } else if (pbo instanceof WTChangeOrder2) {
            WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
            beforeWTParts = WorkflowUtil.getTargetObjectByECN(ecn, AffectedObjects);
            afterWTParts = WorkflowUtil.getTargetObjectByECN(ecn, ResultingObjects);
        }


        if (beforeWTParts == null) {
            System.out.println("未添加受影响对象");
            result = objectMapper.writeValueAsString(resultMap);
            return result;
        }
        if (afterWTParts == null) {
            System.out.println("未添加产生对象");
            result = objectMapper.writeValueAsString(resultMap);
            return result;
        }


        //去除 物料和成品
        if (beforeWTParts != null) {
            beforeWTParts.removeIf(wtPart -> {
                // 直接调用，不捕获异常
                return PartUtil.getLinksByPart(wtPart).isEmpty() || wtPart.isEndItem();
            });
        }


        if (afterWTParts != null) {
            afterWTParts.removeIf(wtPart -> {
                // 直接调用，不捕获异常
                return PartUtil.getLinksByPart(wtPart).isEmpty() || wtPart.isEndItem();
            });
        }

        System.out.println("受影响对象"+beforeWTParts.toString());
        System.out.println("成品对象"+afterWTParts.toString());


        for (WTPart beforePart : beforeWTParts) {

            for (WTPart afterPart : afterWTParts) {


//                //产生对象若修订版本是1或者A  则跳过
//                if (isInitialVersion(afterPart)) {
//                    continue;
//                }

                //是相同编号但不同版本部件
                if (beforePart.getNumber().equals(afterPart.getNumber())) {
                    Map<WTPart, Map<WTPart, BOMSendResult>> wtPartMapMap = new HashMap<>();
                    Map<WTPart, BOMSendResult> wtPartResultMap = CreateOrUpdateBOMSer.sendSingleBOMToSAP(beforePart, afterPart, factoryView);
                    List<String> failedPartNumbers = new ArrayList<>();
                    List<String> errorMessages = new ArrayList<>();
                    boolean isAllOK = true;

                    for (Map.Entry<WTPart, BOMSendResult> entry : wtPartResultMap.entrySet()) {
                        WTPart key = entry.getKey();
                        BOMSendResult bomSendResult = entry.getValue();

                        if (!bomSendResult.isSuccess()) {
                            isAllOK = false;
                            failedPartNumbers.add(key.getNumber());
                            if (bomSendResult.getErrorMessage() != null) {
                                errorMessages.add(key.getNumber() + ": " + bomSendResult.getErrorMessage());
                            }
                        }
                    }

                    resultMap = convertToRFCSendPartResultVo(wtPartMapMap);
                }
            }
        }


        result = objectMapper.writeValueAsString(resultMap);
        return result;
    }

    /**
     * 检查发送是否成功
     *
     * @param resultJson
     * @return
     */
    public static String checkSendPartResult(String resultJson) throws JsonProcessingException {
        String result = "";
        List<RFCSendPartResultVo> rfcSendPartResultVos = objectMapper.readValue(resultJson, new TypeReference<List<RFCSendPartResultVo>>() {
        });
        boolean isError = false;
        for (RFCSendPartResultVo rfcSendPartResultVo : rfcSendPartResultVos) {
            boolean result1 = rfcSendPartResultVo.isResult();
            if (!result1) {
                isError = true;
            }
        }
        if (isError) {
            result = "ERROR";
        } else {
            result = "OK";
        }

        return result;
    }


    // 转换方法
    public static List<RFCSendPartResultVo> convertToRFCSendPartResultVo(Map<WTPart, Map<WTPart, BOMSendResult>> wtPartMapMap) {
        List<RFCSendPartResultVo> resultList = new ArrayList<>();

        if (wtPartMapMap == null || wtPartMapMap.isEmpty()) {
            return resultList;
        }

        // 遍历所有父部件（实际上只有一个）
        for (Map.Entry<WTPart, Map<WTPart, BOMSendResult>> parentEntry : wtPartMapMap.entrySet()) {
            WTPart parentPart = parentEntry.getKey();
            Map<WTPart, BOMSendResult> childResults = parentEntry.getValue();

            if (childResults != null) {
                // 遍历所有子部件结果
                for (Map.Entry<WTPart, BOMSendResult> childEntry : childResults.entrySet()) {
                    WTPart childPart = childEntry.getKey();
                    BOMSendResult bomSendResult = childEntry.getValue();

                    // 创建结果对象
                    RFCSendPartResultVo resultVo = new RFCSendPartResultVo();
                    resultVo.setPartOR(childPart.getNumber()); // 子部件号
                    resultVo.setResult(bomSendResult.isSuccess());
                    resultVo.setMsg(bomSendResult.getErrorMessage());

                    resultList.add(resultVo);
                }
            }
        }

        return resultList;
    }


    //校验是否初始版本
    public static boolean isInitialVersion(WTPart wtPart) {
        boolean result = false;
        String version = wtPart.getVersionIdentifier().getValue();
        //
        if ("1".equals(version) || "A".equals(version)) {
            System.out.println("【跳过】部件 " + wtPart.getNumber() + " 版本 " +
                    version);
            result = true;
        }
        return result;
    }


}
