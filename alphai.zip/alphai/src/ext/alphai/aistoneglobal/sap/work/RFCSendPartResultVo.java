package ext.alphai.aistoneglobal.sap.work;

/**
 * 流程发送结果对象
 */
public class RFCSendPartResultVo {
    private String partOR;
    private boolean result;
    private String msg;

    public String getPartOR() {
        return partOR;
    }

    public void setPartOR(String partOR) {
        this.partOR = partOR;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
