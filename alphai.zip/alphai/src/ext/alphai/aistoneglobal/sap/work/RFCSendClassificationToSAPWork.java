package ext.alphai.aistoneglobal.sap.work;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateClassificationSer;
import ext.alphai.aistoneglobal.sap.utils.PartUtil;
import ext.alphai.aistoneglobal.sap.utils.WorkflowUtil;
import wt.doc.WTDocument;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RFCSendClassificationToSAPWork {

    static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * PLM承认流程
     *
     * @param pbo
     * @param sign 'G'  GPM   'R'  签核 'A'  APPROVED
     * @return
     * @throws WTException
     * @throws JsonProcessingException
     */
    /**
     * 从业务对象获取部件集合
     */
    private static ArrayList<WTPart> getPartsFromBusinessObject(WTObject pbo) throws WTException {
        ArrayList<WTDocument> documents = WorkflowUtil.getTargetObject(pbo, "AffectedObjects", WTDocument.class);
        ArrayList<WTPart> parts = new ArrayList<>();

        if (documents == null || documents.isEmpty()) {
            if (pbo instanceof WTDocument) {
                WTDocument wDoc = (WTDocument) pbo;
                System.out.println("pbo获取" + wDoc);
                List<WTPart> partByDescribesDoc = PartUtil.getPartByDescribesDoc(wDoc);
                parts.addAll(partByDescribesDoc);
            }
        } else {
            for (WTDocument document : documents) {
                List<WTPart> partByDescribesDoc = PartUtil.getPartByDescribesDoc(document);
                if (!partByDescribesDoc.isEmpty()) {
                    parts.addAll(partByDescribesDoc);
                }
            }
        }

        return parts;
    }

    /**
     * PLM承认流程
     */
    public static String processRFCToSAPWork(WTObject pbo, String sign) throws WTException, JsonProcessingException {
        Map<String, String> stringStringMap = new HashMap<>();
        ArrayList<WTPart> parts = getPartsFromBusinessObject(pbo);

        if (parts.isEmpty()) {
            stringStringMap.put("globalType", "E1");
            stringStringMap.put("globalMessage", "获取文档说明部件集合失败！");
            return objectMapper.writeValueAsString(stringStringMap);
        }

        stringStringMap = CreateOrUpdateClassificationSer.updateApproveClassification(parts, "2", sign);
        return objectMapper.writeValueAsString(stringStringMap);
    }

    /**
     * PLM检查流程
     */
    public static String processRFCToCheckSAPWork(WTObject pbo) throws WTException, JsonProcessingException {
        Map<String, String> stringStringMap = new HashMap<>();
        ArrayList<WTPart> parts = getPartsFromBusinessObject(pbo);

        if (parts.isEmpty()) {
            stringStringMap.put("globalType", "E1");
            stringStringMap.put("globalMessage", "获取文档说明部件集合失败！");
            return objectMapper.writeValueAsString(stringStringMap);
        }

        return objectMapper.writeValueAsString(stringStringMap);
    }


    /**
     *
     * @param pbo
     * @return
     * @throws WTException
     * @throws JsonProcessingException
     */
    public static String processRFCToSAPWork(WTObject pbo) throws WTException, JsonProcessingException {
        Map<String, String> stringStringMap = new HashMap<>();
        ArrayList<WTPart> parts = WorkflowUtil.getTargetObject(pbo, "AffectedObjects", WTPart.class);
        if (parts.isEmpty()) {
            stringStringMap.put("globalType", "E1");
            stringStringMap.put("globalMessage", "获取文档说明部件集合失败！");
            return objectMapper.writeValueAsString(stringStringMap);
        }
        stringStringMap = CreateOrUpdateClassificationSer.updateNPIClassification(parts, "2");

        return objectMapper.writeValueAsString(stringStringMap);
    }
}
