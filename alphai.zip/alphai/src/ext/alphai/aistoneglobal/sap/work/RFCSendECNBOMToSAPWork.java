package ext.alphai.aistoneglobal.sap.work;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateECNSer;
import ext.alphai.aistoneglobal.sap.utils.PartUtil;
import ext.alphai.aistoneglobal.sap.utils.WorkflowUtil;
import ext.alphai.aistoneglobal.sap.vo.BOMSendResult;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrder2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.util.WTException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 升级请求发送部件到SAP
 */
public class RFCSendECNBOMToSAPWork {
    static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 执行发送部件
     * @param pbo
     * @return
     */
    public static String processRFCToSAPWork(WTObject pbo,String factoryView) throws Exception {
        String result="";
        List<RFCSendPartResultVo> resultMap = new ArrayList<>();
        //产生对象
        List<WTPart> targetParts = WorkflowUtil.getTargetParts(pbo);
        WTChangeOrder2 ecn = null;
        if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
             ecn = WorkflowUtil.getECALatestECN(eca);
        }else if (pbo instanceof WTChangeOrder2) {
            ecn = (WTChangeOrder2) pbo;
        }


        // 直接从 targetParts 中移除初版部件
        //去除物料和成品
        if (targetParts != null) {
            targetParts.removeIf(wtPart ->
                    RFCSendECNBOMToSAPWork.isInitialVersion(wtPart) ||
                            PartUtil.getLinksByPart(wtPart).isEmpty() ||
                            wtPart.isEndItem()
            );
        }

        System.out.println("物料"+targetParts.toString());

        if(ecn != null && !targetParts.isEmpty()){
            System.out.println("ECA获取到的ECN编号："+ecn.getNumber());

            Map<String, String> stringStringMap = CreateOrUpdateECNSer.RFCCreateOrUpdateECN(targetParts ,ecn,factoryView);
            RFCSendPartResultVo resultVo = new RFCSendPartResultVo();
            String key = stringStringMap.get(Constant.E_TYPE);
            if(Constant.S.equals(key)){
                resultVo.setResult(true);
            } else if (Constant.E.equals(key)) {
                resultVo.setResult(false);
            }
            resultVo.setMsg(stringStringMap.get(Constant.E_MESSAGE));
            resultMap.add(resultVo);
        }else{
            System.out.println("ECA未获取到ECN");
        }



        result = objectMapper.writeValueAsString(resultMap);
        return result;
    }


    /**
     * 执行发送部件  修改
     * @param pbo
     * @return
     */
    public static String processRFCECNInfoToSAP(WTObject pbo,String factoryView) throws WTException, JsonProcessingException {
        String result="";
        List<RFCSendPartResultVo> resultMap = new ArrayList<>();
        WTChangeOrder2 ecn = null;
        if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
            ecn = WorkflowUtil.getECALatestECN(eca);
        }else if (pbo instanceof WTChangeOrder2) {
            ecn = (WTChangeOrder2) pbo;
        }
        if(ecn!=null){
            System.out.println("ECA获取到的ECN编号："+ecn);

            Map<String, String> stringStringMap = CreateOrUpdateECNSer.RFCUpdateECNToSAP(ecn);
            RFCSendPartResultVo resultVo = new RFCSendPartResultVo();
//            resultVo.setPartOR(PersistenceUtil.object2Oid(part));
            String key = stringStringMap.get(Constant.E_TYPE);
            if(Constant.S.equals(key)){
                resultVo.setResult(true);
            } else if (Constant.E.equals(key)) {
                resultVo.setResult(false);
            }
            resultVo.setMsg(stringStringMap.get(Constant.E_MESSAGE));
            resultMap.add(resultVo);
        }else{
            System.out.println("ECA未获取到ECN");
        }
        result = objectMapper.writeValueAsString(resultMap);
        return result;
    }



    /**
     * 检查发送是否成功
     * @param resultJson
     * @return
     */
    public static String checkSendPartResult(String resultJson) throws JsonProcessingException {
        String result="";
        List<RFCSendPartResultVo> rfcSendPartResultVos = objectMapper.readValue(resultJson, new TypeReference<List<RFCSendPartResultVo>>() {
        });
        boolean isError = false;
        for (RFCSendPartResultVo rfcSendPartResultVo : rfcSendPartResultVos) {
            boolean result1 = rfcSendPartResultVo.isResult();
            if(!result1){
                isError = true;
            }
        }
        if(isError){
            result = "ERROR";
        }else {
            result = "OK";
        }

        return result;
    }



    /**
     * 获取eca产生对象
     *
     * @param eca
     * @return ArrayList<WTObject>
     * @throws WTException
     */
    public static List<WTPart> getTargetObjectByECA(WTChangeActivity2 eca) throws WTException {
        List<WTPart> list = new ArrayList<>();

        QueryResult links= ChangeHelper2.service.getChangeablesAfter(eca, false);
        while (links.hasMoreElements()) {
            Object obj = links.nextElement();
            list.add((WTPart) obj);
        }
        return list;
    }

    // 转换方法
    public static List<RFCSendPartResultVo> convertToRFCSendPartResultVo(Map<WTPart, Map<WTPart, BOMSendResult>> wtPartMapMap) {
        List<RFCSendPartResultVo> resultList = new ArrayList<>();

        if (wtPartMapMap == null || wtPartMapMap.isEmpty()) {
            return resultList;
        }

        // 遍历所有父部件（实际上只有一个）
        for (Map.Entry<WTPart, Map<WTPart, BOMSendResult>> parentEntry : wtPartMapMap.entrySet()) {
            WTPart parentPart = parentEntry.getKey();
            Map<WTPart, BOMSendResult> childResults = parentEntry.getValue();

            if (childResults != null) {
                // 遍历所有子部件结果
                for (Map.Entry<WTPart, BOMSendResult> childEntry : childResults.entrySet()) {
                    WTPart childPart = childEntry.getKey();
                    BOMSendResult bomSendResult = childEntry.getValue();

                    // 创建结果对象
                    RFCSendPartResultVo resultVo = new RFCSendPartResultVo();
                    resultVo.setPartOR(childPart.getNumber()); // 子部件号
                    resultVo.setResult(bomSendResult.isSuccess());
                    resultVo.setMsg(bomSendResult.getErrorMessage());

                    resultList.add(resultVo);
                }
            }
        }

        return resultList;
    }


    //校验是否初始版本
    public static boolean isInitialVersion(WTPart wtPart) {
        boolean result = false;
        String version = wtPart.getVersionIdentifier().getValue();
        //
        if ("1".equals(version) || "A".equals(version)) {
            System.out.println("【跳过】部件 " + wtPart.getNumber() + " 版本 " +
                    version);
            result = true;
        }
        return result;
    }
}
