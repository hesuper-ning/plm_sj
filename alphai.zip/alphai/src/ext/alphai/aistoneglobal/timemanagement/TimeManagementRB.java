package ext.alphai.aistoneglobal.timemanagement;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.timemanagement.TimeManagementRB")
public class TimeManagementRB extends WTListResourceBundle {



    @RBEntry("Time Management")
    public static final String E_T_M_TITLE = "timeManager.cusNav.title";

    @RBEntry("Time Management")
    public static final String E_T_M_TOOLTIP = "timeManager.cusNav.tooltip";

    @RBEntry("Time Management")
    public static final String E_T_M_DES = "timeManager.cusNav.description";

    @RBEntry("navigator_home.png")
    public static final String E_T_M_ICON = "timeManager.cusNav.icon";



    @RBEntry("Time Management")
    public static final String I_T_M_TOOLTIP = "timeManager.manager.tooltip";

    @RBEntry("Time Management")
    public static final String I_T_M_DES = "timeManager.manager.description";


}
