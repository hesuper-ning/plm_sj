package ext.alphai.aistoneglobal.timemanagement.vo;

public class ResponseVo {

    public int code;

    public String msg;

    public Object data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public ResponseVo(int code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public ResponseVo() {
    }
    public  ResponseVo success(Object object){
        ResponseVo vo = new ResponseVo();
        vo.setCode(200);
        vo.setMsg("操作成功");
        vo.setData(object);
        return vo;
    }


    public  ResponseVo success(int result, String msg){
        ResponseVo vo = new ResponseVo();
        if(result > 0){
            vo.setCode(200);
        }else {
            vo.setCode(400);
        }
        vo.setMsg(msg);
        return vo;
    }


    public  ResponseVo error(int code, String msg){
        ResponseVo vo = new ResponseVo();
        vo.setCode(code);
        vo.setMsg(msg);
        return vo;
    }


    public  ResponseVo result(int result){
        ResponseVo vo = new ResponseVo();
        if(result > 0){
            vo.setCode(200);
            vo.setMsg("操作成功");
        }else {
            vo.setCode(400);
            vo.setMsg("操作失败");
        }
        return vo;
    }
}
