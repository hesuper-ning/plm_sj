package ext.alphai.aistoneglobal.timemanagement.dao;

import com.ptc.projectmanagement.assignment.ResourceAssignment;
import com.ptc.projectmanagement.assignment.resource.PlanResource;
import com.ptc.projectmanagement.plan.PlanActivity;
import ext.alphai.aistoneglobal.timemanagement.Constant;
import ext.alphai.aistoneglobal.timemanagement.util.CommonUtil;
import ext.alphai.aistoneglobal.timemanagement.util.ToolUtil;
import ext.alphai.aistoneglobal.timemanagement.vo.AIWorkHoursVo;
import org.apache.commons.lang3.StringUtils;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.inf.container.WTContainer;
import wt.meeting.actionitem.DiscreteActionItem;
import wt.org.WTUser;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TimeManagementDAO {
    // 日期格式
    private static final String DATE_PATTERN_FRONTEND = "yyyy-MM-dd";
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat(DATE_PATTERN_FRONTEND);

    /**
     * 根据当前用户和非解决状态查询 措施项
     *
     * @return
     * @throws WTException
     */
    public static List<DiscreteActionItem> findDiscreteActionItems(WTUser principal) throws WTException {
        List<DiscreteActionItem> discreteActionItems = new ArrayList<>();

        //根据用户查所有的措施项
//        WTUser principal = (WTUser) SessionHelper.getPrincipal();
//        ActionItem[] actionItems = ActionItemServiceHelper.service.getActionItems(principal);
//        for (ActionItem actionItem : actionItems) {
//            DiscreteActionItem discreteActionItem = (DiscreteActionItem) actionItem;
//                    discreteActionItems.add(discreteActionItem);
//
//
//        }
        QuerySpec querySpec = new QuerySpec(DiscreteActionItem.class);
        SearchCondition sc = new SearchCondition(DiscreteActionItem.class, "ownership.owner.key.id", SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(principal).getId());
        querySpec.appendWhere(sc, new int[]{0});
        querySpec.appendAnd();
        sc = new SearchCondition(new ClassAttribute(DiscreteActionItem.class, DiscreteActionItem.LIFE_CYCLE_STATE), SearchCondition.NOT_IN,
                new ArrayExpression(new String[] { Constant.RESOLVED}));
        querySpec.appendWhere(sc, new int[] { 0 });

        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);

        while (queryResult.hasMoreElements()) {
            Object o = queryResult.nextElement();
            if (o instanceof DiscreteActionItem) {
                DiscreteActionItem link = (DiscreteActionItem) o;
                discreteActionItems.add(link);
            }
        }
        return discreteActionItems;
    }


    /**
     * 根据当前用户查询和未完工 分配资源
     *
     * @return
     * @throws WTException
     */
    public static List<ResourceAssignment> findResourceAssignments(WTUser principal) throws WTException {
        List<ResourceAssignment> resourceAssignmentList = new ArrayList<>();

//        WTUser principal = (WTUser) SessionHelper.getPrincipal();
        //根据用户查所有的资源活动
//        WTCollection resourceAssignments = AssignmentHelper.service.getResourceAssignments(principal);
//        for (Object object : resourceAssignments) {
//            ObjectReference or = (ObjectReference) object;
//            ResourceAssignment resourceAssignment = (ResourceAssignment) or.getObject();
//            double percentWorkComplete = resourceAssignment.getPercentWorkComplete();
//            resourceAssignmentList.add(resourceAssignment);
//        }

        QuerySpec querySpec = new QuerySpec();
        int planResourceID = querySpec.addClassList(PlanResource.class, false);
        int resourceAssignmentID = querySpec.addClassList(ResourceAssignment.class, true);
        double complete = 100.0;//完工率 100.0说明完成
        SearchCondition sc = new SearchCondition(ResourceAssignment.class, "percentWorkComplete", SearchCondition.NOT_EQUAL, Constant.COMPLETE);
        querySpec.appendWhere(sc, resourceAssignmentID);
        querySpec.appendAnd();
        SearchCondition var5 = new SearchCondition(PlanResource.class, "principalRef.key.id", SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(principal).getId());
        querySpec.appendWhere(var5, planResourceID);
        querySpec.appendAnd();
        SearchCondition var6 = new SearchCondition(new ClassAttribute(ResourceAssignment.class, "roleAObjectRef.key.id"), SearchCondition.EQUAL, new ClassAttribute(PlanResource.class, "thePersistInfo.theObjectIdentifier.id"));
        querySpec.appendWhere(var6, resourceAssignmentID, planResourceID);
        QueryResult var7 = PersistenceHelper.manager.find(querySpec);
        WTArrayList var8 = new WTArrayList();
        var8.addAll(var7);
        for (Object o : var8) {
            ObjectReference or = (ObjectReference)o;
            ResourceAssignment  resourceAssignment =(ResourceAssignment ) or.getObject();
            resourceAssignmentList.add(resourceAssignment);
        }
        return resourceAssignmentList;
    }


    // ========== 基础CRUD操作 ==========

    /**
     * 插入工时记录（触发器会自动设置CREATE_TIME和UPDATE_TIME）
     */
    public static int insertWorkHours(AIWorkHoursVo vo) throws SQLException, WTException {
        // 验证日期
        if (!isValidDate(vo.getWorkDate())) {
            throw new IllegalArgumentException("工作日期格式不正确，应为yyyy-MM-dd格式");
        }

        String sql = "INSERT INTO AI_WORK_HOURS (PROJECT_ID, WORK_TYPE, TASK_ID, TASK_NAME, " +
                "WORK_DATE, HOURS, REMARKS, REPORTER_ID) " +  // 注意：不包含CREATE_TIME和UPDATE_TIME
                "VALUES (?, ?, ?, ?, TO_DATE(?, 'YYYY-MM-DD'), ?, ?, ?)";

        String[] params = {
                vo.getProjectId(),
                vo.getWorkType(),
                vo.getTaskId(),
                vo.getTaskName(),
                vo.getWorkDate(),  // 前端传来的yyyy-MM-dd格式
                vo.getHours() != null ? vo.getHours().toString() : null,
                vo.getRemarks(),
                vo.getReporterId()
        };

//        int affectedRows = excuteUpdate(sql, params);

//        if (affectedRows > 0) {
//            Long lastId = getLastInsertId();
//            if (lastId != null) {
//                vo.setWorkId(lastId);
//                // 触发器会自动设置时间，这里查询获取
//                return selectById(lastId);
//            }
//        }
//        return null;
        return excuteUpdate(sql, params);
    }

    /**
     * 更新工时记录（触发器会自动更新UPDATE_TIME）
     */
    public static int updateWorkHours(AIWorkHoursVo vo) throws SQLException, WTException {
        if (vo.getWorkId() == null) {
            return 0;
        }

        // 验证日期
        if (vo.getWorkDate() != null && !isValidDate(vo.getWorkDate())) {
            throw new IllegalArgumentException("工作日期格式不正确，应为yyyy-MM-dd格式");
        }

        String sql = "UPDATE AI_WORK_HOURS SET " +
                "PROJECT_ID = ?, " +
                "WORK_TYPE = ?, " +
                "TASK_ID = ?, " +
                "TASK_NAME = ?, " +
                "WORK_DATE = TO_DATE(?, 'YYYY-MM-DD'), " +
                "HOURS = ?, " +
                "REMARKS = ?, " +
                "REPORTER_ID = ? " +  // 注意：不更新UPDATE_TIME，触发器会自动更新
                "WHERE WORK_ID = ?";

        String[] params = {
                vo.getProjectId(),
                vo.getWorkType(),
                vo.getTaskId(),
                vo.getTaskName(),
                vo.getWorkDate(),
                vo.getHours() != null ? vo.getHours().toString() : null,
                vo.getRemarks(),
                vo.getReporterId(),
                vo.getWorkId().toString()
        };



//        int affectedRows = excuteUpdate(sql, params);
//
//        if (affectedRows > 0) {
//            // 触发器会自动更新时间，这里查询获取更新后的记录
//            return selectById(vo.getWorkId());
//        }
//        return null;

        return excuteUpdate(sql, params);
    }

    /**
     * 根据ID删除工时记录
     */
    public static int deleteById(Long workId) throws SQLException {
        String sql = "DELETE FROM AI_WORK_HOURS WHERE WORK_ID = ?";
        return excuteUpdate(sql, workId.toString());
    }

    /**
     * 根据ID查询工时记录
     */
    public static AIWorkHoursVo selectById(Long workId) throws SQLException, WTException {
        String sql = "SELECT * FROM AI_WORK_HOURS WHERE WORK_ID = ?";
        ResultSet rs = excuteSelect(sql, workId.toString());

        if (rs != null && rs.next()) {
            return mapResultSetToAIWorkHoursVo(rs);
        }
        return null;
    }


    // ========== 带用户ID过滤的查询方法 ==========

    /**
     * 查询当前用户本周所有工时任务
     * @param reporterId 用户ID（填报人ID）
     * @return 当前用户的本周工时VO列表
     */
    public static List<AIWorkHoursVo> selectThisWeekByUser(String reporterId) throws SQLException, WTException {
        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE, 'IW') = TRUNC(SYSDATE, 'IW') " +
                "AND REPORTER_ID = ? " +
                "ORDER BY WORK_DATE, PROJECT_ID, TASK_ID";

        ResultSet rs = excuteSelect(sql, reporterId);
        return resultSetToVoList(rs);
    }

    /**
     * 查询本周所有工时任务（可选用户ID过滤）
     * @param reporterId 用户ID（可为null，null时查询所有用户）
     * @return 本周工时VO列表
     */
    public static List<AIWorkHoursVo> selectThisWeek(String reporterId) throws SQLException, WTException {
        if (reporterId == null || reporterId.trim().isEmpty()) {
            // 查询所有用户的本周工时
            return selectThisWeekAll();
        } else {
            // 查询指定用户的本周工时
            return selectThisWeekByUser(reporterId);
        }
    }

    /**
     * 查询本周所有用户的工时任务
     */
    private static List<AIWorkHoursVo> selectThisWeekAll() throws SQLException, WTException {
        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE, 'IW') = TRUNC(SYSDATE, 'IW') " +
                "ORDER BY WORK_DATE, PROJECT_ID, TASK_ID";

        ResultSet rs = excuteSelect(sql);
        return resultSetToVoList(rs);
    }

    /**
     * 查询当前用户指定周的工时任务
     * @param reporterId 用户ID
     * @param dateStr 该周内的任意日期（yyyy-MM-dd格式）
     * @return 当前用户指定周的工时VO列表
     */
    public static List<AIWorkHoursVo> selectWeekByUserAndDate(String reporterId, String dateStr) throws SQLException, WTException {
        if (!isValidDate(dateStr)) {
            throw new IllegalArgumentException("日期格式不正确，应为yyyy-MM-dd格式");
        }

        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE, 'IW') = TRUNC(TO_DATE(?, 'YYYY-MM-DD'), 'IW') " +
                "AND REPORTER_ID = ? " +
                "ORDER BY WORK_DATE, PROJECT_ID, TASK_ID";

        ResultSet rs = excuteSelect(sql, dateStr, reporterId);
        return resultSetToVoList(rs);
    }

    /**
     * 查询当前用户今天的工作记录
     * @param reporterId 用户ID
     * @return 当前用户今天的工时VO列表
     */
    public static List<AIWorkHoursVo> selectTodayByUser(String reporterId) throws SQLException, WTException {
        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE) = TRUNC(SYSDATE) " +
                "AND REPORTER_ID = ? " +
                "ORDER BY WORK_ID";

        ResultSet rs = excuteSelect(sql, reporterId);
        return resultSetToVoList(rs);
    }

    /**
     * 查询当前用户指定日期的工作记录
     * @param reporterId 用户ID
     * @param dateStr 日期字符串（yyyy-MM-dd格式）
     * @return 当前用户指定日期的工时VO列表
     */
    public static List<AIWorkHoursVo> selectByDateAndUser(String dateStr, String reporterId) throws SQLException, WTException {
        if (!isValidDate(dateStr)) {
            throw new IllegalArgumentException("日期格式不正确，应为yyyy-MM-dd格式");
        }

        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE) = TO_DATE(?, 'YYYY-MM-DD') " +
                "AND REPORTER_ID = ? " +
                "ORDER BY WORK_ID";

        ResultSet rs = excuteSelect(sql, dateStr, reporterId);
        return resultSetToVoList(rs);
    }




    /**
     * 查询当前用户按日期范围的工作记录
     * @param reporterId 用户ID
     * @param startDate 开始日期（yyyy-MM-dd格式）
     * @param endDate 结束日期（yyyy-MM-dd格式）
     * @return 当前用户日期范围内的工时VO列表
     */
    public static List<AIWorkHoursVo> selectByDateRangeAndUser(String reporterId, String startDate, String endDate)
            throws SQLException, WTException {
        if (startDate != null && !isValidDate(startDate)) {
            throw new IllegalArgumentException("开始日期格式不正确，应为yyyy-MM-dd格式");
        }
        if (endDate != null && !isValidDate(endDate)) {
            throw new IllegalArgumentException("结束日期格式不正确，应为yyyy-MM-dd格式");
        }

        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE WORK_DATE BETWEEN TO_DATE(?, 'YYYY-MM-DD') AND TO_DATE(?, 'YYYY-MM-DD') " +
                "AND REPORTER_ID = ? " +
                "ORDER BY WORK_DATE, WORK_ID";

        ResultSet rs = excuteSelect(sql, startDate, endDate, reporterId);
        return resultSetToVoList(rs);
    }

    /**
     * 查询当前用户某月份的工作记录
     * @param reporterId 用户ID
     * @param yearMonth 年月字符串，格式：2025-12
     * @return 当前用户指定月份的工时VO列表
     */
    public static List<AIWorkHoursVo> selectByMonthAndUser(String reporterId, String yearMonth) throws SQLException, WTException {
        if (yearMonth == null || !yearMonth.matches("\\d{4}-\\d{2}")) {
            throw new IllegalArgumentException("年月格式不正确，应为yyyy-MM格式");
        }

        String startDate = yearMonth + "-01";
        String endDate = getMonthLastDay(yearMonth);

        return selectByDateRangeAndUser(reporterId, startDate, endDate);
    }

    // ========== 本周工时相关查询 ==========

    /**
     * 查询本周所有工时任务
     */
    public static List<AIWorkHoursVo> selectThisWeek() throws SQLException, WTException {
        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE, 'IW') = TRUNC(SYSDATE, 'IW') " +
                "ORDER BY WORK_DATE, PROJECT_ID, TASK_ID";

        ResultSet rs = excuteSelect(sql);
        return resultSetToVoList(rs);
    }




    /**
     * 查询指定周的工时任务
     */
    public static List<AIWorkHoursVo> selectWeekByDate(String dateStr) throws SQLException, WTException {
        if (!isValidDate(dateStr)) {
            throw new IllegalArgumentException("日期格式不正确，应为yyyy-MM-dd格式");
        }

        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE, 'IW') = TRUNC(TO_DATE(?, 'YYYY-MM-DD'), 'IW') " +
                "ORDER BY WORK_DATE, PROJECT_ID, TASK_ID";

        ResultSet rs = excuteSelect(sql, dateStr);
        return resultSetToVoList(rs);
    }

    /**
     * 查询今天的工作记录
     */
    public static List<AIWorkHoursVo> selectToday() throws SQLException, WTException {
        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE) = TRUNC(SYSDATE) " +
                "ORDER BY WORK_ID";

        ResultSet rs = excuteSelect(sql);
        return resultSetToVoList(rs);
    }

    /**
     * 查询指定日期的工作记录
     */
    public static List<AIWorkHoursVo> selectByDate(String dateStr) throws SQLException, WTException {
        if (!isValidDate(dateStr)) {
            throw new IllegalArgumentException("日期格式不正确，应为yyyy-MM-dd格式");
        }

        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE TRUNC(WORK_DATE) = TO_DATE(?, 'YYYY-MM-DD') " +
                "ORDER BY WORK_ID";

        ResultSet rs = excuteSelect(sql, dateStr);
        return resultSetToVoList(rs);
    }



    // ========== 通用查询 ==========

    /**
     * 按日期范围查询
     */
    public static List<AIWorkHoursVo> selectByDateRange(String startDate, String endDate) throws SQLException, WTException {
        if (startDate != null && !isValidDate(startDate)) {
            throw new IllegalArgumentException("开始日期格式不正确，应为yyyy-MM-dd格式");
        }
        if (endDate != null && !isValidDate(endDate)) {
            throw new IllegalArgumentException("结束日期格式不正确，应为yyyy-MM-dd格式");
        }

        String sql = "SELECT * FROM AI_WORK_HOURS " +
                "WHERE WORK_DATE BETWEEN TO_DATE(?, 'YYYY-MM-DD') AND TO_DATE(?, 'YYYY-MM-DD') " +
                "ORDER BY WORK_DATE, WORK_ID";

        ResultSet rs = excuteSelect(sql, startDate, endDate);
        return resultSetToVoList(rs);
    }

    /**
     * 按月份查询
     */
    public static List<AIWorkHoursVo> selectByMonth(String yearMonth) throws SQLException, WTException {
        if (yearMonth == null || !yearMonth.matches("\\d{4}-\\d{2}")) {
            throw new IllegalArgumentException("年月格式不正确，应为yyyy-MM格式");
        }

        String startDate = yearMonth + "-01";
        String endDate = getMonthLastDay(yearMonth);

        return selectByDateRange(startDate, endDate);
    }

    /**
     * 查询所有工时记录（分页）
     */
    public static List<AIWorkHoursVo> selectAll(int page, int pageSize) throws SQLException, WTException {
        int start = (page - 1) * pageSize + 1;
        int end = page * pageSize;

        String sql = "SELECT * FROM ( " +
                "SELECT t.*, ROWNUM rn FROM ( " +
                "SELECT * FROM AI_WORK_HOURS ORDER BY WORK_ID DESC " +
                ") t WHERE ROWNUM <= " + end +
                ") WHERE rn >= " + start;

        ResultSet rs = excuteSelect(sql);
        return resultSetToVoList(rs);
    }

    // ========== 统计查询 ==========



    // ========== 辅助方法 ==========

    /**
     * 验证日期格式
     */
    private static boolean isValidDate(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) {
            return false;
        }
        try {
            DATE_FORMATTER.setLenient(false);
            DATE_FORMATTER.parse(dateStr);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 获取月份的最后一天
     */
    private static String getMonthLastDay(String yearMonth) throws SQLException {
        String sql = "SELECT TO_CHAR(LAST_DAY(TO_DATE(?, 'YYYY-MM')), 'YYYY-MM-DD') AS LAST_DAY FROM DUAL";
        ResultSet rs = excuteSelect(sql, yearMonth);

        if (rs != null && rs.next()) {
            return rs.getString("LAST_DAY");
        }
        return yearMonth + "-31";
    }

    /**
     * 将ResultSet转换为VO列表
     */
    private static List<AIWorkHoursVo> resultSetToVoList(ResultSet rs) throws SQLException, WTException {
        List<AIWorkHoursVo> result = new ArrayList<>();

        if (rs != null) {
            while (rs.next()) {
                result.add(mapResultSetToAIWorkHoursVo(rs));
            }
        }
        return result;
    }

    /**
     * 将ResultSet映射为AIWorkHoursVo对象
     */
    private static AIWorkHoursVo mapResultSetToAIWorkHoursVo(ResultSet rs) throws SQLException, WTException {
        AIWorkHoursVo vo = new AIWorkHoursVo();

        vo.setWorkId(rs.getLong("WORK_ID"));
        vo.setProjectId(rs.getString("PROJECT_ID"));
//        vo.setProjectName(rs.getString("PROJECT_ID"));
        vo.setWorkType(rs.getString("WORK_TYPE"));
        vo.setTaskId(rs.getString("TASK_ID"));
        vo.setTaskName(rs.getString("TASK_NAME"));

        // 处理日期字段
        Date workDate = rs.getDate("WORK_DATE");
        if (workDate != null) {
            vo.setWorkDate(DATE_FORMATTER.format(workDate));
        }

        vo.setHours(rs.getBigDecimal("HOURS"));
        vo.setRemarks(rs.getString("REMARKS"));
        vo.setReporterId(rs.getString("REPORTER_ID"));
//        vo.setReporterName(rs.getString("REPORTER_ID"));

        // 触发器自动生成的时间字段
        Timestamp createTime = rs.getTimestamp("CREATE_TIME");
        if (createTime != null) {
            vo.setCreateTime(createTime.toString());
        }

        Timestamp updateTime = rs.getTimestamp("UPDATE_TIME");
        if (updateTime != null) {
            vo.setUpdateTime(updateTime.toString());
        }

        //设置vo填报人
        String reporterOid = vo.getReporterId();
        if (reporterOid != null) {
            WTUser wtUser = ToolUtil.oid2WTUser(reporterOid);
            String fullName = wtUser.getFullName();
            vo.setReporterName(fullName);
        }

        //设置项目名称
        String projectOid = vo.getProjectId();
        if (projectOid != null) {
            WTContainer wtContainer = ToolUtil.oid2Container(projectOid);
            vo.setProjectName(wtContainer.getName());
        }

        //设置任务名称 若是TaskOid是空说明是自由工时，取本身
        if (StringUtils.isNotBlank(vo.getTaskName())) {
            setTaskName(vo);
        }


        return vo;
    }


    public static void setTaskName(AIWorkHoursVo vo) throws WTException {
        String taskOid = vo.getTaskId();
        if (StringUtils.isEmpty(taskOid)) {
            return;
        }
        if (taskOid.contains("com.ptc.projectmanagement.assignment.ResourceAssignment")){
            System.out.println("ResourceAssignment："+taskOid);
            ResourceAssignment resourceAssignment = ToolUtil.oid2ResourceAssignment(taskOid);
            //RoleB是活动对象PlanActivity  RoleA是资源 PlanResource
            PlanActivity planActivity =(PlanActivity) resourceAssignment.getRoleBObject();
            vo.setTaskName(planActivity.getName());

        }else  if (taskOid.contains("wt.meeting.actionitem.DiscreteActionItem")){
            System.out.println("DiscreteActionItem："+taskOid);
            DiscreteActionItem discreteActionItem = ToolUtil.oid2DiscreteActionItem(taskOid);
            vo.setTaskName(discreteActionItem.getItemName());

        }else {
            return;
        }
    }



    /**
     * 获取最后插入的ID
     */
    private static Long getLastInsertId() throws SQLException {
        String sql = "SELECT SEQ_AI_WORK_HOURS_ID.CURRVAL FROM DUAL";
        ResultSet rs = excuteSelect(sql);

        if (rs != null && rs.next()) {
            return rs.getLong(1);
        }
        return null;
    }

    /**
     * 获取当前日期
     */
    public static String getCurrentDate() throws SQLException {
        String sql = "SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD') AS TODAY FROM DUAL";
        ResultSet rs = excuteSelect(sql);

        if (rs != null && rs.next()) {
            return rs.getString("TODAY");
        }
        return null;
    }

    // ========== 调用JDBC ==========

    private static ResultSet excuteSelect(String sql, String... params) {
        return CommonUtil.excuteSelect(sql, params);
    }

    private static int excuteUpdate(String sql, String... params) throws SQLException {
        return CommonUtil.excuteUpdate(sql, params);
    }











}
