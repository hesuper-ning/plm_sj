package ext.alphai.aistoneglobal.timemanagement.service;

import com.ptc.projectmanagement.assignment.ResourceAssignment;

import com.ptc.projectmanagement.plan.PlanActivity;
import ext.alphai.aistoneglobal.timemanagement.Constant;
import ext.alphai.aistoneglobal.timemanagement.dao.TimeManagementDAO;
import ext.alphai.aistoneglobal.timemanagement.util.ToolUtil;
import ext.alphai.aistoneglobal.timemanagement.vo.AIWorkHoursVo;
import ext.alphai.aistoneglobal.timemanagement.vo.ResponseVo;

import org.apache.commons.lang3.StringUtils;
import wt.inf.container.WTContainer;
import wt.meeting.actionitem.DiscreteActionItem;

import wt.org.WTUser;
import wt.pom.Transaction;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.List;

public class TimeManagementService {


    // 日期格式
    private static final String DATE_PATTERN_FRONTEND = "yyyy-MM-dd";
    private static final String DATE_PATTERN_FRONTEND_HM = "yyyy/MM/dd HH:mm";
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat(DATE_PATTERN_FRONTEND);
    private static final SimpleDateFormat DATE_FORMATTER_HM = new SimpleDateFormat(DATE_PATTERN_FRONTEND_HM);


    public ResponseVo waitWriteTask(WTUser user) throws WTException {

        //查询当前用户未完成的待办和分配资源
        ResponseVo responseVo = new ResponseVo();


        //当前用户 未完成的资源分配
        List<ResourceAssignment> resourceAssignments = TimeManagementDAO.findResourceAssignments(user);
        //当前用户 未完成的措施项
        List<DiscreteActionItem> findDiscreteActionItems = TimeManagementDAO.findDiscreteActionItems(user);

        List<AIWorkHoursVo> aiWorkHoursVos = resourceAssignments2AIWorkHours(resourceAssignments, findDiscreteActionItems);

        if (!aiWorkHoursVos.isEmpty()) {
            return responseVo.success(aiWorkHoursVos);
        } else {
            return responseVo.error(201, "未填报本周工时记录");
        }


    }


    /**
     * 当前用户系统任务转换为VO
     *
     * @param resourceAssignments
     * @param findDiscreteActionItems
     * @return
     * @throws WTException
     */
    public List<AIWorkHoursVo> resourceAssignments2AIWorkHours(List<ResourceAssignment> resourceAssignments, List<DiscreteActionItem> findDiscreteActionItems) throws WTException {
        List<AIWorkHoursVo> aiWorkHoursVos = new ArrayList<>();
        for (ResourceAssignment resourceAssignment : resourceAssignments) {
            AIWorkHoursVo vo = new AIWorkHoursVo();
            WTContainer container = resourceAssignment.getContainer();
            vo.setProjectId(Constant.OR_COLON + container.toString());
            vo.setProjectName(container.getName());
            vo.setWorkType(Constant.RESOURCE_ASSIGNMENT);
            String raOid = Constant.OR_COLON + (resourceAssignment.toString().split(",")[1]).trim();//资源对象toString=数据库设计(He Ning), com.ptc.projectmanagement.assignment.ResourceAssignment:225200
            vo.setTaskId(raOid);
            PlanActivity planActivity = (PlanActivity) resourceAssignment.getRoleBObject();
            vo.setTaskName(planActivity.getName());

            // 处理日期字段
//            Date workDate = rs.getDate("WORK_DATE");
//            if (workDate != null) {
//                vo.setWorkDate(DATE_FORMATTER.format(workDate));
//            }

            String hours = resourceAssignment.getTotalEffort().toString();


            vo.setHours(BigDecimal.valueOf(Double.parseDouble(hours)));
            //默认为活动的描述
            vo.setRemarks(planActivity.getDescription());
            //预计完成时间
            Timestamp finishDate = resourceAssignment.getFinishDate();
            if (finishDate != null) {
                vo.setFinishTime(DATE_FORMATTER_HM.format(finishDate));
            }
//            String s = ToolUtil.user2Oid(user);
//            vo.setReporterId(rs.getString("REPORTER_ID"));
//        vo.setReporterName(rs.getString("REPORTER_ID"));
            aiWorkHoursVos.add(vo);
        }

        for (DiscreteActionItem findDiscreteActionItem : findDiscreteActionItems) {
            AIWorkHoursVo vo = new AIWorkHoursVo();
            WTContainer container = findDiscreteActionItem.getContainer();
            vo.setProjectId(Constant.OR_COLON + container.toString());
            vo.setProjectName(container.getName());
            vo.setWorkType(Constant.DISCRETE_ACTION_ITEM);
            String fdaOid = Constant.OR_COLON + findDiscreteActionItem.toString().trim();//资源对象toString=数据库设计(He Ning), com.ptc.projectmanagement.assignment.ResourceAssignment:225200
            vo.setTaskId(fdaOid);
            vo.setTaskName(findDiscreteActionItem.getItemName());

            // 处理日期字段
//            Date workDate = rs.getDate("WORK_DATE");
//            if (workDate != null) {
//                vo.setWorkDate(DATE_FORMATTER.format(workDate));
//            }

            //工时数暂时为空
            vo.setHours(null);
            // 填报工时填写
            String itemDescription = findDiscreteActionItem.getItemDescription();
            vo.setRemarks(itemDescription);
            //预计完成时间
            Timestamp itemDueDate = findDiscreteActionItem.getItemDueDate();
            if (itemDueDate != null) {
                vo.setFinishTime(DATE_FORMATTER.format(itemDueDate));
            }
//            String s = ToolUtil.user2Oid(user);
//            vo.setReporterId(rs.getString("REPORTER_ID"));
//        vo.setReporterName(rs.getString("REPORTER_ID"));
            aiWorkHoursVos.add(vo);
        }

        return aiWorkHoursVos;
    }

    public ResponseVo getWeekRecord(WTUser user) throws WTException, SQLException {
        ResponseVo responseVo = new ResponseVo();

        List<AIWorkHoursVo> aiWorkHoursVoList = new ArrayList<>();
        //获取了所有的本周任务
        List<AIWorkHoursVo> aiWorkHoursVos = TimeManagementDAO.selectThisWeekByUser(ToolUtil.user2Oid(user));
        if (!aiWorkHoursVos.isEmpty()) {
            return responseVo.success(aiWorkHoursVos);
        } else {
            return responseVo.error(201, "未填报本周工时记录");
        }

    }


    public ResponseVo insertWorkHours(AIWorkHoursVo aiWorkHoursVo) throws WTException, SQLException {
        ResponseVo responseVo = new ResponseVo();
        //设置填报人
        WTUser principal = (WTUser) SessionHelper.getPrincipal();
        String userOid = ToolUtil.user2Oid(principal);
        aiWorkHoursVo.setReporterId(userOid);

        //设置任务类型
        setWorkType(aiWorkHoursVo);

        int i = TimeManagementDAO.insertWorkHours(aiWorkHoursVo);
        if (i > 0) {
            return responseVo.success(i);
        } else {
            return responseVo.error(201, "填报本周工时失败");
        }


    }


    public ResponseVo updateWorkHours(AIWorkHoursVo aiWorkHoursVo) throws WTException, SQLException {
        ResponseVo responseVo = new ResponseVo();
        //设置填报人
        WTUser principal = (WTUser) SessionHelper.getPrincipal();
        String userOid = ToolUtil.user2Oid(principal);
        aiWorkHoursVo.setReporterId(userOid);

        //设置任务类型
//        setWorkType(aiWorkHoursVo);

        int i = TimeManagementDAO.updateWorkHours(aiWorkHoursVo);
        if (i > 0) {
            return responseVo.success(i);
        } else {
            return responseVo.error(201, "填报本周工时失败");
        }


    }


    //周记录表类型
    public void setWorkType(AIWorkHoursVo aiWorkHoursVo) {
        String taskOid = aiWorkHoursVo.getTaskId();

        if (StringUtils.isEmpty(taskOid)) {
            aiWorkHoursVo.setWorkType(Constant.FREE_RESOURCE_REGISTRATION);
        } else {
            aiWorkHoursVo.setWorkType(Constant.TASK_REPORTING);
        }
//        else if (taskOid.contains("com.ptc.projectmanagement.assignment.ResourceAssignment")) {
//            aiWorkHoursVo.setWorkType(Constant.RESOURCE_ASSIGNMENT);
//
//        } else if (taskOid.contains("wt.meeting.actionitem.DiscreteActionItem")) {
//            aiWorkHoursVo.setWorkType(Constant.DISCRETE_ACTION_ITEM);
//
//        }
    }


    /**
     * 批量删除
     *
     * @param workIds
     * @return
     */
    public void deleteWorkHours(List<Long> workIds) {
        Transaction trx = null;
        try {
            trx = new Transaction();
            trx.start();
            for (Long id : workIds) {
                TimeManagementDAO.deleteById(id);
            }

            trx.commit();
            trx = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (trx != null) {
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }

    }


    /**
     * 批量删除
     *
     * @param workIds
     * @return
     */
    public ResponseVo deleteWorkHour(List<Long> workIds) throws SQLException {
        ResponseVo responseVo = new ResponseVo();
        int i = TimeManagementDAO.deleteById(workIds.get(0));
        if (i > 0) {
            return responseVo.success(i);
        } else {
            return responseVo.error(201, "删除失败!");
        }

    }


}
