package ext.alphai.aistoneglobal.timemanagement;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.timemanagement.TimeManagementRB_zh_CN")
public class TimeManagementRB_zh_CN extends WTListResourceBundle {

    @RBEntry("工时管理")
    public static final String E_T_M_TITLE = "timeManager.cusNav.title";

    @RBEntry("工时管理")
    public static final String E_T_M_TOOLTIP = "timeManager.cusNav.tooltip";

    @RBEntry("工时管理")
    public static final String E_T_M_DES = "timeManager.cusNav.description";

    @RBEntry("navigator_home.png")
    public static final String E_T_M_ICON = "timeManager.cusNav.icon";



    @RBEntry("工时管理")
    public static final String I_T_M_TOOLTIP = "timeManager.manager.tooltip";

    @RBEntry("工时管理")
    public static final String I_T_M_DES = "timeManager.manager.description";


}
