package ext.alphai.aistoneglobal.timemanagement.controller;



import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.aistoneglobal.timemanagement.service.TimeManagementService;
import ext.alphai.aistoneglobal.timemanagement.vo.AIWorkHoursVo;
import ext.alphai.aistoneglobal.timemanagement.vo.ResponseVo;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import wt.org.WTUser;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("/alphai/workTime")
public class TimeManagementController {
    public static ObjectMapper objectMapper = new ObjectMapper();
    public static TimeManagementService timeManagementService = new TimeManagementService();



//    @RequestMapping(value = "/getWaitWork", method = RequestMethod.POST)
//    public static void getWgetWaitWorkait(HttpServletRequest request,
//                                     HttpServletResponse response) throws WTException, IOException {
//        request.setCharacterEncoding("UTF-8");
//        WTUser principal = (WTUser) SessionHelper.getPrincipal();
//        ResponseVo vo = new ResponseVo();
//        SessionServerHelper.manager.setAccessEnforced(false);
//        try {
//            vo = timeManagementService.waitWriteTask(principal);
//        } catch (WTException e) {
//            vo = vo.error(500, e.getMessage());
//        }   catch (SQLException e) {
//            throw new RuntimeException(e);
//        } finally {
//            SessionServerHelper.manager.setAccessEnforced(true);
//        }
//        String respJson = objectMapper.writeValueAsString(vo);
//        outResponse(response,respJson);
//
//    }

    /**
     * 工时记录表--一周记录
     * @param request
     * @param response
     * @throws WTException
     * @throws IOException
     */
    @RequestMapping(value = "/getWorkRecord", method = RequestMethod.GET)
    public static void getWorkRecord(HttpServletRequest request,
                                   HttpServletResponse response) throws WTException, IOException {
        request.setCharacterEncoding("UTF-8");
        WTUser principal = (WTUser) SessionHelper.getPrincipal();
        ResponseVo vo = new ResponseVo();
        SessionServerHelper.manager.setAccessEnforced(false);
        try {
            vo = timeManagementService.getWeekRecord(principal);
        } catch (WTException e) {
            vo = vo.error(500, e.getMessage());
        }   catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);

    }

    /**
     * 系统任务
     * @param request
     * @param response
     * @throws WTException
     * @throws IOException
     */
    @RequestMapping(value = "/getSystemTask", method = RequestMethod.GET)
    public static void getSystemTask(HttpServletRequest request,
                                     HttpServletResponse response) throws WTException, IOException {
        request.setCharacterEncoding("UTF-8");
        WTUser principal = (WTUser) SessionHelper.getPrincipal();
        ResponseVo vo = new ResponseVo();
        SessionServerHelper.manager.setAccessEnforced(false);
        try {
            vo = timeManagementService.waitWriteTask(principal);
        } catch (WTException e) {
            vo = vo.error(500, e.getMessage());
        }     finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }
        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);

    }


    /**
     * 添加工时
     * @param json
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/insertWorkRecord", method = RequestMethod.POST)
    public static void insertWorkRecord(@RequestBody String json ,  HttpServletRequest request,
                                     HttpServletResponse response) throws  IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        SessionServerHelper.manager.setAccessEnforced(false);

        ResponseVo vo = new ResponseVo();
        try {
            AIWorkHoursVo aiWorkHoursVo = objectMapper.readValue(json, new TypeReference<AIWorkHoursVo>() {});

            vo = timeManagementService.insertWorkHours(aiWorkHoursVo);
        } catch (Exception e) {
            vo =vo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }



        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);

    }


    /**
     * 删除工时
     * @param json
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public static void deleteWorkRecord(@RequestBody String json ,  HttpServletRequest request,
                                        HttpServletResponse response) throws  IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        List<Long> drawings = objectMapper.readValue(json, new TypeReference<List<Long>>(){});
        SessionServerHelper.manager.setAccessEnforced(false);
        ResponseVo vo = new ResponseVo();
        try {
            vo = timeManagementService.deleteWorkHour(drawings);
        } catch (Exception e) {
            vo =vo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }



        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);

    }

    /**
     * 修改工时
     * @param json
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/updateWorkRecord", method = RequestMethod.POST)
    public static void updateWorkRecord(@RequestBody String json ,  HttpServletRequest request,
                                        HttpServletResponse response) throws  IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        SessionServerHelper.manager.setAccessEnforced(false);

        ResponseVo vo = new ResponseVo();
        try {
            AIWorkHoursVo aiWorkHoursVo = objectMapper.readValue(json, new TypeReference<AIWorkHoursVo>() {});
            vo = timeManagementService.updateWorkHours(aiWorkHoursVo);
        } catch (Exception e) {
            vo =vo.error(500, e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(true);
        }



        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);

    }



    public static void outResponse(HttpServletResponse response, String json) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }


}