package ext.alphai.aistoneglobal.timemanagement.util;

import com.ptc.projectmanagement.assignment.ResourceAssignment;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.inf.container.WTContainer;
import wt.meeting.actionitem.DiscreteActionItem;
import wt.org.WTUser;
import wt.util.WTException;

public class ToolUtil {

    public static ReferenceFactory rf = new ReferenceFactory();

    public static String resourceAssignment2Oid(ResourceAssignment resourceAssignment) throws WTException {
        long id = PersistenceHelper.getObjectIdentifier(resourceAssignment).getId();
        return "OR:com.ptc.projectmanagement.assignment.ResourceAssignment:" + id;
    }

    public static String DiscreteActionItem2Oid(DiscreteActionItem discreteActionItem) throws WTException {
        long id = PersistenceHelper.getObjectIdentifier(discreteActionItem).getId();
        return "OR:wt.meeting.actionitem.DiscreteActionItem:" + id;
    }

    public static String user2Oid(WTUser user) throws WTException {
        long id = PersistenceHelper.getObjectIdentifier(user).getId();
        return "OR:wt.org.WTUser:" + id;
    }


    public static WTContainer oid2Container(String oid) throws WTException {
        WTReference reference = rf.getReference(oid);
        return (WTContainer)reference.getObject();
    }

    public static WTUser oid2WTUser(String oid) throws WTException {
        WTReference reference = rf.getReference(oid);
        return (WTUser) reference.getObject();
    }

    public static DiscreteActionItem oid2DiscreteActionItem(String oid) throws WTException {
        WTReference reference = rf.getReference(oid);
        return (DiscreteActionItem) reference.getObject();
    }

    public static ResourceAssignment oid2ResourceAssignment(String oid) throws WTException {
        WTReference reference = rf.getReference(oid);
        return (ResourceAssignment) reference.getObject();
    }


}
