package ext.alphai.aistoneglobal.timemanagement.util;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalField;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 周计算工具类
 */
public class WeekCalculator {

    // 中国习惯：周一为一周的开始，第一周至少4天
    private static final WeekFields CHINESE_WEEK_FIELDS = WeekFields.of(Locale.CHINA);

    /**
     * 获取指定日期的年份
     */
    public static int getYear(LocalDate date) {
        return date != null ? date.getYear() : 0;
    }

    /**
     * 获取指定日期的一年中的第几周
     */
    public static int getWeekOfYear(LocalDate date) {
        if (date == null) return 0;
        TemporalField weekField = CHINESE_WEEK_FIELDS.weekOfWeekBasedYear();
        return date.get(weekField);
    }

    /**
     * 获取指定日期的基于周的年份
     */
    public static int getWeekBasedYear(LocalDate date) {
        if (date == null) return 0;
        TemporalField weekBasedYearField = CHINESE_WEEK_FIELDS.weekBasedYear();
        return date.get(weekBasedYearField);
    }

    /**
     * 获取周显示字符串
     */
    public static String getWeekDisplay(LocalDate date) {
        if (date == null) return "";
        return String.format("%d年第%d周", getWeekBasedYear(date), getWeekOfYear(date));
    }

    /**
     * 获取指定周的周一日期
     */
    public static LocalDate getWeekStartDate(int year, int week) {
        // 获取该年第一天的周信息
        LocalDate firstDayOfYear = LocalDate.of(year, 1, 1);
        int firstWeek = getWeekOfYear(firstDayOfYear);

        // 计算目标周的周一
        LocalDate weekStart = firstDayOfYear.plusWeeks(week - firstWeek);

        // 调整到周一
        int dayOfWeek = weekStart.getDayOfWeek().getValue(); // 1=周一
        if (dayOfWeek > 1) {
            weekStart = weekStart.minusDays(dayOfWeek - 1);
        }

        return weekStart;
    }

    /**
     * 获取指定周的周日日期
     */
    public static LocalDate getWeekEndDate(int year, int week) {
        LocalDate weekStart = getWeekStartDate(year, week);
        return weekStart.plusDays(6);
    }

    /**
     * 获取指定日期所在周的所有日期
     */
    public static List<LocalDate> getWeekDates(LocalDate date) {
        List<LocalDate> weekDates = new ArrayList<>();
        if (date == null) return weekDates;

        LocalDate monday = getMondayOfWeek(date);
        for (int i = 0; i < 7; i++) {
            weekDates.add(monday.plusDays(i));
        }
        return weekDates;
    }

    /**
     * 获取指定日期所在周的周一
     */
    public static LocalDate getMondayOfWeek(LocalDate date) {
        if (date == null) return null;
        int dayOfWeek = date.getDayOfWeek().getValue(); // 1=周一
        return date.minusDays(dayOfWeek - 1);
    }

    /**
     * 获取指定日期所在周的周日
     */
    public static LocalDate getSundayOfWeek(LocalDate date) {
        LocalDate monday = getMondayOfWeek(date);
        return monday != null ? monday.plusDays(6) : null;
    }

    /**
     * 判断两个日期是否在同一周
     */
    public static boolean isSameWeek(LocalDate date1, LocalDate date2) {
        if (date1 == null || date2 == null) return false;
        return getWeekBasedYear(date1) == getWeekBasedYear(date2)
                && getWeekOfYear(date1) == getWeekOfYear(date2);
    }

    /**
     * 获取一年的总周数
     */
    public static int getTotalWeeksOfYear(int year) {
        LocalDate lastDayOfYear = LocalDate.of(year, 12, 31);
        int lastWeek = getWeekOfYear(lastDayOfYear);

        // 如果12月31日是下一年的第一周，需要调整
        if (getWeekBasedYear(lastDayOfYear) > year) {
            LocalDate prevWeek = lastDayOfYear.minusWeeks(1);
            return getWeekOfYear(prevWeek);
        }

        return lastWeek;
    }

    /**
     * 生成周次范围字符串
     */
    public static String getWeekRangeDisplay(int year, int week) {
        LocalDate start = getWeekStartDate(year, week);
        LocalDate end = getWeekEndDate(year, week);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM月dd日");
        return String.format("%d年第%d周 (%s - %s)",
                year, week,
                start.format(formatter),
                end.format(formatter));
    }
}