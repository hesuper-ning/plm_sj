package ext.alphai.aistoneglobal.timemanagement;

public class Constant {

    // 使用更符合Java命名规范的常量名称（全大写+下划线）
    public static final String RESOURCE_ASSIGNMENT = "分配";
    public static final String DISCRETE_ACTION_ITEM = "待办项";


    // 周工时记录类型
    public static final String FREE_RESOURCE_REGISTRATION = "自由登记";
    public static final String TASK_REPORTING = "任务填报";

    //状态
    //已解决
    public static final String RESOLVED = "RESOLVED";
    //完工率---100.0==完成
    public static final double COMPLETE = 100.0;

    public static final String OR = "OR";

    public static final String COLON = ":";

    public static final String OR_COLON = OR+COLON;





}
