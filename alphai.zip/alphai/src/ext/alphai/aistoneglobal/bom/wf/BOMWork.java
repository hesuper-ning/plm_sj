package ext.alphai.aistoneglobal.bom.wf;

import com.fasterxml.jackson.core.JsonProcessingException;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.service.CreateOrUpdateBOMSer;
import ext.alphai.aistoneglobal.sap.utils.WorkflowUtil;
import ext.alphai.aistoneglobal.sap.vo.BOMItem;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.WTObject;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.util.WTException;

import java.util.List;
import java.util.Map;


public class BOMWork {

    public static String BOMValidation(WTObject pbo,String targetFactory) throws WTException, JsonProcessingException {
        StringBuilder result = new StringBuilder();
        List<WTPart> wtParts = null;
        if (pbo instanceof PromotionNotice) {
            PromotionNotice promotionNotice = (PromotionNotice) pbo;

            wtParts = WorkflowUtil.getTargerObjectByPromotionNotices(promotionNotice);

        } else if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
            wtParts = WorkflowUtil.getTargetObjectByECA(eca);
        } else if (pbo instanceof WTChangeOrder2) {
            WTChangeOrder2 ecn = (WTChangeOrder2) pbo;
            wtParts = WorkflowUtil.getTargetObjectByECN(ecn);
        }


        for (WTPart wtPart : wtParts) {
            Map<WTPart, List<BOMItem>> afterWTPartListMap = CreateOrUpdateBOMSer.bomConvertToBomItem(wtPart, targetFactory, Constant.WORKFLOW);
            if (!CreateOrUpdateBOMSer.checkBOMLineNumber(afterWTPartListMap)) {
                if (result.length() > 0) {
                    result.append(", ");
                }
                result.append(wtPart.getNumber());
            }

        }
        // 如果存在空行号，加上错误提示信息
        if (result.length() > 0) {
            return "以下BOM存在空行号: " + result.toString();
        }

        return "success";
    }
}
