package ext.alphai.aistoneglobal.bom;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.bom.BomRB")
public class BomRB extends WTListResourceBundle {
    @RBEntry("AutoSetLineNumber")
    public static final String AUTO_SETlINEnUMBER_1 = "CusBOM.autoSetLineNumber.title";

    @RBEntry("AutoSetLineNumber")
    public static final String AUTO_SETlINEnUMBER_2 = "CusBOM.autoSetLineNumber.tooltip";

    @RBEntry("AutoSetLineNumber")
    public static final String AUTO_SETlINEnUMBER_3 = "CusBOM.autoSetLineNumber.description";

    @RBEntry("chk_uniqueness.gif")
    public static final String AUTO_SETlINEnUMBER_4 = "CusBOM.autoSetLineNumber.icon";

    @RBEntry("Setting Line Number OK!")
    public static final String AUTO_SETlINEnUMBER_5 = "AUTO_SETlINEnUMBER_5";

    @RBEntry("Setting Line Number ERROE，Please contact the administrator!")
    public static final String AUTO_SETlINEnUMBER_6 = "AUTO_SETlINEnUMBER_6";

    @RBEntry("BOM Validate")
    public static final String VAL_BOM_TITLE = "CusBOM.valBom.title";

    @RBEntry("BOM Validate")
    public static final String VAL_BOM_TOOLTIP= "CusBOM.valBom.tooltip";

    @RBEntry("BOM Validate")
    public static final String VAL_BOM_DES = "CusBOM.valBom.description";

    @RBEntry("校验完成，BOM未存在空行号料")
    public static final String VAL_BOM_LINE_NUMBER_SUCCESS = "VAL_BOM_LINE_NUMBER_SUCCESS";

    @RBEntry("ERROR, Please contact the administrator!")
    public static final String VAL_BOM_ERROR = "VAL_BOM_ERROR";



//    PSB设置的按钮名称
    @RBEntry("BOM")
    public static final String AUTO_SET_LINE_PSB_NUMBER = "psb.bomGroupGWT.description";

    @RBEntry("AutoSetLineNumber")
    public static final String AUTO_SET_LINE_NUMBER_PSB_DES = "psb.autoSetLineNumber.description";

    @RBEntry("add16x16.gif")
    public static final String AUTO_SET_LINE_NUMBER_PSB_ICON = "psb.autoSetLineNumber.icon";

    @RBEntry("BOM Validate")
    public static final String VAL_BOM_PSB_DES = "psb.valBom.description";

    @RBEntry("add16x16.gif")
    public static final String VAL_BOM_PSB_ICON = "psb.valBom.icon";


}
