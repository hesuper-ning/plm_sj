package ext.alphai.aistoneglobal.bom.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.bom.BomRB;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.utils.IBAUtil;
import ext.alphai.aistoneglobal.sap.utils.PartUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;

import java.util.Iterator;
import java.util.List;


public class ValidationBomLineNumber extends DefaultObjectFormProcessor {


    @Override
    public FormResult doOperation(NmCommandBean nmcommandbean, List<ObjectBean> paramList) throws WTException {
        FormResult result = super.doOperation(nmcommandbean, paramList);

        StringBuilder bomLineNumberMsg = new StringBuilder();

        boolean bool = SessionServerHelper.manager.isAccessEnforced();
        Iterator iterator1 = paramList.iterator();
        try {
            SessionServerHelper.manager.setAccessEnforced(false);
            String oid = nmcommandbean.getElemAddress();
            oid = oid.substring(0, oid.length() - 2);
            if (StringUtils.isNotEmpty(oid)) {
                Object obj = getObjectByOid(oid);
                if (obj != null) {
                    if (obj instanceof WTPart) {
                        WTPart wtPart = (WTPart) obj;
                        bomLineNumberMsg =  lineNumberIsEmpty(wtPart);
                    }
                }
            }

            // 检查是否有行号为空的情况
            if (bomLineNumberMsg.length() > 0) {
//                throw new WTException("以下物料存在空行号: " + bomLineNumberMsg.toString());

                result.setStatus(FormProcessingStatus.FAILURE);
                result.setSkipPageRefresh(true);
                String errorMsg = "以下物料存在空行号: " + bomLineNumberMsg.toString();
                result.addFeedbackMessage(
                        new FeedbackMessage(FeedbackType.FAILURE, null, null, null, new String[]{errorMsg}));
                return result;
            }

        } catch (Exception e) {
            result.setStatus(FormProcessingStatus.FAILURE);
            result.setSkipPageRefresh(true);
            String errorMsg = WTMessage.getLocalizedMessage(BomRB.class.getName(),
                    BomRB.VAL_BOM_ERROR, null, SessionHelper.getLocale());
            result.addFeedbackMessage(
                    new FeedbackMessage(FeedbackType.FAILURE, null, null, null, new String[]{errorMsg}));
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(bool);
        }

        // 如果没有错误，返回成功消息
        result.setStatus(FormProcessingStatus.SUCCESS);
        result.setSkipPageRefresh(true);
        String successMsg = WTMessage.getLocalizedMessage(BomRB.class.getName(),
                BomRB.VAL_BOM_LINE_NUMBER_SUCCESS, null, SessionHelper.getLocale());
        result.addFeedbackMessage(
                new FeedbackMessage(FeedbackType.SUCCESS, null, null, null, new String[]{successMsg}));

        return result;
    }

    /**
     * 通过oid获取对象
     *
     * @version: 2018年8月7日
     * @author Houjs
     */
    public static Object getObjectByOid(String oid) throws WTException {
        Object obj = null;
        ReferenceFactory rf = new ReferenceFactory();
        try {
            obj = rf.getReference(oid).getObject();
        } catch (WTRuntimeException e) {
            System.out.println(e.getLocalizedMessage()+ e);
        } catch (WTException e) {
            System.out.println(e.getLocalizedMessage()+ e);
        }
        return obj;
    }


    public static StringBuilder lineNumberIsEmpty(WTPart wtPart) throws WTException {
        StringBuilder result = new StringBuilder();
        List<WTPartUsageLink> partUsageLinks = PartUtil.getSortLinksByPart(wtPart);
        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            IBAUtil usageLinkIBA = new IBAUtil(partUsageLink);
            String primaryPartLineNumberStr = usageLinkIBA.getIBAValue(Constant.AI_LineNumber);
            WTPartMaster wtPartMaster = partUsageLink.getUses();
            if (StringUtils.isBlank(primaryPartLineNumberStr) ) {
                if (result.length() > 0) {
                    result.append(", ");
                }
                result.append(wtPartMaster.getNumber());
            }

        }
        return result;
    }
}