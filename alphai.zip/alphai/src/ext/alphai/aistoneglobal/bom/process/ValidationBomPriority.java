package ext.alphai.aistoneglobal.bom.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.bom.BomRB;
import ext.alphai.aistoneglobal.sap.Constant;
import ext.alphai.aistoneglobal.sap.utils.IBAUtil;
import ext.alphai.aistoneglobal.sap.utils.PartUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;

import java.util.*;


public class ValidationBomPriority extends DefaultObjectFormProcessor {

    @Override
    public FormResult doOperation(NmCommandBean nmcommandbean, List<ObjectBean> paramList) throws WTException {
        FormResult result = super.doOperation(nmcommandbean, paramList);

        boolean bool = SessionServerHelper.manager.isAccessEnforced();
        String bomNumber = "";
        String bomVersion = "";

        try {
            SessionServerHelper.manager.setAccessEnforced(false);

            String oid = nmcommandbean.getElemAddress();
            oid = oid.substring(0, oid.length() - 2);

            if (StringUtils.isNotEmpty(oid)) {
                Object obj = getObjectByOid(oid);
                if (obj instanceof WTPart) {
                    WTPart wtPart = (WTPart) obj;
                    bomNumber = wtPart.getNumber();
                    bomVersion = wtPart.getVersionIdentifier().getValue();

                    // 校验当前BOM的替代料优先级
                    String errorMsg = validateBomPriority(wtPart);

                    // 检查是否有优先级为空或重复的情况
                    if (StringUtils.isNotBlank(errorMsg)) {
                        result.setStatus(FormProcessingStatus.FAILURE);
                        result.setSkipPageRefresh(true);

                        // 构建详细的错误信息
                        String errorDetail = String.format("BOM %s(%s) 校验失败：%s",
                                bomNumber, bomVersion, errorMsg);

                        result.addFeedbackMessage(
                                new FeedbackMessage(FeedbackType.FAILURE, null, null, null, new String[]{errorDetail}));
                        return result;
                    }
                }
            }

        } catch (Exception e) {
            result.setStatus(FormProcessingStatus.FAILURE);
            result.setSkipPageRefresh(true);
            String errorMsg = WTMessage.getLocalizedMessage(BomRB.class.getName(),
                    BomRB.VAL_BOM_ERROR, null, SessionHelper.getLocale());
            result.addFeedbackMessage(
                    new FeedbackMessage(FeedbackType.FAILURE, null, null, null, new String[]{errorMsg}));
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(bool);
        }

        // 如果没有错误，返回成功消息
        result.setStatus(FormProcessingStatus.SUCCESS);
        result.setSkipPageRefresh(true);

        String successMsg = String.format("BOM %s(%s) 校验通过，所有替代料优先级已设置",
                bomNumber, bomVersion);

        result.addFeedbackMessage(
                new FeedbackMessage(FeedbackType.SUCCESS, null, null, null, new String[]{successMsg}));

        return result;
    }

    /**
     * 校验BOM中所有主料的替代料优先级（空值和重复值）
     * @param wtPart 顶层BOM
     * @return 存在问题的物料信息
     * @throws WTException
     */
    public static String validateBomPriority(WTPart wtPart) throws WTException {
        StringBuilder result = new StringBuilder();

        // 用于去重，避免同一个物料（相同安装面）重复显示
        Set<String> processedParts = new HashSet<>();

        List<WTPartUsageLink> partUsageLinks = PartUtil.getSortLinksByPart(wtPart);

        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            WTPartMaster wtPartMaster = partUsageLink.getUses();
            IBAUtil usageLinkIBA = new IBAUtil(partUsageLink);
            String placementSide = usageLinkIBA.getIBAValue(Constant.AI_Placement_Side);

            // 生成物料唯一标识
            String partKey = buildPartKey(wtPartMaster.getNumber(), placementSide);

            // 如果已经处理过，跳过
            if (processedParts.contains(partKey)) {
                continue;
            }
            processedParts.add(partKey);

            List<WTPartSubstituteLink> partSubstituteLinks = PartUtil.getWTPartSubstituteLinks(partUsageLink);

            // 如果只有0或1个替代料，只需要检查空优先级
            if (partSubstituteLinks.size() <= 1) {
                if (partSubstituteLinks.size() == 1) {
                    IBAUtil partSubstituteLinkIBA = new IBAUtil(partSubstituteLinks.get(0));
                    String priority = partSubstituteLinkIBA.getIBAValue(Constant.AI_Priority);

                    if (StringUtils.isBlank(priority)) {
                        if (result.length() > 0) {
                            result.append("; ");
                        }
                        String partInfo = buildPartInfo(wtPartMaster.getNumber(), placementSide);
                        result.append(partInfo).append("【存在空优先级】");
                    }
                }
                continue;
            }

            // 有多个替代料，需要检查空优先级和重复优先级
            Set<String> prioritySet = new HashSet<>();
            List<String> emptyPriorityList = new ArrayList<>();
            Map<String, List<String>> priorityToSubstitutesMap = new HashMap<>();

            for (WTPartSubstituteLink partSubstituteLink : partSubstituteLinks) {
                IBAUtil partSubstituteLinkIBA = new IBAUtil(partSubstituteLink);
                String priority = partSubstituteLinkIBA.getIBAValue(Constant.AI_Priority);

                // 获取替代料编号用于显示
                WTPartMaster substituteMaster = partSubstituteLink.getSubstitutes();
                String substituteNumber = substituteMaster != null ? substituteMaster.getNumber() : "未知";

                if (StringUtils.isBlank(priority)) {
                    emptyPriorityList.add(substituteNumber);
                } else {
                    if (!priorityToSubstitutesMap.containsKey(priority)) {
                        priorityToSubstitutesMap.put(priority, new ArrayList<>());
                    }
                    priorityToSubstitutesMap.get(priority).add(substituteNumber);
                    prioritySet.add(priority);
                }
            }

            // 检查是否有问题
            boolean hasIssue = false;
            List<String> issueList = new ArrayList<>();

            // 检查空优先级
            if (!emptyPriorityList.isEmpty()) {
                hasIssue = true;
                issueList.add("空优先级(" + String.join(",", emptyPriorityList) + ")");
            }

            // 检查重复优先级
            List<String> duplicatePriorities = new ArrayList<>();
            for (Map.Entry<String, List<String>> entry : priorityToSubstitutesMap.entrySet()) {
                if (entry.getValue().size() > 1) {
                    duplicatePriorities.add(entry.getKey() + "(" + String.join(",", entry.getValue()) + ")");
                }
            }
            if (!duplicatePriorities.isEmpty()) {
                hasIssue = true;
                issueList.add("重复优先级:" + String.join(",", duplicatePriorities));
            }

            // 如果有问题，记录主料信息
            if (hasIssue) {
                if (result.length() > 0) {
                    result.append("; ");
                }

                String partInfo = buildPartInfo(wtPartMaster.getNumber(), placementSide);
                result.append(partInfo).append("【").append(String.join("; ", issueList)).append("】");
            }
        }
        return result.toString();
    }

    /**
     * 构建物料唯一标识（用于去重）
     */
    private static String buildPartKey(String partNumber, String placementSide) {
        if (StringUtils.isBlank(placementSide)) {
            return partNumber;
        } else {
            return partNumber + "|" + placementSide;
        }
    }

    /**
     * 构建物料显示信息
     */
    private static String buildPartInfo(String partNumber, String placementSide) {
        if (StringUtils.isBlank(placementSide)) {
            return partNumber;
        } else {
            return partNumber + "(安装面:" + placementSide + ")";
        }
    }

    /**
     * 通过oid获取对象
     */
    public static Object getObjectByOid(String oid) throws WTException {
        Object obj = null;
        ReferenceFactory rf = new ReferenceFactory();
        try {
            obj = rf.getReference(oid).getObject();
        } catch (WTRuntimeException | WTException e) {
            System.out.println(e.getLocalizedMessage() + e);
        }
        return obj;
    }

    /**
     * 兼容旧版本的方法（只校验空优先级）
     * @deprecated 建议使用 validateBomPriority 方法
     */
    @Deprecated
    public static String priorityIsEmpty(WTPart wtPart) throws WTException {
        return validateBomPriority(wtPart);
    }
}