package ext.alphai.aistoneglobal.bom.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.meta.common.impl.TypeIdentifierUtilityHelper;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.bom.BomRB;
import ext.alphai.aistoneglobal.bom.Constant;
import ext.alphai.aistoneglobal.bom.util.IBAUtil;
import ext.alphai.aistoneglobal.bom.util.PartUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.Persistable;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;

import java.rmi.RemoteException;
import java.util.*;


public class ValidationBom extends DefaultObjectFormProcessor {


    @Override
    public FormResult doOperation(NmCommandBean nmcommandbean, List<ObjectBean> paramList) throws WTException {
        FormResult result = super.doOperation(nmcommandbean, paramList);

        boolean bool = SessionServerHelper.manager.isAccessEnforced();
        String bomNumber = "";
        String bomVersion = "";

        try {
            SessionServerHelper.manager.setAccessEnforced(false);

            String oid = nmcommandbean.getElemAddress();
            oid = oid.substring(0, oid.length() - 2);

            if (StringUtils.isNotEmpty(oid)) {
                Object obj = getObjectByOid(oid);
                if (obj instanceof WTPart) {
                    WTPart wtPart = (WTPart) obj;
                    bomNumber = wtPart.getNumber();
                    bomVersion = wtPart.getVersionIdentifier().getValue()+"."+wtPart.getIterationIdentifier().getValue();
                    //基础属性校验
                    String attributeError = validateAttribute(wtPart);

                    // 校验行号
                    String lineNumberError = validateLineNumber(wtPart);

                    // 校验优先级
                    String priorityError = validatePriority(wtPart);

                    // 合并错误信息
                    StringBuilder errorMsg = new StringBuilder();
                    if (StringUtils.isNotBlank(attributeError)) {
                        errorMsg.append("属性问题：").append(lineNumberError);
                    }

                    if (StringUtils.isNotBlank(lineNumberError)) {
                        if (errorMsg.length() > 0) {
                            errorMsg.append("；\n ");
                        }
                        errorMsg.append("行号问题：").append(lineNumberError);
                    }
                    if (StringUtils.isNotBlank(priorityError)) {
                        if (errorMsg.length() > 0) {
                            errorMsg.append("；\n ");
                        }
                        errorMsg.append("优先级问题：").append(priorityError);
                    }

                    // 如果有错误，返回失败信息
                    if (errorMsg.length() > 0) {
                        result.setStatus(FormProcessingStatus.FAILURE);
                        result.setSkipPageRefresh(true);

                        String errorDetail = String.format("BOM %s(%s) 校验未通过：%s",
                                bomNumber, bomVersion, errorMsg.toString());

                        result.addFeedbackMessage(
                                new FeedbackMessage(FeedbackType.FAILURE, null, null, null, new String[]{errorDetail}));
                        return result;
                    }
                }
            }

        } catch (Exception e) {
            result.setStatus(FormProcessingStatus.FAILURE);
            result.setSkipPageRefresh(true);
            String errorMsg = WTMessage.getLocalizedMessage(BomRB.class.getName(),
                    BomRB.VAL_BOM_ERROR, null, SessionHelper.getLocale());
            result.addFeedbackMessage(
                    new FeedbackMessage(FeedbackType.FAILURE, null, null, null, new String[]{errorMsg}));
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(bool);
        }

        // 如果没有错误，返回成功消息
        result.setStatus(FormProcessingStatus.SUCCESS);
        result.setSkipPageRefresh(true);

        String successMsg = String.format("BOM %s(%s) 校验通过，行号和优先级均正常",
                bomNumber, bomVersion);

        result.addFeedbackMessage(
                new FeedbackMessage(FeedbackType.SUCCESS, null, null, null, new String[]{successMsg}));

        return result;
    }

    public static String validateAttribute(WTPart wtPart) throws WTException {
        StringBuilder result = new StringBuilder();
        Map<String, String> ibaAttributeMap = ibaAttribute(wtPart);
        String subTypeInternal = getSubTypeInternal(wtPart);
        //如果是 ASY部件  校验项目名称和分类
        if(Constant.ASY_PART.equals(subTypeInternal)){
            if (StringUtils.isBlank(ibaAttributeMap.get(Constant.AI_CLSNODE))) {
                result.append("分类属性未填写！");
            }

            if (StringUtils.isBlank(ibaAttributeMap.get(Constant.AI_PROJECT_NAME))) {
                if (result.length()>0) {
                    result.append("；\n ");
                }
                result.append("项目名称未填写！");
            }
        }


        return  result.toString();
    }

    public static Map<String,String> ibaAttribute(WTPart wtPart) throws WTException {
        Map<String,String> map = new HashMap<>();
        //获取  分类   项目名称
        IBAUtil ibaUtil = new IBAUtil(wtPart);
        map.put(Constant.AI_CLSNODE,ibaUtil.getIBAValue(Constant.AI_CLSNODE));
        map.put(Constant.AI_PROJECT_NAME,ibaUtil.getIBAValue(Constant.AI_PROJECT_NAME));

        return  map;
    }


    /**
     * 校验BOM行号是否为空
     */
    public static String validateLineNumber(WTPart wtPart) throws WTException {
        StringBuilder result = new StringBuilder();
        List<WTPartUsageLink> partUsageLinks = PartUtil.getSortLinksByPart(wtPart);

        // 用于去重
        Set<String> processedParts = new HashSet<>();

        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            IBAUtil usageLinkIBA = new IBAUtil(partUsageLink);
            String primaryPartLineNumberStr = usageLinkIBA.getIBAValue(Constant.AI_LineNumber);
            WTPartMaster wtPartMaster = partUsageLink.getUses();

            // 获取安装面
            String placementSide = usageLinkIBA.getIBAValue(Constant.AI_Placement_Side);

            // 生成物料唯一标识
            String partKey = buildPartKey(wtPartMaster.getNumber(), placementSide);

            // 如果已经处理过，跳过
            if (processedParts.contains(partKey)) {
                continue;
            }

            if (StringUtils.isBlank(primaryPartLineNumberStr)) {
                if (result.length() > 0) {
                    result.append("; ");
                }
                result.append(buildPartInfo(wtPartMaster.getNumber(), placementSide));
                processedParts.add(partKey);
            }
        }
        return result.toString();
    }

    /**
     * 校验BOM中所有主料的替代料优先级（空值和重复值）
     */
    public static String validatePriority(WTPart wtPart) throws WTException {
        StringBuilder result = new StringBuilder();

        // 用于去重，避免同一个物料（相同安装面）重复显示
        Set<String> processedParts = new HashSet<>();

        List<WTPartUsageLink> partUsageLinks = PartUtil.getSortLinksByPart(wtPart);

        for (WTPartUsageLink partUsageLink : partUsageLinks) {
            WTPartMaster wtPartMaster = partUsageLink.getUses();
            IBAUtil usageLinkIBA = new IBAUtil(partUsageLink);
            String placementSide = usageLinkIBA.getIBAValue(Constant.AI_Placement_Side);

            // 生成物料唯一标识
            String partKey = buildPartKey(wtPartMaster.getNumber(), placementSide);

            // 如果已经处理过，跳过
            if (processedParts.contains(partKey)) {
                continue;
            }
            processedParts.add(partKey);

            List<WTPartSubstituteLink> partSubstituteLinks = PartUtil.getWTPartSubstituteLinks(partUsageLink);

            // 如果只有0或1个替代料，只需要检查空优先级
            if (partSubstituteLinks.size() <= 1) {
                if (partSubstituteLinks.size() == 1) {
                    IBAUtil partSubstituteLinkIBA = new IBAUtil(partSubstituteLinks.get(0));
                    String priority = partSubstituteLinkIBA.getIBAValue(Constant.AI_Priority);

                    if (StringUtils.isBlank(priority)) {
                        if (result.length() > 0) {
                            result.append("; ");
                        }
                        String partInfo = buildPartInfo(wtPartMaster.getNumber(), placementSide);
                        result.append(partInfo).append("【空优先级】");
                    }
                }
                continue;
            }

            // 有多个替代料，需要检查空优先级和重复优先级
            Set<String> prioritySet = new HashSet<>();
            List<String> emptyPriorityList = new ArrayList<>();
            Map<String, List<String>> priorityToSubstitutesMap = new HashMap<>();

            for (WTPartSubstituteLink partSubstituteLink : partSubstituteLinks) {
                IBAUtil partSubstituteLinkIBA = new IBAUtil(partSubstituteLink);
                String priority = partSubstituteLinkIBA.getIBAValue(Constant.AI_Priority);

                // 获取替代料编号用于显示
                WTPartMaster substituteMaster = partSubstituteLink.getSubstitutes();
                String substituteNumber = substituteMaster != null ? substituteMaster.getNumber() : "未知";

                if (StringUtils.isBlank(priority)) {
                    emptyPriorityList.add(substituteNumber);
                } else {
                    if (!priorityToSubstitutesMap.containsKey(priority)) {
                        priorityToSubstitutesMap.put(priority, new ArrayList<>());
                    }
                    priorityToSubstitutesMap.get(priority).add(substituteNumber);
                    prioritySet.add(priority);
                }
            }

            // 检查是否有问题
            boolean hasIssue = false;
            List<String> issueList = new ArrayList<>();

            // 检查空优先级
            if (!emptyPriorityList.isEmpty()) {
                hasIssue = true;
                issueList.add("空优先级(" + String.join(",", emptyPriorityList) + ")");
            }

            // 检查重复优先级
            List<String> duplicatePriorities = new ArrayList<>();
            for (Map.Entry<String, List<String>> entry : priorityToSubstitutesMap.entrySet()) {
                if (entry.getValue().size() > 1) {
                    duplicatePriorities.add(entry.getKey() + "(" + String.join(",", entry.getValue()) + ")");
                }
            }
            if (!duplicatePriorities.isEmpty()) {
                hasIssue = true;
                issueList.add("重复优先级:" + String.join(",", duplicatePriorities));
            }

            // 如果有问题，记录主料信息
            if (hasIssue) {
                if (result.length() > 0) {
                    result.append("; ");
                }

                String partInfo = buildPartInfo(wtPartMaster.getNumber(), placementSide);
                result.append(partInfo).append("【").append(String.join("; ", issueList)).append("】");
            }
        }
        return result.toString();
    }

    /**
     * 构建物料唯一标识（用于去重）
     */
    private static String buildPartKey(String partNumber, String placementSide) {
        if (StringUtils.isBlank(placementSide)) {
            return partNumber;
        } else {
            return partNumber + "|" + placementSide;
        }
    }

    /**
     * 构建物料显示信息
     */
    private static String buildPartInfo(String partNumber, String placementSide) {
        if (StringUtils.isBlank(placementSide)) {
            return partNumber;
        } else {
            return partNumber + "(安装面:" + placementSide + ")";
        }
    }

    /**
     * 通过oid获取对象
     */
    public static Object getObjectByOid(String oid) throws WTException {
        Object obj = null;
        ReferenceFactory rf = new ReferenceFactory();
        try {
            obj = rf.getReference(oid).getObject();
        } catch (WTRuntimeException | WTException e) {
            System.out.println(e.getLocalizedMessage() + e);
        }
        return obj;
    }

    /**
     * 获取子类型 内部名称
     *
     * @param per 持久化对象
     * @return String
     * @throws Exception
     */
    public static String getSubTypeInternal(Persistable per) {
        try {
            String type = TypeIdentifierUtilityHelper.service.getTypeIdentifier(per).toString();
            String[] typeArray = type.split("\\|");
            if (typeArray.length > 0) {
                return typeArray[typeArray.length - 1];
            } else {
                return "";
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return "";
    }



}