package ext.alphai.aistoneglobal.bom.process;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.bom.BomRB;
import ext.alphai.aistoneglobal.bom.util.BOMLineNumberHelper;
import ext.alphai.aistoneglobal.bom.util.PropertiesUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;

import java.util.Iterator;
import java.util.List;

/**
 * 自动分配组号
 *
 * @version: 2018年8月3日
 * @author Guowei
 */


public class AutoSetLineNumber extends DefaultObjectFormProcessor {


    @Override
    public FormResult doOperation(NmCommandBean nmcommandbean, List<ObjectBean> paramList) throws WTException {
        String flag = PropertiesUtil.getValueByKey("alphai.AutoSetLineNumber.Recursion");
        FormResult result = super.doOperation(nmcommandbean, paramList);



        boolean bool = SessionServerHelper.manager.isAccessEnforced();
        Iterator iterator1 = paramList.iterator();
        try {
            SessionServerHelper.manager.setAccessEnforced(false);
            String oid = nmcommandbean.getElemAddress();
            oid = oid.substring(0, oid.length() - 2);
            if (StringUtils.isNotEmpty(oid)) {
                Object obj = getObjectByOid(oid);
                if (obj != null) {
                    if (obj instanceof WTPart) {
                        WTPart part = (WTPart) obj;
                        BOMLineNumberHelper helper = new BOMLineNumberHelper();
                        helper.autoGenLineNumber(part, null, flag);
                    }
                }
            }

        } catch (Exception e) {
            result.setStatus(FormProcessingStatus.FAILURE);
            result.setSkipPageRefresh(true);
            String feedbackMsg = WTMessage.getLocalizedMessage(BomRB.class.getName(),
                    BomRB.AUTO_SETlINEnUMBER_6, null, SessionHelper.getLocale());
            result.addFeedbackMessage(
                    new FeedbackMessage(FeedbackType.FAILURE, null, null, null, new String[] { feedbackMsg }));
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(bool);
        }
        result.setStatus(FormProcessingStatus.SUCCESS);
        result.setSkipPageRefresh(true);
        String feedbackMsg = WTMessage.getLocalizedMessage(BomRB.class.getName(),
                BomRB.AUTO_SETlINEnUMBER_5, null, SessionHelper.getLocale());
        result.addFeedbackMessage(
                new FeedbackMessage(FeedbackType.SUCCESS, null, null, null, new String[] { feedbackMsg }));

        return result;
    }

    /**
     * 通过oid获取对象
     *
     * @version: 2018年8月7日
     * @author Houjs
     */
    public static Object getObjectByOid(String oid) throws WTException {
        Object obj = null;
        ReferenceFactory rf = new ReferenceFactory();
        try {
            obj = rf.getReference(oid).getObject();
        } catch (WTRuntimeException e) {
            System.out.println(e.getLocalizedMessage()+ e);
        } catch (WTException e) {
            System.out.println(e.getLocalizedMessage()+ e);
        }
        return obj;
    }
}
