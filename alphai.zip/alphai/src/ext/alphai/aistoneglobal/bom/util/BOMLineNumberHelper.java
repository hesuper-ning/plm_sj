package ext.alphai.aistoneglobal.bom.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.*;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.config.ConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;

import java.text.DecimalFormat;
import java.util.*;

/**
 * 自动生成行号信息
 *
 * @version: 2018年10月11日
 * @author Hou Jiansong
 */

public class BOMLineNumberHelper {

    private static final Logger logger = LogManager.getLogger(BOMLineNumberHelper.class.getName());

    public static String  LINE_NUMBER = "AI_LineNumber";
    public static String  AI_Placement_Side="AI_Placement_Side";

    // 定义行号格式化为4位，前面补0
    private static final DecimalFormat LINE_NUMBER_FORMAT = new DecimalFormat("0000");

    /**
     * 自动生成行号
     *
     * @param part
     * @param numberList
     * @param flag
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public void autoGenLineNumber(WTPart part, List<String> numberList, String  flag)
            throws Exception {
        if (part != null) {
            if (numberList == null) {
                numberList = new ArrayList<String>();
            }
            if (numberList.contains(part.getNumber())) {
                return;
            } else {
                numberList.add(part.getNumber());
            }

            // 获取当前BOM中最大的行号
            Long ln = getMaxLineNumber(part);

            if (logger.isDebugEnabled()) {
                logger.debug("ln : " + ln);
            }
            if (ln > 0) {
                ln = ln - ln % 10;
            }

            Map<WTPartUsageLink, String> linkMap = new HashMap<WTPartUsageLink, String>();
            QueryResult childNodes = WTPartHelper.service.getUsesWTParts(part, getViewConfig(part.getViewName()));

            // 创建列表存储link和对应的part信息用于排序
            List<LinkWithPart> linkWithParts = new ArrayList<LinkWithPart>();
            List<WTPart> childList = new ArrayList<WTPart>();

            while (childNodes.hasMoreElements()) {
                Persistable aSubNodePair[] = (Persistable[]) childNodes.nextElement();
                WTPartUsageLink link = (WTPartUsageLink) aSubNodePair[0];
                Persistable childp = aSubNodePair[1];

                if (childp instanceof WTPart) {
                    WTPart child = (WTPart) childp;
                    linkWithParts.add(new LinkWithPart(link, child));
                } else {
                    logger.error(".........." + childp);
                }
            }

            // 按照部件编号排序
            Collections.sort(linkWithParts, new Comparator<LinkWithPart>() {
                @Override
                public int compare(LinkWithPart o1, LinkWithPart o2) {
                    String number1 = o1.getPart().getNumber();
                    String number2 = o2.getPart().getNumber();
                    return number1.compareTo(number2);
                }
            });

            // 用于存储相同物料编号且AI_Placement_Side不为空的组
            Map<String, List<LinkWithPart>> samePartNumberGroup = new HashMap<String, List<LinkWithPart>>();

            // 第一遍遍历：收集需要特殊处理的子料（物料编号相同且AI_Placement_Side不为空）
            for (LinkWithPart linkWithPart : linkWithParts) {
                WTPart child = linkWithPart.getPart();
                IBAUtil linkIBA = new IBAUtil(linkWithPart.getLink());
                String placementSide = linkIBA.getIBAValue(AI_Placement_Side);

                // 如果物料编号的AI_Placement_Side不为空，则加入分组
                if (placementSide != null && !placementSide.trim().isEmpty()) {
                    String partNumber = child.getNumber();
                    if (!samePartNumberGroup.containsKey(partNumber)) {
                        samePartNumberGroup.put(partNumber, new ArrayList<LinkWithPart>());
                    }
                    samePartNumberGroup.get(partNumber).add(linkWithPart);
                }
            }

            // 为每个特殊组预先分配行号
            Map<String, String> groupLineNumberMap = new HashMap<String, String>();
            for (Map.Entry<String, List<LinkWithPart>> entry : samePartNumberGroup.entrySet()) {
                String partNumber = entry.getKey();
                List<LinkWithPart> groupLinks = entry.getValue();

                // 如果该组有多个相同物料编号的子料
                if (groupLinks.size() > 1) {
                    // 检查组内是否已经有行号
                    String existingLineNumber = null;
                    boolean hasLineNumber = false;

                    for (LinkWithPart linkWithPart : groupLinks) {
                        IBAUtil linkIBA = new IBAUtil(linkWithPart.getLink());
                        String lineNumberIBA = linkIBA.getIBAValue(LINE_NUMBER);
                        if (lineNumberIBA != null && !lineNumberIBA.trim().isEmpty()) {
                            existingLineNumber = lineNumberIBA;
                            hasLineNumber = true;
                            break;
                        }
                    }

                    if (hasLineNumber && existingLineNumber != null) {
                        // 如果组内已有行号，整个组使用相同的行号
                        groupLineNumberMap.put(partNumber, existingLineNumber);
                    } else {
                        // 如果组内没有行号，分配新的行号
                        ln = ln + 10;
                        String formattedLineNumber = LINE_NUMBER_FORMAT.format(ln);
                        groupLineNumberMap.put(partNumber, formattedLineNumber);
                    }
                }
            }

            // 第二遍遍历：处理所有子料的行号分配
            for (LinkWithPart linkWithPart : linkWithParts) {
                WTPartUsageLink link = linkWithPart.getLink();
                WTPart child = linkWithPart.getPart();

                IBAUtil linkIBA = new IBAUtil(link);
                String lineNumberIBA = linkIBA.getIBAValue(LINE_NUMBER);
                String placementSide = linkIBA.getIBAValue(AI_Placement_Side);

                // 判断是否需要分配行号
                if (lineNumberIBA == null || lineNumberIBA.trim().isEmpty()) {
                    String partNumber = child.getNumber();
                    String assignedLineNumber = null;

                    // 检查是否属于需要特殊处理的组
                    if (placementSide != null && !placementSide.trim().isEmpty() &&
                            samePartNumberGroup.containsKey(partNumber) &&
                            samePartNumberGroup.get(partNumber).size() > 1) {
                        // 属于特殊组，使用组内统一的行号
                        assignedLineNumber = groupLineNumberMap.get(partNumber);
                    }

                    // 如果不是特殊组，或者特殊组但未分配到行号，则分配新的行号
                    if (assignedLineNumber == null) {
                        ln = ln + 10;
                        assignedLineNumber = LINE_NUMBER_FORMAT.format(ln);
                    }

                    linkIBA.setIBAAttribute4AllType(link, LINE_NUMBER, assignedLineNumber);

                    if (logger.isDebugEnabled()) {
                        logger.debug("Generated line number: " + assignedLineNumber + " for part: " + child.getNumber() +
                                ", PlacementSide: " + (placementSide != null ? placementSide : "null"));
                    }
                }

                if (!childList.contains(child)) {
                    childList.add(child);
                }
            }

            if ("true".equals(flag)) {
                for (WTPart child : childList) {
                    autoGenLineNumber(child, numberList, flag);
                }
            }
        }
    }

    /**
     * 辅助类，用于存储link和对应的part
     */
    private static class LinkWithPart {
        private WTPartUsageLink link;
        private WTPart part;

        public LinkWithPart(WTPartUsageLink link, WTPart part) {
            this.link = link;
            this.part = part;
        }

        public WTPartUsageLink getLink() {
            return link;
        }

        public WTPart getPart() {
            return part;
        }
    }

    /**
     * 获取视图过滤条件
     *
     * @return
     * @throws WTException
     */
    public ConfigSpec getViewConfig(String viewname) {
        ConfigSpec configSpec = null;
        try {
            // 这个是设计视图
            if (viewname != null) {
                View view = ViewHelper.service.getView(viewname);
                configSpec = WTPartConfigSpec
                        .newWTPartConfigSpec(WTPartStandardConfigSpec.newWTPartStandardConfigSpec(view, null));
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return configSpec;
    }

    public static Long getMaxLineNumber(WTPart part) {
        Long maxLineNumber = 0L;

        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                IBAUtil linkIBA = new IBAUtil(link);
                String lineNumberValue = linkIBA.getIBAValue(LINE_NUMBER);

                if (lineNumberValue != null && !lineNumberValue.trim().isEmpty()) {
                    try {
                        long lineNumberIBALong = Long.parseLong(lineNumberValue.trim());
                        if (lineNumberIBALong > maxLineNumber) {
                            maxLineNumber = lineNumberIBALong;
                        }
                    } catch (NumberFormatException e) {
                        // 如果转换失败，跳过这个值
                        logger.error("Invalid line number format: " + lineNumberValue);
                    }
                }
            }
        } catch (WTException e) {
            throw new RuntimeException(e);
        }

        return maxLineNumber;
    }

    /**
     * 新增方法：将行号格式化为4位（用于外部调用）
     * @param lineNumber 原始行号
     * @return 格式化后的4位行号
     */
    public static String formatLineNumber(Long lineNumber) {
        if (lineNumber == null) {
            return LINE_NUMBER_FORMAT.format(0);
        }
        return LINE_NUMBER_FORMAT.format(lineNumber);
    }

    /**
     * 新增方法：将行号字符串解析为Long
     * @param formattedLineNumber 格式化后的行号字符串
     * @return 解析后的Long值
     */
    public static Long parseLineNumber(String formattedLineNumber) {
        if (formattedLineNumber == null || formattedLineNumber.trim().isEmpty()) {
            return 0L;
        }
        try {
            return Long.parseLong(formattedLineNumber);
        } catch (NumberFormatException e) {
            logger.error("Failed to parse line number: " + formattedLineNumber);
            return 0L;
        }
    }

    /**
     * 为相同物料编号且AI_Placement_Side相同的子料设置相同的行号
     * @param part 父部件
     * @throws Exception
     */
    public void syncLineNumberForSameParts(WTPart part) throws Exception {
        if (part == null) {
            return;
        }

        QueryResult childNodes = WTPartHelper.service.getUsesWTParts(part, getViewConfig(part.getViewName()));

        // 使用Map存储相同物料编号+AI_Placement_Side组合的link列表
        Map<String, List<WTPartUsageLink>> groupMap = new HashMap<String, List<WTPartUsageLink>>();

        while (childNodes.hasMoreElements()) {
            Persistable aSubNodePair[] = (Persistable[]) childNodes.nextElement();
            WTPartUsageLink link = (WTPartUsageLink) aSubNodePair[0];
            Persistable childp = aSubNodePair[1];

            if (childp instanceof WTPart) {
                WTPart child = (WTPart) childp;
                IBAUtil linkIBA = new IBAUtil(link);
                String placementSide = linkIBA.getIBAValue(AI_Placement_Side);
                String lineNumber = linkIBA.getIBAValue(LINE_NUMBER);

                // 如果AI_Placement_Side不为空，且物料编号相同
                if (placementSide != null && !placementSide.trim().isEmpty()) {
                    String key = child.getNumber() + "_" + placementSide;
                    if (!groupMap.containsKey(key)) {
                        groupMap.put(key, new ArrayList<WTPartUsageLink>());
                    }
                    groupMap.get(key).add(link);
                }
            }
        }

        // 为每组设置相同的行号
        for (Map.Entry<String, List<WTPartUsageLink>> entry : groupMap.entrySet()) {
            List<WTPartUsageLink> links = entry.getValue();
            if (links.size() > 1) {
                // 获取组内第一个有效行号
                String unifiedLineNumber = null;
                for (WTPartUsageLink link : links) {
                    IBAUtil linkIBA = new IBAUtil(link);
                    String lineNumber = linkIBA.getIBAValue(LINE_NUMBER);
                    if (lineNumber != null && !lineNumber.trim().isEmpty()) {
                        unifiedLineNumber = lineNumber;
                        break;
                    }
                }

                // 如果组内都没有行号，生成一个新的
                if (unifiedLineNumber == null) {
                    Long maxLn = getMaxLineNumber(part);
                    if (maxLn > 0) {
                        maxLn = maxLn - maxLn % 10;
                    }
                    maxLn = maxLn + 10;
                    unifiedLineNumber = LINE_NUMBER_FORMAT.format(maxLn);
                }

                // 为组内所有link设置相同的行号
                for (WTPartUsageLink link : links) {
                    IBAUtil linkIBA = new IBAUtil(link);
                    String currentLineNumber = linkIBA.getIBAValue(LINE_NUMBER);
                    if (!unifiedLineNumber.equals(currentLineNumber)) {
                        linkIBA.setIBAAttribute4AllType(link, LINE_NUMBER, unifiedLineNumber);
                        logger.info("Synced line number: " + unifiedLineNumber + " for part: " +
                                ((WTPart)link.getRoleAObject()).getNumber() +
                                ", PlacementSide: " + linkIBA.getIBAValue(AI_Placement_Side));
                    }
                }
            }
        }
    }
}