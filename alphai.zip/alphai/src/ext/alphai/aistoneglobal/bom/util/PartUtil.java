package ext.alphai.aistoneglobal.bom.util;

import ext.alphai.aistoneglobal.sap.utils.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.occurrence.OccurrenceHelper;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PartUtil {
    /**
     * 获取部件与其所有子部件间的关联关系
     *
     * @param WTPart
     * @return List<WTPartUsageLink>
     */
    public static List<WTPartUsageLink> getLinksByPart(WTPart fatherPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                list.add(link);
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        System.out.println("listsize" + list.size());
        return list;
    }

    public static List<WTPartUsageLink> getSortLinksByPart(WTPart fatherPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                list.add(link);
            }

            // 直接在方法内部排序（Java 8 Lambda表达式）
            if (list.size() > 1) {
                list.sort((link1, link2) -> {
                    try {
                        // 获取第一个链接的排序信息
                        ext.alphai.aistoneglobal.sap.utils.IBAUtil iba1 = new ext.alphai.aistoneglobal.sap.utils.IBAUtil(link1);
                        String lineNumberStr1 = iba1.getIBAValue("AI_LineNumber");
                        String partNumber1 = link1.getUses().getNumber();

                        // 获取第二个链接的排序信息
                        ext.alphai.aistoneglobal.sap.utils.IBAUtil iba2 = new IBAUtil(link2);
                        String lineNumberStr2 = iba2.getIBAValue("AI_LineNumber");
                        String partNumber2 = link2.getUses().getNumber();

                        // 安全解析行号
                        Long lineNumber1 = safeParseLong(lineNumberStr1);
                        Long lineNumber2 = safeParseLong(lineNumberStr2);

                        // 首先比较行号
                        int lineCompare = lineNumber1.compareTo(lineNumber2);
                        if (lineCompare != 0) {
                            return lineCompare;
                        }

                        // 行号相同比较部件编码
                        return partNumber1.compareTo(partNumber2);

                    } catch (Exception e) {
                        // 发生异常时保持原顺序
                        return 0;
                    }
                });
            }

        } catch (WTException e) {
            e.printStackTrace();
        }
        System.out.println("listsize: " + list.size());
        return list;
    }

    /**
     * 安全解析Long值
     */
    private static Long safeParseLong(String str) {
        if (StringUtils.isBlank(str)) {
            return Long.MIN_VALUE;
        }
        try {
            return Long.parseLong(str.trim());
        } catch (NumberFormatException e) {
            return Long.MIN_VALUE;
        }
    }

    /**
     * 根据部件于获取局部替代料的关联关系
     *
     * @param WTPart part
     * @return List<WTPartSubstituteLink>
     */
    public static List<WTPartSubstituteLink> getWTPartSubstituteLinks(WTPartUsageLink usageLink) {
        if (usageLink == null) {
            return null;
        }
        List<WTPartSubstituteLink> list = new ArrayList<WTPartSubstituteLink>();
        long masterId = PersistenceHelper.getObjectIdentifier(usageLink).getId();
        int[] index = { 0 };
        try {
            QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
            qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class, "roleAObjectRef.key.id",
                    SearchCondition.EQUAL, masterId), index);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            while (qr.hasMoreElements()) {
                WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr.nextElement();
                list.add(sLink);
            }
        } catch (QueryException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 递归获取部件的所有子部件
     *
     * @param WTPart
     * @return List<WTPart>
     */
    public static List<WTPart> getAllBomByPart(WTPart part) {
        List<WTPart> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        WTPart sPart = null;
        QueryResult qr2 = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    // 可能需要指定部件的视图
                    localList.add(sPart);

                    // 递归调用，将结果合并到局部列表
                    localList.addAll(getAllBomByPart(sPart));
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }

    /**
     * 递归获取部件的单层子部件
     *
     * @param
     * @return List<WTPart>
     */
    public static List<WTPart> getSingleBomByPart(WTPart part) {
        List<WTPart> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        WTPart sPart = null;
        QueryResult qr2 = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    // 可能需要指定部件的视图
                    localList.add(sPart);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }


    /**
     * 根据usagelink获取位号,分割（按自然顺序排序，保证每次顺序一致）
     * @param usageLink
     * @return
     */
    public static String getUsageLinkPartUsesOccurrence(WTPartUsageLink usageLink){
        try {
            QueryResult result = OccurrenceHelper.service.getUsesOccurrences(usageLink);
            List<String> names = new ArrayList<>();
            while( result.hasMoreElements() ) {
                PartUsesOccurrence occ = (PartUsesOccurrence)result.nextElement();
                String name = occ.getName();
                if (name != null && !name.trim().isEmpty()) {
                    names.add(name.trim());
                }
            }

            // 使用自然排序，保证每次顺序一致
            Collections.sort(names);

            return String.join(",", names);
        } catch (WTException e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 通过说明文档找到部件
     *
     * @param WTDocument
     * @return List<WTPart>
     */
    public static List<WTPart> getPartByDescribesDoc(WTDocument WTDocument) {
        QueryResult qr = null;
        WTPart part = null;
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            qr = WTPartHelper.service.getDescribesWTParts(WTDocument);// 说明文档
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTPart) {
                    part = (WTPart) obj;
                    list.add(part);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


}
