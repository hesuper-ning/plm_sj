package ext.alphai.aistoneglobal.todo.service;

import com.ptc.core.components.beans.ObjectBean;

import com.ptc.netmarkets.actionitem.NmActionItemHelper;
import com.ptc.windchill.cloudapp.officeapp.actions.ActionHelper;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.meeting.actionitem.DiscreteActionItem;
import wt.meeting.actionitem.IteratedActionItemSubjectLink;
import wt.meeting.actionitem.IteratedSubjectOfActionItem;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.util.WTException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import java.util.List;

public class TodoService {

    public DiscreteActionItem getDiscreteActionItemByBean(List<ObjectBean> list){
        DiscreteActionItem doc = (!list.isEmpty())
                ? (list.get(0).getObject() instanceof DiscreteActionItem ? (DiscreteActionItem) list.get(0).getObject() : null)
                : null;

        return doc;
    }


    /**
     * 措施项（待办）与 交付关联
     * @param discreteActionItem
     * @param persistable
     * @throws WTException
     */
    public void addTodoAndWTPartLink(DiscreteActionItem discreteActionItem , Persistable persistable) throws WTException {
        IteratedActionItemSubjectLink iteratedActionItemSubjectLink = IteratedActionItemSubjectLink.newIteratedActionItemSubjectLink(discreteActionItem, (IteratedSubjectOfActionItem) VersionControlHelper.getLatestIteration((Iterated) persistable));
        PersistenceHelper.manager.save(iteratedActionItemSubjectLink);
        PersistenceHelper.manager.refresh(iteratedActionItemSubjectLink);
    }

    /**
     * 措施项（待办）与 交付关联
     * @param discreteActionItem
     * @param persistable
     * @throws WTException
     */
    public void updateTodoAndWTPartLink(DiscreteActionItem discreteActionItem , Persistable persistable) throws WTException {
        IteratedActionItemSubjectLink iteratedActionItemSubjectLink = IteratedActionItemSubjectLink.newIteratedActionItemSubjectLink(discreteActionItem, (IteratedSubjectOfActionItem) VersionControlHelper.getLatestIteration((Iterated) persistable));
        PersistenceHelper.manager.save(iteratedActionItemSubjectLink);
        PersistenceHelper.manager.refresh(iteratedActionItemSubjectLink);
    }


    /**
     * 措施项（待办）与 交付关联
     * @param discreteActionItem
     * @param persistable
     * @throws WTException
     */
    public void SubjectLink(DiscreteActionItem discreteActionItem , Persistable persistable) throws WTException {


    }
}
