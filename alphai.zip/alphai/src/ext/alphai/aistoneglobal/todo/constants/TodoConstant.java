package ext.alphai.aistoneglobal.todo.constants;

public class TodoConstant {
    /** 待办类型  交付对象编号 */
    public static final String AI_DELIVERY_NUMBER = "AI_DeliveryNumber";


}
