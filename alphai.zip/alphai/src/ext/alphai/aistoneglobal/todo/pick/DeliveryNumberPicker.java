package ext.alphai.aistoneglobal.todo.pick;



import java.util.HashMap;
import java.util.List;

import com.ptc.core.lwc.common.view.PropertyHolderHelper;
import ext.alphai.aistoneglobal.todo.constants.TodoConstant;
import wt.inf.container.WTContainerRef;
import wt.util.WTException;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultPickerDataUtility;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.netmarkets.util.beans.NmCommandBean;

public class DeliveryNumberPicker extends DefaultPickerDataUtility {
    ComponentMode mode= ComponentMode.CREATE;
    WTContainerRef containerRef = null;

    @Override
    public void setModelData(String component_id, List<?> objects, ModelContext mc)throws WTException
    {
        mode = mc.getDescriptorMode();
        super.setModelData(component_id, objects, mc);
        NmCommandBean clientData = mc.getNmCommandBean();
        containerRef = (clientData != null) ? clientData.getContainerRef() : null;
        if (ComponentMode.CREATE.equals(mode) || ComponentMode.EDIT.equals(mode))
        {
            buildUserPickerConfig(component_id, mc);
        }
    }

    public void buildUserPickerConfig(final String component_id, final ModelContext mc) throws WTException
    {
        HashMap<String, Object> defaultProps = new HashMap<String, Object>();
        defaultProps.put("objectType", "wt.doc.WTDocument,wt.part.WTPart,wt.epm.EPMDocument,wt.change2.WTChangeRequest2,wt.change2.WTChangeOrder2");  //只查询的类型
        defaultProps.put("pickedAttributes", "name,number");//projectNumber是项目编号
        defaultProps.put("displayAttribute", "name,number");//回调函数返回的属性
        defaultProps.put("attributes", "name,number,version");//回调函数返回的属性
        defaultProps.put("multiSelect", "true");
        defaultProps.put("readOnlyPickerTextBox", "true");
        defaultProps.put("pickerTitle", "交付项搜索");   //查询页面的标题
        defaultProps.put("componentId", "authObjectsItemPicker");

        HashMap<String, Object> customProps = new HashMap<String, Object>();
        //注意AI_ProjectInfo是绑定的iab属性，写成配置最好
        if (TodoConstant.AI_DELIVERY_NUMBER.equalsIgnoreCase(component_id)) {	// replace <ATTRIBUTE_INTERNAL_NAME> with attribute internal name
            customProps.put("pickerId",component_id);
            customProps.put("pickerCallback", "CustomPickerInputComponentCallback");
        }
        defaultProps.putAll(customProps);
        mc.getDescriptor().setProperties(defaultProps);
    }

    @Override
    public Object getDataValue(String component_id, Object object, ModelContext mc) throws WTException
    {
        GUIComponentArray guiArray = new GUIComponentArray();
        String attributeId = component_id;

        Object obj = null;

        if (ComponentMode.CREATE.equals(mode) || ComponentMode.EDIT.equals(mode))
        {
            obj = super.getDataValue(attributeId, object, mc);

            if (obj instanceof PickerInputComponent)
            {
                PickerInputComponent pickerComponent = (PickerInputComponent) obj;
                setRequired(component_id, object, pickerComponent, mc);
                guiArray.addGUIComponent(pickerComponent);
            }
        }
        else{

        }
        return obj;
    }

    void setRequired(String component_id, Object object, PickerInputComponent pickerComponent, ModelContext mc) throws WTException {
        boolean isRequired = true;
        pickerComponent.setRequired(isRequired);
    }


}
