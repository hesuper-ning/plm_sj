package ext.alphai.aistoneglobal.todo.processors;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.actionitem.processors.CreateActionItemFormProcessor;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.todo.constants.TodoConstant;
import ext.alphai.aistoneglobal.todo.service.TodoService;
import ext.alphai.aistoneglobal.todo.uitls.IBAUtil;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.meeting.actionitem.DiscreteActionItem;
import wt.meeting.actionitem.IteratedActionItemSubjectLink;
import wt.meeting.actionitem.IteratedSubjectOfActionItem;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;

import java.util.List;


public class TodoFormProcessor extends CreateActionItemFormProcessor {

    public TodoService todoService = new  TodoService();


    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        FormResult formResult = super.doOperation(nmCommandBean, list);
        //获取当前用户
        WTPrincipal currentUser = SessionHelper.manager.getPrincipal();

        for (ObjectBean objectBean : list) {
            try {
                DiscreteActionItem discreteActionItem = (DiscreteActionItem)objectBean.getObject();//措施项
                //交付对象编号  内部值为
                IBAUtil ibaUtil = new IBAUtil(discreteActionItem);
                String deliveryItem = ibaUtil.getIBAValue(TodoConstant.AI_DELIVERY_NUMBER);//，分割的  编号与oid
                String[] deliveryItems = deliveryItem.split(",");//0 是编号  1是oid
                System.out.println("交付对象编号"+deliveryItems[0]);  //
                ReferenceFactory rf = new ReferenceFactory();
                WTReference reference =  rf.getReference(deliveryItems[1]);
                Persistable object = reference.getObject();//交付对象

                todoService.addTodoAndWTPartLink(discreteActionItem,object);
            } finally {
                //切回当前用户
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
//        DiscreteActionItem discreteActionItem= todoService.getDiscreteActionItemByBean(list);
//        //获取当前用户
//        WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
//        try {
//            IBAUtil ibaUtil = new IBAUtil(discreteActionItem);
//            //交付对象编号  内部值为  具体的对象oid
//            String deliveryNumber = ibaUtil.getIBAValue(TodoConstant.AI_DELIVERY_NUMBER);
//
//            System.out.println("交付对象编号"+deliveryNumber);
//
//
//            ReferenceFactory rf = new ReferenceFactory();
//            WTReference reference =  rf.getReference(deliveryNumber);
//            Persistable object = reference.getObject();
//
//
//
//
//
//
//
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        } finally {
//            //切回当前用户
//            SessionHelper.manager.setPrincipal(currentUser.getName());
//        }
        return formResult;
    }
}
