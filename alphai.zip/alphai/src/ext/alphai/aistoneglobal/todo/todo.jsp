<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="wt.session.SessionHelper, wt.org.WTUser, wt.org.WTPrincipal" %>
<%
    String currentUserId = "";
    String currentUserName = "";
    try {
        WTPrincipal principal = SessionHelper.getPrincipal();
        if (principal instanceof WTUser) {
            WTUser user = (WTUser) principal;
            currentUserId = String.valueOf(user.getPersistInfo().getObjectIdentifier().getId());
            currentUserName = user.getFullName();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>待办任务管理系统</title>
    <link rel="stylesheet" type="text/css" href="/windchill/ext/resources/css/ext-all.css">
    <script type="text/javascript" src="/windchill/ext/ext-all.js"></script>
    <script type="text/javascript" src="/windchill/ext/locale/ext-lang-zh_CN.js"></script>
    <style>
        .priority-high { background-color: #ffebee !important; }
        .priority-medium { background-color: #fff3e0 !important; }
        .priority-low { background-color: #e8f5e8 !important; }
        .completed-task { text-decoration: line-through; color: #888; }
        .overdue-task { color: #d32f2f; font-weight: bold; }
    </style>
</head>
<body>
<script type="text/javascript">
    Ext.onReady(function() {
        // 当前用户信息
        const currentUser = {
            id: '<%=currentUserId%>',
            name: '<%=currentUserName%>'
        };

        // 状态映射
        const statusMap = {
            1: { text: '待处理', color: '#ff9800' },
            2: { text: '已完成', color: '#4caf50' },
            3: { text: '已取消', color: '#9e9e9e' }
        };

        // 优先级映射
        const priorityMap = {
            1: { text: '高', color: '#f44336' },
            2: { text: '中', color: '#ff9800' },
            3: { text: '低', color: '#4caf50' }
        };

        // 数据模型
        Ext.define('Todo', {
            extend: 'Ext.data.Model',
            fields: [
                'todoId', 'title', 'description', 'creatorId', 'creatorName',
                'assigneeId', 'assigneeName', 'priorityLevel', 'status',
                'dueDate', 'creationDate', 'lastUpdateDate', 'isActive'
            ]
        });

        // 主Store
        const todoStore = Ext.create('Ext.data.Store', {
            model: 'Todo',
            proxy: {
                type: 'ajax',
                url: '/windchill/todos/all',
                extraParams: {
                    userId: currentUser.id
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: true
        });

        // 创建工具栏
        const toolbar = Ext.create('Ext.toolbar.Toolbar', {
            items: [
                {
                    text: '刷新',
                    iconCls: 'x-tbar-loading',
                    handler: function() {
                        todoStore.load();
                    }
                },
                '-',
                {
                    text: '创建任务',
                    iconCls: 'x-tbar-add',
                    handler: showCreateForm
                },
                '-',
                {
                    text: '我创建的',
                    handler: function() {
                        loadMyCreatedTodos();
                    }
                },
                {
                    text: '分配给我的',
                    handler: function() {
                        loadMyAssignedTodos();
                    }
                },
                '->',
                {
                    xtype: 'textfield',
                    emptyText: '搜索任务标题...',
                    width: 200,
                    listeners: {
                        specialkey: function(field, e) {
                            if (e.getKey() === e.ENTER) {
                                searchTodos(field.getValue());
                            }
                        }
                    }
                }
            ]
        });

        // 创建任务表格
        const todoGrid = Ext.create('Ext.grid.Panel', {
            store: todoStore,
            columns: [
                {
                    text: '标题',
                    dataIndex: 'title',
                    flex: 2,
                    renderer: function(value, metadata, record) {
                        let css = '';
                        if (record.get('status') === 2) {
                            css = 'completed-task';
                        } else if (record.get('dueDate') && new Date(record.get('dueDate')) < new Date()) {
                            css = 'overdue-task';
                        }
                        return '<span class="' + css + '">' + value + '</span>';
                    }
                },
                {
                    text: '描述',
                    dataIndex: 'description',
                    flex: 2
                },
                {
                    text: '创建人',
                    dataIndex: 'creatorName',
                    width: 100
                },
                {
                    text: '负责人',
                    dataIndex: 'assigneeName',
                    width: 100
                },
                {
                    text: '优先级',
                    dataIndex: 'priorityLevel',
                    width: 80,
                    renderer: function(value) {
                        const priority = priorityMap[value];
                        return '<span style="color:' + priority.color + '">' + priority.text + '</span>';
                    }
                },
                {
                    text: '状态',
                    dataIndex: 'status',
                    width: 80,
                    renderer: function(value) {
                        const status = statusMap[value];
                        return '<span style="color:' + status.color + '">' + status.text + '</span>';
                    }
                },
                {
                    text: '截止日期',
                    dataIndex: 'dueDate',
                    width: 100,
                    renderer: function(value) {
                        return value ? Ext.Date.format(new Date(value), 'Y-m-d') : '';
                    }
                },
                {
                    text: '创建时间',
                    dataIndex: 'creationDate',
                    width: 120,
                    renderer: function(value) {
                        return value ? Ext.Date.format(new Date(value), 'Y-m-d H:i') : '';
                    }
                },
                {
                    xtype: 'actioncolumn',
                    text: '操作',
                    width: 150,
                    items: [
                        {
                            iconCls: 'x-fa fa-edit',
                            tooltip: '编辑',
                            handler: function(grid, rowIndex, colIndex) {
                                const record = grid.getStore().getAt(rowIndex);
                                showEditForm(record);
                            },
                            getClass: function(value, metadata, record) {
                                return canEdit(record) ? 'x-fa fa-edit' : 'x-fa fa-edit x-item-disabled';
                            }
                        },
                        {
                            iconCls: 'x-fa fa-check',
                            tooltip: '完成',
                            handler: function(grid, rowIndex, colIndex) {
                                const record = grid.getStore().getAt(rowIndex);
                                completeTodo(record);
                            },
                            getClass: function(value, metadata, record) {
                                return canComplete(record) ? 'x-fa fa-check' : 'x-fa fa-check x-item-disabled';
                            }
                        },
                        {
                            iconCls: 'x-fa fa-user',
                            tooltip: '重新分配',
                            handler: function(grid, rowIndex, colIndex) {
                                const record = grid.getStore().getAt(rowIndex);
                                showReassignForm(record);
                            },
                            getClass: function(value, metadata, record) {
                                return canReassign(record) ? 'x-fa fa-user' : 'x-fa fa-user x-item-disabled';
                            }
                        },
                        {
                            iconCls: 'x-fa fa-trash',
                            tooltip: '删除',
                            handler: function(grid, rowIndex, colIndex) {
                                const record = grid.getStore().getAt(rowIndex);
                                deleteTodo(record);
                            },
                            getClass: function(value, metadata, record) {
                                return canDelete(record) ? 'x-fa fa-trash' : 'x-fa fa-trash x-item-disabled';
                            }
                        }
                    ]
                }
            ],
            viewConfig: {
                getRowClass: function(record) {
                    return 'priority-' + (record.get('priorityLevel') === 1 ? 'high' :
                        record.get('priorityLevel') === 2 ? 'medium' : 'low');
                }
            },
            listeners: {
                itemdblclick: function(grid, record) {
                    showTodoDetail(record);
                }
            }
        });

        // 权限检查函数
        function canEdit(record) {
            return record.get('creatorId') === currentUser.id;
        }

        function canComplete(record) {
            return record.get('assigneeId') === currentUser.id && record.get('status') === 1;
        }

        function canReassign(record) {
            return record.get('creatorId') === currentUser.id;
        }

        function canDelete(record) {
            return record.get('creatorId') === currentUser.id;
        }

        // 创建任务表单
        function showCreateForm() {
            const form = Ext.create('Ext.window.Window', {
                title: '创建新任务',
                width: 500,
                height: 450,
                layout: 'fit',
                items: [{
                    xtype: 'form',
                    bodyPadding: 10,
                    defaults: {
                        anchor: '100%',
                        labelWidth: 80
                    },
                    items: [
                        {
                            xtype: 'textfield',
                            name: 'title',
                            fieldLabel: '标题',
                            allowBlank: false
                        },
                        {
                            xtype: 'textareafield',
                            name: 'description',
                            fieldLabel: '描述',
                            height: 80
                        },
                        {
                            xtype: 'textfield',
                            name: 'assigneeName',
                            fieldLabel: '负责人',
                            allowBlank: false
                        },
                        {
                            xtype: 'hiddenfield',
                            name: 'assigneeId'
                        },
                        {
                            xtype: 'combo',
                            name: 'priorityLevel',
                            fieldLabel: '优先级',
                            store: [[1, '高'], [2, '中'], [3, '低']],
                            value: 2,
                            editable: false
                        },
                        {
                            xtype: 'datefield',
                            name: 'dueDate',
                            fieldLabel: '截止日期',
                            format: 'Y-m-d'
                        }
                    ],
                    buttons: [{
                        text: '保存',
                        formBind: true,
                        handler: function() {
                            const form = this.up('form').getForm();
                            if (form.isValid()) {
                                createTodo(form.getValues());
                            }
                        }
                    }, {
                        text: '取消',
                        handler: function() {
                            this.up('window').close();
                        }
                    }]
                }]
            });
            form.show();
        }

        // 编辑任务表单
        function showEditForm(record) {
            if (!canEdit(record)) {
                Ext.Msg.alert('错误', '没有权限编辑此任务');
                return;
            }

            const form = Ext.create('Ext.window.Window', {
                title: '编辑任务',
                width: 500,
                height: 450,
                layout: 'fit',
                items: [{
                    xtype: 'form',
                    bodyPadding: 10,
                    defaults: {
                        anchor: '100%',
                        labelWidth: 80
                    },
                    items: [
                        {
                            xtype: 'textfield',
                            name: 'title',
                            fieldLabel: '标题',
                            allowBlank: false,
                            value: record.get('title')
                        },
                        {
                            xtype: 'textareafield',
                            name: 'description',
                            fieldLabel: '描述',
                            height: 80,
                            value: record.get('description')
                        },
                        {
                            xtype: 'textfield',
                            name: 'assigneeName',
                            fieldLabel: '负责人',
                            allowBlank: false,
                            value: record.get('assigneeName')
                        },
                        {
                            xtype: 'hiddenfield',
                            name: 'assigneeId',
                            value: record.get('assigneeId')
                        },
                        {
                            xtype: 'combo',
                            name: 'priorityLevel',
                            fieldLabel: '优先级',
                            store: [[1, '高'], [2, '中'], [3, '低']],
                            value: record.get('priorityLevel'),
                            editable: false
                        },
                        {
                            xtype: 'combo',
                            name: 'status',
                            fieldLabel: '状态',
                            store: [[1, '待处理'], [2, '已完成'], [3, '已取消']],
                            value: record.get('status'),
                            editable: false
                        },
                        {
                            xtype: 'datefield',
                            name: 'dueDate',
                            fieldLabel: '截止日期',
                            format: 'Y-m-d',
                            value: record.get('dueDate') ? new Date(record.get('dueDate')) : null
                        }
                    ],
                    buttons: [{
                        text: '保存',
                        formBind: true,
                        handler: function() {
                            const form = this.up('form').getForm();
                            if (form.isValid()) {
                                updateTodo(record.get('todoId'), form.getValues());
                            }
                        }
                    }, {
                        text: '取消',
                        handler: function() {
                            this.up('window').close();
                        }
                    }]
                }]
            });
            form.show();
        }

        // API调用函数
        function createTodo(data) {
            Ext.Ajax.request({
                url: '/windchill/todos/createTodo',
                method: 'POST',
                jsonData: data,
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        Ext.Msg.alert('成功', '任务创建成功');
                        todoStore.load();
                        Ext.WindowManager.getActive().close();
                    } else {
                        Ext.Msg.alert('错误', result.msg);
                    }
                },
                failure: function() {
                    Ext.Msg.alert('错误', '创建任务失败');
                }
            });
        }

        function updateTodo(id, data) {
            Ext.Ajax.request({
                url: '/windchill/todos/' + id,
                method: 'PUT',
                params: {
                    userId: currentUser.id
                },
                jsonData: data,
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        Ext.Msg.alert('成功', '任务更新成功');
                        todoStore.load();
                        Ext.WindowManager.getActive().close();
                    } else {
                        Ext.Msg.alert('错误', result.msg);
                    }
                },
                failure: function() {
                    Ext.Msg.alert('错误', '更新任务失败');
                }
            });
        }

        function deleteTodo(record) {
            if (!canDelete(record)) {
                Ext.Msg.alert('错误', '没有权限删除此任务');
                return;
            }

            Ext.Msg.confirm('确认', '确定要删除这个任务吗？', function(btn) {
                if (btn === 'yes') {
                    Ext.Ajax.request({
                        url: '/windchill/todos/' + record.get('todoId'),
                        method: 'DELETE',
                        params: {
                            userId: currentUser.id
                        },
                        success: function(response) {
                            const result = Ext.decode(response.responseText);
                            if (result.code === 200) {
                                Ext.Msg.alert('成功', '任务删除成功');
                                todoStore.load();
                            } else {
                                Ext.Msg.alert('错误', result.msg);
                            }
                        },
                        failure: function() {
                            Ext.Msg.alert('错误', '删除任务失败');
                        }
                    });
                }
            });
        }

        function completeTodo(record) {
            if (!canComplete(record)) {
                Ext.Msg.alert('错误', '没有权限完成此任务');
                return;
            }

            Ext.Ajax.request({
                url: '/windchill/todos/' + record.get('todoId') + '/complete',
                method: 'PUT',
                params: {
                    userId: currentUser.id
                },
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        Ext.Msg.alert('成功', '任务已完成');
                        todoStore.load();
                    } else {
                        Ext.Msg.alert('错误', result.msg);
                    }
                },
                failure: function() {
                    Ext.Msg.alert('错误', '完成任务失败');
                }
            });
        }

        function showReassignForm(record) {
            if (!canReassign(record)) {
                Ext.Msg.alert('错误', '没有权限重新分配此任务');
                return;
            }

            const form = Ext.create('Ext.window.Window', {
                title: '重新分配任务',
                width: 400,
                height: 200,
                layout: 'fit',
                items: [{
                    xtype: 'form',
                    bodyPadding: 10,
                    defaults: {
                        anchor: '100%',
                        labelWidth: 80
                    },
                    items: [
                        {
                            xtype: 'textfield',
                            name: 'newAssigneeName',
                            fieldLabel: '新负责人',
                            allowBlank: false
                        },
                        {
                            xtype: 'hiddenfield',
                            name: 'newAssigneeId'
                        }
                    ],
                    buttons: [{
                        text: '分配',
                        formBind: true,
                        handler: function() {
                            const form = this.up('form').getForm();
                            if (form.isValid()) {
                                reassignTodo(record.get('todoId'), form.getFieldValues());
                            }
                        }
                    }, {
                        text: '取消',
                        handler: function() {
                            this.up('window').close();
                        }
                    }]
                }]
            });
            form.show();
        }

        function reassignTodo(id, data) {
            Ext.Ajax.request({
                url: '/windchill/todos/' + id + '/reassign',
                method: 'PUT',
                params: {
                    userId: currentUser.id,
                    newAssigneeId: data.newAssigneeId,
                    newAssigneeName: data.newAssigneeName
                },
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        Ext.Msg.alert('成功', '任务重新分配成功');
                        todoStore.load();
                        Ext.WindowManager.getActive().close();
                    } else {
                        Ext.Msg.alert('错误', result.msg);
                    }
                },
                failure: function() {
                    Ext.Msg.alert('错误', '重新分配任务失败');
                }
            });
        }

        function showTodoDetail(record) {
            Ext.Ajax.request({
                url: '/windchill/todos/' + record.get('todoId'),
                method: 'GET',
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        const todo = result.data;
                        const msg = [
                            '<b>标题:</b> ' + todo.title,
                            '<b>描述:</b> ' + (todo.description || '无'),
                            '<b>创建人:</b> ' + todo.creatorName,
                            '<b>负责人:</b> ' + todo.assigneeName,
                            '<b>优先级:</b> ' + priorityMap[todo.priorityLevel].text,
                            '<b>状态:</b> ' + statusMap[todo.status].text,
                            '<b>截止日期:</b> ' + (todo.dueDate ? Ext.Date.format(new Date(todo.dueDate), 'Y-m-d') : '未设置'),
                            '<b>创建时间:</b> ' + Ext.Date.format(new Date(todo.creationDate), 'Y-m-d H:i:s'),
                            '<b>最后更新:</b> ' + Ext.Date.format(new Date(todo.lastUpdateDate), 'Y-m-d H:i:s')
                        ].join('<br>');

                        Ext.Msg.alert('任务详情', msg);
                    }
                }
            });
        }

        function loadMyCreatedTodos() {
            Ext.Ajax.request({
                url: '/windchill/todos/created',
                method: 'GET',
                params: {
                    userId: currentUser.id
                },
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        todoStore.loadData(result.data);
                    }
                }
            });
        }

        function loadMyAssignedTodos() {
            Ext.Ajax.request({
                url: '/windchill/todos/assigned',
                method: 'GET',
                params: {
                    userId: currentUser.id
                },
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        todoStore.loadData(result.data);
                    }
                }
            });
        }

        function searchTodos(keyword) {
            if (!keyword) {
                todoStore.load();
                return;
            }

            Ext.Ajax.request({
                url: '/windchill/todos/all',
                method: 'GET',
                params: {
                    userId: currentUser.id
                },
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        const filteredData = result.data.filter(function(todo) {
                            return todo.title.indexOf(keyword) !== -1;
                        });
                        todoStore.loadData(filteredData);
                    }
                }
            });
        }

        // 创建主面板
        const mainPanel = Ext.create('Ext.panel.Panel', {
            renderTo: Ext.getBody(),
            width: '100%',
            height: '100%',
            layout: 'fit',
            tbar: toolbar,
            items: [todoGrid]
        });

        // 加载统计信息
        function loadStats() {
            Ext.Ajax.request({
                url: '/windchill/todos/stats',
                method: 'GET',
                params: {
                    userId: currentUser.id
                },
                success: function(response) {
                    const result = Ext.decode(response.responseText);
                    if (result.code === 200) {
                        const stats = result.data;
                        console.log('任务统计:', stats);
                    }
                }
            });
        }

        // 初始化加载统计信息
        loadStats();
    });
</script>
</body>
</html>