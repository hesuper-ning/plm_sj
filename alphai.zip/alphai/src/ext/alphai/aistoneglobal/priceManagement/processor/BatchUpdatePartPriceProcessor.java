package ext.alphai.aistoneglobal.priceManagement.processor;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.priceManagement.util.IBAUtil;
import ext.alphai.aistoneglobal.priceManagement.util.PartUtil;
import ext.alphai.aistoneglobal.priceManagement.vo.PriceMaintainerVO;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import wt.part.WTPart;
import wt.util.WTException;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


public class BatchUpdatePartPriceProcessor extends DefaultObjectFormProcessor {

    public static final String AI_HAS_PRICE = "AI_hasPrice";
    public static final String AI_PRICE = "AI_Price";

    private static final Logger LOGGER = LogManager.getLogger(BatchUpdatePartPriceProcessor.class.getName());
    private static final Gson gson = new Gson();

    @Override
    public FormResult doOperation(NmCommandBean nmcb, List<ObjectBean> paramList) throws WTException {
        FormResult result = super.doOperation(nmcb, paramList);
        String priceMaintainerJson = nmcb.getRequest().getParameter("priceMaintainerJson");

        if (StringUtils.isEmpty(priceMaintainerJson)) {
            throw new WTException("价格维护数据不能为空！");
        }

        LOGGER.debug("价格维护 JSON: " + priceMaintainerJson);
        System.out.println("价格维护 JSON: " + priceMaintainerJson);

        // 解析PBOM结构JSON - 获取多个父部件列表
        List<PriceMaintainerVO> priceMaintainerList = parseVOStructure(priceMaintainerJson);
        for (PriceMaintainerVO priceMaintainerVO : priceMaintainerList) {
            try {
                batchUpdatePrice(priceMaintainerVO);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }


        return result;
    }

    public static void batchUpdatePrice(PriceMaintainerVO vo) throws Exception {
        String partNumber = vo.getPartNumber();
        String aiHasPrice = vo.getAiHasPrice();
        String aiPrice = vo.getAiPrice();

        WTPart designPart = PartUtil.getLatestWTPart(partNumber, "Design");
        // 检查 WTPart 是否有效
        if (designPart == null) {
            throw new Exception("未找到零件: " + partNumber);
        }
        IBAUtil ibaUtil = new IBAUtil(designPart);
        ibaUtil.setIBAAttribute4AllType(designPart, AI_HAS_PRICE, aiHasPrice);
        ibaUtil.setIBAAttribute4AllType(designPart, AI_PRICE, aiPrice);
    }


    /**
     * 解析PBOM结构JSON
     */
    private List<PriceMaintainerVO> parseVOStructure(String jsonStr) {
        List<PriceMaintainerVO> result = new ArrayList<>();
        try {
            Type listType = new TypeToken<List<PriceMaintainerVO>>() {
            }.getType();
            result = gson.fromJson(jsonStr, listType);
        } catch (Exception e) {
            LOGGER.error("解析PBOM结构JSON失败: " + e.getMessage(), e);
            throw new RuntimeException("解析PBOM结构JSON失败: " + e.getMessage(), e);
        }
        return result;

    }


}