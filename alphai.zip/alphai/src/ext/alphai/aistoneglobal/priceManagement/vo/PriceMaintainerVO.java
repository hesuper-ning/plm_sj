package ext.alphai.aistoneglobal.priceManagement.vo;

public class PriceMaintainerVO {
    private String partNumber;
    private String aiPrice;
    private String aiHasPrice;

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getAiPrice() {
        return aiPrice;
    }

    public void setAiPrice(String aiPrice) {
        this.aiPrice = aiPrice;
    }

    public String getAiHasPrice() {
        return aiHasPrice;
    }

    public void setAiHasPrice(String aiHasPrice) {
        this.aiHasPrice = aiHasPrice;
    }
}
