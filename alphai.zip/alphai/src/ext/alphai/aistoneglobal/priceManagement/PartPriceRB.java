package ext.alphai.aistoneglobal.priceManagement;
import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.priceManagement.PartPriceRB")
public class PartPriceRB extends WTListResourceBundle {

    @RBEntry("Promote Part")
    public static final String countPart = "countPart";

    @RBEntry("Price")
    public static final String AI_PRICE = "AI_Price";

    @RBEntry("HasPrice")
    public static final String AI_HAS_PRICE = "AI_hasPrice";

    @RBEntry("Promote Part")
    public static final String countPart_DESC = "price.promotePart.description";

    @RBEntry("Promote Part")
    public static final String countPart_TOOLTIP = "price.promotePart.tooltip";

    @RBEntry("Price Maintainer")
    public static final String Price_DESC = "price.priceMaintainer.description";

    @RBEntry("Price Maintainer")
    public static final String Price_TOOLTIP = "price.priceMaintainer.tooltip";

    @RBEntry("chk_uniqueness.gif")
    public static final String Price_ICON = "price.priceMaintainer.icon";



}
