package ext.alphai.aistoneglobal.priceManagement.builder;
import com.ptc.core.components.descriptor.DescriptorConstants;
import com.ptc.jca.mvc.components.JcaColumnConfig;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.object.mvc.helper.ItemIdVersion;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.aistoneglobal.priceManagement.PartPriceRB;
import ext.alphai.aistoneglobal.priceManagement.service.PriceManagementService;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.util.WTException;
import wt.workflow.work.WorkItem;

@ComponentBuilder("ext.alphai.aistoneglobal.priceManagement.builder.PartPriceTable")
public class PartPriceTable extends AbstractComponentBuilder {
    public static final String RESOURCECLASS = PartPriceRB.class.getName();

    private final ClientMessageSource messageSource = getMessageSource(PartPriceRB.class.getName());

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig config = factory.newTableConfig();
        config.setType(WTPart.class.getName());

        config.setLabel(messageSource.getMessage(PartPriceRB.countPart));//table标题
        config.setSelectable(true);
        config.setShowCount(true);
        config.setShowCustomViewLink(true);
        config.setSelectable(true);
        config.setActionModel("PartPriceTableOperate");

        ColumnConfig oidColumn = factory.newColumnConfig("oid", true);
        oidColumn.setHidden(true);
        oidColumn.setSortable(true);
        config.addComponent(oidColumn);

        //逻辑标识
//        config.addComponents(ItemIdVersion.getColumnConfigs(factory));
        //图标
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.ICON, true));
        //编号
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.NUMBER, true));

        ColumnConfig name = factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.NAME, true);
        //设置链接
        name.setInfoPageLink(true);

        config.addComponent(name);

        //是否有价
        ColumnConfig JC_CNNAME = factory.newColumnConfig("AI_hasPrice", true);
        JC_CNNAME.setLabel(messageSource.getMessage(PartPriceRB.AI_HAS_PRICE));
        config.addComponent(JC_CNNAME);

        //价格
        ColumnConfig AI_NAME_EN = factory.newColumnConfig("AI_Price", true);
        AI_NAME_EN.setLabel(messageSource.getMessage(PartPriceRB.AI_PRICE));
        config.addComponent(AI_NAME_EN);

        //版本
        JcaColumnConfig version = ((JcaColumnConfig)factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.VERSION, true));
        version.setDescriptorProperty("display", "VERSION");
        config.addComponent(version);
        //查看信息
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.INFO_ACTION, true));
        //生命周期
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.STATE, true));
        //修改者
        config.addComponent(factory.newColumnConfig(DescriptorConstants.ColumnIdentifiers.MODIFIED_BY, true));

        return config;
    }


    //table数据
    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        JcaComponentParams jca_params = (JcaComponentParams) componentParams;
        NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
        NmOid primaryOid2 = cb.getPrimaryOid();
        WorkItem workItem = null;
        if (primaryOid2 == null)
            return null;
        Object content = primaryOid2.getRef();
        if (content instanceof WorkItem) {
            workItem = (WorkItem) content;
        }

        WTObject pbo = PriceManagementService.getPBOByWorkItem(workItem);

        return PriceManagementService.getPartListByPBO(pbo);
    }



}
