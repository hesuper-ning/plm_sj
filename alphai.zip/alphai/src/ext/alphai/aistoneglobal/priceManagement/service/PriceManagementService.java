package ext.alphai.aistoneglobal.priceManagement.service;

import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.Promotable;
import wt.maturity.PromotionNotice;
import wt.maturity.PromotionTarget;
import wt.part.WTPart;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.workflow.work.WorkItem;

import java.util.ArrayList;
import java.util.List;

public class PriceManagementService {

    /**
     * 通过workitem获取pbo
     *
     * @param workItem
     * @return pbo
     */
    public static WTObject getPBOByWorkItem(WorkItem workItem) {
        WTObject pbo = null;
        boolean origEnforce = false;
        try {
            origEnforce = SessionServerHelper.manager.setAccessEnforced(false);
            pbo = (WTObject) workItem.getPrimaryBusinessObject().getObject();
        } catch (NullPointerException nex) {
            pbo = null;
        } finally {
            SessionServerHelper.manager.setAccessEnforced(origEnforce);
        }
        return pbo;
    }

    public static List<WTPart> getPartListByPBO(WTObject pbo) throws WTException {
        List<WTPart> wtParts = new ArrayList<>();
        //pbo--->ECA
        if (pbo instanceof WTChangeActivity2) {
            WTChangeActivity2 eca = (WTChangeActivity2) pbo;
            //获取产生对象的部件
            wtParts.addAll(getChangeablesAfterPartsByECA(eca));
        } else if (pbo instanceof PromotionNotice) {
            PromotionNotice pn = (PromotionNotice) pbo;
            //获取升级对象的部件
            wtParts.addAll(getTargerObjectByPromotionNotices(pn));
        }


        //获取历史防重技术号部件
        return  wtParts;
    }


    /**
     * 获取产生对象的部件
     * @param eca
     * @return
     * @throws WTException
     */
    public static List<WTPart> getChangeablesAfterPartsByECA(WTChangeActivity2 eca) throws WTException {
        List<WTPart> wtParts = new ArrayList<>();
        //ECA获取产生对象  true是直接获取对象
        QueryResult links = ChangeHelper2.service.getChangeablesAfter(eca);
        while (links.hasMoreElements()) {
            Object obj = links.nextElement();
            //只获取部件
            if (obj instanceof WTPart) {
                wtParts.add((WTPart) obj);
            }
        }

        return wtParts;
    }


    /**
     * 获取升级请求中被升级的对象 ---部件
     *
     * @return ArrayList<WTObject>
     * @throws WTException
     */
    public static List<WTPart> getTargerObjectByPromotionNotices(PromotionNotice pn) throws WTException {
        List<WTPart> list = new ArrayList<WTPart>();
        //pn获取升级对象
        QueryResult qr = MaturityHelper.service.getPromotionTargets(pn, false);
        while (qr.hasMoreElements()) {
            PromotionTarget pt = (PromotionTarget) qr.nextElement();
            Promotable ptObj = pt.getPromotable();
            if (ptObj instanceof  WTPart){
                list.add((WTPart) ptObj);
            }
        }
        return list;
    }
}
