package ext.alphai.aistoneglobal.priceManagement;
import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.aistoneglobal.priceManagement.PartPriceRB_zh_CN")
public class PartPriceRB_zh_CN extends WTListResourceBundle {


    @RBEntry("升级部件")
    public static final String countPart = "countPart";

    @RBEntry("价格")
    public static final String AI_PRICE = "AI_Price";

    @RBEntry("是否有价")
    public static final String AI_HAS_PRICE = "AI_hasPrice";

    @RBEntry("升级部件")
    public static final String countPart_DESC = "price.promotePart.description";

    @RBEntry("升级部件")
    public static final String countPart_TOOLTIP = "price.promotePart.tooltip";

    @RBEntry("价格维护")
    public static final String Price_DESC = "price.priceMaintainer.description";

    @RBEntry("价格维护")
    public static final String Price_TOOLTIP = "price.priceMaintainer.tooltip";

    @RBEntry("chk_uniqueness.gif")
    public static final String Price_ICON = "price.priceMaintainer.icon";


}
