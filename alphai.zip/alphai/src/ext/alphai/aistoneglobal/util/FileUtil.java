//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package ext.alphai.aistoneglobal.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileUtil {
    private static final int SIZE = 8192;
    public static final SimpleDateFormat YYYYMM = new SimpleDateFormat("yyyy-MM");
    public static final SimpleDateFormat YYYYMMDDHHMMSS = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    public static final String TYPE_JPG = "jpg";
    public static final String TYPE_GIF = "gif";
    public static final String TYPE_PNG = "png";
    public static final String TYPE_BMP = "bmp";
    public static final String TYPE_UNKNOWN = "unknown";
    public static final String FORMAT_FILE_NAME = "%d.%s";
    private static byte[] b;

    private FileUtil() throws Exception {
        throw new Exception("Cannot be instantiated");
    }

    public static String readBytesToString(InputStream is) {
        return new String(readBytes(is));
    }

    public static String readBytesToString(InputStream is, String charsetName) {
        try {
            return new String(readBytes(is), charsetName);
        } catch (UnsupportedEncodingException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static String readBytesToString(File file, String charsetName) {
        try {
            return new String(readBytes(file), charsetName);
        } catch (UnsupportedEncodingException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static String readBytesToString(File file) {
        return new String(readBytes(file));
    }

    public static String readCharsToString(File file) {
        try {
            return readCharsToString((InputStream)(new FileInputStream(file)), (String)null);
        } catch (FileNotFoundException var2) {
            var2.printStackTrace();
            return null;
        }
    }

    public static String readCharsToString(File file, String charset) {
        try {
            return readCharsToString((InputStream)(new FileInputStream(file)), charset);
        } catch (FileNotFoundException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static String readCharsToString(InputStream is) {
        return new String(readChars((InputStream)is, (String)null));
    }

    public static String readCharsToString(InputStream is, String charsetName) {
        return new String(readChars(is, charsetName));
    }

    public static byte[] readBytes(File file) {
        try {
            return readBytes((InputStream)(new FileInputStream(file)));
        } catch (FileNotFoundException var2) {
            var2.printStackTrace();
            return null;
        }
    }

    public static byte[] readBytes(InputStream is) {
        byte[] bytes = null;

        try {
            BufferedInputStream bis = new BufferedInputStream(is);
            byte[] cbuf = new byte[8192];
            ByteArrayOutputStream outWriter = new ByteArrayOutputStream();

            int len;
            while((len = bis.read(cbuf)) != -1) {
                outWriter.write(cbuf, 0, len);
            }

            outWriter.flush();
            bis.close();
            is.close();
            bytes = outWriter.toByteArray();
            outWriter.close();
        } catch (UnsupportedEncodingException var6) {
            var6.printStackTrace();
        } catch (IOException var7) {
            var7.printStackTrace();
        }

        return bytes;
    }

    public static char[] readChars(File file, String charsetName) {
        try {
            return readChars((InputStream)(new FileInputStream(file)), charsetName);
        } catch (FileNotFoundException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static char[] readChars(InputStream is, String charsetName) {
        char[] chars = null;

        try {
            InputStreamReader isr = null;
            if (charsetName == null) {
                isr = new InputStreamReader(is);
            } else {
                isr = new InputStreamReader(is, charsetName);
            }

            BufferedReader br = new BufferedReader(isr);
            char[] cbuf = new char[8192];
            CharArrayWriter outWriter = new CharArrayWriter();

            int len;
            while((len = br.read(cbuf)) != -1) {
                outWriter.write(cbuf, 0, len);
            }

            outWriter.flush();
            br.close();
            isr.close();
            is.close();
            chars = outWriter.toCharArray();
            outWriter.close();
        } catch (UnsupportedEncodingException var8) {
            var8.printStackTrace();
        } catch (IOException var9) {
            var9.printStackTrace();
        }

        return chars;
    }

    public static void writeBytes(OutputStream os, byte[] text) {
        writeBytes(os, text, 0, text.length);
    }

    public static void writeBytes(OutputStream os, byte[] text, int off, int lenght) {
        try {
            BufferedOutputStream bos = new BufferedOutputStream(os);
            bos.write(text, off, lenght);
            bos.flush();
            bos.close();
            os.close();
        } catch (UnsupportedEncodingException var5) {
            var5.printStackTrace();
        } catch (IOException var6) {
            var6.printStackTrace();
        }

    }

    public static void writeChars(OutputStream os, char[] text, String charsetName) {
        writeChars(os, text, 0, text.length, charsetName);
    }

    public static void writeChars(OutputStream os, char[] text, int off, int lenght, String charsetName) {
        try {
            OutputStreamWriter osw = null;
            if (charsetName == null) {
                osw = new OutputStreamWriter(os);
            } else {
                osw = new OutputStreamWriter(os, charsetName);
            }

            BufferedWriter bw = new BufferedWriter(osw);
            bw.write(text, off, lenght);
            bw.flush();
            bw.close();
            osw.close();
            os.close();
        } catch (UnsupportedEncodingException var7) {
            var7.printStackTrace();
        } catch (IOException var8) {
            var8.printStackTrace();
        }

    }

    public static void writeString(File file, boolean append, String text) {
        writeString(file, append, text, 0, text.length(), (String)null);
    }

    public static void writeString(File file, boolean append, String text, int off, int lenght, String charsetName) {
        try {
            writeString(new FileOutputStream(file, append), text, off, lenght, charsetName);
        } catch (FileNotFoundException var7) {
            var7.printStackTrace();
        }

    }

    public static void writeString(File file, String text) {
        writeString(file, false, text, 0, text.length(), (String)null);
    }

    public static void writeString(File file, boolean append, String text, String charsetName) {
        writeString(file, append, text, 0, text.length(), charsetName);
    }

    public static void writeString(File file, String text, String charsetName) {
        writeString(file, false, text, 0, text.length(), charsetName);
    }

    public static void writeString(OutputStream os, String text, String charsetName) {
        writeString(os, text, 0, text.length(), charsetName);
    }

    public static void writeString(OutputStream os, String text, int off, int lenght, String charsetName) {
        try {
            OutputStreamWriter osw = null;
            if (charsetName == null) {
                osw = new OutputStreamWriter(os);
            } else {
                osw = new OutputStreamWriter(os, charsetName);
            }

            BufferedWriter bw = new BufferedWriter(osw);
            bw.write(text, off, lenght);
            bw.flush();
            bw.close();
            osw.close();
            os.close();
        } catch (UnsupportedEncodingException var7) {
            var7.printStackTrace();
        } catch (IOException var8) {
            var8.printStackTrace();
        }

    }

    public static boolean exists(String path) {
        return exists(new File(path));
    }

    public static boolean exists(File file) {
        return file.exists();
    }

    public static String getExtension(String var0) {
        for(int var1 = var0.length() - 1; var1 >= 0; --var1) {
            if (var0.charAt(var1) == '.') {
                String var2 = var0.substring(var1 + 1, var0.length());
                return var2;
            }
        }

        return new String("");
    }

    public static void createPdfFolder(String path) throws InterruptedException {
        String[] paths = path.split("/");
        StringBuffer fullPath = new StringBuffer();

        for(int i = 0; i < paths.length; ++i) {
            fullPath.append(paths[i]).append("\\\\");
            File file = new File(fullPath.toString());
            if (paths.length - 1 != i && !file.exists()) {
                file.mkdir();
                Thread.sleep(1500L);
            }
        }

    }

    public static void createJpgFolder(String path) throws InterruptedException {
        String[] paths = path.split("/");
        StringBuffer fullPath = new StringBuffer();

        for(int i = 0; i < paths.length; ++i) {
            fullPath.append(paths[i]).append("\\\\");
            File file = new File(fullPath.toString());
            if (!file.exists()) {
                file.mkdir();
                Thread.sleep(1500L);
            }
        }

    }

    public static String getPicType(InputStream fis) {
        b = new byte[4];

        try {
            fis.read(b, 0, b.length);
            String type = bytesToHexString(b).toUpperCase();
            if (type.contains("FFD8FF")) {
                return "jpg";
            } else if (type.contains("89504E47")) {
                return "png";
            } else if (type.contains("47494638")) {
                return "gif";
            } else {
                return type.contains("424D") ? "bmp" : "unknown";
            }
        } catch (IOException var2) {
            var2.printStackTrace();
            return null;
        }
    }

    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder();
        if (src != null && src.length > 0) {
            for(int i = 0; i < src.length; ++i) {
                int v = src[i] & 255;
                String hv = Integer.toHexString(v);
                if (hv.length() < 2) {
                    stringBuilder.append(0);
                }

                stringBuilder.append(hv);
            }

            return stringBuilder.toString();
        } else {
            return null;
        }
    }

    public static void isDirPathExist(File dir) {
        if (dir.isDirectory()) {
            System.out.println(dir + "文件夹已存在");
        } else {
            System.out.println(dir + "文件夹不存在");
            dir.mkdirs();
            System.out.println("创建文件夹" + dir);
        }

    }

    public static void saveImageToDisk(InputStream inputStream, String diskPath, String type) {
        String picType = getPicType(inputStream);
        System.out.println("图片格式为：" + type);
        String fileName = String.format("%d.%s", (new Date()).getTime(), type);
        System.out.println("图片名字为：" + fileName);
        byte[] data = new byte[1024];
        int len = 0;
        FileOutputStream fileOutputStream = null;

        try {
            File dirFile = new File(diskPath);
            isDirPathExist(dirFile);
            fileOutputStream = new FileOutputStream(new File(dirFile, fileName));
            fileOutputStream.write(b, 0, b.length);

            while((len = inputStream.read(data)) != -1) {
                fileOutputStream.write(data, 0, len);
            }

            fileOutputStream.flush();
        } catch (IOException var21) {
            var21.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException var20) {
                    var20.printStackTrace();
                }
            }

            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close();
                } catch (IOException var19) {
                    var19.printStackTrace();
                }
            }

        }

        System.out.println(fileName + "写到本地磁盘完成");
    }

    public static void saveImageToDisk(InputStream inputStream, String diskPath, String type, String fileName) {
        String picType = getPicType(inputStream);
        System.out.println("图片格式为：" + type);
        System.out.println("图片名字为：" + fileName);
        byte[] data = new byte[1024];
        int len = 0;
        FileOutputStream fileOutputStream = null;

        try {
            File imgFile = new File(diskPath + fileName);
            if (imgFile.exists()) {
                imgFile.delete();
            }

            File dirFile = new File(diskPath);
            isDirPathExist(dirFile);
            fileOutputStream = new FileOutputStream(new File(dirFile, fileName));
            fileOutputStream.write(b, 0, b.length);

            while((len = inputStream.read(data)) != -1) {
                fileOutputStream.write(data, 0, len);
            }

            fileOutputStream.flush();
        } catch (IOException var22) {
            var22.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException var21) {
                    var21.printStackTrace();
                }
            }

            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close();
                } catch (IOException var20) {
                    var20.printStackTrace();
                }
            }

        }

        System.out.println(fileName + "写到本地磁盘完成");
    }
}
