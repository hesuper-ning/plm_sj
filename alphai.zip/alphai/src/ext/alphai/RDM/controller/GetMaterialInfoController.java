package ext.alphai.RDM.controller;

import ext.alphai.RDM.bean.ErrorInfoBean;
import ext.alphai.RDM.bean.InfoBean;
import ext.alphai.RDM.service.RDMService;
import ext.alphai.RDM.bean.ResultBean;
import ext.util.PartUtil;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;


public class GetMaterialInfoController implements Controller {

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 设置响应内容类型
        boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
        ResultBean rb = null;
        try {
            // 设置响应内容类型
            response.setContentType("text/json");
            // 获取请求体的读取器
            BufferedReader reader = request.getReader();
            StringBuilder sb = new StringBuilder();
            String line;
            // 逐行读取请求体内容
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            // 获取完整的请求体内容
            String params = sb.toString();
            System.out.println("读取的数据是：" + params);
            JSONObject jsonObject = new JSONObject(params);

            String userId = (String) PartUtil.getJsonParam(jsonObject, "userId");
            JSONArray requests = PartUtil.getJsonArrayParam(jsonObject, "requests");
            JSONArray successArray = new JSONArray();
            JSONArray errorArray = new JSONArray();
            // 遍历数组
            for (int i = 0; i < requests.length(); i++) {
                JSONObject requestJson = requests.getJSONObject(i);
                String number = requestJson.getString("number");
                String type = requestJson.getString("type");

                System.out.println("Request " + (i + 1) + ":");
                System.out.println("  number: " + number);
                System.out.println("  type: " + type);
                System.out.println();
                Object bean = RDMService.getMaterialInfo(number, type);
                if (bean == null) {
                    throw new WTException("Windchill 错误!");
                }
                if (bean instanceof InfoBean) {
                    InfoBean infoBean = (InfoBean) bean;
                    successArray.put(new JSONObject(infoBean));
                    System.out.println("当前的success bean：" + infoBean);
                } else if (bean instanceof ErrorInfoBean) {
                    ErrorInfoBean errorInfoBean = (ErrorInfoBean) bean;
                    errorArray.put(new JSONObject(errorInfoBean));
                    System.out.println("当前的error bean：" + errorInfoBean);
                } else {
                    throw new WTException("Windchill 错误!");
                }
            }
            if (errorArray.length() > 0) {
                rb = ResultBean.newInstance(false, "Partial Success", successArray, errorArray);
            } else {
                rb = ResultBean.newInstance(true, "Success", successArray, "");
            }
        } catch (Exception e) {
            e.printStackTrace();
            rb = new ResultBean("400", "Error", "", e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(enforce);
        }
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        System.out.println("最后输出的bean是：" + rb);
        PrintWriter out = response.getWriter();
        out.print(rb);
        out.flush();
        return null; // 返回 null 表示不需要 ModelAndView
    }


}
