package ext.alphai.RDM.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import ext.alphai.RDM.ResponseVo;
import ext.alphai.RDM.RDMRequestVo;
import ext.alphai.RDM.server.PassRDMServer;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
//import jakarta.servlet.http.HttpServlet;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.mvc.Controller;
public class StartProcessNode implements Controller {
    private static final long serialVersionUID = 1L;
    static final ObjectMapper objectMapper = new ObjectMapper();

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        ResponseVo vo = null;
        // 设置响应内容类型
        boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
        // 设置响应内容类型
        response.setContentType("text/json");
        // 获取请求体的读取器
        BufferedReader reader = request.getReader();
        StringBuilder sb = new StringBuilder();
        String line;
        // 逐行读取请求体内容
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        // 获取完整的请求体内容
        String json = sb.toString();
        RDMRequestVo rdmRequestVo = objectMapper.readValue(json, RDMRequestVo.class);
        String ecnNumber = rdmRequestVo.getOriginal_notice_id();
        System.out.println("RDM调用完成接口："+json+"   RDM流程编号"+rdmRequestVo.getRdm_project_id());
        try {
            vo = PassRDMServer.passRDM(ecnNumber, rdmRequestVo.getRdm_project_id());
        } catch (WTException e){
            e.printStackTrace();
            vo = ResponseVo.error("500", "Windchill错误", "Windchill错误,无法开启流程");
        }
        if("200".equals(vo.getCode())){
            DateTimeFormatter formatter = DateTimeFormatter
                    .ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
                    .withZone(ZoneOffset.UTC);

            // 获取当前 UTC 时间并格式化
            String timestamp = formatter.format(Instant.now());
            Map<String, String> data = new HashMap<String, String>();
            data.put("original_notice_id", ecnNumber);
            data.put("rdm_process_id", rdmRequestVo.getRdm_project_id());
            data.put("timestamp", timestamp);
            vo.setData(data);
        }
        String respJson = objectMapper.writeValueAsString(vo);
        outResponse(response,respJson);
        return null; // 返回 null 表示不需要 ModelAndView
    }

    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }

}
