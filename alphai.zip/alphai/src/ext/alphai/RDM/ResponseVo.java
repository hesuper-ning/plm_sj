package ext.alphai.RDM;

public class ResponseVo {

    public String code;

    public String msg;

    public Object data;

    public String errors;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public ResponseVo(String code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public ResponseVo() {
    }
    public static ResponseVo success(Object object){
        ResponseVo vo = new ResponseVo();
        vo.setCode("200");
        vo.setMsg("变更通告已开启");
        vo.setData(object);
        vo.setErrors("");
        return vo;
    }


    public static ResponseVo success(String code, String msg){
        ResponseVo vo = new ResponseVo();
        vo.setCode(code);
        vo.setMsg(msg);
        vo.setErrors("");
        return vo;
    }


    public static ResponseVo error(String code, String msg, String errors){
        ResponseVo vo = new ResponseVo();
        vo.setCode(code);
        vo.setMsg(msg);
        vo.setErrors(errors);
        return vo;
    }


    public String getErrors() {
        return errors;
    }

    public void setErrors(String errors) {
        this.errors = errors;
    }
}
