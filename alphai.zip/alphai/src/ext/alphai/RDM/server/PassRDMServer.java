package ext.alphai.RDM.server;

import ext.alphai.RDM.ResponseVo;
import ext.alphai.RDM.util.PropertiesUtil;
import ext.util.WorkflowUtil;
import org.apache.commons.lang3.StringUtils;
import wt.change2.WTChangeOrder2;
import wt.fc.*;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.CollationKeyFactory;
import wt.util.SortedEnumeration;
import wt.util.WTException;
import wt.workflow.engine.ProcessData;
import wt.workflow.engine.WfEngineHelper;
import wt.workflow.engine.WfExecutionObject;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

public class PassRDMServer {


    /**
     *  RDM评审结束 发送接口
     * @param object
     * @param rdmProcessId  rdm单据流程编号 流程表达式
     */
    public static void finishRDM(String rdmProcessId) throws IOException {
//        if(object instanceof WTChangeOrder2) {
//            WTChangeOrder2 ecn = (WTChangeOrder2) object;
            // 登录认证
            String token = loginRDM();
            String respJSON = finishRDMReq(token, rdmProcessId);
            System.out.println("完成RDM评审接口返回JSON："+respJSON);
//        }
    }

    public static String loginRDM() throws IOException {
        String token = "";
        String username = PropertiesUtil.getValueByKey("RDM.username");
        String password = PropertiesUtil.getValueByKey("RDM.password");
        String authenticationUrl = PropertiesUtil.getValueByKey("RDM.authentication.url");

        // 构建带参数的 URL
        String authenticationUrlReq = authenticationUrl + "userName=" + username + "&password=" + password;
        System.out.println("RDM访问认证接口："+authenticationUrlReq);
        URL url = new URL(authenticationUrlReq);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        try {
            // 设置请求方法为 POST
            conn.setRequestMethod("POST");
            // 设置可输出（POST 请求需要）
            conn.setDoOutput(true);

            // 添加必要的请求头（根据 API 要求）
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Accept", "application/json");

            // 发送空请求体（参数已在 URL 中）
            try (OutputStream os = conn.getOutputStream()) {
                os.write(new byte[0]); // 发送空请求体
            }

            // 获取响应码
            int responseCode = conn.getResponseCode();

            // 处理成功响应
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (InputStream is = conn.getInputStream();
                     BufferedReader reader = new BufferedReader(
                             new InputStreamReader(is, StandardCharsets.UTF_8))) {

                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    // 假设响应是 JSON 格式：{"token": "value"}
                    // 这里需要根据实际响应结构调整解析逻辑
                    token = response.toString();
                }
            } else {
                // 处理错误响应
                try (InputStream es = conn.getErrorStream();
                     BufferedReader reader = new BufferedReader(
                             new InputStreamReader(es, StandardCharsets.UTF_8))) {

                    StringBuilder errorResponse = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        errorResponse.append(line);
                    }
                    throw new IOException("Authentication failed. Response code: " + responseCode
                            + "\nError: " + errorResponse.toString());
                }
            }
        } finally {
            conn.disconnect(); // 确保断开连接
        }

        return token;
    }


    /**
     * 调用RDM  完成接口
     * @param token
     * @param rdmProcessId RDM单据编号
     * @return
     */
    public static String finishRDMReq(String token, String rdmProcessId) {
        try {
            // 从配置获取URL
            String finishRDMUrl = PropertiesUtil.getValueByKey("RDM.finish.url");

            // 对参数进行URL编码（重要！）
            String encodedToken = URLEncoder.encode(token, StandardCharsets.UTF_8.name());
            String encodedRdmId = URLEncoder.encode(rdmProcessId, StandardCharsets.UTF_8.name());

            // 构建带参数的URL
            String finishRDMUrlReq = finishRDMUrl
                    + "token=" + encodedToken
                    + "&objectType=CHG"
                    + "&objectId=" + encodedRdmId
                    + "&status=9868b1ae-6104-4aa1-8d4b-22c479d88e77";
            System.out.println("RDM访问完成RDM评审接口："+finishRDMUrlReq);
            URL url = new URL(finishRDMUrlReq);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            try {
                // 设置请求方法为POST
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                // 设置必要的请求头
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestProperty("Accept", "application/json");

                // 发送空请求体（参数已在URL中）
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(new byte[0]);
                }

                // 设置超时时间
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(10000);

                // 获取响应码
                int responseCode = conn.getResponseCode();

                // 读取响应
                try (InputStream is = (responseCode >= 200 && responseCode < 300)
                        ? conn.getInputStream()
                        : conn.getErrorStream();
                     BufferedReader reader = new BufferedReader(
                             new InputStreamReader(is, StandardCharsets.UTF_8))) {

                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    // 根据响应格式返回JSON
                    return response.toString();
                }
            } finally {
                conn.disconnect();
            }
        } catch (Exception e) {
            // 返回标准错误格式JSON
            return "{\"error\":{\"code\":\"EXCEPTION\",\"msg\":\"" + e.getMessage() + "\"}}";
        }
    }







    public static ResponseVo passRDM(String ecnNumber, String rdmProcessId) throws WTException {
        ResponseVo vo = null;
        WTChangeOrder2 ecn = getECNByNumber(ecnNumber);
        WfProcess wfProcess = null;
        if(ecn == null){
            vo = ResponseVo.error("400", "流程数据验证失败","变更通告编号"+ecnNumber+"不存在");
        }else {
            try {
                wfProcess = getRelatedProcess(ecn);
            } catch (Exception e) {
                e.printStackTrace();
                vo = ResponseVo.error("500","Windchill错误", "Windchill错误,无法开启流程 205");
            }
            if(wfProcess == null){
                vo = ResponseVo.error("500","Windchill错误", "Windchill错误,无法开启流程 208");
            } else {
                ArrayList<WfAssignedActivity> wfAssignedActivityList = getWfAssignedActivitys(wfProcess);
                for (WfAssignedActivity wfAssignedActivity : wfAssignedActivityList) {
//                        System.out.println("流程中活动的名称"+wfAssignedActivity.getName());
                    if ("RDM评审".equals(wfAssignedActivity.getName())) {
                        ArrayList<WorkItem> activityWorkItems = getActivityWorkItems(wfAssignedActivity);
                        Vector v = new Vector();
                        v.addElement("批准");
                        for (WorkItem workItem : activityWorkItems) {
                            try {
                                WorkflowHelper.service.workComplete(workItem, workItem.getOwnership().getOwner(), v);
                            } catch (WTException e) {
                                e.printStackTrace();
                            }
                        }
                        try {
                            WorkflowHelper.service.completeActivity(ObjectReference.newObjectReference(wfAssignedActivity),"批准");
                        } catch (WTException e) {
                            e.printStackTrace();
                            vo = ResponseVo.error("500","Windchill错误", "Windchill错误,无法开启流程 228");
                        }
                        System.out.println("自动完成RDM评审");
                        vo = ResponseVo.success("200", "变更通告已开启");
                    }
                }

                // 将 RDM流程单据设置到流程变量中
                setProcessValue(wfProcess, "rdmProcessId", rdmProcessId);
            }
        }

        return vo;
    }



    /**
     * 根据持久化对象获取相关联的流程
     *
     * @param ecn
     * @return WfProcess
     * @throws Exception
     */
    public static WfProcess getRelatedProcess(WTChangeOrder2 ecn) throws Exception {
//        System.out.println("变更单编号："+doc.getNumber());
        WfProcess process = null;
        QueryResult qrProcs = null;
        qrProcs = WfEngineHelper.service.getAssociatedProcesses(ecn, null, null);
//        System.out.println("qrProcs:"+qrProcs.hasMoreElements());
        // 按时间排序,取最新一个流程实例
        CollationKeyFactory timeKeyFact = new CollationKeyFactory() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

            public String getCollationString(Object o) {
                if (!(o instanceof Persistable) || !PersistenceHelper.isPersistent(o))
                    return "";
                return sdf.format(PersistenceHelper.getModifyStamp((Persistable) o));
            }
        };
        Enumeration enProcs = new SortedEnumeration(qrProcs, timeKeyFact, SortedEnumeration.DESCENDING);
        while (enProcs.hasMoreElements()) {
            process = (WfProcess) enProcs.nextElement();
//            System.out.println("变更单关联的流程："+process.getName());
            // 最新的非子进程（子进程的名称带有$符号
            if (process.getName().indexOf("$") == -1) {
                break;
            }
        }
        return process;
    }




    @SuppressWarnings("deprecation")
    public static WTChangeOrder2 getECNByNumber(String number) {
        try {
            if (StringUtils.isBlank(number)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(WTChangeOrder2.class);
            qs.appendWhere(
                    new SearchCondition(WTChangeOrder2.class, WTChangeOrder2.NUMBER, SearchCondition.EQUAL, number));
            QueryResult qr = PersistenceHelper.manager.find(qs);
//            qr = new LatestConfigSpec().process(qr);
//            System.out.println("查询的相关个数是：" + qr.size());
            if (qr.hasMoreElements()) {
                WTChangeOrder2 ecn = (WTChangeOrder2) qr.nextElement();
                System.out.println("ECN 名称为："+ecn.getName());
                return ecn;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 获取流程中的所有活动
     *
     * @param process
     * @return ArrayList<WfAssignedActivity>
     */
    public static ArrayList<WfAssignedActivity> getWfAssignedActivitys(WfProcess process) {
        ArrayList<WfAssignedActivity> list = new ArrayList<WfAssignedActivity>();
        try {
            QuerySpec qs = new QuerySpec(WfAssignedActivity.class);
            qs.appendWhere(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key.id",
                    SearchCondition.EQUAL, process.getPersistInfo().getObjectIdentifier().getId()), new int[] { 0 });
            QueryResult qr = PersistenceHelper.manager.find(qs);
            while (qr.hasMoreElements()) {
                WfAssignedActivity act = (WfAssignedActivity) qr.nextElement();
                list.add(act);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }



    /**
     * 获取同一个活动下的所有任务
     *
     * @param WfAssignedActivity
     * @return ArrayList<WorkItem>
     */
    public static ArrayList<WorkItem> getActivityWorkItems(WfAssignedActivity wfActivity) {
        ArrayList<WorkItem> list = new ArrayList<WorkItem>();
        try {
            Enumeration activityEnum = wfActivity.getAllAssignments();
            while (activityEnum.hasMoreElements()) {
                WfAssignment assignment = (WfAssignment) activityEnum.nextElement();
                if (assignment != null) {
                    QueryResult qr = PersistenceHelper.manager.navigate(assignment, WorkItemLink.WORK_ITEM_ROLE,
                            WorkItemLink.class);
                    while (qr.hasMoreElements()) {
                        list.add((WorkItem) qr.nextElement());
                    }
                }
            }

            Enumeration activityEnum1 = wfActivity.getAssignments();
            while (activityEnum1.hasMoreElements()) {
                WfAssignment assignment = (WfAssignment) activityEnum1.nextElement();
                if (assignment != null) {
                    QueryResult qr = PersistenceHelper.manager.navigate(assignment, "workItem", WorkItemLink.class);
                    if (qr.size() > 0) {
                        while (qr.hasMoreElements()) {
                            list.add((WorkItem) qr.nextElement());
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }






    /**
     * 保存流程变量
     *
     * @param key
     * @param value
     * @throws WTException
     */
    public static void setProcessValue(WfProcess process, String key, Object value) throws WTException {
        try {
            System.out.println("设置流程变量key:"+key+"值为："+value);
            WfExecutionObject wfObject = (WfExecutionObject) PersistenceHelper.manager.refresh(process);
            ProcessData data = wfObject.getContext();
            data.setValue(key, value);
            PersistenceHelper.manager.modify(wfObject);
            PersistenceHelper.manager.refresh(wfObject);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        }

    }
}
