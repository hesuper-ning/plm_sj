package ext.alphai.RDM;

import java.util.List;

public class RDMRequestVo {
    private String original_notice_id;
    private String rdm_project_id;
    private String creator_email;
    private List<ChangeObject> change_objects;

    public String getOriginal_notice_id() {
        return original_notice_id;
    }

    public void setOriginal_notice_id(String original_notice_id) {
        this.original_notice_id = original_notice_id;
    }

    public String getRdm_project_id() {
        return rdm_project_id;
    }

    public void setRdm_project_id(String rdm_project_id) {
        this.rdm_project_id = rdm_project_id;
    }

    public String getCreator_email() {
        return creator_email;
    }

    public void setCreator_email(String creator_email) {
        this.creator_email = creator_email;
    }

    public List<ChangeObject> getChange_objects() {
        return change_objects;
    }

    public void setChange_objects(List<ChangeObject> change_objects) {
        this.change_objects = change_objects;
    }

}
