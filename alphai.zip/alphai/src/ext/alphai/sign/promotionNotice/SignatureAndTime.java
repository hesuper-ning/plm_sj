package ext.alphai.sign.promotionNotice;

import ext.alphai.doBot.util.IBAUtil;
import ext.alphai.sign.promotionNotice.utils.PropertiesUtil;
import ext.alphai.sign.promotionNotice.utils.WorkFlowUtil;
import org.json.JSONObject;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.WTObject;
import wt.maturity.PromotionNotice;
import wt.util.WTException;
import wt.workflow.engine.ProcessData;
import wt.workflow.engine.WfProcess;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;


public class SignatureAndTime {


    /***
     * 流程反签，流程审批人、审批时间、备注等信息写到流程变量中
     *
     * @description @param ObjectReference @param primaryBusinessObject @param
     * 当前角色名称 @return @throws
     */

    //保存属性
    public static String saveReviewToVar(ObjectReference self, WTObject pbo, String roleName) {
        try {
            System.out.println("Save reviewer for role :" + roleName);
            String values[] = WorkFlowUtil.getWorkFlowInfo(self);
            // 当前审核人员
            Persistable object = self.getObject();
            if (object instanceof WfProcess) {
                WfProcess wfprocess = (WfProcess) object;
                ProcessData context = wfprocess.getContext();
                Object value = context.getValue("reviewer");
                if (value != null && value instanceof String && !"".equalsIgnoreCase((String) (value))) {
                    String oldValue = (String) value;
                    JSONObject jsonObject = new JSONObject(oldValue);
                    jsonObject.put(roleName, values);
                    context.setValue("reviewer", jsonObject.toJSONString());
                    return jsonObject.toJSONString();
                } else {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(roleName, values);
                    context.setValue("reviewer", jsonObject.toJSONString());
                    return jsonObject.toJSONString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "{}";
    }


    public static void setEPMAttribute(WTObject primaryBusinessObject, ObjectReference or,String roleNames) throws Exception {
        HashMap<String, Vector<String[]>> signInfo = WorkFlowUtil.getSignInfo(or);
        String[] roles = roleNames.split(",");

        PromotionNotice pn = WorkFlowUtil.getPromotionNotices(primaryBusinessObject);
        //获取流程模板名称
        WfProcess processByPbo = WorkFlowUtil.getProcessByPbo(primaryBusinessObject);
        String processName = processByPbo.getTemplate().getName();

        //变更请求实例名称
        System.out.println("流程模板名称"+processName);
        //pn.get
        List<EPMDocument> promotionEPMsByPN = getPromotionEPMsByPN(pn);

        for (EPMDocument epmDocument : promotionEPMsByPN) {
            for (String role : roles) {
                String roleIBAKey = PropertiesUtil.getValueByKey("ai."+processName+"."+role) ;
                String dateIBAKey = PropertiesUtil.getValueByKey("ai."+processName+"."+role+"时间");

                if (roleIBAKey.isEmpty() ){
                    System.out.println("未找到"+"ai."+processName+"."+role+"对应iba值");
                    break;
                }

                if (dateIBAKey.isEmpty() ){
                    System.out.println("未找到"+"ai."+processName+"."+role+"时间"+"对应iba值");
                    break;

                }

                IBAUtil ibaUtil = new IBAUtil(epmDocument);
                Vector<String[]> value = signInfo.get(role.trim());
                //修改属性
                ibaUtil.setIBAAttribute4AllType(epmDocument,roleIBAKey,value.get(0)[0]);
                ibaUtil.setIBAAttribute4AllType(epmDocument,dateIBAKey,value.get(0)[1].replace(".", "-"));
            }
        }

    }

    public static List<EPMDocument> getPromotionEPMsByPN(PromotionNotice pn){
        List<EPMDocument> epms = new ArrayList<>();

        //获取升级请求
        try {
            List<WTObject> objects = WorkFlowUtil.getTargerObjectByPromotionNotices(pn);
            for (WTObject object : objects) {
                if (object instanceof EPMDocument) {
                    EPMDocument epm = (EPMDocument)object;
                    epms.add(epm);
                }
            }
        } catch (WTException e) {
            throw new RuntimeException(e);
        }
        return epms;
    }








}
