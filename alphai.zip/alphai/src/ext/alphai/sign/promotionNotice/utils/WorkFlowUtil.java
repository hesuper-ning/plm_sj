package ext.alphai.sign.promotionNotice.utils;

import com.ptc.netmarkets.model.NmOid;
import com.ptc.windchill.enterprise.workflow.WfDataUtilitiesHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.access.AdHocAccessKey;
import wt.access.AdHocControlled;
import wt.change2.VersionableChangeItem;
import wt.enterprise.RevisionControlled;
import wt.fc.*;
import wt.httpgw.URLFactory;
import wt.maturity.MaturityHelper;
import wt.maturity.Promotable;
import wt.maturity.PromotionNotice;
import wt.maturity.PromotionTarget;
import wt.method.RemoteAccess;
import wt.org.WTPrincipalReference;
import wt.query.*;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.CollationKeyFactory;
import wt.util.SortedEnumeration;
import wt.util.WTException;
import wt.workflow.definer.WfAssignedActivityTemplate;
import wt.workflow.definer.WfProcessTemplate;
import wt.workflow.engine.*;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WfAssignment;
import wt.workflow.work.WorkItem;
import wt.workflow.work.WorkItemLink;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

public class WorkFlowUtil implements RemoteAccess {
	public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	/**
	 * 获取升级请求中被升级的对象
	 * 
	 * @param pn
	 * @return ArrayList<WTObject>
	 * @throws WTException
	 */
	public static List<WTObject> getTargerObjectByPromotionNotices(PromotionNotice pn) throws WTException {

		System.out.println("获取被升级对象");
		List<WTObject> list = new ArrayList<WTObject>();
		QueryResult qr = MaturityHelper.service.getPromotionTargets(pn, false);
		while (qr.hasMoreElements()) {
			PromotionTarget pt = (PromotionTarget) qr.nextElement();
			Promotable ptObj = pt.getPromotable();
			list.add((WTObject) ptObj);
		}
		return list;
	}



	/**
	 * 根据流程中的self获取WfProcess对象
	 * 
	 * @param self
	 * @return WfProcess
	 */
	public static WfProcess getProcess(ObjectReference self) {
		Persistable persistable = self.getObject();
		if (persistable == null) {
			return null;
		}
		try {
			// 通过WorkItem获取流程
			if (persistable instanceof WorkItem) {
				persistable = ((WorkItem) persistable).getSource().getObject();
			}
			// 通过WfActivity获取流程
			if (persistable instanceof WfActivity) {
				persistable = ((WfActivity) persistable).getParentProcess();
			}
			// 通过WfConnector获取流程
			if (persistable instanceof WfConnector) {
				persistable = ((WfConnector) persistable).getParentProcessRef().getObject();
			}
			// 通过WfBlock获取流程
			if (persistable instanceof WfBlock) {
				persistable = ((WfBlock) persistable).getParentProcess();
			}
			// 转换成流程对象
			if (persistable instanceof WfProcess) {
				return (WfProcess) persistable;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 通过任务（WorkItem）获取WfProcess对象
	 * 
	 * @param wi
	 * @return WfProcess
	 */
	public static WfProcess getProcess(WorkItem wi) {
		return (WfProcess) wi.getSource().getObject();
	}

	/**
	 * 根据评审对象（PBO）获取WfProcess对象
	 * 
	 * @param obj
	 * @return WfProcess
	 */
	@SuppressWarnings("deprecation")
	public static WfProcess getProcessByPbo(WTObject obj) {
		WfProcess process = null;
		try {
			String pboId = "";
			if (obj instanceof VersionableChangeItem) {
				pboId = "VR:" + obj.getClass().getName() + ":"
						+ ((VersionableChangeItem) obj).getIterationInfo().getBranchId();
				;
			} else if (obj instanceof RevisionControlled) {
				pboId = "VR:" + obj.getClass().getName() + ":"
						+ ((RevisionControlled) obj).getIterationInfo().getBranchId();
			} else if (obj instanceof PromotionNotice) {
				PromotionNotice pn = (PromotionNotice) obj;
				pboId = "OR:" + obj.getClass().getName() + ":" + pn.getPersistInfo().getObjectIdentifier().getId();
			} else {
				return null;
			}
			QuerySpec qs = new QuerySpec(WfProcess.class);
			qs.appendWhere(new SearchCondition(WfProcess.class, WfProcess.BUSINESS_OBJ_REFERENCE, SearchCondition.EQUAL,
					pboId));
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while (qr != null && qr.hasMoreElements()) {
				WfProcess tmpProcess = (WfProcess) qr.nextElement();
				if (process == null) {
					process = tmpProcess;
				} else {
					if (tmpProcess.getStartTime().after(process.getStartTime())) {
						process = tmpProcess;
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return process;
	}

	/**
	 * 将自定义的变量添加到流程中去
	 * 
	 * @param self
	 * @param key
	 * @param value
	 * @throws WTException
	 */
	public static void setProcessValue(ObjectReference self, String key, Object value) throws WTException {
		try {
			WfProcess process = getProcess(self);
			WfExecutionObject wfObject = (WfExecutionObject) PersistenceHelper.manager.refresh(process);
			ProcessData data = wfObject.getContext();
			data.setValue(key, value);
			PersistenceHelper.manager.modify(wfObject);
			PersistenceHelper.manager.refresh(wfObject);
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}
	}

	/**
	 * 将自定义的变量加到活动中去
	 *
	 * @param self
	 * @param key
	 * @param obj
	 * @throws WTException
	 */
	public static void setActivityValue(ObjectReference self, String key, Object obj) {
		try {
			WfExecutionObject p = (WfExecutionObject) self.getObject();
			ProcessData data = p.getContext();
			data.setValue(key, obj);
			PersistenceHelper.manager.modify(p);
			PersistenceHelper.manager.refresh(p);
		} catch (WTException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取流程中所有的任务
	 * 
	 * @param process
	 * @return ArrayList<WorkItem>
	 */
	@SuppressWarnings("deprecation")
	public static ArrayList<WorkItem> getWorkItemByProcess(WfProcess process) {
		ArrayList<WorkItem> list = new ArrayList<WorkItem>();
		if (process == null) {
			return list;
		}
		try {
			QuerySpec qs = new QuerySpec();
			int wfAssignedActivityIndex = qs.addClassList(WfAssignedActivity.class, true);
			int workItemIndex = qs.addClassList(WorkItem.class, true);
			qs.appendWhere(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key.id",
					SearchCondition.EQUAL, process.getPersistInfo().getObjectIdentifier().getId()),
					wfAssignedActivityIndex);
			qs.appendAnd();
			qs.appendWhere(new SearchCondition(WorkItem.class, "source.key.id", WfAssignedActivity.class,
					"thePersistInfo.theObjectIdentifier.id"), workItemIndex, wfAssignedActivityIndex);
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while (qr != null && qr.hasMoreElements()) {
				Object[] objs = (Object[]) qr.nextElement();
				Object obj = objs[1];
				if (obj instanceof WorkItem) {
					list.add((WorkItem) obj);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 获取流程中的所有活动
	 * 
	 * @param process
	 * @return ArrayList<WfAssignedActivity>
	 */
	public static ArrayList<WfAssignedActivity> getWfAssignedActivitys(WfProcess process) {
		ArrayList<WfAssignedActivity> list = new ArrayList<WfAssignedActivity>();
		try {
			QuerySpec qs = new QuerySpec(WfAssignedActivity.class);
			qs.appendWhere(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key.id",
					SearchCondition.EQUAL, process.getPersistInfo().getObjectIdentifier().getId()), new int[] { 0 });
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while (qr.hasMoreElements()) {
				WfAssignedActivity act = (WfAssignedActivity) qr.nextElement();
				list.add(act);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 获取流程中所有的任务
	 * 
	 * @param process
	 * @return ArrayList<WorkItem>
	 * @throws WTException
	 */
	@SuppressWarnings("deprecation")
	public static ArrayList<WorkItem> getInProcessWorkItemByProcess(WfProcess process) throws WTException {
		ArrayList<WorkItem> list = new ArrayList<WorkItem>();
		if (process == null) {
			return list;
		}
		try {
			QuerySpec qs = new QuerySpec();
			int wfAssignedActivityIndex = qs.addClassList(WfAssignedActivity.class, true);
			int workItemIndex = qs.addClassList(WorkItem.class, true);
			qs.appendWhere(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key.id",
					SearchCondition.EQUAL, process.getPersistInfo().getObjectIdentifier().getId()),
					wfAssignedActivityIndex);
			qs.appendAnd();
			qs.appendWhere(new SearchCondition(WorkItem.class, "source.key.id", WfAssignedActivity.class,
					"thePersistInfo.theObjectIdentifier.id"), workItemIndex, wfAssignedActivityIndex);
			qs.appendAnd();
			qs.appendWhere(new SearchCondition(WorkItem.class, WorkItem.STATUS, SearchCondition.NOT_EQUAL, "COMPLETED"),
					workItemIndex);
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while (qr != null && qr.hasMoreElements()) {
				Object[] objs = (Object[]) qr.nextElement();
				Object obj = objs[1];
				if (obj instanceof WorkItem) {
					list.add((WorkItem) obj);
				}
			}
			return list;
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 获取全局未完成的所有任务
	 * 
	 * @return ArrayList<WorkItem>
	 */
	@SuppressWarnings("deprecation")
	public static ArrayList<WorkItem> getUnfinishedWorkItem() {
		ArrayList<WorkItem> list = new ArrayList<WorkItem>();
		try {
			QuerySpec qs = new QuerySpec(WorkItem.class);
			qs.appendWhere(
					new SearchCondition(WorkItem.class, WorkItem.STATUS, SearchCondition.NOT_EQUAL, "COMPLETED"));
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while (qr != null && qr.hasMoreElements()) {
				Object obj = (Object) qr.nextElement();
				if (obj instanceof WorkItem) {
					list.add((WorkItem) obj);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 获取任务对应的URL
	 * 
	 * @param wi
	 * @return String
	 */
	public static String getWorkItemUrl(WorkItem wi) {
		String url = "";
		try {
			URLFactory factory = new URLFactory();
			String resource = "servlet/TypeBasedIncludeServlet";
			HashMap<String, String> map = new HashMap<String, String>();
			NmOid oid = new NmOid();
			oid.setOid(wi.getPersistInfo().getObjectIdentifier());
			map.put("oid", oid.toString());
			map.put("u8", "1");
			oid.setOid(wi.getPersistInfo().getObjectIdentifier());
			String ref1 = factory.getHREF(resource, map);
			if (ref1 != null && ref1.trim().length() > 0) {
				url = ref1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return url;
	}

	/**
	 * 从self中获取工作流中所有任务的URL
	 * 
	 * @param self
	 * @return String
	 */
	public static String getWorkItemUrl(ObjectReference self) {
		String result = "";
		Persistable persistable = self.getObject();
		ArrayList<WorkItem> workItems = new ArrayList<>();
		if (persistable == null) {
			return result;
		}
		if (persistable instanceof WfAssignedActivity) {
			workItems = getWorkItems((WfAssignedActivity) persistable);
			workItems = getActivityWorkItems((WfAssignedActivity) persistable);
		}
		for (WorkItem workItem : workItems) {
			String temp = getWorkItemUrl(workItem);
			result = result + temp + ";";
		}
		return result;
	}

	/**
	 * 获取任务的审计对象
	 * 
	 * @param wi
	 * @return WfVotingEventAudit
	 */
	@SuppressWarnings("deprecation")
	public static WfVotingEventAudit getVoting(WorkItem wi) {
		WfVotingEventAudit wa = null;
		try {
			QuerySpec qs = new QuerySpec(WfVotingEventAudit.class);
			qs.appendWhere(new SearchCondition(WfVotingEventAudit.class, "theWorkItemReference.key.id",
					SearchCondition.EQUAL, wi.getPersistInfo().getObjectIdentifier().getId()));
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while (qr != null && qr.hasMoreElements()) {
				wa = (WfVotingEventAudit) qr.nextElement();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return wa;
	}

	/**
	 * 赋予用户流程编辑权限
	 * 
	 * @param process
	 */
	@SuppressWarnings("deprecation")
	public static void giveAccessWorkflow(WfProcess process) {
		try {
			WTPrincipalReference ref = SessionHelper.manager.getPrincipalReference();
			Vector<AccessPermission> vector = new Vector<>();
			vector.add(AccessPermission.MODIFY);
			AccessControlHelper.manager.addPermissions((AdHocControlled) process, ref, vector,
					AdHocAccessKey.WNC_ACCESS_CONTROL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 收回/移除用户流程编辑权限
	 * 
	 * @param process
	 */
	@SuppressWarnings("deprecation")
	public static void removeAccessWorkflow(WfProcess process) {
		try {
			WTPrincipalReference ref = SessionHelper.manager.getPrincipalReference();
			Vector<AccessPermission> vector = new Vector<>();
			vector.add(AccessPermission.MODIFY);
			AccessControlHelper.manager.removePermissions((AdHocControlled) process, ref, vector,
					AdHocAccessKey.WNC_ACCESS_CONTROL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取任务的路由选择
	 * 
	 * @param itemList
	 * @param actName
	 * @return String
	 */
	public static String getEvent(ArrayList<WorkItem> itemList, String actName) {
		String voting = "";
		if (actName != null && actName.trim().length() > 0) {
			Timestamp ts = null;
			for (WorkItem item : itemList) {
				WfAssignedActivity waa = (WfAssignedActivity) item.getSource().getObject();
				if (actName.equals(waa.getName())) {
					if (item.isComplete()) {
						WfVotingEventAudit audit = WorkFlowUtil.getVoting(item);
						if (audit != null) {
							if (voting.trim().length() == 0) {
								// 路由选择
								voting = audit.getEventList().toString();
								ts = item.getModifyTimestamp();
							} else {
								if (item.getModifyTimestamp().after(ts)) {
									ts = item.getModifyTimestamp();
									voting = audit.getEventList().toString();
								}
							}
						}
					}
				}
			}
		}
		if (voting.trim().length() > 0) {
			voting.replace("[", "");
			voting.replace("]", "");
		}
		// LOGGER.debug(" 活动["+actName+"] 路由选择为--->"+voting);
		return voting;
	}

	/**
	 * 获取同一个活动下的所有任务
	 * 
	 * @param waa
	 * @return ArrayList<WorkItem>
	 */
	@SuppressWarnings("deprecation")
	public static ArrayList<WorkItem> getWorkItems(WfAssignedActivity waa) {
		ArrayList<WorkItem> list = new ArrayList<WorkItem>();
		try {
			QuerySpec qs = new QuerySpec(WorkItem.class);
			qs.appendWhere(new SearchCondition(WorkItem.class, "source.key.id", SearchCondition.EQUAL,
					waa.getPersistInfo().getObjectIdentifier().getId()));
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while (qr.hasMoreElements()) {
				WorkItem workItem = (WorkItem) qr.nextElement();
				list.add(workItem);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 获取同一个活动下的所有任务
	 * 
	 * @param wfActivity
	 * @return ArrayList<WorkItem>
	 */
	public static ArrayList<WorkItem> getActivityWorkItems(WfAssignedActivity wfActivity) {
		ArrayList<WorkItem> list = new ArrayList<WorkItem>();
		try {
			Enumeration activityEnum = wfActivity.getAllAssignments();
			while (activityEnum.hasMoreElements()) {
				WfAssignment assignment = (WfAssignment) activityEnum.nextElement();
				if (assignment != null) {
					QueryResult qr = PersistenceHelper.manager.navigate(assignment, WorkItemLink.WORK_ITEM_ROLE,
							WorkItemLink.class);
					while (qr.hasMoreElements()) {
						list.add((WorkItem) qr.nextElement());
					}
				}
			}

			Enumeration activityEnum1 = wfActivity.getAssignments();
			while (activityEnum1.hasMoreElements()) {
				WfAssignment assignment = (WfAssignment) activityEnum1.nextElement();
				if (assignment != null) {
					QueryResult qr = PersistenceHelper.manager.navigate(assignment, "workItem", WorkItemLink.class);
					if (qr.size() > 0) {
						while (qr.hasMoreElements()) {
							list.add((WorkItem) qr.nextElement());
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 获取流程模板中预设的参与者
	 * 
	 * @param template
	 * @return Vector<WTPrincipalReference>
	 */
	@SuppressWarnings("deprecation")
	public static Vector<WTPrincipalReference> getTemplateUsers(WfProcessTemplate template) {
		Vector<WTPrincipalReference> vector = new Vector<>();
		/**
		 * 查询模板中所有预设的活动
		 */
		try {
			QuerySpec qs = new QuerySpec(WfAssignedActivityTemplate.class);
			qs.appendWhere(new SearchCondition(WfAssignedActivityTemplate.class, "parentTemplate.key.id",
					SearchCondition.EQUAL, template.getPersistInfo().getObjectIdentifier().getId()));
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while (qr.hasMoreElements()) {
				WfAssignedActivityTemplate act = (WfAssignedActivityTemplate) qr.nextElement();
				Enumeration ens = act.getPrincipalRefs();
				while (ens.hasMoreElements()) {
					Object obj = ens.nextElement();
					// LOGGER.debug("从流程模板["+template.getName()+"]活动["+act.getName()+"]中获取到预设的参与者对象--->"+obj.toString());
					if (obj instanceof WTPrincipalReference) {
						WTPrincipalReference ref = (WTPrincipalReference) obj;
						vector.add(ref);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vector;
	}

	/**
	 * 根据持久化对象获取相关联的流程
	 * 
	 * @param obj
	 * @return WfProcess
	 * @throws Exception
	 */
	public static WfProcess getRelatedProcess(Persistable obj) throws Exception {
		WfProcess process = null;
		QueryResult qrProcs = null;
		qrProcs = WfEngineHelper.service.getAssociatedProcesses(obj, null, null);
		// 按时间排序,取最新一个流程实例
		CollationKeyFactory timeKeyFact = new CollationKeyFactory() {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

			public String getCollationString(Object o) {
				if (!(o instanceof Persistable) || !PersistenceHelper.isPersistent(o))
					return "";
				return sdf.format(PersistenceHelper.getModifyStamp((Persistable) o));
			}
		};
		Enumeration enProcs = new SortedEnumeration(qrProcs, timeKeyFact, SortedEnumeration.DESCENDING);
		while (enProcs.hasMoreElements()) {
			process = (WfProcess) enProcs.nextElement();
			// 最新的非子进程（子进程的名称带有$符号
			if (process.getName().indexOf("$") == -1) {
				break;
			}
		}
		return process;
	}


	/**
	 * 通过workitem获取pbo
	 * 
	 * @param workItem
	 * @return pbo
	 */
	public static WTObject getPBOByWorkItem(WorkItem workItem) {
		WTObject pbo = null;
		boolean origEnforce = false;
		try {
			origEnforce = SessionServerHelper.manager.setAccessEnforced(false);
			pbo = (WTObject) workItem.getPrimaryBusinessObject().getObject();
		} catch (NullPointerException nex) {
			pbo = null;
		} finally {
			SessionServerHelper.manager.setAccessEnforced(origEnforce);
		}
		return pbo;
	}

	/**
	 * 通过WfProcess来获取流程中特性中的变量列表
	 * 
	 * @param process
	 */
	public static WfVariable[] getVarsByWf(WfProcess process) {
		try {
			Enumeration activityList = WfEngineHelper.service.getProcessSteps((WfContainer) process, null);
			while (activityList.hasMoreElements()) {
				WfActivity activity = (WfActivity) activityList.nextElement();
				ProcessData data = activity.getContext();
				WfVariable[] vars = data.getVariableList();
				return vars;
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 通过WfProcess来获取流程中特性中处理好的变量列表所组成的HashMap
	 * 
	 * @param process
	 */
	public static HashMap<String, Object> getRefinedVarsByWf(WfProcess process) {
		HashMap<String, Object> map = new HashMap<>();
		WfVariable[] vars = getVarsByWf(process);
		for (WfVariable wfVar : vars) {
			map.put(wfVar.getDisplayName(), wfVar.getValue());
		}
		return map;
	}

	/**
	 * 从PBO中获取升级请求
	 * @param primaryBusinessObject
	 * @return
	 */
	public static PromotionNotice getPromotionNotices(WTObject  primaryBusinessObject)   {
		PromotionNotice pn =  null;
		if(primaryBusinessObject instanceof PromotionNotice){
			 pn = (PromotionNotice) primaryBusinessObject;

		}
		return pn;
	}

	public static String[] getWorkFlowInfo(ObjectReference var0) {
		String[] var1 = new String[4];

		try {
			ReferenceFactory var2 = new ReferenceFactory();
			WTReference var3 = var2.getReference(var0.getObjectId().toString());
			if (var3.getObject() != null) {
				String var7;
				if (var3.getObject() instanceof WfProcess) {
					WfProcess var4 = (WfProcess) var3.getObject();
					WorkItem var5 = getWorkItem(var4);
					WfVotingEventAudit var6 = WfDataUtilitiesHelper.getMatchingEventAudit(var5);
					if (var6 != null) {
						var1[0] = var6.getUserRef() != null ? var6.getUserRef().getFullName() : "";
						var7 = simpleDateFormat.format(var6.getTimestamp());
						var1[1] = var7;
						var1[2] = var6.getUserRef().getFullName();
						var1[3] = var6.getUserComment();
					}
				} else if (var3.getObject() instanceof WfAssignedActivity) {
					WfAssignedActivity var15 = (WfAssignedActivity) var3.getObject();
					QuerySpec var16 = new QuerySpec(WorkItem.class);
					WTReference var17 = var2.getReference(var15);
					var7 = var2.getReferenceString(var17);
					System.out.println("oid----" + var7);
					SearchCondition var8 = new SearchCondition(WorkItem.class, "source.key", "=", new ObjectIdentifier(var7));
					var16.appendWhere(var8);
					QueryResult var9 = PersistenceServerHelper.manager.query(var16);

					while (var9.hasMoreElements()) {
						Object var10 = var9.nextElement();
						WorkItem var11 = (WorkItem) var10;
						WfVotingEventAudit var12 = WfDataUtilitiesHelper.getMatchingEventAudit(var11);
						if (var12 != null) {
							var1[0] = var12.getUserRef() != null ? var12.getUserRef().getFullName() : "";
							String var13 = simpleDateFormat.format(var12.getTimestamp());
							var1[1] = var13;
							var1[2] = var12.getUserRef().getFullName();
							var1[3] = var12.getUserComment();
						}
					}
				}
			}
		} catch (Exception var14) {
			var14.printStackTrace();
		}

		return var1;
	}


	public static WorkItem getWorkItem(WfProcess var0) {
		WorkItem var1 = null;

		try {
			QuerySpec var2 = new QuerySpec();
			int var3 = var2.appendClassList(WfAssignedActivity.class, false);
			int var4 = var2.appendClassList(WorkItem.class, true);
			var2.setAdvancedQueryEnabled(true);
			String[] var5 = new String[]{var2.getFromClause().getAliasAt(var3), var2.getFromClause().getAliasAt(var4)};
			TableColumn var6 = new TableColumn(var5[0], "IDA2A2");
			TableColumn var7 = new TableColumn(var5[1], "IDA3A4");
			CompositeWhereExpression var8 = new CompositeWhereExpression(LogicalOperator.AND);
			var8.append(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key", "=", getOid(var0)));
			var8.append(new SearchCondition(var6, "=", var7));
			var2.appendWhere(var8, (int[]) null);
			var2.appendOrderBy(WorkItem.class, "thePersistInfo.updateStamp", true);
			QueryResult var9 = PersistenceHelper.manager.find(var2);

			while (var9.hasMoreElements()) {
				Object[] var10 = (Object[]) ((Object[]) var9.nextElement());
				if (var10[0] instanceof WorkItem) {
					var1 = (WorkItem) var10[0];
					return var1;
				}
			}
		} catch (Exception var11) {
			var11.printStackTrace();
		}

		return var1;
	}


	private static ObjectIdentifier getOid(Object var0) {
		if (var0 == null) {
			return null;
		} else {
			return var0 instanceof ObjectReference ? (ObjectIdentifier) ((ObjectReference) var0).getKey() : PersistenceHelper.getObjectIdentifier((Persistable) var0);
		}
	}


	public static HashMap<String, Vector<String[]>> getSignInfo(Object var0) {
		HashMap var1 = new HashMap();

		try {
			String var2 = "{}";
			if (var0 instanceof ObjectReference) {
				var2 = getReview((WfProcess) ((ObjectReference) var0).getObject());
			} else if (var0 instanceof WfProcess) {
				var2 = getReview((WfProcess) var0);
			}

			JSONObject var3 = new JSONObject(var2);

			String var6;
			Vector var8;
			for (Iterator var4 = var3.keys(); var4.hasNext(); var1.put(var6, var8)) {
				Object var5 = var4.next();
				var6 = String.valueOf(var5);
				Object var7 = var3.get(var6);
				var8 = new Vector();
				if (var7 instanceof JSONArray) {
					JSONArray var9 = (JSONArray) var7;
					int var10 = var9.length();
					String[] var11 = new String[var10];

					for (int var12 = 0; var12 < var9.length(); ++var12) {
						var11[var12] = var9.getString(var12);
					}

					var8.add(var11);
				}
			}
		} catch (Exception var13) {
			var13.printStackTrace();
		}

		return var1;
	}


	public static String getReview(WfProcess var0) {
		try {
			Object var1 = var0.getContext().getValue("reviewer");
			return var1 != null ? var1.toString() : "{}";
		} catch (Exception var2) {
			var2.printStackTrace();
			return "";
		}
	}


}
