package ext.alphai.domeitic.listen;

import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import ext.alphai.domeitic.util.PersistenceUtil;
import ext.alphai.domeitic.listen.util.PropertiesUtil;
import wt.epm.EPMDocument;
import wt.events.KeyedEventListener;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.vc.VersionControlServiceEvent;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.io.Serializable;
import java.util.Locale;

public class EPMListenerService extends StandardManager implements EPMListener, Serializable {
    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = EPMListenerService.class.getName();
    private KeyedEventListener listener;


    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public EPMListenerService() {
    }

    public static EPMListenerService newEPMListenerService() throws WTException {
        EPMListenerService instance = new EPMListenerService();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new WCListenerEventListener(getConceptualClassname());
        //版本控制的检入监听事件
        getManagerService().addEventListener(listener,
                VersionControlServiceEvent.generateEventKey(VersionControlServiceEvent.NEW_VERSION));//新版本

    }

    // 内部类里面进行监听的逻辑操作
    class WCListenerEventListener extends ServiceEventListenerAdapter {
        public WCListenerEventListener(String manager_name) {
            super(manager_name);
        }

        @Override
        public void notifyVetoableEvent(Object event) throws Exception {
            System.out.println("准备监听cad部件修订");
            if (!(event instanceof VersionControlServiceEvent)) {

                return;
            }
            System.out.println("开始监听cad部件修订");
//

            VersionControlServiceEvent pmEvent = (VersionControlServiceEvent) event;
            Object target = pmEvent.getEventTarget();

//            WorkInProgressHelper.isCheckedOut((Workable) target)
//            如果返回 TRUE 则表示对象是升小版本因为它需要一个检入操作
//            如果返回 FALSE 则表示对象是升大版本因为它不需要一个检出-检入操作
            //监听EPM对象升级大版本
            if (target instanceof EPMDocument) {
                EPMDocument epm = (EPMDocument) target;
                //获取子类型
                String subTypeInternal = PersistenceUtil.getSubTypeInternal(epm);
                System.out.println("输出epm子类型：" + subTypeInternal);
                if (!WorkInProgressHelper.isCheckedOut((Workable) target)) {
                    String cleanIBAStr = PropertiesUtil.getValueByKey(subTypeInternal + ".removeIBAList");
                    if (cleanIBAStr != null && !cleanIBAStr.trim().isEmpty()) {
                        String[] ibaNames = (PropertiesUtil.getValueByKey(subTypeInternal + ".removeIBAList")).split(",");
                        System.out.println("开始清空指定属性");
                        for (String ibaName : ibaNames) {
                            //设置空值
                            setIBA(epm, ibaName, "");
                        }
                    }else {
                        // 如果cleanIBAStr为null或者空字符串，则不需要处理
                        System.out.println("没有需要清空的IBA属性");
                    }

                    System.out.println("清空指定属性end");
                }
            }

        }
    }


    public static void setIBA(Persistable persistable, String ibaName, String value) throws WTException {
        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        normalizedObject.set(ibaName, value);
        persistable = normalizedObject.apply();
        PersistenceHelper.manager.modify(persistable);
    }


}
