package ext.alphai.domeitic.wf.promotionNotice;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import ext.alphai.domeitic.util.IBAUtil;
import ext.alphai.domeitic.wf.promotionNotice.utils.PropertiesUtil;
import ext.alphai.domeitic.wf.promotionNotice.utils.WorkFlowUtil;

import org.apache.commons.lang3.StringUtils;
import wt.epm.EPMDocument;
import wt.fc.*;
import wt.maturity.PromotionNotice;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;

import java.util.*;


public class SignatureAndTime {

    /**
     *
     * @param primaryBusinessObject
     * @param self
     * @return
     * @throws WTException
     */
    public static WfAssignedActivity getAssignedActivity(WTObject primaryBusinessObject, ObjectReference self) throws WTException {
        ReferenceFactory factory = new ReferenceFactory();
        WTReference reference = factory.getReference(self.getObjectId().toString());
        WfAssignedActivity assignedActivity = null;
        //获取当前任务
        if (reference != null && reference.getObject() instanceof WfAssignedActivity) {
            assignedActivity = (WfAssignedActivity) reference.getObject();
        }
        String actionName = assignedActivity.getName();


        PromotionNotice pn = WorkFlowUtil.getPromotionNotices(primaryBusinessObject);
        WfProcess processByPbo = WorkFlowUtil.getProcessByPbo(primaryBusinessObject);
        String processName = processByPbo.getTemplate().getName();

        //任务完成人.模板名称.任务初始名称

        String TaskCompleterKey = PropertiesUtil.getValueByKey("TaskComplete." + processName + "." + actionName);
        String reviewer = IBAUtil.getEnumDisplayValue(pn, TaskCompleterKey);

        //新任务名称
        String newActionName = actionName + "_" + reviewer;
        System.out.println("修改的任务名称：" + newActionName);

        // 任务完成人以及任务名称不含任务完成人  修改  任务名称：初始名称_任务完成人
        if (StringUtils.isNotBlank(reviewer)) {
            // 修改任务名称
            assignedActivity.setName(newActionName);
            assignedActivity = (WfAssignedActivity) PersistenceHelper.manager.save(assignedActivity);
        }
        return assignedActivity;
    }

//    /**
//     *
//     * @param primaryBusinessObject
//     * @param or
//     * @param options  流程模板节点初始的内部名
//     * @throws Exception
//     */
//    public static String setEPMAttribute(WTObject primaryBusinessObject, ObjectReference or,String options) throws Exception {
//        String[] roles = options.split(",");
//
//        PromotionNotice pn = WorkFlowUtil.getPromotionNotices(primaryBusinessObject);
//        //获取流程模板名称
//        WfProcess processByPbo = WorkFlowUtil.getProcessByPbo(primaryBusinessObject);
//        String processName = processByPbo.getTemplate().getName();
//
//        WfProcess wfProcess = null;
//        if (or.getObject() instanceof WfProcess) {
//             wfProcess = (WfProcess) or.getObject();
//        }
//
//        //变更请求实例名称
//        System.out.println("流程模板名称"+processName);
//
//        List<EPMDocument> promotionEPMsByPN = getPromotionEPMsByPN(pn);
//        Map<String, List<String[]>> approvalInfoMap = new HashMap<>();
//        for (EPMDocument epmDocument : promotionEPMsByPN) {
//            for (String role : roles) {
//
//                //任务完成人在  升级请求上
//                String roleIBAKey = PropertiesUtil.getValueByKey("TaskComplete." + processName + "."+role);
//                //完成时间在任务上
//                String dateIBAKey = PropertiesUtil.getValueByKey("TaskComplete."+processName+"."+role+".时间");
//
//                if (roleIBAKey.isEmpty() ){
//                    System.out.println("未找到"+"ai."+processName+"."+role+"对应iba值");
//                    continue;
//                }
//
//                if (dateIBAKey.isEmpty() ){
//                    System.out.println("未找到"+"ai."+processName+"."+role+"时间"+"对应iba值");
//                    continue;
//                }
//
//
//                //任务完成人
//                String roleValue = IBAUtil.getEnumDisplayValue(pn,PropertiesUtil.getValueByKey("TaskComplete." + processName + "."+role));
//                String actionName = role + "_" + roleValue;
//                Map<String, String> review = WorkFlowUtil.getReview(wfProcess, actionName);
//
//
//                IBAUtil ibaUtil = new IBAUtil(epmDocument);
//                //修改属性

    /// /                ibaUtil.setIBAAttribute4AllType(epmDocument,roleIBAKey,review.get("modifier"));
//                ibaUtil.setIBAAttribute4AllType(epmDocument,roleIBAKey,roleValue);//从升级请求获取
//                ibaUtil.setIBAAttribute4AllType(epmDocument,dateIBAKey,review.get("modifyTime").replace(".", "-"));
//
//                // 收集审批信息用于生成JSON
//                String[] approvalRecord = new String[4];
//                approvalRecord[0] = roleValue; // 审批人
//                approvalRecord[1] = review.get("modifyTime").replace(".", "-"); // 审批日期
//                approvalRecord[2] = roleValue; // 下一审批人（这里用同一人，实际可根据业务调整）
//                approvalRecord[3] = " "; // 备注或空格
//
//                // 将审批记录添加到对应角色的列表中
//                if (!approvalInfoMap.containsKey(role)) {
//                    approvalInfoMap.put(role, new ArrayList<>());
//                }
//                approvalInfoMap.get(role).add(approvalRecord);
//            }
//        }
//
//        return generateApprovalInfoJSON(approvalInfoMap);
//
//    }
    public static String setEPMAttribute(WTObject primaryBusinessObject, ObjectReference or, String options) throws Exception {
        String[] roles = options.split(",");

        PromotionNotice pn = WorkFlowUtil.getPromotionNotices(primaryBusinessObject);
        WfProcess processByPbo = WorkFlowUtil.getProcessByPbo(primaryBusinessObject);
        String processName = processByPbo.getTemplate().getName();

        WfProcess wfProcess = null;
        if (or.getObject() instanceof WfProcess) {
            wfProcess = (WfProcess) or.getObject();
        }

        System.out.println("流程模板名称" + processName);

        List<EPMDocument> promotionEPMsByPN = getPromotionEPMsByPN(pn);
        HashMap<String, Vector<String[]>> approvalInfoMap = new HashMap<>();

        // 只需要第一个EPM文档来收集审批信息
        boolean isFirstEPM = true;

        for (EPMDocument epmDocument : promotionEPMsByPN) {
            for (String role : roles) {
                String roleIBAKey = PropertiesUtil.getValueByKey("TaskComplete." + processName + "." + role);
                String dateIBAKey = PropertiesUtil.getValueByKey("TaskComplete." + processName + "." + role + ".时间");

                if (roleIBAKey.isEmpty() ){
                    System.out.println("未找到"+"ai."+processName+"."+role+"对应iba值");
                    continue;
                }

                if (dateIBAKey.isEmpty() ){
                    System.out.println("未找到"+"ai."+processName+"."+role+"时间"+"对应iba值");
                    continue;
                }

                String roleValue = IBAUtil.getEnumDisplayValue(pn, PropertiesUtil.getValueByKey("TaskComplete." + processName + "." + role));
                String actionName = role + "_" + roleValue;
                Map<String, String> review = WorkFlowUtil.getReview(wfProcess, actionName);

                if (review == null || review.get("modifyTime") == null) {
                    System.out.println("未找到"+actionName+"的信息");
                    continue;
                }

                IBAUtil ibaUtil = new IBAUtil(epmDocument);
                ibaUtil.setIBAAttribute4AllType(epmDocument, roleIBAKey, roleValue);
                ibaUtil.setIBAAttribute4AllType(epmDocument, dateIBAKey, review.get("modifyTime"));

                // 只在第一个EPM文档收集审批信息
                if (isFirstEPM) {
                    String[] approvalRecord = new String[4];
                    approvalRecord[0] = roleValue;
                    approvalRecord[1] = review.get("modifyTime");
                    approvalRecord[2] = roleValue;
                    approvalRecord[3] = " ";

                    if (!approvalInfoMap.containsKey(role)) {
                        approvalInfoMap.put(role, new Vector<String[]>());
                    }
                    // 这里可以添加去重逻辑，如果需要的话
                    approvalInfoMap.get(role).add(approvalRecord);
                }
            }
            isFirstEPM = false; // 处理完第一个EPM后，后续只设置属性
        }

        return generateApprovalInfoJSON(approvalInfoMap);
    }

    public static List<EPMDocument> getPromotionEPMsByPN(PromotionNotice pn) {
        List<EPMDocument> epms = new ArrayList<>();

        //获取升级请求
        try {
            List<WTObject> objects = WorkFlowUtil.getTargerObjectByPromotionNotices(pn);
            for (WTObject object : objects) {
                if (object instanceof EPMDocument) {
                    EPMDocument epm = (EPMDocument) object;
                    epms.add(epm);
                }
            }
        } catch (WTException e) {
            throw new RuntimeException(e);
        }
        return epms;
    }

    /**
     * 生成JSON格式的审批信息
     *
     * @param approvalInfoMap 审批信息Map，类型为 HashMap<String, Vector<String[]>>
     * @return JSON字符串
     */
    private static String generateApprovalInfoJSON(HashMap<String, Vector<String[]>> approvalInfoMap) {
        // 使用LinkedHashMap保持顺序
        Map<String, Object> jsonMap = new LinkedHashMap<>();

        for (Map.Entry<String, Vector<String[]>> entry : approvalInfoMap.entrySet()) {
            String role = entry.getKey();
            Vector<String[]> approvalRecords = entry.getValue();

            // 转换为List of Arrays格式
            List<String[]> roleApprovals = new ArrayList<>();
            for (String[] record : approvalRecords) {
                roleApprovals.add(record);
            }
            jsonMap.put(role, roleApprovals);
        }

        // 使用Gson生成JSON
        Gson gson = new GsonBuilder()
                .disableHtmlEscaping()
                .create();

        return gson.toJson(jsonMap);
    }


}
