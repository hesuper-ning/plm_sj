package ext.alphai.dszn;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.lwc.server.LWCMasterEnumerationDefinition;
import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.windchill.enterprise.copy.server.CoreMetaUtility;
import com.ptc.wvs.common.ui.Publisher;
import com.ptc.wvs.common.ui.VisualizationHelper;
import org.apache.commons.lang3.StringUtils;
import wt.content.*;
import wt.doc.DocumentType;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.*;
import wt.filter.NavigationCriteria;
import wt.folder.*;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.State;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.representation.Representation;
import wt.series.MultilevelSeries;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.FileUtil;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.*;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewReference;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

public class RemoteTest23 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;


    public static void main(String[] args) throws WTRuntimeException, WTException, JsonProcessingException {

        String str = (String) invoke("process", RemoteTest23.class.getName(), null, new Class[]{}, new Object[]{});
    }


    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }




    public static String process() throws Exception{
        try {
            // 	0000000002.DRW  0000000008.DRW 都有两个pdf       0000000005.DRW没有
            EPMDocument epm = getEPMByNumber("0000000005.DRW");

            // 启动可视化发布器
            handVisualization(epm);


//            File file = new File("D:/601100021_D_中间体_A.1.pdf");
//
//            createWTDoc(epm,"","",file);

//            WTDocument doc = getWTDocByNumber("9920250208");
//            setIterationCreator(doc, epm.getCreator().getPrincipal());

            // 获取epm默认表示法附件
//            List<ApplicationData> epmApplicationData = getEPMApplicationData(epm);
//            for (ApplicationData data : epmApplicationData) {
//                System.out.println("默认表示法附件名称："+data.getFileName());
//            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取EPM文档默认表示法的附件
     * @param epm
     * @return
     */
    public static List<ApplicationData> getEPMApplicationData(EPMDocument epm) throws PropertyVetoException, WTException {
        List<ApplicationData> dataLists = new ArrayList<ApplicationData>();
        VisualizationHelper vizHelper = new VisualizationHelper();
        QueryResult result = vizHelper.getRepresentations(epm);
        Representation rep = null;
        ContentHolder ch = null;
        Vector<?> appDatas = null;
        ApplicationData appData = null;

        while (result.hasMoreElements()) {
            rep = (Representation) result.nextElement();
            ch = ContentHelper.service.getContents(rep);
            String name = rep.getName();

            Boolean defaultRepresentation = rep.getDefaultRepresentation();
            //必须从默认表示法中获取pdf
            if(!defaultRepresentation){
                continue;
            }
            appDatas = ContentHelper.getContentListAll(ch);
            for (int i = 0; i < appDatas.size(); i++) {
                appData = (ApplicationData) appDatas.get(i);
                ContentRoleType role = appData.getRole();
                // 检查表示法中是否包含pdf
                if ((role.equals(ContentRoleType.ADDITIONAL_FILES) || role.equals(ContentRoleType.SECONDARY))) {
                    dataLists.add(appData);
                }
            }
        }

        return dataLists;
    }




    /**
     * 手动开启可视化发布器
     * @param epm 2D图
     * 该方法的返回值是
     * boolean如果发布作业将创建的表示已存在，则为true（forceRepublish为false）。
     * 在这种情况下，如果viewableLink为true，则可以使用getViewableLink（）获得查看现有表示的信息。如果发布作业尚未提交，因为正在发布的对象被标记为不发布，那么isMarkedNotPublishable（）将返回true。
     * 如果业务对象没有已经存在的表示，则返回false。
     */
    public static boolean handVisualization(EPMDocument epm) throws WTException {
        boolean result = false;
        Publisher pub = new Publisher();
        ReferenceFactory rf = new ReferenceFactory();
        String objRef = rf.getReferenceString(epm);


        // b2 是是否默认表示法  s1是表示法名称       i1 [0=未知，1=手动，2=签入，3=计划]
        result = pub.doPublish(false, true, objRef, (NavigationCriteria) null, (NavigationCriteria) null, true, null, null,
                Publisher.EPM, null, 0);
        return result;
    }



    /**
     * 设置文档 或部件的修改者创建者  前提是已存在的对象
     * @param revisionControlledObject
     * @param wtprincipal
     * @throws WTException
     */
    public static void setIterationCreator(RevisionControlled revisionControlledObject, WTPrincipal wtprincipal) throws WTException {
        ReferenceFactory rf = new ReferenceFactory();
        boolean accessFlag = true;
        try {
            accessFlag = wt.session.SessionServerHelper.manager.setAccessEnforced(false);//过滤权限
            Class[] classWTPrinicipalReference = new Class[] { WTPrincipalReference.class };
            Method setCreator = _IterationInfo.class.getDeclaredMethod("setCreator", classWTPrinicipalReference);

            Method setModifier = _IterationInfo.class.getDeclaredMethod("setModifier", classWTPrinicipalReference);
            setCreator.setAccessible(true);
            setModifier.setAccessible(true);
            IterationInfo iterationInfo = revisionControlledObject.getIterationInfo();
            setCreator.invoke(iterationInfo,new Object[] { (WTPrincipalReference) rf.getReference(wtprincipal) });

            setModifier.invoke(iterationInfo,new Object[] { (WTPrincipalReference) rf.getReference(wtprincipal) });
            PersistenceServerHelper.manager.update(revisionControlledObject);
        } catch (Exception e) {
            throw new WTException(e);
        }finally{
            wt.session.SessionServerHelper.manager.setAccessEnforced(accessFlag);//还原权限
        }

    }


    /**
     * API 创建文档 设置子类型
     * @param epm
     * @param docNumber
     * @param docName
     * @param file
     * @throws Exception
     */
    public static void createWTDoc(EPMDocument epm,String docNumber, String docName, File file) throws Exception {
        // 三参  1 是编号 2是名称
        WTDocument pdfDoc = WTDocument.newWTDocument();
        pdfDoc.setNumber(docNumber);
        pdfDoc.setName(docName);
        pdfDoc.setContainer(epm.getContainer());
        //设置对象的ContainerReference，为空会上传失败
        WTContainer container = WTContainerHelper.getContainer(epm);
        WTContainerRef c_ref = WTContainerRef.newWTContainerRef(container);
        pdfDoc.setContainerReference(c_ref);
        SubFolder parentFolder = (SubFolder)epm.getParentFolder().getObject();
        String folderPath;

        if(parentFolder == null){
            folderPath = "/Default";
        } else {
            folderPath = parentFolder.getFolderPath();
        }

        //根据工作区的文件夹路径以及工作区的WTContainer对象来获取工作区对应的文件夹
        Folder folder = FolderHelper.service.getFolder(folderPath,c_ref);
        FolderHelper.assignLocation(pdfDoc, folder);
        // 设置文件创建者修改者
//        VersionControlHelper.assignIterationCreator(pdfDoc,
//                WTPrincipalReference.newWTPrincipalReference(user));// 修改对象的创建者
//        VersionControlHelper.setIterationModifier(pdfDoc, WTPrincipalReference.newWTPrincipalReference(user));// 更新者

        // 目前以EPM文档的创建者修改者为准
        VersionControlHelper.assignIterationCreator(pdfDoc,
        epm.getCreator());// 修改对象的创建者
        VersionControlHelper.setIterationModifier(pdfDoc, epm.getModifier());// 更新者

        // 设置生命周期模板
        LifeCycleTemplate lct = LifeCycleHelper.service.getLifeCycleTemplate("Basic" , pdfDoc.getContainerReference());
        // 设置状态
//        LifeCycleState lifeCycleState = LifeCycleState.newLifeCycleState();
//        lifeCycleState.setState(State.toState("状态内部值"));
//        pdfDoc.setState(lifeCycleState);
        pdfDoc = (WTDocument) LifeCycleHelper.setLifeCycle(pdfDoc, lct);


        WTDocumentMaster master = (WTDocumentMaster) pdfDoc.getMaster();
        createSoftTypeDoc(pdfDoc, "com.ds.pdf");
        pdfDoc = (WTDocument)PersistenceHelper.manager.store(pdfDoc);

        ApplicationData data = ApplicationData.newApplicationData(pdfDoc);

        data.setRole(ContentRoleType.PRIMARY);
        data.setFileName(file.getName());
        String coding = new String(file.getAbsolutePath().getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);

        // 这里设置IBA值
//        updateIBAValue(pdfDoc,"","");
        ContentServerHelper.service.updateContent(pdfDoc, data, coding);

    }


    public static void updateIBAValue(WTDocument doc, String ibaName, Object value) throws WTException {
        System.out.println("更新的属性是：" + ibaName + ",更新的值是：" + value);
        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(doc, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        normalizedObject.set(ibaName, value);
        doc = (WTDocument) normalizedObject.apply();
        PersistenceHelper.manager.save(doc);
    }


    /**
     * 设置文档子类型
     * @param wtdoc
     * @param softName 内部值
     * @throws WTException
     * @throws RemoteException
     * @throws WTPropertyVetoException
     */
    public static void createSoftTypeDoc(WTDocument wtdoc, String softName) throws WTException, RemoteException, WTPropertyVetoException {
        TypeIdentifier myCustomType = TypeHelper.getTypeIdentifier(softName);
        WCTypeIdentifier myCustomWCType = (WCTypeIdentifier) myCustomType;
        TypeDefinitionReference myCustomTDR = TypedUtilityServiceHelper.service.getTypeDefinitionReference(myCustomWCType.getTypename());
        wtdoc.setTypeDefinitionReference(myCustomTDR);
    }




    public static EPMDocument getEPMByNumber(String number) {
        EPMDocument result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(EPMDocument.class);
            SearchCondition scnumber = new SearchCondition(EPMDocument.class,
                    EPMDocument.NUMBER, SearchCondition.EQUAL, number
                    .toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(
                    EPMDocument.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (EPMDocument) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static WTDocument getWTDocByNumber(String number) {
        WTDocument result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTDocument.class);
            SearchCondition scnumber = new SearchCondition(WTDocument.class,
                    WTDocument.NUMBER, SearchCondition.EQUAL, number
                    .toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(
                    WTDocument.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (WTDocument) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    /**
     * 用API创建部件 设置编号  名称  单位 生命周期  创建者修改者 及版本
     * @param number
     * @param name
     * @param unit
     * @param endItem
     * @param folder
     * @param user
     * @param softType
     * @param version
     * @param state
     * @return
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static WTPart createPartAndVersion(String number, String name, String unit, boolean endItem, Folder folder,
                                              WTUser user, String softType, String version, String state) throws WTException, WTPropertyVetoException {
        // SessionHelper.manager.setAdministrator();
        WTPart part = WTPart.newWTPart();
        if (number != null && number.trim().length() > 0) {
            part.setNumber(number);
        }
        View view = ViewHelper.service.getView("Design");
        part.setView(ViewReference.newViewReference(view));
        part.setName(name);
        part.setDefaultUnit(QuantityUnit.toQuantityUnit(unit));
        part.setEndItem(endItem);
        FolderHelper.assignLocation((FolderEntry) part, folder);
        VersionControlHelper.assignIterationCreator(part,
                WTPrincipalReference.newWTPrincipalReference(user));// 修改对象的创建者
        VersionControlHelper.setIterationModifier(part, WTPrincipalReference.newWTPrincipalReference(user));// 更新者

        /**modify by wq.Ran 20210722 设置部件到指定版本 start**/
        if (!"A".equals(version)) {
            MultilevelSeries mul = MultilevelSeries.newMultilevelSeries("wt.vc.VersionIdentifier", version);
            String s = mul.getUniqueSeriesName();
            Mastered mastered = part.getMaster();
            String series = mastered.getSeries();
            if (!s.equals(series)) {
                mastered.setSeries(s);
            }
            VersionControlServerHelper.setVersionIdentifier(part, VersionIdentifier.newVersionIdentifier(mul), false);
        }
        /**modify by wq.Ran 20210722 设置部件到指定版本 end**/

        if (org.apache.commons.lang.StringUtils.isNotBlank(softType)) {
            TypeIdentifier id = TypeIdentifierHelper.getTypeIdentifier(softType);
            part = (WTPart) CoreMetaUtility.setType(part, id);
        }
        // 设置状态
        if (StringUtils.isNotBlank(state)) {
            LifeCycleState lifeCycleState = LifeCycleState.newLifeCycleState();
            lifeCycleState.setState(State.toState(state));
            part.setState(lifeCycleState);
        }
        part = (WTPart) PersistenceHelper.manager.save(part);
        return part;
    }

}
