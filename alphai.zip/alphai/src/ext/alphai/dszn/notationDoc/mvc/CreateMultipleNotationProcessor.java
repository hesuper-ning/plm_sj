package ext.alphai.dszn.notationDoc.mvc;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.dszn.notationDoc.service.NotationDocService;
import org.apache.commons.lang3.StringUtils;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.WTObject;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 批量生成文档表示法及文档处理
 */
public class CreateMultipleNotationProcessor extends DefaultObjectFormProcessor {

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {

        FormResult formResult = null;
        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();
        String[] soids = new String[]{};

        List<String> ors = new ArrayList<>();
        for (String key: parameterMap.keySet()) {
            Object value = parameterMap.get(key);
//            String[] values = (String[]) value;
//            for (String a : values) {
//                System.out.println("key=" + key + "value=" + a);
//            }
            if("soid".equals(key)){
                soids = (String[]) value;
            }
        }
        for (String oid : soids) {
            String or = NotationDocService.getPartOR(oid);
            if(!StringUtils.isBlank(or)){
                ors.add(or);
            }
        }
        List<EPMDocument> drawings = new ArrayList<>();

        for (String or : ors) {
            WTObject object = NotationDocService.oid2Object(or);
            if(object!=null){
                if(object instanceof EPMDocument) {
                    EPMDocument drawing = (EPMDocument) object;
                    String cadName = drawing.getCADName();
                    drawings.add(drawing);
                }
            }
        }

        // 生成默认表示法
        StringBuilder sb = new StringBuilder();
        List<WTDocument> docs = new ArrayList<>();
        NotationDocService.createEPMNotation(drawings);


        // 通过文档表示法附件创建对应的wtdoc 对象
        try {
            docs = NotationDocService.createWTDocumentByEPMList(drawings);
        } catch (PropertyVetoException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 根据文档个数判断是否生成成功


        if(org.apache.commons.lang3.StringUtils.isBlank(sb)){
            formResult= new FormResult(FormProcessingStatus.SUCCESS);
            formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null,null, new String[]{"EPM文档转档成功"}));
        }else {
            formResult= new FormResult(FormProcessingStatus.FAILURE);
            formResult.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null,null, new String[]{"EPM文档编号"+sb+"转档失败"}));

        }
        return formResult;
    }
}
