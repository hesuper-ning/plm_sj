package ext.alphai.dszn.notationDoc.service;

import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.wvs.common.ui.Publisher;
import com.ptc.wvs.common.ui.VisualizationHelper;
import wt.content.*;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.filter.NavigationCriteria;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleTemplate;
import wt.method.MethodContext;
import wt.pom.WTConnection;
import wt.representation.Representation;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.VersionControlHelper;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 生成文档表示法及附件文档的服务类
 */
public class NotationDocService {

    /**
     * 手动触发生成EPM文档表示法
     * @param epmList
     */
    public static void createEPMNotation(List<EPMDocument> epmList) throws WTException {
        Publisher pub = new Publisher();
        ReferenceFactory rf = new ReferenceFactory();
        for (EPMDocument epm : epmList) {
            String objRef = rf.getReferenceString(epm);
            // b2 是是否默认表示法  s1是表示法名称       i1 [0=未知，1=手动，2=签入，3=计划]
            boolean result = pub.doPublish(false, true, objRef, (NavigationCriteria) null, (NavigationCriteria) null, true, null, null,
                    Publisher.EPM, null, 0);
        }

        // 是否需要一个工作队列来检测表示法是否创建完毕



    }


    /**
     * 创建EPM 文档对应的文档
     * @param epms
     * @return
     */
    public static List<WTDocument> createWTDocumentByEPMList(List<EPMDocument> epms) throws PropertyVetoException, WTException, IOException {
        List<WTDocument> result = new ArrayList<>();
        for (EPMDocument epm : epms) {
            result.add(createWTDocumentByEPMList(epm, null, null,"Basic"));
        }
        return result;
    }


    /**
     * 通过EPM创建指定子类型文档
     * @param epm
     * @param epmData 文档主要内容对应的epm文档的附件
     * @param docChildType 文档子类型
     * @param lifeTemp 文档生命周期模板
     * @return
     * @throws WTException
     * @throws PropertyVetoException
     * @throws IOException
     */
    public static WTDocument createWTDocumentByEPMList(EPMDocument epm, ApplicationData epmData ,String docChildType,String lifeTemp) throws WTException, PropertyVetoException, IOException {
        WTDocument doc = WTDocument.newWTDocument();
        doc.setNumber("");
        doc.setName("");
        doc.setContainer(epm.getContainer());
        //设置对象的ContainerReference，为空会上传失败
        WTContainer container = WTContainerHelper.getContainer(epm);
        WTContainerRef c_ref = WTContainerRef.newWTContainerRef(container);
        doc.setContainerReference(c_ref);
        SubFolder parentFolder = (SubFolder)epm.getParentFolder().getObject();
        String folderPath;

        if(parentFolder == null){
            folderPath = "/Default";
        } else {
            folderPath = parentFolder.getFolderPath();
        }

        //根据工作区的文件夹路径以及工作区的WTContainer对象来获取工作区对应的文件夹
        Folder folder = FolderHelper.service.getFolder(folderPath,c_ref);
        FolderHelper.assignLocation(doc, folder);

        // 目前以EPM文档的创建者修改者为准
        VersionControlHelper.assignIterationCreator(doc,
                epm.getCreator());// 修改对象的创建者
        VersionControlHelper.setIterationModifier(doc, epm.getModifier());// 更新者


        // 设置生命周期模板
        LifeCycleTemplate lct = LifeCycleHelper.service.getLifeCycleTemplate(lifeTemp , doc.getContainerReference());
        // 设置状态
//        LifeCycleState lifeCycleState = LifeCycleState.newLifeCycleState();
//        lifeCycleState.setState(State.toState("状态内部值"));
//        pdfDoc.setState(lifeCycleState);
        doc = (WTDocument) LifeCycleHelper.setLifeCycle(doc, lct);

        // 设置子类型
        createSoftTypeDoc(doc, docChildType);
        doc = (WTDocument)PersistenceHelper.manager.store(doc);
//        updateIBAValue(pdfDoc,"","");
        ApplicationData data = ApplicationData.newApplicationData(doc);

        data.setRole(ContentRoleType.PRIMARY);
        data.setFileName(epmData.getFileName());

        ContentServerHelper.service.updateContent(doc, data, ContentServerHelper.service.findContentStream(epmData));
        return doc;
    }
















    /**
     * 获取EPM文档默认表示法的附件
     * @param epm
     * @return
     */
    public static List<ApplicationData> getEPMApplicationData(EPMDocument epm) throws PropertyVetoException, WTException {
        List<ApplicationData> dataLists = new ArrayList<ApplicationData>();
        VisualizationHelper vizHelper = new VisualizationHelper();
        QueryResult result = vizHelper.getRepresentations(epm);
        Representation rep = null;
        ContentHolder ch = null;
        Vector<?> appDatas = null;
        ApplicationData appData = null;

        while (result.hasMoreElements()) {
            rep = (Representation) result.nextElement();
            ch = ContentHelper.service.getContents(rep);
            String name = rep.getName();

            Boolean defaultRepresentation = rep.getDefaultRepresentation();
            //必须从默认表示法中获取pdf
            if(!defaultRepresentation){
                continue;
            }
            appDatas = ContentHelper.getContentListAll(ch);
            for (int i = 0; i < appDatas.size(); i++) {
                appData = (ApplicationData) appDatas.get(i);
                ContentRoleType role = appData.getRole();
                // 检查表示法中是否包含pdf
                if ((role.equals(ContentRoleType.ADDITIONAL_FILES) || role.equals(ContentRoleType.SECONDARY))) {
                    dataLists.add(appData);
                }
            }
        }

        return dataLists;
    }


    public static void updateIBAValue(WTDocument doc, String ibaName, Object value) throws WTException {
        System.out.println("更新的属性是：" + ibaName + ",更新的值是：" + value);
        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(doc, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        normalizedObject.set(ibaName, value);
        doc = (WTDocument) normalizedObject.apply();
        PersistenceHelper.manager.save(doc);
    }


    /**
     * 设置文档子类型
     * @param wtdoc
     * @param softName 内部值
     * @throws WTException
     * @throws RemoteException
     * @throws WTPropertyVetoException
     */
    public static void createSoftTypeDoc(WTDocument wtdoc, String softName) throws WTException, RemoteException, WTPropertyVetoException {
        TypeIdentifier myCustomType = TypeHelper.getTypeIdentifier(softName);
        WCTypeIdentifier myCustomWCType = (WCTypeIdentifier) myCustomType;
        TypeDefinitionReference myCustomTDR = TypedUtilityServiceHelper.service.getTypeDefinitionReference(myCustomWCType.getTypename());
        wtdoc.setTypeDefinitionReference(myCustomTDR);
    }










    /**
     *
     * 在返回的String soid中得到部件OR
     * @param soid
     * @return
     */
    public static String getPartOR(String soid) {
        String pattern =null;
//        if(soid.contains("VR:wt.doc.WTDocument:")){
//            pattern = "VR:wt.doc.WTDocument:\\d+"; // 正则表达式匹配模式
//        } else if(soid.contains("OR:wt.doc.WTDocument:")){
//            pattern = "OR:wt.doc.WTDocument:\\d+"; // 正则表达式匹配模式
//        } else
            if (soid.contains("VR:wt.epm.EPMDocument:")) {
            pattern = "VR:wt.epm.EPMDocument:\\d+"; // 正则表达式匹配模式
        } else if(soid.contains("OR:wt.epm.EPMDocument:")){
            pattern = "OR:wt.epm.EPMDocument:\\d+"; // 正则表达式匹配模式
        } else {
            return "";
        }
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(soid);
        if (m.find()) {
            String partVROrOR = m.group(0);
            if(partVROrOR.contains("OR")){
                return partVROrOR;
            } else if (partVROrOR.contains("VR")){

//                if(partVROrOR.contains("WTDocument")){
//
//                    return getORbyVR(partVROrOR, "WTDOCUMENT");
//                } else
                    if (partVROrOR.contains("EPMDocument")) {
                    return getORbyVR(partVROrOR, "EPMDOCUMENT");
                } else {
                    return "";
                }
            }
        }
        return "";
    }


    /**
     * 根据部件的EPM WTDOC查找到部件的OR
     *
     */
    public static String getORbyVR(String VR, String table) {
        String sql = "";
        VR = VR.split(":")[2];

        if("WTDOCUMENT".equals(table)){
            sql = "SELECT IDA2A2 FROM WTDOCUMENT WHERE BRANCHIDITERATIONINFO = ?";
        } else if("EPMDOCUMENT".equals(table)){
            sql = "SELECT IDA2A2 FROM EPMDOCUMENT WHERE BRANCHIDITERATIONINFO = ?";
        } else {
            return "";
        }


        String OR = "";
        try {
            ResultSet resultSet = excuteSelect(sql,VR);
            while (resultSet.next()) {
                if("WTDOCUMENT".equals(table)){
                    OR = "OR:wt.doc.WTDocument:" + resultSet.getString("IDA2A2");
                } else if("EPMDOCUMENT".equals(table)){
                    OR = "OR:wt.epm.EPMDocument:" + resultSet.getString("IDA2A2");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return OR;
    }
    /**
     * 执行查询的SQL语句并返回结果 SQL示例：SELECT WTPARTNUMBER FROM WTPARTMASTER WHERE
     * WTPARTNUMBER LIKE ?
     *
     * @param sql    SQL语句
     * @param params 参数集
     * @return ResultSet 返回结果集
     */
    public static ResultSet excuteSelect(String sql, String... params) {
        try {
            WTConnection connection = getWTConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                statement.setString(i + 1, params[i]);
            }

            // 输出当前执行查询操作的SQL语句
            String fullSql = sql;
            for (String param : params) {
                param = param.length() > 250 ? "此属性太长，不显示内容" : param;
                fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
            }
            System.out.println("--------当前执行查询操作的SQL语句为--------");
            System.out.println(fullSql);

            ResultSet resultSet = statement.executeQuery();
            return resultSet;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 连接Windchill数据库来运行自定义sql
     *
     * @return WTConnection 数据库连接
     * @throws Exception
     */
    public static WTConnection getWTConnection() {
        WTConnection wtconnection = null;
        try {
            MethodContext methodcontext = MethodContext.getContext();
            wtconnection = (WTConnection) methodcontext.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtconnection;
    }

    public static WTObject oid2Object(String oid) {


        try {
            ReferenceFactory factory = new ReferenceFactory();
            return (WTObject) factory.getReference(oid).getObject();
        } catch (WTRuntimeException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return null;
    }
}
