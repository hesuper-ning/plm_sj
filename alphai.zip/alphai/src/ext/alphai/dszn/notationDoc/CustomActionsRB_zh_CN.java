package ext.alphai.dszn.notationDoc;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;
@RBUUID("ext.alphai.dszn.notationDoc.CustomActionsRB_zh_CN")
public class CustomActionsRB_zh_CN extends WTListResourceBundle {

    @RBEntry("新建转档")
    public static final String PRIVATE_CONSTANT_1 ="xplz.createRFQ.description";

    @RBEntry("新建转档")
    public static final String PRIVATE_CONSTANT_2 ="xplz.createRFQ.tooltip";

    @RBEntry("deliverable.gif")
    public static final String PRIVATE_CONSTANT_3 = "xplz.createRFQ.icon";
}
