<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca" %>
<%@page import="wt.util.WTProperties" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc" %>
<jca:tabToHighlight actionName="propertyPanel" objectType="object"/>
<%@ include file="/netmarkets/jsp/util/begin.jspf" %>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb" %>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags" %>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>批量属性</title>

</head>
<body>

<div class="search-container">
        *部件编号：<input name="partNumber" id="searchPartNumber" type="text" placeholder="输入部件编号搜索...">
        <input type="button" onclick="searchData()" value="搜索">
</div>

<script>
    function searchData() {
        const searchItemInputValue = document.getElementById('searchPartNumber').value.trim();
         

        if (!searchItemInputValue ){
            alert("未输入部件编号，请填写!")
            return
        }

        
        Ext.Ajax.request({
                    url: 'servlet/Navigation/ClsAConstraint?number='+searchItemInputValue,
                    method: 'get', // 请求方法设置为 POST
                    success: function (response) {
                        var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                         
                    },
                    failure: function (response) {
                        console.error('请求失败：', response.statusText);
                    }
                });

        


 
    }


</script>
</body>

</html>