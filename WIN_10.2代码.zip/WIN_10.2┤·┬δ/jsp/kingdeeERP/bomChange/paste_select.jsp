<% request.setAttribute(NmAction.SHOW_CONTEXT_INFO, "false"); %>
<%@ page import="java.util.ResourceBundle,com.ptc.netmarkets.util.utilResource"%>
<%@ page import="wt.util.HTMLEncoder"%>
<%@ include file="/netmarkets/jsp/util/beginPopup.jspf"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc"%>
<%@page language="java" session="true" pageEncoding="UTF-8" %>



    <input type="button" value="粘贴" onclick="refreshIncludedContent()">
<div id="includedContent">
	<jsp:include page="${mvc:getComponentURL('netmarkets.object.clipboard')}" flush="true" />
</div>

<input type="hidden" name="isPasteSelect" value="true">
<script language="JavaScript">
function refreshIncludedContent(){
  location.reload();

}


</script>

<%@ include file="/netmarkets/jsp/util/end.jspf"%>  