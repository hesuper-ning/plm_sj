<%@page language="java" session="true" pageEncoding="UTF-8"%>
<script><%@ include file="jquery-1.7.1.min.js"%></script>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca"%>
<%@page import="wt.util.WTProperties"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc"%>
<jca:tabToHighlight actionName="propertyPanel" objectType="object" />	
<%@ include file="/netmarkets/jsp/util/begin.jspf"%>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb"%>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags"%>
<%@page import="wt.doc.WTDocument"%>
<%@page import="wt.epm.EPMDocument"%>

<%@page import="com.ptc.netmarkets.model.NmOid"%>
<%@page import="java.util.ArrayList"%>
<%@page import="com.ptc.netmarkets.util.beans.NmContextBean"%>
<%@page import="com.ptc.netmarkets.util.beans.NmCommandBean"%>





<input type='button' class='button' value='&nbsp;导出excel&nbsp;' onclick="ExportExcel()" />
<input type='button' class='button' value='&nbsp;下载模板&nbsp;' onclick="openTemplate()" />

<jsp:include page="${mvc:getComponentURL('ext.kingdeeERP.changeBOM.ChangeBomTable')}" />

<%@ include file="/netmarkets/jsp/util/end.jspf"%>
<script type="text/javascript">
// 下载模板
	function openTemplate(){
		var iTop = (window.screen.height)/2 ;
		var iLeft = 500;
		window.open("netmarkets/jsp/kingdeeERP/禾苗ECNBOM变更项模板.xlsx",null,"top="+iTop+",left="+iLeft+",height=250,width=300");
	}

		// 导出excel
		function ExportExcel(){
			var oid = '<%= request.getParameter("oid") %>';
			// 发送 AJAX 请求
                    $.ajax({
                        url: 'servlet/Navigation/changeBOM/ExportBOMExcelController?oid='+oid,
                        type: 'GET',
                        contentType: 'application/json;charset=UTF-8',
                        success: function(response) {
							alert(response)
                        },
                        error: function(xhr, status, error) {
                            // 处理错误情况
                            console.error('AJAX 请求失败:', error);
                            alert("发生错误，请稍后重试");
                        }
                    });
			}

</script>