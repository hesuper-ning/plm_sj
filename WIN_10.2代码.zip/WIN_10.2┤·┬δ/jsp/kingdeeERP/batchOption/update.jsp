<%@page import="wt.part.WTPart" %>
<%@page import="wt.part.WTPartSubstituteLink" %>
<%@page import="wt.part.WTPartMaster" %>
<%@page import="wt.change2.WTChangeOrder2" %>
<%@page import="java.util.Arrays" %>


<%@page import="ext.kingdeeERP.batchOption.utils.IBAUtil" %>

<%@page import="wt.session.SessionHelper" %>
<%@page import="java.util.ResourceBundle" %>
<%@page import="java.lang.reflect.Method" %>
<%@page import="org.apache.commons.lang.StringUtils" %>
<%@page import="com.ptc.netmarkets.util.beans.NmContextBean" %>
<%@page import="com.ptc.netmarkets.util.beans.NmCommandBean" %>
<%@page import="java.util.ArrayList" %>
<%@page import="com.ptc.netmarkets.model.NmOid" %>
<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/picker" prefix="p" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca" %>
<%@page import="wt.util.WTProperties" %>
<%@ page import="java.util.List" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc" %>
<jca:tabToHighlight actionName="propertyPanel" objectType="object"/>
<%@ include file="/netmarkets/jsp/util/begin.jspf" %>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb" %>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags" %>
<%
    System.out.println("进入添加");
    String contextPath = request.getContextPath();
    NmCommandBean cb1 = new NmCommandBean();
    cb1.setInBeginJsp(true);
    cb1.setOpenerCompContext(request.getParameter("compContext"));
    cb1.setOpenerElemAddress(NmCommandBean.convert(request.getParameter("openerElemAddress")));
    cb1.setCompContext(NmCommandBean.convert(request.getParameter("compContext")));
    cb1.setElemAddress(NmCommandBean.convert(request.getParameter("elemAddress")));
    cb1.setRequest(request);
    cb1.setResponse(response);
    cb1.setOut(out);
    cb1.setContextBean(new NmContextBean());
    ArrayList<NmOid> selected = cb1.getSelectedOidForPopup();
    List<WTPart> item = new ArrayList<>();

    for (NmOid nmOid : selected) {
        Object ref = nmOid.getRef();
        if (ref instanceof WTPart) {
            WTPart wtPart = (WTPart) ref;
            item.add(wtPart);
        }
    }

%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title>修改子项</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        #priceTable {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        #priceTable th,
        #priceTable td {
            position: relative;
            width: 170px;
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            overflow: hidden;
        }

        #priceTable th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #333;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            position: relative;
            /* 相对定位 */
        }

        #priceTable td input[type="text"] {
            display: block;
            width: 90%;
            margin-left: 5%;
            padding: 5px;
            border: 1px solid #ccc;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            border-radius: 3px;
            box-sizing: border-box;
            float: left;
            /* 添加 float 属性 */
        }

        #priceTable tr td input[type="text"]:read-only {
            background-color: #eee;
        }

        #priceTable td input[type="text"]:focus {
            outline: none;
            border-color: #66afe9;
            box-shadow: 0 0 5px #66afe9;
        }

        #priceTable tr td input[type="text"] + span {
            position: absolute;
            /* 绝对定位 */
            top: 14px;
            right: 11%;
        }

        p {
            margin-top: 20px;
            font-style: italic;
            color: #888;
        }

        .selectBox {
            display: block;
            width: 90%;
            margin-left: 5%;
            padding: 5px;
            border: 1px solid #ccc;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            border-radius: 3px;
            box-sizing: border-box;
            float: left;
            /* 添加 float 属性 */
        }

    </style>
</head>
<body>
<div class="search-container">
    *子项部件编号：<input name="childNumber" id="searchItemInput" type="text" placeholder="输入子项部件编号搜索...">
    <input type="button" onclick="searchData()" value="搜索">
</div>
<br><br><br>

批量修改数量:<input id="afterNumber" type="text">
批量修改工位:<input id="afterTagNumber" type="text">
批量修改行号:<input id="lineNumber" type="text">
批量添加物料行备注<input id="itemNote" type="text">

<%--批量修改行号<input name="lineNumber" type="text">--%>

批量修改是否客供料:
    <select id="isByCust" >
        <option value=""></option>
        <option value="0">否</option>
        <option value="1">是</option>
    </select>

批量修改是否售后料:
    <select id="isCustomerService" >
        <option value=""></option>
        <option value="0">否</option>
        <option value="1">是</option>

    </select>

批量修改是否跳层:
    <select id="BOMSkip" >
        <option value=""></option>
        <option value="0">否</option>
        <option value="1">是</option>

    </select></td>
   
<table id="priceTable">
    <thead>
    <tr>
        <th><input type="checkbox" id="selectAllCheckbox"></th>
        <th>*父项部件编号</th>
        <th>父项部件名称</th>

        <th>改前子项编号</th>
        <th>改前子项名称</th>
        <th>子项部件规格型号</th>
        <th>改前数量</th>
        <th>改前工位</th>

        <th>改后数量</th>
        <th>改后工位</th>

        <th>行号</th>
        <th>物料行备注</th>
        <th>否客供物料</th>
        <th>是否售后物料</th>
        <th>跳层</th>
    </tr>
    </thead>

    <tbody id="tableBody">

<%--    <tr>--%>
<%--        <td><input type="checkbox" class="rowCheckbox"></td>--%>
<%--        <td><input class="parentPartNumber" name="parentPartNumber" type="text" readonly></td>--%>
<%--        <td><input name="parentPartName" type="text" readonly></td>--%>

<%--        <td><input class="beforeChildPartNumber" name="beforChildPartNumber" type="text" readonly></td>--%>
<%--        <td><input class="beforeChildPartName" name="beforeChildPartName" type="text" readonly></td>--%>
<%--        <td><input class="beforeSpecificationsModel" name="beforeSpecificationsModel" type="text" readonly></td>--%>
<%--        <td><input name="beforeNumber" type="text" readonly></td>--%>
<%--        <td><input name="beforeTagNumber" type="text" readonly></td>--%>

<%--        <td><input name="afterNumber" type="text"></td>--%>
<%--        <td><input name="afterTagNumber" type="text"></td>--%>

<%--        <td><input name="lineNumber" type="text"></td>--%>

<%--        <td>--%>
<%--            <select name="isByCust" class="selectBox">--%>
<%--                <option value="否">否</option>--%>
<%--                <option value="是">是</option>--%>
<%--            </select>--%>
<%--        </td>--%>
<%--        <td>--%>
<%--            <select name="isCustomerService" class="selectBox">--%>
<%--                <option value="否">否</option>--%>
<%--                <option value="是">是</option>--%>

<%--            </select>--%>
<%--        </td>--%>
<%--        <td>--%>
<%--            <select name="BOMSkip" class="selectBox">--%>
<%--                <option value="否">否</option>--%>
<%--                <option value="是">是</option>--%>

<%--            </select></td>--%>
<%--        </td>--%>


<%--    </tr>--%>


    </tbody>
</table>
<tr>
    <%
        if (item.size()!=0) {

            for (WTPart part : item) {
    %>

    <input type="hidden" name="bomNumberList" value="<%=part.getNumber()%>">
    <%
        }}else{

    %>
    未选中BOM.请选择BOM之后搜索子项部件
    <% }%>
</tr>
<br>
<%--<input type="button" id="addRow" value="复制选中行/新增行">--%>
<input type="button" id="deleteRow" value="删除选中行">
</body>
<%@ include file="/netmarkets/jsp/util/end.jspf" %>
<script type="text/javascript">


       // 获取具有 name 属性为 'parentPartNumber' 的 input 元素
       const tableBody = document.getElementById('tableBody')
       //获取删除按钮
       const deleteButton = document.getElementById('deleteRow');

       // 删除选中行按钮点击事件
       deleteButton.addEventListener('click', function () {
           const checkboxes = document.querySelectorAll('.rowCheckbox:checked');
           checkboxes.forEach(checkbox => {
               const row = checkbox.closest('tr'); // 获取即将删除的行
               row.remove(); // 删除行
           });
           // 点击后禁用删除按钮
           deleteButton.disabled = true;
       });

       // 全选复选框事件
       selectAllCheckbox.addEventListener('change', function (e) {
           const checkboxes = document.querySelectorAll('.rowCheckbox');
           checkboxes.forEach(checkbox => {
               checkbox.checked = e.target.checked;
           });
           deleteButton.disabled = !e.target.checked; // 如果没有任何复选框被选中，则禁用删除按钮
       });
       // 表体行复选框事件
       tableBody.addEventListener('change', function (e) {
           if (e.target.matches('.rowCheckbox')) {
               const checkedCheckboxes = document.querySelectorAll('.rowCheckbox:checked');
               const allCheckboxes = document.querySelectorAll('.rowCheckbox');
               deleteButton.disabled = checkedCheckboxes.length === 0;
               // 更新全选复选框状态
               selectAllCheckbox.checked = checkedCheckboxes.length === allCheckboxes.length;
           }
       });

       //根据name获取输入框的值
       function getNumberList(name) {
           // 获取所有 name="bomNumberList" 的输入框
           var inputs = document.getElementsByName(name);
           // 创建一个空数组来存储输入框的值
           var values = [];
           // 遍历 NodeList，并将每个输入框的值放入数组
           for (var i = 0; i < inputs.length; i++) {
               values.push(inputs[i].value.trim());
           }

           return values;
       }

       function searchData() {
           //子部件编号
           var beforePartNumber = document.getElementById("searchItemInput").value
           console.log("子部件编号：", beforePartNumber)
           if (!beforePartNumber) {
               alert("请输入子部件编号")
           }
           const BOMPartNumber =  getNumberList("bomNumberList")
           console.log('输入框的值为：', BOMPartNumber);

           var jsonData = {
               optionType: "UPDATE",
               BOMPartNumber,
               beforePartNumber: beforePartNumber
           }

           jsonData = JSON.stringify(jsonData);
           jsonData = jsonData.replace(/\\"/g, '"').replace('"[', '[').replace(']"', ']'); ;
           console.log(jsonData)

           Ext.Ajax.request({
               url: 'servlet/Navigation/batchOption/DataDisplayController',
               method: 'POST', // 请求方法设置为 POST
               jsonData,
               success: function (response) {
                   var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                   console.log('成功获取数据：', result);

                   if (result.code != 200){
                       alert(result.msg)
                       tableBody.innerHTML = ''; // 清空表
                       return
                   }


                   tableBody.innerHTML = ''; // 清空表
                   result.data.forEach(function (item,index) {
                       const row = tableBody.insertRow();
                       const rowNum = index + 1;

                       var beforeSpecificationsModel = item.beforeSpecificationsModel == null ? "" : item.beforeSpecificationsModel
                       console.log("规格型号", beforeSpecificationsModel)

                       var  IsByCust =convertBackendValue(item.IsByCust)
                       var  IsCustomerService =convertBackendValue(item.IsCustomerService)
                       var  BOMSkip =convertBackendValue(item.BOMSkip)
                       row.innerHTML =
                           '<tr>' +
                           '<input type="hidden"  name="wtUserLink" value="' + item.wtUserLink + '"> ' +
                           '<td><input type="checkbox" class="rowCheckbox"></td>' +
                           '<td><input class="parentPartNumber" name="parentPartNumber"  type="text" readonly value="' + item.BOMPartNumber + '"></td>' +
                           ' <td><input name="parentPartName"  type="text" readonly value="' + item.BOMPartName + '" readonly ></td>' +

                           ' <td><input  class="beforePartNumber" name="beforeChildPartNumber" type="text" readonly value="' + item.beforePartNumber + '" ></td>' +
                           ' <td><input class="beforePartName" name="afterChildPartName" type="text" readonly value="' + item.beforePartName + '"  ></td>' +
                           '<td><input type="text" name="beforeSpecificationsModel" value="' + item.beforeSpecificationsModel + '" readonly ></td>' +
                           '<td><input name="beforeNumber" type="text" value="' + item.beforeNumber + '" readonly></td>' +
                           ' <td><input name="beforeTagNumber" type="text" value="' + item.beforeTagNumber + '" readonly></td>' +

                           '<td><input name="afterNumber" value="' + item.beforeNumber + '"  type="text" ></td>' +
                           ' <td><input name="afterTagNumber" value="' + item.beforeTagNumber + '"  type="text" ></td>' +

                           

                           '<td><input name="lineNumber" type="text" value="' + item.lineNumber + '" ></td>' +

                           '  <td><input name="itemNote" type="text" value="' + item.itemNote + '" ></td>' +

                           '<td> <select name="isByCust" class="selectBox"> <option value="'+item.IsByCust+'">'+IsByCust+'</option>  <option value="0">否</option>  <option value="1">是</option> </select> </td>' +
                           '<td><select name="isCustomerService" class="selectBox"> <option value="'+item.IsCustomerService+'">'+IsCustomerService+'</option> <option value="0">否</option> <option value="1">是</option> </select></td>' +
                           '<td> <select name="BOMSkip" class="selectBox"> <option value="'+item.BOMSkip+'">'+BOMSkip+'</option> <option value="0">否</option> <option value="1">是</option> </select> </td>' +

                           '</tr>'
                       // 插入到目标行的后面
                   });
                   changeTitle()
               },
               failure: function (response) {
                   console.error('请求失败：', response.statusText);
               }
           });

       }


       //将后端0改否 1改是
       function convertBackendValue(value) {
           if (value === '0') {
               return '否';
           } else if (value === '1') {
               return '是';
           } else if(value === ""){
               return ''; // 处理空字符串
           }else{
               return value;
           }
       }


       //
       // // 监听复制按钮的点击事件
       // addRowBtn.addEventListener('click', function () {
       //     var tableBody = document.getElementById('tableBody');
       //     var selectedRows = tableBody.querySelectorAll('.rowCheckbox:checked'); // 检查选择器是否正确
       //
       //     if (selectedRows.length > 0) {
       //         console.log("复制选中行"); // 确保这个输出在点击事件中显示
       //
       //         selectedRows.forEach(function (row) {// row是input
       //             const td = row.closest('td');//  获取td
       //             row = td.closest('tr') //  获取行tr --- row
       //
       //             // 创建新行
       //             var newRow = document.createElement('tr');
       //
       //             // 遍历当前行的所有单元格
       //             var cells = row.querySelectorAll('td');
       //             cells.forEach(function (cell) {
       //                 // 创建新单元格
       //                 var newCell = document.createElement('td');
       //
       //                 // 检查是否有输入框
       //                 var input = cell.querySelector('input');
       //                 if (input) {
       //                     // 创建新的输入框并设置值
       //                     var newInput = document.createElement('input');
       //
       //                     if (input.readOnly || input.disabled) {
       //                         newInput.readOnly = true
       //                     }
       //                     newInput.type = input.type;
       //                     newInput.value = input.value;
       //                     newInput.name = input.name;
       //                     newInput.className = input.className;
       //
       //
       //                     // 将新输入框添加到新单元格中
       //                     newCell.appendChild(newInput);
       //                 } else {
       //                     // 如果没有输入框，则直接复制原始单元格的内容
       //                     newCell.innerHTML = cell.innerHTML;
       //                 }
       //                 newRow.appendChild(newCell);
       //
       //
       //                 // var newRow = document.createElement('tr');
       //                 // newRow.innerHTML = row.innerHTML; // 确保复制行的HTML内容正确设置
       //                 row.parentNode.insertBefore(newRow, row.nextSibling);
       //             })
       //         })
       //     } else {
       //         // 如果没有选中行，新增一行空白行
       //         var newRow = document.createElement('tr');
       //         newRow.innerHTML =
       //             '<td><input type="checkbox" class="rowCheckbox"></td>' +
       //             '<td><input name="optionType" type="text" value="移除子项" readonly></td>' +
       //             '<td><input class="parentPartNumber" name="parentPartNumber" type="text"></td>' +
       //             '<td><input name="parentPartName" type="text" readonly></td>' +
       //             '<td><input class="childPartNumber" name="childPartNumber" type="text"></td>' +
       //             '<td><input name="childPartName" type="text" readonly></td>' +
       //             '<td><input name="number" type="text" readonly></td>' +
       //             '<td><input name="tagNumber" type="text" readonly></td>' +
       //             '<td><input name="lineNumber" type="text" readonly></td>'
       //         tableBody.appendChild(newRow); // 将新行添加到表格中
       //     }
       // });
       //
       //

       function batchChangeInput(inputId , inputName) {

           var input = document.getElementById(inputId)
           input.addEventListener('change', function (event) {
               var inputValue = input.value;
               console.log(inputValue)
               // 获取所有 name="LifelessPartHandMet" 的输入框
               var inputs = document.getElementsByName(inputName);
               // 将选中的值填入所有输入框
               for (var i = 0; i < inputs.length; i++) {
                   inputs[i].value = inputValue;
               }
           })
       }
        //批量修改
       batchChangeInput("afterNumber","afterNumber")
       batchChangeInput("isByCust","isByCust")
       batchChangeInput("isCustomerService","isCustomerService")
       batchChangeInput("BOMSkip","BOMSkip")
       batchChangeInput("itemNote","itemNote")
       batchChangeInput("lineNumber","lineNumber")
       batchChangeInput("afterTagNumber","afterTagNumber")


       function changeTitle() {
           // 获取所有的输入框
           const inputs = document.querySelectorAll('input');

           // 遍历每个输入框
           inputs.forEach(input => {
               // 添加输入事件监听器，当用户输入内容时更新title属性
               var inputValue = input.value == null ? "" : input.value

               input.setAttribute('title', inputValue);
           });
       }
       changeTitle()

       // 确保改前数量是int类型且大于等于0的函数
       function validateNumber(input) {

           var days = parseInt(input.value, 10); // 尝试将输入转换为整数
           if (isNaN(days) || !Number.isInteger(days) || days < 0) { // 检查是否为数字且为整数且大于等于0
               alert("改后数量必填且为大于等于0的整数"); // 提示消息
               input.value = ""; // 清空输入框
           }

       }



       // 添加粘贴事件监听器到整个文档
       document.addEventListener('paste', function (event) {
           // 阻止默认粘贴行为，因为我们需要自定义处理
           event.preventDefault();

           // 获取粘贴板内容
           let pastedText = '';
           if (event.clipboardData && event.clipboardData.getData) {
               pastedText = event.clipboardData.getData('text/plain');
           } else if (window.clipboardData && window.clipboardData.getData) {
               pastedText = window.clipboardData.getData('Text');
           }

           pastedText = pastedText.trim()

           // 将处理后的文本插入到输入框中
           document.execCommand('insertText', false, pastedText);
       });

</script>

</html>
