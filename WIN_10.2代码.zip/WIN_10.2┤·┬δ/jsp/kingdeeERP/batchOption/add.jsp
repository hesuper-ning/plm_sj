<%@page import="wt.part.WTPart" %>

<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="org.codehaus.jackson.map.ObjectMapper" %>
<jca:tabToHighlight actionName="propertyPanel" objectType="object"/>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

</head>
<body>
</body>
</html>
