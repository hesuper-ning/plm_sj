<%@page import="wt.part.WTPart" %>
<%@page import="wt.part.WTPartSubstituteLink" %>
<%@page import="wt.part.WTPartMaster" %>
<%@page import="wt.change2.WTChangeOrder2" %>
<%@page import="java.util.Arrays" %>

<%@page import="ext.kingdeeERP.batchOption.utils.IBAUtil" %>

<%@page import="wt.session.SessionHelper" %>
<%@page import="java.util.ResourceBundle" %>
<%@page import="java.lang.reflect.Method" %>
<%@page import="org.apache.commons.lang.StringUtils" %>
<%@page import="com.ptc.netmarkets.util.beans.NmContextBean" %>
<%@page import="com.ptc.netmarkets.util.beans.NmCommandBean" %>
<%@page import="java.util.ArrayList" %>
<%@page import="com.ptc.netmarkets.model.NmOid" %>
<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/picker" prefix="p" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca" %>
<%@page import="wt.util.WTProperties" %>
<%@ page import="java.util.List" %>
<%@ page import="org.codehaus.jackson.map.ObjectMapper" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc" %>
<jca:tabToHighlight actionName="propertyPanel" objectType="object"/>
<%@ include file="/netmarkets/jsp/util/begin.jspf" %>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb" %>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags" %>
<%
    System.out.println("进入添加");
    String contextPath = request.getContextPath();
    NmCommandBean cb1 = new NmCommandBean();
    cb1.setInBeginJsp(true);
    cb1.setOpenerCompContext(request.getParameter("compContext"));
    cb1.setOpenerElemAddress(NmCommandBean.convert(request.getParameter("openerElemAddress")));
    cb1.setCompContext(NmCommandBean.convert(request.getParameter("compContext")));
    cb1.setElemAddress(NmCommandBean.convert(request.getParameter("elemAddress")));
    cb1.setRequest(request);
    cb1.setResponse(response);
    cb1.setOut(out);
    cb1.setContextBean(new NmContextBean());
    ArrayList<NmOid> selected = cb1.getSelectedOidForPopup();
    List<WTPart> item = new ArrayList<>();

    for (NmOid nmOid : selected) {
        Object ref = nmOid.getRef();
        if (ref instanceof WTPart) {
            WTPart wtPart = (WTPart) ref;
            item.add(wtPart);
        }
    }


%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title>删除子项</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        #priceTable {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        #priceTable th,
        #priceTable td {
            position: relative;
            width: 170px;
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            overflow: hidden;
        }

        #priceTable th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #333;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            position: relative;
            /* 相对定位 */
        }

        #priceTable td input[type="text"] {
            display: block;
            width: 90%;
            margin-left: 5%;
            padding: 5px;
            border: 1px solid #ccc;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            border-radius: 3px;
            box-sizing: border-box;
            float: left;
            /* 添加 float 属性 */
        }

        #priceTable tr td input[type="text"]:read-only {
            background-color: #eee;
        }

        #priceTable td input[type="text"]:focus {
            outline: none;
            border-color: #66afe9;
            box-shadow: 0 0 5px #66afe9;
        }

        #priceTable tr td input[type="text"] + span {
            position: absolute;
            /* 绝对定位 */
            top: 14px;
            right: 11%;
        }

        p {
            margin-top: 20px;
            font-style: italic;
            color: #888;
        }

    </style>
</head>
<body>
<div class="search-container">
    *子项部件编号：<input name="childNumber" id="searchItemInput" type="text" placeholder="输入子项部件编号搜索...">
    <input type="button" onclick="searchData()" value="搜索">
</div>
<table id="priceTable">
    <thead>
    <tr>
        <th><input type="checkbox" id="selectAllCheckbox"></th>
        <th>*BOM编号</th>
        <th>BOM名称</th>
        <th>*子项部件编号</th>
        <th>*子项部件名称</th>
        <th>*子项部件规格型号</th>
        <th>数量</th>
        <th>工位</th>
        <th>行号</th>
    </tr>
    </thead>

    <tbody id="tableBody">



<%--    <tr>--%>
<%--        <td><input type="checkbox" class="rowCheckbox"></td>--%>
<%--        <td><input class="parentPartNumber" name="parentPartNumber" type="text" readonly></td>--%>
<%--        <td><input name="parentPartName" type="text" readonly></td>--%>
<%--        <td><input class="beforePartNumber" name="beforeChildNumber" type="text"></td>--%>
<%--        <td><input class="beforePartName" name="afterChildPartName" type="text"></td>--%>
<%--        <td><input class="afterSpecificationsModel" name="afterSpecificationsModel" type="text"></td>--%>
<%--        <td><input name="beforeTagNumber" type="text"></td>--%>
<%--        <td><input name="number" type="text"></td>--%>
<%--        <td><input name="lineNumber" type="text"></td>--%>
<%--    </tr>--%>
    </tbody>

</table>
<tr>
    <%
        if (item.size()!=0) {

            for (WTPart part : item) {
    %>

    <input type="hidden" name="bomNumberList" value="<%=part.getNumber()%>">
    <%
        }}else{

    %>
    未选中BOM.请选择BOM之后搜索子项部件
    <% }%>
</tr>
<br>
<%--<input type="button" id="addRow" value="复制选中行/新增行">--%>
<input type="button" id="deleteRow" value="删除选中行">
</body>

<%@ include file="/netmarkets/jsp/util/end.jspf" %>
<script>
    // 获取具有 name 属性为 'parentPartNumber' 的 input 元素
    const tableBody = document.getElementById('tableBody')
    const addRowBtn = document.getElementById("addRow")
    //获取删除按钮
    const deleteButton = document.getElementById('deleteRow');

    //根据name获取输入框的值
    function getNumberList(name) {
        // 获取所有 name="bomNumberList" 的输入框
        var inputs = document.getElementsByName(name);
        // 创建一个空数组来存储输入框的值
        var values = [];
        // 遍历 NodeList，并将每个输入框的值放入数组
        for (var i = 0; i < inputs.length; i++) {
            values.push(inputs[i].value.trim());
        }

        return values;
    }



    function searchData() {
        //子部件编号
        var beforePartNumber = document.getElementById("searchItemInput").value
        console.log("子部件编号：", beforePartNumber)
        if (!beforePartNumber) {
            alert("请输入子部件编号")
        }
        const BOMPartNumber =  getNumberList("bomNumberList")
        console.log('输入框的值为：', BOMPartNumber);

        var jsonData = {
            optionType: "DELETE",
            BOMPartNumber,
            beforePartNumber: beforePartNumber
        }

        jsonData = JSON.stringify(jsonData);
        jsonData = jsonData.replace(/\\"/g, '"').replace('"[', '[').replace(']"', ']'); ;
        console.log(jsonData)

        Ext.Ajax.request({
            url: 'servlet/Navigation/batchOption/DataDisplayController',
            method: 'POST', // 请求方法设置为 POST
            jsonData,
            success: function (response) {
                var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                console.log('成功获取数据：', result);

                if (result.code != 200){
                    alert(result.msg)
                    tableBody.innerHTML = ''; // 清空表
                    return
                }


                tableBody.innerHTML = ''; // 清空表
                result.data.forEach(function (item,index) {
                    const row = tableBody.insertRow();
                    const rowNum = index + 1;

                    var beforeSpecificationsModel = item.beforeSpecificationsModel == null ? "" : item.beforeSpecificationsModel
                    console.log("规格型号", beforeSpecificationsModel)
                    row.innerHTML =
                        '<tr>' +
                        '<input type="hidden"  name="wtUserLink" value="' + item.wtUserLink + '"> ' +
                        '<td><input type="checkbox" class="rowCheckbox"></td>' +
                        '<td><input class="parentPartNumber" name="parentPartNumber"  type="text" readonly value="' + item.BOMPartNumber + '"></td>' +
                        ' <td><input name="parentPartName"  type="text" readonly value="' + item.BOMPartName + '" readonly ></td>' +
                        ' <td><input  class="beforePartNumber" name="beforeChildNumber" type="text" readonly value="' + item.beforePartNumber + '" ></td>' +
                        ' <td><input class="beforePartName" name="afterChildPartName" type="text" readonly value="' + item.beforePartName + '"  ></td>' +
                        '<td><input type="text" name="beforeSpecificationsModel" value="' + item.beforeSpecificationsModel + '" readonly ></td>' +
                        '<td><input name="number" type="text" value="' + item.beforeNumber + '" readonly></td>' +
                        ' <td><input name="beforeTagNumber" type="text" value="' + item.beforeTagNumber + '" readonly></td>' +
                        '<td><input name="lineNumber" type="text" value="' + item.lineNumber + '" readonly></td>' +
                        '</tr>'
                    // 插入到目标行的后面
                });
                changeTitle()


            },
            failure: function (response) {
                console.error('请求失败：', response.statusText);
            }
        });

    }
    // 删除选中行按钮点击事件
    deleteButton.addEventListener('click', function () {
        const checkboxes = document.querySelectorAll('.rowCheckbox:checked');
        checkboxes.forEach(checkbox => {
            const row = checkbox.closest('tr'); // 获取即将删除的行
            row.remove(); // 删除行
        });
        // 点击后禁用删除按钮
        deleteButton.disabled = true;
    });

    // 全选复选框事件
    selectAllCheckbox.addEventListener('change', function (e) {
        const checkboxes = document.querySelectorAll('.rowCheckbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = e.target.checked;
        });
        deleteButton.disabled = !e.target.checked; // 如果没有任何复选框被选中，则禁用删除按钮
    });
    // 表体行复选框事件
    tableBody.addEventListener('change', function (e) {
        if (e.target.matches('.rowCheckbox')) {
            const checkedCheckboxes = document.querySelectorAll('.rowCheckbox:checked');
            const allCheckboxes = document.querySelectorAll('.rowCheckbox');
            deleteButton.disabled = checkedCheckboxes.length === 0;
            // 更新全选复选框状态
            selectAllCheckbox.checked = checkedCheckboxes.length === allCheckboxes.length;
        }
    });



    function changeTitle() {
        // 获取所有的输入框
        const inputs = document.querySelectorAll('input');

        // 遍历每个输入框
        inputs.forEach(input => {
            // 添加输入事件监听器，当用户输入内容时更新title属性
            var inputValue = input.value == null ? "" : input.value

            input.setAttribute('title', inputValue);
        });
    }

    changeTitle()

</script>

</html>
