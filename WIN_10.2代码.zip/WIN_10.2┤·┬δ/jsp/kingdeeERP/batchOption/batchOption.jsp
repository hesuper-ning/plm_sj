<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca" %>
<%@page import="wt.util.WTProperties" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc" %>
<jca:tabToHighlight actionName="propertyPanel" objectType="object"/>
<%@ include file="/netmarkets/jsp/util/begin.jspf" %>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb" %>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags" %>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>批量操作</title>

</head>
<body>

<div class="search-container">
        *项目部件名称：<input name="itemName" id="searchItemInput" type="text" placeholder="输入项目部件名称搜索...">
        *BOM部件名称：<input name="bomName" id="searchBOMInput" type="text" placeholder="输入BOM名称搜索...">
         <input type="button" onclick="searchData()" value="搜索">
</div>


<div class="cover" id="cover">
    <jsp:include page="${mvc:getComponentURL('ext.kingdeeERP.batchOption.builder.PartListSearchTable')}" flush="False"/>
</div>
<%@ include file="/netmarkets/jsp/util/end.jspf" %>

<script>
    function searchData() {
        const searchItemInput = document.getElementById('searchItemInput').value.trim();
        const searchBOMInput = document.getElementById('searchBOMInput').value.trim();
        var params = {
            itemName : searchItemInput,
            bomName : searchBOMInput,
        }

        if (!searchItemInput || !searchBOMInput ){
            alert("未输入项目名称或BOM名称，请填写!")
            return
        }

        var cover = document.getElementById('cover')
        cover.style.display = "none";
        setTimeout(function () {
            cover.style.display = "block";
        },2000);
        PTC.jca.table.Utils.reload("ext.kingdeeERP.batchOption.builder.PartListSearchTable",params,false)
    }
</script>
</body>

</html>