<%@ page language="java" import="java.util.*" pageEncoding="utf-8"%>
<script><%@ include file="jquery-1.7.1.min.js"%></script>
<%@page import="wt.doc.WTDocument"%>
<%@page import="wt.epm.EPMDocument"%>

<%@page import="com.ptc.netmarkets.model.NmOid"%>
<%@page import="java.util.ArrayList"%>
<%@page import="com.ptc.netmarkets.util.beans.NmContextBean"%>
<%@page import="com.ptc.netmarkets.util.beans.NmCommandBean"%>

<%
	String oid = request.getParameter("oid");
	String wayType = request.getParameter("wayType");
	String upload = "servlet/Navigation/changeBOM/UploadChangeBomExcelController?url=" + request.getRequestURL()+"&wayType="+wayType+"&oid="+oid;
	
	String path = request.getContextPath();
	String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + path + "/";
	
	String butonName = "点击导入";
	if("updateECFile".equals(wayType)){
		butonName="点击上传";
	}
%>

<script language="Javascript">
    function validateFile(){    
		var file = document.getElementById("documentFile").value;
		var suffix = file.substring(file.indexOf('.')+1,file.length);

		if("xlsx" != suffix.toLowerCase()){
			alert("只支持xlsx文件，请重新上传！");
			return false;
		}else{
			return true;
		}
    }
	

</script>


<title>导入</title>
<div>
<br>


<form name="form1" id="form1" action="<%=upload%>" enctype="multipart/form-data" method="post">
	<table cellpadding="0" style="border-collapse: collapse; border: 0px solid #003399;">
		<tr>
			<td style="cursor: pointer;">&nbsp;&nbsp;请选择文件:<br>
			&nbsp;&nbsp;<input type="file" size="60" id="documentFile" name="documentFile"
				style="color: Blue; background-color: White; border-width: 1px; border-style: Solid; font-family: 宋体; font-size: 10pt; height: 22px; width: 385px;">
				&nbsp;<input type="submit" value="<%=butonName%>" onclick="return validateFile();"/>
			</td>
		</tr>
	
	</table>
</form>
</div>

<div><font color="red" size="2">
</font>
</div>

<style type="text/css">

</style>