<%@page language="java" session="true" pageEncoding="UTF-8"%>
<%@ taglib prefix="jca" uri="http://www.ptc.com/windchill/taglib/components" %>
<%@ include file="/netmarkets/jsp/components/beginWizard.jspf"%>
<%@ include file="/netmarkets/jsp/components/includeWizBean.jspf"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<jca:wizard title="修改变更项" >
	<jca:wizardStep action="updateItem" type="changeNotBom" />
</jca:wizard>
<%@ include file="/netmarkets/jsp/util/end.jspf"%>
