<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib prefix="jca" uri="http://www.ptc.com/windchill/taglib/components" %>


<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title>删除子项</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        #priceTable {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        #priceTable th,
        #priceTable td {
            position: relative;
            width: 170px;
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            overflow: hidden;
        }

        #priceTable th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #333;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            position: relative;
            /* 相对定位 */
        }

        #priceTable td input[type="text"] {
            display: block;
            width: 90%;
            margin-left: 5%;
            padding: 5px;
            border: 1px solid #ccc;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            border-radius: 3px;
            box-sizing: border-box;
            float: left;
            /* 添加 float 属性 */
        }

        #priceTable tr td input[type="text"]:read-only {
            background-color: #eee;
        }

        #priceTable td input[type="text"]:focus {
            outline: none;
            border-color: #66afe9;
            box-shadow: 0 0 5px #66afe9;
        }

        #priceTable tr td input[type="text"] + span {
            position: absolute;
            /* 绝对定位 */
            top: 14px;
            right: 11%;
        }

        p {
            margin-top: 20px;
            font-style: italic;
            color: #888;
        }

    </style>
</head>
<body>
<table id="priceTable">
    <thead>
    <tr>

        <th><input type="checkbox" id="selectAllCheckbox"></th>
        <th>修改类型</th>
        <th>父项部件编号</th>
        <th>父项部件名称</th>
        <th>改前子项部件编号</th>
        <th>改前子项部件名称</th>
        <th>规格型号</th>
        <th>改前数量</th>
        <th>改前工位</th>
        <th>行号</th>
    </tr>
    </thead>
    <tbody id="tableBody">
    <tr>
        <input type="hidden" name="wtUserLink">
        <td><input type="checkbox" class="rowCheckbox"></td>
        <td><input name="optionType" type="text" value="移除子项" readonly></td>
        <td><input class="parentPartNumber" name="parentPartNumber" type="text"></td>
        <td><input name="parentPartName" type="text" readonly></td>


        <td><input class="childPartNumber" name="childPartNumber" type="text"></td>
        <td><input name="childPartName" type="text" readonly></td>

        <td><input type="text" name="beforeSpecificationsModel" readonly></td>
        <td><input name="number" type="text" readonly></td>
        <td><input name="tagNumber" type="text" readonly></td>
        <td><input name="lineNumber" type="text" readonly></td>
    </tr>
    </tbody>
</table>

<input type="button" id="addRow" value="复制选中行/新增行">
<input type="button" id="deleteRow" value="删除选中行">
</body>


<script>

    // 获取具有 name 属性为 'parentPartNumber' 的 input 元素
    const parentPartNumberInput = document.querySelector('input[name="parentPartNumber"]');
    const tableBody = document.getElementById('tableBody')
    const addRowBtn = document.getElementById("addRow")
    //获取删除按钮
    const deleteButton = document.getElementById('deleteRow');


    // 删除选中行按钮点击事件
    deleteButton.addEventListener('click', function () {
        const checkboxes = document.querySelectorAll('.rowCheckbox:checked');
        checkboxes.forEach(checkbox => {
            const row = checkbox.closest('tr'); // 获取即将删除的行
            row.remove(); // 删除行
        });
        // 点击后禁用删除按钮
        deleteButton.disabled = true;
    });

    // 全选复选框事件
    selectAllCheckbox.addEventListener('change', function (e) {
        const checkboxes = document.querySelectorAll('.rowCheckbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = e.target.checked;
        });
        deleteButton.disabled = !e.target.checked; // 如果没有任何复选框被选中，则禁用删除按钮
    });
    // 表体行复选框事件
    tableBody.addEventListener('change', function (e) {
        if (e.target.matches('.rowCheckbox')) {
            const checkedCheckboxes = document.querySelectorAll('.rowCheckbox:checked');
            const allCheckboxes = document.querySelectorAll('.rowCheckbox');
            deleteButton.disabled = checkedCheckboxes.length === 0;
            // 更新全选复选框状态
            selectAllCheckbox.checked = checkedCheckboxes.length === allCheckboxes.length;
        }
    });


    // 监听复制按钮的点击事件
    addRowBtn.addEventListener('click', function () {
        var tableBody = document.getElementById('tableBody');
        var selectedRows = tableBody.querySelectorAll('.rowCheckbox:checked'); // 检查选择器是否正确

        if (selectedRows.length > 0) {
            console.log("复制选中行"); // 确保这个输出在点击事件中显示

            selectedRows.forEach(function (row) {// row是input
                const td = row.closest('td');//  获取td
                row = td.closest('tr') //  获取行tr --- row

                // 创建新行
                var newRow = document.createElement('tr');

                // 遍历当前行的所有单元格
                var cells = row.querySelectorAll('td');
                cells.forEach(function (cell) {
                    // 创建新单元格
                    var newCell = document.createElement('td');

                    // 检查是否有输入框
                    var input = cell.querySelector('input');
                    if (input) {
                        // 创建新的输入框并设置值
                        var newInput = document.createElement('input');

                        if (input.readOnly || input.disabled) {
                            newInput.readOnly = true
                        }
                        newInput.type = input.type;
                        newInput.value = input.value;
                        newInput.name = input.name;
                        newInput.className = input.className;


                        // 将新输入框添加到新单元格中
                        newCell.appendChild(newInput);
                    } else {
                        // 如果没有输入框，则直接复制原始单元格的内容
                        newCell.innerHTML = cell.innerHTML;
                    }
                    newRow.appendChild(newCell);


                    // var newRow = document.createElement('tr');
                    // newRow.innerHTML = row.innerHTML; // 确保复制行的HTML内容正确设置
                    row.parentNode.insertBefore(newRow, row.nextSibling);
                })
            })
        } else {
            // 如果没有选中行，新增一行空白行
            var newRow = document.createElement('tr');
            newRow.innerHTML =
                // 加一个隐藏表单域里面放的是回显接口返回的link对象
                '<input type="hidden" name="wtUserLink">' +
                '<td><input type="checkbox" class="rowCheckbox"></td>' +
                '<td><input name="optionType" type="text" value="移除子项" readonly></td>' +
                '<td><input class="parentPartNumber" name="parentPartNumber" type="text"></td>' +
                '<td><input name="parentPartName" type="text" readonly ></td>' +
                '<td><input class="childPartNumber" name="childPartNumber" type="text"></td>' +
                '<td><input name="childPartName" type="text" readonly ></td>' +
                '<td><input type="text" name="beforeSpecificationsModel" readonly ></td>' +
                '<td><input name="number" type="text" readonly></td>' +
                '<td><input name="tagNumber" type="text" readonly></td>' +
                '<td><input name="lineNumber" type="text" readonly></td>'
            tableBody.appendChild(newRow); // 将新行添加到表格中
        }
    });


    let focusedElement = null;
    //聚焦对象
    tableBody.addEventListener('focusin', function (event) {
        focusedElement = event.target;
    });

    // 监听表格主体的失焦事件，使用事件委托
    tableBody.addEventListener('blur', function (event) {
        var target = event.relatedTarget || document.activeElement;


        if (target === null || (target !== focusedElement && !focusedElement.contains(target))) {
            // 检查事件目标是否为类名为 parentPartNumber 的输入框
            if (focusedElement && focusedElement.matches('.parentPartNumber')) {
                target = event.target
                var parentPartNumber = event.target.value;
                console.log('父项部件编号失焦，值为:', parentPartNumber);
                // 示例：可以通过 event.target.closest('tr') 获取当前行，然后对其他输入框进行操作
                if (!parentPartNumber) {
                    alert("请输入父部件编号！")
                    return
                }
                Ext.Ajax.request({
                    url: 'servlet/Navigation/changeBOM/EchoDataController?parentPartNumber=' + parentPartNumber,
                    type: 'GET',
                    success: function (response) {
                        var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                        console.log('成功获取数据：', result);

                        // 如果 parentPartName 为空，则弹窗提醒用户

                        if (result.code != 200) {
                            alert(result.msg);
                            return;
                        }
                        var parentPartName = result.data.parentPartName;

                        if (!parentPartName || parentPartName.trim() === '') {
                            alert("父项部件不存在或名称为空");
                        }
                        // 找到包含target的<td>元素
                        const td = target.closest('td');

                        // 获取td元素的下一个兄弟td元素
                        const nextTd = td.nextElementSibling;
                        // 在下一个td元素内查找<input>元素
                        const nextInput = nextTd.querySelector('input');

                        //将编号得到的值填到name框
                        nextInput.value = parentPartName;
                        changeTitle();
                    },
                    failure: function (response) {
                        console.error('请求失败：', response.statusText);
                    }
                });


            }

            if (focusedElement && focusedElement.matches(".childPartNumber")) {
                target = event.target
                // 找到包含target的<td>元素
                const td = target.closest('td');//  获取td
                const row = td.closest('tr') //  获取行tr --- row
                // 获取行内的所有单元格（td 元素）
                const cells = row.querySelectorAll('td');
                //当前的td下标
                const currentCellIndex = Array.from(cells).indexOf(td);

                // 在上上一个td元素内查找<input>元素的value
                parentPartNumber = cells[currentCellIndex - 2].querySelector('input').value
                parentPartName = cells[currentCellIndex - 1].querySelector('input').value
                //当前td的input
                currInput = cells[currentCellIndex].querySelector('input')
                // 在下一个td元素内查找<input>元素
                nextInput = cells[currentCellIndex + 1].querySelector('input')
                beforeNumber = cells[currentCellIndex + 2].querySelector('input')
                beforeTagNumber = cells[currentCellIndex + 3].querySelector('input')
                lineNumber = cells[currentCellIndex + 4].querySelector('input')


                //当前选中部件
                var beforePartNumber = event.target.value;
                if (!beforePartNumber) {
                    alert("请输入改前子项部件编号！")
                    nextInput.value = ""
                    currInput.value = ""
                    beforeNumber.value = ""
                    beforeTagNumber.value = ""
                    lineNumber.value = ""
                    return
                }


                if (!parentPartNumber) {
                    alert("请输入父部件编号！")
                    nextInput.value = ""
                    currInput.value = ""
                    beforeNumber.value = ""
                    beforeTagNumber.value = ""
                    lineNumber.value = ""
                    return
                }

                Ext.Ajax.request({
                    url: 'servlet/Navigation/changeBOM/EchoDataInfoController',
                    method: 'POST', // 请求方法设置为 POST
                    jsonData: {
                        changeType: "deleteSonPart",
                        parentPartNumber: parentPartNumber,
                        beforePartNumber: beforePartNumber,
                    },
                    success: function (response) {
                        var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                        console.log('成功获取数据：', result);

                        if (result.code != 200) {
                            alert(result.msg)
                            nextInput.value = ""
                            currInput.value = ""
                            beforeNumber.value = ""
                            beforeTagNumber.value = ""
                            lineNumber.value = ""
                            return
                        }

                        // 构建新行的 HTML 字符串
                        result.data.forEach(function (item) {
                            var newRow = document.createElement('tr')
                            var beforeSpecificationsModel = item.beforeSpecificationsModel == null ? "" : item.beforeSpecificationsModel
                            console.log("规格型号", beforeSpecificationsModel)
                            newRow.innerHTML =
                                '<tr>' +
                                '<input type="hidden"  name="wtUserLink" value="' + item.wtUserLink + '"> ' +
                                '<td><input type="checkbox" class="rowCheckbox"></td>' +
                                '<td><input name="optionType" type="text" value="移除子项" readonly></td>' +
                                '<td><input class="parentPartNumber" name="parentPartNumber"  type="text" value="' + parentPartNumber + '"></td>' +
                                ' <td><input name="parentPartName"  type="text" value="' + parentPartName + '" readonly ></td>' +

                                ' <td><input class="childPartNumber" name="childPartNumber" value="' + beforePartNumber + '" type="text"></td>' +
                                ' <td><input name="childPartName" type="text" value="' + item.beforePartName + '" readonly ></td>' +

                                '<td><input type="text" name="beforeSpecificationsModel" value="' + beforeSpecificationsModel + '" readonly ></td>' +
                                '<td><input name="number" type="text" value="' + item.beforeNumber + '" readonly></td>' +
                                ' <td><input name="tagNumber" type="text" value="' + item.beforeTagNumber + '" readonly></td>' +
                                '<td><input name="lineNumber" type="text" value="' + item.lineNumber + '" readonly></td>' +
                                '</tr>'
                            // 插入到目标行的后面
                            row.parentNode.insertBefore(newRow, row.nextSibling);
                        });
                        row.remove();
                        changeTitle();
                    },
                    failure: function (response) {
                        console.error('请求失败：', response.statusText);
                    }
                });


            }
        }
    }, true); // 使用捕获阶段，以确保事件委托的正确性

    // 添加粘贴事件监听器到整个文档
    document.addEventListener('paste', function (event) {
        // 阻止默认粘贴行为，因为我们需要自定义处理
        event.preventDefault();

        // 获取粘贴板内容
        let pastedText = '';
        if (event.clipboardData && event.clipboardData.getData) {
            pastedText = event.clipboardData.getData('text/plain');
        } else if (window.clipboardData && window.clipboardData.getData) {
            pastedText = window.clipboardData.getData('Text');
        }

        pastedText = pastedText.trim()

        // 将处理后的文本插入到输入框中
        document.execCommand('insertText', false, pastedText);
    });


    function changeTitle() {
        // 获取所有的输入框
        const inputs = document.querySelectorAll('input');

        // 遍历每个输入框
        inputs.forEach(input => {
            // 添加输入事件监听器，当用户输入内容时更新title属性
            input.setAttribute('title', input.value);
        });
    }

</script>

</html>
