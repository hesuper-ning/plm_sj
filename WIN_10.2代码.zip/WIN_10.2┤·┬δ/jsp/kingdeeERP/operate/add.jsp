<%@page import="com.ptc.netmarkets.util.beans.NmContextBean" %>
<%@page import="com.ptc.netmarkets.util.beans.NmCommandBean" %>
<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib prefix="jca" uri="http://www.ptc.com/windchill/taglib/components" %>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags" %>
<%
    String oid = request.getParameter("oid");

%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <style>
      

        #priceTable {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        #priceTable th,
        #priceTable td {
            position: relative;
            width: 170px;
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            overflow: hidden;
        }

        #priceTable th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #333;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            position: relative;
            /* 相对定位 */
        }

        #priceTable td input[type="text"] {
            display: block;
            width: 90%;
            margin-left: 5%;
            padding: 5px;
            border: 1px solid #ccc;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            border-radius: 3px;
            box-sizing: border-box;
            float: left;
            /* 添加 float 属性 */
        }

        #priceTable tr td input[type="text"]:read-only {
            background-color: #eee;
        }

        #priceTable td input[type="text"]:focus {
            outline: none;
            border-color: #66afe9;
            box-shadow: 0 0 5px #66afe9;
        }

        #priceTable tr td input[type="text"] + span {
            position: absolute;
            /* 绝对定位 */
            top: 14px;
            right: 11%;
        }

        p {
            margin-top: 20px;
            font-style: italic;
            color: #888;
        }

        .selectBox {
            display: block;
            width: 90%;
            margin-left: 5%;
            padding: 5px;
            border: 1px solid #ccc;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            border-radius: 3px;
            box-sizing: border-box;
            float: left;
            /* 添加 float 属性 */
        }

    </style>
</head>
<body>

<table id="priceTable">
    <thead>
    <tr>
        <th><input type="checkbox" id="selectAllCheckbox"></th>
        <th>修改类型</th>
        <th>*父项部件编号</th>
        <th>父项部件名称</th>
        <th>*改后子项部件编号</th>
        <th>改后子项部件名称</th>
        <th>规格型号</th>
        <th>*改后数量</th>
        <th>改后工位</th>


        <th>是否客供料</th>
        <th>是否售后物料</th>
        <th>物料行备注</th>
        <th>行号</th>
        <th>跳层</th>

    </tr>
    </thead>
    <tbody id="tableBody">
    <tr>
        <td><input type="checkbox" class="rowCheckbox"></td>
        <td><input name="optionType" type="text" value="添加子项" readonly></td>
        <td><input class="parentPartNumber" name="parentPartNumber" type="text"></td>
        <td><input name="parentPartName" type="text" readonly></td>

        <td><input class="afterChildPartNumber" name="afterChildPartNumber" type="text"></td>
        <td><input name="afterChildPartName" type="text" readonly></td>
        <td><input name="afterPartSpecificationsModel" type="text" value="" readonly></td>

        <td><input class="afterNumber" name="afterNumber" type="text" required></td>
        <td><input name="afterTagNumber" type="text"></td>

        <%-- IBA属性 --%>
        <td>
            <select name="IsByCust" class="selectBox">
                <option value="否">否</option>
                <option value="是">是</option>
            </select>
        </td>

        <td>
            <select name="IsCustomerService" class="selectBox">
                <option value="否">否</option>
                <option value="是">是</option>

            </select>
        </td>

        <td><input name="ItemNote" type="text"></td>

        <td><input name="lineNumber" type="text"></td>
        <td>
            <select name="BOMSkip" class="selectBox">
                <option value="否">否</option>
                <option value="是">是</option>

            </select></td>
        </td>

    </tr>
    </tbody>
</table>
<input type="button" id="addRow" value="复制选中行/新增行">
<input type="button" id="deleteRow" value="删除选中行">
</body>

<script type="text/javascript">

    const oid = "<%=oid%>"
    console.log(oid)

    // 获取具有 name 属性为 'parentPartNumber' 的 input 元素
    const parentPartNumberInput = document.querySelector('input[name="parentPartNumber"]');
    const tableBody = document.getElementById('tableBody')
    const addRowBtn = document.getElementById("addRow")
    //获取删除按钮
    const deleteButton = document.getElementById('deleteRow');


    // 删除选中行按钮点击事件
    deleteButton.addEventListener('click', function () {
        const checkboxes = document.querySelectorAll('.rowCheckbox:checked');
        checkboxes.forEach(checkbox => {
            const row = checkbox.closest('tr'); // 获取即将删除的行
            row.remove(); // 删除行
        });
        // 点击后禁用删除按钮
        deleteButton.disabled = true;
    });

    // 全选复选框事件
    selectAllCheckbox.addEventListener('change', function (e) {
        const checkboxes = document.querySelectorAll('.rowCheckbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = e.target.checked;
        });
        deleteButton.disabled = !e.target.checked; // 如果没有任何复选框被选中，则禁用删除按钮
    });
    // 表体行复选框事件
    tableBody.addEventListener('change', function (e) {
        if (e.target.matches('.rowCheckbox')) {
            const checkedCheckboxes = document.querySelectorAll('.rowCheckbox:checked');
            const allCheckboxes = document.querySelectorAll('.rowCheckbox');
            deleteButton.disabled = checkedCheckboxes.length === 0;
            // 更新全选复选框状态
            selectAllCheckbox.checked = checkedCheckboxes.length === allCheckboxes.length;
        }
    });


    // 监听复制按钮的点击事件 添加选中行或新增行
    addRowBtn.addEventListener('click', function () {
        var tableBody = document.getElementById('tableBody');
        var selectedRows = tableBody.querySelectorAll('.rowCheckbox:checked'); // 检查选择器是否正确

        if (selectedRows.length > 0) {
            console.log("复制选中行"); // 确保这个输出在点击事件中显示

            selectedRows.forEach(function (row) {// row是input
                const td = row.closest('td');//  获取td
                row = td.closest('tr') //  获取行tr --- row

                // 创建新行
                var newRow = document.createElement('tr');

                // 遍历当前行的所有单元格
                var cells = row.querySelectorAll('td');
                cells.forEach(function (cell) {
                    // 创建新单元格
                    var newCell = document.createElement('td');

                    // 检查是否有输入框
                    var input = cell.querySelector('input');
                    if (input) {
                        // 创建新的输入框并设置值
                        var newInput = document.createElement('input');

                        if (input.readOnly || input.disabled) {
                            newInput.readOnly = true
                        }
                        newInput.type = input.type;
                        newInput.value = input.value;
                        newInput.name = input.name;
                        newInput.className = input.className;


                        // 将新输入框添加到新单元格中
                        newCell.appendChild(newInput);
                    } else {
                        // 如果没有输入框，则直接复制原始单元格的内容
                        newCell.innerHTML = cell.innerHTML;
                    }
                    newRow.appendChild(newCell);


                    // var newRow = document.createElement('tr');
                    // newRow.innerHTML = row.innerHTML; // 确保复制行的HTML内容正确设置
                    row.parentNode.insertBefore(newRow, row.nextSibling);
                })
            })
        } else {
            // 如果没有选中行，新增一行空白行
            var newRow = document.createElement('tr');
            newRow.innerHTML =
                '<td><input type="checkbox" class="rowCheckbox"></td>' +
                '<td><input name="optionType" type="text" value="添加子项" readonly></td>' +
                '<td><input class="parentPartNumber" name="parentPartNumber" type="text"></td>' +
                '<td><input name="parentPartName" type="text" readonly></td>' +
                '<td><input class="afterChildPartNumber" name="afterChildPartNumber" type="text"></td>' +
                '<td><input name="afterChildPartName" type="text" readonly></td>' +
                '<td><input name="afterPartSpecificationsModel" type="text" value="" readonly></td>' +
                '<td><input class="afterNumber" name="afterNumber" type="text"></td>' +
                '<td><input name="afterTagNumber" type="text"></td>' +
                '<td><select name="IsByCust" class="selectBox">' +
                '<option value="否">否</option>' +
                '<option value="是">是</option></select></td>' +
                '<td><select name="IsCustomerService" class="selectBox">' +
                '<option value="否">否</option>' +
                '<option value="是">是</option></select></td>' +
                '<td><input name="ItemNote" type="text"></td>' +
                '<td><input name="lineNumber" type="text"></td>' +
                '<td><select name="BOMSkip" class="selectBox">' +
                '<option value="否">否</option>' +
                '<option value="是">是</option></select></td>';

            tableBody.appendChild(newRow); // 将新行添加到表格中
        }
    });

    let focusedElement = null;
    //聚焦对象
    tableBody.addEventListener('focusin', function (event) {
        focusedElement = event.target;
    });

    // 监听表格主体的失焦事件，使用事件委托
    tableBody.addEventListener('blur', function (event) {
        var target = event.relatedTarget || document.activeElement;

        if (target === null || (target !== focusedElement && !focusedElement.contains(target))) {
            // 检查事件目标是否为类名为 parentPartNumber 的输入框
            if (focusedElement && focusedElement.matches('.parentPartNumber')) {
                target = event.target
                var parentPartNumber = event.target.value;
                console.log('父项部件编号失焦，值为:', parentPartNumber);
                // 示例：可以通过 event.target.closest('tr') 获取当前行，然后对其他输入框进行操作
                if (!parentPartNumber) {
                    alert("请输入父部件编号！")
                    return
                }
                Ext.Ajax.request({
                    url: 'servlet/Navigation/changeBOM/EchoDataController?parentPartNumber=' + parentPartNumber + "&changeOR=" + oid,
                    type: 'GET',
                    success: function (response) {
                        var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                        console.log('成功获取数据：', result);

                        // 如果 parentPartName 为空，则弹窗提醒用户

                        if (result.code != 200) {
                            alert(result.msg);
                            return;
                        }
                        var parentPartName = result.data.parentPartName;

                        if (!parentPartName || parentPartName.trim() === '') {
                            alert("父项部件不存在或名称为空");
                            return
                        }
                        // 找到包含target的<td>元素
                        const td = target.closest('td');

                        // 获取td元素的下一个兄弟td元素
                        const nextTd = td.nextElementSibling;
                        // 在下一个td元素内查找<input>元素
                        const nextInput = nextTd.querySelector('input');

                        //将编号得到的值填到name框
                        nextInput.value = parentPartName;
                    },
                    failure: function (response) {
                        console.error('请求失败：', response.statusText);
                    }
                });


            }


            if (focusedElement && focusedElement.matches(".afterChildPartNumber")) {
                target = event.target
                // 找到包含target的<td>元素
                const td = target.closest('td');//  获取td
                const row = td.closest('tr') //  获取行tr --- row

                // 获取行内的所有单元格（td 元素）
                const cells = row.querySelectorAll('td');
                //当前的td下标
                const currentCellIndex = Array.from(cells).indexOf(td);


                // 父部件编号和名称
                var parentPartNumber = cells[currentCellIndex - 2].querySelector('input').value
                var parentPartName = cells[currentCellIndex - 1].querySelector('input').value


                //改后数量
                var afterNumber = cells[currentCellIndex + 3].querySelector('input')
                //改后位号
                var afterTagNumber = cells[currentCellIndex + 4].querySelector('input')
                //行号
                var lineNumber = cells[currentCellIndex + 8].querySelector('input')
                //当前td的input

                var currInput = cells[currentCellIndex].querySelector('input')
                var nextInput = cells[currentCellIndex + 1].querySelector('input')
                //改后规格型号
                var afterPartSpecificationsModel = cells[currentCellIndex + 2].querySelector('input')
                //改后子部件编号
                var afterPartNumber = currInput.value

                if (!afterPartNumber) {
                    alert("请输入改后子部件编号！")
                    currInput.value = ""
                    nextInput.value = ""
                    afterPartSpecificationsModel.value = ""
                    // afterNumber.value = ""
                    // afterTagNumber.value = ""
                    // lineNumber.value = ""
                    return
                }


                if (!parentPartNumber) {
                    alert("请输入父部件编号！")
                    currInput.value = ""
                    nextInput.value = ""
                    afterPartSpecificationsModel.value = ""
                    // afterNumber.value = ""
                    // afterTagNumber.value = ""
                    // lineNumber.value = ""
                    return
                }
                Ext.Ajax.request({
                    url: 'servlet/Navigation/changeBOM/EchoDataInfoController',
                    method: 'POST', // 请求方法设置为 POST
                    jsonData: {
                        changeType: "addSonPart",
                        changeOR: oid,
                        parentPartNumber: parentPartNumber,
                        afterPartNumber: afterPartNumber
                    },
                    success: function (response) {
                        var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                        console.log('成功获取数据：', result);
                        var confirmed =null;
                        if (result.code == 400) {
                            alert(result.msg);
                            currInput.value = ""
                            nextInput.value = ""
                            afterPartSpecificationsModel.value = ""
                            return;
                        }

                        if (result.code == 300) {
                            confirmed = confirm(result.msg);
                        }
                        if(result.code == 200 || confirmed ){
                            nextInput.value = result.data[0].afterPartName;
                            var afterSpecificationsModel = result.data[0].afterSpecificationsModel == null? "":result.data[0].afterSpecificationsModel
                            afterPartSpecificationsModel.value = afterSpecificationsModel
                            changeTitle()
                        }else{
                            currInput.value = ""
                            nextInput.value = ""
                            afterPartSpecificationsModel.value = ""
                            return;
                        }

                        // // 构建新行的 HTML 字符串
                        // result.data.forEach(function (item) {
                        //     var newRow = document.createElement('tr')
                        //     newRow.innerHTML =
                        //         ' <tr>' +
                        //         '<td><input type="checkbox" class="rowCheckbox"></td>' +
                        //         '<td><input name="optionType" type="text" value="添加子项" readonly></td>' +
                        //         '<td><input class="parentPartNumber" name="parentPartNumber" value="'+parentPartNumber+'" type="text"></td>' +
                        //         '<td><input name="parentPartName" type="text" value="'+parentPartName+'" readonly></td>' +
                        //         '<td><input class="afterChildPartNumber" name="afterChildPartNumber" value="'+afterPartNumber+'" type="text"></td>' +
                        //         '<td><input name="afterChildPartName" type="text" value="'+item.afterChildPartName+'" readonly></td>' +
                        //         '<td><input class="afterNumber" name="afterNumber" value="'+item.afterNumber+'" type="text"></td>' +
                        //         '<td><input name="afterTagNumber" value="'+item.afterTagNumber+'" type="text"></td>' +
                        //         '<td><select name="IsByCust" class="selectBox">' +
                        //         '<option value="否">否</option>' +
                        //         '<option value="是">是</option></select></td>' +
                        //         '<td><select name="IsCustomerService" class="selectBox">' +
                        //         '<option value="否">否</option>' +
                        //         '<option value="是">是</option></select></td>' +
                        //         '<td><input name="ItemNote" type="text"></td>' +
                        //         '<td><input name="lineNumber" value="'+item.lineNumber+'" type="text"></td>' +
                        //         '<td><select name="BOMSkip" class="selectBox">' +
                        //         '<option value="否">否</option>' +
                        //         '<option value="是">是</option></select></td>';
                        //         '</tr>'
                        //     // 插入到目标行的后面
                        //     row.parentNode.insertBefore(newRow, row.nextSibling);
                        // });
                        // row.remove()
                    },
                    failure: function (response) {
                        console.error('请求失败：', response.statusText);
                    }
                });

            }


            if (focusedElement && focusedElement.matches(".afterNumber")) {
                target = event.target
                validateNumber(target); // 调用验证有效期类型的函数
            }
        }
    }, true); // 使用捕获阶段，以确保事件委托的正确性

    // 确保改前数量是int类型且大于等于0的函数
    function validateNumber(input) {

        var days = parseInt(input.value, 10); // 尝试将输入转换为整数
        if (isNaN(days) || !Number.isInteger(days) || days < 0) { // 检查是否为数字且为整数且大于等于0
            alert("改后数量必填且为大于等于0的整数"); // 提示消息
            input.value = ""; // 清空输入框
        }

    }

    // 添加粘贴事件监听器到整个文档
    document.addEventListener('paste', function (event) {
        // 阻止默认粘贴行为，因为我们需要自定义处理
        event.preventDefault();

        // 获取粘贴板内容
        let pastedText = '';
        if (event.clipboardData && event.clipboardData.getData) {
            pastedText = event.clipboardData.getData('text/plain');
        } else if (window.clipboardData && window.clipboardData.getData) {
            pastedText = window.clipboardData.getData('Text');
        }
        console.log("清楚空格前", pastedText)

        pastedText = pastedText.trim()

        console.log("清楚空格后", pastedText)


        // 将处理后的文本插入到输入框中
        document.execCommand('insertText', false, pastedText);
    });

    function changeTitle() {
        // 获取所有的输入框
        const inputs = document.querySelectorAll('input');

        // 遍历每个输入框
        inputs.forEach(input => {
            // 添加输入事件监听器，当用户输入内容时更新title属性
            var inputValue = input.value == null ? "" : input.value

            input.setAttribute('title', inputValue);
        });
    }
</script>
</html>
