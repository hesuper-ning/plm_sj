<%@page language="java" session="true" pageEncoding="UTF-8"%>
<%@ taglib prefix="jca" uri="http://www.ptc.com/windchill/taglib/components" %>
<%@ include file="/netmarkets/jsp/components/beginWizard.jspf"%>
<%@ include file="/netmarkets/jsp/components/includeWizBean.jspf"%> 


<%-- <jca:wizard title="删除子件"  formProcessorController="ext.kingdeeERP.changeBOM.controller.ChangeItemController"> --%>
<jca:wizard title="删除子件">
	<jca:wizardStep action="delete" type="changeNotBom" />
</jca:wizard>
<%@ include file="/netmarkets/jsp/util/end.jspf"%>

