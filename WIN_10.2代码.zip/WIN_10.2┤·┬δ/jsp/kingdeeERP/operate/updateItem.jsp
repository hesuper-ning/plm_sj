<%@page import="ext.kingdeeERP.changeBOM.WTPartUsageLinkChangeItem"%>

<%@page import="wt.part.WTPart"%>
<%@page import="wt.part.WTPartMaster"%>

<%@page import="ext.kingdeeERP.changeBOM.util.PersistenceUtil"%>
<%@page import="ext.kingdeeERP.changeBOM.ChangeTypeEnum"%>

<%@page import="wt.session.SessionHelper"%>
<%@page import="java.util.ResourceBundle"%>
<%@page import="java.lang.reflect.Method"%>
<%@page import="org.apache.commons.lang.StringUtils"%>
<%@page import="com.ptc.netmarkets.util.beans.NmContextBean"%>
<%@page import="com.ptc.netmarkets.util.beans.NmCommandBean"%>
<%@page import="java.util.ArrayList"%>
<%@page import="com.ptc.netmarkets.model.NmOid"%>
<%@page language="java" session="true" pageEncoding="UTF-8"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/picker" prefix="p"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca"%>
<%@page import="wt.util.WTProperties"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc"%>
<jca:tabToHighlight actionName="propertyPanel" objectType="object" />	
<%@ include file="/netmarkets/jsp/util/begin.jspf"%>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w"%>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb"%>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags"%>
<%
	String contextPath=request.getContextPath(); 
	ResourceBundle resource = ResourceBundle.getBundle("ext.kingdeeERP.changeBOM.CustomRB", SessionHelper.getLocale());
	NmCommandBean cb1 = new NmCommandBean();
	cb1.setInBeginJsp        (true);
	cb1.setOpenerCompContext (request.getParameter("compContext"));
	cb1.setOpenerElemAddress (NmCommandBean.convert(request.getParameter("openerElemAddress")));
	cb1.setCompContext       (NmCommandBean.convert(request.getParameter("compContext")));
	cb1.setElemAddress       (NmCommandBean.convert(request.getParameter("elemAddress")));
	cb1.setRequest           (request);
	cb1.setResponse          (response);
	cb1.setOut               (out);
	cb1.setContextBean       (new NmContextBean());
	ArrayList<NmOid> selected = cb1.getSelectedOidForPopup();
	WTPartUsageLinkChangeItem item = null;
	if(selected != null && selected.size()==1){
		NmOid primaryOid = selected.get(0);
		Object ref =  primaryOid.getRef();
	    if(ref instanceof WTPartUsageLinkChangeItem){
	    	item = (WTPartUsageLinkChangeItem) ref;
	    }
	}
   
    if(item != null){

            String parentOID = item.getParentOID();
            String changeType = item.getChangeType();
            String type = ChangeTypeEnum.getValueByKey(changeType);
            WTPart parentPart = (WTPart) PersistenceUtil.oid2Object(parentOID);
            String parentPartNum=parentPart.getNumber();
            String parentPartName=parentPart.getName();
            String mount = "";
            String tarNumber=""; 
            String itemNote=""; 

            if(item.getNewAMountA7()!=null){
                mount=item.getNewAMountA7();
            }
            if(item.getNewAMountA7TagNumber()!=null){
                tarNumber=item.getNewAMountA7TagNumber();
            }

            if(item.getItemNote()!=null){
                itemNote=item.getItemNote();
            }
            


            String beforeChildMasterNumber ="";
            String beforeChildMasterName ="";
            if(item.getBeforeChildMasterOR() != null){
                WTPartMaster beforePart = (WTPartMaster) PersistenceUtil.oid2Object(item.getBeforeChildMasterOR());
                beforeChildMasterNumber = beforePart.getNumber();
                beforeChildMasterName = beforePart.getName();
            }

            String afterChildMasterNumber ="";
            String afterChildMasterName ="";
            if(item.getAfterChildMasterOR() != null){
                WTPartMaster afterPart = (WTPartMaster) PersistenceUtil.oid2Object(item.getAfterChildMasterOR());
                afterChildMasterNumber = afterPart.getNumber();
                afterChildMasterName = afterPart.getName();
            }



            String replaceMasterNumber ="";
            String replaceChildMasterName ="";
            if(item.getReplaceChildMasterOR() != null){
                WTPartMaster replacePart = (WTPartMaster) PersistenceUtil.oid2Object(item.getReplaceChildMasterOR());
                replaceMasterNumber = replacePart.getNumber();
                replaceChildMasterName = replacePart.getName();
            }
		%>
        <%-- 修改类型table开的 --%>
        <%if("UPDATE".equals(changeType)) {%>
            <table id="priceTable">
            <tr>
                <th>修改类型</th>
                <th>父项部件编号</th>
                <th>父项部件名称</th>
                <th>改前子项部件编号</th>
                <th>改前子项部件名称</th>
                <th>改后子项部件编号</th>
                <th>改后子项部件名称</th>
                <th>改后用量</th>
                <th>改后工位</th>
                <th>是否客供料</th>
                <th>是否售后物料</th>
                <th>物料行备注</th>
                <th>行号</th>
                <th>跳层</th>
            </tr>

        <tr>
        <input type="hidden" name="OR" value="<%= item.getWTChangeORDER2OR() %>">
        <input type="hidden" name="typeKey" value="<%=changeType %>">
        <td><input name="type" type="text" value="<%= type %>" readonly></td>
        <td><input name="parentPartNum" type="text" value="<%= parentPartNum %>" ></td>
        <td><input name="parentPartName" type="text" value="<%= parentPartName %>"></td>
        <td><input type="text" name="beforeChildMasterNumber" value="<%= beforeChildMasterNumber %>"></td>
        <td><input type="text" name="beforeChildMasterName" value="<%= beforeChildMasterName %>"></td>
    
        <td><input type="text" name="afterChildMasterNumber" value="<%= afterChildMasterNumber %>"></td>
        <td><input type="text" name="afterChildMasterName" value="<%= afterChildMasterName %>"></td>
        <td><input name="afterNumber" type="text" value="<%= mount %>"></td>
        <td><input name="afterTagNumber" type="text" value="<%= tarNumber %>"></td>

        <td>          
        <select name="IsByCust" class="selectBox">
            <option value="<%= item.getIsByCust() %>"><%= item.getIsByCust() %></option>
            <option value="否">否</option>
            <option value="是">是</option>
            
            </select>
        </td>

        <td><select name="IsCustomerService" class="selectBox">
        <option value="<%= item.getIsCustomerService() %>"><%= item.getIsCustomerService() %></option>
            <option value="否">否</option>
            <option value="是">是</option>
            
            </select></td>
        <td><input name="ItemNote" type="text" value="<%= itemNote %>" ></td>

        <td><input name="lineNumber" type="text"  value="<%= item.getLineNumber() %>"></td>
        <td>
        <select name="BOMSkip" class="selectBox">
            <option value="<%= item.getBOMSkip() %>"><%= item.getBOMSkip() %></option>
            <option value="否">否</option>
            <option value="是">是</option>
        
            </select>
            </td>



        </tr>
    </table>

        <%-- 修改类型的结束 --%>
        <%}%>





        <%-- 添加类型的开始 --%>
        <%if("addSonPart".equals(changeType)) {%>
        <table id="priceTable">
            <tr>
                <th>修改类型</th>
                <th>父项部件编号</th>
                <th>父项部件名称</th>
                <th>改后子项部件编号</th>
                <th>改后子项部件名称</th>
                <th>改后用量</th>
                <th>改后工位</th>
                <th>是否客供料</th>
                <th>是否售后物料</th>
                <th>物料行备注</th>
                <th>行号</th>
                <th>跳层</th>
            </tr>
        <tr>
        <input type="hidden" name="OR" value="<%= item.getWTChangeORDER2OR() %>">
        <input type="hidden" name="typeKey" value="<%=changeType %>">
        <td><input name="type" type="text" value="<%= type %>" readonly></td>
        <td><input name="parentPartNum" type="text" value="<%= parentPartNum %>" ></td>
        <td><input name="parentPartName" type="text" value="<%= parentPartName %>"></td>
    
        <td><input type="text" name="afterChildMasterNumber" value="<%= afterChildMasterNumber %>"></td>
        <td><input type="text" name="afterChildMasterName" value="<%= afterChildMasterName %>"></td>
        <td><input name="afterNumber" type="text" value="<%= mount %>"></td>
        <td><input name="afterTagNumber" type="text" value="<%= tarNumber %>"></td>

        <td>          
        <select name="IsByCust" class="selectBox">
            <option value="<%= item.getIsByCust() %>"><%= item.getIsByCust() %></option>
            <option value="否">否</option>
            <option value="是">是</option>
            
            </select>
        </td>

        <td><select name="IsCustomerService" class="selectBox">
        <option value="<%= item.getIsCustomerService() %>"><%= item.getIsCustomerService() %></option>
            <option value="否">否</option>
            <option value="是">是</option>
            
            </select></td>
        <td><input name="ItemNote" type="text" value="<%= itemNote %>" ></td>

        <td><input name="lineNumber" type="text"  value="<%= item.getLineNumber() %>"></td>
        <td>
        <select name="BOMSkip" class="selectBox">
            <option value="<%= item.getBOMSkip() %>"><%= item.getBOMSkip() %></option>
            <option value="否">否</option>
            <option value="是">是</option>
        
            </select>
            </td>



        </tr>
    </table>

        <%-- 添加类型的结束 --%>
        <%}%>





<%-- 删除类型的开始 --%>
<%if("deleteSonPart".equals(changeType)) {%>
 <table id="priceTable">
            <tr>
                <th>修改类型</th>
                <th>父项部件编号</th>
                <th>父项部件名称</th>
                <th>改前子项部件编号</th>
                <th>改前子项部件名称</th>
            </tr>

        <tr>
        <input type="hidden" name="OR" value="<%= item.getWTChangeORDER2OR() %>">
        <input type="hidden" name="typeKey" value="<%=changeType %>">
        <td><input name="type" type="text" value="<%= type %>" readonly></td>
        <td><input name="parentPartNum" type="text" value="<%= parentPartNum %>" ></td>
        <td><input name="parentPartName" type="text" value="<%= parentPartName %>"></td>
        <td><input type="text" name="beforeChildMasterNumber" value="<%= beforeChildMasterNumber %>"></td>
        <td><input type="text" name="beforeChildMasterName" value="<%= beforeChildMasterName %>"></td>
        </tr>
    </table>
<%-- 删除类型的结束 --%>
<%}%>






<%-- 替换类型的开始 --%>
<%if("REPLACE".equals(changeType)) {%>



<table id="priceTable">
            <tr>
                <th>修改类型</th>
                <th>父项部件编号</th>
                <th>父项部件名称</th>
                <th>改前子项部件编号</th>
                <th>改前子项部件名称</th>
                <th>改后子项部件编号</th>
                <th>改后子项部件名称</th>
            </tr>

        <tr>
        <input type="hidden" name="OR" value="<%= item.getWTChangeORDER2OR() %>">
        <input type="hidden" name="typeKey" value="<%=changeType %>">
        <td><input name="type" type="text" value="<%= type %>" readonly></td>
        <td><input name="parentPartNum" type="text" value="<%= parentPartNum %>" ></td>
        <td><input name="parentPartName" type="text" value="<%= parentPartName %>"></td>
        <td><input type="text" name="beforeChildMasterNumber" value="<%= beforeChildMasterNumber %>"></td>
        <td><input type="text" name="beforeChildMasterName" value="<%= beforeChildMasterName %>"></td>
    
        <td><input type="text" name="afterChildMasterNumber" value="<%= afterChildMasterNumber %>"></td>
        <td><input type="text" name="afterChildMasterName" value="<%= afterChildMasterName %>"></td>
        </tr>
    </table>



<%-- 替换类型的结束 --%>
<%}%>


<%-- 替代料类型的开始 --%>
<%if("addReplacePart".equals(changeType) || "deleteReplacePart".equals(changeType)) {%>



<table id="priceTable">
            <tr>
                <th>修改类型</th>
                <th>父项部件编号</th>
                <th>父项部件名称</th>
                <th>改前子项部件编号</th>
                <th>改前子项部件名称</th>
                <th>替代料部件编号</th>
                <th>替代料部件名称</th>
            </tr>

        <tr>
        <input type="hidden" name="OR" value="<%= item.getWTChangeORDER2OR() %>">
        <input type="hidden" name="typeKey" value="<%=changeType %>">
        <td><input name="type" type="text" value="<%= type %>" readonly></td>
        <td><input name="parentPartNum" type="text" value="<%= parentPartNum %>" ></td>
        <td><input name="parentPartName" type="text" value="<%= parentPartName %>"></td>
        <td><input type="text" name="beforeChildMasterNumber" value="<%= beforeChildMasterNumber %>"></td>
        <td><input type="text" name="beforeChildMasterName" value="<%= beforeChildMasterName %>"></td>
        <td><input type="text" name="replaceMasterNumber" value="<%= replaceMasterNumber %>"></td>
        <td><input type="text" name="replaceChildMasterName" value="<%= replaceChildMasterName %>"></td>
        </tr>
    </table>

<%-- 替代料类型的结束 --%>
<%}%>





		
		<%} else {
		%>
<div style="clear: both;">请选择一条记录</div>
<%} %>







<style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        #priceTable {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        #priceTable th,
        #priceTable td {
            position: relative;
            width: 170px;
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            overflow: hidden;
        }

        #priceTable th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #333;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            position: relative;
            /* 相对定位 */
        }

        #priceTable td input[type="text"] {
            display: block;
            width: 90%;
            margin-left: 5%;
            padding: 5px;
            border: 1px solid #ccc;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            border-radius: 3px;
            box-sizing: border-box;
            float: left;
            /* 添加 float 属性 */
        }

        #priceTable tr td input[type="text"]:read-only {
            background-color: #eee;
        }

        #priceTable td input[type="text"]:focus {
            outline: none;
            border-color: #66afe9;
            box-shadow: 0 0 5px #66afe9;
        }

        #priceTable tr td input[type="text"]+span {
            position: absolute;
            /* 绝对定位 */
            top: 14px;
            right: 11%;
        }

        p {
            margin-top: 20px;
            font-style: italic;
            color: #888;
        }

        .selectBox{
            display: block;
            width: 90%;
            margin-left: 5%;
            padding: 5px;
            border: 1px solid #ccc;
            text-align: center;
            /* 居中对齐 th 中的文本 */
            border-radius: 3px;
            box-sizing: border-box;
            float: left;
            /* 添加 float 属性 */
        }

    </style>

    <script>
      // 添加粘贴事件监听器到整个文档
    document.addEventListener('paste', function (event) {
        // 阻止默认粘贴行为，因为我们需要自定义处理
        event.preventDefault();

        // 获取粘贴板内容
        let pastedText = '';
        if (event.clipboardData && event.clipboardData.getData) {
            pastedText = event.clipboardData.getData('text/plain');
        } else if (window.clipboardData && window.clipboardData.getData) {
            pastedText = window.clipboardData.getData('Text');
        }

        pastedText = pastedText.trim()

        // 将处理后的文本插入到输入框中
        document.execCommand('insertText', false, pastedText);
    });
    </script>
<%@ include file="/netmarkets/jsp/util/end.jspf"%>