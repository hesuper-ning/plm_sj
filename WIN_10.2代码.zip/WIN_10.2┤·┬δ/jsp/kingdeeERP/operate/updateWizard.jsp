<%@page language="java" session="true" pageEncoding="UTF-8"%>
<%@ taglib prefix="jca" uri="http://www.ptc.com/windchill/taglib/components" %>
<%@ include file="/netmarkets/jsp/components/beginWizard.jspf"%>
<%@ include file="/netmarkets/jsp/components/includeWizBean.jspf"%> 
<jca:wizard title="修改子件">
	<jca:wizardStep action="update" type="changeNotBom" />
</jca:wizard>
<%@ include file="/netmarkets/jsp/util/end.jspf"%>