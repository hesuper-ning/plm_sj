<%@ page errorPage="../../util/error.jsp"
%><%@ page import="com.ptc.netmarkets.util.beans.NmCommandBean"
%><%@ page import="com.ptc.netmarkets.model.NmOid"
%><%@ page import="com.ptc.netmarkets.model.NmObjectHelper"
%><%@ page import="com.ptc.netmarkets.model.NmObjectCommands"
%><%@ page import="wt.httpgw.EncodingConverter"
%><%@ page import="java.util.ResourceBundle"
%><%@ page import="java.util.Locale"
%><%@ page import="wt.util.WTMessage"
%><%@ include file="../../util/beginPopup.jspf"

%><%@ page import="com.ptc.core.components.beans.ObjectBean" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.List" %>
<%@ page import="ext.alphai.epm.updateEPM.processor.exportEPMProcessor" %>


<%
    List<ObjectBean> paramList = new ArrayList<ObjectBean>();
    NmCommandBean cb = new NmCommandBean();
    cb.setCompContext(nmcontext.getContext().toString());
    cb.setUrlFactoryBean(urlFactoryBean);
    cb.setSessionBean(sessionBean);
    cb.setRequest(request);
    cb.setResponse(response);

    cb.setOut(out);

    exportEPMProcessor exportEPMProcessor = new exportEPMProcessor();
    exportEPMProcessor.doOperation(cb, paramList);
%>



<%@ include file="../../util/endPopup.jspf"%>