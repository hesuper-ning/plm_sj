<%@ page language="java" import="java.util.*" pageEncoding="utf-8"%>

<%@page import="wt.doc.WTDocument"%>
<%@page import="wt.epm.EPMDocument"%>
<%@ include file="../../util/beginPopup.jspf"%>
<%@ include file="../../util/endPopup.jspf"%>
<%@page import="com.ptc.netmarkets.model.NmOid"%>
<%@page import="java.util.ArrayList"%>
<%@page import="com.ptc.netmarkets.util.beans.NmContextBean"%>
<%@page import="com.ptc.netmarkets.util.beans.NmCommandBean"%>
<%@ page import="ext.alphai.epm.updateEPM.utils.EPMUtils" %>
<%@ page import="static ext.alphai.epm.updateEPM.utils.PersistenceUtil.isCheckOut" %>
<%@ page import="wt.util.WTException" %>

<%
    NmCommandBean cb = new NmCommandBean();
    cb.setCompContext(nmcontext.getContext().toString());
    cb.setUrlFactoryBean(urlFactoryBean);
    cb.setSessionBean(sessionBean);
    cb.setRequest(request);
    cb.setResponse(response);
    cb.setOut(out);
    NmOid primaryOid2 = cb.getPrimaryOid();
    Object content = primaryOid2.getRef();

    String number=null;
    if (content instanceof EPMDocument){
        EPMDocument epm = (EPMDocument)content;
         number = epm.getNumber();

    }

    System.out.println(number);
    //获取操作的


    String upload = "/Windchill/ptc1/alphai/excelUpdateEPM/servlet/epm/ExcelUpdateEPMController?number="+number;
    String oid = request.getParameter("oid");
    String path = request.getContextPath();
    String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + path + "/";
    System.out.println(basePath);

%>

<script language="Javascript">


    //清确定按钮
    apply = document.getElementById("PJL_popup_apply");
    ok = document.getElementById("PJL_popup_ok");
    cancel = document.getElementById("PJL_popup_cancel");
    ok.style.display = "none"
    apply.style.display = "none"
    cancel.style.display = "none"



</script>


<title>上传excel修改EPM属性</title>
<div>
    <br>


    <form name="form1" id="form1" action="<%=upload%>" enctype="multipart/form-data" method="post">
        <table cellpadding="0" style="border-collapse: collapse; border: 0px solid #003399;">
            <tr>
                <td style="cursor: pointer;">&nbsp;&nbsp;请选择修改EPM的模板文件:<br>
                    &nbsp;&nbsp;<input type="file" size="60" id="documentFile" name="documentFile"
                                       style="color: Blue; background-color: White; border-width: 1px; border-style: Solid; font-family: 宋体; font-size: 10pt; height: 22px; width: 385px;">
                     <input type="hidden" name="number" value="<%=number %>">
                    &nbsp;<input type="submit" value="上传excel" onclick="return validateFile();"/>
                </td>
            </tr>

        </table>
    </form>
</div>

<div><font color="red" size="2">
</font>
</div>

<style type="text/css">

</style>

