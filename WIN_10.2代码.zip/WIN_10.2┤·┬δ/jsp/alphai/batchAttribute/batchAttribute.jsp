<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca" %>
<%@page import="wt.util.WTProperties" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc" %>
<jca:tabToHighlight actionName="propertyPanel" objectType="object"/>
<%@ include file="/netmarkets/jsp/util/begin.jspf" %>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb" %>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags" %>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Table</title>
<%--    <link rel="stylesheet" href="/Windchill/netmarkets/jsp/alphai/batchAttribute/css/batchAttributeCSS.css">--%>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }


        .dynamicTable {
            width: 100%;
            border-collapse: collapse;
        }

        .dynamicTable ,
        .dynamicTable th,
        .dynamicTable  td {
            border: 1px solid #ddd;
        }

        .dynamicTable  th,
        .dynamicTable  td {
            width: 30%;
            padding: 10px;
            text-align: left;
        }

        .dynamicTable  th {
            background-color: #f4f4f4;
        }

        .dynamicTable select,
        .dynamicTable input[type="text"] {
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 8px;
            font-size: 14px;
            width: 100%;
            box-sizing: border-box;
        }

        .dynamicTable  select:focus,
        .dynamicTable input[type="text"]:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(38, 143, 255, 0.5);
        }

        .dynamicTable  option {
            padding: 8px;
        }


        .search-container {
            margin-bottom: 20px;
            display: flex;
            width: 400px;
            align-items: center;
        }

        <%-- .search-container input[type="text"] {
            flex: 1;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px 0 0 4px;
        } --%>

        .search-container input[type="button"] {
           <%--  padding: 8px 15px;
            font-size: 16px;
            background-color: #4CAF50;
            color: white;
            border: 1px solid #4CAF50;
            border-radius: 0 4px 4px 0;
            cursor: pointer; --%>
            margin-left: 5px;
        }


        .button-top {
            margin-top: 10px;
        }

      <%--   .button-top input[type="button"] {
            padding: 8px 15px;
            font-size: 16px;
            cursor: pointer;
        }

        .optionButton {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            margin-right: 10px;
        } --%>

        .optionButton {
            float: right;
            padding: 0px 15px;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .overlay-content {
            background: white;
            padding: 20px;
            border-radius: 5px;
            width: 50%;
            height: 70%;
            position: relative;
            overflow: auto;
        }

        .close-button {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            font-size: 20px;
            color: #333;
        }
          .unique-search-container {
            position: relative;
            width: 300px;
        }

        #unique-search-input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        .unique-results-popup {
            position: absolute;
            width: 93%;
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ccc;
            background-color: #fff;
            z-index: 1000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .unique-results-popup div {
            padding: 8px;
            border-bottom: 1px solid #ccc;
            cursor: pointer;
        }

        .unique-results-popup div:hover {
            background-color: #f0f0f0;
        }

        .hidden {
          
    </style>
</head>

<body>

    <input type="button"  value="新增物料属性变更" id="openButton">
    <!-- table -->

    <jsp:include page="${mvc:getComponentURL('ext.alphai.partAttributeChange.builder.UpdateAttributeTable')}" flush="false"/>


    <!--遮盖 -->
    <div id="overlay" class="overlay">
        <div class="overlay-content">
            <span id="closeButton" class="close-button">&times;</span>
            <div class="search-container">
                *部件编号：<input id="searchInput" type="text" placeholder="输入部件编号搜索... " title="输入部件编号搜索部件属性">
                <input type="button" value="搜索" onclick="searchData()"> 
            </div>
            <table id="dynamicTable" class="dynamicTable">
                <thead>
                    <tr>
                        <th>属性名</th>
                        <th>修改前</th>
                        <th>修改后</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <div class="button-top">
                <input type="button"  value="确认" id="createButton" class="optionButton">
            </div>
        </div>
    </div>



    <div id="overlay2" class="overlay">
        <div class="overlay-content">
            <span id="closeButton2" class="close-button">&times;</span>
            <br>
            <table id="dynamicTable2" class="dynamicTable">
                <thead>
                <tr>
                    <th>属性名</th>
                    <th>修改前</th>
                    <th>修改后</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>

        </div>
    </div>



    <div id="overlay3" class="overlay">
        <div class="overlay-content">
            <span id="closeButton3" class="close-button">&times;</span>

            <br>
            <table id="dynamicTable3" class="dynamicTable">
                <thead>
                <tr>
                    <th>属性名</th>
                    <th>修改前</th>
                    <th>修改后</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <div class="button-top">
                <input type="button"  value="确认" id="updateButton" class="optionButton">
            </div>
        </div>
    </div>

    <%@ include file="/netmarkets/jsp/util/end.jspf" %>


</body>

<script type="text/javascript">

    var oid = "<%=request.getParameter("oid")%>"

    //供应商=“零散供应商”或“零散供应商-美金”时，供应商全名不能为空
    
    const Suppliers = "Suppliers";//定义供应商内部值
    const SupplierFullName = "SupplierFullName";//定义供应商全名内部值


 



    //点击搜索
    var data;
    function searchData() {
        var tableBody = document.querySelector('.dynamicTable tbody');
        tableBody.innerHTML = ""
        
        var searchValue =  document.getElementById("searchInput").value.trim()
        if (!searchValue){
            alert("请输入搜索的部件编号！")
            return;
        }
         Ext.Ajax.request({
             url: '/Windchill/ptc1/ClsAConstraint/cls?number='+searchValue+"&oid="+oid,
            method: 'GET', // 请求方法设置为 POST
            success: function (response) {
                var result = JSON.parse(response.responseText) // 将响应数据解析为对象
                 console.log(JSON.stringify(result))
                if(result.code != 200){
                    alert(result.msg);
                     location.reload();
                    return
                }
               
                 data = result;
                 populateTable(result);
             },
             failure: function (response) {
                 console.error('请求失败：', response.statusText);
             }
         });
    
    }

    document.getElementById('createButton').addEventListener('click', function () {
            if (data === null || data === undefined) {
                alert("请查询部件属性！")
                return;
            }
            var flag= true;  //默认允许发
            const rows = document.querySelectorAll('#dynamicTable tbody tr');
            let result = {};
            result["oid"] = oid
            // data["oid"] = oid
            result["number"] = data["number"] 
            result["classify"] = data["classify"] 
            result["partTypeInternalName"] = data["partTypeInternalName"] 
            result["displayAttribute"] = data["displayAttribute"] //显示的数据
            result["KeyAttributeRules"] = data["KeyAttributeRules"] //包含内部值 中文
            result["requiredAttribute"] = data["requiredAttribute"] //必填属性
            <%-- result["oldDisplayAttribute"] = data["KeyAttributeRules"] // 保存旧数据 --%>

            var updateAttributeRules={};
            rows.forEach(row => {
                const thirdColumn = row.querySelector('td:nth-child(3)');
                if (thirdColumn) {
                    const input = thirdColumn.querySelector('input');
                    const select = thirdColumn.querySelector('select');


                    
                    if (input) {
                        value = input.value.trim()
                        name = input.name
                         //跳过没有name的输入框
                        if (name!=='') {updateAttributeRules[name] = value;}
                        
                    } else if (select) {
                        value = select.value.trim()
                        name = select.name
                         //跳过没有name的下拉框
                        if (name!=='') {updateAttributeRules[name] = value;}
                        
                    }


                    ///校验供应商值  是否为数据库中的   不是就填空
                    if(checkSupply(input) ){
                        input.value=""
                        updateAttributeRules["Suppliers"] = "";
                    }
                    //必填校验
                     if (checkRequire(result,input,select)) {
                        flag = false
                        return
                    }
                }
            });
            result["updateAttribute"] = updateAttributeRules //新数据数据
            <%-- const mergedResult = Object.assign({}, data, { updateAttribute: updateAttributeRules }); --%>

            var sendJson = JSON.stringify(result)




            console.log(sendJson);
            if (flag) {
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/Change/createAttribute',
                    method: 'POST', // 请求方法设置为 POST
                    jsonData: sendJson,
                    success: function (response) {
                        var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                        //发送json成功，成功刷新页面
                        if(result.code!=200){
                            alert(result.msg);
                            return;
                        }
                        location.reload();
                    },
                    failure: function (response) {
                        console.error('请求失败：', response.statusText);
                    }
                });
            }
            


        });



    //打开遮盖  详细
    function showDetail(itemOR,number) {
        document.getElementById('overlay2').style.display = 'flex';
        Ext.Ajax.request({
            url: '/Windchill/ptc1/Change/updateDetail?itemOR='+itemOR+"&oid="+oid+"&option=show",
            method: 'GET', // 请求方法设置为 POST
            success: function (response) {
                var result = JSON.parse(response.responseText) // 将响应数据解析为对象
                
                if (result.code != 200) {
                    alert(result.msg)
                    location.reload();
                    return;
                }

                result = JSON.parse(result.data) 
                //获取枚举和合法值列表
                Ext.Ajax.request({
                url: '/Windchill/ptc1/ClsAConstraint/getEnumAndCls?number='+number,
                method: 'GET', // 请求方法设置为 POST
                success: function (response) {
                    console.log("枚举和合法值",response.responseText)
                    var enumAndLegal = JSON.parse(response.responseText) // 将响应数据解析为对象

                    result["Legal_Values"] = enumAndLegal["Legal_Values"]
                    result["Enum_Values"] = enumAndLegal["Enum_Values"]

                    console.log(result)
                    populateTableShowDetail(result,"show");
                    
                },
                failure: function (response) {
                    console.error('请求失败：', response.statusText);
                }
            });

              
            },
            failure: function (response) {
                console.error('请求失败：', response.statusText);
            }
        });

    }

    //修改
    var updateData;
    var updateItemOR;
    function updateAttribute(itemOR,number){
        document.getElementById('overlay3').style.display = 'flex';
        updateItemOR = itemOR;
        Ext.Ajax.request({
            url: '/Windchill/ptc1/Change/updateDetail?itemOR='+itemOR+"&oid="+oid+"&option=update",
            method: 'GET', // 请求方法设置为 POST
            success: function (response) {
                var result = JSON.parse(response.responseText) // 将响应数据解析为对象
                console.log(response.responseText)

                if (result.code != 200) {
                    alert(result.msg)
                    location.reload();
                    return;
                }

                result = JSON.parse(result.data) 
               

                 //获取枚举和合法值列表
                Ext.Ajax.request({
                url: '/Windchill/ptc1/ClsAConstraint/getEnumAndCls?number='+number,
                method: 'GET', // 请求方法设置为 POST
                    success: function (response) {
                        console.log("枚举和合法值",response.responseText)
                        var enumAndLegal = JSON.parse(response.responseText) // 将响应数据解析为对象

                        result["Legal_Values"] = enumAndLegal["Legal_Values"]
                        result["Enum_Values"] = enumAndLegal["Enum_Values"]


                         updateData = result;
                         populateTableShowDetail(result,"update");
                        
                    },
                    failure: function (response) {
                        console.error('请求失败：', response.statusText);
                    }
                });

               
            },
            failure: function (response) {
                console.error('请求失败：', response.statusText);
            }
        });    
    }
     //确定新建修改传递json
        document.getElementById('updateButton').addEventListener('click', function () {
            if (updateData === null || updateData === undefined) {
                alert("请查询部件属性！")
                return;
            }
            var flag= true;  //默认允许发
            const rows = document.querySelectorAll('#dynamicTable3 tbody tr');
            let result = {};
            result["oid"] = oid
            result["itemOR"] = updateItemOR
            // data["oid"] = oid
            result["number"] = updateData["number"] 
            result["classify"] = updateData["classify"] 
            result["partTypeInternalName"] = updateData["partTypeInternalName"]
            result["displayAttribute"] = updateData["updateAttribute"] //将之前的值填入显示
            result["KeyAttributeRules"] = updateData["KeyAttributeRules"] //旧数据
            result["requiredAttribute"] = updateData["requiredAttribute"] //必填属性
            var updateAttributeRules={};
            rows.forEach(row => {
                const thirdColumn = row.querySelector('td:nth-child(3)');
                if (thirdColumn) {
                    const input = thirdColumn.querySelector('input');
                    const select = thirdColumn.querySelector('select');
                 
                    if (input) {
                        value = input.value.trim()
                        name = input.name
                        //跳过没有name的输入框
                        if (name!=='') {
                            updateAttributeRules[name] = value;
                        }
                        
                    } else if (select) {
                        value = select.value.trim()
                        name = select.name
                        //跳过没有name的下拉框
                        if (name!=='') {updateAttributeRules[name] = value;}
                        
                    }
                    ///校验供应商值  是否为数据库中的   不是就填空
                    if(checkSupply(input)){
                        input.value=""
                        updateAttributeRules["Suppliers"] = "";
                    }
                    //判断是否必填
                    if (checkRequire(result,input,select)) {
                        //是  不发送json
                        flag = false
                        return
                    }
                }
            });
            result["updateAttribute"] = updateAttributeRules //新数据数据
            <%-- const mergedResult = Object.assign({}, updateData, { updateAttribute: updateAttributeRules }); --%>

            var sendJson = JSON.stringify(result)

            console.log("修改发送",sendJson)


            if (flag) {
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/Change/updateAttribute',
                    method: 'POST', // 请求方法设置为 POST
                    jsonData: sendJson,
                    success: function (response) {
                        var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                        //发送json成功，成功刷新页面
                        if (result.code !=200) {
                            alert(result.msg)
                            return
                        }
                        location.reload();
                    },
                    failure: function (response) {
                        console.error('请求失败：', response.statusText);
                    }
                });
            }


        });


    //打开遮盖
    document.getElementById('openButton').addEventListener('click', function () {
        var tableBody = document.querySelector('.dynamicTable tbody');
        tableBody.innerHTML = ""

        searchInput =document.getElementById("searchInput")
        if (searchInput){
            searchInput.value = ""
        }
        document.getElementById('overlay').style.display = 'flex';
    });

    //关闭遮盖，清除表
    document.getElementById('closeButton').addEventListener('click', function () {
        document.getElementById('overlay').style.display = 'none';
    });

    //关闭遮盖，清除表  详细
    document.getElementById('closeButton2').addEventListener('click', function () {
        var tableBody = document.querySelector('#dynamicTable2 tbody');
        tableBody.innerHTML = ""
        document.getElementById('overlay2').style.display = 'none';
    });

    //关闭遮盖，清除表  详细
    document.getElementById('closeButton3').addEventListener('click', function () {
        var tableBody = document.querySelector('#dynamicTable3 tbody');
        tableBody.innerHTML = ""
        document.getElementById('overlay3').style.display = 'none';
    });


    function createInputOrSelectElement(key, value, data) {
        var enumOptions = getEnumOptions(key, data);
        var legalOptions = getLegalOptions(key, data);

        var element = '';
        if (enumOptions.length > 0) {
            element = '<select   name="' + key + '"> \
                <option value=""></option> \
                ' + enumOptions.map(function (option) {
                return '<option value="' + option.text + '"' + (option.value === value ? ' selected' : '') + '>' + option.value + '</option>';
            }).join('') + ' \
            </select>';
        } else if (legalOptions.length > 0) {
            element = '<select name="' + key + '"> <option value=""></option>' + legalOptions.map(function (option) {
                return '<option value="' + option + '"' + (option === value ? ' selected' : '') + '>' + option + '</option>';
            }).join('') + ' </select>';
        } else {
            element = '<input type="text" name="' + key + '" id="' + key + '" value="' + (value || '') + '">';
        }

        return element;
    }

    function getEnumOptions(attributeName, data) {
        for (var key in data.Enum_Values) {
            if (data.Enum_Values.hasOwnProperty(key) && key.indexOf(attributeName) !== -1) {
                if(!(data.Enum_Values[key]  instanceof Array) ){
                   var EnumJson =  JSON.stringify(data.Enum_Values[key])
                    console.log( );
                    var clearEnum = EnumJson.substring(1, EnumJson.length - 1).replace(/\\"/g, '"')
                    data.Enum_Values[key] = JSON.parse(clearEnum)
                }
                return data.Enum_Values[key].map(function (option) {
                    return {
                        text: Object.keys(option)[0],
                        value: Object.values(option)[0]
                    };
                });
            }
        }
        return [];
    }

    function getLegalOptions(attributeName, data) {
        for (var key in data.Legal_Values) {
            if (data.Legal_Values[key]) {
            if (data.Legal_Values.hasOwnProperty(key) && key.indexOf(attributeName) !== -1) {
                return data.Legal_Values[key].split(',');
            }}
        }
        return [];
    }


    function populateTable(data) {
        var tableBody = document.querySelector('#dynamicTable tbody');
        tableBody.innerHTML = ""
        var displayAttribute = data.displayAttribute;
        var KeyAttributeRules = data.KeyAttributeRules;

        for (var key in displayAttribute) {
            if (displayAttribute.hasOwnProperty(key)) {
                var value = displayAttribute[key];// 显示属性值
                var label = KeyAttributeRules[key];//显示属性名
                if (value === "无") {
                    value = "";
                }


                //IBA布尔
                <%-- if (displayAttribute.hasOwnProperty("IsSKDPart")) { --%>
                if (key==="IsSKDPart"){
                    isSKD = JSON.parse("[{\"True\":\"是\"},{\"False\":\"否\"}]")
                    if (value === "真") {
                        value = "True"
                    }

                    if (value === "假") {
                        value = "False"
                    }

                    data["Enum_Values"]["IBA_IsSKDPart"] =   isSKD
                }

               <%--  }else{
                     continue;
                } --%>


                //获取枚举内部值对应的显示值
                var enumOptions = getEnumOptions(key, data);
                if(enumOptions.length>0){
                    for (var i = 0; i < enumOptions.length; i++) {
                        // 遍历对象的属性
                        if (enumOptions[i]["text"] == value) {
                            value = enumOptions[i]["value"];
                            break;
                        }

                    }
                }
                var inputElement = createInputOrSelectElement(key, value, data);

                //必填添加*
                 var requireAtt = data.requiredAttribute.split(',')
                    if(requireAtt.includes(key)){
                        label = "*"+label
                    }


                var row = document.createElement('tr');
                row.innerHTML = '<td>' + label + '</td> \
            <td class="display-value">' + value + '</td> \
            <td>' + inputElement + '</td>';
                tableBody.appendChild(row);
                if(key=="Suppliers"){serachGYS("Suppliers")}
                <%-- if(key=="Factory"){ 
                    var factorySelect = document.querySelector('select[name="Factory"]');
                    if(factorySelect){dropsDownSearchInput(factorySelect)}
                } --%>
            }
        }
    }

    //展示修改|详细
    function populateTableShowDetail(data , option) {
        var tableBody ;
        if(option === "show"){
            tableBody = document.querySelector('#dynamicTable2 tbody');
        }
        if(option === "update"){
            tableBody =document.querySelector('#dynamicTable3 tbody');
        }
        tableBody.innerHTML = ""
        var oldAttributeRules = data.displayAttribute;
        var updateAttribute = data.updateAttribute;
        var KeyAttributeRules = data.KeyAttributeRules;

        for (var key in oldAttributeRules) {
            if (oldAttributeRules.hasOwnProperty(key)) {
                var oldValue = oldAttributeRules[key];// 显示属性值
                var newValue = updateAttribute[key];// 显示属性值
                var label = KeyAttributeRules[key];//显示属性名

                if (newValue === "无") {
                    newValue = "";
                }

                if (oldValue === "无") {
                    oldValue = "";
                }


                //IBA布尔
                <%-- if (oldAttributeRules.hasOwnProperty("IsSKDPart")) { --%>

                if (key==="IsSKDPart"){
                    isSKD = JSON.parse("[{\"True\":\"是\"},{\"False\":\"否\"}]")
                    if (oldValue === "真") {
                        oldValue = "True";// 显示属性值
                    }

                    if (oldValue === "假") {
                        oldValue = "True";// 显示属性值
                    }
                    if (newValue === "真") {
                        newValue = "True";// 显示属性值
                    }

                    if (newValue === "假") {
                        newValue = "True";// 显示属性值
                    }

                    data["Enum_Values"]["IBA_IsSKDPart"] =   isSKD
                }
               <%--  }else{
                    
                } --%>

                //获取枚举内部值对应的显示值
                var enumOptions = getEnumOptions(key, data);
                if (enumOptions.length > 0) {
                    for (var i = 0; i < enumOptions.length; i++) {
                        // 遍历对象的属性
                        if (enumOptions[i]["text"] == newValue) {
                            newValue = enumOptions[i]["value"];
                        }

                        if (enumOptions[i]["text"] == oldValue) {
                            oldValue = enumOptions[i]["value"];
                        }

                    }
                }


                //展示必填项
                var requireAtt = data.requiredAttribute.split(',')
                if(requireAtt.includes(key)){
                    label = "*"+label
                }





                if (option === "update") {
                    var inputElement = createInputOrSelectElement(key, newValue, data);
                    var row = document.createElement('tr');
                    row.innerHTML = '<td>' + label + '</td> \
                    <td class="display-value">' + oldValue + '</td> \
                    <td>' + inputElement + '</td>';
                    tableBody.appendChild(row);

                    if(key=="Suppliers"){serachGYS("Suppliers")}
                   <%--  if(key=="Factory"){ 
                        var factorySelect = document.querySelector('select[name="Factory"]');
                        if(factorySelect){dropsDownSearchInput(factorySelect)}
                    } --%>
                 

                }
                if (option === "show") {
                    var row = document.createElement('tr');
                    row.innerHTML = '<td>' + label + '</td> \
                    <td class="display-value">' + oldValue + '</td> \
                    <td>' + newValue + '</td>';
                    tableBody.appendChild(row);
                }

            }}

    }





    //搜索
    //获取供应商的数据
    var checkSupplyData;
     Ext.Ajax.request({
        url: '/Windchill/ptc1/Change/getALlSupplyName',
        method: 'GET', // 请求方法设置为 GET
        success: function (response) {
           checkSupplyData = Ext.decode(response.responseText); // 将响应数据解析为对象
        },
        failure: function (response) {
            console.error('请求失败：', response.statusText);
        }
    });
    function serachGYS(inputId) {
        const input = document.getElementById(inputId);

        input.parentNode.className="unique-search-container";

        // Create and insert the results popup
        const resultsPopup = document.createElement('div');
        resultsPopup.className = 'unique-results-popup hidden';
        input.parentNode.insertBefore(resultsPopup, input.nextSibling);

        input.addEventListener('input',  function () {
            const query = this.value;
            if (query.length > 0) {
                var result = checkSupplyData.filter(item => item.toLowerCase().includes(query.toLowerCase())).slice(0, 10);
                displayResults(result, resultsPopup, input);
            } else {
                clearResults(resultsPopup);
            }
        });

         
        

        function displayResults(supplyData, resultsPopup, input) {

            resultsPopup.innerHTML = ''; // Clear previous results
            supplyData.forEach(item => {
                const resultItem = document.createElement('div');
                resultItem.textContent = item;
                resultItem.addEventListener('click', () => {
                    input.value = item; // Fill input with selected value
                    clearResults(resultsPopup);
                });
                resultsPopup.appendChild(resultItem);
            });

            resultsPopup.classList.remove('hidden');
        }

        function clearResults(resultsPopup) {
            resultsPopup.innerHTML = '';
            resultsPopup.classList.add('hidden');
        }
    }

    //判断是否含有
    function checkSupply(input){
        var flag =false
        if (input && input.name === Suppliers && !checkSupplyData.includes(input.value.trim())) {
            flag =true
        }
        return flag
    }


    //校验必填
    function checkRequire(data,input,select){
        var flag = false;
        var requireAtt = data.requiredAttribute.split(',')
        if ( (input && requireAtt.includes(input.name) && input.value.trim()==='') ||
             (select &&requireAtt.includes(select.name) && select.value.trim()==='')) {
            alert("注意：缺少必要信息 \n\n您必须为所有带星号(*)的必填字段，指定有效的信息！")
            flag= true;

            return flag;
        }


        //供应商=“零散供应商”或“零散供应商-美金”时，供应商全名不能为空
        if(input &&  input.name===Suppliers &&  (input.value==="零散供应商" || input.value==='零散供应商-美金')){
            var supplierFullNameInput = document.querySelector('input[name="'+SupplierFullName+'"]');
            if (supplierFullNameInput && supplierFullNameInput.value.trim()==='') {
                alert("供应商选择零散供应商，零散供应商-美金时，供应商全名不能为空！")
                 flag= true;
                 return flag;
            }
        }

        //非电子部件，当源=“外购”时，供应商必填；电子部件，料号带"."的，当源=“外购”时，供应商必填


        //当input为供应商输入框时  且为空时
        if(input &&  input.name===Suppliers &&  input.value.trim()===''){


            //获取部件类型内部名，从json对象中
            var partTypeName = data.partTypeInternalName;
            //获取部件编号，从json对象中
            var partNumber = data.number;



            //获取源下拉框
            var sourceSelect = document.querySelector('select[name="source"]');

            //不为电子部件  源为外购
            if(sourceSelect && partTypeName!="com.ptc.ElectricalPart" && sourceSelect.value.trim() === "WG"){
                alert("非电子部件，当源=“外购”时，供应商必填");
                flag= true;
                return flag;
            }


            //为电子部件 编号带.  源为外购
            if(sourceSelect && partTypeName==="com.ptc.ElectricalPart" && partNumber.includes(".") && sourceSelect.value.trim() === "WG"){
                alert("电子部件，料号带'.'时，当源=“外购”时，供应商必填");
                flag= true;
                return flag;
            }

        }


        return flag;
    }



    //给指定下拉框添加输入
     function dropsDownSearchInput(dataDropdown) {
        
        // var dataDropdown = document.getElementById(customer);
        var fcontainer = dataDropdown.parentNode
        // 创建输入框
        var inputContainer = document.createElement('div');
        var searchInputF= document.createElement('input');
        searchInputF.type = 'text';
        searchInputF.placeholder = '';
        searchInputF.style.width = '100px';

        // 创建浮窗展示搜索结果
        const resultsContainer = document.createElement('div');
        resultsContainer.style.width = '100px';
        resultsContainer.style.border = '1px solid #ccc';
        resultsContainer.style.borderRadius = '5px';
        resultsContainer.style.zIndex='1000'
        resultsContainer.style.overflowY = 'auto';
        
        resultsContainer.style.position = 'absolute'; // 使浮窗位置绝对定位
        resultsContainer.style.display = 'none'; // 默认隐藏浮窗
        resultsContainer.style.background = 'rgb(255, 240, 214)'; // 默认隐藏浮窗

        // 将输入框和结果容器添加到页面中
        inputContainer.appendChild(searchInputF);
        inputContainer.appendChild(resultsContainer);
        inputContainer.appendChild(dataDropdown);
        fcontainer.appendChild(inputContainer)

        // 获取下拉框的选项作为数据源
        const dropdownOptions = Array.from(dataDropdown.options).map(option => ({
            text: option.textContent, // 显示文本
            value: option.value // 选项值
        }));

        // 处理输入框输入事件
        searchInputF.addEventListener('input', function () {
            const searchTerm = searchInputF.value.toLowerCase();
            const filteredResults = dropdownOptions.filter(item =>
                item.text.toLowerCase().includes(searchTerm)
            );
            displayResults(filteredResults);
        });

        // 展示搜索结果
        function displayResults(results) {
            resultsContainer.innerHTML = ''; // 清空之前的结果
            if (results.length > 0) {
                resultsContainer.style.display = 'block'; // 显示浮窗
                results.forEach(item => {
                    const resultItem = document.createElement('div');
                    resultItem.style.padding = '1px';
                    resultItem.style.cursor = 'pointer';
                    resultItem.textContent = item.text;
                    resultItem.addEventListener('click', function () {

                        selectOption(item); // 点击选项后更新下拉框内容
                    });
                    resultsContainer.appendChild(resultItem);
                });
            } else {
                resultsContainer.style.display = 'none'; // 隐藏浮窗
            }
        }

        // 更新下拉框选中内容
        function selectOption(option) {
            dataDropdown.value = option.value; // 更新下拉框的 value 属性
            searchInputF.value = option.text; // 更新输入框的显示值
            resultsContainer.innerHTML = ''; // 清空搜索结果
            resultsContainer.style.display = 'none'; // 隐藏浮窗
        }

        // 点击文档其他区域时隐藏浮窗
        document.addEventListener('click', function (event) {
            if (!resultsContainer.contains(event.target) && event.target !== searchInputF) {
                resultsContainer.style.display = 'none';
            }
        });

        // 更新浮窗位置到下拉框旁边
        function updateResultsPosition() {
            const dropdownRect = dataDropdown.getBoundingClientRect();
            searchInputF.style.top = `${dropdownRect.top}px`;
            searchInputF.style.left = `${dropdownRect.right + 10}px`; // 下拉框右侧10px位置
            resultsContainer.style.top = `${dropdownRect.bottom + window.scrollY}px`;
            resultsContainer.style.left = `${dropdownRect.left + dropdownRect.width + 10}px`;


        }

        // 初始位置设置
        function initializePosition() {
            searchInputF.style.position = 'absolute';
            resultsContainer.style.position = 'absolute';
            updateResultsPosition();
        }

        // 页面加载完成后设置位置
        window.addEventListener('load', initializePosition);
        // 重新更新位置当窗口调整大小时
    }




</script>

</html>