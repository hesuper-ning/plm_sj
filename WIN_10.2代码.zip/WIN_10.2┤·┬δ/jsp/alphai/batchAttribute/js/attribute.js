document.getElementById('openButton').addEventListener('click', function () {
    document.getElementById('overlay').style.display = 'flex';
});

document.getElementById('closeButton').addEventListener('click', function () {
    document.getElementById('overlay').style.display = 'none';
});
var data;
function searchData() {
    data = 
    
    {"Enum_Values":{"CLS_Color":[{"2":"白"},{"1":"黑"}]},"classify":"02.16","Legal_Values":{"CLS_sprocommType":"三合一,车把预组,轮胎预组,控制器预组,座包预组,包材预组,加工件"},"displayAttribute":{"EUcertification":"无","ProjectName":"三合一_E6553-信利_-_售后","sprocommType":"三合一","Color":"无"},"KeyAttributeRules":{"EUcertification":"欧盟认证(仅限出口欧盟项目选择)","ProjectName":"项目名","sprocommType":"类型","Color":"颜色"},"number":"02.16.0606"}


    // {
    //     "Enum_Values": {
    //         "CLS_颜色": [
    //             {
    //                 "白": "2"
    //             },
    //             {
    //                 "黑": "1"
    //             }
    //         ]
    //     },
    //     "classify": "02.16",
    //         "Legal_Values": {
    //         "CLS_类型": "三合一,车把预组,轮胎预组,控制器预组,座包预组,包材预组,加工件"
    //     },
    //     "displayAttribute": {
    //         "EUcertification": "无",
    //             "ProjectName": "三合一_E6553-信利_-_售后",
    //                 "sprocommType": "三合一",
    //                     "Color": "无"
    //     },
    //     "KeyAttributeRules": {
    //         "欧盟认证(仅限出口欧盟项目选择)": "EUcertification",
    //             "颜色": "Color",
    //                 "类型": "sprocommType",
    //                     "项目名": "ProjectName"
    //     },
    //     "number": "02.16.0606"
    // }
    populateTable(data);


}



function createInputOrSelectElement(key, value, data) {
    var enumOptions = getEnumOptions(key, data);
    var legalOptions = getLegalOptions(key, data);

    var element = '';
    if (enumOptions.length > 0) {
        element = '<select name="' + key + '"> \
            <option value=""></option> \
            ' + enumOptions.map(function (option) {
            return '<option value="' + option.text + '"' + (option.value === value ? ' selected' : '') + '>' + option.value + '</option>';
        }).join('') + ' \
        </select>';
    } else if (legalOptions.length > 0) {
        element = '<select name="' + key + '"> \
            <option value=""></option> \
            ' + legalOptions.map(function (option) {
            return '<option value="' + option + '"' + (option === value ? ' selected' : '') + '>' + option + '</option>';
        }).join('') + ' \
        </select>';
    } else {
        element = '<input type="text" name="' + key + '" value="' + (value || '') + '">';
    }

    return element;
}

function getEnumOptions(attributeName, data) {
    for (var key in data.Enum_Values) {
        if (data.Enum_Values.hasOwnProperty(key) && key.indexOf(attributeName) !== -1) {
            return data.Enum_Values[key].map(function (option) {
                return {
                    text: Object.keys(option)[0],
                    value: Object.values(option)[0]
                };
            });
        }
    }
    return [];
}

function getLegalOptions(attributeName, data) {
    for (var key in data.Legal_Values) {
        if (data.Legal_Values.hasOwnProperty(key) && key.indexOf(attributeName) !== -1) {
            return data.Legal_Values[key].split(',');
        }
    }
    return [];
}

function populateTable(data) {
    var tableBody = document.querySelector('#dynamicTable tbody');
    var displayAttribute = data.displayAttribute;
    var KeyAttributeRules = data.KeyAttributeRules;

    for (var key in displayAttribute) {
        if (displayAttribute.hasOwnProperty(key)) {
            var value = displayAttribute[key];
            var label = KeyAttributeRules[key];
            if (value === "无") {
                value = "";
            }
            var inputElement = createInputOrSelectElement(key, value, data);

            var row = document.createElement('tr');
            row.innerHTML = '<td>' + label + '</td> \
        <td class="display-value">' + value + '</td> \
        <td>' + inputElement + '</td>';
            tableBody.appendChild(row);
        }
    }
}

function updateDisplayValue(element) {
    var row = element.closest('tr');
    var displayCell = row.querySelector('.display-value');

    if (element.tagName === 'SELECT') {
        displayCell.textContent = element.options[element.selectedIndex].text;
    } else if (element.tagName === 'INPUT') {
        displayCell.textContent = element.value;
    }
}




//修改json
document.getElementById('updateButton').addEventListener('click', function () {
    if (data === null || data === undefined) {
        alert("请查询部件属性！")
        return;
    }


    const rows = document.querySelectorAll('#dynamicTable tbody tr');
    const result = {};

    result["number"] = data["number"]
    result["classify"] = data["classify"]
    result["Enum_Values"] = data["Enum_Values"]
    result["KeyAttributeRules"] = data["KeyAttributeRules"]

    rows.forEach(row => {
        const thirdColumn = row.querySelector('td:nth-child(3)');
        if (thirdColumn) {
            const input = thirdColumn.querySelector('input');
            const select = thirdColumn.querySelector('select');

            if (input) {
                value = input.value
                name = input.name
                result[name] = value;
            } else if (select) {
                value = select.value
                name = select.name
                result[name] = value;
            }
        }
    });


    var sendJosn = JSON.stringify(result, null, 2)
    console.log(sendJosn);

    //发送json，成功刷新页面
    location.reload();
});