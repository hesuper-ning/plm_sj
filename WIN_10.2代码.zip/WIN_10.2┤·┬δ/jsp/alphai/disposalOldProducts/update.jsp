<%@page import="com.ptc.netmarkets.util.beans.NmContextBean" %>
<%@page import="com.ptc.netmarkets.util.beans.NmCommandBean" %>
<%@page import="java.util.ArrayList" %>
<%@page import="com.ptc.netmarkets.model.NmOid" %>
<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/picker" prefix="p" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca" %>
<%@ page import="java.util.List" %>
<%@ page import="ext.alphai.xl.disposalOldProducts.DisposalOldProducts" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc" %>
<jca:tabToHighlight actionName="propertyPanel" objectType="object"/>
<%@ include file="/netmarkets/jsp/util/begin.jspf" %>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb" %>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags" %>
<%
    System.out.println("进入添加");
    String contextPath = request.getContextPath();
    NmCommandBean cb1 = new NmCommandBean();
    cb1.setInBeginJsp(true);
    cb1.setOpenerCompContext(request.getParameter("compContext"));
    cb1.setOpenerElemAddress(NmCommandBean.convert(request.getParameter("openerElemAddress")));
    cb1.setCompContext(NmCommandBean.convert(request.getParameter("compContext")));
    cb1.setElemAddress(NmCommandBean.convert(request.getParameter("elemAddress")));
    cb1.setRequest(request);
    cb1.setResponse(response);
    cb1.setOut(out);
    cb1.setContextBean(new NmContextBean());
    ArrayList<NmOid> selected = cb1.getSelectedOidForPopup();
    List<DisposalOldProducts> items = new ArrayList<>();

    for (NmOid nmOid : selected) {
        Object ref = nmOid.getRef();
        if (ref instanceof DisposalOldProducts) {
            DisposalOldProducts disposalOldProducts = (DisposalOldProducts) ref;
            items.add(disposalOldProducts);
        }
    }

    String[] options = {"","无", "返工", "返修", "报废", "其他"};
    String[] options2 = {"","自制件", "外购件", "外协件", "外协子件"};
%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <style>

        #priceTable {
            width: 100%;
            border-collapse: collapse;
        }
        #priceTable th,
        #priceTable td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center; /* 水平居中 */
            vertical-align: middle; /* 垂直居中 */
        }
        #priceTable th {
            background-color: #f2f2f2;
        }
        /* 隐藏边框的多文本框样式 */
        .hidden-textarea {
            border: none; /* 隐藏边框 */
            background-color: transparent; /* 背景透明 */
            width: 100%; /* 宽度100%以填满单元格 */
            resize: none; /* 禁止调整大小 */
            color: #333; /* 文本颜色 */
            height: 50px; /* 设置固定高度 */
            outline: none; /* 去掉焦点时的轮廓 */
            text-align: center; /* 文本水平居中 */
            line-height: 50px; /* 设置行高，使内容垂直居中 */
            padding: 0; /* 去掉内边距 */
        }
        .hidden-textarea-common{
            border: none; /* 隐藏边框 */
            background-color: transparent; /* 背景透明 */
            width: 100%; /* 宽度100%以填满单元格 */
            resize: none; /* 禁止调整大小 */
            color: #333; /* 文本颜色 */
            height: 50px; /* 设置固定高度 */
            outline: none; /* 去掉焦点时的轮廓 */
            padding: 0; /* 去掉内边距 */
        }
    </style>

</head>
<body>

<table id="priceTable">
    <thead>
    <tr>
        <th>零部件名称</th>
        <th>零部件编号</th>
        <th>旧版</th>
        <th>顾客成品</th>
        <th>西菱成品</th>
        <th>在制品</th>
        <th>定制品</th>
        <th>工装</th>
        <th>模具</th>
        <th>刀具</th>
        <th>检具</th>
        <th>在库存</th>
        <th>在订</th>
        <th>WIP</th>
        <th>其他项说明</th>
    </tr>
    </thead>
    <tbody>
    <%
        if (items.size()>0) {
            for (DisposalOldProducts item : items) {
                long id = item.getPersistInfo().getObjectIdentifier().getId();
                String IDA2A =String.valueOf(id);
                String inTheLibrary = item.getInTheLibrary()==null?"": item.getInTheLibrary();
                String inOrder = item.getInOrder()==null?"": item.getInOrder();
                String wip = item.getWip()==null?"": item.getWip();
                String otherNotes = item.getOtherNotes()==null?"": item.getOtherNotes();
    %>

    <tr>
        <input hidden type="hidden"  name="IDA2A" value="<%=IDA2A%>">
        <input hidden type="hidden"  name="partOid" value="<%=item.getPartOID()%>">
        <td><textarea name="partName" class="hidden-textarea" readonly><%=item.getPartName()%></textarea></td>
        <td><textarea name = "partNumber" class="hidden-textarea" readonly><%=item.getPartNumber()%></textarea></td>
        <td><textarea name ="partOldVersion" class="hidden-textarea" readonly><%=item.getPartOldVersion()%></textarea></td>
        <td class="dropdown">
            <select name="customerArtifact">
                <%for (String option : options) {%>
                <option value="<%=option%>"  <%= option.equals(item.getCustomerArtifact()) ? "selected" : "" %> ><%=option%></option>
                <%}%>
            </select>
        </td>
        <td class="dropdown">
            <select name="xlArtifact">
                <%for (String option : options) {%>
                <option value="<%=option%>"  <%= option.equals(item.getXLArtifact()) ? "selected" : "" %> ><%=option%></option>
                <%}%>
            </select>
        </td>
        <td class="dropdown">
            <select name="inMaking">
                <%for (String option : options) {%>
                <option value="<%=option%>"  <%= option.equals(item.getInMaking()) ? "selected" : "" %> ><%=option%></option>
                <%}%>
            </select>
        </td>
        <td class="dropdown">
            <select name="inOrdering">
                <%for (String option : options) {%>
                <option value="<%=option%>"  <%= option.equals(item.getInOrdering()) ? "selected" : "" %> ><%=option%></option>
                <%}%>
            </select>
        </td>
        <td class="dropdown">
            <select name="frock">
                <%for (String option : options) {%>
                <option value="<%=option%>"  <%= option.equals(item.getFrock()) ? "selected" : "" %> ><%=option%></option>
                <%}%>
            </select>
        </td>
        <td class="dropdown">
            <select name="mold">
                <%for (String option : options) {%>
                <option value="<%=option%>"  <%= option.equals(item.getMold()) ? "selected" : "" %> ><%=option%></option>
                <%}%>
            </select>
        </td>
        <td class="dropdown">
            <select name="cuttingTool">
                <%for (String option : options) {%>
                <option value="<%=option%>"  <%= option.equals(item.getCuttingTool()) ? "selected" : "" %> ><%=option%></option>
                <%}%>
            </select>
        </td>
        <td class="dropdown">
            <select name="fixtures">
                <%for (String option : options) {%>
                <option value="<%=option%>"  <%= option.equals(item.getFixtures()) ? "selected" : "" %> ><%=option%></option>
                <%}%>
            </select>
        </td>
        <td><input name="inTheLibrary" type="text" value="<%=inTheLibrary%>"></td>
        <td><input name="inOrder" type="text" value="<%=inOrder%>"></td>
        <td><input name="wip" type="text" value="<%=wip%>"></td>
<%--        <td class="dropdown">--%>
<%--            <select name="wip">--%>
<%--                <%for (String option : options2) {%>--%>
<%--                <option value="<%=option%>"  <%= option.equals(item.getWip()) ? "selected" : "" %> ><%=option%></option>--%>
<%--                <%}%>--%>
<%--            </select>--%>
<%--        </td>--%>

        <td> <textarea name="otherNotes"  class="hidden-textarea-common" ><%=otherNotes%></textarea></td>
    </tr>
    <%}}else{%>

    请选择修改的部件
    <%}%>
    </tbody>
</table>
</body>


</body>
<%@ include file="/netmarkets/jsp/util/end.jspf" %>
<script type="text/javascript">

</script>

</html>
