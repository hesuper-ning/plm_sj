<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib tagdir="/WEB-INF/tags" prefix="tags"%>
<%@page pageEncoding="utf-8" %>


<%@taglib uri="http://www.ptc.com/windchill/taglib/workItem"  prefix="workItem"%>

<%@ include file="/netmarkets/jsp/util/begin.jspf"%>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        #data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        #data-table th,
        #data-table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
        }

        #data-table tr td:nth-child(1){
            width: 25%;
        }
        #data-table tr td:nth-child(2){
            width: 5%;
        }

        #data-table tr td:nth-child(3),
        #data-table tr td:nth-child(4){
            width: 35%;
        }

        .container {
            width: 80%;
            margin: auto;
        }

        #data-table .underline-input {
            border: none;
            border-bottom: 2px solid black;
            outline: none;
            padding: 5px;
            width: 70%;
        }

        #data-table .underline-input-short {
            border: none;
            border-bottom: 2px solid black;
            outline: none;
            padding: 5px;
            width: 50px;
        }
    </style>
</head>

<workItem:MyWorkItem/>
<c:if test="${myWorkItem != null}">

<%-- There are two steps to render a custom activity variable on the task page.

1) Place the name of the activity variable that you want to display on the 
page in the comma delimited custom_variables list.

Height and/or width can be specified using CSS style syntax.  
For example "variable_name{height:1;width:2}". 
Specifying "all_activity_variables" will display all visible activity 
variables not named "special_instructions", or "instructions".  

2) To specify where to render the particular variable on the page you must add
the following line.

<tags:taskPanelValue propertyModel="${propertyModel}" attrs="variable_name"/>

Note: by default all_activty_variables are rendered.  If you add a custom 
activity variable and have all_activity_variables the variable will show up twice.

--%>

<tags:workItemInfo custom_variables="all_activity_variables"/>

<BR>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td rowspan="3" width="12"><IMG SRC="netmarkets/images/sp.gif" height="1" width="12"></td>
    <td rowspan="3" class="tableborderbg" width="1"><IMG SRC="netmarkets/images/sp.gif" height="1" width="1"></td>
    <td class="tableborderbg"><IMG SRC="netmarkets/images/sp.gif" height="1" width="1"></td>
    <td rowspan="3" class="tableborderbg" width="1"><IMG SRC="netmarkets/images/sp.gif" height="1" width="1"></td>
    <td rowspan="3" width="12"><IMG SRC="netmarkets/images/sp.gif" height="1" width="12"></td>
  </tr>
  <tr class="detailsboxbg">
    <td>

      <table cellpadding="0" cellspacing="0" border="0" align="right" width=100%>
        <tr>
          <td> &nbsp; </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr class="detailsboxbg">
    <td>
<table border="0" cellpadding="0" cellspacing="0">
  <tr>
  	 <td><tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_detailaction"/> </td>
	 <td width="12"><IMG SRC="netmarkets/images/sp.gif" height="1" width="12"></td>
	 <td><font class="projectnamefont"><IMG SRC="netmarkets/images/open_work.gif">
		<tags:taskPanelValue propertyModel="${propertyModel}" attrs="workitem_activityname"/>
	</td>
  </tr>
</table>
<div align="left">

<table border="0" cellpadding="1" width=100%>
        <!-- Task Information Section -->
	<span class="x-reset">
	<tr>
		<tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_instructions"/>
	</tr>
	</span>
	<tr>

	<tr>
		<td align="right" valign="top" nowrap><FONT class=tabledatafont>
			<tags:taskPanelLabel propertyModel="${propertyModel}" attrs="workitem_processname"/></FONT>
		</td>
		<td valign="top"><FONT class=tabledatafont>
                        <tags:taskPanelValue propertyModel="${propertyModel}" attrs="workitem_lightweightprocessmonitor"/>
                        <tags:taskPanelValue propertyModel="${propertyModel}" attrs="workitem_processname"/> 
		</td>
	</tr>

	<tr>
		<tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_processinitiator"/>
	</tr>

	<tr>
		<tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_assignee"/>
	</tr>
	<tr>
		<td align="right" valign="top" nowrap><FONT class=tabledatafont>
			<tags:taskPanelLabel propertyModel="${propertyModel}" attrs="workitem_role"/></FONT>
		</td>
		<td valign="top"><FONT class=tabledatafont>
			<tags:taskPanelValue propertyModel="${propertyModel}" attrs="workitem_role"/>
		</td>
	</tr>
	<tr>
		<tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_priority"/>
	</tr>
	<tr>
		<tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_deadline"/>
	</tr>
	<tr>
		<tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_pbolink"/>
	</tr>

	<tr>
		<tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_state"/>
	</tr>
   
        <tags:taskPanelValue propertyModel="${propertyModel}" attrs="all_activity_variables"/>   
	
<tr>	

	<td valign="middle" colspan="3">
		<FONT class=wizardbuttonfont>
		<tags:adhocAct/></FONT></td>
</tr>


	<tr><td valign="middle" colspan="3"><hr size="1" width="100%"></td></tr>

	<tags:workItemActions />
	</tr>	
		
	<tr>
		<td valign="middle" colspan="3"><hr size="1" width="100%"></td>
	</tr>
        <!-- task completion section -->

	<tr>
		<tags:taskPanel propertyModel="${propertyModel}" attrs="workitem_esignature"/>
	</tr>

	<tr>
		<td></td><td></td><td valign="middle" align="left">
			<FONT class=wizardbuttonfont><jsp:include page="/netmarkets/jsp/customtemplates/completeButton.jsp"/>
							  			 </FONT>
		</td>
  	</tr>
  	
	</table>

	</div>
	</td>
  </tr>
  <tr>
	<td></td><td></td><td class="tableborderbg"><IMG SRC="netmarkets/images/sp.gif" height="1" width="1"></td>
  </tr>
</table>

<fieldset class="x-fieldset x-form-label-left" id="Visualization_and_Attributes" style="margin:10px 5px 15px 10px;">

    <div class="container">
        <table id="data-table">
            <thead>
                <tr>
                    <th>评估项</th>
                    <th>是否</th>
                    <th>评审意见</th>
                    <th>文件或记录支持</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>是否识别了所有受影响对象？</td>
                    <td>
                        <select name="status1">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        <input class="underline-input" type="text" name="comment1_2">
                    </td>
                    <td><input class="underline-input" class="underline-input" type="text" name="supportingDoc1"></td>
                </tr>
                <tr>
                    <td>是否影响特殊特性？若是，请更新文件？</td>
                    <td>
                        <select name="status2">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        <input class="underline-input" type="text" name="comment2_2">
                    </td>
                    <td><input class="underline-input" type="text" name="supportingDoc2"></td>
                </tr>


                <tr>
                    <td>是否影响增压器性能和可靠性?</td>
                    <td>
                        <select name="status2">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        <input class="underline-input" type="text" name="comment2_2">
                    </td>
                    <td><input class="underline-input" type="text" name="supportingDoc2"></td>
                </tr>

                <tr>
                    <td>是否需要计算/试验验证？若是，提供验证计划和报告（含变更前方案验证，变更后结果、一致性验证，变更前验证需提供报告）</td>
                    <td>
                        <select name="status2">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        <input class="underline-input" type="text" name="comment2_2">
                    </td>
                    <td><input class="underline-input" type="text" name="supportingDoc2"></td>
                </tr>

                <tr>
                    <td>是否需要变更设计文档(D-FMEA、设计规范等)</td>
                    <td>
                        <select name="status2">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        <input class="underline-input" type="text" name="comment2_2">
                    </td>
                    <td><input class="underline-input" type="text" name="supportingDoc2"></td>
                </tr>

                <tr>
                    <td>是否需要变更工程文档(材料规范、接收规范等)</td>
                    <td>
                        <select name="status2">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        <input class="underline-input" type="text" name="comment2_2">
                    </td>
                    <td><input class="underline-input" type="text" name="supportingDoc2"></td>
                </tr>

                <tr>
                    <td>是否需要更新检测规范、表格或指导书？</td>
                    <td>
                        <select name="status2">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        需更新<input class="underline-input" type="text" name="comment2_2">
                    </td>
                    <td><input class="underline-input" type="text" name="supportingDoc2"></td>
                </tr>


                <tr>
                    <td>是否需要新增检具等检测设备？</td>
                    <td>
                        <select name="status2">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        需新增<input class="underline-input" type="text" name="comment2_2">
                    </td>
                    <td><input class="underline-input" type="text" name="supportingDoc2"></td>
                </tr>

                <tr>
                    <td>需要新增检具等检测设备费用（预估）</td>
                    <td>
                        <select name="status2">
                            <option value="是">是</option>
                            <option value="否">否</option>
                        </select>
                    </td>
                    <td>
                        新增项周期需要<input class="underline-input-short" type="text" name="comment2_2">天，
                        费用需要<input class="underline-input-short" type="text" name="comment2_2">元
                    </td>
                    <td><input class="underline-input" type="text" name="supportingDoc2"></td>
                </tr>
            </tbody>
        </table>
        <input type="button"  value="生成JSON" onclick="generateJSON()">

    </div>
</fieldset>


<!-- PBO Info -->
<table border="0" cellpadding="3" width=100%>
	<tr>
            <td colspan="3">&nbsp;
                <!-- show the entire routing history & reassignment history tables -->
                <tags:routingStatus dispProcess="ALL"/>
                <!-- show the reassignment history within a table -->
                <!-- tags:reassignHistory showRH="table"/ -->
				
                <!-- displayType options are "table" or "link".  This tag only works when PBO implements interface SubjectOfNotebook -->
                <workItem:notebook displayType="table"/>
                
                <!-- displayType options are "table" or "link".  This tag only works when PBO implements interface SubjectOfForum -->
                <workItem:discussions displayType="table"/> 
                
	    </td>
	</tr>	
</table>

<BR>
</c:if>
<script>
    var jsonData = [];
    var result = {};
    result["DCRProductDev"];
    function generateJSON() {
        var rows = document.getElementById('data-table').getElementsByTagName('tr');

        jsonData = [];
        for (var i = 1; i < rows.length; i++) {
            var cells = rows[i].getElementsByTagName('td');
            var comments = [];
            var inputs = cells[2].getElementsByTagName('input');

            // 遍历第三列的所有输入框，获取它们的值
            for (var j = 0; j < inputs.length; j++) {
                comments.push(inputs[j].value);
            }

            var rowData = {
                "assessmentItems": cells[0].innerText,
                "yesOrNo": cells[1].getElementsByTagName('select')[0].value,
                "comments": comments,
                "fileOrSupport": cells[3].getElementsByTagName('input')[0].value
            };
            jsonData.push(rowData);
            //生产部审阅


        }
        result["DCRProductDev"] = jsonData;
        var sendJson = JSON.stringify(result, null, 2);
        console.log(sendJson)
        // document.getElementById('output').innerText = sendJson

        Ext.Ajax.request({
            url: '/Windchill/ptc1/alphai/DCR/assessmentTable',
            method: 'POST', // 请求方法设置为 POST
            jsonData: sendJson,
            success: function (response) {
                var result = Ext.decode(response.responseText); // 将响应数据解析为对象
                //发送json成功，成功刷新页面
                location.reload();
            },
            failure: function (response) {
                console.error('请求失败：', response.statusText);
            }
        });
    }
 
</script>

<%@ include file="/netmarkets/jsp/util/end.jspf"%>
