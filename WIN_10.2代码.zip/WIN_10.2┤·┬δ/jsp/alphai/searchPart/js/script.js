// new Vue({
//     el: '#app',
//     data() {
//         return {
//             oid : new URLSearchParams(window.location.search).get("oid"),
//             treeData: [
//
//             ],
//             defaultProps: {
//                 children: 'children',
//                 label: 'label'
//             },
//             selectedNode: null,
//             formData: {
//                 param1: '',
//                 param2: ''
//             },
//             options: [
//                 { value: 'option1', label: '选项 1' },
//                 { value: 'option2', label: '选项 2' },
//                 { value: 'option3', label: '选项 3' }
//             ],
//             tableData: []
//         };
//     },
//     created() {
//         this.getTreeData(); // 在组件创建时获取数据
//     },
//     methods: {
//         getTreeData() {
//             // 模拟接口调用
//             const simulatedData = [
//                 {
//                     label: '部件',
//                     children: [
//                         {  label: 'A_卷料' },
//                         {   label: 'C_半成品' },
//                         {   label: 'B_散件' },
//                         {   label: 'D_总成' }
//                     ]
//                 },
//                 {
//                     label: 'C_电控涡旋压缩机',
//                     children: [
//                         {  label: 'C43_弱电端子' },
//                         {   label: 'C90_总成' }
//                     ]
//                 }
//             ];
//             // 直接赋值模拟数据
//             this.treeData = simulatedData;
//         },
//         handleNodeClick(node) {
//             // 只有点击最低层子项才设置选中
//             if (!node.children || node.children.length === 0) {
//                 this.selectedNode = node.label;
//                 this.formData.param1 = '';
//                 this.formData.param2 = '';
//             }
//         },
//         searchTbaleData() {
//             const oid = this.oid;
//             const selectedOid = this.selectedNode; // 选中的节点 ID
//             const param1 = this.formData.param1; // 输入参数 1
//             const param2 = this.formData.param2; // 输入参数 2
//
//             // 构造查询参数
//
//             const queryParams = `oid=${oid}&selectedId=${selectedOid}&param1=${param1}&param2=${param2}`;
//
//             // 模拟接口请求，实际中应使用 axios 或 fetch
//             console.log('查询参数:', queryParams);
//             this.tableData = [
//                 { partNumber: 'P001', partName: '部件 A', version: 'v1.0', status: '正常' },
//                 { partNumber: 'P002', partName: '部件 B', version: 'v1.1', status: '异常' },
//                 { partNumber: 'P004', partName: '部件 A', version: 'v1.0', status: '正常' },
//                 { partNumber: 'P005', partName: '部件 B', version: 'v1.1', status: '异常' },
//                 { partNumber: 'P006', partName: '部件 A', version: 'v1.0', status: '正常' },
//                 { partNumber: 'P007', partName: '部件 B', version: 'v1.1', status: '异常' },
//                 { partNumber: 'P008', partName: '部件 A', version: 'v1.0', status: '正常' },
//                 { partNumber: 'P009', partName: '部件 B', version: 'v1.1', status: '异常' },
//                 { partNumber: 'P0010', partName: '部件 A', version: 'v1.0', status: '正常' },
//                 { partNumber: 'P011', partName: '部件 B', version: 'v1.1', status: '异常' },
//                 { partNumber: 'P0012', partName: '部件 A', version: 'v1.0', status: '正常' },
//                 { partNumber: 'P0013', partName: '部件 B', version: 'v1.1', status: '异常' },
//                 { partNumber: 'P0014', partName: '部件 A', version: 'v1.0', status: '正常' },
//                 { partNumber: 'P0015', partName: '部件 B', version: 'v1.1', status: '异常' },
//                 { partNumber: 'P0016', partName: '部件 C', version: 'v2.0', status: '正常' }
//
//             ];
//         }
//     }
// });