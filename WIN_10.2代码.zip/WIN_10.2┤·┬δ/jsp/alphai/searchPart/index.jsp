<%@page language="java" session="true" pageEncoding="UTF-8" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/components" prefix="jca" %>
<%@page import="wt.util.WTProperties" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/mvc" prefix="mvc" %>
<jca:tabToHighlight actionName="propertyPanel" objectType="object"/>
<%@ include file="/netmarkets/jsp/components/standardAttributeConfigs.jspf" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/wrappers" prefix="w" %>
<%@ taglib uri="http://www.ptc.com/windchill/taglib/carambola" prefix="cmb" %>
<%@ taglib prefix="wctags" tagdir="/WEB-INF/tags" %>
<%@ include file="/netmarkets/jsp/util/begin.jspf" %>
<%@ include file="/netmarkets/jsp/util/end.jspf" %>


<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="/Windchill/netmarkets/jsp/alphai/searchPart/element-ui/element-ui.css">
    <link rel="stylesheet" href="/Windchill/netmarkets/jsp/alphai/searchPart/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }
        .container {
            display: flex;
            gap: 20px;
            height: 750px;
            margin: auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .tree {
            min-width: 250px;
            border-right: 1px solid #e0e0e0;
            padding: 20px;
        }
        .form {
            flex: 2;
            padding: 20px;
        }
        .form .el-form-item {
            margin-bottom: 15px;
            width: 100%;
            overflow-x: auto;
        }
        .form  .el-input{
            width: 150px;
        }
        .el-button {
            width: 100px;
        }
        .table-container {
            margin-top: 20px;
            width: 800px;
        }
    </style>

</head>

<body>


  <div id="app" class="container">
    <el-tree
        class="tree"
        :data="treeData"
        :props="defaultProps"
        @node-click="handleNodeClick">
    </el-tree>
    <div class="form">
        <el-form :model="formData" v-if="selectedNode">
            <el-form-item label="参数 1">
                <el-input v-model="formData.param1"></el-input>
            </el-form-item>

            <el-form-item label="参数 1">
                <el-input v-model="formData.param1"></el-input>
            </el-form-item>

            <el-form-item label="参数 2">
                <el-select v-model="formData.param2" placeholder="请选择">
                    <el-option
                        v-for="option in options"
                        :key="option.value"
                        :label="option.label"
                        :value="option.value">
                    </el-option>
                </el-select>
            </el-form-item>

            <el-form-item>
                <el-button type="primary" @click="searchTbaleData">查询</el-button>
            </el-form-item>
        </el-form>

        <div class="table-container">
            <el-table
            :data="tableData"
            height="400"
            v-if="tableData.length > 0"
            >
                <el-table-column prop="partNumber" label="部件编号"  fixed   sortable resizable ></el-table-column>
                <el-table-column prop="partName" label="部件名称"    sortable resizable></el-table-column>
                <el-table-column prop="version" label="版本"    resizable></el-table-column>
                <el-table-column prop="status" label="状态"    resizable></el-table-column>

            </el-table>
        </div>
    </div>
</div>




</body>



<script type="text/javascript" src="/Windchill/netmarkets/jsp/alphai/searchPart/vue/vue.js"></script>
<script type="text/javascript" src="/Windchill/netmarkets/jsp/alphai/searchPart/vue/dist/axios.min.js"></script>
<script type="text/javascript" src="/Windchill/netmarkets/jsp/alphai/searchPart/element-ui/element-ui.js"></script>
<%--<script type="text/javascript" src="/Windchill/netmarkets/jsp/alphai/searchPart/js/script.js"></script>--%>


<script>
    new Vue({
        el: '#app',
        data() {
            return {
                oid : new URLSearchParams(window.location.search).get("oid"),
                treeData: [

                ],
                defaultProps: {
                    children: 'children',
                    label: 'label'
                },
                selectedNode: null,
                formData: {
                    param1: '',
                    param2: ''
                },
                options: [
                    { value: 'option1', label: '选项 1' },
                    { value: 'option2', label: '选项 2' },
                    { value: 'option3', label: '选项 3' }
                ],
                tableData: []
            };
        },
        created() {
            this.getTreeData(); // 在组件创建时获取数据
        },
        methods: {
            getTreeData() {
                // 模拟接口调用
                const simulatedData = [
                    {
                        label: '部件',
                        children: [
                            {  label: 'A_卷料' },
                            {   label: 'C_半成品' },
                            {   label: 'B_散件' },
                            {   label: 'D_总成' }
                        ]
                    },
                    {
                        label: 'C_电控涡旋压缩机',
                        children: [
                            {  label: 'C43_弱电端子' },
                            {   label: 'C90_总成' }
                        ]
                    }
                ];
                // 直接赋值模拟数据
                this.treeData = simulatedData;
            },
            handleNodeClick(node) {
                // 只有点击最低层子项才设置选中
                if (!node.children || node.children.length === 0) {
                    this.selectedNode = node.label;
                    this.formData.param1 = '';
                    this.formData.param2 = '';
                }
            },
            searchTbaleData() {
                const oid = this.oid;
                const selectedOid = this.selectedNode; // 选中的节点 ID
                const param1 = this.formData.param1; // 输入参数 1
                const param2 = this.formData.param2; // 输入参数 2

                // 构造查询参数

                const queryParams = `oid=${oid}&selectedId=${selectedOid}&param1=${param1}&param2=${param2}`;

                // 模拟接口请求，实际中应使用 axios 或 fetch
                console.log('查询参数:', queryParams);
                this.tableData = [
                    { partNumber: 'P001', partName: '部件 A', version: 'v1.0', status: '正常' },
                    { partNumber: 'P002', partName: '部件 B', version: 'v1.1', status: '异常' },
                    { partNumber: 'P004', partName: '部件 A', version: 'v1.0', status: '正常' },
                    { partNumber: 'P005', partName: '部件 B', version: 'v1.1', status: '异常' },
                    { partNumber: 'P006', partName: '部件 A', version: 'v1.0', status: '正常' },
                    { partNumber: 'P007', partName: '部件 B', version: 'v1.1', status: '异常' },
                    { partNumber: 'P008', partName: '部件 A', version: 'v1.0', status: '正常' },
                    { partNumber: 'P009', partName: '部件 B', version: 'v1.1', status: '异常' },
                    { partNumber: 'P0010', partName: '部件 A', version: 'v1.0', status: '正常' },
                    { partNumber: 'P011', partName: '部件 B', version: 'v1.1', status: '异常' },
                    { partNumber: 'P0012', partName: '部件 A', version: 'v1.0', status: '正常' },
                    { partNumber: 'P0013', partName: '部件 B', version: 'v1.1', status: '异常' },
                    { partNumber: 'P0014', partName: '部件 A', version: 'v1.0', status: '正常' },
                    { partNumber: 'P0015', partName: '部件 B', version: 'v1.1', status: '异常' },
                    { partNumber: 'P0016', partName: '部件 C', version: 'v2.0', status: '正常' }

                ];
            }
        }
    });

</script>

</html>



 