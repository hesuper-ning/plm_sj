<%@page import="ext.ptc.jsp.exportExcelReport.ExportExcelReport"%>
<%@page import="java.io.File"%>
<%@page import="java.util.Date"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.TimeZone"%>
<%@page import="wt.change2.WTChangeOrder2" %>
<%@page import="ext.ptc.jsp.exportExcelReport.ExportExcelReport" %>
<%
	response.setCharacterEncoding("UTF-8");
%>
<%@ page import="java.util.List,java.io.OutputStream"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
	String stroid = request.getParameter("oid");
	System.out.println(">>>>>>>>> stroid :"+stroid );
	WTChangeOrder2 ecn = ExportExcelReport.getECNByOid(stroid);

	String fileName = ecn.getNumber() + "_" + ecn.getName() + "_ECN" + ".xlsx";
	response.setContentType("application/msexcel");
	response.setHeader("Content-Disposition", "attachment;filename="
			+ java.net.URLEncoder.encode(fileName, "UTF-8"));
	response.setHeader("Cache-Control", "no-cache");
	OutputStream os = response.getOutputStream();
	ExportExcelReport.ExportECNReport(stroid, os);
	os.flush();
	os.close();
	out.clear();
	out = pageContext.pushBody();
%>