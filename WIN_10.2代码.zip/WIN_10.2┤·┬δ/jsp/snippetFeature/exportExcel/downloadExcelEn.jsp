<%@ page pageEncoding="UTF-8"%>
<%@ page errorPage="../../util/error.jsp"
%><%@ page import="com.ptc.netmarkets.util.beans.NmCommandBean"
%><%@ page import="com.ptc.netmarkets.model.NmOid"
%><%@ page import="com.ptc.netmarkets.model.NmObjectHelper"
%><%@ page import="com.ptc.netmarkets.model.NmObjectCommands"
%><%@ page import="wt.httpgw.EncodingConverter"
%><%@ page import="java.util.ResourceBundle"
%><%@ page import="java.util.Locale"
%><%@ page import="wt.util.WTMessage"
%><%@ include file="../../util/beginPopup.jspf"

%><%@ page import="com.ptc.core.components.beans.ObjectBean" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.List" %>
<%@ page import="ext.exportBom.downloadExcel.DownloadExcel" %>
<%@ page import="wt.part.WTPart" %>
<%@ page import="wt.fc.WTObject" %>
<%@ page import="ext.exportBom.processor.ExportBOMWizardEnProcessor" %>



<fieldset id="create_div" class="x-fieldset x-form-label-left" style="width: 600px; ">
    <legend class="x-fieldset-header x-unselectable">
        <span class="attributePanel-fieldset-title">颜色部件管理</span>
    </legend>
<div>
    请选择是否导出图片:<select name="image_export" id="image_export" >
        <option value="">请选择</option>
        <option>是</option>
        <option>否</option>
    </select>
</div>
</fieldset>

<%@ include file="../../util/endPopup.jspf"%>


