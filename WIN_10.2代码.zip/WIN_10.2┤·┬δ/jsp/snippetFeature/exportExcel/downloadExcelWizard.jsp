<%@page language="java" session="true" pageEncoding="UTF-8"%>
<%@ taglib prefix="jca" uri="http://www.ptc.com/windchill/taglib/components" %>
<%--<%@ include file="../../util/beginWizard.jspf"%>--%>
<%--<%@ include file="../../util/includeWizBean.jspf"%>--%>
<jca:wizard title="是否导出图片">
    <jca:wizardStep action="exportBOMWizard" type="export" />
</jca:wizard>
<%@ include file="../../util/end.jspf"%>