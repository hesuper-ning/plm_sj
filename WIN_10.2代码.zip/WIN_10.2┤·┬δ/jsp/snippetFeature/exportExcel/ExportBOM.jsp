<%@page import="ext.ptc.jsp.exportExcelReport.WTContants"%>
<%@page import="java.io.File"%>
<%@page import="cn.hutool.poi.excel.ExcelWriter"%>
<%@page import="ext.ptc.jsp.exportExcelReport.ExcelService"%>
<%@page import="ext.ptc.jsp.exportExcelReport.PartUtil"%>
<%@page import="java.util.Date"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.TimeZone"%>
<%@page import="org.json.JSONArray"%>
<%@page import="wt.change2.WTChangeOrder2" %>
<%@page import="ext.ptc.jsp.exportExcelReport.GetAttOrIBAService" %>
<%
	response.setCharacterEncoding("UTF-8");
%>
<%@ page import="java.util.List,java.io.OutputStream"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
	String stroid = request.getParameter("oid");
	System.out.println(">>>>>>>>> stroid :"+stroid );
	wt.part.WTPart part = PartUtil.getPartByOid(stroid);
	
	String fileName = 
			part.getNumber() + "_" + GetAttOrIBAService.getPartAttOrIBAByKey(part, "part_attribute.baselinemodel") +"_" + part.getName() + "_" + "V" + wt.vc.VersionControlHelper.getIterationDisplayIdentifier(part).toString() + "_BOM.xlsx";
	response.setContentType("application/msexcel");
	response.setHeader("Content-Disposition", "attachment;filename="
			+ java.net.URLEncoder.encode(fileName, "UTF-8"));
	response.setHeader("Cache-Control", "no-cache");
	OutputStream os = response.getOutputStream();
	File file2ReadConfig = new File(WTContants.EXPORTBOM2EXCELCONFIG);
	ExcelWriter writer = ExcelService.write2Excel(file2ReadConfig, part);
	writer.flush(os);

	os.flush();
	os.close();
	out.clear();
	out = pageContext.pushBody();
%>