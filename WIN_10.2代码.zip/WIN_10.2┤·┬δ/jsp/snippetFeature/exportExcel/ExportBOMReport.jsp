<%@page import="ext.ptc.jsp.exportExcelReport.WTContants"%>
<%@page import="java.io.File"%>
<%@page import="ext.ptc.jsp.exportExcelReport.ExcelService"%>
<%@page import="ext.ptc.jsp.exportExcelReport.PartUtil"%>
<%@page import="java.util.Date"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.TimeZone"%>
<%@page import="org.json.JSONArray"%>
<%@page import="wt.change2.WTChangeOrder2" %>
<%@page import="ext.ptc.jsp.exportExcelReport.GetAttOrIBAService" %>
<%@page import="ext.ptc.jsp.exportExcelReport.ExcelService"%>
<%@page import="ext.ptc.jsp.exportExcelReport.CommonUtil"%>
<%
	response.setCharacterEncoding("UTF-8");
%>
<%@ page import="java.util.List,java.io.OutputStream"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
	String stroid = request.getParameter("oid");
	System.out.println(">>>>>>>>> stroid :"+stroid );
	wt.part.WTPart part = PartUtil.getPartByOid(stroid);
	
	String fileName = 
			part.getNumber() + "_BOM_"+ CommonUtil.getTimeString() +".xlsx";
	response.setContentType("application/msexcel");
	response.setHeader("Content-Disposition", "attachment;filename="
			+ java.net.URLEncoder.encode(fileName, "UTF-8"));
	response.setHeader("Cache-Control", "no-cache");
	OutputStream os = response.getOutputStream();
	ExcelService.write2Excel(os, part);

	os.flush();
	os.close();
	out.clear();
	out = pageContext.pushBody();
%>