<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
</head>
<body>
<h1>Hello:aaa</h1>
<div>
    请选择是否导出图片：<select name="image_export" id="image_export" style="width: 100%;height: 85%">
        <option value="">请选择</option>
        <option>是</option>
        <option>否</option>
    </select>
</div>
</body>
</html>