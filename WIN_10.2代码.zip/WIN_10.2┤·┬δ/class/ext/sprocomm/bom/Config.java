package ext.sprocomm.bom;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import wt.util.WTProperties;

public final class Config {


	/**
	 * 加载配置文件config.properties,修改配置config.properties不需要重启
	 */
	private static Properties CONFIG = new Properties();

	private static String iba_config_file_path = "";
	private static long iba_config_file_modified = 0;

	/**
	 * 初始化时加载配置文件，同时记录文件的最后修改时间，用于判断是否被修改过
	 */
	static {
		try {
			WTProperties wtprop = WTProperties.getLocalProperties();
			String codebaseLocation = wtprop.getProperty("wt.codebase.location");
			iba_config_file_path = codebaseLocation+File.separator+"ext"+File.separator+"sprocomm"+File.separator+"bom"+File.separator+"config.properties";
			reloadConfig();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 根据配置文件最后修改时间判断是否重新加载配置
	 */
	private static void reloadConfig(){
		try {
			File configFile = new File(iba_config_file_path);
			if(!configFile.exists()){
				System.out.println(" No iba-config.properties found.");
			}else {
				long lastModified = configFile.lastModified();
				if(lastModified != iba_config_file_modified){
					CONFIG.load(new FileInputStream(configFile));
					iba_config_file_modified = configFile.lastModified();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 对外提供接口获取配置信息
	 * @return
	 */
	public static Properties getConfig(){
		reloadConfig();
		return CONFIG;
	}
	
	/**
	 * 获取配置，以逗号隔开
	 * @return
	 */
	public static String getEndItemPreNumberStringConfig(){
		String property = getConfig().getProperty("bom.pre.number");
		return property;
	}
	/**
	 * 获取配置，以字符串数组返回
	 * @return
	 */
	public static String[] getEndItemPreNumberArrayConfig(){
		String property = getEndItemPreNumberStringConfig();
		if(property == null){
			property="";
		}
		return property.split(",");
	}
}
