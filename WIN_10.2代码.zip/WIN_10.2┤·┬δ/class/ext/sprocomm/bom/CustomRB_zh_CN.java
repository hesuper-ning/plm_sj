package ext.sprocomm.bom;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * 资源文件
 * 
 * @author lxm
 * @date 2021-10-28
 */
@RBUUID( "ext.sprocomm.bom.CustomRB" )
public class CustomRB_zh_CN extends WTListResourceBundle
{
	
	@RBEntry("BOM导出")
	public static final String PRIVATE_CONSTANT_10 = "sprocomm.exportBOM.description";

	@RBEntry("BOM导出")
	public static final String PRIVATE_CONSTANT_11 = "sprocomm.exportBOM.title";

	@RBEntry("BOM导出")
	public static final String PRIVATE_CONSTANT_12 = "sprocomm.exportBOM.tooltip";

	@RBEntry("StructureNode.gif")
	@RBPseudo(false)
	public static final String PRIVATE_CONSTANT_13 = "sprocomm.exportBOM.icon";

	@RBEntry("height=650,width=750")
	@RBPseudo(false)
	public static final String PRIVATE_CONSTANT_14 = "sprocomm.exportBOM.moreurlinfo";
	

}