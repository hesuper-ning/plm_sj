package ext.sprocomm.bom;

import java.io.InputStream;


public class ExcelTemplate {
	public static final String BOM_03 = "ExportBOM_03.xls";
	public static final String BOM_NOT_03 = "ExportBOM_NOT_03.xls";
	public static InputStream getExcelTempate(String name) {
		 InputStream is = ExcelTemplate.class.getResourceAsStream(name);
		return is;
	}
}
