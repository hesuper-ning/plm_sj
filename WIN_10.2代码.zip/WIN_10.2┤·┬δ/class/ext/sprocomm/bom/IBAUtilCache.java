
package ext.sprocomm.bom;

import java.util.Hashtable;


import wt.iba.definition.DefinitionLoader;
import wt.iba.definition.litedefinition.AbstractAttributeDefinizerView;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.AttributeDefNodeView;
import wt.iba.definition.litedefinition.UnitDefView;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.log4j.LogR;
import wt.units.service.MeasurementSystemCache;
import wt.units.service.QuantityOfMeasureDefaultView;
import org.apache.log4j.Logger;


public class IBAUtilCache
{
    String measurementSystem = "SI";
    Hashtable definitionCache;
    Hashtable defaultUnitCache;
    private static final Logger logger = LogR.getLogger(IBAUtilCache.class.getName());
    public IBAUtilCache()
    {
        definitionCache = new Hashtable();
        defaultUnitCache = new Hashtable();
    }

    public AttributeDefDefaultView getCachedAttributeDefinition(String s)
    {
    	AttributeDefDefaultView attributedefdefaultview = null;
    	attributedefdefaultview=(AttributeDefDefaultView)definitionCache.get(s);
    	if(attributedefdefaultview != null)
    		return attributedefdefaultview;
    	else{
    		attributedefdefaultview=getAttributeDefinition(s);
    		definitionCache.put(s,attributedefdefaultview);
    		return attributedefdefaultview;
    	}
    	
    }
    
    public String getCachedDefaultUnit(String s)
    {
    	  if (s == null)
      	    return "";
    	
    	  String defaultUnit = (String)defaultUnitCache.get(s);
    	  if (defaultUnit != null)
    	      return defaultUnit;
    	
    	  AttributeDefDefaultView attributedefdefaultview = getCachedAttributeDefinition(s);
    	  if (attributedefdefaultview instanceof UnitDefView)
    	      defaultUnit = getDefaultUnit((UnitDefView)attributedefdefaultview);
    	  if (defaultUnit == null)
    	      defaultUnit = "";
    	      
    	  defaultUnitCache.put(s, defaultUnit);
    	  
    	  return defaultUnit;
    }
    
    private String getDefaultUnit(UnitDefView definition)
    {
        if(measurementSystem == null)
            measurementSystem = MeasurementSystemCache.getCurrentMeasurementSystem();
        
        QuantityOfMeasureDefaultView quantityofmeasuredefaultview = definition.getQuantityOfMeasureDefaultView();
        String defaultUnit = quantityofmeasuredefaultview.getBaseUnit();
        if(measurementSystem != null)
        {
            String s = definition.getDisplayUnitString(measurementSystem);
            if(s == null)
                s = quantityofmeasuredefaultview.getDisplayUnitString(measurementSystem);
            if(s == null)
                s = quantityofmeasuredefaultview.getDefaultDisplayUnitString(measurementSystem);
            if(s != null)
                defaultUnit = s;
        }
        if(defaultUnit == null)
            defaultUnit = "";
        
        return defaultUnit;
    }
    
    private AttributeDefDefaultView getAttributeDefinition(String s)
    {
        AttributeDefDefaultView attributedefdefaultview = null;
        try
        {
            attributedefdefaultview = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(s);
            if(attributedefdefaultview == null)
            {
                AbstractAttributeDefinizerView abstractattributedefinizerview = DefinitionLoader.getAttributeDefinition(s);
                if(abstractattributedefinizerview != null)
                    attributedefdefaultview = IBADefinitionHelper.service.getAttributeDefDefaultView((AttributeDefNodeView)abstractattributedefinizerview);
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        return attributedefdefaultview;
    }

    static 
    {

    }

}
