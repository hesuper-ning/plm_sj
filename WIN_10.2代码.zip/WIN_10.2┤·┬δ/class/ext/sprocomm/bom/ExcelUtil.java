package ext.sprocomm.bom;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import wt.util.WTException;

public class ExcelUtil {
	
	private static final int MAX_ROW_COUNT = 9999;
	private static final int MAX_CELL_COUNT = 6;
	
	public static List<Object[]> retrivaleDataFromExcel(HSSFWorkbook workbook ,int sheetIndex,int startRowIndex) throws WTException{
		if(workbook == null || sheetIndex < 0){
			throw new WTException("Excel template error.");
		}
		HSSFSheet sheet = workbook.getSheetAt(sheetIndex);
    	if(null == sheet){
			throw new WTException("No sheet at "+sheetIndex+".");
		}
    	List<Object[]> data = new ArrayList<Object[]>();
    	int rowIndex = startRowIndex;
    	while(rowIndex < MAX_ROW_COUNT){
    		HSSFRow row = sheet.getRow(rowIndex++);
    		if(row == null || row.getCell(0) == null || StringUtils.isBlank(row.getCell(0).toString())){
    			break;
    		}
    		Object[] rowData = new Object[MAX_CELL_COUNT];
    		for (int i = 0; i < rowData.length; i++) {
				HSSFCell cell = row.getCell(i);
				if(cell == null || StringUtils.isBlank(cell.toString())){
					rowData[i] = "";
				}else if(cell.getCellType() != HSSFCell.CELL_TYPE_STRING && cell.getCellType() != HSSFCell.CELL_TYPE_NUMERIC){
					throw new WTException("Excel template data error from cell["+startRowIndex+","+i+"]");
				}else if(cell.getCellType() == HSSFCell.CELL_TYPE_STRING){
					rowData[i] = cell.getStringCellValue();
				}else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
					rowData[i] = new Double(cell.getNumericCellValue()).longValue();
				}
			}
    		data.add(rowData);
    	}
    	
		
		
		return data;
	}
	
	public static List<Object[]> retrivaleDataFromExcel(XSSFWorkbook workbook ,int sheetIndex,int startRowIndex,int cellCount) throws WTException{
		List<Object[]> data = new ArrayList<Object[]>();
		if(workbook == null || sheetIndex < 0){
			return data;
		}
		XSSFSheet sheet = workbook.getSheetAt(sheetIndex);
    	if(null == sheet){
    		return data;
		}
    	int rowIndex = startRowIndex;
    	while(rowIndex < MAX_ROW_COUNT){
    		XSSFRow row = sheet.getRow(rowIndex++);
    		if(row == null ||row.getCell(0) == null|| StringUtils.isBlank(row.getCell(0).getStringCellValue())){
    			break;
    		}
    		Object[] rowData = new Object[cellCount];
    		for (int i = 0; i < rowData.length; i++) {
				XSSFCell cell = row.getCell(i);
				if(cell == null || StringUtils.isBlank(cell.toString())){
					rowData[i] = "";
				}else if(cell.getCellType() != HSSFCell.CELL_TYPE_STRING && cell.getCellType() != HSSFCell.CELL_TYPE_NUMERIC){
					throw new WTException("Excel template data error from cell["+startRowIndex+","+i+"]");
				}else if(cell.getCellType() == HSSFCell.CELL_TYPE_STRING){
					rowData[i] = cell.getStringCellValue();
				}else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
					rowData[i] = String.valueOf(cell.getNumericCellValue());
				}
			}
    		data.add(rowData);
    	}
    	
		
		
		return data;
	}
	
	/**
	 * 从文件流中获取workbook
	 * @param filePath
	 * @return HSSFWorkbook
	 * @throws WTException 
	 */
	public static XSSFWorkbook getWorkBookTemplate(InputStream inputStream) throws WTException {
		if(null == inputStream){
			throw new WTException("No template found.");
		}
		try {
			// 创建一个工作薄
			XSSFWorkbook wb = new XSSFWorkbook(inputStream);
			return wb;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 从文件流中获取workbook
	 * @param filePath
	 * @return HSSFWorkbook
	 * @throws WTException 
	 */
	public static HSSFWorkbook getXlsWorkBookTemplate(InputStream inputStream) throws WTException {
		if(null == inputStream){
			throw new WTException("No template found.");
		}
		try {
			// 创建一个工作薄
			HSSFWorkbook wb = new HSSFWorkbook(inputStream);
			return wb;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 从服务器文件系统中加载模板文件
	 * @param filePath
	 * @return HSSFWorkbook
	 * @throws WTException 
	 */
	public static HSSFWorkbook getWorkBookTemplate(String filePath) throws WTException {
		if(StringUtils.isBlank(filePath)){
			throw new WTException("No template found.");
		}
		try {
			// 加载excel导出模版
			FileInputStream fis = new FileInputStream(filePath);
			POIFSFileSystem poif = new POIFSFileSystem(fis);
			// 创建一个工作薄
			HSSFWorkbook wb = new HSSFWorkbook(poif);
			return wb;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new WTException("File <"+filePath+"> is not found.");
		} catch (IOException e) {
			e.printStackTrace();
			throw new WTException("File <"+filePath+"> is not valid.");
		}
	}
	
	/**
	 * 导出数据到指定excel文本簿中，然后输出文件流
	 * @param workbook 文本簿对象，从模板中获得
	 * @param sheetIndex 文本簿中sheet的位置，从0开始计算
	 * @param startRowIndex 标识sheet中从第几行开始填充数据，从0开始计算
	 * @param startColumIndex 标识sheet中从第几列开始填数据，从0开始计算
	 * @param data 待填充的数据，对象为Object[]，代表一行，严格按顺序填充
	 * @param outputStream 填充完数据后输出的文件流
	 * @throws WTException 
	 */
	@SuppressWarnings("deprecation")
	public static void exportToOutputSteam(HSSFWorkbook workbook,int sheetIndex,short startRowIndex,short startColumIndex,List<Object[]> data, OutputStream outputStream) throws WTException{
		if(null == workbook){
			throw new WTException("No workbook.");
		}
		if(sheetIndex < 0 || startRowIndex < 0 || startColumIndex < 0){
			throw new WTException("Out of index.");
		}
		//获取sheet
    	HSSFSheet sheet = workbook.getSheetAt(sheetIndex);
    	if(null == sheet){
			throw new WTException("No sheet at "+sheetIndex+".");
		}
    	HSSFRow row = null ;
    	HSSFCell cell = null ;
    	//使用模板的style
    	HSSFCellStyle style = null;
    	HSSFCellStyle endStyle = null;
    	short rowIndex = startRowIndex;
    	HSSFRow styleRow = sheet.getRow(startRowIndex);
    	if(styleRow != null){
    		HSSFCell styleCell = styleRow.getCell(startColumIndex);
    		if(styleCell != null){
    			HSSFCellStyle cellStyle = styleCell.getCellStyle();
    			style = cellStyle;
    		}
    		HSSFCell styleCell2 = styleRow.getCell(startColumIndex-(short)1);
    		if(styleCell2 != null){
    			HSSFCellStyle cellStyle2 = styleCell2.getCellStyle();
    			endStyle = cellStyle2;
    			
    			endStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
    			endStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    			endStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
    			
    		}
    	}
    	if(endStyle == null){
    		endStyle = style;
    	}
    	int size = data.size();
    	for(Object[] rowData : data){
    		size--;
    		//最后一行底框线加粗
    		if(size == 0){
    			style = endStyle;
    		}
    		//System.out.println(size+"="+style.getBorderBottom());
    		//创建行
    		row = sheet.createRow(rowIndex++);
    		short cellIndex = startColumIndex;
    		for (int i = startColumIndex-1; i >= 0; i--) {
    			cell = row.createCell(i); 
    			cell.setCellStyle(style);
			}
    		//逐列填充
    		for (Object object : rowData) {
    			cell = row.createCell(cellIndex++); 
    			cell.setCellStyle(style);
    			if(object == null){
    				continue;
    			}
    			
    			if(object instanceof String){
					cell.setCellValue((String)object);
				}else if(object instanceof Integer){
					cell.setCellValue((Integer)object);
				}else if(object instanceof Long){
					cell.setCellValue((Long)object);
				}else if(object instanceof Double){
					cell.setCellValue((Double)object);
				}else {
					cell.setCellValue(object.toString());
				}
			}
    	}
    	try {
			workbook.write(outputStream);
		} catch (IOException e) {
			e.printStackTrace();
			throw new WTException("Workbook writes outputsteam error.");
		}
	}
	
	/**
	 * 导出数据到指定excel文本簿中，然后输出文件流
	 * @param workbook 文本簿对象，从模板中获得
	 * @param sheetIndex 文本簿中sheet的位置，从0开始计算
	 * @param startRowIndex 标识sheet中从第几行开始填充数据，从0开始计算
	 * @param startColumIndex 标识sheet中从第几列开始填数据，从0开始计算
	 * @param data 待填充的数据，对象为Object[]，代表一行，严格按顺序填充
	 * @throws WTException 
	 */
	@SuppressWarnings("deprecation")
	public static void exportToExcel(HSSFWorkbook workbook,int sheetIndex,short startRowIndex,short startColumIndex,List<Object[]> data) throws WTException{
		if(null == workbook){
			throw new WTException("No workbook.");
		}
		if(sheetIndex < 0 || startRowIndex < 0 || startColumIndex < 0){
			throw new WTException("Out of index.");
		}
		//获取sheet
    	HSSFSheet sheet = workbook.getSheetAt(sheetIndex);
    	if(null == sheet){
			throw new WTException("No sheet at "+sheetIndex+".");
		}
    	HSSFRow row = null ;
    	HSSFCell cell = null ;
    	//使用模板的style
    	HSSFCellStyle style = null;
    	HSSFCellStyle endStyle = null;
    	short rowIndex = startRowIndex;
    	HSSFRow styleRow = sheet.getRow(startRowIndex);
    	if(styleRow != null){
    		HSSFCell styleCell = styleRow.getCell(startColumIndex);
    		if(styleCell != null){
    			HSSFCellStyle cellStyle = styleCell.getCellStyle();
    			style = cellStyle;
    		}
    		HSSFCell styleCell2 = styleRow.getCell(startColumIndex-(short)1);
    		if(styleCell2 != null){
    			HSSFCellStyle cellStyle2 = styleCell2.getCellStyle();
    			endStyle = cellStyle2;
    			
    			endStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
    			endStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    			endStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
    			
    		}
    	}
    	if(endStyle == null){
    		endStyle = style;
    	}
    	int size = data.size();
    	for(Object[] rowData : data){
    		size--;
    		//最后一行底框线加粗
    		if(size == 0){
    			style = endStyle;
    		}
    		//System.out.println(size+"="+style.getBorderBottom());
    		//创建行
    		if(rowIndex == 0){
    			row = styleRow;
    		}else {
    			row = sheet.createRow(rowIndex++);
    			for (int i = startColumIndex-1; i >= 0; i--) {
        			cell = row.createCell(i); 
        			if(style != null){
        				cell.setCellStyle(style);
        			}
    			}
    		}
    		short cellIndex = startColumIndex;
    		
    		//逐列填充
    		for (Object object : rowData) {
    			cell = row.createCell(cellIndex++); 
    			if(style != null){
    				cell.setCellStyle(style);
    			}
    			if(object == null){
    				continue;
    			}
    			
    			if(object instanceof String){
					cell.setCellValue((String)object);
				}else if(object instanceof Integer){
					cell.setCellValue((Integer)object);
				}else if(object instanceof Long){
					cell.setCellValue((Long)object);
				}else if(object instanceof Double){
					cell.setCellValue((Double)object);
				}else {
					cell.setCellValue(object.toString());
				}
			}
    	}
	}
	
	/**
	 * 导出数据到指定excel文本簿中，然后输出文件流
	 * @param workbook 文本簿对象，从模板中获得
	 * @param sheetIndex 文本簿中sheet的位置，从0开始计算
	 * @param startRowIndex 标识sheet中从第几行开始填充数据，从0开始计算
	 * @param startColumIndex 标识sheet中从第几列开始填数据，从0开始计算
	 * @param data 待填充的数据，对象为Object[]，代表一行，严格按顺序填充
	 * @param outputStream 填充完数据后输出的文件流
	 * @throws WTException 
	 */
	@SuppressWarnings("deprecation")
	public static void exportToOutputSteam(XSSFWorkbook workbook,int sheetIndex,short startRowIndex,short startColumIndex,List<String[]> data, OutputStream outputStream) throws WTException{
		if(null == workbook){
			throw new WTException("No workbook.");
		}
		if(sheetIndex < 0 || startRowIndex < 0 || startColumIndex < 0){
			throw new WTException("Out of index.");
		}
		//获取sheet
    	XSSFSheet sheet = workbook.getSheetAt(sheetIndex);
    	if(null == sheet){
			throw new WTException("No sheet at "+sheetIndex+".");
		}
    	if(null == data || data.size() ==0 ){
    		throw new WTException("No data.");
    	}
    	XSSFRow row = null ;
    	XSSFCell cell = null ;
    	int length = data.get(0).length;
    	//使用模板的style
    	XSSFCellStyle[] style = new XSSFCellStyle[data.get(0).length];
    	short rowIndex = startRowIndex;
    	XSSFRow styleRow = sheet.getRow(startRowIndex);
    	if(styleRow != null){
    		for(int i = 0 ; i < length ; i++){
    			XSSFCell styleCell = styleRow.getCell(startColumIndex+i);
	    		if(styleCell != null){
	    			XSSFCellStyle cellStyle = styleCell.getCellStyle();
	    			style[i] = cellStyle;
	    		}
    		}
    		/*XSSFCell styleCell2 = styleRow.getCell(startColumIndex);
    		if(styleCell2 != null){
    			XSSFCellStyle cellStyle2 = styleCell2.getCellStyle();
    			endStyle = cellStyle2;
    			
    			endStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
    			endStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    			endStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
    			System.out.println(endStyle+"="+endStyle.getBorderBottom());
    			
    		}*/
    	}
    	int size = data.size();
    	for(Object[] rowData : data){
    		size--;
    		//最后一行底框线加粗
    		/*if(size == 0){
    			style = endStyle;
    		}*/
    		//System.out.println(size+"="+style.getBorderBottom());
    		//创建行
    		row = sheet.createRow(rowIndex++);	
    		short cellIndex = startColumIndex;
    		/*for (int i = startColumIndex-1; i >= 0; i--) {
    			cell = row.createCell(i); 
    			cell.setCellStyle(style);
			}*/
    		//逐列填充
    		int styleIndex = 0;
    		for (Object object : rowData) {
    			cell = row.createCell(cellIndex++); 
    			cell.setCellStyle(style[styleIndex++]);
    			if(object == null){
    				continue;
    			}
    			
    			if(object instanceof String){
					cell.setCellValue((String)object);
				}else if(object instanceof Integer){
					cell.setCellValue((Integer)object);
				}else if(object instanceof Long){
					cell.setCellValue((Long)object);
				}else if(object instanceof Double){
					cell.setCellValue((Double)object);
				}else {
					cell.setCellValue(object.toString());
				}
			}
    	}
//    	sheet.removeRow(sheet.getRow(startRowIndex-1));
    	XSSFSheet sheetAt = workbook.getSheetAt(sheetIndex+1);
    	row = sheet.createRow(rowIndex++);
    	XSSFCell createCell = row.createCell(0);
    	createCell.setCellValue("");
    	for(int i = 0 ; i < 4 ; i++){
	    	row = sheet.createRow(rowIndex++);
	    	XSSFCell cell2 = sheetAt.getRow(i).getCell(0);
	    	createCell = row.createCell(startColumIndex);
	    	createCell.setCellValue(cell2.getStringCellValue());
    	}
    	try {
			workbook.write(outputStream);
			
		} catch (IOException e) {
			e.printStackTrace();
			throw new WTException("Workbook writes outputsteam error.");
		}finally{
			try {
				outputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    	
    	
	}
	public static void main(String[] args) throws WTException, FileNotFoundException{
		String filePath = "D:/Dev/workspace/MMPPProject/bin/net/haige/mm/SAP_MM.xls";
		HSSFWorkbook workbook = getWorkBookTemplate(filePath);
		FileOutputStream outputStream = new FileOutputStream("D:/text.xls");
		List<Object[]> data = new ArrayList<Object[]>();
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		data.add(new Object[]{"test","test"});
		exportToOutputSteam(workbook, 0, (short)4, (short)1, data, outputStream);
		System.out.println("done");
	}
	
	
	/***
	 * 得到row行的cellNum列，如果不存在就createCell，存在就getCell
	 * @param row 当前row行
	 * @param cellNum 列号
	 * @param style 样式
	 * @return HSSFCell
	 */
	public static HSSFCell getCell(HSSFRow row,int cellNum,HSSFCellStyle style){
		HSSFCell cell = row.getCell((short)cellNum);
		if(cell == null){
			cell = row.createCell((short)cellNum);
		}
		if(style != null){
			cell.setCellStyle(style);
		}
		return cell;
	}
	
	/***
	 * 得到sheet页rownum的行，如果不存在就createRow，存在就getRow
	 * @param sheet 当前sheet页
	 * @param rownum 行号
	 * @return HSSFRow
	 */
	public static HSSFRow getRow(HSSFSheet sheet,int rownum){
		HSSFRow row = sheet.getRow(rownum);
		if(row == null){
			row = sheet.createRow(rownum);
		}else{
			row = sheet.getRow(rownum);
		}
		return row;
	}
	
	/**
	 * 
	 * @param workBookTemplate
	 * @param map
	 */
	public static void exportMapToWorkBook(XSSFWorkbook workBookTemplate,Map<String, String> map) {
		XSSFSheet sheet = workBookTemplate.getSheetAt(0);
		Set<String> keySet = map.keySet();
		Iterator<String> iterator = keySet.iterator();
		while (iterator.hasNext()) {
			String key = (String) iterator.next();
			String[] split = StringUtils.split(key,";");
			int rowIndex = Integer.valueOf(split[0]);
			int columnIndex = Integer.valueOf(split[1]);
			XSSFRow row = sheet.getRow(rowIndex);
			XSSFCell cell = row.getCell(columnIndex);
			cell.setCellValue(map.get(key));
		}
	}
	
	public static void retrivaleRowFromExcel(XSSFWorkbook wb,Map<String, String> map) {
		// TODO Auto-generated method stub
		XSSFSheet sheet = wb.getSheetAt(0);
		Set<String> keySet = map.keySet();
		Iterator<String> iterator = keySet.iterator();
		while (iterator.hasNext()) {
			String key = (String) iterator.next();
			String[] split = StringUtils.split(key,";");
			int rowIndex = Integer.valueOf(split[0]);
			int columnIndex = Integer.valueOf(split[1]);
			XSSFRow row = sheet.getRow(rowIndex);
			XSSFCell cell = row.getCell(columnIndex);
			if(cell == null || StringUtils.isBlank(cell.toString())){
				continue;
			}else if(cell.getCellType() == XSSFCell.CELL_TYPE_STRING){
				String stringCellValue = cell.getStringCellValue();
				map.put(key, stringCellValue);
			}else if(cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC){
				map.put(key, String.valueOf(cell.getNumericCellValue()));
			}
		}
	}
}
