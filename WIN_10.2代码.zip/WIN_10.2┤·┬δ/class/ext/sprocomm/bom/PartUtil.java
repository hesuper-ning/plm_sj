package ext.sprocomm.bom;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import wt.csm.navigation.ClassificationNode;
import wt.epm.EPMAuthoringAppType;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentType;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.iba.value.ReferenceValue;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

/**
 * 通用接口，根据配置文件获取WTPart的固定属性和分类属性
 * @author samuel
 *
 */
public class PartUtil {
	
	private static EPMDocumentType         CADCOMPONENT            = EPMDocumentType.toEPMDocumentType( "CADCOMPONENT" ); // 

    private static EPMDocumentType         CADASSEMBLY             = EPMDocumentType.toEPMDocumentType( "CADASSEMBLY" ); // 

    private static EPMAuthoringAppType     NX                    = EPMAuthoringAppType.toEPMAuthoringAppType( "UG" ); //
	
    
    /**
	 * 获取当前WTPart的分类属性，分类的iba属性
	 * @param part
	 */
	public static Object[] getClsFullpath(WTPart part){
		Object[] result = new Object[3];
		String clsFullPath = "";
		try {
			QuerySpec queryspec = new QuerySpec(ReferenceValue.class);
			queryspec.appendWhere(new SearchCondition(ReferenceValue.class,
					"theIBAHolderReference.key", "=", part.getPersistInfo().getObjectIdentifier()),
					new int[] {});
			QueryResult qr = PersistenceHelper.manager.find(queryspec);
			ClassificationNode localClassificationNode = null;
			while (qr.hasMoreElements()) {
				ReferenceValue rv = (ReferenceValue) qr.nextElement();
				if(rv.getIBAReferenceableReference() != null &&
						rv.getIBAReferenceableReference().getObject() instanceof ClassificationNode ){
					localClassificationNode = (ClassificationNode) rv.getIBAReferenceableReference().getObject();
					break;
				}
			}
			//for test
//			localClassificationNode = new ClassificationNode();
			if(localClassificationNode != null){
				result[0] = localClassificationNode.getName();
				//获取所有属性
				List<String[]> allIbaKeysFromClassification = getAllIbaKeysFromClassification(localClassificationNode);
				
				clsFullPath = localClassificationNode.getName();
				while(localClassificationNode.getParent() != null){
					ClassificationNode parent = localClassificationNode.getParent();
					clsFullPath = parent.getName() + "/"+clsFullPath;
					localClassificationNode = parent;
				}
				//for test
//				clsFullPath = String.valueOf(new Random().nextInt(10));
				result[1] = clsFullPath;
				result[2] = allIbaKeysFromClassification;
			}
		} catch (QueryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 获取分类的所有iba属性列表，返回iba key和显示名称
	 * @param cls
	 * @return
	 * @throws WTException
	 */
	private static List<String[]> getAllIbaKeysFromClassification(ClassificationNode cls) throws WTException{
		
		List<String[]> result = new ArrayList<String[]>();
		
		IBAUtil iba = new IBAUtil(cls);
		
		Set keySet = iba.ibaContainer.keySet();
		for(Object key : keySet){
			result.add(new String[]{(String)key,(String)key});
		}
		/*ArrayList<AttributeDefinitionReadView> typeAttributes = LWCCommands.getTypeAttributes("OR:"+cls.getPersistInfo().getObjectIdentifier().toString());
		if(typeAttributes != null){
			for (AttributeDefinitionReadView attributeDefinitionReadView2 : typeAttributes) {
				String key = attributeDefinitionReadView2.getName();
				String displayName = attributeDefinitionReadView2.getName();
				key = "key"+String.valueOf(new Random().nextInt(10));
				displayName = "displayName"+String.valueOf(new Random().nextInt(10));
				result.add(new String[]{key,displayName});
			}
		}*/
		return result;
	}
    
	/**
	 * 获取当前WTPart的分类属性
	 * @param part
	 */
	public static String getPartCls(WTPart part){
		IBAUtil iba = new IBAUtil(part);
//		Properties ibaConfig = Constants.getIBAConfig();
		//分类属性
//		String cls = ibaConfig.getProperty("classification.id");
		String clsKey = iba.getIBAValue("Part");
		return clsKey;
	}
	/**
     * 部件与CAD文档， 说明关系 通过部件获取CAD文档
     * @param part
     * @throws Exception
     */
    public static EPMDocument getNXCADByPart( WTPart part ) throws Exception
    {
        QueryResult qr = null;
        EPMDocument doc = null;
        try
        {
            qr = WTPartHelper.service.getDescribedByDocuments( part );// CAD文档
            while( qr.hasMoreElements() )
            {
                Object obj = qr.nextElement();
                if( obj instanceof EPMDocument )
                {
                    doc = ( EPMDocument ) obj;
                    EPMDocumentType docType = doc.getDocType();
                    EPMAuthoringAppType appType = doc.getAuthoringApplication();
                    if( ( CADCOMPONENT.equals( docType ) || CADASSEMBLY.equals( docType ) )// 零件或装配
                            && NX.equals( appType ) )
                    {
                        return doc;
                    }
                }
            }

        } catch( WTException e )
        {
            e.printStackTrace();
            throw new Exception( "No 3D CAD Document on Part :" + part.getName() );
        }
        return null;
    }
    
    /**
	 * 查找特定替代料
	 * 
	 * @param useagelink
	 * @return List<WTPartMaster>
	 * @throws WTException
	 */
	public static List<WTPartMaster> getSubstituteParts(WTPartUsageLink useagelink)
			throws WTException {
		List<WTPartMaster> list = new ArrayList<WTPartMaster>();
		if (useagelink == null) {
			return list;
		}
		QueryResult qr = WTPartHelper.service.getSubstitutesWTPartMasters(useagelink);
		while (qr.hasMoreElements()) {
			WTPartMaster master = (WTPartMaster)qr.nextElement();
			list.add(master);
		}
		return list;
	}
	
	/**
	 * 查找主料的全局替代料
	 * @param wtpart
	 * @return
	 * @throws WTException
	 */
	public static List<WTPartMaster> getWTPartAlternateLinks(WTPartMaster wtpartMaster) throws WTException{
		List<WTPartMaster> list = new ArrayList<WTPartMaster>();
		if (wtpartMaster == null) {
			return list;
		}
		QueryResult qr = WTPartHelper.service.getAlternatesWTPartMasters(wtpartMaster);
		while (qr.hasMoreElements()) {
			WTPartMaster sLink = (WTPartMaster) qr.nextElement();
			list.add(sLink);
		}
		return list;
	}
	
	/**
	 * 根据part得到其子部件
	 */
	public static List<WTPart> getBomByPart(WTPart rootPart) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		List<WTPart> list = new ArrayList<WTPart>();
		try {
			QueryResult qr = WTPartHelper.service
					.getUsesWTPartMasters(rootPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink
						.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					list.add(sPart);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}
	/**
	 * 根据part得到其所有子部件
	 */
	public static void getAllBomByPart(WTPart ProductPart,List<WTPart> list) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service
					.getUsesWTPartMasters(ProductPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					list.add(sPart);
					getAllBomByPart(sPart, list);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
	}
}
