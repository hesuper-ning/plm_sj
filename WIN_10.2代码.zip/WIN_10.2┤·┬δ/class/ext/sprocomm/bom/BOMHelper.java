package ext.sprocomm.bom;

import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.org.WTPrincipal;
import wt.part.PartUsesOccurrence;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

public class BOMHelper {
	/**
	 * 导出的BOM
	 * 
	 * @param part
	 *            
	 * @param outputStream
	 *            导出excel表
	 * @throws Exception
	 */
	public static void exportBOMFromPart(WTPart part,OutputStream outputStream) throws Exception {
		String preNumber = Config.getConfig().getProperty("pcba.part.pre.number","03.");
		System.out.println("002-ExportBOM-config.pcba.part.pre.number:"+preNumber);
		WTPrincipal currPrincipal = null;
		try {
			currPrincipal = SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			int level = 1;
			//默认只有一个sheet表格
			
			System.out.println("002-ExportBOM-Get-BOM-By-Item:"+part.getNumber()+","+part.getName());
			List<Object[]> newBOMList = new ArrayList<Object[]>();
			InputStream inputStream = null ;
			IBAUtil partIba = new IBAUtil(part);
			if(StringUtils.startsWithIgnoreCase(part.getNumber(), preNumber)){
				//PCBA根节点数据，特殊处理
				String[] data = new String[12];
				int index = 0;
				data[index++] = "";//层级Level_CJ
				data[index++] = "";//行号
				data[index++] = "";//数量
				data[index++] = "";//工位MachinePos
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.Factory","Factory"));//厂家Factory
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.SpecificationsModel","SpecificationsModel"));//规格型号SpecificationsModel
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc","ItemDesc"));//物料描述ItemDesc
				data[index++] = part.getNumber();//编号
				data[index++] = "";// 是否客供物料IsBuyCust
				data[index++] = part.getName();//名称
				data[index++] = "";//物料行备注ItemNote
				data[index++] = "";// 是否替代料
				newBOMList.add(data);
				//递归获取PCBA下所有子件
				getAllBomByPartInPCBA(part, newBOMList, level,preNumber);
				inputStream = ExcelTemplate.getExcelTempate(ExcelTemplate.BOM_03);
			}else {
				//整机根节点数据，特殊处理
				String[] data = new String[11];
				int index = 0;
				data[index++] = "";//层级Level_CJ
				data[index++] = "";//行号
				data[index++] = part.getNumber();//编号
				data[index++] = part.getName();//名称
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc","ItemDesc"));//物料描述ItemDesc
				data[index++] = "";//物料行备注ItemNote
				data[index++] = "";// 数量
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.supply","supply"));// 供应商supply
				data[index++] = "";// 是否客供物料IsBuyCust
				data[index++] = "";// 是否售后物料IsCoustomerService
				data[index++] = "否";// 是否替代料
				newBOMList.add(data);
				//递归获取整机下所有子件，当遇到PCBA时，不再往下获取子件
				getAllBomByPartNoPCBA(part, newBOMList, level,preNumber);
				inputStream = ExcelTemplate.getExcelTempate(ExcelTemplate.BOM_NOT_03);
			}
			
			//输出excel文件
			HSSFWorkbook workBookTemplate = ExcelUtil.getXlsWorkBookTemplate(inputStream);
			ExcelUtil.exportToExcel(workBookTemplate, 0, (short) 1,	(short) 0, newBOMList);
			workBookTemplate.write(outputStream);
			System.out.println("002-ExportBOM-Export to sheet done.");
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e.getLocalizedMessage());
		} finally {
			if (currPrincipal != null) {
				try {
					SessionHelper.manager.setPrincipal(currPrincipal.getName());
				} catch (WTException e) {
					e.printStackTrace();
				}
			}
		}
	}
	

	/**
	 * 递归part得到其所有子部件,不包含PCBA的下层子节点
	 * 
	 * @param index
	 */
	public static void getAllBomByPartNoPCBA(WTPart rootPart, List<Object[]> list,int level,String preNumber) {
		try {
			List<Object[]> childBOM = getChildBOM(rootPart);
			if(childBOM.size() > 0 ){
				for(int i=0;i<childBOM.size();i++){
					WTPartUsageLink usageLink = (WTPartUsageLink)childBOM.get(i)[0];
					WTPart sPart = (WTPart)childBOM.get(i)[1];
					IBAUtil usageLinkIBA = new IBAUtil(usageLink);
					System.out.println("002-ExportBOM-Get-BOM-IBA-"+sPart.getNumber()+":"+usageLinkIBA.ibaContainer.toString());
					IBAUtil partIba = new IBAUtil(sPart);
					String[] data = new String[11];
					int index = 0;
//					data[index++] = usageLinkIBA.getIBAValue("Level_CJ");//层级Level_CJ 
					data[index++] = levelString(level);
					data[index++] = String.valueOf(usageLink.getLineNumber() == null ? "":usageLink.getLineNumber());// 行号
					data[index++] = sPart.getNumber();//编号
					data[index++] = sPart.getName();//名称
					data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc","ItemDesc"));//物料描述ItemDesc
					data[index++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.ItemNote","ItemNote"));//物料行备注ItemNote
					String amount = ""+usageLink.getQuantity().getAmount();
					if(amount.contains("E")){
						amount = getRealNumOfScientificNotation(amount);
					}
					data[index++] = amount;// 数量
					data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.supply","supply"));// 供应商supply
					data[index++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.IsBuyCust","IsBuyCust"));// 是否客供物料IsBuyCust
					data[index++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.IsCoustomerService","IsCoustomerService"));// 是否售后物料IsCoustomerService
					data[index++] = "否";// 是否替代料
					list.add(data);
					handleReplacePartsNoPCBA(usageLink,list);
					if(!StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber)){
						getAllBomByPartNoPCBA(sPart, list, level+1,preNumber);
					}
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 递归part得到其所有子部件,只包含PCBA的下层子节点
	 * 
	 * @param index
	 */
	public static void getAllBomByPartInPCBA(WTPart rootPart, List<Object[]> list,int level,String preNumber) {
		try {
			List<Object[]> childBOM = getChildBOM(rootPart);
			if(childBOM.size() > 0 ){
				for(int i=0;i<childBOM.size();i++){
					WTPartUsageLink usageLink = (WTPartUsageLink)childBOM.get(i)[0];
					WTPart sPart = (WTPart)childBOM.get(i)[1];
					IBAUtil usageLinkIBA = new IBAUtil(usageLink);
					System.out.println("002-ExportBOM-Get-BOM-IBA-"+sPart.getNumber()+":"+usageLinkIBA.ibaContainer.toString());
					IBAUtil partIba = new IBAUtil(sPart);
					String[] data = new String[12];
					int index = 0;
//					data[index++] = usageLinkIBA.getIBAValue("Level_CJ");//层级Level_CJ 
					data[index++] = levelString(level);
					data[index++] = String.valueOf(usageLink.getLineNumber() == null ? "":usageLink.getLineNumber());// 行号
					String amount = ""+usageLink.getQuantity().getAmount();
					if(amount.contains("E")){
						amount = getRealNumOfScientificNotation(amount);
					}
					data[index++] = amount;// 数量
					data[index++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.MachinePos","MachinePos"));//工位MachinePos
					data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.Factory","Factory"));//厂家Factory
					data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.SpecificationsModel","SpecificationsModel"));//规格型号SpecificationsModel
					data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc","ItemDesc"));//物料描述ItemDesc
					data[index++] = sPart.getNumber();//编号
					data[index++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.IsBuyCust","IsBuyCust"));// 是否客供物料IsBuyCust
					data[index++] = sPart.getName();//名称
					data[index++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.ItemNote","ItemNote"));//物料行备注ItemNote
					data[index++] = "否";// 是否替代料
					list.add(data);
					//处理替代料
					handleReplacePartsInPCBA(usageLink, list);
					if(!StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber)){
						getAllBomByPartInPCBA(sPart, list, level+1,preNumber);
					}
					
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 获取子阶列表，按物料编码排序
	 * @param rootPart
	 * @return
	 */
	private static List<Object[]> getChildBOM(WTPart rootPart){
		List<Object[]> list = new ArrayList<Object[]>();
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(rootPart);
			while (qr.hasMoreElements()) {
				Object[] obj = new Object[2];
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				obj[0] = usageLink;
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
				LatestConfigSpec cfg = new LatestConfigSpec();
				qr2 = cfg.process(qr2);
				if (qr2.hasMoreElements()) {
					WTPart sPart = (WTPart) qr2.nextElement();
					obj[1] = sPart;
				}
				list.add(obj);
			}
			//排序
			Collections.sort(list, new Comparator<Object[]>(){
	            public int compare( Object[] obj1, Object[] obj2) {
	            	WTPart part1 = (WTPart)obj1[1];
	            	WTPart part2 = (WTPart)obj2[1];
	                return part1.getNumber().compareTo(part2.getNumber());
	            }
	        });
		}catch (WTException e) {
			e.printStackTrace();
		}
			
		return list;
	}
	
	/**
	 * 科学计数法改为数字字符串
	 * @param doubleStr
	 * @return
	 */
	private static String getRealNumOfScientificNotation(String doubleStr) {
        int indexOfE = doubleStr.indexOf('E');
        int indexOfPoint = doubleStr.indexOf('.');
        // 整数部分
        BigInteger zs = new BigInteger(doubleStr.substring(0, indexOfPoint));
        // 小数部分
        BigInteger xs = new BigInteger(doubleStr.substring(indexOfPoint
                + BigInteger.ONE.intValue(), indexOfE));
        // 指数
        int pow = Integer.valueOf(doubleStr.substring(indexOfE
                + BigInteger.ONE.intValue()));
        StringBuffer buffer = new StringBuffer();
        // e.g. 1.23E-5
        if (pow < 0) {
            for (int i = 0; i < -pow; i++) {
                buffer.append(0);
            }
            buffer.insert(BigInteger.ONE.intValue(), ".");
            buffer.append(zs.toString());
            if(!"0".equalsIgnoreCase(xs.toString())){
            	buffer.append(xs.toString());
            }
            doubleStr = buffer.toString();
        } else {
            int xsLen = xs.toByteArray().length;
            int needFill0 = pow - xsLen;
            if (needFill0 < 0) {
                // e.g. 1.234E2
                buffer.append(xs);
                buffer.insert(pow, ".");
                buffer.insert(0, zs);
                doubleStr = buffer.toString();
            } else {
                // e.g. 1.234E6 or 1.234E3
                for (int i = 0; i < needFill0; i++) {
                    buffer.append(0);
                }
                buffer.insert(0, xs);
                buffer.insert(0, zs);
                doubleStr = buffer.toString();
            }
        }
        return doubleStr;
    }
	
	/**
	 * 处理整机替代料
	 * @param usageLink
	 * @param list
	 * @throws WTException
	 */
	private static void handleReplacePartsNoPCBA(WTPartUsageLink usageLink,List<Object[]> list) throws WTException{
		//查找特定替代
		List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
		//查找全局替代
		List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster)usageLink.getRoleBObject());
		substituteParts.addAll(wtPartAlternateLinks);
		for (int i = 0; i < substituteParts.size(); i++) {
			WTPartMaster wtPartMaster = substituteParts.get(i);
			QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
			LatestConfigSpec cfg = new LatestConfigSpec();
			qr2 = cfg.process(qr2);
			if (qr2.hasMoreElements()) {
				WTPart sPart = (WTPart) qr2.nextElement();
				IBAUtil partIba = new IBAUtil(sPart);
				String[] data = new String[11];
				int index = 0;
				data[index++] = "";//层级Level_CJ 
				data[index++] = "";// 行号
				data[index++] = sPart.getNumber();//编号
				data[index++] = sPart.getName();//名称
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc","ItemDesc"));//物料描述ItemDesc
				data[index++] = "";//物料行备注ItemNote
				data[index++] = "";// 数量
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.supply","supply"));// 供应商supply
				data[index++] = "";// 是否客供物料IsBuyCust
				data[index++] = "";// 是否售后物料IsCoustomerService
				data[index++] = "是";// 是否替代料
				list.add(data);
			}
		}
		
	}
	
	/**
	 * 处理PCBA替代料
	 * @param usageLink
	 * @param list
	 * @throws WTException
	 */
	private static void handleReplacePartsInPCBA(WTPartUsageLink usageLink,List<Object[]> list) throws WTException{
		//查找特定替代
		List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
		//查找全局替代
		List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster)usageLink.getRoleBObject());
		substituteParts.addAll(wtPartAlternateLinks);
		for (int i = 0; i < substituteParts.size(); i++) {
			WTPartMaster wtPartMaster = substituteParts.get(i);
			QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
			LatestConfigSpec cfg = new LatestConfigSpec();
			qr2 = cfg.process(qr2);
			if (qr2.hasMoreElements()) {
				WTPart sPart = (WTPart) qr2.nextElement();
				IBAUtil partIba = new IBAUtil(sPart);
				String[] data = new String[12];
				int index = 0;
				data[index++] = "";//层级Level_CJ 
				data[index++] = "";// 行号
				data[index++] = "";// 数量
				data[index++] = "";//工位MachinePos
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.Factory","Factory"));//厂家Factory
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.SpecificationsModel","SpecificationsModel"));//规格型号SpecificationsModel
				data[index++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc","ItemDesc"));//物料描述ItemDesc
				data[index++] = sPart.getNumber();//编号
				data[index++] = "";// 是否客供物料IsBuyCust
				data[index++] = sPart.getName();//名称
				data[index++] = "";//物料行备注ItemNote
				data[index++] = "是";// 是否替代料
				list.add(data);
			}
		}
		
	}

	/**
	 * 获取位号
	 * 
	 * @param WTPartUsageLink
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public static String getPartUsesOccurrence(WTPartUsageLink useagelink)
			throws WTException {
		List listWTPart2 = new ArrayList();
		long linkid = PersistenceHelper.getObjectIdentifier(useagelink).getId();
		QuerySpec qs = new QuerySpec(PartUsesOccurrence.class);
		qs.appendWhere(new SearchCondition(PartUsesOccurrence.class,
				"linkReference.key.id", SearchCondition.EQUAL, linkid)); 
		QueryResult qr = PersistenceHelper.manager.find(qs);
		String occurrenceStr = "";
		while (qr.hasMoreElements()) {
			PartUsesOccurrence occurrence = (PartUsesOccurrence) qr
					.nextElement();
			listWTPart2.add(occurrence.getName());
		}
		for (int i = 0; i < listWTPart2.size(); i++) {
			if (listWTPart2.get(i) != null) {
				String ocName = listWTPart2.get(i).toString();
				if (i == 0) {
					occurrenceStr = ocName;
				} else {
					occurrenceStr = occurrenceStr + "," + ocName;
				}
			}
		}
		String numberStr = sortPlaceNumber(occurrenceStr);// 对位号排序
		return numberStr;
	}
	// 对位号排序
	public static String sortPlaceNumber(String numberStr) {
		TreeMap tm = new TreeMap();
		String[] s = numberStr.split(",");
		for (int i = 0; i < s.length; i++) {
			tm.put(s[i], s[i]);
		}
		Iterator it = tm.keySet().iterator();
		String number = "";
		int a = 0;
		while (it.hasNext()) {
			if (a == 0) {
				number = (String) it.next();
			} else {
				number = number + "," + (String) it.next();
			}
			a++;
		}
		return number;
	}
	private static String levelString(int level) {
		StringBuffer sb = new StringBuffer("*");
		for (int i = 1; i < level; i++) {
			sb.append("*");
		}
		String levelStr = StringUtils.replace(sb.toString(), "*", "  ", sb.length()-1);
		return levelStr;
	}
	
}
