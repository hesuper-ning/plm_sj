package ext.signature;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import com.ptc.windchill.enterprise.part.commands.PartDocServiceCommand;
import com.ptc.wvs.common.ui.VisualizationHelper;

import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentType;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartUsageLink;
import wt.representation.Representation;
import wt.util.FileUtil;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

public class PartPDFHelper {

	private static EPMDocumentType CADCOMPONENT = EPMDocumentType.toEPMDocumentType("CADCOMPONENT"); //

	private static EPMDocumentType CADASSEMBLY = EPMDocumentType.toEPMDocumentType("CADASSEMBLY"); //

	private static EPMDocumentType CADDRAWING = EPMDocumentType.toEPMDocumentType("CADDRAWING"); //

	/**
	 * 根据WTPart获取 pdf表示法
	 * 
	 * @param part
	 * @return
	 * @throws Exception
	 */
	public static List<ApplicationData> findPDFRepFromPart(WTPart part) throws Exception {
		System.out.println("005-batch download pdf : findPDFRepFromPart " + part.getNumber());
		List<ApplicationData> pdfList = new ArrayList<ApplicationData>();
		List<Persistable> drawingList = get2DDrawingByWTPart(part);
//		List<Persistable> drawingList = getPDFDocByWTPart(part);
		if (drawingList == null) {
			return null;
		}
		VisualizationHelper vizHelper = new VisualizationHelper();

		for (Persistable drawing : drawingList) {
			QueryResult result = vizHelper.getRepresentations(drawing);
			Representation rep = null;
			ContentHolder ch = null;
			Vector<?> appDatas = null;

			ApplicationData appData = null;
			ApplicationData foundPDF = null;
			String fileName = null;
			while (result.hasMoreElements()) {
				rep = (Representation) result.nextElement();
				ch = ContentHelper.service.getContents(rep);
				Boolean defaultRepresentation = rep.getDefaultRepresentation();
				// 必须从默认表示法中获取pdf
				if (!defaultRepresentation) {
					continue;
				}
				appDatas = ContentHelper.getContentListAll(ch);
				for (int i = 0; i < appDatas.size(); i++) {
					appData = (ApplicationData) appDatas.get(i);
					fileName = appData.getFileName();
					ContentRoleType role = appData.getRole();
					// 检查表示法中是否包含pdf
					// 下载pdf到临时目录，添加封面
					if ((role.equals(ContentRoleType.ADDITIONAL_FILES) || role.equals(ContentRoleType.SECONDARY))
							&& FileUtil.getExtension(fileName).equalsIgnoreCase("pdf")) {
						foundPDF = appData;
						break;
					}
				}
				if (foundPDF != null) {
					break;
				}
			}
			if (foundPDF != null) {
				System.out.println("005-batch download pdf : findPDFRepFromPart " + foundPDF.getFileName());
				pdfList.add(foundPDF);
			}
		}
		return pdfList;
	}

	/**
	 * BOM
	 * 
	 * @param part
	 * @return
	 * @throws Exception 
	 */
	public static List<ApplicationData> findBOMPDFRepFromPart(WTPart part) throws Exception {
		System.out.println("005-batch download pdf : findBOMPDFRepFromPart " + part.getNumber());
		List<ApplicationData> list = new ArrayList<ApplicationData>();
		Set<WTPart> set = new HashSet<WTPart>();
		getHasBomPartsByPart(part, set);
		set.add(part);
		System.out.println("005-batch download pdf : getHasBomPartsByPart " + set.size());
		for (WTPart wtPart : set) {
			List<ApplicationData> pdfRep = findPDFRepFromPart(wtPart);
			list.addAll(pdfRep);
		}
		return list;
	}

	/**
	 * 根据part得到其包含子部件 的所有部件(包括其本身)
	 * @param WTPart
	 * @param Set    <WTPart>
	 * @return Set<WTPart>
	 */
	public static Set<WTPart> getHasBomPartsByPart(WTPart productPart, Set<WTPart> set) {
		WTPart sPart = null;
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(productPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
				if (qr2.hasMoreElements()) {
					sPart = (WTPart) qr2.nextElement();
					set.add(sPart);
					getHasBomPartsByPart(sPart, set);
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return set;
	}

	
	/**
	 * 根据3D获取2D drawing
	 * 
	 * @param cad
	 * @throws Exception
	 */
	public static List<Persistable> getPDFDocByWTPart(WTPart part) throws Exception {
		List<Persistable> result = new ArrayList<Persistable>();
		QueryResult qr = null;
		WTDocument doc = null;
		try {
			qr = WTPartHelper.service.getDescribedByDocuments(part);// CAD文档
			while (qr.hasMoreElements()) {
				Object obj = qr.nextElement();
				if (obj instanceof WTDocument) {
					doc = (WTDocument) obj;
					result.add(doc);
				}
			}

		} catch (WTException e) {
			e.printStackTrace();
			throw e;
		}
		return result;
	}
	
	/**
	 * 根据3D获取2D drawing
	 * 
	 * @param cad
	 * @throws Exception
	 */
	public static List<Persistable> get2DDrawingByWTPart(WTPart part) throws Exception {
		List<Persistable> result = new ArrayList<Persistable>();
		QueryResult qr = null;
		EPMDocument doc = null;
		try {
			qr = PartDocServiceCommand.getAssociatedCADDocuments(part);// CAD文档
			while (qr.hasMoreElements()) {
				Object obj = qr.nextElement();
				if (obj instanceof EPMDocument) {
					doc = (EPMDocument) obj;
					EPMDocumentType docType = doc.getDocType();
//					EPMAuthoringAppType appType = doc.getAuthoringApplication();
					if (CADDRAWING.equals(docType)&& doc.getNumber().contains(part.getNumber())) {
						System.out.println("005-batch download pdf : get2DDrawingByWTPart " + doc.getNumber());
						result.add(doc);
					}
				}
			}

		} catch (WTException e) {
			e.printStackTrace();
			throw e;
		}
		return result;
	}

	/**
	 * 根据WTPart获取3D
	 * 
	 * @param part
	 * @throws Exception
	 */
	public static EPMDocument get3DCADByPart(WTPart part) throws Exception {
		EPMDocument doc = null;
		try {
			// 3D
			QueryResult qr = PartDocServiceCommand.getAssociatedCADDocuments(part);// CAD文档
			while (qr.hasMoreElements()) {
				Object obj = qr.nextElement();
				if (obj instanceof EPMDocument) {
					doc = (EPMDocument) obj;
					EPMDocumentType docType = doc.getDocType();
					if ((CADCOMPONENT.equals(docType) || CADASSEMBLY.equals(docType))) {
						return doc;
					}
				}
			}

		} catch (WTException e) {
			e.printStackTrace();
			throw new Exception("No 3D CAD Document on Part :" + part.getName());
		}
		return null;
	}
}
