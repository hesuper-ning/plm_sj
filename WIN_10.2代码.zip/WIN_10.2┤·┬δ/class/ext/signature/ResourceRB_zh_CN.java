package ext.signature;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * 资源文件
 * 
*/
@RBUUID("ext.signature.ResourceRB")
public class ResourceRB_zh_CN extends WTListResourceBundle {

	@RBEntry("批量下载PDF")
	public static final String PRIVATE_CONSTANT_0 = "ext.batchpdf.description";

	@RBEntry("批量下载PDF")
	public static final String PRIVATE_CONSTANT_1 = "ext.batchpdf.title";

	@RBEntry("批量下载PDF")
	public static final String PRIVATE_CONSTANT_2 = "ext.batchpdf.tooltip";

	@RBEntry("file_pdf.gif")
	@RBPseudo(false)
	public static final String PRIVATE_CONSTANT_3 = "ext.batchpdf.icon";

	@RBEntry("height=650,width=750")
	@RBPseudo(false)
	public static final String PRIVATE_CONSTANT_4 = "ext.batchpdf.moreurlinfo";
}
