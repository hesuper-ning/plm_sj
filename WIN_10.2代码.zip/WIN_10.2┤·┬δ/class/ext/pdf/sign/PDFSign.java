package ext.pdf.sign;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.UUID;
import java.util.Vector;

import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.pom.Transaction;
import wt.representation.Representation;
import wt.util.FileUtil;
import wt.util.WTException;
import wt.util.WTProperties;

import com.lowagie.text.DocumentException;
import com.ptc.wvs.common.ui.VisualizationHelper;

import ext.signature.SignaturePDF;


public class PDFSign {

	public static String PDF_TEMP = "";
	static {
		String wtHome = null;
		try {
			WTProperties props = WTProperties.getLocalProperties();
			wtHome = props.getProperty("wt.temp");
			PDF_TEMP = wtHome + File.separator + "pdf";
			File pdfFolder = new File(PDF_TEMP);
			if (!pdfFolder.exists()) {
				pdfFolder.mkdir();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 把pdf表示法更新为新的pdf
	 * 
	 * @param doc
	 * @param documentType 
	 * @param reviewers
	 * @return
	 * @throws WTException
	 */
	public static WTDocument signPDFVisualization(WTDocument doc,
			HashMap<String, Vector<String[]>> signInfoMap, String documentType) throws WTException {

		Transaction trx = new Transaction();

		try {
			trx.start();

			VisualizationHelper vizHelper = new VisualizationHelper();
			QueryResult result = vizHelper.getRepresentations(doc);

			Representation rep = null;
			ContentHolder ch = null;
			Vector<?> appDatas = null;

			ApplicationData appData = null;
			String fileName = null;
			InputStream is = null;

			while (result.hasMoreElements()) {
				rep = (Representation) result.nextElement();
				ch = ContentHelper.service.getContents(rep);
				appDatas = ContentHelper.getContentListAll(ch);
				for (int i = 0; i < appDatas.size(); i++) {
					appData = (ApplicationData) appDatas.get(i);
					fileName = appData.getFileName();
					ContentRoleType role = appData.getRole();
					// 检查表示法中是否包含pdf
					// 下载pdf到临时目录，添加封面
					if (role.equals(ContentRoleType.SECONDARY) && FileUtil.getExtension(fileName).equalsIgnoreCase("pdf")) {
						break;
					}
				}
				if(appData != null){
					break;
				}
			}
			if(appData != null){
				System.out.println("002-check PDF : " + fileName);
				is = ContentServerHelper.service.findContentStream(appData);
				String newPdfName = UUID.randomUUID().toString()+ ".pdf";
				String signatureFilePath = PDF_TEMP + File.separator+ newPdfName;
				//调用签名方法
				System.out.println("003-PDF 签名开始 : " +signatureFilePath);
				SignaturePDF.WriteSignatureToPDF(signInfoMap,is,signatureFilePath,"",doc.getState().toString(),documentType);
				//更新表示法
				System.out.println("004-签名结束后更新到表示法 : "+fileName);
				FileInputStream fis = new FileInputStream (signatureFilePath);
				ContentServerHelper.service.deleteContent(ch, appData);
				appData = ContentServerHelper.service.updateContent(ch, appData, fis);
				PersistenceHelper.manager.save(appData);
				fis.close();
				//删除临时文件
				System.out.println("005-删除临时文件 : "+signatureFilePath);
				new File(signatureFilePath).delete();
			}
			
			trx.commit();
			trx = null;
		} catch (PropertyVetoException e) {
			throw new WTException(e);
		} catch (FileNotFoundException e) {
			throw new WTException(e);
		} catch (IOException e) {
			throw new WTException(e);
		} catch (DocumentException e) {
			e.printStackTrace();
			throw new WTException(e);
		}catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		} finally {
			if (trx != null) {
				trx.rollback();
				trx = null;
			}
		}

		return doc;
	}
}