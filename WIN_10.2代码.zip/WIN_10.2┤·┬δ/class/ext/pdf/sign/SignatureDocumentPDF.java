package ext.pdf.sign;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;

import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.lowagie.text.pdf.parser.PdfTextExtractor;

import ext.signature.PropertiesHelper;
import ext.signature.SignatureHelper;
import ext.signature.SignaturePDF;

public class SignatureDocumentPDF extends SignaturePDF
{
  
  /**
   * 
   * @param objectType PDF文档
   * @param signInfoMap 签名信息
   * @param is 原PDF流
   * @param pdfPath 新PDF文件路径
   * @param state 文档状态
   * @throws Exception
   */
  public static void WriteSignatureToDocumentPDF(String objectType,HashMap signInfoMap, InputStream is, String pdfPath,  String state) throws Exception {
	    try {
	      if (is == null) {
	        System.out.println("003-signature : error of no pdf stream from Document");
	        return;
	      }
	      PdfReader reader = new PdfReader(is);
	      System.out.println("003-signature : loading pdf stream from Document");
	      int totalPage = reader.getNumberOfPages();
	      ArrayList<String> drawFormat = SignatureHelper.mapSheet(reader, totalPage);
	      String fromStr = "[";
	      for (String format : drawFormat) {
	        fromStr = fromStr + format + ",";
	      }
	      fromStr = StringUtils.removeEnd(fromStr, ",") + "]";
	      System.out.println("003-signature : each page format :" + fromStr);
	      String[] pdfSignPage = new String[totalPage];
	      String strFromProperties = PropertiesHelper.getStrFromProperties("默认签名页数");
	      if (StringUtils.isBlank(strFromProperties))
	        pdfSignPage[0] = "N";
	      else {
	        pdfSignPage = strFromProperties.split(",");
	      }
	      PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(pdfPath));
	      int deletePageNumber = totalPage;
	      PdfTextExtractor extractor = new PdfTextExtractor(reader);

	      for (int j = 1; j < totalPage + 1; j++)
	      {

	        if (!StringUtils.isNotBlank(state))
	          continue;
	        String tufu = (String)drawFormat.get(j - 1);
	        PdfContentByte cb = stamp.getOverContent(j);
	        cb.beginText();
	        if ("N".equalsIgnoreCase(pdfSignPage[0])) {
	          System.out.println("003-signature : signature page [" + j + "] start ...");
	          WritePDFCoordinateContent(objectType, tufu, signInfoMap, cb, state);
	          System.out.println("003-signature : signature page [" + j + "] success.");
	        } else {
	          for (int k = 0; k < pdfSignPage.length; k++) {
	            try {
	              int signaturePage = Integer.parseInt(pdfSignPage[k]);
	              if (j == signaturePage) {
	                System.out.println("003-signature : signature page [" + j + "] start ...");
	                WritePDFCoordinateContent(objectType, tufu, signInfoMap, cb, state);
	                System.out.println("003-signature : signature page [" + j + "] success.");
	              }
	            } catch (NumberFormatException e) {
	              System.out.println("003-signature : signpage config from signature.properties has error :[" + pdfSignPage[k] + "] is not Integer number");
	            }
	          }
	        }

	        cb.endText();
	      }

	      StringBuffer pageList = new StringBuffer("");
	      if (deletePageNumber == 1)
	        pageList = pageList.append("1");
	      else {
	        for (int index = 1; index <= totalPage; index++) {
	          if (index == deletePageNumber) {
	            continue;
	          }
	          pageList.append(index);
	          pageList.append(",");
	        }
	      }
	      String pageString = pageList.toString();
	      if (StringUtils.endsWith(pageString, ",")) {
	        pageString = StringUtils.removeEnd(pageString, ",");
	      }
	      reader.selectPages(pageString);
	      stamp.close();
	      reader.close();
	    } catch (Exception e) {
	      e.printStackTrace();
	      System.out.println("003-signature : signpage  error :" + e.getMessage());
	      throw e;
	    }
	  }
}

