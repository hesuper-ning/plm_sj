package ext.replacePart.server;

import com.ptc.windchill.enterprise.object.WhereUsedConfigSpec;
import ext.replacePart.controller.BatchAddReplacePartServlet;
import ext.replacePart.jsonObject.JsonWTPart;
import ext.replacePart.controller.WTPartSubstituteLinkUtil;
import ext.replacePart.utils.PartUtil;
import ext.replacePart.utils.PersistenceUtil;
import ext.replacePart.utils.PropertiesUtil;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.struct.StructHelper;

import java.util.*;

/**
 *
 */
public class CheckAndDelServer {


    /**
     * 检查父子部件的连接关系
     * 若存在返回连接对象 反之返回空连接对象
     * @param fatherNum
     * @param sonNum
     * @return
     */
    public static JsonWTPart checkLinkExists(String fatherNum, String sonNum) throws WTException {
        System.out.println("传入的fatherNumber"+fatherNum);
        System.out.println("传入的sonNum"+sonNum);

        JsonWTPart jsonWTPart = new JsonWTPart();
        WTPart fatherPart = WTPartSubstituteLinkUtil.getWTPartByNumber(fatherNum);
        WTPartMaster sonMaster = WTPartSubstituteLinkUtil.getWTPartMasterByNumber(sonNum);
        WTPartUsageLink link = WTPartSubstituteLinkUtil.findWTPartUsageLink(fatherPart, sonMaster);



        System.out.println("JsonWTPart的fatherNumber"+fatherPart.getNumber());
        System.out.println("JsonWTPart的sonNum"+sonMaster.getNumber());
        System.out.println("JsonWTPart的父子连接"+link.toString());
        // 获取父子部件的连接
        jsonWTPart.setFatherNumber(fatherPart.getNumber());
        jsonWTPart.setFatherName(fatherPart.getName());
        jsonWTPart.setFatherLifeStatue(fatherPart.getLifeCycleState().getDisplay());



        if(link != null) {
            jsonWTPart.setWtPartUsageLink(link.toString());
        }
        return jsonWTPart;
    }


    /**
     * 批量删除替代料的查询方法
     * @param itemNumber
     * @param oRbyVR
     * @return
     * @throws WTException
     */
    public static LinkedHashSet<JsonWTPart> selectResponse(String itemNumber, String oRbyVR) throws WTException {
        ReferenceFactory refefence = new ReferenceFactory();
        //通过or获取到部件
        WTPart part = (WTPart) refefence.getReference(oRbyVR).getObject();

        LinkedHashSet faPartResult = new LinkedHashSet();


        System.out.println("001==" + part.getNumber());
        List<WTPart> fatherParts =  getFatherParts(part, 1);
        System.out.println("所有父部件长度："+fatherParts.size());
        for (WTPart fatherPart : fatherParts) {
            System.out.println("002==" + fatherPart.getNumber());


            String fatherStatue = fatherPart.getLifeCycleState().getDisplay();
            List<String> noShowPartStatusList = WTPartSubstituteLinkUtil.noShowPartStatusList;

            if(noShowPartStatusList.contains(fatherStatue)){
                continue;
            }

             List<WTPart> topParentParts =  getPartsByItemNumber(fatherPart,itemNumber);
            for (WTPart topParentPart : topParentParts) {
                System.out.println("003==" + topParentPart.getNumber());
                String typeName = PersistenceUtil.getPartTypeInternalName(topParentPart);
                String itemType = PropertiesUtil.getValueByKey("doc.type.picType");
                System.out.println("配置文件项目类型："+itemType);
                System.out.println("顶层的项目类型内部名："+typeName);
                System.out.println("是否为同项目类型"+typeName.equals(itemType) );
                System.out.println("是否为同编号"+(topParentPart.getNumber()).equals(itemNumber));

                if (typeName.equals(itemType) && (topParentPart.getNumber()).equals(itemNumber)) {
                    WTPartMaster sonMaster = WTPartSubstituteLinkUtil.getWTPartMasterByNumber(part.getNumber());
                    System.out.println("过滤之后："+fatherPart.getNumber());
                    WTPartUsageLink wtPartUsageLink = WTPartSubstituteLinkUtil.findWTPartUsageLink(fatherPart, sonMaster);

                    List<WTPartSubstituteLink> wtPartSubstituteLinks = WTPartSubstituteLinkUtil.getWTPartSubstituteLinks(wtPartUsageLink);

                    for (WTPartSubstituteLink subLink : wtPartSubstituteLinks){
                        WTPartMaster substitutes = subLink.getSubstitutes();
                        //将数据包裹一行
                        JsonWTPart jsonWTPart = new JsonWTPart();
                        jsonWTPart.setFatherNumber(fatherPart.getNumber());
                        jsonWTPart.setFatherName(fatherPart.getName());
                        jsonWTPart.setWtPartUsageLink(wtPartUsageLink.toString());
                        jsonWTPart.setSubstituteName(substitutes.getName());
                        jsonWTPart.setSubstituteNumber(substitutes.getNumber());
                        jsonWTPart.setWtPartSubLink(subLink.toString());
                        jsonWTPart.setFatherLifeStatue(fatherStatue);
                        faPartResult.add(jsonWTPart);
                    }
                }
            }
        }
        return faPartResult;
    }





    /**
     * 获取部件的上层父部件
     *
     * @param part
     * @return
     */
    public static List<WTPart> getFatherParts(WTPart part, int depth) {
        List<WTPart> result = new ArrayList<>();
        String viewName = part.getViewName();
        try {
            QueryResult qr = StructHelper.service.navigateUsedByToIteration(part, true, new WhereUsedConfigSpec());
            while (qr.hasMoreElements()) {
                WTPart faPart = (WTPart) qr.nextElement();
                String fatherViewName = faPart.getViewName();
                if (fatherViewName.equals(viewName) && result.add(faPart)) {
//                    result.addAll(getFatherParts(faPart, depth - 1));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * 通过递归找到部件的BOM最上层部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getTopParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<>();
        try {
            if (part != null) {
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());
                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        list.addAll(getTopParentParts(childPart));
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();

        }
        return list;
    }

 /**
     * 通过递归 找到部件上层指定编号的部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getPartsByItemNumber(WTPart part,String itemNumber) {
        List<WTPart> list = new ArrayList<>();
        try {
            if (part != null) {
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());
                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        if (itemNumber.equals(childPart.getNumber())){//指定项目编号的上层
                            list.add(childPart);
                            break;
                        }else {
                            list.addAll(getPartsByItemNumber(childPart,itemNumber));
                        }

                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();

        }
        return list;
    }
    /**
     * 根据子部件获取所有父部件之间的关联
     *
     * @param childPart
     * @return List<WTPartUsageLink>
     */
    @SuppressWarnings("deprecation")
    public static Set<WTPartUsageLink> getBomLinkByChildPart(WTPart childPart) {
        Set<WTPartUsageLink> list = new HashSet<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 通过父部件和子部件获取部件之间使用关系
     *
     * @param fatherPart
     * @param childPart
     * @return
     */
    public static List<WTPartUsageLink> getWtPartUsageLink(WTPart fatherPart, WTPart childPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier(fatherPart)));
                queryspec.appendAnd();
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 检查父部件是否是检出状态 如果是则返回错误信息
     * @param objects
     * @return
     */
    public static String checkFatherPart(JsonWTPart[] objects){
        String errMsg = null;
        StringBuffer msg = new StringBuffer();
        for (JsonWTPart object : objects){
            WTPart part = WTPartSubstituteLinkUtil.getWTPartByNumber(object.getFatherNumber());
            boolean checkOut = PersistenceUtil.isCheckOut(part);
            if(checkOut){
                msg.append("父部件编号"+object.getFatherNumber()+"_"+object.getFatherName()+"已被检出"+"\n");
            }
        }
        errMsg = msg.toString();
        return errMsg;
    }
}
