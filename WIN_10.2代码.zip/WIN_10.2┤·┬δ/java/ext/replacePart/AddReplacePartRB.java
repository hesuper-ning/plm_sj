package ext.replacePart;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.replacePart.AddReplacePartRB")
public class AddReplacePartRB extends WTListResourceBundle {

    @RBEntry("批量添加替代料")
    public static final String PRIVATE_CONSTANT_0 = "ReplacePartWizard.addReplacePart.description";
    @RBEntry("批量添加替代料")
    public static final String PRIVATE_CONSTANT_1 = "ReplacePartWizard.addReplacePart.tooltip";
    @RBEntry("add16x16.gif")
    public static final String PRIVATE_CONSTANT_3 = "ReplacePartWizard.addReplacePart.icon";


    @RBEntry("excel添加替代料")
    public static final String PRIVATE_CONSTANT_4 = "ReplacePartWizard.excelSetreplace.description";
    @RBEntry("excel添加替代料")
    public static final String PRIVATE_CONSTANT_5 = "ReplacePartWizard.excelSetreplace.tooltip";


    @RBEntry("批量删除替代料")
    public static final String PRIVATE_CONSTANT_6 = "ReplacePartWizard.delReplacePart.description";
    @RBEntry("批量删除替代料")
    public static final String PRIVATE_CONSTANT_7 = "ReplacePartWizard.delReplacePart.tooltip";
    @RBEntry("delete.gif")
    public static final String PRIVATE_CONSTANT_8 = "ReplacePartWizard.delReplacePart.icon";
}
