package ext.replacePart.jsonObject;

public class ReplacePart_data {
    private String itemPartNumber;
    private String itemPartName;
    private String fatherPartNumber;
    private String fatherPartName;
    private String replacePartNumber;
    private String updateType;

    public String getItemPartNumber() {
        return itemPartNumber;
    }

    public void setItemPartNumber(String itemPartNumber) {
        this.itemPartNumber = itemPartNumber;
    }

    public String getItemPartName() {
        return itemPartName;
    }

    public void setItemPartName(String itemPartName) {
        this.itemPartName = itemPartName;
    }

    public String getFatherPartNumber() {
        return fatherPartNumber;
    }

    public void setFatherPartNumber(String fatherPartNumber) {
        this.fatherPartNumber = fatherPartNumber;
    }

    public String getFatherPartName() {
        return fatherPartName;
    }

    public void setFatherPartName(String fatherPartName) {
        this.fatherPartName = fatherPartName;
    }

    public String getReplacePartNumber() {
        return replacePartNumber;
    }

    public void setReplacePartNumber(String replacePartNumber) {
        this.replacePartNumber = replacePartNumber;
    }

    public String getUpdateType() {
        return updateType;
    }

    public void setUpdateType(String updateType) {
        this.updateType = updateType;
    }



}
