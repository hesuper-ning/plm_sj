package ext.replacePart.jsonObject;

import java.util.Objects;

public class JsonWTPart {
    private String fatherNumber;
    private String fatherName;
    private String substituteNumber;
    private String substituteName;
    private String wtPartSubLink;
    private String wtPartUsageLink;
    public String fatherLifeStatue;

    public String getFatherNumber() {
        return fatherNumber;
    }

    public void setFatherNumber(String fatherNumber) {
        this.fatherNumber = fatherNumber;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getSubstituteNumber() {
        return substituteNumber;
    }

    public void setSubstituteNumber(String substituteNumber) {
        this.substituteNumber = substituteNumber;
    }

    public String getSubstituteName() {
        return substituteName;
    }

    public void setSubstituteName(String substituteName) {
        this.substituteName = substituteName;
    }

    public String getWtPartSubLink() {
        return wtPartSubLink;
    }

    public void setWtPartSubLink(String wtPartSubLink) {
        this.wtPartSubLink = wtPartSubLink;
    }

    public String getWtPartUsageLink() {
        return wtPartUsageLink;
    }

    public void setWtPartUsageLink(String wtPartUsageLink) {
        this.wtPartUsageLink = wtPartUsageLink;
    }

    public String getFatherLifeStatue() {
        return fatherLifeStatue;
    }

    public void setFatherLifeStatue(String fatherLifeStatue) {
        this.fatherLifeStatue = fatherLifeStatue;
    }

    public JsonWTPart() {
    }

    @Override
    public String toString() {
        return "JsonWTPart{" +
                "fatherNumber='" + fatherNumber + '\'' +
                ", fatherName='" + fatherName + '\'' +
                ", substituteNumber='" + substituteNumber + '\'' +
                ", substituteName='" + substituteName + '\'' +
                ", wtPartSubLink='" + wtPartSubLink + '\'' +
                ", wtPartUsageLink='" + wtPartUsageLink + '\'' +
                ", fatherLifeStatue='" + fatherLifeStatue + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        JsonWTPart that = (JsonWTPart) o;
        return Objects.equals(fatherNumber, that.fatherNumber) && Objects.equals(fatherName, that.fatherName) && Objects.equals(substituteNumber, that.substituteNumber) && Objects.equals(substituteName, that.substituteName) && Objects.equals(wtPartSubLink, that.wtPartSubLink) && Objects.equals(wtPartUsageLink, that.wtPartUsageLink) && Objects.equals(fatherLifeStatue, that.fatherLifeStatue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fatherNumber, fatherName, substituteNumber, substituteName, wtPartSubLink, wtPartUsageLink, fatherLifeStatue);
    }
}
