package ext.replacePart.jsonObject;

public class ResponseConstant {
    public final static String BATCH_ADD_SUBSTITUTE_SUCCESS = "1";   //
    public final static String BATCH_CHECK_OUT = "2";
    public final static String BATCH_NOT_SUBSTITUTE = "3";
    public final static String BATCH_SOME_SUBSTITUTE = "4";


    public final static String BATCH_Delete_SUBSTITUTE_SUCCESS = "5";

}
