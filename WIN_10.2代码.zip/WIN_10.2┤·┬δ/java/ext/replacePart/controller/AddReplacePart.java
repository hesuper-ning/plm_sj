package ext.replacePart.controller;


import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.fileupload.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import static ext.replacePart.controller.readExcel.getExcelModel;

/**
 * 变更定制操作 工具类
 */
public class AddReplacePart {

    private static final long serialVersionUID = 1L;

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, WTException, InvalidFormatException, FileUploadException {

        InputStream is = getFileInputStream(request, null);



        if (is != null) {
            System.out.println("01读取到了文件流");

            readExcel.getExcelModel(is);
        }
        response.setContentType("text/html;charset=UTF-8");
        System.out.println("进入excel上传接口");

    }

    private static InputStream getFileInputStream(HttpServletRequest request, List<String> fileList) throws FileUploadException, IOException {
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);
        if (isMultipart) {
            FileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            Iterator<FileItem> items = upload.parseRequest(request).iterator();// 解析表单中提交的所有文件内容
            while (items.hasNext()) {
                FileItem item = (FileItem) items.next();
                if (!item.isFormField()) {
                    String fileName = item.getName();
                    if (fileList != null) {
                        fileList.add(fileName);
                    }
                    return item.getInputStream();
                }
            }
        }
        return null;
    }
}

	

	
	

	

	

	
	

