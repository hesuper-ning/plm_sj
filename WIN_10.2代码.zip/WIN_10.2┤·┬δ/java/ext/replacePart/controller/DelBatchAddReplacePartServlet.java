package ext.replacePart.controller;

import ext.replacePart.jsonObject.JsonWTPart;
import ext.replacePart.server.CheckAndDelServer;
import ext.replacePart.utils.PartUtil;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import wt.util.WTException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashSet;


/**
 * 删除搜索页面的查询返回接口
 */
public class DelBatchAddReplacePartServlet {


    ObjectMapper objectMapper = new ObjectMapper();
    private static final long serialVersionUID = 1L;
    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, WTException {

        System.out.println("进入BatchAddReplacePartServlet");
        //查询关键词
        String itemNumber = request.getParameter("itemNumber");
        //传入的部件oid
        String oid = request.getParameter("oid");

        String oRbyVR = oid;
        if((oid != null && !oid.isEmpty()) && (itemNumber != null && !itemNumber.isEmpty())){
            if(oid.contains("VR")){
                oRbyVR = PartUtil.getORbyVR(oid);
            }

            LinkedHashSet<JsonWTPart> faPartResult = CheckAndDelServer.selectResponse(itemNumber, oRbyVR);

            String faPartJson = objectMapper.writeValueAsString(faPartResult);

            System.out.println(faPartJson);
            //数组转为json
            String returnJson = faPartJson;
            // 设置响应内容类型为 JSON
            response.reset();
            response.setContentType("application/json;charset=utf-8");
            response.setContentType("text/html;charset=UTF-8");  //这句太重要了

            PrintWriter out = response.getWriter();
            out.print(returnJson);
            out.flush();
        }



    }
}
