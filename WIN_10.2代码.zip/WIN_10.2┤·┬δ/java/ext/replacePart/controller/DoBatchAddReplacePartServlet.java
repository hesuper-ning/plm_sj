package ext.replacePart.controller;

import com.ptc.windchill.enterprise.object.WhereUsedConfigSpec;
import ext.replacePart.jsonObject.JsonWTPart;
import ext.replacePart.jsonObject.ResponseJsonVo;
import ext.replacePart.server.CheckAndDelServer;
import ext.replacePart.utils.CommonUtil;
import ext.replacePart.utils.PartUtil;
import ext.replacePart.utils.PersistenceUtil;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;
import wt.vc.wip.WorkInProgressHelper;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import static ext.replacePart.jsonObject.ResponseConstant.*;

public class DoBatchAddReplacePartServlet {

    ReferenceFactory refefence = new ReferenceFactory();

    private static final long serialVersionUID = 1L;
    ObjectMapper objectMapper = new ObjectMapper();

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, WTException, WTPropertyVetoException {
        String userName = SessionHelper.manager.getPrincipal().getName();

        ResponseJsonVo responseJsonVo =null;
        String returnJson="";
        System.out.println("进入DoBatchAddReplacePartServlet");
        // 设置请求和响应的内容类型为JSON
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");

//        String jsonData = request.getParameter("jsonData");
//        System.out.println("打印get数据："+jsonData);

        // 读取请求体中的JSON数据
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        String jsonStr = sb.toString();
//        jsonStr = jsonStr.substring(1, jsonStr.length() - 1);
        System.out.println("打印post数据：" + jsonStr);


        JsonWTPart[] objects = objectMapper.readValue(jsonStr, JsonWTPart[].class);
        // 检查父部件是否为检出状态
        String checkOutMsg = CheckAndDelServer.checkFatherPart(objects);
        if(checkOutMsg.length() >2) {
            responseJsonVo = new ResponseJsonVo(BATCH_CHECK_OUT,checkOutMsg,null);
            returnJson = objectMapper.writeValueAsString(responseJsonVo);

            response.reset();
            response.setContentType("application/json;charset=utf-8");
            response.setContentType("text/html;charset=UTF-8");  //这句太重要了
            PrintWriter out = response.getWriter();
            out.print(returnJson);
            out.flush();
            return;
        }

        for (JsonWTPart object : objects) {
            //使用关系oid获取使用关系对象

            WTPartUsageLink partUsageLink = (WTPartUsageLink) refefence.getReference(object.getWtPartUsageLink()).getObject();

            //传入的替代料编号获取替代料
            WTPartMaster substitutePart = getWTPartMasterByNumber(object.getSubstituteNumber());

            if (substitutePart==null){
                String noSubstituteJson ="没有"+object.getSubstituteNumber()+"替代料";
                responseJsonVo = new ResponseJsonVo(BATCH_NOT_SUBSTITUTE,noSubstituteJson,null);
                continue;
            }
            //根据使用关系获取所有的使用关系
            List<WTPartSubstituteLink> wtPartSubstituteLinks = getWTPartSubstituteLinks(partUsageLink);

            Set<WTPartUsageLink> waitAddLink = new HashSet<>();

            waitAddLink.add(partUsageLink);

            System.out.println("当前父子链接子项部件的number"+partUsageLink.getUses().getNumber());

            //只执行当前link中没有指定替代料的，new替代料link
            for (WTPartSubstituteLink wtPartSubstituteLink : wtPartSubstituteLinks) {
                WTPartMaster substitutes = wtPartSubstituteLink.getSubstitutes();

                if(substitutePart.equals(substitutes)){
                    System.out.println("子部件编号"+partUsageLink.getUses().getNumber()+"发现有相同替代料");
                    String someSubstitute = "子部件编号"+partUsageLink.getUses().getNumber()+"发现有相同替代料";
                    responseJsonVo = new ResponseJsonVo(BATCH_SOME_SUBSTITUTE,someSubstitute,null);
                    waitAddLink.remove(partUsageLink);
                }
            }

            for (WTPartUsageLink link: waitAddLink){
                WTPart fatherPart = getWTPartByNumber(object.getFatherNumber());
                WTPartMaster sonMaster = link.getUses();
                System.out.println("检入版本的or"+PersistenceUtil.object2Oid(fatherPart));
                WTPart chickOutPart = (WTPart) WorkInProgressHelper.service.checkout(fatherPart,WorkInProgressHelper.service.getCheckoutFolder(),"").getWorkingCopy();

                // 创建检出父部件和子件的link
                List<WTPartUsageLink> wtPartUsageLink = getWtPartUsageLink(chickOutPart, getWTPartByNumber(sonMaster.getNumber()));


                WTPartSubstituteLink wtPartSubstituteLink = WTPartSubstituteLink.newWTPartSubstituteLink(wtPartUsageLink.get(0), substitutePart);
                PersistenceHelper.manager.save(wtPartSubstituteLink);

//                chickOutPart.setOwnership(CommonUtil.getOwnershipByName(userName));
                System.out.println("检出版本的or"+PersistenceUtil.object2Oid(chickOutPart));
                WorkInProgressHelper.service.checkin(chickOutPart ,"批量添加"+substitutePart.getNumber()+"_"+substitutePart.getName()+"替代料");

                System.out.println("需要执行的插入替代料的子项部件的number"+partUsageLink.getUses().getNumber());

                responseJsonVo = new ResponseJsonVo(BATCH_ADD_SUBSTITUTE_SUCCESS,"添加成功！",null);

            }

        }

        returnJson = objectMapper.writeValueAsString(responseJsonVo);

        // 设置响应内容类型为 JSON
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了


        PrintWriter out = response.getWriter();
        out.print(returnJson);
        out.flush();


    }


    /**
     * 获取部件的上层父部件
     *
     * @param part
     * @return
     */
    public static List<WTPart> getFatherParts(WTPart part, int depth) {
        List<WTPart> result = new ArrayList<>();
        String viewName = part.getViewName();
        try {
            QueryResult qr = StructHelper.service.navigateUsedByToIteration(part, true, new WhereUsedConfigSpec());
            while (qr.hasMoreElements()) {
                WTPart faPart = (WTPart) qr.nextElement();
                String fatherViewName = faPart.getViewName();
                if (fatherViewName.equals(viewName)) {
//                    result.addAll(getFatherParts(faPart, depth - 1));
                    result.add(faPart)
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * 通过递归找到部件的BOM最上层部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getTopParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<>();
        try {
            if (part != null) {
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());
                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        list.addAll(getTopParentParts(childPart));
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();

        }
        return list;
    }


    /**
     * 根据子部件获取所有父部件之间的关联
     *
     * @param childPart
     * @return List<WTPartUsageLink>
     */
    @SuppressWarnings("deprecation")
    public static Set<WTPartUsageLink> getBomLinkByChildPart(WTPart childPart) {
        Set<WTPartUsageLink> list = new HashSet<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 通过父部件和子部件获取部件之间使用关系
     *
     * @param fatherPart
     * @param childPart
     * @return
     */
    public static List<WTPartUsageLink> getWtPartUsageLink(WTPart fatherPart, WTPart childPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier(fatherPart)));
                queryspec.appendAnd();
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 根据编号查询part
     *
     * @param number
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static WTPart getWTPartByNumber(String number) {
        WTPart result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (WTPart) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    //02.零件号  返回 WTPartMaster 对象
    public static WTPartMaster getWTPartMasterByNumber(String paramString)
            throws WTException {
        WTPartMaster localWTPartMaster = null;
        QuerySpec localQuerySpec = null;
        QueryResult localQueryResult = null;
        localQuerySpec = new QuerySpec(WTPartMaster.class);

        SearchCondition localSearchCondition = new SearchCondition(WTPartMaster.class, "number", "LIKE", paramString);
        localQuerySpec.appendSearchCondition(localSearchCondition);
        localQueryResult = PersistenceHelper.manager.find(localQuerySpec);
        if (localQueryResult.hasMoreElements()) {
            localWTPartMaster = (WTPartMaster) localQueryResult.nextElement();
        }

        return localWTPartMaster;
    }

    /**
     * 根据部件于获取局部替代料的关联关系
     *
     * @param usageLink
     * @return List<WTPartSubstituteLink>
     */
    public static List<WTPartSubstituteLink> getWTPartSubstituteLinks(WTPartUsageLink usageLink) {
        if (usageLink == null) {
            return null;
        }
        List<WTPartSubstituteLink> list = new ArrayList<WTPartSubstituteLink>();
        long masterId = PersistenceHelper.getObjectIdentifier(usageLink).getId();
        int[] index = {0};
        try {
            QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
            qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class, "roleAObjectRef.key.id",
                    SearchCondition.EQUAL, masterId), index);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            while (qr.hasMoreElements()) {
                WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr.nextElement();
                list.add(sLink);
            }
        } catch (QueryException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

}