package ext.replacePart.controller;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.pds.StatementSpec;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class WTPartSubstituteLinkUtil {
    private static final String[] noShowPartStatus = {"试制", "已发布", "正在审阅", "废弃"};

    public static final List<String> noShowPartStatusList = new ArrayList<>(Arrays.asList(noShowPartStatus));

    public static void batchReplaceSubstitute(String fatherNumber, String sonNumber, String modificationType, String substituteNumber) throws WTException {
        System.out.println("batchReplaceSubstitute方法的fatherNumber" + fatherNumber);
        System.out.println("batchReplaceSubstitute方法的sonNumber" + sonNumber);
        System.out.println("batchReplaceSubstitute方法的modificationType" + modificationType);
        System.out.println("batchReplaceSubstitute方法的substituteNumber" + substituteNumber);
        WTPart fatherPart = getWTPartByNumber(fatherNumber);
        WTPartMaster sonPart = getWTPartMasterByNumber(sonNumber);
        WTPartUsageLink usageLink = findWTPartUsageLink(fatherPart, sonPart);
        List<WTPartSubstituteLink> wTPartsubstituteLinkList = getWTPartSubstituteLinks(usageLink);
        //传入的替代料编号获取替代料
        WTPartMaster substitutePart = getWTPartMasterByNumber(substituteNumber);

        //创建等待添加的link
        HashSet<WTPartUsageLink> waitAddLink = new HashSet<>();
        waitAddLink.add(usageLink);

        //创建待删除link
//        HashSet<WTPartUsageLink> waitDelete = new HashSet<>();
//        waitDelete.add(usageLink);

        System.out.println("当前父子链接子项部件的number" + usageLink.getUses().getNumber());
        for (WTPartSubstituteLink substituteLink : wTPartsubstituteLinkList) {
            WTPartMaster subPart = substituteLink.getSubstitutes();
            String subNumber = subPart.getNumber();
            if (modificationType.equals("新增")) {
                //过滤已经存在的替代料
                if (substitutePart.getNumber().equals(subNumber)) {
                    //移除存在传入替代料的link
                    System.out.println("子部件编号" + usageLink.getUses().getNumber() + "发现有相同替代料");
                    waitAddLink.remove(substituteLink);
                }

            } else if (modificationType.equals("删除")) {
                if (!subNumber.equals(substituteNumber)) {
//                    waitDelete.remove(substituteLink);
                    PersistenceHelper.manager.delete(substituteLink);
                }
            }
        }


        if (modificationType.equals("新增")) {
            System.out.println("添加替代料操作时需要添加替代料的链接集合的长度=" + waitAddLink.size());
            for (WTPartUsageLink wtPartUsageLink : waitAddLink) {
                //执行过滤后的
                System.out.println("需要执行的插入替代料的子项部件的number" + usageLink.getUses().getNumber());
                PersistenceHelper.manager.save(WTPartSubstituteLink.newWTPartSubstituteLink(wtPartUsageLink, substitutePart));

            }
        }
//        } else if (modificationType.equals("删除")) {
//                System.out.println("删除替代料操作时需要添加替代料的链接集合的长度=" + waitDelete.size());
//            for (WTPartUsageLink wtPartUsageLink : waitDelete) {
//                PersistenceHelper.manager.delete(wtPartUsageLink);
//
//            }
//        }

    }

    /**
     * 根据编号查询part
     *
     * @param fatherNumber
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static WTPart getWTPartByNumber(String fatherNumber) {
        WTPart result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
                    fatherNumber.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (WTPart) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 根据子件编号获取WTPartMaster
     *
     * @param sonNumber
     * @return
     * @throws WTException
     */
    public static WTPartMaster getWTPartMasterByNumber(String sonNumber)
            throws WTException {
        WTPartMaster localWTPartMaster = null;
        QuerySpec localQuerySpec = null;
        QueryResult localQueryResult = null;
        localQuerySpec = new QuerySpec(WTPartMaster.class);

        SearchCondition localSearchCondition = new SearchCondition(WTPartMaster.class, "number", "LIKE", sonNumber);
        localQuerySpec.appendSearchCondition(localSearchCondition);
        localQueryResult = PersistenceHelper.manager.find(localQuerySpec);
        if (localQueryResult.hasMoreElements()) {
            localWTPartMaster = (WTPartMaster) localQueryResult.nextElement();
        }

        return localWTPartMaster;
    }

    /**
     * 获取父子部件的连接
     *
     * @param part
     * @param subMaster
     * @return
     */
    public static WTPartUsageLink findWTPartUsageLink(WTPart part, WTPartMaster subMaster) {
        WTPartUsageLink link = null;
        if (part == null || subMaster == null) {
            return link;
        }
        try {
            QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
            queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                    PersistenceHelper.getObjectIdentifier(part)), new int[]{});
            queryspec.appendAnd();
            queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                    PersistenceHelper.getObjectIdentifier(subMaster)), new int[]{});
            QueryResult qr = PersistenceHelper.manager.find(queryspec);
            if (qr != null && qr.hasMoreElements()) {
                link = (WTPartUsageLink) qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return link;
    }


    /**
     * 根据部件于获取局部替代料的关联关系
     *
     * @param  usageLink
     * @return List<WTPartSubstituteLink>
     */
    public static List<WTPartSubstituteLink> getWTPartSubstituteLinks(WTPartUsageLink usageLink) {
        if (usageLink == null) {
            return null;
        }
        List<WTPartSubstituteLink> list = new ArrayList<WTPartSubstituteLink>();
        long masterId = PersistenceHelper.getObjectIdentifier(usageLink).getId();
        int[] index = {0};
        try {
            QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
            qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class, "roleAObjectRef.key.id",
                    SearchCondition.EQUAL, masterId), index);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            while (qr.hasMoreElements()) {
                WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr.nextElement();
                list.add(sLink);
            }
        } catch (QueryException e) {
            e.printStackTrace();
        } catch (WTException e) {
            throw new RuntimeException(e);
        }
        return list;
    }


}
