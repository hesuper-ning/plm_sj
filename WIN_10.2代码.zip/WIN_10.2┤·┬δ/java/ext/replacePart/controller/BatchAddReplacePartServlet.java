package ext.replacePart.controller;

import com.ptc.windchill.enterprise.object.WhereUsedConfigSpec;
import ext.replacePart.jsonObject.JsonWTPart;
import ext.replacePart.utils.PartUtil;
import ext.replacePart.utils.PersistenceUtil;
import ext.replacePart.utils.PropertiesUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import org.codehaus.jackson.map.ObjectMapper;
import wt.part.WTPartUsageLink;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.vc.struct.StructHelper;

import java.util.LinkedHashSet;
import wt.part.WTPartMaster;
import wt.util.WTException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class BatchAddReplacePartServlet {
    ObjectMapper objectMapper = new ObjectMapper();
    private static final long serialVersionUID = 1L;
    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, WTException {

        System.out.println("进入BatchAddReplacePartServlet");
        //查询关键词
        String itemNumber = request.getParameter("itemNumber");
        //传入的部件oid
        String oid = request.getParameter("oid");

        if((oid != null && !oid.isEmpty()) && (itemNumber != null && !itemNumber.isEmpty())){
            //通过vr获取or
            String oRbyVR = PartUtil.getORbyVR(oid);
            ReferenceFactory refefence = new ReferenceFactory();
            //通过or获取到部件
            WTPart part = (WTPart) refefence.getReference(oRbyVR).getObject();

            LinkedHashSet faPartResult = new LinkedHashSet();


            System.out.println("001==" + part.getNumber());
            List<WTPart> fatherParts = getFatherParts(part, 1);
            System.out.println("所有父部件长度："+fatherParts.size());

            for (WTPart fatherPart : fatherParts) {
                System.out.println("002==" + fatherPart.getNumber());

                String fatherStatue = fatherPart.getLifeCycleState().getDisplay();
                List<String> noShowPartStatusList = WTPartSubstituteLinkUtil.noShowPartStatusList;

                if(noShowPartStatusList.contains(fatherStatue)){
                    continue;
                }

              List<WTPart> topParentParts = getPartsByItemNumber(fatherPart,itemNumber);
                for (WTPart topParentPart : topParentParts) {
                    System.out.println("003==" + topParentPart.getNumber());
                    String typeName = PersistenceUtil.getPartTypeInternalName(topParentPart);
                    String itemType = PropertiesUtil.getValueByKey("doc.type.picType");
                    System.out.println("配置文件项目类型："+itemType);
                    System.out.println("顶层的项目类型内部名："+typeName);
                    System.out.println("是否为同项目类型"+typeName.equals(itemType) );
                    System.out.println("是否为同编号"+(topParentPart.getNumber()).equals(itemNumber));

                    if (typeName.equals(itemType) && (topParentPart.getNumber()).equals(itemNumber)) {
                        System.out.println("过滤之后："+fatherPart.getNumber());
                        List<WTPartUsageLink> wtPartUsageLink = getWtPartUsageLink(fatherPart, part);

                        //将数据包裹一行
                        JsonWTPart jsonWTPart = new JsonWTPart();
                        jsonWTPart.setFatherNumber(fatherPart.getNumber());
                        jsonWTPart.setFatherName(fatherPart.getName());
                        jsonWTPart.setWtPartUsageLink(wtPartUsageLink.get(0).toString());
                        jsonWTPart.setFatherLifeStatue(fatherStatue);

                        faPartResult.add(jsonWTPart);
                    }
                }
            }


            String faPartJson = objectMapper.writeValueAsString(faPartResult);

            System.out.println(faPartJson);
            //数组转为json
            String returnJson = faPartJson;
            // 设置响应内容类型为 JSON
            response.reset();
            response.setContentType("application/json;charset=utf-8");
            response.setContentType("text/html;charset=UTF-8");  //这句太重要了


            PrintWriter out = response.getWriter();
            out.print(returnJson);
            out.flush();
        }



    }


    /**
     * 获取部件的上层父部件
     *
     * @param part
     * @return
     */
    public static List<WTPart> getFatherParts(WTPart part, int depth) {
        List<WTPart> result = new ArrayList<>();
        String viewName = part.getViewName();
        try {
            wt.fc.QueryResult qr = StructHelper.service.navigateUsedByToIteration(part, true, new WhereUsedConfigSpec());
            while (qr.hasMoreElements()) {
                WTPart faPart = (WTPart) qr.nextElement();
                String fatherViewName = faPart.getViewName();
                if (fatherViewName.equals(viewName) && result.add(faPart)) {
//                    result.addAll(getFatherParts(faPart, depth - 1));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * 通过递归找到部件的BOM最上层部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getTopParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<>();
        try {
            if (part != null) {
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());
                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        list.addAll(getTopParentParts(childPart));
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();

        }
        return list;
    }


    /**
     * 通过递归找到部件上层指定编号的
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getPartsByItemNumber(WTPart part,String itemNumber) {
        List<WTPart> list = new ArrayList<>();
        try {
            if (part != null) {
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());
                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        if (itemNumber.equals(childPart.getNumber())){//指定项目编号的上层
                            list.add(childPart);
                            break;
                        }else {
                            list.addAll(getPartsByItemNumber(childPart,itemNumber));
                        }

                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();

        }
        return list;
    }


    /**
     * 根据子部件获取所有父部件之间的关联
     *
     * @param childPart
     * @return List<WTPartUsageLink>
     */
    @SuppressWarnings("deprecation")
    public static Set<WTPartUsageLink> getBomLinkByChildPart(WTPart childPart) {
        Set<WTPartUsageLink> list = new HashSet<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 通过父部件和子部件获取部件之间使用关系
     *
     * @param fatherPart
     * @param childPart
     * @return
     */
    public static List<WTPartUsageLink> getWtPartUsageLink(WTPart fatherPart, WTPart childPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier(fatherPart)));
                queryspec.appendAnd();
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


}