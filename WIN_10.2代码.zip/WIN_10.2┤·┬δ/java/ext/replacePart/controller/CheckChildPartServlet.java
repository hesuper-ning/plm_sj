package ext.replacePart.controller;

import ext.replacePart.jsonObject.JsonWTPart;
import ext.replacePart.server.CheckAndDelServer;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.util.WTException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 检验父子关系的控制器
 */

public class CheckChildPartServlet {


    ObjectMapper objectMapper = new ObjectMapper();
    private static final long serialVersionUID = 1L;
    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, WTException {

        System.out.println("进入检验父子部件关联关系接口");
        //查询关键词
        String fatherNumber = request.getParameter("fatherNumber");

        String childNumber = request.getParameter("childNumber");
        System.out.println("从request获取的fatherNumber"+fatherNumber);
        System.out.println("从request获取的childNumber"+childNumber);

        JsonWTPart jsonWTPart = CheckAndDelServer.checkLinkExists(fatherNumber, childNumber);

        String faPartJson = objectMapper.writeValueAsString(jsonWTPart);

        System.out.println(faPartJson);
        //数组转为json
        String returnJson = faPartJson;
        // 设置响应内容类型为 JSON
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(returnJson);
        out.flush();
    }

}
