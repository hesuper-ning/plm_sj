package ext.replacePart.controller;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import wt.util.WTException;
import wt.util.WTProperties;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class readExcel {
	private static final int START_ROW = 9;
	
	private static final int LAST_ROW = 100;
	
	private static final int B = 0;
	
	private static final int M = 3;
	
	public static String PDF_TEMP = "";
	
	
	public static void getExcelModel(InputStream inputStream) throws IOException, InvalidFormatException, WTException {
		// 从文件系统中读取 Excel 文件
//		File excelFile = new File(PDF_TEMP);
//		InputStream inputStream = new FileInputStream(excelFile);
		
		// 使用 WorkbookFactory 创建 Workbook 对象
		Workbook workbook = WorkbookFactory.create(inputStream);
		
		// 获取要读取的工作表
		Sheet sheet = workbook.getSheetAt(0); // 例如，这里选择第一个工作表
		System.out.println("获取读取的工作表："+sheet!=null);
		List<WTPartSubstituteLinkVo> WTPartSubstituteLinkList = readExcel(sheet);
		
		for (WTPartSubstituteLinkVo wTPartSubstituteLinkVo : WTPartSubstituteLinkList) {
			String fatherNumber = wTPartSubstituteLinkVo.getFatherNumber();
			String sonNumber = wTPartSubstituteLinkVo.getSonNumber();
			String modificationType = wTPartSubstituteLinkVo.getModificationType();
			String substituteNumber = wTPartSubstituteLinkVo.getSubstituteNumber();
			System.out.println("WTPartSubstituteLinkVo对象："+wTPartSubstituteLinkVo);
			WTPartSubstituteLinkUtil.batchReplaceSubstitute(fatherNumber, sonNumber, modificationType, substituteNumber);
		}
	}
	
	/**
	 * 读取
	 *
	 * @param sheet
	 * @return
	 */
	public static List<WTPartSubstituteLinkVo> readExcel(Sheet sheet) {
		List<WTPartSubstituteLinkVo> res = new ArrayList<>();
		List<List<String>> data = new ArrayList<>();
		int lastRowNum = sheet.getLastRowNum() -1;
		System.out.println("最后一行减1为："+ lastRowNum);
		try {
			for (int i = START_ROW; i < lastRowNum; i++) {
				Row row = sheet.getRow(i);
				List<String> rowData = new ArrayList<>();
				
				for (int j = B; j <= M; j++) {
					Cell cell = row.getCell(j);
					if (1 == cell.getCellType()) {
						System.out.println("01"+cell.getStringCellValue());
						rowData.add(cell.getStringCellValue());
					} else if (0 == cell.getCellType()) {
						System.out.println("02"+cell.getNumericCellValue());
						rowData.add(String.valueOf(cell.getNumericCellValue()));
					}
					
				}
				
				data.add(rowData);
			}
			// 拼接返回参数值
			for (int i = 0; i < data.size(); i++) {
				WTPartSubstituteLinkVo model = new WTPartSubstituteLinkVo();
				List<String> strings = data.get(i);
				for (int j = 0; j < strings.size(); j++) {
					String s = strings.get(j);
					
					switch (j) {
						case 0:
							model.setFatherNumber(s);
							break;
						case 1:
							model.setSonNumber(s);
							break;
						case 2:
							model.setModificationType(s);
							break;
						case 3:
							model.setSubstituteNumber(s);
							break;
					}
				}
				if (model.getFatherNumber()!=null){
					res.add(model);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
}
