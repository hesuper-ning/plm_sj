package ext.replacePart.controller;


import ext.replacePart.jsonObject.JsonWTPart;
import ext.replacePart.jsonObject.ResponseJsonVo;
import ext.replacePart.server.CheckAndDelServer;
import ext.replacePart.utils.CommonUtil;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.wip.WorkInProgressHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import static ext.replacePart.jsonObject.ResponseConstant.*;

/**
 * 删除替代料的接口
 */
public class DelSubPartServlet {
    ReferenceFactory refefence = new ReferenceFactory();

    private static final long serialVersionUID = 1L;
    ObjectMapper objectMapper = new ObjectMapper();

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, WTException, WTPropertyVetoException {
        String userName = SessionHelper.manager.getPrincipal().getName();
        String returnJson = "";
        ResponseJsonVo responseJsonVo = null;
        System.out.println("进入DelSubPartServlet");
        // 设置请求和响应的内容类型为JSON
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");

        // 读取请求体中的JSON数据
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        String jsonStr = sb.toString();
//        jsonStr = jsonStr.substring(1, jsonStr.length() - 1);
        System.out.println("打印post数据：" + jsonStr);
        //
        JsonWTPart[] objects = objectMapper.readValue(jsonStr, JsonWTPart[].class);

        // 检查父部件是否为检出状态
        String checkOutMsg = CheckAndDelServer.checkFatherPart(objects);
        if (checkOutMsg.length() > 2) {
            responseJsonVo = new ResponseJsonVo(BATCH_CHECK_OUT, checkOutMsg, null);
            returnJson = objectMapper.writeValueAsString(responseJsonVo);
            response.reset();
            response.setContentType("application/json;charset=utf-8");
            response.setContentType("text/html;charset=UTF-8");  //这句太重要了
            PrintWriter out = response.getWriter();
            out.print(returnJson);
            out.flush();
            return;
        }


        for (JsonWTPart object : objects) {
            WTPart fatherPart = DoBatchAddReplacePartServlet.getWTPartByNumber(object.getFatherNumber());
            WTPart chickOutPart = (WTPart) WorkInProgressHelper.service.checkout(fatherPart, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
            // 获取检出的父部件与子部件的连接
            WTPartUsageLink oldUsageLink = (WTPartUsageLink) refefence.getReference(object.getWtPartUsageLink()).getObject();
            String sonPartNumber = oldUsageLink.getUses().getNumber();
            // 获取被检出的父部件与子部件的连接
            List<WTPartUsageLink> wtPartUsageLink = DoBatchAddReplacePartServlet.getWtPartUsageLink(chickOutPart, DoBatchAddReplacePartServlet.getWTPartByNumber(sonPartNumber));

            for (WTPartUsageLink useLink : wtPartUsageLink) {
                List<WTPartSubstituteLink> wtPartSubstituteLinks = WTPartSubstituteLinkUtil.getWTPartSubstituteLinks(useLink);
                for (WTPartSubstituteLink subLink : wtPartSubstituteLinks) {
                    WTPartMaster substitutesMaster = subLink.getSubstitutes();
                    if (object.getSubstituteNumber().equals(substitutesMaster.getNumber())) {

                        PersistenceHelper.manager.delete(subLink);
                    }
                }
            }
//            chickOutPart.setOwnership(CommonUtil.getOwnershipByName(userName));
            // 检入父部件
            responseJsonVo = new ResponseJsonVo(BATCH_Delete_SUBSTITUTE_SUCCESS, "删除成功！", null);
            WorkInProgressHelper.service.checkin(chickOutPart, "批量删除" + object.getSubstituteNumber() + "_" + object.getSubstituteName() + "替代料");
        }

        returnJson = objectMapper.writeValueAsString(responseJsonVo);

        // 设置响应内容类型为 JSON
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了


        PrintWriter out = response.getWriter();
        out.print(returnJson);
        out.flush();
    }

}
