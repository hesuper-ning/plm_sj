package ext.replacePart.controller;

public class WTPartSubstituteLinkVo {
	public String fatherNumber;
	
	
	public String sonNumber;
	
	public String modificationType;
	
	public String substituteNumber;
	
	
	public String getFatherNumber() {
		return fatherNumber;
	}
	
	public void setFatherNumber(String fatherNumber) {
		this.fatherNumber = fatherNumber;
	}
	
	
	public String getSonNumber() {
		return sonNumber;
	}
	
	public void setSonNumber(String sonNumber) {
		this.sonNumber = sonNumber;
	}
	
	
	public String getModificationType() {
		return modificationType;
	}
	
	public void setModificationType(String modificationType) {
		this.modificationType = modificationType;
	}
	
	public String getSubstituteNumber() {
		return substituteNumber;
	}
	
	public void setSubstituteNumber(String substituteNumber) {
		this.substituteNumber = substituteNumber;
	}

	@Override
	public String toString() {
		return "WTPartSubstituteLinkVo{" +
				"fatherNumber='" + fatherNumber + '\'' +
				", sonNumber='" + sonNumber + '\'' +
				", modificationType='" + modificationType + '\'' +
				", substituteNumber='" + substituteNumber + '\'' +
				'}';
	}
}
