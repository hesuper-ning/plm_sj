package ext.replacePart.test;

import com.ptc.windchill.enterprise.object.WhereUsedConfigSpec;

import ext.replacePart.jsonObject.JsonWTPart;
import ext.replacePart.utils.PartUtil;
import ext.replacePart.utils.PersistenceUtil;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.*;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 */
public class RemoteTest95 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;

    public static void main(String[] args) throws WTRuntimeException, WTException {
//		ReferenceFactory rf = new ReferenceFactory();
//		WTDocument doc = (WTDocument) rf.getReference("OR:wt.doc.WTDocument:1796110").getObject();
//		WTPart part = (WTPart) rf.getReference("OR:wt.part.WTPart:1939296").getObject();
//		EPMDocument epm = (EPMDocument) rf.getReference("OR:wt.epm.EPMDocument:1833683").getObject();
//		WTChangeRequest2 ecr = (WTChangeRequest2) rf.getReference("OR:wt.change2.WTChangeRequest2:2113629").getObject();
//		WorkItem wi = (WorkItem) rf.getReference("OR:wt.workflow.work.WorkItem:2538761").getObject();
//		PlanActivity planActivity = (PlanActivity) rf
//				.getReference("OR:com.ptc.projectmanagement.plan.PlanActivity:849396").getObject();
        String str = (String) invoke("process", RemoteTest95.class.getName(), null, new Class[]{}, new Object[]{});


    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String process() {
        try {

            LinkedHashSet hs = new LinkedHashSet();
            LinkedHashSet usaLink = new LinkedHashSet();

            String oRbyVR = PartUtil.getORbyVR("VR:wt.part.WTPart:362909");
            ReferenceFactory refefence = new ReferenceFactory();
            //通过or获取到部件
            WTPart part = (WTPart) refefence.getReference(oRbyVR).getObject();

            System.out.println("001==" + part.getNumber());
            List<WTPart> fatherParts = getFatherParts(part, 1);
            System.out.println("所有父部件长度："+fatherParts.size());
            for (WTPart fatherPart : fatherParts) {
                System.out.println("002==" + fatherPart.getNumber());
                List<WTPart> topParentParts = getTopParentParts(fatherPart);
                for (WTPart topParentPart : topParentParts) {
                    System.out.println("003==" + topParentPart.getNumber());
                    String typeName = PersistenceUtil.getTypeName(topParentPart);
                    if (typeName.equals("CN.CREOLIVE.ProjectPart")&& (topParentPart.getNumber()).equals("0000000123")){

                        List<WTPartUsageLink> wtPartUsageLink = getWtPartUsageLink(fatherPart, part);
                        usaLink.add(wtPartUsageLink.get(0));

                        //获取使用关系
                        hs.add(fatherPart.getNumber());
                        hs.add(fatherPart.getName());
//                        hs.add(usaLink);
                    }
                }
            }

            String s2 = new ObjectMapper().writeValueAsString(hs);
            System.out.println(s2);


//            String substituteNumber = "123456";

            //获取替代料部件
//            WTPart substitutePart = getWTPartByNumber(substituteNumber);

            //插入到关系表中
//            WTPartSubstituteLink.newWTPartSubstituteLink()
//            WTPartSubstituteLink wtPartSubstituteLink = WTPartSubstituteLink.newWTPartSubstituteLink(usageLink, substitutePart.getMaster());

//            PersistenceHelper.manager.save(wtPartSubstituteLink);

//            String jsonData = "[{\"fatherNumber\": \"04.1.12555\", \"fatherName\": \"test3\", \"substituteNumber\": \"1\", \"substituteName\": \"1\", \"wtPartUsageLink\": \"wt.part.WTPartUsageLink:444756\"}, {\"fatherNumber\": \"02.16.0505\", \"fatherName\": \"电池盖加工组件-TA-1580 SS Australia（午夜黑）3\", \"substituteNumber\": \"1\", \"substituteName\": \"1\", \"wtPartUsageLink\": \"wt.part.WTPartUsageLink:466430\"}]";
//            System.out.println(jsonData);
//
//            ObjectMapper objectMapper = new ObjectMapper();
//            List<JsonWTPart> partUsageLinks = null;
//
//            partUsageLinks= objectMapper.readValue(jsonData, new TypeReference<List<JsonWTPart>>() {});
//
//            for (JsonWTPart partUsageLink : partUsageLinks) {
//
//                System.out.println(partUsageLink);
//            }


        } catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }


        /**
         * 获取部件的上层父部件
         *
         * @param part
         * @return
         */
        public static List<WTPart> getFatherParts (WTPart part,int depth){
            List<WTPart> result = new ArrayList<>();
            String viewName = part.getViewName();
            try {
                QueryResult qr = StructHelper.service.navigateUsedByToIteration(part, true, new WhereUsedConfigSpec());
                while (qr.hasMoreElements()) {
                    WTPart faPart = (WTPart) qr.nextElement();
                    String fatherViewName = faPart.getViewName();
                    if (fatherViewName.equals(viewName) && result.add(faPart)) {
//                    result.addAll(getFatherParts(faPart, depth - 1));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return result;
        }


        /**
         * 通过递归找到部件的BOM最上层部件
         *
         * @param part
         * @return List<WTPart>
         */
        public static List<WTPart> getTopParentParts (WTPart part){
            List<WTPart> list = new ArrayList<WTPart>();
            try {
                if (part != null) {
                    QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());
                    if (!qr.hasMoreElements()) {
                        list.add(part);
                    } else {
                        while (qr.hasMoreElements()) {
                            WTPart childPart = (WTPart) qr.nextElement();
                            list.addAll(getTopParentParts(childPart));
                        }
                    }
                }
            } catch (WTException e) {
                e.printStackTrace();
            }
            return list;
        }


        /**
         * 根据子部件获取所有父部件之间的关联
         *
         * @param childPart
         * @return List<WTPartUsageLink>
         */
        @SuppressWarnings("deprecation")
        public static List<WTPartUsageLink> getBomLinkByChildPart (WTPart childPart){
            List<WTPartUsageLink> list = new ArrayList<>();
            try {
                if (childPart != null) {
                    QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                    queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                            PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                    QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                    while (qr.hasMoreElements()) {
                        WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                        list.add(usageLink);
                    }
                }
            } catch (WTException e) {
                e.printStackTrace();
            }
            return list;
        }

        /**
         * 通过父部件和子部件获取部件之间使用关系
         *
         * @param fatherPart
         * @param childPart
         * @return
         */
        public static List<WTPartUsageLink> getWtPartUsageLink (WTPart fatherPart, WTPart childPart){
            List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
            try {
                if (childPart != null) {
                    QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                    queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                            PersistenceHelper.getObjectIdentifier(fatherPart)));
                    queryspec.appendAnd();
                    queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                            PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                    QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                    while (qr.hasMoreElements()) {
                        WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                        list.add(usageLink);
                    }
                }
            } catch (WTException e) {
                e.printStackTrace();
            }
            return list;
        }

        /**
         * 根据编号查询part
         *
         * @param number
         * @return WTPart
         */
        @SuppressWarnings("deprecation")
        public static WTPart getWTPartByNumber (String number){
            WTPart result = null;
            QueryResult qr = null;
            try {
                QuerySpec qs = new QuerySpec(WTPart.class);
                SearchCondition scnumber = new SearchCondition(WTPart.class, wt.part.WTPart.NUMBER, SearchCondition.EQUAL,
                        number.toUpperCase());
                qs.appendSearchCondition(scnumber);
                qs.appendAnd();
                SearchCondition sclatest = VersionControlHelper.getSearchCondition(wt.part.WTPart.class, true);
                qs.appendSearchCondition(sclatest);
                qr = PersistenceHelper.manager.find(qs);
                LatestConfigSpec cfg = new LatestConfigSpec();
                QueryResult qr1 = cfg.process(qr);
                if (qr1 != null && qr1.hasMoreElements()) {
                    result = (WTPart) qr1.nextElement();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

    }
