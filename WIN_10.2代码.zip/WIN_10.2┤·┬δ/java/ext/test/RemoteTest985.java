package ext.test;

import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.core.meta.common.impl.TypeIdentifierUtilityHelper;
import org.apache.commons.lang.StringUtils;
import wt.epm.*;
import wt.fc.*;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.AbstractValue;
import wt.iba.value.IBAHolder;
import wt.iba.value.StringValue;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.Typed;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.WorkInProgressHelper;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 */
public class RemoteTest985 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;

    public static void main(String[] args) throws WTRuntimeException, WTException {
        String str = (String) invoke("process", RemoteTest985.class.getName(), null, new Class[]{}, new Object[]{});

    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String process() {
        WTPart result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr = cfg.process(qr);
            System.out.println("查询的个数是：" + qr.size());
            while (qr.hasMoreElements()) {
                WTPart part = (WTPart) qr.nextElement();
                if (!WorkInProgressHelper.isCheckedOut(part)) {
                    WorkInProgressHelper.service.checkout(part, WorkInProgressHelper.service.getCheckoutFolder(), null);
                }
                if (!WorkInProgressHelper.isWorkingCopy(part)) {
                    part = (WTPart) WorkInProgressHelper.service.workingCopyOf(part);
                }
                System.out.println(part.getNumber() + "当前物料的父级数量是：" + getParentParts(part).size());
                if (getParentParts(part).size() > 10) {
                    setIBA(part, "reusingLevel", "B");
                } else {
                    setIBA(part, "reusingLevel", "A");
                }
                if (WorkInProgressHelper.isCheckedOut(part)) {
                    WorkInProgressHelper.service.checkin(part, null);
                }
                System.out.println("处理完成");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //获取内部名称
    public static String getTypeInternalName(Typed typed_object) throws WTException {
        String name = null;
        try {
            TypeIdentifier type = TypeIdentifierUtilityHelper.service.getTypeIdentifier(typed_object);
            TypeDefinitionReadView trv = TypeDefinitionServiceHelper.service.getTypeDefView(type);
            name = trv.getName();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        }
        return name;
    }


    public static EPMDocument getEPMByNumber(String number) {
        try {
            if (StringUtils.isBlank(number)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(EPMDocument.class);
            qs.appendWhere(
                    new SearchCondition(EPMDocument.class, EPMDocument.CADNAME, SearchCondition.EQUAL, number));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            System.out.println("查询的相关个数是：" + qr.size());
            if (qr.hasMoreElements()) {
                EPMDocument doc = (EPMDocument) qr.nextElement();
                return doc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getIBAValue(IBAHolder holder, String ibaName) throws WTException {
        AttributeDefDefaultView addv = null;
        try {
            addv = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
        } catch (RemoteException e) {
            throw new WTException(e);
        }
        if (addv == null) {
            throw new WTException("undefined iba name :" + ibaName);
        }
        long ibaDefId = addv.getObjectID().getId();

        QuerySpec qs = new QuerySpec(StringValue.class);
        qs.appendWhere(new SearchCondition(StringValue.class,
                AbstractValue.IBAHOLDER_REFERENCE + "." + ObjectReference.KEY + "." + ObjectIdentifier.ID,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier((Persistable) holder).getId()), new int[]{0});
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(StringValue.class, StringValue.DEFINITION_REFERENCE + "."
                + ObjectReference.KEY
                + "." + ObjectIdentifier.ID, SearchCondition.EQUAL, ibaDefId), new int[]{0});

        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
        StringValue sv = null;
        if (qr.hasMoreElements()) {
            sv = (StringValue) qr.nextElement();
        }
        return sv == null ? null : sv.getValue();
    }

    public static void setIBA(Persistable persistable, String ibaName, String value) throws WTException {

        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        normalizedObject.set(ibaName, value);
        persistable = normalizedObject.apply();
        PersistenceHelper.manager.modify(persistable);
    }

    /**
     * 找到部件的BOM上层部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            if (part != null) {
                //查到的是什么
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());

                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        list.add(childPart);
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

}