package ext.test.controller;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 *  Java Lib For PLM, Powered By NanJing WITSOFT.
 *  <p>
 *  <a href="http://www.witsoft.cn/">南京维拓科技股份有限公司</a>
 *
 *  @Company: Copyright © 2021 - 2025 Cld , All Rights Reserved 南京维拓科技股份有限公司 版权所有  苏ICP备12026267号-1
 *
 *  @PackageName: ext.fasteaton.pbom.controller
 *  @FileName: MaintainDataController.java
 *  @ClassPath: ext.fasteaton.pbom.controller.MaintainDataController.java
 *
 *  @ClassName: MaintainDataController
 *  @Description: 维护采购/工位/虚拟件信息的接口
 *  @Author: dangz
 *  @Date: 2024/08/06 18:55
 **/
@Controller
@RequestMapping({ "/MaintainData" })
public class MaintainDataController {

	/**
	 * @Description 前端获取EBOM/PBOM信息接口
	 * <p>
	 * 根据视图来分别获取两个不同的BOM信息，其中大致信息相同，不同视图会有如同 采购制造属性，工位号等参数的不同
	 * @param topPartOid BOM顶层部件oid
	 * @throws IOException e
	 * @author dangz
	 * @Date 2024/08/06 18:56
	 */
	@ResponseBody
	@RequestMapping(value = "/queryBom", method = RequestMethod.GET)
	public String  queryBom(@RequestParam("topPartOid") String topPartOid,HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		System.out.println("查询BOM"+topPartOid);
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding("UTF-8");
//		List<String> topPartOids = CommonUtil.getEntitiesFromJson(topPartOid, String.class, "topPartOid");
//		// 判断url后缀是否存在
//		if (topPartOids.isEmpty()) {
//			response.getWriter().println(CommonUtil.parseJson(Result.error("topPartOid不能为空,请选择一个BOM", null)));
//		} else {
//			String json = MaintainDataService.queryBom(topPartOids.get(0));
//			response.getWriter().println(json);
//		}

		return topPartOid;
	}


	@RequestMapping(value = "/queryPart", method = RequestMethod.GET)
	public void queryPart(@RequestBody String topPartOid, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding("UTF-8");
		System.out.println("查询Part"+topPartOid);
	}

	/**
	 * @Description 前端访问接口，维护采购制造属性
	 * @param sourceParts 采购制造件信息bean对象
	 * @param request request
	 * @param response response
	 * @throws IOException e
	 * @author dangz
	 * @Date 2024/08/06 18:58
	 */
	@RequestMapping(value = "/source", method = RequestMethod.POST)
	public void maintainSource(@RequestBody String sourceParts, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding("UTF-8");
//		List<SourceBean> sourceBeans = CommonUtil.getEntitiesFromJson(sourceParts, SourceBean.class, "");
//		String json = MaintainDataService.maintainSource(sourceBeans);
//		response.getWriter().println(json);
	}

	/**
	 * @Description 前端访问接口，维护PBOM工位信息
	 *
	 * @param processNumberParts 工位信息列表
	 * @param request            request
	 * @param response           response
	 * @throws IOException e
	 * @author dangz
	 * @Date 2024/07/25 13:59
	 */
	@RequestMapping(value = "/processNumber", method = RequestMethod.POST)
	public void maintainProcessNumber(@RequestBody String processNumberParts, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding("UTF-8");
//		List<ProcessNumberBean> processNumberBeans = CommonUtil.getEntitiesFromJson(processNumberParts,
//				ProcessNumberBean.class, "");
//		String json = MaintainDataService.maintainProcessNumber(processNumberBeans);
//		response.getWriter().println(json);
	}

	/**
	 * @Description 前端访问接口，维护虚拟件信息
	 *
	 * @param virtualParts 虚拟件信息列表
	 * @param request      request
	 * @param response     response
	 * @throws IOException e
	 * @author dangz
	 * @Date 2024/07/25 14:00
	 */
	@RequestMapping(value = "/virtualParts", method = RequestMethod.POST)
	public void maintainVirtualParts(@RequestBody String virtualParts, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding("UTF-8");
//		List<VirtualBean> virtualBeans = CommonUtil.getEntitiesFromJson(virtualParts, VirtualBean.class, "");
//		String json = MaintainDataService.maintainVirtualParts(virtualBeans);
//		response.getWriter().println(json);
	}
}
