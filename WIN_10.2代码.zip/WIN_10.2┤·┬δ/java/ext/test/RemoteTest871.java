package ext.test;
 
import org.apache.commons.lang.StringUtils;
import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.config.LatestConfigSpec;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 */
public class RemoteTest871 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;

    public static void main(String[] args) throws WTRuntimeException, WTException {
        String str = (String) invoke("process", RemoteTest871.class.getName(), null, new Class[]{}, new Object[]{});

    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String process() {
        try {
            WTContainer container = getWTContainByName("HIP Test");
            WTContainerRef c_ref = WTContainerRef.newWTContainerRef(container);
            Folder folder = FolderHelper.service.getFolder("/Default/部件", c_ref);
            System.out.println("文件夹信息" + folder.getFolderPath() + folder.getContainerDisplayName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public static EPMDocument getEPMByNumber(String number) {
        try {
            if (StringUtils.isBlank(number)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(EPMDocument.class);
            qs.appendWhere(
                    new SearchCondition(EPMDocument.class, EPMDocument.NUMBER, SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                EPMDocument doc = (EPMDocument) qr.nextElement();
                return doc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public static WTContainer getWTContainByName(String name) {
        WTContainer result = null;
        try {
            if (StringUtils.isBlank(name)) {
                return result;
            }
            QuerySpec qs = new QuerySpec(WTContainer.class);
            SearchCondition scnumber = new SearchCondition(WTContainer.class, WTContainer.NAME, SearchCondition.LIKE, name);
            qs.appendWhere(scnumber);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            if (qr != null && qr.hasMoreElements()) {
                result = (WTContainer) qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}