package ext.test;
import com.ptc.core.lwc.server.PersistableAdapter;
import org.apache.commons.lang.StringUtils;
import wt.epm.*;
import wt.fc.*;
import wt.folder.Folder;
import wt.folder.FolderHelper;

import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;

import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;

import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.vc.config.LatestConfigSpec;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 */
public class RemoteTest865 implements RemoteAccess, Serializable {

    public static Object getIBAValue2(Persistable targetObj, String ibaName) {
        Object value = null;
        try {
            PersistableAdapter obj = new PersistableAdapter(targetObj, null, SessionHelper.getLocale(), null);
            obj.load(ibaName);
            value = obj.get(ibaName);
        } catch (WTException e) {
            e.printStackTrace();
        }
        return value;
    }

    private static final long serialVersionUID = 1L;

    public static void main(String[] args) throws WTRuntimeException, WTException {
        String str = (String) invoke("process", RemoteTest865.class.getName(), null, new Class[]{}, new Object[]{});

    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }

    //String number = "0000000021";
    //WTPart parentPart = getWTPartByNumber(number);
    //String ibaLegalList = getIBALegalList(parentPart, "cn.alphai.test3");
    //Boolean ibaInfo = isIBA(parentPart, "com.apollo.Trading_properties");
    //System.out.println("正确？：" + ibaInfo);
    public static String process() {
        try {
            EPMDocument epm = getEPMByNumber("0000000101.SLDASM");
            Folder folder = FolderHelper.service.getFolder(epm);
            System.out.println("保存的文件夹位置为：" + epm.getContainer().getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

//    public static String getLinkIBAInfo(WTPartUsageLink link, String ibaName) throws WTException {
//        Locale locale = Locale.getDefault();
//        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(link, null, locale, new UpdateOperationIdentifier());
//        normalizedObject.load(ibaName);
//        Object result = normalizedObject.get(ibaName);
//        return result == null ? null : result.toString();
//    }
//
//    public static void saveFile(InputStream inputStream, String filePath) throws IOException {
//        File file = new File(filePath);
//        File parentDir = file.getParentFile();
//        if (parentDir != null && !parentDir.exists()) {
//            if (parentDir.mkdirs()) {
//                System.out.println("Directories created successfully.");
//            } else {
//                throw new IOException("Failed to create directories.");
//            }
//        }
//        try (OutputStream outputStream = new FileOutputStream(filePath)) {
//            byte[] buffer = new byte[1024];
//            int bytesRead;
//            while ((bytesRead = inputStream.read(buffer)) != -1) {
//                outputStream.write(buffer, 0, bytesRead);
//            }
//        }
//    }
//
//    // 获取内部名称对应的显示名称
//    public static String getDisplayName(Persistable part, String internalName) throws WTException {
//        TypeIdentifier serialNumberManagement = TypeIdentifierUtility.getTypeIdentifier(internalName);
//        String typename = serialNumberManagement.getTypename();
//        Locale locale = Locale.getDefault();
//        LWCNormalizedObject obj = new LWCNormalizedObject(part, null, locale, null);
//        obj.load(internalName);
//        return obj.getAttributeDescriptor(internalName).getLabel();
//    }
//
//    public static String getInternalDisplayName(Persistable persistable, String ibaName) throws Exception {
//        String displayName = "";
//        TypeIdentifier typeIden = TypeIdentifierUtility.getTypeIdentifier(persistable); // unsupported API
//        TypeDefinitionReadView tdrv = TypeDefinitionServiceHelper.service.getTypeDefView(typeIden);
//        if (tdrv != null) {
//            AttributeDefinitionReadView attView = tdrv.getAttributeByName(ibaName); // att1 is attribute name
//            if (attView != null) {
//                displayName = PropertyHolderHelper.getDisplayName(attView, SessionHelper.manager.getLocale());
//                // LOGGER.debug("display Name:" + displayName);
//                // LOGGER.debug("attView Name:" + attView.getName());
//            }
//        }
//        return displayName;
//    }
//
//
//    public static String getClsValue(Persistable persistable, String typeName) throws WTException {
//        PersistableAdapter obj = new PersistableAdapter(persistable, null, SessionHelper.getLocale(), new UpdateOperationIdentifier());
//        obj.load(typeName);
//        Object result = obj.get(typeName);
//        return result == null ? "" : result.toString();
//    }
//
//
//    public static String setClsValue(Persistable persistable, String typeName) throws WTException {
//        PersistableAdapter obj = new PersistableAdapter(persistable, null, SessionHelper.getLocale(), new UpdateOperationIdentifier());
//        obj.load(typeName);
//        Object result = obj.set(typeName, "77777");
//        obj.apply();
//        obj.persist();
//        return result == null ? "" : result.toString();
//    }
//
//    public static List<Object> jsonArrayToList(JSONArray jsonArray) {
//        List<Object> list = new ArrayList<>();
//
//        try {
//            for (int i = 0; i < jsonArray.length(); i++) {
//                list.add(jsonArray.get(i));
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        return list;
//    }
//
//    public static List<WTPart> getPartByRefrenceDoc(EPMDocument doc) {
//        QueryResult qr = null;
//        WTPart part = null;
//        List<WTPart> list = new ArrayList<WTPart>();
//        try {
//            qr = StructHelper.service.navigateReferencedBy(doc.getMaster());// 参考关系
//            while (qr.hasMoreElements()) {
//                Object obj = qr.nextElement();
//                if (obj instanceof WTPart) {
//                    part = (WTPart) obj;
//                    list.add(part);
//                }
//            }
//        } catch (WTException e) {
//            e.printStackTrace();
//        }
//        return list;
//    }
//
//    public static WTUser getWTUserByOid(String oid) {
//        WTUser result = null;
//        QueryResult qr = null;
//        try {
//            ReferenceFactory referencefactory = new ReferenceFactory();
//            WTReference wtreference = referencefactory.getReference(oid);
//            Persistable persistable = wtreference.getObject();
//            if (persistable instanceof WTUser) {
//                result = (WTUser) wtreference.getObject();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return result;
//    }
//
//    public static WTUser getWTUserByName(String number) {
//        WTUser result = null;
//        QueryResult qr = null;
//        try {
//            QuerySpec qs = new QuerySpec(WTUser.class);
//            SearchCondition scnumber = new SearchCondition(WTUser.class, WTUser.NAME, SearchCondition.EQUAL,
//                    number);
//            qs.appendWhere(scnumber);
//            qr = PersistenceHelper.manager.find(qs);
//            if (qr != null && qr.hasMoreElements()) {
//                result = (WTUser) qr.nextElement();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return result;
//    }
//
//    private static WTContainer getWTContainByOid(String oid) {
//        WTContainer result = null;
//        try {
//            if (StringUtils.isBlank(oid)) {
//                return result;
//            }
//            QuerySpec qs = new QuerySpec(WTContainer.class);
//            SearchCondition scnumber = new SearchCondition(WTContainer.class, WTContainer.NAME, SearchCondition.LIKE, oid);
//            qs.appendWhere(scnumber);
//            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
//            if (qr != null && qr.hasMoreElements()) {
//                result = (WTContainer) qr.nextElement();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return result;
//    }
//
//    private static WTContainerRef getWTContainerRefByName(String name) {
//        WTContainerRef result = null;
//        try {
//            if (StringUtils.isBlank(name)) {
//                return result;
//            }
//            QuerySpec qs = new QuerySpec(WTContainerRef.class);
//            SearchCondition scnumber = new SearchCondition(WTContainerRef.class, WTContainerRef.NAME, SearchCondition.EQUAL, name);
//            qs.appendWhere(scnumber);
//            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
//            if (qr != null && qr.hasMoreElements()) {
//                result = (WTContainerRef) qr.nextElement();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return result;
//    }
//
//    public static String queryInfo(String info) {
//        if (info == null || info.equals(""))
//            return "属性缺失";
//        return info;
//    }
//
//    public static String getTypeInternalName(Typed typed_object) throws WTException {
//        String name = null;
//        try {
//            TypeIdentifier type = TypeIdentifierUtilityHelper.service.getTypeIdentifier(typed_object);
//            TypeDefinitionReadView trv = TypeDefinitionServiceHelper.service.getTypeDefView(type);
//            name = trv.getName();
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new WTException(e);
//        }
//        return name;
//    }
//
//    public static WTPart getWTPartByNumber(String number) {
//        WTPart result = null;
//        try {
//            if (StringUtils.isBlank(number)) {
//                return result;
//            }
//            QuerySpec qs = new QuerySpec(WTPart.class);
//            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, number);
//            qs.appendSearchCondition(scnumber);
//            QueryResult qr = PersistenceHelper.manager.find(qs);
//            LatestConfigSpec cfg = new LatestConfigSpec();
//            qr = cfg.process(qr);
//            if (qr != null && qr.hasMoreElements()) {
//                result = (WTPart) qr.nextElement();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return result;
//    }
//
//    public static String getIBAValue(IBAHolder holder, String ibaName) throws WTException {
//        AttributeDefDefaultView addv = null;
//        try {
//            addv = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
//        } catch (RemoteException e) {
//            throw new WTException(e);
//        }
//        if (addv == null) {
//            throw new WTException("undefined iba name :" + ibaName);
//        }
//        long ibaDefId = addv.getObjectID().getId();
//
//        QuerySpec qs = new QuerySpec(StringValue.class);
//        qs.appendWhere(new SearchCondition(StringValue.class,
//                AbstractValue.IBAHOLDER_REFERENCE + "." + ObjectReference.KEY + "." + ObjectIdentifier.ID,
//                SearchCondition.EQUAL,
//                PersistenceHelper.getObjectIdentifier((Persistable) holder).getId()), new int[]{0});
//        qs.appendAnd();
//        qs.appendWhere(new SearchCondition(StringValue.class, StringValue.DEFINITION_REFERENCE + "."
//                + ObjectReference.KEY
//                + "." + ObjectIdentifier.ID, SearchCondition.EQUAL, ibaDefId), new int[]{0});
//
//        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
//        StringValue sv = null;
//        if (qr.hasMoreElements()) {
//            sv = (StringValue) qr.nextElement();
//        }
//        return sv == null ? null : sv.getValue();
//    }
//
//    public static void getList2() throws Exception {
//        TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
//                "com.ptc.csm.default_clf_namespace", "cn.alphai.MachinePart");
//        AttributeDefinitionReadView adrv = clfNodeView.getAttributeByName("cn.alphai.test1");
//        Collection<ConstraintDefinitionReadView> a = adrv.getAllConstraints();
//        List<ConstraintDefinitionReadView> collect = a.stream().collect(Collectors.toList());
//        System.out.println("=====================================");
//        System.out.println(collect.size());
//        System.out.println("=====================================");
//        for (ConstraintDefinitionReadView cv : collect) {
//            String rule = cv.getRule().getKey().toString();
//            System.out.println("================" + rule + "==============");
//            ConstraintDefinitionReadView.RuleDataObject rdo = cv.getRuleDataObj();
//            if (rdo != null) {
//                System.out.println("开始输出1" + rdo.getEnumDef());
//                if (rdo.getEnumDef() == null)
//                    continue;
//                Collection<EnumerationEntryReadView> coll = rdo.getEnumDef().getAllEnumerationEntries().values();
//                Iterator<EnumerationEntryReadView> iterator = coll.iterator();
//                while (iterator.hasNext()) {
//                    EnumerationEntryReadView next = iterator.next();
//                    //内部名称
//                    String internalName = next.getName();
//                    System.out.println("当前的内部名称：" + internalName);
//                    PropertyValueReadView pv = next.getAllProperties().iterator().next();
//                    String displayName = pv.getValueAsString();
//                    System.out.println("当前的显示名称：" + displayName);
//
//                }
//            }
////if (cv.getRuleData() != null) {
////    String s = cv.getRuleData().toString();
////    if (!s.contains(",")) {
////        System.out.println("====1====" + cv.getRuleData().toString());
////    }
////}
//        }
//        System.out.println("=============>");
//    }
//
//    public static void getList3(Persistable part) throws Exception {
//        ArrayList<String> strings = new ArrayList<>();
//        String s = TypeIdentifierUtilityHelper.service.getTypeIdentifier(part).toString();
//        TypeIdentifier ti = TypedUtility.getTypeIdentifier(s);
//        TypeDefinitionReadView tv = TypeDefinitionServiceHelper.service.getTypeDefView(ti);
//        AttributeDefinitionReadView av = tv.getAttributeByName("cn.alphai.test1");
//        if (av != null) {
//            Collection<ConstraintDefinitionReadView> constraints = av.getAllConstraints();
//            for (ConstraintDefinitionReadView cdrv : constraints) {
//                ConstraintDefinitionReadView.RuleDataObject rdo = cdrv.getRuleDataObj();
//                if (rdo != null) {
//                    System.out.println(rdo.getEnumDef() != null ? "正确22" : "失败11");
//                    if (rdo.getEnumDef() == null)
//                        continue;
//                    System.out.println("rdo::::" + rdo.toString());
//                    Collection<EnumerationEntryReadView> values = rdo.getEnumDef().getAllEnumerationEntries().values();
//                    Iterator<EnumerationEntryReadView> iterator = values.iterator();
//                    while (iterator.hasNext()) {
//                        HashMap<String, String> map = new HashMap<>();
//                        EnumerationEntryReadView next = iterator.next();
//                        String name = next.getName();
//                        System.out.println("NAME:::" + name);
//                        String displayName = "";
//                        if (next.getPropertyValueByName("displayName") != null) {
//                            displayName = next.getPropertyValueByName("displayName").getValue().toString();
//                        } else if (next.getPropertyValueByName("产线") != null) {
//                            displayName = next.getPropertyValueByName("产线").getValue().toString();
//                        }
//                        System.out.println("NAME:::" + displayName);
//                        map.put(name, displayName);
//                        strings.add(name);
//                    }
//                }
//            }
//        } else {
//            System.out.println("方法失败");
//        }
//
//        System.out.println("=============>");
//        System.out.println("完成方法：" + strings.toString());
//    }
//
//    public static void getList() throws Exception {
//        SessionHelper.manager.setPrincipal("will");
//        Locale locale = SessionHelper.getLocale();
//
//        PersistableAdapter obj = new PersistableAdapter("cn.alphai.MachinePart", locale, OperationIdentifier.newOperationIdentifier(OperationIdentifierConstants.VIEW));
//        obj.load("SerialNumberManagement");
//        AttributeTypeSummary ats = obj.getAttributeDescriptor("SerialNumberManagement");
//        DataSet ds = ats.getLegalValueSet();
//        System.out.println(ds);
//        if (ds instanceof DiscreteSet) {
//            System.out.println(((DiscreteSet) ds).getElements().length);
//        }
//
//    }
//
//    //获取分类下的固定合法值列表值
//    public static String getList(String typeInternalName) throws Exception {
//        TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
//                "com.ptc.csm.default_clf_namespace", typeInternalName);
//        System.out.println("AAA2:" + clfNodeView);
//        AttributeDefinitionReadView adrv = clfNodeView.getAttributeByName("SerialNumberManagement");
//        Collection<ConstraintDefinitionReadView> a = adrv.getAllConstraints();
//        List<ConstraintDefinitionReadView> collect = collectionToList(a);
//        for (ConstraintDefinitionReadView cv : collect) {
//            if (cv.getRuleData() != null) {
//                String s = cv.getRuleData().toString();
//                if (!s.contains(",")) {
//                    return cv.getRuleData().toString();
//                }
//            }
//        }
//        return null;
//    }
//
//    public static List<ConstraintDefinitionReadView> collectionToList(Collection<ConstraintDefinitionReadView> collections) throws Exception {
//        if (collections == null)
//            return new ArrayList<ConstraintDefinitionReadView>();
//        List<ConstraintDefinitionReadView> list = new ArrayList<>(collections.size());
//        for (ConstraintDefinitionReadView view : collections) {
//            list.add(view);
//        }
//        return list;
//    }
//
//    public static Object[] getLegalSetBySofttypeIBA(String softtype,
//                                                    String attrname) throws WTException {
//        Object[] result = null;
//        try {
//            TypeIdentifier ti = TypedUtility.getTypeIdentifier(softtype);
//
//            TypeDefinitionReadView tv = TypeDefinitionServiceHelper.service
//                    .getTypeDefView(ti);
//            AttributeDefinitionReadView av = tv.getAttributeByName(attrname);
//            Collection<ConstraintDefinitionReadView> constraints = av
//                    .getAllConstraints();
//            for (ConstraintDefinitionReadView constraint : constraints) {
//                String rule = constraint.getRule().getKey().toString();
//                if (rule.indexOf("com.ptc.core.meta.container.common.impl.DiscreteSetConstraint") > -1) {
//                    ConstraintDefinitionReadView.RuleDataObject rdo = constraint.getRuleDataObj();
//                    if (rdo != null) {
//                        DiscreteSet data = (DiscreteSet) rdo.getRuleData();
//                        result = data.getElements();
//                        break;
//                    }
//                }
//            }
//        } catch (Exception e) {
//            throw new WTException(e, "Get Enumeration [" + attrname
//                    + "] for type [" + softtype + "] failed.");
//        }
//        return result;
//    }
//
//    public static String getIBALegalList(Persistable part, String typeInternalName) throws Exception {
//        String s = TypeIdentifierUtilityHelper.service.getTypeIdentifier(part).toString();
//        TypeIdentifier ti = TypedUtility.getTypeIdentifier(s);
//        TypeDefinitionReadView tv = TypeDefinitionServiceHelper.service.getTypeDefView(ti);
//        AttributeDefinitionReadView av = tv.getAttributeByName(typeInternalName);
//        Collection<ConstraintDefinitionReadView> a = av.getAllConstraints();
//        List<ConstraintDefinitionReadView> collect = a.stream().collect(Collectors.toList());
//        for (ConstraintDefinitionReadView cv : collect) {
//            if (cv.getRuleData() != null) {
//                String s2 = cv.getRuleData().toString();
//                if (!s2.contains(",")) {
//                    return cv.getRuleData().toString();
//                }
//            }
//        }
//        return null;
//    }
//
//    public static boolean isIBA(Persistable part, String typeInternalName) throws WTException, RemoteException {
//        String s = TypeIdentifierUtilityHelper.service.getTypeIdentifier(part).toString();
//        TypeIdentifier ti = TypedUtility.getTypeIdentifier(s);
//        TypeDefinitionReadView tv = TypeDefinitionServiceHelper.service.getTypeDefView(ti);
//        AttributeDefinitionReadView av = tv.getAttributeByName(typeInternalName);
//        return av == null ? false : true;
//    }
//
//    public static EPMDocument creatEPM() throws Exception {
//        // 创建一个空的EPMDocument对象，用于存储将要上传的文件信息。
//        EPMDocument epm = new EPMDocument();
//        // 设置上传文档的名称。
////        epm.setName("0001.SLDPRT");
////        // 设置文档的CAD名称。
////        epm.setCADName("0001.SLDPRT");
//        // 创建查询规范，用于查找指定名称的工作空间。
//        QuerySpec qs = new QuerySpec(EPMWorkspace.class);
//        // 添加查询条件，查找名称等于epmWorkspaceName的工作空间。
//        qs.appendWhere(new SearchCondition(EPMWorkspace.class, EPMWorkspace.NAME, SearchCondition.EQUAL, "TEST"), new int[]{0});
//        // 执行查询，获取指定名称的工作空间。
//        QueryResult qr = PersistenceServerHelper.manager.query(qs);
//        // 从查询结果中获取第一个（也是唯一一个）工作空间对象。
//        EPMWorkspace epmWorkspace = (EPMWorkspace) qr.nextElement();
//        // 设置文档的容器为查询到的工作空间。
//        epm.setContainer(epmWorkspace.getContainer());
//        // 创建一个新的应用数据对象，用于存储文件的实际内容。
//        ApplicationData data = ApplicationData.newApplicationData(epm);
//        // 设置应用数据的角色为PRIMARY，表示这是文档的主要内容。
//        data.setRole(ContentRoleType.PRIMARY);
//        // 创建一个File对象，用于操作文件。
//        File file = new File("E:/file/0002.SLDPRT");
//        // 设置应用数据的文件名为文件的实际名称。
//        data.setFileName(file.getName());
//        // 将文件的绝对路径转换为字符串，并编码为系统默认的字符集。
//        String string = new String(file.getAbsolutePath().getBytes("UTF-8"), System.getProperty("file.encoding"));
//        // 使用转换后的字符串更新应用数据的内容，并返回更新后的应用数据对象。
//        //        data = ContentServerHelper.service.updateContent(epm, data, string);
//        EPMDocument masterDoc = new EPMDocument();
//        ObjectReference objectReference = ObjectReference.newObjectReference(masterDoc);
//        epm.setMasterReference(objectReference);
//        System.out.println("新主参考文档设置成功");
//
//        return epm;
//    }
//
//    public static Persistable queryDoc(String number) throws WTException {
//        if (number.isEmpty()) {
//            throw new WTException("number为空！");
//        }
//        QuerySpec qs = new QuerySpec(EPMDocument.class);
//        qs.setAdvancedQueryEnabled(true);
//        SearchCondition sc = new SearchCondition(EPMDocument.class, EPMDocument.NUMBER, SearchCondition.EQUAL, number);
//        qs.appendWhere(sc);
//        QueryResult qr = PersistenceHelper.manager.find(qs);
//        while (qr.hasMoreElements()) {
//            return (EPMDocument) qr.nextElement();
//        }
//        return null;
//    }
//
//    private static WTContainer getWTContainByName(String name) {
//        WTContainer result = null;
//        try {
//            if (StringUtils.isBlank(name)) {
//                return result;
//            }
//            QuerySpec qs = new QuerySpec(WTContainer.class);
//            SearchCondition scnumber = new SearchCondition(WTContainer.class, WTContainer.NAME, SearchCondition.LIKE, name);
//            qs.appendWhere(scnumber);
//            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
//            if (qr != null && qr.hasMoreElements()) {
//                result = (WTContainer) qr.nextElement();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return result;
//    }
//
//
//    private static WTContainerRef getWTContainByName2(String name) {
//        WTContainerRef result = null;
//        try {
//            if (StringUtils.isBlank(name)) {
//                return result;
//            }
//            QuerySpec qs = new QuerySpec(WTContainerRef.class);
//            SearchCondition scnumber = new SearchCondition(WTContainerRef.class, WTContainerRef.NAME, SearchCondition.LIKE, name);
//            qs.appendWhere(scnumber);
//            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
//            if (qr != null && qr.hasMoreElements()) {
//                result = (WTContainerRef) qr.nextElement();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return result;
//    }
//
//    //  获取所有子集
//    public static void getAllChildren(WTPart part, ArrayList<WTPart> list) throws WTException {
//        if (part == null) {
//            throw new WTException("最高级part为空");
//        }
//        QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
//        while (qr.hasMoreElements()) {
//            WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
//            //获取子健
//            WTPartMaster partMaster = link.getUses();
//            WTPart child = getWTPartByNumber(partMaster.getNumber());
//            if (child.getName().contains("BOM部件名称")) {
//                list.add(child);
//            }
//            getAllChildren(child, list);
//        }
//    }
//
//
//
//    public static ApplicationData getEpmApplicationData(EPMDocument epm) throws WTException, PropertyVetoException {
//        ApplicationData applicationData = null;
//        if (epm.isInstance()) return applicationData;
//        if (epm.isTopGeneric()) {
//            QueryResult result1 = EPMStructureHelper.service.navigateContainedIn(epm, null, true);
//            EPMFamilyTable epmSepFamilyTable = (EPMFamilyTable) result1.nextElement();
//            ContentHolder holder = ContentHelper.service.getContents((ContentHolder) epmSepFamilyTable);
//            Vector dataVector = (Vector) ContentHelper.getContentListAll(holder);
//            for (int i = 0; i < dataVector.size(); i++) {
//                applicationData = (ApplicationData) dataVector.elementAt(i);
//            }
//        }
//        return applicationData;
//    }
//
//    public static String checkUser(String userName, String pass) {
//        try {
//            URL url = new URL(getRequestUrl());
//            String input = userName + ":" + pass;
//            String encoding = new BASE64Encoder().encode(input.getBytes());
//            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//            connection.setRequestProperty("Authorization", "Basic " + encoding);
//            int code = connection.getResponseCode();
//            if (code == 200) {
//                return "1";
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return "0";
//    }
//
//    public static String getRequestUrl() throws WTException {
//        try {
//            Properties wtproperties = WTProperties.getLocalProperties();
//            String hostname = wtproperties.getProperty("wt.rmi.server.hostname");
//            String webServerPort = wtproperties.getProperty("wt.webserver.port");
//            StringBuilder path = new StringBuilder();
//            path.append("http://").append(hostname).append(":").append(webServerPort).append("/Windchill");
//            return path.toString();
//        } catch (IOException e) {
//            e.printStackTrace();
//            throw new WTException(e.getLocalizedMessage());
//        }
//    }
//
//    /**
//     * 根据EPMDocument对象获取ApplicationData
//     *
//     * @param EPMDoc
//     * @return
//     * @throws WTException
//     * @throws PropertyVetoException
//     */
//    public static ApplicationData findPrimary(EPMDocument EPMDoc) throws WTException, PropertyVetoException {
//        System.out.println("Starting findPrimary");
//        System.out.println("==========");
//        ApplicationData primaryNotFound = null;
//        FormatContentHolder documentWithContents = (EPMDocument) ContentHelper.service.getContents(EPMDoc);
//        @SuppressWarnings("unchecked")
//        Vector<ContentItem> vector = ContentHelper.getContentList(documentWithContents);
//        vector.addElement(ContentHelper.getPrimary(documentWithContents));
//        for (int i = 0; i < vector.size(); i++) {
//            if (vector.elementAt(i) instanceof ApplicationData) {
//                ApplicationData appData = (ApplicationData) vector.elementAt(i);
//                System.out.println("此时的文件名称是：" + appData.getFileName());
//                if (appData.getFileName().equals(EPMDoc.getCADName())) {
//                    System.out.println("found primary content");
//                    appData.setFileName(EPMDoc.getCADName());
//                    System.out.println("Renamed file: " + appData.getFileName());
//                    System.out.println("pass back to createZipList");
//                    return appData;
//                }
//            }
//        }
//        return primaryNotFound;
//    }
//
//    public static String uploadSWMaterial() throws Exception {
//        try {
//            //获取保存工作区的WTContainer对象
//            WTContainer container = getWTContainByName("Site");
//            //工作区唯一名称
//            String workspaceName = "SW_Workspace";
//            //文件所在位置
//            String filePath = "E:/file/1529807957.SLDPRT";
//            File file = new File(filePath);
//            //用户名称
//            String userName = "Administrator";
//            //获取上传对象的文档类型，例如CADCOMPONENT
//            String epmDocTypeInfo = "CADCOMPONENT";
//            //获取上传对象的名称
//            String name = "SW78998";
//            //获取上传对象的编号
//            String number = "1529807957.SLDPRT";
//            //获取上传对象工作区对应的产品库名称
//            String containerName = "T0001";
//            //系统中工作区的文件夹路径
//            String folderPath = "/" + userName + "/" + workspaceName;
//            //生命周期名称
//            String lifeCycleName = "LC_图纸"; // Lifecycle name
//            //根据产品库名称获取产品库的WTContainer对象
//            WTContainer epmContainer = getWTContainByName(containerName);
//            //创建上载工作区的epm对象
//            EPMDocument doc = EPMDocument.newEPMDocument();
//            System.out.println("开始uploadSWMaterial！！！！");
//            //设置属性
//            doc.setName(name);
//            doc.setNumber(number);
//            //设置容器
//            doc.setContainer(epmContainer);
//            //设置对象的ContainerReference，为空会上传失败
//            PDMLinkProduct product = (PDMLinkProduct) WTContainerHelper.getContainer(doc);
//            WTContainerRef c_ref = WTContainerRef.newWTContainerRef(product);
//            doc.setContainerReference(c_ref);
//            //根据工作区的文件夹路径以及工作区的WTContainer对象来获取工作区对应的文件夹
//            Folder folder = FolderHelper.service.getFolder(folderPath, container.getContainerReference());
//            //根据文件夹对象和文档对象设置属性
//            FolderHelper.assignLocation(doc, folder);
//            //获取epm文档的master对象（此时为空，下面设置的四个数据为空会上传失败）
//            EPMDocumentMaster master = (EPMDocumentMaster) doc.getMaster();
//            //创建epm文档的来源，当前为SOLIDWORKS
//            EPMAuthoringAppType authoringApp = EPMAuthoringAppType.toEPMAuthoringAppType("SOLIDWORKS");
//            //创建epm的文档类型
//            EPMDocumentType epmDocumentType = EPMDocumentType.toEPMDocumentType(epmDocTypeInfo);
//            //创建文档主内容的类型
//            EPMApplicationType epmApplicationType = EPMApplicationType.toEPMApplicationType("EPM");
//            //设置CAD文档的名称（必须唯一）
//            master.setCADName(file.getName());
//            //设置之前创建的属性到master中
//            master.setAuthoringApplication(authoringApp);
//            master.setDocType(epmDocumentType);
//            master.setOwnerApplication(epmApplicationType);
//            //根据名称搜索工作空间对象
//            QuerySpec qs = new QuerySpec(EPMWorkspace.class);
//            qs.appendWhere(new SearchCondition(EPMWorkspace.class, EPMWorkspace.NAME, SearchCondition.EQUAL, workspaceName), new int[]{0});
//            //Search
//            QueryResult qr = PersistenceHelper.manager.find(qs);
//            EPMWorkspace workspace = null;
//            while (qr.hasMoreElements()) {
//                workspace = (EPMWorkspace) qr.nextElement();
//                if (StringUtils.equals(folderPath, workspace.getFolder().getFolderPath())) {
//                    break;
//                } else {
//                    workspace = null;
//                }
//                System.out.println("工作空间workspace : " + workspace.getName());
//            }
//            if (workspace == null)
//                throw new WTException("用户" + userName + "不存在名字为" + workspaceName + "的工作区");
//            //获取epm文档的生命周期
//            LifeCycleTemplate lct = LifeCycleHelper.service.getLifeCycleTemplate(lifeCycleName, doc.getContainerReference());
//            //设置epm文档生命周期
//            doc = (EPMDocument) LifeCycleHelper.setLifeCycle(doc, lct);
//            //保存epm文档到系统对应的文件夹
//            doc = (EPMDocument) PersistenceHelper.manager.store(doc);
//            WTCollection to_removefromws = new WTArrayList(1);
//            to_removefromws.add(doc);
//            //将epm文档保存到工作区
//            EPMWorkspaceHelper.manager.addToWorkspace(workspace, to_removefromws);
//            //创建文档epm文档的主内容对象
//            ApplicationData data = ApplicationData.newApplicationData(doc);
//            //设置主内容对象的属性
//            data.setRole(ContentRoleType.PRIMARY);
//            data.setFileName(file.getName());
//            String coding = new String(file.getAbsolutePath().getBytes("UTF-8"), System.getProperty("file.encoding"));
//            //替换主内容文件
//            ContentServerHelper.service.updateContent(doc, data, coding);
//            return "创建成功";
//        } catch (Exception e) {
//            return e.getMessage();
//        }
//    }

    public static EPMDocument getEPMByNumber(String number) {
        try {
            if (StringUtils.isBlank(number)) {
                return null;
            }
            QuerySpec qs = new QuerySpec(EPMDocument.class);
            qs.appendWhere(
                    new SearchCondition(EPMDocument.class, EPMDocument.NUMBER, SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                EPMDocument doc = (EPMDocument) qr.nextElement();
                return doc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}