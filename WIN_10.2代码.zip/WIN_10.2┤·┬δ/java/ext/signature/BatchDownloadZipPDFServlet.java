package ext.signature;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.CheckedOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import wt.content.ApplicationData;
import wt.content.ContentServerHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.config.LatestConfigSpec;


/**
 *对指定目录的文件夹进行压缩打包成zip文件 
 */

public class BatchDownloadZipPDFServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Gson gson = new Gson();
	public static String PDF_TEMP = "";
	static {
		String wtHome = null;
		try {
			WTProperties props = WTProperties.getLocalProperties();
			wtHome = props.getProperty("wt.temp");
			PDF_TEMP = wtHome + File.separator + "pdf";
			File pdfFolder = new File(PDF_TEMP);
			if (!pdfFolder.exists()) {
				pdfFolder.mkdir();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private List<Object[]> allPDFList = new ArrayList<>();
	private List<Object[]> allDXFList = new ArrayList<>();
	private List<Object[]> allList = new ArrayList<>();
	private static final String DOWNLOAD_PDF_ORDER = "1";
	private static final String DOWNLOAD_DXF_ORDER = "2";
	private static final String DOWNLOAD_ALL_ORDER = "3";
	@SuppressWarnings("deprecation")
	@RequestMapping(method={RequestMethod.GET, RequestMethod.POST,RequestMethod.HEAD})
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException{
		try {
			
//			WTPart part = null;
			List<WTPart> parts = new ArrayList<>();
//			String partnumber =  request.getParameter("Value");//wtpart partnumber
			String partNumberList = request.getParameter("partNumberList");
			String order = request.getParameter("order"); // 指令 不填为查询 1下载pdf 2下载dxf 3全部下载
			//String Version =  request.getParameter("Version");//wtpart Version				
			if(order != null) {
				if(order.equals(DOWNLOAD_PDF_ORDER)) {
					download2DDrawing(allPDFList, "PDF", response);
					return;
				}else if(order.equals(DOWNLOAD_DXF_ORDER)){
					download2DDrawing(allDXFList, "DXF", response);
					return;
				}else if(order.equals(DOWNLOAD_ALL_ORDER)) {
					allList.addAll(allPDFList);
					allList.addAll(allDXFList);
					download2DDrawing(allList, "All", response);
				}
			}else {
				allPDFList.clear();
				allDXFList.clear();
				allList.clear();
			}
			String[] partNumberArray = partNumberList.split(",");
			if(partNumberArray.length > 0) {
				for(String number:partNumberArray) {
					WTPart part = getPartByNumber(number);					
					if(part != null) {
						parts.add(part);
					}
				}
			}else {
				throw new Exception("部件Number输入有误。");
			}

//			if(StringUtils.isNotBlank(partNumberList)){
//				part = getPartByNumber(partNumberList);
//			}else {
//				String oid =  request.getParameter("oid");//wtpart oid
//				NmOid nmoid = NmOid.newNmOid(oid);
//				if(nmoid != null && nmoid.getRef() != null) {
//					Object ref = nmoid.getRef();
//					if(ref instanceof WTPart) {
//						part = (WTPart)ref;
//					}
//				}
//			}
	
			String[] returnArray = new String[4];
			Set<String> searchNoPDFResult = new HashSet<>(); 	
			Set<String> searchPDFResult = new HashSet<>(); 
			Set<String> searchNoDXFResult = new HashSet<>();
			Set<String> searchDXFResult = new HashSet<>();
			if(!parts.isEmpty()) {
				for(WTPart part : parts) {
					Object[]rep = PartPDFHelper.findBOMPDFRepFromPart(part);
					List<Object[]> pdfRefList = (List<Object[]> )rep[0];
					List<Object[]> dxfRefList = (List<Object[]> )rep[1];
					List<WTPart> noPDFParts = (List<WTPart>)rep[2];
					List<WTPart> noDXFParts = (List<WTPart>)rep[3];
					for(WTPart noPDFPart:noPDFParts) {
						searchNoPDFResult.add(noPDFPart.getNumber());
					}
					for(WTPart noDXFPart:noDXFParts) {
						searchNoDXFResult.add(noDXFPart.getNumber());
					}

					if(!pdfRefList.isEmpty()) {
						allPDFList.addAll(pdfRefList);
						for(Object[] o : pdfRefList) {
							searchPDFResult.add(o[1].toString());
						}					
					}
					if(!dxfRefList.isEmpty()) {
						allDXFList.addAll(dxfRefList);
						for(Object[] o : dxfRefList) {
							searchDXFResult.add(o[1].toString());
						}
					}
				}
			}		
			
			String noPDFPartJson = gson.toJson(searchNoPDFResult);
			String PDFPartJson = gson.toJson(searchPDFResult);
			String noDXFPartJson = gson.toJson(searchNoDXFResult);
			String DXFPartJson = gson.toJson(searchDXFResult);
			
			returnArray[0] = PDFPartJson;
			returnArray[1] = DXFPartJson;
			returnArray[2] = noPDFPartJson; 
			returnArray[3] = noDXFPartJson;
			String returnJson = gson.toJson(returnArray);
			response.reset();
    		response.setContentType("appliction/json;charset=utf-8");
//			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter(); 
			out.print(returnJson);
			
//			if(part != null) {
//				response.reset();
//				response.setContentType("APPLICATION/OCTET-STREAM");  
//		        response.setHeader("Content-Disposition","attachment; filename="+part.getNumber()+".zip");
//		        Object[] returnData = PartPDFHelper.findBOMPDFRepFromPart(part);
//		        List<WTPart> noPDFPartList = (List<WTPart>)returnData[0];
//		        List<ApplicationData> pdfRefList = (List<ApplicationData>)returnData[1];
//		        ZipOutputStream zos = new ZipOutputStream(new CheckedOutputStream(response.getOutputStream(),new CRC32()));
//		        for (ApplicationData applicationData : pdfRefList) {
//		        	String fileName = applicationData.getFileName();
//		        	InputStream is = ContentServerHelper.service.findContentStream(applicationData);
//		        	ZipEntry entry = new ZipEntry(fileName);
//		        	zos.putNextEntry(entry);
//		            int len = -1 ;
//		            byte[] buffer = new byte[1024];
//		            while ((len = is.read(buffer)) != -1) {
//		            	zos.write(buffer, 0, len);
//		            }
//		            zos.flush();
//		            is.close();
//		        }
//		        //txt列表保存没有pdf表示法的partnumber
//		        String fileName = "no-pdf-part-list.txt";
//	        	ZipEntry entry = new ZipEntry(fileName);
//	        	StringBuffer sb  =new StringBuffer("");
//	        	int index = 1;
//	        	for (WTPart p : noPDFPartList) {
//	        		 String temp = index+" | ";
//	        		 temp+=p.getNumber()+" | ";
//	        		 temp+=p.getVersionInfo().getIdentifier().getValue()+" | ";
//	        		 temp+=p.getName()+"\r\n";
//	        		 sb.append(temp);
//	        		 index++;
//	        	 }
//	        	InputStream is = new ByteArrayInputStream(sb.toString().getBytes("utf-8"));
//	        	zos.putNextEntry(entry);
//	            int len = -1 ; 
//	            byte[] buffer = new byte[1024];
//	            while ((len = is.read(buffer)) != -1) {
//	            	zos.write(buffer, 0, len);
//	            }
//	            zos.flush();
//	            is.close();
//		        zos.close();
//				response.flushBuffer();
//			}else{
//				response.reset();
//				response.setContentType("text/html;charset=UTF-8");  //这句太重要了
//				response.getWriter().print("无法获取WTPart数据");
//				response.flushBuffer();
//			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				response.reset();
				response.setContentType("text/html;charset=UTF-8");  //这句太重要了
				response.getWriter().print("批量导出PDF出错:"+e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} finally {
		}
	}
	
	
	
	private void download2DDrawing(List<Object[]> all, String zipName, HttpServletResponse response) throws IOException, WTException {
		response.reset();
		response.setContentType("APPLICATION/OCTET-STREAM"); 
        response.setHeader("Content-Disposition","attachment; filename=" + zipName + ".zip");     
        ZipOutputStream zos = new ZipOutputStream(new CheckedOutputStream(response.getOutputStream(),new CRC32()));
        for (Object[] o :  all) {
        	ApplicationData pdf = (ApplicationData)(o[0]);
        	String number = o[1].toString();
        	String fileName = number+ "_" + pdf.getFileName();
        	InputStream is = ContentServerHelper.service.findContentStream(pdf);
        	ZipEntry entry = new ZipEntry(fileName);
        	zos.putNextEntry(entry);
            int len = -1 ;
            byte[] buffer = new byte[1024];
            while ((len = is.read(buffer)) != -1) {
            	zos.write(buffer, 0, len);
            }
            zos.flush();
            is.close();
        }
        zos.close();
		response.flushBuffer();
		
	}

	
	/*
	 * 根据number获取最新版本的part
	 */
	public static WTPart getPartByNumber(String number)
		    throws WTException
		  {
			WTPart part = null;
		    QuerySpec qs = new QuerySpec(WTPart.class);
		    SearchCondition sc = new SearchCondition(WTPart.class, "master>number", "=", number);
		    qs.appendWhere(sc);
		    qs.appendAnd();
		    qs.appendWhere(new SearchCondition(WTPart.class, "interopInfo.iopState", "<>", "terminal"));
		    QueryResult qr = PersistenceHelper.manager.find(qs);
		    LatestConfigSpec lcs = new LatestConfigSpec();
		    qr = lcs.process(qr);
		    if (qr.size() > 0) {
		      part = (WTPart)qr.nextElement();
		    }
		    return part;
		  }
	
	private boolean savePDF2TempFolder(InputStream is,String outFilePath) throws Exception {
		File file = new File(outFilePath);
		if(file.exists()) {
			return false;
		}
		FileOutputStream fos = new FileOutputStream(file);
		 int len = 0 ;
         byte[] buffer = new byte[1024];
         while ((len = is.read(buffer)) > 0) {
        	 fos.write(buffer, 0, len);
        	 fos.flush();
         }
         fos.close();
         return true;
	}
}