package ext.signature.jwis.ui;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.signature.jwis.ui.PurchaseRB")
class PurchaseRB extends WTListResourceBundle {
    @RBEntry("purchase(<U class='mnemonic'>P</U>)")
    public static final String PURCHASETAB_PURCHASENAV_DESCRIPTION = "purchaseTab.purchaseNav.description";
    @RBEntry("P")
    @RBPseudo(false)
    public static final String PURCHASETAB_PURCHASENAV_HOTKEY = "purchaseTab.purchaseNav.hotkey";
    @RBEntry("purchase")
    public static final String PURCHASETAB_PURCHASENAV_TOOLTIP = "purchaseTab.purchaseNav.tooltip";
    @RBEntry("purchase")
    public static final String PURCHASETAB_PURCHASENAV_ACTIVETOOLTIP = "purchaseTab.purchaseNav.activetooltip";
    @RBEntry("navigator_home.png")
    public static final String PURCHASETAB_PURCHASENAV_ICON = "purchaseTab.purchaseNav.icon";
    @RBEntry("CAD download")
    public static final String PURCHASE_CADDOWNLOAD_TITLE = "purchase.cadDownload.title";
    @RBEntry("CAD download")
    public static final String PURCHASE_CADDOWNLOAD_DESCRIPTION = "purchase.cadDownload.description";
    @RBEntry("CAD download")
    public static final String PURCHASE_CADDOWNLOAD_TOOLTIP = "purchase.cadDownload.tooltip";

    public PurchaseRB() {
    }
}
