package ext.signature.jwis.ui;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;

@RBUUID("ext.signature.jwis.ui.PurchaseRB_zh_CN")
public class PurchaseRB_zh_CN {
    @RBEntry("采购(<U class='mnemonic'>P</U>)")
    public static final String PURCHASETAB_PURCHASENAV_DESCRIPTION = "purchaseTab.purchaseNav.description";
    @RBEntry("P")
    @RBPseudo(false)
    public static final String PURCHASETAB_PURCHASENAV_HOTKEY = "purchaseTab.purchaseNav.hotkey";
    @RBEntry("采购")
    public static final String PURCHASETAB_PURCHASENAV_TOOLTIP = "purchaseTab.purchaseNav.tooltip";
    @RBEntry("采购")
    public static final String PURCHASETAB_PURCHASENAV_ACTIVETOOLTIP = "purchaseTab.purchaseNav.activetooltip";
    @RBEntry("navigator_home.png")
    public static final String PURCHASETAB_PURCHASENAV_ICON = "purchaseTab.purchaseNav.icon";
    @RBEntry("图纸下载")
    public static final String PURCHASE_CADDOWNLOAD_TITLE = "purchase.cadDownload.title";
    @RBEntry("图纸下载")
    public static final String PURCHASE_CADDOWNLOAD_DESCRIPTION = "purchase.cadDownload.description";
    @RBEntry("图纸下载")
    public static final String PURCHASE_CADDOWNLOAD_TOOLTIP = "purchase.cadDownload.tooltip";

    public PurchaseRB_zh_CN() {
    }
}
