package ext.exportBom.service;

import org.apache.commons.lang.StringUtils;
import ext.exportBom.util.CommonUtil;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SupplyService {

    /**
     * 根据列名查询第一行的值
     * @param supplyName
     * @return
     */
   public String  getSupplyEngNameBySupplyName(String supplyName){
        String result="";
        if (!supplyName.isEmpty()){
            String sql = "SELECT FENGNAME FROM PDM_ERP_SUPPLIER WHERE FNAME=? and FACCTNO=002";

            ResultSet resultSet = CommonUtil.excuteSelect(sql, supplyName);
            try {
                if (resultSet.next()){
                    if (!StringUtils.isEmpty(resultSet.getString("FENGNAME"))) {
                        result =  resultSet.getString("FENGNAME");
                    }
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
       return result;
   }
}
