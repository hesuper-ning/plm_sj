package ext.exportBom.util;

import ext.exportBom.service.SupplyService;
import ext.exportBom.vo.ReplacePartsVO;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.content.*;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.*;

public class CreateEnExcel {
    private static String excelName;

    public static String PDF_TEMP = "";

    static {
        String wtHome = null;
        try {
            WTProperties props = WTProperties.getLocalProperties();
            wtHome = props.getProperty("wt.temp");
            System.out.println("wtHome:" + wtHome);
            PDF_TEMP = wtHome + File.separator + "excel";
            File pdfFolder = new File(PDF_TEMP);
            if (!pdfFolder.exists()) {
                pdfFolder.mkdir();
            }
            System.out.println("PDF Temp Folder: " + PDF_TEMP);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private final String PIC_DOC = "com.sprocomm.Partpic";

    private static Map<String, Object> isBuyEnumConstraint = IBAEnumUtil.getIbaEnumConstraint("wt.part.WTPartUsageLink", PropertiesUtil.getValueByKey("usagelink.iba.IsBuyCust"));
    private static Map<String, Object> isCusEnumConstraint = IBAEnumUtil.getIbaEnumConstraint("wt.part.WTPartUsageLink", PropertiesUtil.getValueByKey("usagelink.iba.IsCoustomerService"));
    private int rowNum = 0;

    public Workbook createExcel(WTPart part, String option3)
            throws IOException, Exception {
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");

        //判断是否为03.  PCBA
        if (StringUtils.startsWithIgnoreCase(part.getNumber(), preNumber)) {
            // 创建Excel工作簿
            XSSFWorkbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("电子料-英文bom");
            // 创建表头
            Row headerRow = sheet.createRow(rowNum++);
            headerRow.createCell(0).setCellValue("层级");
            headerRow.createCell(1).setCellValue("工位");
            headerRow.createCell(2).setCellValue("料号");
            headerRow.createCell(3).setCellValue("英文名称");
            headerRow.createCell(4).setCellValue("规格型号");
            headerRow.createCell(5).setCellValue("英文描述");
            headerRow.createCell(6).setCellValue("厂家");
            headerRow.createCell(7).setCellValue("是否存在替代料（是=Y，否=空）");
            headerRow.createCell(8).setCellValue("数量");
            if ("是".equals(option3)) {//获取有几张图片，生成几个列
                headerRow.createCell(9).setCellValue("图片");
            }
            getHeadStyle(workbook, headerRow, sheet);


            IBAUtil partIba = new IBAUtil(part);

            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue("");//层级
            row.createCell(1).setCellValue("");//工位
            row.createCell(2).setCellValue(part.getNumber());//料号

            row.createCell(3).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishName")));//英文名字
            row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.SpecificationsModel")));//规格型号
            row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishItemDesc")));//英文描述
            row.createCell(6).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.Factory")));//厂家
            row.createCell(7).setCellValue("");//是否存在替代料（是=Y，否=空）
            row.createCell(8).setCellValue("");//数量
            if ("是".equals(option3)) {//获取有几张图片，生成几个列
                int cellIindex = 9;
                getApplicationData(part, sheet, cellIindex, row);
            }
            //设置样式
            getDataStyle(workbook, row, sheet);
            int level = 1;
            getAllBomByPartPCBA(part, sheet, level, workbook, option3);
            AdjustColumnWidthFromExistingWorkbook(workbook);
            return workbook;

        } else {

            // 创建Excel工作簿
            XSSFWorkbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("组装料-英文bom");

            // 创建表头
            Row headerRow = sheet.createRow(rowNum++);
            headerRow.createCell(0).setCellValue("层级");
            headerRow.createCell(1).setCellValue("料号");
            headerRow.createCell(2).setCellValue("中文名称");
            headerRow.createCell(3).setCellValue("英文名称");
            headerRow.createCell(4).setCellValue("中文描述");
            headerRow.createCell(5).setCellValue("英文描述");
            headerRow.createCell(6).setCellValue("是否存在替代料（是=Y，否=空））");
            headerRow.createCell(7).setCellValue("数量");
            headerRow.createCell(8).setCellValue("供应商英文简称");
            if ("是".equals(option3)) {//获取有几张图片，生成几个列
                headerRow.createCell(9).setCellValue("图片");
            }
            getHeadStyle(workbook, headerRow, sheet);
            IBAUtil partIba = new IBAUtil(part);

            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue("");
            row.createCell(1).setCellValue(part.getNumber());//料号
            row.createCell(2).setCellValue(part.getName());//中文名称
            row.createCell(3).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishName")));//英文名称EenglishName
            row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));//中文描述
            row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishItemDesc")));//英文描述
            row.createCell(6).setCellValue("");//是否替代料
            row.createCell(7).setCellValue("");//数量
            row.createCell(8).setCellValue("");//供应商英文
            if ("是".equals(option3)) {//获取有几张图片，生成几个列
                int cellIindex = 9;
                getApplicationData(part, sheet, cellIindex, row);
            }
            //设置样式
            getDataStyle(workbook, row, sheet);
            int level = 1;
            getAllBomByPartNoPCBA(part, sheet, level, workbook, option3);
            AdjustColumnWidthFromExistingWorkbook(workbook);
            return workbook;
        }
    }


    /**
     * 找到所有PCBA料
     *
     * @param part
     * @param sheet
     * @param level
     * @param workbook
     * @throws WTException
     */
    boolean mark = false;
    private void getAllBomByPartPCBA(WTPart part, Sheet sheet, int level, XSSFWorkbook workbook, String option3) throws
            WTException {
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");
        System.out.println("打印编号03.和CK/S" + preNumber + pcbaContent);
        List<Object[]> childBOM = getChildBOM(part);
        Locale loc = SessionHelper.getLocale();
        System.out.println("002-地址:" + loc.toString());
        Locale locs = Locale.ENGLISH;
        System.out.println("002-Address: " + locs.toString());

        if (childBOM.size() > 0) {
            for (int i = 0; i < childBOM.size(); i++) {
                WTPartUsageLink usageLink = (WTPartUsageLink) childBOM.get(i)[0];
                WTPart sPart = (WTPart) childBOM.get(i)[1];
                IBAUtil usageLinkIBA = new IBAUtil(usageLink);
                IBAUtil partIba = new IBAUtil(sPart);
                System.out.println("打印rowNum（在第几行）" + rowNum);

                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(levelString(level));//层级
                row.createCell(1).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.MachinePos")));//工位	MachinePos
                row.createCell(2).setCellValue(sPart.getNumber());//料号
                row.createCell(3).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishName")));//英文名字
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.SpecificationsModel")));//规格型号
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishItemDesc")));//英文描述
                row.createCell(6).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.Factory")));//厂家
                row.createCell(7).setCellValue("");



                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(8).setCellValue(amount);
                if ("是".equals(option3)) {//获取有几张图片，生成几个列
                    int cellIindex = 9;
                    getApplicationData(sPart, sheet, cellIindex, row);
                }



                getDataStyle(workbook, row, sheet);

                if (isIngredients(usageLink)) {
                    row.createCell(7).setCellValue("Y");
                }

//                //判断可替代料是否有下级bom，层级+1
//                if (isColorIngredients(usageLink)) {//是否存在替代料（是=Y，否=空）
//
//                    //被替代料颜色
//                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(231, 219, 185)));
//                    //获取替代料下级bom
////                    getReplacePartsChildBOMInPCBA(replacePartsVO.getWtPart(), workbook, sheet, level + 1, option3);
//                } else {
//
//                    getDataStyle(workbook, row, sheet);
//                }



                System.out.println("getName:" + sPart.getName());
                System.out.println("是否含有CK/S" + StringUtils.contains(sPart.getName(), pcbaContent));
                System.out.println("getNumber:" + sPart.getNumber());
                System.out.println("开头是否含有03." + StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber));


                if (isGetChildPart(sPart)) {
                    System.out.println("导出：dom");
                    getAllBomByPartPCBA(sPart, sheet, level + 1, workbook, option3);
                }
                //查询是否有替代料+
                ReplacePartsVO replacePartsVO = handleReplacePartsInPCBA(usageLink, workbook, sheet, level, option3 ,false);

            }
        }
    }



    /**
     * 找到所有非PCBA料
     *
     * @param part
     * @param sheet
     * @param level
     * @param workbook
     * @throws WTException
     */
    boolean mark2 = false;
    private void getAllBomByPartNoPCBA(WTPart part, Sheet sheet, int level, XSSFWorkbook workbook, String option3) throws
            WTException {
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");
        System.out.println("打印编号03.和CK/S" + preNumber + pcbaContent);
        List<Object[]> childBOM = getChildBOM(part);
        Locale loc = SessionHelper.getLocale();
        System.out.println("002-地址:" + loc.toString());
        Locale locs = Locale.ENGLISH;
        System.out.println("002-Address: " + locs.toString());

        if (childBOM.size() > 0) {
            for (int i = 0; i < childBOM.size(); i++) {
                WTPartUsageLink usageLink = (WTPartUsageLink) childBOM.get(i)[0];
                WTPart sPart = (WTPart) childBOM.get(i)[1];
                IBAUtil partIba = new IBAUtil(sPart);
                System.out.println("打印rowNUm（在第几行）" + rowNum);
                Row row = sheet.createRow(rowNum++);

                row.createCell(0).setCellValue(levelString(level));
                row.createCell(1).setCellValue(sPart.getNumber());//料号
                row.createCell(2).setCellValue(sPart.getName());//中文名称
                row.createCell(3).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishName")));//英文名称EenglishName
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));//中文描述
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishItemDesc")));//英文描述
                row.createCell(6).setCellValue("");


                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(7).setCellValue(amount);//数量
                String supply = partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply"));
                System.out.println("打印供应商：" + supply);
                String supplyEngNameBySupplyName = new SupplyService().getSupplyEngNameBySupplyName(supply);
                System.out.println("打印供应商英文：" + supplyEngNameBySupplyName);
                if (supplyEngNameBySupplyName==null) {
                    row.createCell(8).setCellValue("");//供应商英文
                } else {
                    row.createCell(8).setCellValue(supplyEngNameBySupplyName);//供应商英文
                }
                System.out.println("是否共用料" + isSharedMterials(sPart));
                System.out.println("获取当前部件的" + PersistenceUtil.getTypeName(sPart));
                System.out.println("获取当前部件的" + PersistenceUtil.getPartTypeInternalName(sPart));

                if ("是".equals(option3)) {//获取有几张图片，生成几个列
                    int cellIindex = 9;
                    getApplicationData(sPart, sheet, cellIindex, row);
                }
                System.out.println("打印查完替代料后的rowNum（在第几行）" + rowNum);

                //数据样式
                getDataStyle(workbook, row, sheet);

                if (isIngredients(usageLink)) {//是否存在替代料（是=Y，否=空）
                    row.createCell(6).setCellValue("Y");
                }

                System.out.println("getName:" + sPart.getName());
                System.out.println("是否含有CK/S" + StringUtils.contains(sPart.getName(), pcbaContent));
                System.out.println("getNumber:" + sPart.getNumber());
                System.out.println("开头是否含有03." + StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber));


                if (isGetChildPart(sPart)) {
                    System.out.println("导出：dom");
                    getAllBomByPartNoPCBA(sPart, sheet, level + 1, workbook, option3);
                }
                //查询是否有替代料+
                ReplacePartsVO replacePartsVO = handleReplacePartsNoPCBA(usageLink, workbook, sheet, level, option3 , false);

            }
        }
    }

    /**
     * 03.开头 只有含有CK/S才导出子料
     * @param part
     * @return  true才导出子项
     */
    public static boolean isGetChildPart(WTPart part){
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");//03.
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");
        boolean flag = true;
        //03.开头，不含CK/S 不获取子项
        if (StringUtils.startsWithIgnoreCase(part.getNumber(), preNumber)
                && !StringUtils.contains(part.getNumber(), "CK")
                && !StringUtils.contains(part.getNumber(), "S")) {
            flag = false;

        }

        return flag;

    }


    /**
     * 判断是否为标记颜色的被替代料（替代料数量大于1或替代料有子料）
     *
     * @param usageLink
     * @return
     * @throws WTException
     */
    public static boolean isColorIngredients(WTPartUsageLink usageLink) throws WTException {
        boolean flag = false;
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);

        //
        for (int i = 0; i < substituteParts.size(); i++) {
            WTPartMaster wtPartMaster = substituteParts.get(i);
            QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr2 = cfg.process(qr2);
            if (qr2.hasMoreElements()) {
                WTPart sPart = (WTPart) qr2.nextElement();

                //替代料有子料
                List<Object[]> childBOM = getChildBOM(sPart);
                if (childBOM.size() > 0) {
                    flag = true;
                }

            }

        }
        //替代料大于1个
        if (substituteParts.size() > 1) {
            flag = true;
        }


        return flag;
    }

    public static boolean isIngredients(WTPartUsageLink usageLink) throws WTException {
        boolean flag = false;
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);
        if (substituteParts.size() > 0) {
            flag = true;
        }

        return flag;
    }

    /**
     * 获取子阶列表，按物料编码排序
     *
     * @param rootPart
     * @return
     */
    private static List<Object[]> getChildBOM(WTPart rootPart) {
        List<Object[]> list = new ArrayList<Object[]>();
        QueryResult qr2 = null;
        try {
            Object[] obj;
            for (QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(rootPart); qr.hasMoreElements(); list.add(obj)) {
                obj = new Object[2];
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                obj[0] = usageLink;
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                LatestConfigSpec cfg = new LatestConfigSpec();
                qr2 = cfg.process(qr2);
                if (qr2.hasMoreElements()) {
                    WTPart sPart = (WTPart) qr2.nextElement();
                    obj[1] = sPart;
                }
            }
            //排序
            Collections.sort(list, new Comparator<Object[]>() {
                public int compare(Object[] obj1, Object[] obj2) {
                    WTPart part1 = (WTPart) obj1[1];
                    WTPart part2 = (WTPart) obj2[1];
//
//                    WTPartUsageLink usageLink1 = (WTPartUsageLink) obj1[0];
//                    WTPartUsageLink usageLink2 = (WTPartUsageLink) obj2[0];
//
//                    WTPart part1 = (WTPart) obj1[1];
//                    WTPart part2 = (WTPart) obj2[1];
//
//                    //先根据行号排序
//                    Long lineNumber1 = usageLink1.getLineNumber() != null ? usageLink1.getLineNumber().getValue() : null;
//                    Long lineNumber2 = usageLink2.getLineNumber() != null ? usageLink2.getLineNumber().getValue() : null;

//                    if (lineNumber1 != null && lineNumber2 != null) {
//                        int compareResult = lineNumber1.compareTo(lineNumber2);
//                        if (compareResult == 0) {
//                            //行号相同根据编号排序
//                            return part1.getNumber().compareTo(part2.getNumber());
//                        }
//                        return compareResult;
//                    } else if (lineNumber1 != null) {
//                        return -1; // obj2 的行号为空，将其排在后面
//                    } else if (lineNumber2 != null) {
//                        return 1; // obj1 的行号为空，将其排在后面
//                    } else {
//                        return part1.getNumber().compareTo(part2.getNumber()); // both lineNumber1 and lineNumber2 are null
//                    }
                    return part1.getNumber().compareTo(part2.getNumber());
                }
            });
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    private Boolean isSharedMterials(WTPart childPart) {
        Boolean flag = false;
        //通过子部件获取子父类关系
        List<WTPart> topParentParts = getParentParts(childPart);
        System.out.println("子部件获取父部件的数量：" + topParentParts.size());
        if (topParentParts.size() > 1) {
            flag = true;
        }
        return flag;
    }




    /**
     * 找到部件的BOM上层部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            if (part != null) {
                //查到的是什么
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());

                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        list.add(childPart);
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 通过递归找到部件的BOM最上层部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getTopParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            if (part != null) {
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());

                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        list.addAll(getTopParentParts(childPart));
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    private String levelString(int level) {
        StringBuffer sb = new StringBuffer("*");
        for (int i = 1; i < level; i++) {
            sb.append("*");
        }
        String levelStr = StringUtils.replace(sb.toString(), "*", "  ", sb.length() - 1);
        return levelStr;
    }

    /**
     * 科学计数法改为数字字符串
     *
     * @param doubleStr
     * @return
     */
    private String getRealNumOfScientificNotation(String doubleStr) {
        int indexOfE = doubleStr.indexOf('E');
        int indexOfPoint = doubleStr.indexOf('.');
        // 整数部分
        BigInteger zs = new BigInteger(doubleStr.substring(0, indexOfPoint));
        // 小数部分
        BigInteger xs = new BigInteger(doubleStr.substring(indexOfPoint
                + BigInteger.ONE.intValue(), indexOfE));
        // 指数
        int pow = Integer.valueOf(doubleStr.substring(indexOfE
                + BigInteger.ONE.intValue()));
        StringBuffer buffer = new StringBuffer();
        // e.g. 1.23E-5
        if (pow < 0) {
            for (int i = 0; i < -pow; i++) {
                buffer.append(0);
            }
            buffer.insert(BigInteger.ONE.intValue(), ".");
            buffer.append(zs.toString());
            if (!"0".equalsIgnoreCase(xs.toString())) {
                buffer.append(xs.toString());
            }
            doubleStr = buffer.toString();
        } else {
            int xsLen = xs.toByteArray().length;
            int needFill0 = pow - xsLen;
            if (needFill0 < 0) {
                // e.g. 1.234E2
                buffer.append(xs);
                buffer.insert(pow, ".");
                buffer.insert(0, zs);
                doubleStr = buffer.toString();
            } else {
                // e.g. 1.234E6 or 1.234E3
                for (int i = 0; i < needFill0; i++) {
                    buffer.append(0);
                }
                buffer.insert(0, xs);
                buffer.insert(0, zs);
                doubleStr = buffer.toString();
            }
        }
        return doubleStr;
    }


    /**
     * 查找PCBA替代料
     *
     * @param usageLink
     * @param sheet
     * @return 返回下一行以及下级bom对象
     * @throws WTException
     */
    private ReplacePartsVO handleReplacePartsInPCBA(WTPartUsageLink usageLink, XSSFWorkbook workbook, Sheet
            sheet, int level, String option3 , boolean flag) throws WTException {
        System.out.println("查找是否含有替代料");
        ReplacePartsVO result = new ReplacePartsVO();
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);
        for (int i = 0; i < substituteParts.size(); i++) {
            System.out.println("rowNum到第" + rowNum + "行");
            System.out.println("含有");
            WTPartMaster wtPartMaster = substituteParts.get(i);//关联属性对象
            QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr2 = cfg.process(qr2);
            if (qr2.hasMoreElements()) {
                WTPart sPart = (WTPart) qr2.nextElement();

                System.out.println(sPart.getName());

                IBAUtil partIba = new IBAUtil(sPart);//部件属性
//                IBAUtil usageLinkIBA = new IBAUtil(usageLink);

                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue("");//层级
//                row.createCell(1).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.MachinePos")));//工位	MachinePos
                row.createCell(1).setCellValue("");//工位	MachinePos
                row.createCell(2).setCellValue(sPart.getNumber());//料号
                row.createCell(3).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishName")));//英文名字
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.SpecificationsModel")));//规格型号
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishItemDesc")));//英文描述
                row.createCell(6).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.Factory")));//厂家
                row.createCell(7).setCellValue("");
                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(8).setCellValue(amount);
                if ("是".equals(option3)) {//获取有几张图片，生成几个列
                    int cellIindex = 9;
                    getApplicationData(sPart, sheet, cellIindex, row);
                }
//                //替代料主料的填充颜色
//                XSSFCellStyle rowStyle = setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(161, 179, 215)));
                //判断是否有子级
                List<Object[]> childBOM = getChildBOM(sPart);

                //替代料数量大于1才添加颜色
                if ( !childBOM.isEmpty() && isGetChildPart(sPart)) {
                    //替代料主料的填充颜色     //判断是否有子级   03.开头只有含有CK/S才找子料
                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(161, 179, 215)));
                    //获取替代料子料
                    getReplacePartsChildBOMInPCBA(sPart, workbook, sheet, level + 1, option3);
                } else {
                    // 只设置样式
                    getDataStyle(workbook, row, sheet);
                }

                if (flag) {
                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));//
                }

                result.setRowNum(rowNum);
                result.setWtPart(sPart);
                System.out.println(result.toString());





            }
        }
        return result; //   返在第几行
    }

    /**
     * 查找非PCBA替代料
     *
     * @param usageLink
     * @param sheet
     * @return 返回下一行以及下级bom对象
     * @throws WTException
     */
    private ReplacePartsVO handleReplacePartsNoPCBA(WTPartUsageLink usageLink, XSSFWorkbook workbook, Sheet sheet, int level,
                                                    String option3 , boolean flag) throws WTException {
        System.out.println("查找是否含有替代料");
        ReplacePartsVO result = new ReplacePartsVO();
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);
        for (int i = 0; i < substituteParts.size(); i++) {
            System.out.println("含有");
            WTPartMaster wtPartMaster = substituteParts.get(i);
            QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr2 = cfg.process(qr2);
            if (qr2.hasMoreElements()) {
                WTPart sPart = (WTPart) qr2.nextElement();
                System.out.println(sPart.getName());
//                IBAUtil usageLinkIBA = new IBAUtil(usageLink);//关系属性
                IBAUtil partIba = new IBAUtil(sPart);
                Row row = sheet.createRow(rowNum++);

                row.createCell(0).setCellValue("");
                row.createCell(1).setCellValue(sPart.getNumber());//料号
                row.createCell(2).setCellValue(sPart.getName());//中文名称
                row.createCell(3).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishName")));//英文名称EenglishName
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));//中文描述
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishItemDesc")));//英文描述
                row.createCell(6).setCellValue("");
                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(7).setCellValue(amount);//数量

                String supply = partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply"));
                System.out.println("打印供应商：" + supply);
                String supplyEngNameBySupplyName = new SupplyService().getSupplyEngNameBySupplyName(supply);
                if (StringUtils.isEmpty(supplyEngNameBySupplyName)) {
                    row.createCell(8).setCellValue("");//供应商英文
                } else {
                    row.createCell(8).setCellValue(supplyEngNameBySupplyName);//供应商英文
                }

                if ("是".equals(option3)) {//获取有几张图片，生成几个列
                    int cellIindex = 9;
                    getApplicationData(sPart, sheet, cellIindex, row);
                }

                List<Object[]> childBOM = getChildBOM(sPart);

                //替代料数量大于1才添加颜色
                if ( !childBOM.isEmpty() && isGetChildPart(sPart)) {
                    //替代料主料的填充颜色
                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(161, 179, 215)));
                    getReplacePartsChildBOMNoPCBA(sPart, workbook, sheet, level + 1, option3);
                } else {
                    // 只设置样式
                    getDataStyle(workbook, row, sheet);
                }
                if (flag) {
                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));//
                }

                result.setRowNum(rowNum);
                result.setWtPart(sPart);
                System.out.println(result.toString());






            }
        }
        return result; //   返在第几行
    }

    /**
     * 找到PCBA替代料子级
     *
     * @param replacePartsPart
     * @param sheet
     * @param level
     * @return 返回下行
     * @throws WTException
     */
    private int getReplacePartsChildBOMInPCBA(WTPart replacePartsPart, XSSFWorkbook workbook, Sheet sheet,
                                              int level, String option3) throws WTException {
        int result = rowNum;
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");
        List<Object[]> childBOM = getChildBOM(replacePartsPart);
        //设置父类颜色
        if (childBOM.size() > 0) {
            for (int i = 0; i < childBOM.size(); i++) {
                WTPartUsageLink usageLink = (WTPartUsageLink) childBOM.get(i)[0];
                WTPart sPart = (WTPart) childBOM.get(i)[1];
                IBAUtil usageLinkIBA = new IBAUtil(usageLink);
                IBAUtil partIba = new IBAUtil(sPart);

                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(levelString(level));//层级
                row.createCell(1).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.MachinePos")));//工位	MachinePos
                row.createCell(2).setCellValue(sPart.getNumber());//料号
                row.createCell(3).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishName")));//英文名字
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.SpecificationsModel")));//规格型号
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishItemDesc")));//英文描述
                row.createCell(6).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.Factory")));//厂家
                row.createCell(7).setCellValue("");// 是否含有替代料
                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(8).setCellValue(amount);
                if ("是".equals(option3)) {//获取有几张图片，生成几个列
                    int cellIindex = 9;
                    getApplicationData(sPart, sheet, cellIindex, row);
                }

                if (isIngredients(usageLink)) {//是否存在替代料（是=Y，否=空）
                    row.createCell(7).setCellValue("Y");
                }

                //替代料子料的填充颜色  217, 225, 242
                setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));//




                //pcba是03.开头 不含有 CK/S   无需导出bom
                if (isGetChildPart(sPart)) {
                    System.out.println("导出：dom");
                    result = getReplacePartsChildBOMInPCBA(sPart, workbook, sheet, level + 1, option3);
                }
                // 替代料的操作
                handleReplacePartsInPCBA(usageLink, workbook, sheet, level, option3 ,true);
            }
        }
        return result;
    }

    /**
     * 找到非PCBA替代料子级
     *
     * @param replacePartsPart
     * @param sheet
     * @param level
     * @return 返回下行
     * @throws WTException
     */
    private List<WTPart> getReplacePartsChildBOMNoPCBA(WTPart replacePartsPart, XSSFWorkbook workbook, Sheet sheet,
                                                       int level, String option3) throws WTException {
        List<WTPart> partList = new ArrayList<>();

        int result = rowNum;
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");
        List<Object[]> childBOM = getChildBOM(replacePartsPart);
        //设置父类颜色
        if (childBOM.size() > 0) {
            for (int i = 0; i < childBOM.size(); i++) {
                WTPartUsageLink usageLink = (WTPartUsageLink) childBOM.get(i)[0];
                WTPart sPart = (WTPart) childBOM.get(i)[1];
                IBAUtil usageLinkIBA = new IBAUtil(usageLink);
                IBAUtil partIba = new IBAUtil(sPart);

                Row row = sheet.createRow(rowNum++);

                row.createCell(0).setCellValue(levelString(level));//层级
                row.createCell(1).setCellValue(sPart.getNumber());//料号
                row.createCell(2).setCellValue(sPart.getName());//中文名称
                row.createCell(3).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishName")));//英文名称EenglishName
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));//中文描述
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.EenglishItemDesc")));//英文描述
                row.createCell(6).setCellValue("");
                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(7).setCellValue(amount);//数量
                String supply = partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply"));
                System.out.println("打印供应商：" + supply);
                String supplyEngNameBySupplyName = new SupplyService().getSupplyEngNameBySupplyName(supply);
                if (supplyEngNameBySupplyName==null) {
                    row.createCell(8).setCellValue("");//供应商英文
                } else {
                    row.createCell(8).setCellValue(supplyEngNameBySupplyName);//供应商英文
                }
                if ("是".equals(option3)) {//获取有几张图片，生成几个列
                    int cellIindex = 9;
                    getApplicationData(sPart, sheet, cellIindex, row);
                }


                if (isIngredients(usageLink)) {//是否存在替代料（是=Y，否=空）
                    row.createCell(6).setCellValue("Y");
                }
                //替代料子料的填充颜色
                setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));//

                System.out.println("getName:" + sPart.getName());
                System.out.println("是否含有CK/S" + StringUtils.contains(sPart.getName(), pcbaContent));
                System.out.println("getNumber:" + sPart.getNumber());
                System.out.println("开头是否含有03." + StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber));

                //pcba是03.开头 不含有 CK/S   无需导出bom
                if (isGetChildPart(sPart)) {
                    System.out.println("导出：dom");
                    getReplacePartsChildBOMNoPCBA(sPart, workbook, sheet, level + 1, option3);
                }
                // 替代料的操作
                handleReplacePartsNoPCBA(usageLink, workbook, sheet, level, option3,true);

                //将子部件添加到集合
                partList.add(sPart);
            }
        }
        return partList;
    }

    /**
     * 表头格式
     *
     * @param xssfwb
     * @return cellStyle
     */
    public XSSFCellStyle getHeadStyle(XSSFWorkbook xssfwb, Row row, Sheet sheet) {
        XSSFCellStyle cellStyle = xssfwb.createCellStyle();
        // 字体
        XSSFFont font = xssfwb.createFont();
        font.setFontHeightInPoints((short) 12);
        font.setFontName("黑体");
        cellStyle.setFont(font);

        //高度
        row.setHeightInPoints(30);
        // 边框
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        // 对齐
        cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
        cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);


        for (int i = 0; i < row.getLastCellNum(); i++) {
            Cell cell = row.getCell(i);

            cell.setCellStyle(cellStyle);
            sheet.autoSizeColumn(i);
        }

        return cellStyle;
    }


    /**
     * 内容格式
     *
     * @param xssfwb
     * @return cellStyle
     */
    public XSSFCellStyle getDataStyle(XSSFWorkbook xssfwb, Row row, Sheet sheet) {
        XSSFCellStyle cellStyle = xssfwb.createCellStyle();

        // 字体
        XSSFFont font = xssfwb.createFont();
        font.setFontHeightInPoints((short) 11);
        font.setFontName("宋体");
        cellStyle.setFont(font);
        // 边框
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        // 对齐
        cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
        cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);

        // 生效
        for (Cell cell : row) {
            cell.setCellStyle(cellStyle);
        }
        return cellStyle;
    }

    /**
     * 根据指定行填充颜色
     *
     * @param xssfwb
     * @param row
     * @return
     */
    public XSSFCellStyle setBackgroundColor(XSSFWorkbook xssfwb, Row row, Sheet sheet, XSSFColor color) {
        //颜色
        XSSFCellStyle rowStyle;
        //获取数据样式
        rowStyle = getDataStyle(xssfwb, row, sheet);
        //背景色
        rowStyle.setFillForegroundColor(color);//背景色
        rowStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);//实心填充
        for (Cell cell : row) {
            cell.setCellStyle(rowStyle);
        }
        return rowStyle;
    }

    public void AdjustColumnWidthFromExistingWorkbook(XSSFWorkbook xssfwb) {
        Sheet sheet = xssfwb.getSheetAt(0);

        // 定义最大宽度
        int maxColumnWidth = 35; // 最大宽度为 40 个字符

        // 从表格的第一行开始设置列的宽度
        for (int rowIndex = 0; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
            Row row = sheet.getRow(rowIndex);
            if (row != null) {
                //第一列开始
                for (int columnIndex = 0; columnIndex < row.getLastCellNum(); columnIndex++) {
                    Cell cell = row.getCell(columnIndex);
                    if (cell != null) {
                        // 计算单元格内容的宽度
                        int cellWidth = cell.toString().length();

                        // 将宽度限制在最大宽度以内
                        int maxWidth = Math.min(cellWidth, maxColumnWidth);

                        // 获取当前列的宽度
                        int currentWidth = sheet.getColumnWidth(columnIndex);

                        // 计算自适应宽度
                        int newWidth = Math.max(currentWidth, (maxWidth + 1) * 256);

                        // 设置列的宽度
                        sheet.setColumnWidth(columnIndex, newWidth);


                        CellStyle oldStyle = cell.getCellStyle();//获取就style
                        CellStyle newstyle = xssfwb.createCellStyle();//创建新的style
                        newstyle.cloneStyleFrom(oldStyle);//克隆到新的style
                        //第一列左对齐且除了第一行
//                        if (columnIndex == 0 && rowIndex > 0) {
//                            newstyle.setAlignment(CellStyle.ALIGN_LEFT);//左对齐
//                        }else{
//                            newstyle.setAlignment(CellStyle.ALIGN_CENTER);//居中
//                        }
                        cell.setCellStyle(newstyle);
                    }
                }
            }
        }

    }

    /**
     * 获取图片
     *
     * @param sheet
     * @param cellIindex
     * @param row
     */
    public void ExportPicture(Sheet sheet, ApplicationData applicationData, int cellIindex, Row row) {
        System.out.println("执行了获取图片！");
        File file = null;
        try {
            file = new File(PDF_TEMP);//导入临时文件
            String fileName = applicationData.getFileName();
            System.out.println("--------------图片----------------");
            System.out.println("名：" + fileName);
            System.out.println("插入图片到第" + cellIindex + "列");

//            ClassInfo classInfo = applicationData.getClassInfo();
            file = new File(file, fileName);
            // 将图片写入临时目录
            try {
                ContentServerHelper.service.writeContentStream(applicationData, file.getCanonicalPath());
            } catch (IOException e) {
//                cellIindex--;
                return;
            }

            // 将图片插入到Excel单元格中
            InputStream inputStream = ContentServerHelper.service.findContentStream(applicationData);
            byte[] imageBytes = IOUtils.toByteArray(inputStream);
            int pictureIdx = sheet.getWorkbook().addPicture(imageBytes, Workbook.PICTURE_TYPE_PNG);
            inputStream.close();

            CreationHelper helper = sheet.getWorkbook().getCreationHelper();
            Drawing drawing = sheet.createDrawingPatriarch();
            ClientAnchor anchor = helper.createClientAnchor();

            anchor.setCol1(cellIindex); // 图片所在列的索引
            anchor.setRow1(row.getRowNum()); // 图片所在行的索引

            Cell cell = row.createCell(cellIindex);
//
            Picture picture = drawing.createPicture(anchor, pictureIdx);

            // 设置列宽和行高
            sheet.setColumnWidth(cellIindex, 12 * 256); // 设置第一列宽度为60个字符的宽度
            row.setHeightInPoints(75); // 设置第一行高度为100 points
//            int cellWidth = (int) sheet.getColumnWidthInPixels(cell.getColumnIndex());
//            int cellHeight = (int) (cell.getRow().getHeightInPoints() / 72 * 96);
            // 调整图片大小
            picture.resize(0.92f, 0.98f);

        } catch (WTException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            e.getMessage();
        } finally {
            // 删除临时文件
            file.delete();
        }
    }

    /**
     * 获取图片对象    问导出的图片放在什么文档  现在是获取"说明方"文档
     *
     * @param part
     * @param sheet
     * @param cellIindex
     * @param row
     * @return
     */
    public int getApplicationData(WTPart part, Sheet sheet, int cellIindex, Row row) {
        int result = 0;
        System.out.println("获取文档前");
        try {

            PersistenceHelper.manager.navigate(part,wt.epm.structure.EPMDescribeLink.DESCRIBED_BY_ROLE,wt.epm.structure.EPMDescribeLink.class);


            QueryResult docs = WTPartHelper.service.getDescribedByWTDocuments(part);
            System.out.println("获取几个文档" + (docs.size()));
            while (docs.hasMoreElements()) {//
                WTDocument doc = (WTDocument) docs.nextElement();
                //文档类型
                String typeInternalName = PersistenceUtil.getDocTypeInternalName(doc);

                System.out.println(typeInternalName);
                //文档为图片文档导出图片
                if (PIC_DOC.equals(typeInternalName)) {
                    ContentHolder holder = ContentHelper.service.getContents(doc);
                    QueryResult contentsByRole = ContentHelper.service.getContentsByRole(holder, ContentRoleType.PRIMARY);
                    while (contentsByRole.hasMoreElements()) {
                        Object obj = contentsByRole.nextElement();
                        if (obj instanceof ApplicationData) {//
                            ApplicationData applicationData = (ApplicationData) obj;
                            ExportPicture(sheet, applicationData, cellIindex++, row);
                            result++; // 执行了多少此
                        }
                    }
                }

            }
        } catch (WTException | PropertyVetoException e) {
            e.printStackTrace();
        }
        return result;
    }


    /**
     * 判断是否为图片
     */
    public boolean isImageFile(String fileName) {
        if (fileName == null) {
            return false;
        }
        String lowerCaseFileName = fileName.toLowerCase(); // 转换为小写以便进行忽略大小写的比较
        return lowerCaseFileName.endsWith(".jpg") || lowerCaseFileName.endsWith(".jpeg") || lowerCaseFileName.endsWith(".png") ||
                lowerCaseFileName.endsWith(".gif") || lowerCaseFileName.endsWith(".bmp") || lowerCaseFileName.endsWith(".webp") ||
                lowerCaseFileName.endsWith(".tiff") || lowerCaseFileName.endsWith(".svg") || lowerCaseFileName.endsWith(".ico");
    }

}

