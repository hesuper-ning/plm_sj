package ext.exportBom.util;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileUtil {

	private static final int SIZE = 1024 * 8;

	private FileUtil() throws Exception {
		throw new Exception("Cannot be instantiated");
	}

	/**
	 * 以字节流的方式读取到字符串。
	 * 
	 * @param is 输入流
	 * @return 字符串
	 */
	public static String readBytesToString(InputStream is) {
		return new String(readBytes(is));
	}

	/**
	 * 以字节流的方式读取到字符串。
	 * 
	 * @param is 输入流
	 * @param charsetName 字符集
	 * @return 字符串
	 */
	public static String readBytesToString(InputStream is, String charsetName) {
		try {
			return new String(readBytes(is), charsetName);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 以字节流的方式从文件中读取字符串
	 * 
	 * @param file 文件
	 * @param charsetName 字符集
	 * @return 字符串
	 */
	public static String readBytesToString(File file, String charsetName) {
		try {
			return new String(readBytes(file), charsetName);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;

	}

	/**
	 * 以字节流的方式从文件中读取字符串。
	 * 
	 * @param file 文件
	 * @return 字符串
	 */
	public static String readBytesToString(File file) {
		return new String(readBytes(file));
	}

	// ---------------------readBytesToString 完成。分割线----------------------

	/**
	 * 以字符流的方式读取到字符串。
	 * 
	 * @param file 文件
	 * @param charset 字符集
	 * @return 字符串
	 */
	public static String readCharsToString(File file) {
		try {
			return readCharsToString(new FileInputStream(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 以字节流的方式读取到字符串。
	 * 
	 * @param file 文件
	 * @param charset 字符集
	 * @return 字符串
	 */
	public static String readCharsToString(File file, String charset) {
		try {
			return readCharsToString(new FileInputStream(file), charset);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 以字符流的方式读取到字符串。默认编码
	 * 
	 * @param is 输入流
	 * @return 字符串
	 */
	public static String readCharsToString(InputStream is) {
		return new String(readChars(is, null));
	}

	/**
	 * 以字符流的方式读取到字符串。
	 * 
	 * @param is 输入流
	 * @param charsetName 编码
	 * @return 字符串
	 */
	public static String readCharsToString(InputStream is, String charsetName) {
		return new String(readChars(is, charsetName));
	}

	// ---------------readCharsToString 完成。分割线-----------------------

	/**
	 * 以字节流的方式读取到字符串。
	 * 
	 * @param file 文件
	 * @return 字节数组
	 */
	public static byte[] readBytes(File file) {
		try {
			return readBytes(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 以字节流的方式读取到字符串。
	 * 
	 * @param is 输入流
	 * @return 字节数组
	 */
	public static byte[] readBytes(InputStream is) {
		byte[] bytes = null;
		try {
			BufferedInputStream bis = new BufferedInputStream(is);

			byte[] cbuf = new byte[SIZE];
			int len;
			ByteArrayOutputStream outWriter = new ByteArrayOutputStream();
			while ((len = bis.read(cbuf)) != -1) {
				outWriter.write(cbuf, 0, len);
			}
			outWriter.flush();

			bis.close();
			is.close();

			bytes = outWriter.toByteArray();
			outWriter.close();

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bytes;
	}

	/**
	 * 以字符流的方式读取到字符串。
	 * 
	 * @param file 文件
	 * @param charsetName 编码
	 * @return 字符数组
	 */
	public static char[] readChars(File file, String charsetName) {
		try {
			return readChars(new FileInputStream(file), charsetName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 以字符流的方式读取到字符串。
	 * 
	 * @param is 输入流
	 * @param charsetName 编码
	 * @return 字符数组
	 */
	public static char[] readChars(InputStream is, String charsetName) {
		char[] chars = null;
		try {
			InputStreamReader isr = null;
			if (charsetName == null) {
				isr = new InputStreamReader(is);
			} else {
				isr = new InputStreamReader(is, charsetName);
			}
			BufferedReader br = new BufferedReader(isr);
			char[] cbuf = new char[SIZE];
			int len;
			CharArrayWriter outWriter = new CharArrayWriter();
			while ((len = br.read(cbuf)) != -1) {
				outWriter.write(cbuf, 0, len);
			}
			outWriter.flush();

			br.close();
			isr.close();
			is.close();

			chars = outWriter.toCharArray();
			outWriter.close();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return chars;
	}

	// -----------------------readxxx 完成。分割线-----------------------
	// -----------------------read 部分完成。接下来是write的部分------------

	/**
	 * 通过字节输出流输出bytes
	 * 
	 * @param os 输出流
	 * @param text 字节数组
	 */
	public static void writeBytes(OutputStream os, byte[] text) {
		writeBytes(os, text, 0, text.length);
	}

	/**
	 * 通过字节输出流输出bytes
	 * 
	 * @param os 输出流
	 * @param text 字节数组
	 * @param off 数组起始下标
	 * @param lenght 长度
	 */
	public static void writeBytes(OutputStream os, byte[] text, int off, int lenght) {
		try {
			BufferedOutputStream bos = new BufferedOutputStream(os);
			bos.write(text, off, lenght);

			bos.flush();
			bos.close();
			os.close();

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// ----------------------writeByte 完成。分割------------------------

	/**
	 * 通过字符输出流输出chars
	 * 
	 * @param os 输出流
	 * @param text 字节数组
	 * @param charsetName 编码方式
	 */
	public static void writeChars(OutputStream os, char[] text, String charsetName) {
		writeChars(os, text, 0, text.length, charsetName);
	}

	/**
	 * 通过字符输出流输出chars
	 * 
	 * @param os 输出流
	 * @param text 字节数组
	 * @param off 数组起始下标
	 * @param lenght 长度
	 * @param charsetName 编码方式
	 */
	public static void writeChars(OutputStream os, char[] text, int off, int lenght, String charsetName) {
		try {
			OutputStreamWriter osw = null;

			if (charsetName == null) {
				osw = new OutputStreamWriter(os);
			} else {
				osw = new OutputStreamWriter(os, charsetName);
			}
			BufferedWriter bw = new BufferedWriter(osw);
			bw.write(text, off, lenght);

			bw.flush();
			bw.close();
			osw.close();
			os.close();

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// ----------------------writeChars 完成。分割------------------------

	/**
	 * 将字符串以默认编码写入文件
	 * 
	 * @param file 文件
	 * @param text 字符串
	 */
	public static void writeString(File file, boolean append, String text) {
		writeString(file, append, text, 0, text.length(), null);
	}

	/**
	 * 将字符串写入文件
	 * 
	 * @param file 文件
	 * @param append 是否追加
	 * @param text 字符串
	 * @param off 起始下标
	 * @param lenght 长度
	 * @param charsetName 编码名称
	 */
	public static void writeString(File file, boolean append, String text, int off, int lenght, String charsetName) {
		try {
			writeString(new FileOutputStream(file, append), text, off, lenght, charsetName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 将字符串以默认编码写入文件
	 * 
	 * @param file 文件
	 * @param text 字符串
	 */
	public static void writeString(File file, String text) {
		writeString(file, false, text, 0, text.length(), null);
	}

	/**
	 * 将字符串写入文件（默认覆盖）
	 * 
	 * @param file 文件
	 * @param append 是否追加
	 * @param text 字符串
	 * @param charsetName 编码名称
	 */
	public static void writeString(File file, boolean append, String text, String charsetName) {
		writeString(file, append, text, 0, text.length(), charsetName);
	}

	/**
	 * 将字符串写入文件（默认覆盖）
	 * 
	 * @param file 文件
	 * @param text 字符串
	 * @param charsetName 编码名称
	 */
	public static void writeString(File file, String text, String charsetName) {
		writeString(file, false, text, 0, text.length(), charsetName);
	}

	/**
	 * 字符输出流输出字符串
	 * 
	 * @param os 输出流
	 * @param text 字符串
	 * @param charsetName 编码
	 */
	public static void writeString(OutputStream os, String text, String charsetName) {
		writeString(os, text, 0, text.length(), charsetName);
	}

	/**
	 * 字符输出流输出字符串
	 * 
	 * @param os 输出流
	 * @param text 字符串
	 * @param off 起始下标
	 * @param lenght 长度
	 * @param charsetName 编码
	 */
	public static void writeString(OutputStream os, String text, int off, int lenght, String charsetName) {
		try {
			OutputStreamWriter osw = null;

			if (charsetName == null) {
				osw = new OutputStreamWriter(os);
			} else {
				osw = new OutputStreamWriter(os, charsetName);
			}
			BufferedWriter bw = new BufferedWriter(osw);
			bw.write(text, off, lenght);

			bw.flush();
			bw.close();
			osw.close();
			os.close();

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static final SimpleDateFormat YYYYMM = new SimpleDateFormat("yyyy-MM");
	
	public static final SimpleDateFormat YYYYMMDDHHMMSS = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	
	public static boolean exists(String path) {
        return exists(new File(path));
    }
 
    public static boolean exists(File file) {
        return file.exists();
    }
    
    
    public static String getExtension(String var0) {
		for(int var1 = var0.length() - 1; var1 >= 0; --var1) {
			if (var0.charAt(var1) == '.') {
			   String var2 = var0.substring(var1 + 1, var0.length());
			   return var2;
			}      
		}
		return new String("");
    }
    
    public static void createPdfFolder(String path)throws InterruptedException{    
    	  String [] paths=path.split("/");      
    	  StringBuffer fullPath=new StringBuffer();
    	  for (int i = 0; i < paths.length; i++) {
    		fullPath.append(paths[i]).append("\\\\");
    		File file=new File(fullPath.toString());
    		if(paths.length-1 != i){//判断path到文件名时，无须继续创建文件夹！
    			if(!file.exists()){
    				file.mkdir();
    				Thread.sleep(1500);
    			}	
    		}
    	  }
    	
    }
    
    public static void createJpgFolder(String path)throws InterruptedException{    
  	  String [] paths=path.split("/");      
  	  StringBuffer fullPath=new StringBuffer();
  	  for (int i = 0; i < paths.length; i++) {
  		fullPath.append(paths[i]).append("\\\\");
  		File file=new File(fullPath.toString());
		if(!file.exists()){
			file.mkdir();
			Thread.sleep(1500);
		}	
  	  }
  }
    
    
    public static final String TYPE_JPG = "jpg";
	public static final String TYPE_GIF = "gif";
	public static final String TYPE_PNG = "png";
	public static final String TYPE_BMP = "bmp";
	public static final String TYPE_UNKNOWN = "unknown";
 
	public static final String FORMAT_FILE_NAME = "%d.%s";
 
	private static byte[] b;
 
	/**
	 * 
	 * @description: 根据文件流判断图片类型
	 * @author: Jeff
	 * @date: 2019年12月7日
	 * @param fis 文件输入流
	 * @return
	 */
	public static String getPicType(InputStream fis) {
		// 读取文件的前几个字节来判断图片格式
		b = new byte[4];
		try {
			fis.read(b, 0, b.length);
			String type = bytesToHexString(b).toUpperCase();
			if (type.contains("FFD8FF")) {
				return TYPE_JPG;
			} else if (type.contains("89504E47")) {
				return TYPE_PNG;
			} else if (type.contains("47494638")) {
				return TYPE_GIF;
			} else if (type.contains("424D")) {
				return TYPE_BMP;
			} else {
				return TYPE_UNKNOWN;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
 
	/**
	 * 
	 * @description: byte数组转换成16进制字符串
	 * @author: Jeff
	 * @date: 2019年12月7日
	 * @param src
	 * @return
	 */
	public static String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder();
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}
 
	/**
	 * 
	 * @description: 判断文件夹是否存在，不存在则创建
	 * @author: Jeff
	 * @date: 2019年12月7日
	 * @param dir
	 */
	public static void isDirPathExist(File dir) {
		// 判断文件夹是否存在
		if (dir.isDirectory()) {
			System.out.println(dir + "文件夹已存在");
		} else {
			System.out.println(dir + "文件夹不存在");
			dir.mkdirs();
			System.out.println("创建文件夹" + dir);
		}
	}
 
	/**
	 * 
	 * @description: 从服务器获得图片输入流InputStream,并写到本地磁盘
	 * @author: Jeff
	 * @date: 2019年12月7日
	 */
	public static void saveImageToDisk(InputStream inputStream, String diskPath,String type) {
		// 根据文件流判断图片类型，此处不要关闭流,要不然下方获取不到输入流
		String picType = getPicType(inputStream);
		System.out.println("图片格式为：" + type);
		String fileName = String.format(FORMAT_FILE_NAME, new Date().getTime(), type);
		System.out.println("图片名字为：" + fileName);
		byte[] data = new byte[1024];
		int len = 0;
		FileOutputStream fileOutputStream = null;
		try {
			File dirFile = new File(diskPath);
			// 判断文件夹是否存在，不存在则创建
			isDirPathExist(dirFile);
			fileOutputStream = new FileOutputStream(new File(dirFile, fileName));
			// 首先写入判断图片格式的前几个字节
			fileOutputStream.write(b, 0, b.length);
			while ((len = inputStream.read(data)) != -1) {
				fileOutputStream.write(data, 0, len);
			}
			fileOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
 
		}
		System.out.println(fileName + "写到本地磁盘完成");
	}
	
	
	/**
	 * 
	 * @description: 从服务器获得图片输入流InputStream,并写到本地磁盘
	 * @author: Jeff
	 * @date: 2019年12月7日
	 */
	public static void saveImageToDisk(InputStream inputStream, String diskPath,String type, String fileName) {
		// 根据文件流判断图片类型，此处不要关闭流,要不然下方获取不到输入流
		String picType = getPicType(inputStream);
		System.out.println("图片格式为：" + type);
		System.out.println("图片名字为：" + fileName);
		byte[] data = new byte[1024];
		int len = 0;
		FileOutputStream fileOutputStream = null;
		try {
			File imgFile = new File(diskPath + fileName);
			if(imgFile.exists()) {
				imgFile.delete();
			}
			File dirFile = new File(diskPath);
			// 判断文件夹是否存在，不存在则创建
			isDirPathExist(dirFile);	
			fileOutputStream = new FileOutputStream(new File(dirFile, fileName));
			// 首先写入判断图片格式的前几个字节
			fileOutputStream.write(b, 0, b.length);
			while ((len = inputStream.read(data)) != -1) {
				fileOutputStream.write(data, 0, len);
			}
			fileOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
 
		}
		System.out.println(fileName + "写到本地磁盘完成");
	}
}


