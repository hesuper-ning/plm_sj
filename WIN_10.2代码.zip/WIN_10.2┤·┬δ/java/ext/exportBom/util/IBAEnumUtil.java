package ext.exportBom.util;

import com.ptc.core.lwc.client.commands.LWCCommands;
import com.ptc.core.lwc.common.view.*;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.DiscreteSet;
import org.apache.commons.lang.StringUtils;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.util.WTException;

import java.io.Serializable;
import java.util.*;

public class IBAEnumUtil {
	
	/**
	  * 获取指定类型TypeName的所有属性ibaKey的枚举值列表
	  * @param typeName
	  * @param ibaKey
	  * @return  Map<String,Map<String,Object>>
	  */
	 public static Map<String,Map<String,Object>> getIbaEnumConstraint(String typeName){
		 Map<String,Map<String,Object>> result = new HashMap<String,Map<String,Object>>();
		if(StringUtils.isBlank(typeName)){
			return result;
		}
		try {
			TypeDefinitionReadView typeDefView = TypeDefinitionServiceHelper.service.getTypeDefView(typeName);
			ArrayList<AttributeDefinitionReadView> typeAttributes = LWCCommands.getTypeAttributes("OR:"+typeDefView.getOid().getStringValue());
			//找到所有IBA属性
			for (AttributeDefinitionReadView attributeDefinitionReadView2 : typeAttributes) {
				//遍历每个IBA属性
				AttributeDefDefaultView ibaRefView = attributeDefinitionReadView2.getIBARefView();
				if(ibaRefView == null){
					continue;
				}
				//获取全局属性内部名称
				String name = attributeDefinitionReadView2.getIBARefView().getName();
				Collection collection = attributeDefinitionReadView2.getAllConstraints();
				//获取每个属性的全部约束
				for (Object object : collection) {
					if(object instanceof ConstraintDefinitionReadView){
						ConstraintDefinitionReadView cdr = (ConstraintDefinitionReadView)object;
						ConstraintRuleDefinitionReadView rule = cdr.getRule();
						String ruleClassname = rule.getRuleClassname();
						//是否合法值列表或枚举值
						if( StringUtils.containsIgnoreCase(ruleClassname,"DiscreteSetConstraint")){
//							System.out.println("===============iba key:"+name);
							//是否有枚举值
							EnumerationDefinitionReadView enumDef = cdr.getEnumDef();
							if(enumDef != null){
								Map<String, EnumerationEntryReadView> allEnumerationEntries = enumDef.getAllEnumerationEntries();
								Set<String> keySet = allEnumerationEntries.keySet();
								//保存所有枚举值的内部名称和显示名称map
								Map<String,Object> enumMap = new HashMap<String, Object>();
								for(String key : keySet){
									EnumerationEntryReadView enumerationEntryReadView = allEnumerationEntries.get(key);
									PropertyValueReadView displayName = enumerationEntryReadView.getPropertyValueByName("displayName");
									Object value = displayName.getValue();
									enumMap.put(key, value);
								}
								result.put(name, enumMap);
//								System.out.println("===============enum values:"+enumMap);
							}
						}
					}
				}
			}
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println("===============Show enums:"+result);
		return result;
	 }
	 
	 /**
	  * 获取指定类型TypeName的所有属性ibaKey的枚举值列表
	  * @param typeName
	  * @param enumKey
	  * @return  Map<String, Object>
	  */
	 public static Map<String, Object> getIbaEnumConstraint(String typeName,String enumKey){
		 Map<String, Map<String, Object>> ibaEnumConstraint = getIbaEnumConstraint(typeName);
		 
		 Map<String, Object> map = ibaEnumConstraint.get(enumKey);
		 
		 return map;
	 }

	/**
	  * 获取指定类型TypeName的某属性ibaKey的合法值列表，返回为字符串List
	  * @param typeName
	  * @param ibaKey
	  * @return List<String>
	  */
	 public static List<String> getIbaDiscreteSetConstraint(String typeName, String ibaKey){
		List<String> result = new ArrayList<String>();
		if(StringUtils.isBlank(typeName)||StringUtils.isBlank(ibaKey)){
			return result;
		}
		try {
			TypeDefinitionReadView typeDefView = TypeDefinitionServiceHelper.service.getTypeDefView(typeName);
			ArrayList<AttributeDefinitionReadView> typeAttributes = LWCCommands.getTypeAttributes("OR:"+typeDefView.getOid().getStringValue());
			for (AttributeDefinitionReadView attributeDefinitionReadView2 : typeAttributes) {
				String name = attributeDefinitionReadView2.getName();
				if(!StringUtils.equalsIgnoreCase(ibaKey, name)){
					continue;
				}
				Collection collection = attributeDefinitionReadView2.getAllConstraints();
				for (Object object : collection) {
					if(object instanceof ConstraintDefinitionReadView){
						ConstraintDefinitionReadView cdr = (ConstraintDefinitionReadView)object;
						ConstraintRuleDefinitionReadView rule = cdr.getRule();
						String ruleClassname = rule.getRuleClassname();
						if( StringUtils.containsIgnoreCase(ruleClassname,"DiscreteSetConstraint")){//是否合法值列表
							Serializable ruleData = cdr.getRuleData();
							if(ruleData instanceof DiscreteSet){
								DiscreteSet ds = (DiscreteSet)ruleData;
								Object[] elements = ds.getElements();
								if(elements != null && elements.length > 0){
									for(Object obj : elements){
										result.add(String.valueOf(obj));
									}
								}
							}
							break;
						}
					}
				}
				break;
			}
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	 }
	
	 
	
}
