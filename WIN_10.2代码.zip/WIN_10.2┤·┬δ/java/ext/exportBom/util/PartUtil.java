package ext.exportBom.util;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import org.codehaus.jackson.map.ObjectMapper;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class PartUtil {

    /**
     * 找到部件的BOM上层部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            if (part != null) {
                //查到的是什么
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());

                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        list.add(childPart);
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 通过递归找到部件的BOM最上层部件
     *
     * @param part
     * @return List<WTPart>
     */
    public static List<WTPart> getTopParentParts(WTPart part) {
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            if (part != null) {
                QueryResult qr = WTPartHelper.service.getUsedByWTParts((WTPartMaster) part.getMaster());

                if (!qr.hasMoreElements()) {
                    list.add(part);
                } else {
                    while (qr.hasMoreElements()) {
                        WTPart childPart = (WTPart) qr.nextElement();
                        list.addAll(getTopParentParts(childPart));
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 根据部件的VR查找到部件的OR
     *
     * @param VR VR:wt.part.WTPart:569305
     * @return OR OR:wt.part.WTPart:569306
     */
    public static String getORbyVR(String VR) {
        VR = VR.split(":")[2];
        String sql = "SELECT IDA2A2 FROM WTPART WHERE BRANCHIDITERATIONINFO = ?";
        String OR = "";
        try {
            ResultSet resultSet = CommonUtil.excuteSelect(sql, VR);
            while (resultSet.next()) {
                OR = "OR:wt.part.WTPart:" + resultSet.getString("IDA2A2");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return OR;
    }

    public static List<WTPartMaster> getSubstituteParts(WTPartUsageLink useagelink) throws WTException {
        List<WTPartMaster> list = new ArrayList();
        if (useagelink == null) {
            return list;
        } else {
            QueryResult qr = WTPartHelper.service.getSubstitutesWTPartMasters(useagelink);

            while(qr.hasMoreElements()) {
                WTPartMaster master = (WTPartMaster)qr.nextElement();
                list.add(master);
            }

            return list;
        }
    }

    public static List<WTPartMaster> getWTPartAlternateLinks(WTPartMaster wtpartMaster) throws WTException {
        List<WTPartMaster> list = new ArrayList();
        if (wtpartMaster == null) {
            return list;
        } else {
            QueryResult qr = WTPartHelper.service.getAlternatesWTPartMasters(wtpartMaster);

            while(qr.hasMoreElements()) {
                WTPartMaster sLink = (WTPartMaster)qr.nextElement();
                list.add(sLink);
            }

            return list;
        }
    }


    /**
     * 通过父部件和子部件获取部件之间使用关系
     *
     * @param fatherPart
     * @param childPart
     * @return
     */
    public static List<WTPartUsageLink> getWtPartUsageLink(WTPart fatherPart, WTPart childPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier(fatherPart)));
                queryspec.appendAnd();
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

}
