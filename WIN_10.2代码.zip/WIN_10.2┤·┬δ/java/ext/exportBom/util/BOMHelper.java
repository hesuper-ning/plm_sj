package ext.exportBom.util;


import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import ext.sprocomm.bom.*;
import ext.sprocomm.bom.IBAUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.org.WTPrincipal;
import wt.part.PartUsesOccurrence;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

public class BOMHelper {
    public BOMHelper() {
    }

    public static void exportBOMFromPart(WTPart part, OutputStream outputStream) throws Exception {
        String preNumber = Config.getConfig().getProperty("pcba.part.pre.number", "03.");
        System.out.println("002-ExportBOM-config.pcba.part.pre.number:" + preNumber);
        WTPrincipal currPrincipal = null;

        try {
            currPrincipal = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();
            int level = 1;
            System.out.println("002-ExportBOM-Get-BOM-By-Item:" + part.getNumber() + "," + part.getName());
            List<Object[]> newBOMList = new ArrayList();
            InputStream inputStream = null;
            ext.sprocomm.bom.IBAUtil partIba = new ext.sprocomm.bom.IBAUtil(part);
            String[] data;
            byte index;
            int var20;
            if (StringUtils.startsWithIgnoreCase(part.getNumber(), preNumber)) {
                data = new String[12];
                index = 0;
                var20 = index + 1;
                data[index] = "";
                data[var20++] = "";
                data[var20++] = "";
                data[var20++] = "";
                data[var20++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.Factory", "Factory"));
                data[var20++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.SpecificationsModel", "SpecificationsModel"));
                data[var20++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc", "ItemDesc"));
                data[var20++] = part.getNumber();
                data[var20++] = "";
                data[var20++] = part.getName();
                data[var20++] = "";
                data[var20++] = "";
                newBOMList.add(data);
                getAllBomByPartInPCBA(part, newBOMList, level, preNumber);
                inputStream = ExcelTemplate.getExcelTempate("ExportBOM_03.xls");
            } else {
                data = new String[11];
                index = 0;
                var20 = index + 1;
                data[index] = "";
                data[var20++] = "";
                data[var20++] = part.getNumber();
                data[var20++] = part.getName();
                data[var20++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc", "ItemDesc"));
                data[var20++] = "";
                data[var20++] = "";
                data[var20++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.supply", "supply"));
                data[var20++] = "";
                data[var20++] = "";
                data[var20++] = "否";
                newBOMList.add(data);
                getAllBomByPartNoPCBA(part, newBOMList, level, preNumber);
                inputStream = ExcelTemplate.getExcelTempate("ExportBOM_NOT_03.xls");
            }

            HSSFWorkbook workBookTemplate = ExcelUtil.getXlsWorkBookTemplate(inputStream);
            ExcelUtil.exportToExcel(workBookTemplate, 0, (short)1, (short)0, newBOMList);
            workBookTemplate.write(outputStream);
            System.out.println("002-ExportBOM-Export to sheet done.");
        } catch (Exception var17) {
            var17.printStackTrace();
            throw new WTException(var17.getLocalizedMessage());
        } finally {
            if (currPrincipal != null) {
                try {
                    SessionHelper.manager.setPrincipal(currPrincipal.getName());
                } catch (WTException var16) {
                    var16.printStackTrace();
                }
            }

        }


    }

    public static void getAllBomByPartNoPCBA(WTPart rootPart, List<Object[]> list, int level, String preNumber) {
        try {
            List<Object[]> childBOM = getChildBOM(rootPart);
            if (childBOM.size() > 0) {
                for(int i = 0; i < childBOM.size(); ++i) {
                    WTPartUsageLink usageLink = (WTPartUsageLink)((Object[])childBOM.get(i))[0];
                    WTPart sPart = (WTPart)((Object[])childBOM.get(i))[1];
                    ext.sprocomm.bom.IBAUtil usageLinkIBA = new ext.sprocomm.bom.IBAUtil(usageLink);
                    System.out.println("002-ExportBOM-Get-BOM-IBA-" + sPart.getNumber() + ":" + usageLinkIBA.ibaContainer.toString());
                    ext.sprocomm.bom.IBAUtil partIba = new ext.sprocomm.bom.IBAUtil(sPart);
                    String[] data = new String[11];
                    int index = 0;
                    int var14 = index + 1;
                    data[index] = levelString(level);
                    data[var14++] = String.valueOf(usageLink.getLineNumber() == null ? "" : usageLink.getLineNumber());
                    data[var14++] = sPart.getNumber();
                    data[var14++] = sPart.getName();
                    data[var14++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc", "ItemDesc"));
                    data[var14++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.ItemNote", "ItemNote"));
                    String amount = "" + usageLink.getQuantity().getAmount();
                    if (amount.contains("E")) {
                        amount = getRealNumOfScientificNotation(amount);
                    }

                    data[var14++] = amount;
                    data[var14++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.supply", "supply"));
                    data[var14++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.IsBuyCust", "IsBuyCust"));
                    data[var14++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.IsCoustomerService", "IsCoustomerService"));
                    data[var14++] = "否";
                    list.add(data);
                    handleReplacePartsNoPCBA(usageLink, list);
                    if (!StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber)) {
                        getAllBomByPartNoPCBA(sPart, list, level + 1, preNumber);
                    }
                }
            }
        } catch (WTException var13) {
            var13.printStackTrace();
        }

    }

    public static void getAllBomByPartInPCBA(WTPart rootPart, List<Object[]> list, int level, String preNumber) {
        try {
            List<Object[]> childBOM = getChildBOM(rootPart);
            if (childBOM.size() > 0) {
                for(int i = 0; i < childBOM.size(); ++i) {
                    WTPartUsageLink usageLink = (WTPartUsageLink)((Object[])childBOM.get(i))[0];
                    WTPart sPart = (WTPart)((Object[])childBOM.get(i))[1];
                    ext.sprocomm.bom.IBAUtil usageLinkIBA = new ext.sprocomm.bom.IBAUtil(usageLink);
                    System.out.println("002-ExportBOM-Get-BOM-IBA-" + sPart.getNumber() + ":" + usageLinkIBA.ibaContainer.toString());
                    ext.sprocomm.bom.IBAUtil partIba = new ext.sprocomm.bom.IBAUtil(sPart);
                    String[] data = new String[12];
                    int index = 0;
                    int var14 = index + 1;
                    data[index] = levelString(level);
                    data[var14++] = String.valueOf(usageLink.getLineNumber() == null ? "" : usageLink.getLineNumber());
                    String amount = "" + usageLink.getQuantity().getAmount();
                    if (amount.contains("E")) {
                        amount = getRealNumOfScientificNotation(amount);
                    }

                    data[var14++] = amount;
                    data[var14++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.MachinePos", "MachinePos"));
                    data[var14++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.Factory", "Factory"));
                    data[var14++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.SpecificationsModel", "SpecificationsModel"));
                    data[var14++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc", "ItemDesc"));
                    data[var14++] = sPart.getNumber();
                    data[var14++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.IsBuyCust", "IsBuyCust"));
                    data[var14++] = sPart.getName();
                    data[var14++] = usageLinkIBA.getIBAValue(Config.getConfig().getProperty("usagelink.iba.ItemNote", "ItemNote"));
                    data[var14++] = "否";
                    list.add(data);
                    handleReplacePartsInPCBA(usageLink, list);
                    if (!StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber)) {
                        getAllBomByPartInPCBA(sPart, list, level + 1, preNumber);
                    }
                }
            }
        } catch (WTException var13) {
            var13.printStackTrace();
        }

    }

    private static List<Object[]> getChildBOM(WTPart rootPart) {
        List<Object[]> list = new ArrayList();
        QueryResult qr2 = null;

        try {
            Object[] obj;
            for(QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(rootPart); qr.hasMoreElements(); list.add(obj)) {
                obj = new Object[2];
                WTPartUsageLink usageLink = (WTPartUsageLink)qr.nextElement();
                obj[0] = usageLink;
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                LatestConfigSpec cfg = new LatestConfigSpec();
                qr2 = cfg.process(qr2);
                if (qr2.hasMoreElements()) {
                    WTPart sPart = (WTPart)qr2.nextElement();
                    obj[1] = sPart;
                }
            }

            Collections.sort(list, new Comparator<Object[]>() {
                public int compare(Object[] obj1, Object[] obj2) {
                    WTPart part1 = (WTPart)obj1[1];
                    WTPart part2 = (WTPart)obj2[1];
                    return part1.getNumber().compareTo(part2.getNumber());
                }
            });
        } catch (WTException var8) {
            var8.printStackTrace();
        }

        return list;
    }

    private static String getRealNumOfScientificNotation(String doubleStr) {
        int indexOfE = doubleStr.indexOf(69);
        int indexOfPoint = doubleStr.indexOf(46);
        BigInteger zs = new BigInteger(doubleStr.substring(0, indexOfPoint));
        BigInteger xs = new BigInteger(doubleStr.substring(indexOfPoint + BigInteger.ONE.intValue(), indexOfE));
        int pow = Integer.valueOf(doubleStr.substring(indexOfE + BigInteger.ONE.intValue()));
        StringBuffer buffer = new StringBuffer();
        int i;
        if (pow < 0) {
            for(i = 0; i < -pow; ++i) {
                buffer.append(0);
            }

            buffer.insert(BigInteger.ONE.intValue(), ".");
            buffer.append(zs.toString());
            if (!"0".equalsIgnoreCase(xs.toString())) {
                buffer.append(xs.toString());
            }

            doubleStr = buffer.toString();
        } else {
            i = xs.toByteArray().length;
            int needFill0 = pow - i;
            if (needFill0 < 0) {
                buffer.append(xs);
                buffer.insert(pow, ".");
                buffer.insert(0, zs);
                doubleStr = buffer.toString();
            } else {
                for( i = 0; i < needFill0; ++i) {
                    buffer.append(0);
                }

                buffer.insert(0, xs);
                buffer.insert(0, zs);
                doubleStr = buffer.toString();
            }
        }

        return doubleStr;
    }

    private static void handleReplacePartsNoPCBA(WTPartUsageLink usageLink, List<Object[]> list) throws WTException {
        List<WTPartMaster> substituteParts =PartUtil.getSubstituteParts(usageLink);
        List<WTPartMaster> wtPartAlternateLinks =PartUtil.getWTPartAlternateLinks((WTPartMaster)usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);

        for(int i = 0; i < substituteParts.size(); ++i) {
            WTPartMaster wtPartMaster = (WTPartMaster)substituteParts.get(i);
            QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr2 = cfg.process(qr2);
            if (qr2.hasMoreElements()) {
                WTPart sPart = (WTPart)qr2.nextElement();
                ext.sprocomm.bom.IBAUtil partIba = new ext.sprocomm.bom.IBAUtil(sPart);
                String[] data = new String[11];
                int index = 0;
                int var12 = index + 1;
                data[index] = "";
                data[var12++] = "";
                data[var12++] = sPart.getNumber();
                data[var12++] = sPart.getName();
                data[var12++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc", "ItemDesc"));
                data[var12++] = "";
                data[var12++] = "";
                data[var12++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.supply", "supply"));
                data[var12++] = "";
                data[var12++] = "";
                data[var12++] = "是";
                list.add(data);
            }
        }

    }

    private static void handleReplacePartsInPCBA(WTPartUsageLink usageLink, List<Object[]> list) throws WTException {
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster)usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);

        for(int i = 0; i < substituteParts.size(); ++i) {
            WTPartMaster wtPartMaster = (WTPartMaster)substituteParts.get(i);
            QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr2 = cfg.process(qr2);
            if (qr2.hasMoreElements()) {
                WTPart sPart = (WTPart)qr2.nextElement();
                ext.sprocomm.bom.IBAUtil partIba = new IBAUtil(sPart);
                String[] data = new String[12];
                int index = 0;
                int var12 = index + 1;
                data[index] = "";
                data[var12++] = "";
                data[var12++] = "";
                data[var12++] = "";
                data[var12++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.Factory", "Factory"));
                data[var12++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.SpecificationsModel", "SpecificationsModel"));
                data[var12++] = partIba.getIBAValue(Config.getConfig().getProperty("part.iba.ItemDesc", "ItemDesc"));
                data[var12++] = sPart.getNumber();
                data[var12++] = "";
                data[var12++] = sPart.getName();
                data[var12++] = "";
                data[var12++] = "是";
                list.add(data);
            }
        }

    }

    public static String getPartUsesOccurrence(WTPartUsageLink useagelink) throws WTException {
        List listWTPart2 = new ArrayList();
        long linkid = PersistenceHelper.getObjectIdentifier(useagelink).getId();
        QuerySpec qs = new QuerySpec(PartUsesOccurrence.class);
        qs.appendWhere(new SearchCondition(PartUsesOccurrence.class, "linkReference.key.id", "=", linkid));
        QueryResult qr = PersistenceHelper.manager.find(qs);
        String occurrenceStr = "";

        while(qr.hasMoreElements()) {
            PartUsesOccurrence occurrence = (PartUsesOccurrence)qr.nextElement();
            listWTPart2.add(occurrence.getName());
        }

        for(int i = 0; i < listWTPart2.size(); ++i) {
            if (listWTPart2.get(i) != null) {
                String ocName = listWTPart2.get(i).toString();
                if (i == 0) {
                    occurrenceStr = ocName;
                } else {
                    occurrenceStr = occurrenceStr + "," + ocName;
                }
            }
        }

        String numberStr = sortPlaceNumber(occurrenceStr);
        return numberStr;
    }

    public static String sortPlaceNumber(String numberStr) {
        TreeMap tm = new TreeMap();
        String[] s = numberStr.split(",");

        for(int i = 0; i < s.length; ++i) {
            tm.put(s[i], s[i]);
        }

        Iterator it = tm.keySet().iterator();
        String number = "";

        for(int a = 0; it.hasNext(); ++a) {
            if (a == 0) {
                number = (String)it.next();
            } else {
                number = number + "," + (String)it.next();
            }
        }

        return number;
    }

    private static String levelString(int level) {
        StringBuffer sb = new StringBuffer("*");

        for(int i = 1; i < level; ++i) {
            sb.append("*");
        }

        String levelStr = StringUtils.replace(sb.toString(), "*", "  ", sb.length() - 1);
        return levelStr;
    }
}
