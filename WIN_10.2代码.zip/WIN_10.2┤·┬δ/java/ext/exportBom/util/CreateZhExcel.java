package ext.exportBom.util;
import ext.exportBom.vo.ReplacePartsVO;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

import java.io.IOException;
import java.math.BigInteger;
import java.util.*;

public class CreateZhExcel {

//    private static Map<String, Object> isBuyEnumConstraint = IBAEnumUtil.getIbaEnumConstraint("wt.part.WTPartUsageLink", PropertiesUtil.getValueByKey("usagelink.iba.IsBuyCust"));
//    private static Map<String, Object> isCusEnumConstraint = IBAEnumUtil.getIbaEnumConstraint("wt.part.WTPartUsageLink", PropertiesUtil.getValueByKey("usagelink.iba.IsCoustomerService"));

    private String isCustServiceValue = "1";
    private String isByCustValue = "1";
    private String signSample = "1";
    private int rowNum = 0;

    public Workbook createExcel(WTPart part)
            throws IOException, Exception {
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");

        //判断是否为03.  PCBA
        if (StringUtils.startsWithIgnoreCase(part.getNumber(), preNumber)) {
            // 创建Excel工作簿
            XSSFWorkbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("电子料-中文bom");
            // 创建表头
            Row headerRow = sheet.createRow(rowNum++);
            headerRow.createCell(0).setCellValue("层级");
            headerRow.createCell(1).setCellValue("行号");
            headerRow.createCell(2).setCellValue("数量");
            headerRow.createCell(3).setCellValue("工位");
            headerRow.createCell(4).setCellValue("厂家");
            headerRow.createCell(5).setCellValue("规格型号");
            headerRow.createCell(6).setCellValue("物料描述");
            headerRow.createCell(7).setCellValue("编号");
            headerRow.createCell(8).setCellValue("是否客供物料");
            headerRow.createCell(9).setCellValue("名称");
            headerRow.createCell(10).setCellValue("物料行备注");
            headerRow.createCell(11).setCellValue("是否存在替代料");
            getHeadStyle(workbook, headerRow, sheet);//设置头部样式

            System.out.println("打印part的name和number" + part.getName() + part.getNumber());
            IBAUtil partIba = new IBAUtil(part);

            Row row = sheet.createRow(rowNum++); // 第一行打印整机物料行
            row.createCell(0).setCellValue("");
            row.createCell(1).setCellValue("");
            row.createCell(2).setCellValue("");//数量
            row.createCell(3).setCellValue("");
            row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.SpecificationsModel")));
            row.createCell(6).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));
            row.createCell(7).setCellValue(part.getNumber());
            row.createCell(8).setCellValue("");
            row.createCell(9).setCellValue(part.getName());
            row.createCell(10).setCellValue("");
            row.createCell(11).setCellValue("");


            //设置样式
            getDataStyle(workbook, row, sheet);
            int level = 1;
            getAllBomByPartPCBA(part, sheet, level, workbook);
            AdjustColumnWidthFromExistingWorkbook(workbook);
            return workbook;
        } else {
            XSSFWorkbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("组装料-中文bom");
            // 创建表头
            Row headerRow = sheet.createRow(rowNum++);
            headerRow.createCell(0).setCellValue("层级");
            headerRow.createCell(1).setCellValue("行号");
            headerRow.createCell(2).setCellValue("编号");
            headerRow.createCell(3).setCellValue("名称");
            headerRow.createCell(4).setCellValue("物料描述");
            headerRow.createCell(5).setCellValue("物料行备注");
            headerRow.createCell(6).setCellValue("数量");
            headerRow.createCell(7).setCellValue("供应商");
            headerRow.createCell(8).setCellValue("供应商全称");
            headerRow.createCell(9).setCellValue("是否签样");
            headerRow.createCell(10).setCellValue("是否客供物料");
            headerRow.createCell(11).setCellValue("是否售后物料");
            headerRow.createCell(12).setCellValue("是否存在替代料");
            getHeadStyle(workbook, headerRow, sheet);//设置头部样式

            System.out.println("打印part的name和number" + part.getName() + part.getNumber());
            IBAUtil partIba = new IBAUtil(part);

            Row row = sheet.createRow(rowNum++); // 第一行打印整机物料行
            row.createCell(0).setCellValue("");
            row.createCell(1).setCellValue("");
            row.createCell(2).setCellValue(part.getNumber());//编号
            row.createCell(3).setCellValue(part.getName());//名称
            row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));//物料描述
            row.createCell(5).setCellValue("");//物料备注行
            row.createCell(6).setCellValue("");//数量
            row.createCell(7).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply")));//供应商
            row.createCell(8).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supplierFullName")));//供应商全名
            row.createCell(9).setCellValue("");//是否签样
            row.createCell(10).setCellValue("");//是否客供
            row.createCell(11).setCellValue("");//是否售后
            row.createCell(12).setCellValue("");

            //设置样式
            getDataStyle(workbook, row, sheet);
            int level = 1;
            getAllBomByPartNoPCBA(part, sheet, level, workbook);
            AdjustColumnWidthFromExistingWorkbook(workbook);
            return workbook;
        }

    }

    /**
     * 找到所有PCBA料
     *
     * @param part
     * @param sheet
     * @param level
     * @param workbook
     * @throws WTException
     */
    boolean mark = false;
    private void getAllBomByPartPCBA(WTPart part, Sheet sheet, int level, XSSFWorkbook workbook) throws WTException {
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");


        System.out.println("打印编号03.和CK/S" + preNumber + pcbaContent);
        List<Object[]> childBOM = getChildBOM(part);
        Locale loc = SessionHelper.getLocale();
        System.out.println("002-地址:" + loc.toString());
        Locale locs = Locale.ENGLISH;
        System.out.println("002-Address: " + locs.toString());

        if (childBOM.size() > 0) {
            for (int i = 0; i < childBOM.size(); i++) {
                WTPartUsageLink usageLink = (WTPartUsageLink) childBOM.get(i)[0];
                WTPart sPart = (WTPart) childBOM.get(i)[1];
                IBAUtil usageLinkIBA = new IBAUtil(usageLink);
                IBAUtil partIba = new IBAUtil(sPart);
                System.out.println("打印rowNUm（在第几行）" + rowNum);
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(levelString(level));
                row.createCell(1).setCellValue(String.valueOf(usageLink.getLineNumber() == null ? "" : usageLink.getLineNumber()));
                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(2).setCellValue(amount);
                row.createCell(3).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.MachinePos")));
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.Factory")));
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.SpecificationsModel")));
                row.createCell(6).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));
                row.createCell(7).setCellValue(sPart.getNumber());

                String isByCust = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsBuyCust"));
                isByCust = isByCustValue.equals(isByCust) ? "是":"否";
                row.createCell(8).setCellValue(isByCust);
                row.createCell(9).setCellValue(sPart.getName());
                row.createCell(10).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.ItemNote")));
                //数据样式
                row.createCell(11).setCellValue("");
                getDataStyle(workbook, row, sheet);

                //是否为替代料
                if (isIngredients(usageLink)) {
                    row.getCell(11).setCellValue("Y");
                }

//                //是否为标记颜色替代料
//                if (isColorIngredients(usageLink)) {
//                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(231, 219, 185)));
//                    mark = true;
//                }
//
//                if (mark) {
//                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(231, 219, 185)));
//                }

                System.out.println("打印查完替代料后的rowNUm（在第几行）" + rowNum);


                System.out.println("厂家型号" + PropertiesUtil.getValueByKey("part.iba.Factory"));

                System.out.println("getName:" + sPart.getName());
                System.out.println("是否含有CK/S" + StringUtils.contains(sPart.getNumber(), pcbaContent));
                System.out.println("getNumber:" + sPart.getNumber());
                System.out.println("开头是否含有03." + StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber));


                //03.开头只有CK/S才导出
                if (isGetChildPart(sPart)) {
                    System.out.println("导出：dom");
                    getAllBomByPartPCBA(sPart, sheet, level + 1, workbook);
                }
                ReplacePartsVO replacePartsVO = handleReplacePartsInPCBA(usageLink, workbook, sheet, level,false);
            }
            mark = false;

        }
    }

    /**
     * 找到所有非PCBA料
     *
     * @param part
     * @param sheet
     * @param level
     * @param workbook
     * @throws WTException
     */
    boolean mark2 = false;// 是否为BOM组件
    private void getAllBomByPartNoPCBA(WTPart part, Sheet sheet, int level, XSSFWorkbook workbook) throws WTException {
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");
        System.out.println("打印编号03.和CK/S" + preNumber + pcbaContent);
        List<Object[]> childBOM = getChildBOM(part);
        Locale loc = SessionHelper.getLocale();
        System.out.println("002-地址:" + loc.toString());
        Locale locs = Locale.ENGLISH;
        System.out.println("002-Address: " + locs.toString());


        if (childBOM.size() > 0) {
            for (int i = 0; i < childBOM.size(); i++) {
                WTPartUsageLink usageLink = (WTPartUsageLink) childBOM.get(i)[0];
                WTPart sPart = (WTPart) childBOM.get(i)[1];
                IBAUtil usageLinkIBA = new IBAUtil(usageLink);
                IBAUtil partIba = new IBAUtil(sPart);
                System.out.println("打印rowNUm（在第几行）" + rowNum);
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(levelString(level));// 层级
                row.createCell(1).setCellValue(String.valueOf(usageLink.getLineNumber() == null ? "" : usageLink.getLineNumber()));//行号
                row.createCell(2).setCellValue(sPart.getNumber());//编号
                row.createCell(3).setCellValue(sPart.getName());//名称
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));//物料描述
                row.createCell(5).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.ItemNote")));//物料行备注
                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(6).setCellValue(amount);//数量
                row.createCell(7).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply")));//供应商
                row.createCell(8).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supplierFullName")));//供应商全名

                String isSignSample = partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.signSample"));
                isSignSample = signSample.equals(isSignSample) ? "是":"否";
                row.createCell(9).setCellValue(isSignSample);//是否签样

                String isByCust = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsBuyCust"));
                isByCust = isByCustValue.equals(isByCust) ? "是":"否";
                row.createCell(10).setCellValue(isByCust);

                String IsCoustomerService = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsCoustomerService"));//是否售后
                IsCoustomerService = isCustServiceValue.equals(IsCoustomerService) ? "是":"否";
                row.createCell(11).setCellValue(IsCoustomerService);//是否售后物料
                row.createCell(12).setCellValue("");
                //数据样式
                getDataStyle(workbook, row, sheet);

                //是否存在替代料
                if (isIngredients(usageLink)) {
                    row.getCell(12).setCellValue("Y");
                }

//                //是否为标记颜色替代料
//                if (isColorIngredients(usageLink)) {
//                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(231, 219, 185)));
//                    mark2 = true;
//                }
//
//                if (mark2){
//                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(231, 219, 185)));
//                }


//                //兄弟料循环结束，且替代料循环结束
//                if (i ==childBOM.size()-1 && ( )){
//                    mark2 = false;
//                }

                System.out.println("打印查完替代料后的rowNUm（在第几行）" + rowNum);


//                System.out.println("厂家型号" + PropertiesUtil.getValueByKey("part.iba.Factory"));
                System.out.println("============信息==============");
                System.out.println("供应商: " + partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply")));
                System.out.println("getName:" + sPart.getName());
                System.out.println(sPart.getNumber() + "是否含有S:" + StringUtils.contains(sPart.getNumber(), "S"));
                System.out.println(sPart.getNumber() + "是否含有CK:" + StringUtils.contains(sPart.getNumber(), "CK"));
                System.out.println(sPart.getNumber() + "是否含有CK/S:" + StringUtils.contains(sPart.getNumber(), pcbaContent));
                System.out.println("getNumber:" + sPart.getNumber());
                System.out.println("开头是否含有03." + StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber));


                System.out.println("03.开头 不含CK/S" + (StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber)
                        && (!StringUtils.contains(sPart.getNumber(), "CK") || !StringUtils.contains(sPart.getNumber(), "S"))));


                if (isGetChildPart(sPart)) {
                    System.out.println("导出：dom");
                    getAllBomByPartNoPCBA(sPart, sheet, level + 1, workbook);
                }

                //查询是否有替代料+
                ReplacePartsVO replacePartsVO = handleReplacePartsNoPCBA(usageLink, workbook, sheet, level,false);
            }
            mark2 = false;// 是否为BOM组件

        }
    }

    /**
     * 判断是否为标记颜色的被替代料（替代料数量大于1或替代料有子料）
     *
     * @param usageLink
     * @return
     * @throws WTException
     */
    public static boolean isColorIngredients(WTPartUsageLink usageLink) throws WTException {
        boolean flag = false;
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);

        //
        for (int i = 0; i < substituteParts.size(); i++) {
            WTPartMaster wtPartMaster = substituteParts.get(i);
            QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr2 = cfg.process(qr2);
            if (qr2.hasMoreElements()) {
                WTPart sPart = (WTPart) qr2.nextElement();

                //替代料有子料
                List<Object[]> childBOM = getChildBOM(sPart);
                if (childBOM.size() > 0) {
                    flag = true;
                }

            }

        }
        //替代料大于1个
        if (substituteParts.size() > 1) {
            flag = true;
        }


        return flag;
    }

    /**
     * 是否存在替代料
     * @param usageLink
     * @return
     * @throws WTException
     */
    public static boolean isIngredients(WTPartUsageLink usageLink) throws WTException {
        boolean flag = false;
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);
        if (substituteParts.size() > 0) {
            flag = true;
        }

        return flag;
    }

    public static boolean isMarkReplace(WTPartUsageLink usageLink) throws WTException {
        boolean flag = false;
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);
        if (substituteParts.size() > 0) {
            flag = true;
        }

        return flag;
    }

    /**
     * 获取子阶列表，按物料编码排序
     *
     * @param rootPart
     * @return
     */
    private static List<Object[]> getChildBOM(WTPart rootPart) {
        List<Object[]> list = new ArrayList<Object[]>();
        QueryResult qr2 = null;
        try {
            Object[] obj;
            for (QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(rootPart); qr.hasMoreElements(); list.add(obj)) {
                obj = new Object[2];
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                obj[0] = usageLink;
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                LatestConfigSpec cfg = new LatestConfigSpec();
                qr2 = cfg.process(qr2);
                if (qr2.hasMoreElements()) {
                    WTPart sPart = (WTPart) qr2.nextElement();
                    obj[1] = sPart;
                }
            }
            Collections.sort(list, new Comparator<Object[]>() {
                public int compare(Object[] obj1, Object[] obj2) {
                    WTPart part1 = (WTPart) obj1[1];
                    WTPart part2 = (WTPart) obj2[1];

//                    WTPartUsageLink usageLink1 = (WTPartUsageLink) obj1[0];
//                    WTPartUsageLink usageLink2 = (WTPartUsageLink) obj2[0];
//
//                    WTPart part1 = (WTPart) obj1[1];
//                    WTPart part2 = (WTPart) obj2[1];
//
//                    //先根据行号排序
//                    Long lineNumber1 = usageLink1.getLineNumber() != null ? usageLink1.getLineNumber().getValue() : null;
//                    Long lineNumber2 = usageLink2.getLineNumber() != null ? usageLink2.getLineNumber().getValue() : null;

//                    if (lineNumber1 != null && lineNumber2 != null) {
//                        int compareResult = lineNumber1.compareTo(lineNumber2);
//                        if (compareResult == 0) {
//                            //行号相同根据编号排序
//                            return part1.getNumber().compareTo(part2.getNumber());
//                        }
//                        return compareResult;
//                    } else if (lineNumber1 != null) {
//                        return -1; // obj2 的行号为空，将其排在后面
//                    } else if (lineNumber2 != null) {
//                        return 1; // obj1 的行号为空，将其排在后面
//                    } else {
//                        return part1.getNumber().compareTo(part2.getNumber()); // both lineNumber1 and lineNumber2 are null
//                    }
                    return part1.getNumber().compareTo(part2.getNumber());
                }
            });
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    private String levelString(int level) {
        StringBuffer sb = new StringBuffer("*");
        for (int i = 1; i < level; i++) {
            sb.append("*");
        }
        String levelStr = StringUtils.replace(sb.toString(), "*", "  ", sb.length() - 1);
        return levelStr;
    }

    /**
     * 科学计数法改为数字字符串
     *
     * @param doubleStr
     * @return
     */
    private String getRealNumOfScientificNotation(String doubleStr) {
        int indexOfE = doubleStr.indexOf('E');
        int indexOfPoint = doubleStr.indexOf('.');
        // 整数部分
        BigInteger zs = new BigInteger(doubleStr.substring(0, indexOfPoint));
        // 小数部分
        BigInteger xs = new BigInteger(doubleStr.substring(indexOfPoint
                + BigInteger.ONE.intValue(), indexOfE));
        // 指数
        int pow = Integer.valueOf(doubleStr.substring(indexOfE
                + BigInteger.ONE.intValue()));
        StringBuffer buffer = new StringBuffer();
        // e.g. 1.23E-5
        if (pow < 0) {
            for (int i = 0; i < -pow; i++) {
                buffer.append(0);
            }
            buffer.insert(BigInteger.ONE.intValue(), ".");
            buffer.append(zs.toString());
            if (!"0".equalsIgnoreCase(xs.toString())) {
                buffer.append(xs.toString());
            }
            doubleStr = buffer.toString();
        } else {
            int xsLen = xs.toByteArray().length;
            int needFill0 = pow - xsLen;
            if (needFill0 < 0) {
                // e.g. 1.234E2
                buffer.append(xs);
                buffer.insert(pow, ".");
                buffer.insert(0, zs);
                doubleStr = buffer.toString();
            } else {
                // e.g. 1.234E6 or 1.234E3
                for (int i = 0; i < needFill0; i++) {
                    buffer.append(0);
                }
                buffer.insert(0, xs);
                buffer.insert(0, zs);
                doubleStr = buffer.toString();
            }
        }
        return doubleStr;
    }


    /**
     * 查找PCBA替代料
     *
     * @param usageLink
     * @param sheet
     * @return 返回下一行以及下级bom对象
     * @throws WTException
     */
    private ReplacePartsVO handleReplacePartsInPCBA(WTPartUsageLink usageLink, XSSFWorkbook workbook, Sheet sheet, int level , boolean flag) throws WTException {
        System.out.println("查找是否含有替代料");
        ReplacePartsVO result = new ReplacePartsVO();
        result.setRowNum(rowNum);//设置原本的行
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);
        for (int i = 0; i < substituteParts.size(); i++) {
            System.out.println("rowNum到第" + rowNum + "行");
            System.out.println("含有");
            WTPartMaster wtPartMaster = substituteParts.get(i);
            QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr2 = cfg.process(qr2);
            if (qr2.hasMoreElements()) {
                WTPart sPart = (WTPart) qr2.nextElement();
                System.out.println(sPart.getName());
                IBAUtil partIba = new IBAUtil(sPart);
//                IBAUtil usageLinkIBA = new IBAUtil(wtPartMaster);
                Row row = sheet.createRow(rowNum++);//替代料主料行
                row.createCell(0).setCellValue("");//层级
                row.createCell(1).setCellValue("");
                row.createCell(2).setCellValue("");
                row.createCell(3).setCellValue("");
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.Factory")));
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.SpecificationsModel")));
                row.createCell(6).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));
                row.createCell(7).setCellValue(sPart.getNumber());
//                String isByCust = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsBuyCust"));
//                isByCust = isByCustValue.equals(isByCust) ? "是":"否";
//                row.createCell(8).setCellValue(isByCust);
                row.createCell(8).setCellValue("");//是否客供
                row.createCell(9).setCellValue(sPart.getName());
                row.createCell(10).setCellValue("");
                row.createCell(11).setCellValue("");


                //判断是否有子级
                List<Object[]> childBOM = getChildBOM(sPart);
                if ( !childBOM.isEmpty() && isGetChildPart(sPart)) {
                    //替代料主料的填充颜色
                    XSSFCellStyle rowStyle = setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(161, 179, 215)));
                    //获取替代料子料
                    getReplacePartsChildBOMInPCBA(sPart, workbook, sheet, level + 1);
                } else {
                    // 只设置样式
                    getDataStyle(workbook, row, sheet);
                }

                if (flag) {
                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));//
                }

                result.setRowNum(rowNum);
                result.setWtPart(sPart);
                System.out.println(result.toString());

            }
        }
        return result; //   返在第几行
    }

    /**
     * 查找非PCBA替代料
     *
     * @param usageLink
     * @param sheet
     * @return 返回下一行以及下级bom对象
     * @throws WTException
     */
    private ReplacePartsVO handleReplacePartsNoPCBA(WTPartUsageLink usageLink, XSSFWorkbook workbook, Sheet sheet, int level,boolean flag) throws WTException {
        System.out.println("查找是否含有替代料");
        ReplacePartsVO result = new ReplacePartsVO();
        result.setRowNum(rowNum);//设置原本的行
        //查找特定替代
        List<WTPartMaster> substituteParts = PartUtil.getSubstituteParts(usageLink);
        //查找全局替代
        List<WTPartMaster> wtPartAlternateLinks = PartUtil.getWTPartAlternateLinks((WTPartMaster) usageLink.getRoleBObject());
        substituteParts.addAll(wtPartAlternateLinks);
        for (int i = 0; i < substituteParts.size(); i++) {
            System.out.println("rowNum到第" + rowNum + "行");
            System.out.println("含有");
            WTPartMaster wtPartMaster = substituteParts.get(i);
            QueryResult qr2 = VersionControlHelper.service.allVersionsOf(wtPartMaster);
            LatestConfigSpec cfg = new LatestConfigSpec();
            qr2 = cfg.process(qr2);
            if (qr2.hasMoreElements()) {
                WTPart sPart = (WTPart) qr2.nextElement();
                System.out.println(sPart.getName());
//                IBAUtil usageLinkIBA = new IBAUtil(wtPartMaster);//
                IBAUtil partIba = new IBAUtil(sPart);
                Row row = sheet.createRow(rowNum++);//替代料的行
                row.createCell(0).setCellValue("");//层级
                row.createCell(1).setCellValue("");//行号
                row.createCell(2).setCellValue(sPart.getNumber());//编号
                row.createCell(3).setCellValue(sPart.getName());//名称
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));//物料描述
//                row.createCell(5).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.ItemNote")));//物料行备注
                row.createCell(5).setCellValue("");//物料行备注
//                String amount = "" + usageLink.getQuantity().getAmount();
//                if (amount.contains("E")) {
//                    amount = getRealNumOfScientificNotation(amount);
//                }
//                row.createCell(6).setCellValue(amount);//数量
                row.createCell(6).setCellValue("");//数量
                row.createCell(7).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply")));//供应商
                row.createCell(8).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supplierFullName")));//供应商全名

                String isSignSample = partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.signSample"));
                isSignSample = signSample.equals(isSignSample) ? "是":"否";
                row.createCell(9).setCellValue(isSignSample);//是否签样

//                String isByCust = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsBuyCust"));
//                isByCust = isByCustValue.equals(isByCust) ? "是":"否";
//                row.createCell(10).setCellValue(isByCust);//是否客供
                row.createCell(10).setCellValue("");//是否客供

//                String IsCoustomerService = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsCoustomerService"));//是否售后
//                IsCoustomerService = isCustServiceValue.equals(IsCoustomerService) ? "是":"否";
//                row.createCell(11).setCellValue(IsCoustomerService);//是否售后物料
                row.createCell(11).setCellValue("");//是否售后物料

                row.createCell(12).setCellValue("");
                //判断替代料是否有子级
                List<Object[]> childBOM = getChildBOM(sPart);

                //替代料主料的填充颜色
//                XSSFCellStyle rowStyle = setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));//
                // 替代料不只1个，或 替代俩有bom
                if ( !childBOM.isEmpty() && isGetChildPart(sPart)) {
                    //替代料主料的填充颜色
                    XSSFCellStyle rowStyle = setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(161, 179, 215)));
                    getReplacePartsChildBOMNoPCBA(sPart, workbook, sheet, level + 1);
                } else {
                    // 只设置样式
                    getDataStyle(workbook, row, sheet);
                }

                if (flag) {
                    setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));//
                }

                result.setRowNum(rowNum);
                result.setWtPart(sPart);
                System.out.println(result.toString());




            }
        }
        return result; //   返在第几行
    }




    /**
     * 找到PCBA替代料子级
     *
     * @param replacePartsPart
     * @param sheet
     * @param level
     * @return 返回下行
     * @throws WTException
     */
    private int getReplacePartsChildBOMInPCBA(WTPart replacePartsPart, XSSFWorkbook workbook, Sheet sheet, int level) throws WTException {
        int result = rowNum;
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");
        List<Object[]> childBOM = getChildBOM(replacePartsPart);
        //设置父类颜色
        if (childBOM.size() > 0) {
            for (int i = 0; i < childBOM.size(); i++) {
                WTPartUsageLink usageLink = (WTPartUsageLink) childBOM.get(i)[0];
                WTPart sPart = (WTPart) childBOM.get(i)[1];
                IBAUtil usageLinkIBA = new IBAUtil(usageLink);
                IBAUtil partIba = new IBAUtil(sPart);

                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(levelString(level));
                row.createCell(1).setCellValue(String.valueOf(usageLink.getLineNumber() == null ? "" : usageLink.getLineNumber()));
                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(2).setCellValue(amount);
                row.createCell(3).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.MachinePos")));
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.Factory")));
                row.createCell(5).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.SpecificationsModel")));
                row.createCell(6).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));
                row.createCell(7).setCellValue(sPart.getNumber());
                String isByCust = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsBuyCust"));
                isByCust = isByCustValue.equals(isByCust) ? "是":"否";
                row.createCell(8).setCellValue(isByCust);
                row.createCell(9).setCellValue(sPart.getName());
                row.createCell(10).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.ItemNote")));
                row.createCell(11).setCellValue("");

                //是否存在替代料
                if (isIngredients(usageLink)) {
                    row.getCell(11).setCellValue("Y");
                }
                //替代料子料的填充颜色  217, 225, 242
                XSSFCellStyle rowStyle = setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));


                System.out.println("getNumber:" + sPart.getNumber());
                System.out.println("开头是否含有03." + StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber));

                System.out.println("打印rowNUm（在第几行）" + rowNum);
                //pcba是03.开头 不含有 CK/S   无需导出bom
                if (isGetChildPart(sPart)) {
                    System.out.println("导出：dom");
                    result = getReplacePartsChildBOMInPCBA(sPart, workbook, sheet, level + 1);
                }

                // 替代料的操作
                handleReplacePartsInPCBA(usageLink, workbook, sheet, level ,true);
            }
        }
        return result;
    }

    /**
     * 找到非PCBA替代料子级
     *
     * @param replacePartsPart
     * @param sheet
     * @param level
     * @return 返回下行
     * @throws WTException
     */
    private int getReplacePartsChildBOMNoPCBA(WTPart replacePartsPart, XSSFWorkbook workbook, Sheet sheet, int level) throws WTException {
        int result = rowNum;
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number"); // 0.3
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet"); // CK/S
        List<Object[]> childBOM = getChildBOM(replacePartsPart);
        //设置父类颜色
        if (childBOM.size() > 0) {
            for (int i = 0; i < childBOM.size(); i++) {
                WTPartUsageLink usageLink = (WTPartUsageLink) childBOM.get(i)[0];
                WTPart sPart = (WTPart) childBOM.get(i)[1];
                IBAUtil usageLinkIBA = new IBAUtil(usageLink);
                IBAUtil partIba = new IBAUtil(sPart);

                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(levelString(level));// 层级
                row.createCell(1).setCellValue(String.valueOf(usageLink.getLineNumber() == null ? "" : usageLink.getLineNumber()));//行号
                row.createCell(2).setCellValue(sPart.getNumber());//编号
                row.createCell(3).setCellValue(sPart.getName());//名称
                row.createCell(4).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc")));//物料描述
                row.createCell(5).setCellValue(usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.ItemNote")));//物料行备注
                String amount = "" + usageLink.getQuantity().getAmount();
                if (amount.contains("E")) {
                    amount = getRealNumOfScientificNotation(amount);
                }
                row.createCell(6).setCellValue(amount);//数量
                row.createCell(7).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply")));//供应商
                row.createCell(8).setCellValue(partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supplierFullName")));//供应商全名
                String isSignSample = partIba.getIBAValue(PropertiesUtil.getValueByKey("part.iba.signSample"));
                isSignSample = signSample.equals(isSignSample) ? "是":"否";
                row.createCell(9).setCellValue(isSignSample);//是否签样

                String isByCust = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsBuyCust"));
                isByCust = isByCustValue.equals(isByCust) ? "是":"否";
                row.createCell(10).setCellValue(isByCust);

                String IsCoustomerService = usageLinkIBA.getIBAValue(PropertiesUtil.getValueByKey("usagelink.iba.IsCoustomerService"));//是否售后
                IsCoustomerService = isCustServiceValue.equals(IsCoustomerService) ? "是":"否";
                row.createCell(11).setCellValue(IsCoustomerService);//是否售后物料
                row.createCell(12).setCellValue("");


                //是否存在替代料
                if (isIngredients(usageLink)) {
                    row.getCell(12).setCellValue("Y");
                }

                //替代料子料的填充颜色
                setBackgroundColor(workbook, row, sheet, new XSSFColor(new java.awt.Color(135, 206, 250)));//



                System.out.println("getNumber:" + sPart.getNumber());
                System.out.println("开头是否含有03." + StringUtils.startsWithIgnoreCase(sPart.getNumber(), preNumber));

                System.out.println("打印rowNUm（在第几行）" + rowNum);
                //pcba是03.开头 不含有 CK/S   无需导出bom
                if (isGetChildPart(sPart)) {
                    System.out.println("导出：dom");
                    result = getReplacePartsChildBOMNoPCBA(sPart, workbook, sheet, level + 1);
                }
                // 替代料的操作
                handleReplacePartsNoPCBA(usageLink, workbook, sheet, level,true);

            }
        }
        return result;
    }

    /**
     * 03.开头 只有含有CK/S才导出子料
     * @param part
     * @return  true才导出子项
     */
    public static boolean isGetChildPart(WTPart part){
        String preNumber = PropertiesUtil.getValueByKey("pcba.part.pre.number");//03.
        String pcbaContent = PropertiesUtil.getValueByKey("pcba.part.contenet");
        boolean flag = true;
        //03.开头，不含CK/S 不获取子项
        if (StringUtils.startsWithIgnoreCase(part.getNumber(), preNumber)
                && !StringUtils.contains(part.getNumber(), "CK")
                && !StringUtils.contains(part.getNumber(), "S")) {
            flag = false;

        }

        return flag;

    }

    /**
     * 表头格式
     *
     * @param xssfwb
     * @return cellStyle
     */
    public XSSFCellStyle getHeadStyle(XSSFWorkbook xssfwb, Row row, Sheet sheet) {
        XSSFCellStyle cellStyle = xssfwb.createCellStyle();
        // 字体
        XSSFFont font = xssfwb.createFont();
        font.setFontHeightInPoints((short) 12);
        font.setFontName("黑体");
        cellStyle.setFont(font);

        //高度
        row.setHeightInPoints(30);
        // 边框
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        // 对齐
        cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
        cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);


        for (int i = 0; i < row.getLastCellNum(); i++) {
            Cell cell = row.getCell(i);

            cell.setCellStyle(cellStyle);
            sheet.autoSizeColumn(i);
        }

        return cellStyle;
    }


    /**
     * 内容格式
     *
     * @param xssfwb
     * @return cellStyle
     */
    public XSSFCellStyle getDataStyle(XSSFWorkbook xssfwb, Row row, Sheet sheet) {
        XSSFCellStyle cellStyle = xssfwb.createCellStyle();

        // 字体
        XSSFFont font = xssfwb.createFont();
        font.setFontHeightInPoints((short) 11);
        font.setFontName("宋体");
        cellStyle.setFont(font);
        // 边框
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        // 对齐
        cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
        cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);

        // 生效
        for (Cell cell : row) {
            cell.setCellStyle(cellStyle);
        }
        return cellStyle;
    }

    /**
     * 根据指定行填充颜色
     *
     * @param xssfwb
     * @param row
     * @return
     */
    public XSSFCellStyle setBackgroundColor(XSSFWorkbook xssfwb, Row row, Sheet sheet, XSSFColor color) {
        //颜色
        XSSFCellStyle rowStyle;
        //获取数据样式
        rowStyle = getDataStyle(xssfwb, row, sheet);
        //背景色
        rowStyle.setFillForegroundColor(color);//背景色
        rowStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);//实心填充
        for (Cell cell : row) {
            cell.setCellStyle(rowStyle);
        }
        return rowStyle;
    }

    public void AdjustColumnWidthFromExistingWorkbook(XSSFWorkbook xssfwb) {
        Sheet sheet = xssfwb.getSheetAt(0);

        // 定义最大宽度
        int maxColumnWidth = 35; // 最大宽度为 40 个字符

        // 从表格的第一行开始设置列的宽度
        for (int rowIndex = 0; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
            Row row = sheet.getRow(rowIndex);
            if (row != null) {
                //第一列开始
                for (int columnIndex = 0; columnIndex < row.getLastCellNum(); columnIndex++) {
                    Cell cell = row.getCell(columnIndex);
                    if (cell != null) {
                        // 计算单元格内容的宽度
                        int cellWidth = cell.toString().length();

                        // 将宽度限制在最大宽度以内
                        int maxWidth = Math.min(cellWidth, maxColumnWidth);

                        // 获取当前列的宽度
                        int currentWidth = sheet.getColumnWidth(columnIndex);

                        // 计算自适应宽度
                        int newWidth = Math.max(currentWidth, (maxWidth + 1) * 256);

                        // 设置列的宽度
                        sheet.setColumnWidth(columnIndex, newWidth);


                        CellStyle oldStyle = cell.getCellStyle();//获取就style
                        CellStyle newstyle = xssfwb.createCellStyle();//创建新的style
                        newstyle.cloneStyleFrom(oldStyle);//克隆到新的style
                        //第一列左对齐且除了第一行
//                        if (columnIndex == 0 && rowIndex > 0) {
//                            newstyle.setAlignment(CellStyle.ALIGN_LEFT);//左对齐
//                        }else{
//                            newstyle.setAlignment(CellStyle.ALIGN_CENTER);//居中
//                        }
                        cell.setCellStyle(newstyle);
                    }
                }
            }
        }

    }
}
