package ext.exportBom;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * 资源文件
 * 
 * @author lxm
 * @date 2021-10-28
 */
@RBUUID( "ext.exportBom.HMRB_zh_CN" )
public class HMRB_zh_CN extends WTListResourceBundle
{
	@RBEntry("中文BOM导出")
	public static final String PRIVATE_CONSTANT_10 = "export.exportBOMWizardZh.description";

	@RBEntry("中文BOM导出")
	public static final String PRIVATE_CONSTANT_11 = "export.exportBOMWizardZh.title";

	@RBEntry("中文BOM导出")
	public static final String PRIVATE_CONSTANT_12 = "export.exportBOMWizardZh.tooltip";

	@RBEntry("StructureNode.gif")
	@RBPseudo(false)
	public static final String PRIVATE_CONSTANT_13 = "export.exportBOMWizardZh.icon";

	@RBEntry("height=650,width=750")
	@RBPseudo(false)
	public static final String PRIVATE_CONSTANT_14 = "export.exportBOMWizardZh.moreurlinfo";



	@RBEntry("英文BOM导出")
	public static final String PRIVATE_CONSTANT_15 = "export.exportBOMWizardEn.description";

	@RBEntry("英文BOM导出")
	public static final String PRIVATE_CONSTANT_16 = "export.exportBOMWizardEn.title";

	@RBEntry("英文BOM导出")
	public static final String PRIVATE_CONSTANT_17 = "export.exportBOMWizardEn.tooltip";

	@RBEntry("StructureNode.gif")
	@RBPseudo(false)
	public static final String PRIVATE_CONSTANT_18 = "export.exportBOMWizardEn.icon";

	@RBEntry("height=650,width=750")
	@RBPseudo(false)
	public static final String PRIVATE_CONSTANT_19 = "export.exportBOMWizardEn.moreurlinfo";




}