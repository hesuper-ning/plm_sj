package ext.exportBom;

import ext.exportBom.vo.ReplacePartsVO;

public class test {
    public static void main(String[] args) {
        ReplacePartsVO replaceParts = new ReplacePartsVO(1,null);

        System.out.println(replaceParts.getRowNum());

    }
}
