package ext.exportBom.vo;

import wt.part.WTPart;

public class ReplacePartsVO {
    private int rowNum;
    private WTPart wtPart;

    @Override
    public String toString() {
        return "ReplacePartsVO{" +
                "rowNum=" + rowNum +
                ", wtPart=" + wtPart +
                '}';
    }

    public ReplacePartsVO() {
    }

    public ReplacePartsVO(int rowNum, WTPart wtPart) {
        this.rowNum = rowNum;
        this.wtPart = wtPart;
    }

    public int getRowNum() {
        return rowNum;
    }

    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }

    public WTPart getWtPart() {
        return wtPart;
    }

    public void setWtPart(WTPart wtPart) {
        this.wtPart = wtPart;
    }
}
