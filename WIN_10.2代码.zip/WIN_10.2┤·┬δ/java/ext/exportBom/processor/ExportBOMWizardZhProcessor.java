package ext.exportBom.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.exportBom.util.CreateZhExcel;
import org.apache.poi.ss.usermodel.Workbook;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static ext.exportBom.util.PersistenceUtil.isCheckOut;

public class ExportBOMWizardZhProcessor extends DefaultObjectFormProcessor {


    private static String excelName;

    public static String PDF_TEMP = "";

    static {
        String wtHome = null;
        try {
            WTProperties props = WTProperties.getLocalProperties();
            wtHome = props.getProperty("wt.temp");
            System.out.println("wtHome:" + wtHome);
            PDF_TEMP = wtHome + File.separator + "excel";
            File pdfFolder = new File(PDF_TEMP);
            if (!pdfFolder.exists()) {
                pdfFolder.mkdir();
            }
            System.out.println("PDF Temp Folder: " + PDF_TEMP);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /*在下一步执行*/
    @SuppressWarnings("deprecation")
    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("start======");
        StringBuffer sb = new StringBuffer();
        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        HttpServletResponse response = nmCommandBean.getResponse();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");


        try {
            if (content instanceof WTPart) {
                WTPart wtPart = (WTPart) content;
                String number = wtPart.getNumber();//  编号
                String name = wtPart.getName();    //  名称
//                if (isCheckOut(wtPart)){//判断有没有检出
//                    throw new WTException("对象未检入，请检入再导出！！");
//                }
                String state = wtPart.getLifeCycleState().getDisplay();//状态显示值
                String version = wtPart.getVersionIdentifier().getValue() + "." + wtPart.getIterationIdentifier().getValue();  //版本前置.版本后置
                //料号_名称_状态_版本
                excelName = number + "_" + name + "_" + state + "_" + version + ".xlsx";
                System.out.println("创建的表名:"+excelName);

                // 创建excel表
                Workbook workbook = new CreateZhExcel().createExcel(wtPart);

                System.out.println("保存Excel文件到PDF_TEMP文件夹中");
                // 保存Excel文件到PDF_TEMP文件夹中
                saveExcelToTempFolder(workbook);

                response.reset();
                // 将Excel文件写入响应流
                response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//                response.setHeader("Content-Disposition", "attachment; filename=\"" + excelName + "\"");
                response.setHeader("Content-Disposition", "attachment; filename=\"" + URLEncoder.encode(excelName, "UTF-8") + "\"");

                response.setCharacterEncoding("UTF-8");
                writeExcelToResponse(response);

                workbook.close();
                response.flushBuffer();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        FeedbackMessage fm = new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null,
                new String[]{""});
        fm.addMessage("下载excel成功!!" + sb.toString());
        result.addFeedbackMessage(fm);
        return result;

    }


    private void saveExcelToTempFolder(Workbook workbook) throws IOException {
        File file = new File(PDF_TEMP + File.separator + excelName);
        try (OutputStream outputStream = new FileOutputStream(file)) {
            workbook.write(outputStream);
        }
    }

    private void writeExcelToResponse(HttpServletResponse response) throws IOException {
        File file = new File(PDF_TEMP + File.separator + excelName);
        FileInputStream fileInputStream = new FileInputStream(file);
        OutputStream outputStream = response.getOutputStream();
        try {
            byte[] buffer = new byte[4096];
            int bytesRead = -1;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } finally {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            // 删除临时文件
            file.delete();
        }
    }
}

