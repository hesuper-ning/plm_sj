package ext.exportBom.processor;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ext.sprocomm.bom.BOMHelper;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import wt.log4j.LogR;
import wt.part.WTPart;

import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.beans.NmHelperBean;
import com.ptc.netmarkets.util.beans.NmHelperBeanFactory;


/***
 * 非03导出整机BOM，03导出PCBA的BOM
 *
 * @author lxm @2020-10-28
 */
public class ExportBOM extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unused")
    private static final Logger log = LogR.getLogger(ExportBOM.class.getName());

    @RequestMapping(method = { RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD })
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        NmHelperBean helperBean = NmHelperBeanFactory.getInstance().getHelperBean(request, response);
        ServletOutputStream sout = response.getOutputStream();
        response.setHeader("Pragma", "No-cache");
        response.setHeader("Cache-Control", "no-cache");
        response.setCharacterEncoding("UTF-8");
        response.setDateHeader("Expires", 0);
        response.setContentType("application/octet-stream");
        try {

            NmCommandBean nmCommandBean = helperBean.getNmCommandBean();
            NmOid localNmOid = nmCommandBean.getActionOid();
            Object localObject = localNmOid.getRefObject();
            WTPart part = null;
            if(localObject instanceof WTPart){
                part = (WTPart) localObject;
            }else {
                NmOid elementOid = nmCommandBean.getElementOid();
                localObject = elementOid.getRef();
                if(localObject instanceof WTPart){
                    part = (WTPart) localObject;
                }
            }

            String userAgent = request.getHeader("user-agent");
            String dateFormat = new SimpleDateFormat("yyyyMMddHHmm").format(DateUtils.addHours(new Date(),8));
            String downloadFileName = part.getNumber()+"_BOM_"+dateFormat+".xls";
            if (StringUtils.contains(userAgent, "MSIE")) {
                downloadFileName = new String(downloadFileName.getBytes("GB2312"), "ISO8859-1");
            } else {
                downloadFileName = new String(downloadFileName.getBytes("UTF-8"), "ISO8859-1");
            }

            response.setHeader("Content-disposition", "attachment; filename=" + new String(downloadFileName));
            BOMHelper.exportBOMFromPart(part, sout);
            sout.flush();
        } catch (Exception e) {
            e.printStackTrace();
            response.reset();
            response.setContentType("text/html;charset=UTF-8"); // 这句太重要了
            response.getWriter().print(e.getMessage());
            response.flushBuffer();
        } finally {
            if (sout != null) {
                try {
                    sout.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    throw e;
                }
            }
        }
    }

    private static void writeToXlsx(XSSFSheet sheet, XSSFRow xlsrow, Object[] wd, XSSFCellStyle dataStyle) throws Exception {
        try {
            if(wd == null || wd.length == 0){
                return ;
            }
            int index = 0;
            for (Object object : wd) {
                if(object == null){
                    break;
                }
                writeToCell(sheet, dataStyle, xlsrow, index++, String.valueOf(object));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void writeToCell(XSSFSheet sheet, XSSFCellStyle dataStyle, XSSFRow xlsrow, int c_i, String v) {
        XSSFCell cell = xlsrow.createCell(c_i);
        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
        cell.setCellStyle(dataStyle);
        cell.setCellValue(v);
        if (v.getBytes().length > 10)
            sheet.setColumnWidth(c_i, v.getBytes().length * 256);
    }

    private static void writeHeader(XSSFSheet sheet, String[] headDesc, XSSFCellStyle headStyle) {
        XSSFRow headrow = sheet.createRow(0);
        headrow.setHeightInPoints((short) 20);
        for (int hd = 0; hd < headDesc.length; hd++) {
            XSSFCell cell = headrow.createCell(hd);
            // 设置格式
            cell.setCellType(XSSFCell.CELL_TYPE_STRING);
            cell.setCellStyle(headStyle);
            cell.setCellValue(headDesc[hd]);
        }
    }

    /**
     * 表头格式
     *
     * @param xssfwb
     * @return cellStyle
     */
    public static XSSFCellStyle getHeaderStyle(XSSFWorkbook xssfwb) {
        XSSFCellStyle cellStyle = xssfwb.createCellStyle();
        // 字体
        XSSFFont font = xssfwb.createFont();
        font.setBold(true);
        font.setColor(new XSSFColor(java.awt.Color.BLUE));
        font.setFontHeightInPoints((short) 9);
        font.setFontName("黑体");
        cellStyle.setFont(font);
        // 边框
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        // 对齐
        cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
        cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        // 自动换行
        cellStyle.setWrapText(true);
        cellStyle.setFillBackgroundColor(new XSSFColor(java.awt.Color.lightGray));
        return cellStyle;
    }

    /**
     * 内容格式
     *
     * @param xssfwb
     * @return cellStyle
     */
    public static XSSFCellStyle getDataStyle(XSSFWorkbook xssfwb) {
        XSSFCellStyle cellStyle = xssfwb.createCellStyle();
        // 字体
        XSSFFont font = xssfwb.createFont();
        font.setFontHeightInPoints((short) 9);
        font.setFontName("宋体");
        cellStyle.setFont(font);
        // 边框
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        // 对齐
        cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
        cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        // 自动换行
        cellStyle.setWrapText(true);
        return cellStyle;
    }

}

