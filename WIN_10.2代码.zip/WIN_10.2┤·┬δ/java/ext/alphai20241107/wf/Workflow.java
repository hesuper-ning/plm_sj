package ext.alphai.wf;


import com.ptc.windchill.enterprise.workflow.WfDataUtilitiesHelper;
import ext.alphai.wf.util.EPMUtils;
import ext.alphai.wf.util.IBAUtil;
import ext.alphai.wf.util.PropertiesUtil;
import ext.alphai.wf.util.VersionUtil;
import org.json.JSONArray;
import org.json.JSONObject;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.*;
import wt.maturity.PromotionNotice;
import wt.query.*;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.workflow.engine.ProcessData;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfVotingEventAudit;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

import static ext.alphai.wf.util.EPMUtils.*;
import static ext.alphai.wf.util.WorkflowUtil.getPromotionNotices;
import static ext.alphai.wf.util.WorkflowUtil.getTargerObjectByPromotionNotices;

public class Workflow {
    public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public static final String[] NO_UPDATE_PROTOTYPE_STATE={"PROTOTYPE","RELEASED","PROTOTYPERELEASED"};//不修改为原型状态
    public static final List<String> NO_UPDATE_PROTOTYPE_STATE_LIST=new ArrayList<>(Arrays.asList(NO_UPDATE_PROTOTYPE_STATE));
    public static final String SET_STATE_RELEASED = "RELEASED";   // 子项不为已发布就修改为



    /**
     * 设置升级请求对象，本身、子项、本身和子项的设计图纸的状态与升级的asm对象一致,
     * 不为 原型、原型已发布、已发布---原型     不为已发布----已发布
     * @param primaryBusinessObject
     * @param targetState
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void setPBOState(WTObject primaryBusinessObject,String targetState) throws WTException, WTPropertyVetoException {

        //修改状态情况
        /**
         * 1. L00 版本  升级对象 会自动修订为00版本已发布   若asm与他的子项都是升级对象  ，那么子项在修改状态前  修订为00版本已发布     ------>  升级为原型已发布会自动 修订为已发布00版本
         * ----->  这个时候子项的状态不能根据父项来修改(可能父为原型已发布)  会将子项00版本的修改为原型已发布    ----->  解决：  !已发布   修改状态为与父类一样
         *
         * 2.  1.产生一个bug   00已发布版本的处理 子项为已发布就不根据父类指定了  asm走流程不修改状态  仍然是已发布------子项全走流程
         *
         *
         */


        //获取升级请求
        PromotionNotice pn = getPromotionNotices(primaryBusinessObject);

        //获取流程中的cad，以及2d图纸、子项、子项2d图纸
        List<EPMDocument> allEPM = getAllEPM(primaryBusinessObject);//这时候获取的是流程对象L00版本的，但是他的子项确实最新版本的
        //不为空设置状态
        System.out.println("升级对象结构树长度"+allEPM.size());
        if (!allEPM.isEmpty()) {
            batchSetStateByTargetState(allEPM,targetState);
        }
    }

    /**
     * 修订为00版本
     * @param primaryBusinessObject
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void reviseEPM(WTObject primaryBusinessObject) throws WTException, WTPropertyVetoException {
        //获取升级请求
        PromotionNotice pn = getPromotionNotices(primaryBusinessObject);//获取的是流程对象当时的版本
        String targetStateDisplay = pn.getMaturityState().getDisplay();//升级请求状态，中文
        String targetState = pn.getMaturityState().toString();//升级请求状态，

        System.out.println("升级请求状态：" + targetStateDisplay);
        System.out.println("升级请求显示状态状态：" + targetState);

        //获取流程中的cad，以及2d图纸、子项、子项2d图纸
        if (PropertiesUtil.getValueByKey("ext.alphai.target_state").equals(targetState)) {//为原型已发布
            List<EPMDocument> allEPM = getAllEPM(primaryBusinessObject);
            if (!allEPM.isEmpty()) {
                //修订为00版本  流程中修订版本状态会自动更改为指定的
                List<EPMDocument> epmDocuments = batchReviseEPMVersion(allEPM,"00");
            }
        }

        //升级目标状态未已发布
        if (SET_STATE_RELEASED.equals(targetState)) {//为已发布
            //获取全部的部件  ，将含有L00版本的  状态修改为原型已发布，再去修订为00版本
            List<EPMDocument> allEPM = getAllEPM(primaryBusinessObject);
            if (!allEPM.isEmpty()) {
                for (EPMDocument epm : allEPM) {
                    //获取最新大版本
                    RevisionControlled latestObjectByMaster = VersionUtil.getLatestObjectByMaster(epm.getMaster());
                    String version = latestObjectByMaster.getVersionIdentifier().getValue();

                    System.out.println("reviseEPM方法打印目标状态为已发布时，部件状态："+version);


                    //版本为L
                    if (version.contains("L")){
                       //修改状态为原型已发布
                        changEPMState(epm, PropertiesUtil.getValueByKey("ext.alphai.target_state"));
                        System.out.println("目标状态为已发布，修改完L版本的状态，等待修订版本");

                        //修订版本
                        reviseEPMDocumentByEPM(epm,"00");

                    }
                }
            }
        }
    }

    /***
     * 流程反签，流程审批人、审批时间、备注等信息写到流程变量中
     *
     * @description @param ObjectReference @param primaryBusinessObject @param
     * 当前角色名称 @return @throws
     */
    public static String saveReviewToVar(ObjectReference self, WTObject pbo, String roleName) {
        try {
            System.out.println("Save reviewer for role :" + roleName);
            String values[] = getWorkFlowInfo(self);
            // 当前审核人员
            Persistable object = self.getObject();
            if (object instanceof WfProcess) {
                WfProcess wfprocess = (WfProcess) object;
                ProcessData context = wfprocess.getContext();
                Object value = context.getValue("reviewer");
                if (value != null && value instanceof String && !"".equalsIgnoreCase((String) (value))) {
                    String oldValue = (String) value;
                    JSONObject jsonObject = new JSONObject(oldValue);
                    jsonObject.put(roleName, values);
                    context.setValue("reviewer", jsonObject.toJSONString());
                    return jsonObject.toJSONString();
                } else {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(roleName, values);
                    context.setValue("reviewer", jsonObject.toJSONString());
                    return jsonObject.toJSONString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "{}";
    }

    public static String decidePNStateRoute(WTObject primaryBusinessObject) throws WTException {
        PromotionNotice pn =  null;
        if(primaryBusinessObject instanceof PromotionNotice){
            pn = (PromotionNotice) primaryBusinessObject;
        }

        String displayState = pn.getMaturityState().getDisplay(Locale.CHINESE);
        if ("原型".equals(displayState)){
            return "原型";
        }else{
            return "已发布";
        }

    }

    public static String decidePNStateValue(WTObject primaryBusinessObject) throws WTException {
        PromotionNotice pn =  null;
        if(primaryBusinessObject instanceof PromotionNotice){
            pn = (PromotionNotice) primaryBusinessObject;
        }
        return pn.getMaturityState().getDisplay(Locale.CHINESE);
    }


    /**
     * 设置全部的epm的审阅、批准、设计 人和时间
     *
     * @param primaryBusinessObject 接收了，设置状态的CAD部件、CAD部件子项，以及CAD部件和子项部件的图纸返回的全部集合
     * @param var0
     */
    public static void setEPMAttribute(WTObject primaryBusinessObject, ObjectReference var0) throws WTException, WTPropertyVetoException {

        HashMap var2 = getSignInfo(var0);
        //{"审阅":[["will","2024.07.29","will"," "]],"批准":[["will","2024.07.29","will"," "]]}
        Vector<String[]> check = (Vector) var2.get("审阅");// 下标1为人  2为时间
        Vector<String[]> approved = (Vector) var2.get("批准");

        //获取升级请求
        PromotionNotice pn = getPromotionNotices(primaryBusinessObject);
        String targetStateDisplay = pn.getMaturityState().getDisplay();//升级请求状态，中文
        String targetState = pn.getMaturityState().toString();//升级请求状态，

        System.out.println("升级请求状态：" + targetStateDisplay);
        System.out.println("升级请求显示状态状态：" + targetState);

        //获取流程中的cad，以及2d图纸、子项、子项2d图纸
        List<EPMDocument> allEPM = getAllEPM(primaryBusinessObject);
        System.out.println("打印全部结构树");

        for (EPMDocument epmDocument : allEPM) {
            System.out.println(epmDocument.getCADName()+"版本为："+epmDocument.getVersionIdentifier().getValue());
        }
        if (!allEPM.isEmpty()) {

            //L版本原型已发布 同步修改L00版本
            if (PropertiesUtil.getValueByKey("ext.alphai.target_state").equals(targetState)) {
                //获取L版本
                List<EPMDocument> epmDocuments = batchGetLastEPMByVersion(allEPM, "L00");
                //修改L00版本IBA
                updateEPMIBA(epmDocuments,check,approved);

            }

            //此时传来的不一定是最新版本，需要修改最新版本 获取的父项不是，需要修改
            LinkedHashSet<EPMDocument> latestEPMtList = getLatestEPMtList(allEPM);
            ArrayList<EPMDocument> newAllEPM = new ArrayList<>();
            newAllEPM.addAll(latestEPMtList);
            updateEPMIBA(newAllEPM,check,approved);
        }
    }


    //获取CAD部件
    public static List<EPMDocument> getEPMDocumentByPBO(WTObject primaryBusinessObject) throws WTException {
        List<EPMDocument> epmDocuments = new ArrayList<>();


        //获取升级请求
        PromotionNotice pn = getPromotionNotices(primaryBusinessObject);

        //获取升级请求中被升级的对象
        List<WTObject> targerObjectByPromotionNotices = getTargerObjectByPromotionNotices(pn);


        if (targerObjectByPromotionNotices.size() > 0) {
            //获取集合中后缀为ASM的CAD部件
            for (WTObject targerObjectByPromotionNotice : targerObjectByPromotionNotices) {
                System.out.println("被升级的class是什么：" + targerObjectByPromotionNotice.toString());
                if (targerObjectByPromotionNotice instanceof EPMDocument) {
                    System.out.println("被升级的EPM部件编号：" + ((EPMDocument) targerObjectByPromotionNotice).getNumber());
                    EPMDocument epm = (EPMDocument) targerObjectByPromotionNotice;
                    //获取当前大版本
                    String value = epm.getVersionIdentifier().getValue();
                    System.out.println("版本信息" + value);

                    epmDocuments.add(epm);

                }
            }

        } else {
            System.out.println("未找到被升级对象");
        }
        System.out.println("通过pbo获取升级请求cad对象end");
        return epmDocuments;

    }

    public static String[] getWorkFlowInfo(ObjectReference var0) {
        String[] var1 = new String[4];

        try {
            ReferenceFactory var2 = new ReferenceFactory();
            WTReference var3 = var2.getReference(var0.getObjectId().toString());
            if (var3.getObject() != null) {
                String var7;
                if (var3.getObject() instanceof WfProcess) {
                    WfProcess var4 = (WfProcess) var3.getObject();
                    WorkItem var5 = getWorkItem(var4);
                    WfVotingEventAudit var6 = WfDataUtilitiesHelper.getMatchingEventAudit(var5);
                    if (var6 != null) {
                        var1[0] = var6.getUserRef() != null ? var6.getUserRef().getFullName() : "";
                        var7 = simpleDateFormat.format(var6.getTimestamp());
                        var1[1] = var7;
                        var1[2] = var6.getUserRef().getFullName();
                        var1[3] = var6.getUserComment();
                    }
                } else if (var3.getObject() instanceof WfAssignedActivity) {
                    WfAssignedActivity var15 = (WfAssignedActivity) var3.getObject();
                    QuerySpec var16 = new QuerySpec(WorkItem.class);
                    WTReference var17 = var2.getReference(var15);
                    var7 = var2.getReferenceString(var17);
                    System.out.println("oid----" + var7);
                    SearchCondition var8 = new SearchCondition(WorkItem.class, "source.key", "=", new ObjectIdentifier(var7));
                    var16.appendWhere(var8);
                    QueryResult var9 = PersistenceServerHelper.manager.query(var16);

                    while (var9.hasMoreElements()) {
                        Object var10 = var9.nextElement();
                        WorkItem var11 = (WorkItem) var10;
                        WfVotingEventAudit var12 = WfDataUtilitiesHelper.getMatchingEventAudit(var11);
                        if (var12 != null) {
                            var1[0] = var12.getUserRef() != null ? var12.getUserRef().getFullName() : "";
                            String var13 = simpleDateFormat.format(var12.getTimestamp());
                            var1[1] = var13;
                            var1[2] = var12.getUserRef().getFullName();
                            var1[3] = var12.getUserComment();
                        }
                    }
                }
            }
        } catch (Exception var14) {
            var14.printStackTrace();
        }

        return var1;
    }

    public static WorkItem getWorkItem(WfProcess var0) {
        WorkItem var1 = null;

        try {
            QuerySpec var2 = new QuerySpec();
            int var3 = var2.appendClassList(WfAssignedActivity.class, false);
            int var4 = var2.appendClassList(WorkItem.class, true);
            var2.setAdvancedQueryEnabled(true);
            String[] var5 = new String[]{var2.getFromClause().getAliasAt(var3), var2.getFromClause().getAliasAt(var4)};
            TableColumn var6 = new TableColumn(var5[0], "IDA2A2");
            TableColumn var7 = new TableColumn(var5[1], "IDA3A4");
            CompositeWhereExpression var8 = new CompositeWhereExpression(LogicalOperator.AND);
            var8.append(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key", "=", getOid(var0)));
            var8.append(new SearchCondition(var6, "=", var7));
            var2.appendWhere(var8, (int[]) null);
            var2.appendOrderBy(WorkItem.class, "thePersistInfo.updateStamp", true);
            QueryResult var9 = PersistenceHelper.manager.find(var2);

            while (var9.hasMoreElements()) {
                Object[] var10 = (Object[]) ((Object[]) var9.nextElement());
                if (var10[0] instanceof WorkItem) {
                    var1 = (WorkItem) var10[0];
                    return var1;
                }
            }
        } catch (Exception var11) {
            var11.printStackTrace();
        }

        return var1;
    }

    private static ObjectIdentifier getOid(Object var0) {
        if (var0 == null) {
            return null;
        } else {
            return var0 instanceof ObjectReference ? (ObjectIdentifier) ((ObjectReference) var0).getKey() : PersistenceHelper.getObjectIdentifier((Persistable) var0);
        }
    }

    public static String getReview(WfProcess var0) {
        try {
            Object var1 = var0.getContext().getValue("reviewer");
            return var1 != null ? var1.toString() : "{}";
        } catch (Exception var2) {
            var2.printStackTrace();
            return "";
        }
    }

    public static HashMap<String, Vector<String[]>> getSignInfo(Object var0) {
        HashMap var1 = new HashMap();

        try {
            String var2 = "{}";
            if (var0 instanceof ObjectReference) {
                var2 = getReview((WfProcess) ((ObjectReference) var0).getObject());
            } else if (var0 instanceof WfProcess) {
                var2 = getReview((WfProcess) var0);
            }

            JSONObject var3 = new JSONObject(var2);

            String var6;
            Vector var8;
            for (Iterator var4 = var3.keys(); var4.hasNext(); var1.put(var6, var8)) {
                Object var5 = var4.next();
                var6 = String.valueOf(var5);
                Object var7 = var3.get(var6);
                var8 = new Vector();
                if (var7 instanceof JSONArray) {
                    JSONArray var9 = (JSONArray) var7;
                    int var10 = var9.length();
                    String[] var11 = new String[var10];

                    for (int var12 = 0; var12 < var9.length(); ++var12) {
                        var11[var12] = var9.getString(var12);
                    }

                    var8.add(var11);
                }
            }
        } catch (Exception var13) {
            var13.printStackTrace();
        }

        return var1;
    }


    /**
     * 通过升级请求获取获取全部的EPM，包含本身，子项以及2d图纸
     *
     * @param primaryBusinessObject
     */
    public static List<EPMDocument> getAllEPM(WTObject primaryBusinessObject) throws WTException {

        //去除重复对象
        LinkedHashSet<EPMDocument> epmDocuments = new LinkedHashSet<>();

        //获取升级对象的中的epm
        List<EPMDocument> epmDocument = getEPMDocumentByPBO(primaryBusinessObject);

        List<EPMDocument> allEPM = new ArrayList<>();

        for (EPMDocument epm : epmDocument) {
            //将这个asm结尾的epm插入集合
            epmDocuments.add(epm);
            //插入asm结尾的2d图纸
            if (!EPMUtils.get2DBy3D(epm).isEmpty()) {
                epmDocuments.addAll(EPMUtils.get2DBy3D(epm));
            }

            //获取asm结尾的子项
            for (EPMDocument childEPM : getAllChildByEpm(epm)) {
                epmDocuments.add(childEPM);
                //插入子项的2d图纸
                if (!EPMUtils.get2DBy3D(childEPM).isEmpty()) {
                    epmDocuments.addAll(EPMUtils.get2DBy3D(childEPM));
                }

            }
        }

        allEPM.addAll(epmDocuments);

        return allEPM;
    }

    /**
     * 批量设置状态，状态与下标0一致（2d图，子项，子项2d图与cad部件一致）   不为原型、原型已发布、已发布才修改状态
     * @param epm
     */
    public static void  batchSetStateByTargetState(List<EPMDocument> epm,String targetState) throws WTException, WTPropertyVetoException {

        //除去父
        System.out.println("开始打印待修改状态的CAD部件");
        //获取父类状态
        String fatherState = epm.get(0).getLifeCycleState().toString();
        for (int i = 1; i < epm.size(); i++) {
            String epmState = epm.get(i).getLifeCycleState().toString();//英文
            String version = epm.get(i).getVersionIdentifier().getValue();
            System.out.println(epm.get(i).getCADName()+"的版本为"+version);
            
            if ("PROTOTYPE".equals(targetState)){
                //不为原型、原型已发布、已发布才修改状态
                if (!NO_UPDATE_PROTOTYPE_STATE_LIST.contains(epmState)){
                    changEPMState(epm.get(i), targetState);
                }
                continue;
            }

            //问题   已发布的 L00怎么办
            if ("RELEASED".equals(targetState)){
//                //子项 为已发布才   说明修订了  就是00版本了
//                if (!SET_STATE.equals(epmState) && "00".equals(version)){
//                    changEPMState(epm.get(i), targetState);
//                    continue;
//                }
                //子项不为已发布才修改为与父类一致状态  没有修订  版本不为00
//                if (!SET_STATE.equals(epmState) && !"00".equals(version)){
//                    changEPMState(epm.get(i), fatherState);
//                    continue;
//                }else{
//                    changEPMState(epm.get(i), fatherState);
//                }

                // prt  包含drw    prt修订为 00已发布  ---但是这个时候获取的父类状态为升级的状态   drw为设计
                if (!SET_STATE_RELEASED.equals(epmState) ){
                    changEPMState(epm.get(i), fatherState);
                    continue;
                }





            }


        }
    }


    /**
     * 修订epm为00版本 2d图纸、子项、子项2d图纸 并且返回修订的版本集合
     * 存在情况  已被修订为00
     * @param epm
     * @return
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static List<EPMDocument>  batchReviseEPMVersion(List<EPMDocument> epm ,String version) throws WTException, WTPropertyVetoException {
        List<EPMDocument> reviseEPMList = new ArrayList<>();

        reviseEPMList.add(epm.get(0));

        //除去父项从1开始
        for (int i = 1; i < epm.size(); i++) {
            //获取当前最新版本  若为00版  就不修订
            RevisionControlled latestObjectByMaster = VersionUtil.getLatestObjectByMaster(epm.get(i).getMaster());
            String bigVersion = latestObjectByMaster.getVersionIdentifier().getValue();

            String epmState = epm.get(i).getLifeCycleState().toString();//英文
            String version1 = epm.get(i).getVersionIdentifier().getValue();
            System.out.println(epm.get(i).getCADName()+"的版本为"+version1);

            //版本不为L就不修订 跳过
            if (!bigVersion.contains("L")){
                continue;
            }

            EPMDocument epmDocument = reviseEPMDocumentByEPM(epm.get(i),version);
            reviseEPMList.add(epmDocument);
        }
        return reviseEPMList;
    }

    /**
     * 修改cad部件，2d图纸，以及子项和子项的2d图纸IBA属性 审批人 审批时间 批准人 批准时间 设计人 设计时间 英文生命周期
     * @param allEPM
     * @param check
     * @param approved
     */
    public static void  updateEPMIBA(List<EPMDocument> allEPM , Vector<String[]> check ,  Vector<String[]> approved){

        System.out.println("修改最新版本的修改信息");
        for (EPMDocument epmDocument : allEPM) {
            try {
                IBAUtil ibaUtil = new IBAUtil(epmDocument);
                Timestamp modifyTimestamp = epmDocument.getModifyTimestamp();

                String timeStamp = simpleDateFormat.format(modifyTimestamp);//修改时间
                String modifyFullName = epmDocument.getModifierFullName();//修改人

                ibaUtil.setIBAAttribute4AllType(epmDocument, PropertiesUtil.getValueByKey("ext.alphai.check_by"), check.get(0)[0]); // 审批人
                ibaUtil.setIBAAttribute4AllType(epmDocument, PropertiesUtil.getValueByKey("ext.alphai.check_date"), check.get(0)[1].replace(".", "-")); // 审批时间
                ibaUtil.setIBAAttribute4AllType(epmDocument, PropertiesUtil.getValueByKey("ext.alphai.approved_by"), approved.get(0)[0]); // 批准人
                ibaUtil.setIBAAttribute4AllType(epmDocument, PropertiesUtil.getValueByKey("ext.alphai.approved_date"), approved.get(0)[1].replace(".", "-"));//批准时间
                ibaUtil.setIBAAttribute4AllType(epmDocument, PropertiesUtil.getValueByKey("ext.alphai.cdrawn_by"), modifyFullName); // 设计人
                ibaUtil.setIBAAttribute4AllType(epmDocument, PropertiesUtil.getValueByKey("ext.alphai.cdrawn_date"), timeStamp); // 设计时间

                //将生命周期的英文名写入IBA属性中  ----这个IBA删掉了
                //1.获取生命周期
//                String englishState = epmDocument.getLifeCycleState().getDisplay(Locale.ENGLISH);
//                ibaUtil.setIBAAttribute4AllType(epmDocument, PropertiesUtil.getValueByKey("ext.alphai.state_english"), englishState); // 将生命周期英文写入IBA中


            } catch (WTException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 批量获取指定版本的最新小版本
     * @param allEPM
     * @param version
     * @return
     * @throws WTException
     */
    public static List<EPMDocument> batchGetLastEPMByVersion(List<EPMDocument> allEPM , String version) throws WTException {
        List<EPMDocument> lastEpmList = new ArrayList<>();

        System.out.println("开始打印修改属性信息");
        for (EPMDocument epmDocument : allEPM) {
            EPMDocument lastEPMByVersion = getLastEPMByVersion(epmDocument, version);
            lastEpmList.add(lastEPMByVersion);
        }
        return lastEpmList;
    }


    /**
     * 批量转为最新版本
     * @param allEPM
     * @return
     * @throws WTException
     *
     */
    public static LinkedHashSet<EPMDocument> getLatestEPMtList(List<EPMDocument> allEPM) throws WTException {
        LinkedHashSet<EPMDocument> latestEPMList = new LinkedHashSet<>();


        for (EPMDocument epmDocument : allEPM) {
            EPMDocument latestEPM =(EPMDocument) VersionUtil.getLatestObjectByMaster(epmDocument.getMaster());
            latestEPMList.add(latestEPM);
        }

        return latestEPMList;

    }





}


