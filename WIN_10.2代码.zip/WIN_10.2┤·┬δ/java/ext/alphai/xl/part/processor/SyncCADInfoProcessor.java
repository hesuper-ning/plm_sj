package ext.alphai.xl.part.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.xl.part.util.EPMUtils;
import ext.alphai.xl.part.util.IBAUtil;
import ext.alphai.xl.part.util.PartUtil;
import ext.alphai.xl.part.util.PropertiesUtil;
import wt.epm.EPMDocument;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;

public class SyncCADInfoProcessor extends DefaultObjectFormProcessor {

    protected static final String isUpdateFileName = PropertiesUtil.getValueByKey("ext.alphai.isUpdateFileName");

    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("开始同步CAD部件信息");

        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
            try {
                if (content instanceof WTPart) {
                    WTPart part = (WTPart) content;
                    String partNumber = part.getNumber();//编号
                    String partName = part.getName();//中文名
                    IBAUtil ibaUtilPart = new IBAUtil(part);
                    String partNameEN = ibaUtilPart.getIBAValue(PropertiesUtil.getValueByKey("ext.alphai.partNameEN"));
                    List<EPMDocument> allCADByPart = PartUtil.getAllCADByPart(part);


                    System.out.println("打印英文名"+partNameEN);


                    int count=0;
                    for (EPMDocument epm : allCADByPart) {
                        System.out.println("打印cad部件名称"+epm.getName());
                        //修改编号, 2d+_D
                        if ("CADDRAWING".equals(epm.getDocType().toString())) {//判断是否为2d部件
                            count++;
                            EPMUtils.updateEPMNumber(epm,partNumber+"_D"+count);
                        }else{
                            EPMUtils.updateEPMNumber(epm,partNumber);
                        }

                        //修改名称
                        EPMUtils.updateEPMName(epm,partName);

                        //修改英文名称
                        IBAUtil ibaUtilEPM = new IBAUtil(epm);
                        ibaUtilEPM.setIBAAttribute4AllType(epm,PropertiesUtil.getValueByKey("ext.alphai.partNameEN"),partNameEN);

                        //修改文件名
                        if (isUpdateFileName.equals("true")) {
                            String oldFileName = epm.getCADName();// 文件名
                            String newFile = EPMUtils.getNewSuffixFileName(partNumber, oldFileName);//新文件名 = 部件编号+旧文件后缀
                            EPMUtils.updateEPMFileName(epm,newFile);

                        }

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                FormResult result = new FormResult(FormProcessingStatus.FAILURE);
                result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), (String)null, (ArrayList)null, new String[]{"同步CAD信息失败：" + e.getMessage()}));
                return result;
            }
        System.out.println("同步cad信息结束，返回显示信息！");
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null, new String[] { "同步CAD信息成功!" }));
        return result;

    }
}
