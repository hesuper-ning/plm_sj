package ext.alphai.xl.part.util;

import wt.epm.EPMDocument;
import wt.epm.EPMDocumentHelper;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentMasterIdentity;
import wt.fc.Identified;
import wt.fc.IdentityHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.config.LatestConfigSpec;


public class EPMUtils {

    /**
     * 更改CAD部件编号
     *
     * @param epm
     * @param newNumber
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPMNumber(EPMDocument epm, String newNumber) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified) epm.getMaster();
        EPMDocumentMasterIdentity iden = (EPMDocumentMasterIdentity) icp.getIdentificationObject();
        iden.setNumber(newNumber);
        IdentityHelper.service.changeIdentity(icp, iden);
        PersistenceHelper.manager.refresh(epm);
    }

    /**
     * 修改EPM名称
     *
     * @param epm
     * @param newName
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPMName(EPMDocument epm, String newName) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified) epm.getMaster();
        EPMDocumentMasterIdentity iden = (EPMDocumentMasterIdentity) icp.getIdentificationObject();
        iden.setName(newName);
        IdentityHelper.service.changeIdentity(icp, iden);
        PersistenceHelper.manager.refresh(epm);
    }


    /**
     * 更改CAD部件文件名,注意cadName必须含有后缀asm,或者prt
     *
     * @param epm
     * @param newCADName
     * @throws WTException
     */
    public static void updateEPMFileName(EPMDocument epm, String newCADName) throws WTException {
        EPMDocumentMaster epmdocumentmaster = (EPMDocumentMaster) epm.getMaster();
        WTKeyedMap map = new WTKeyedHashMap(1);
        map.put(epmdocumentmaster, newCADName);
        EPMDocumentHelper.service.changeCADName(map);
    }

    /**
     * 修改cad部件的编号,名称,文件名
     *
     * @param epm
     * @param newNumber
     * @param newName
     * @param newCADName
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPM(EPMDocument epm, String newNumber, String newName, String newCADName) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified) epm.getMaster();
        EPMDocumentMasterIdentity iden = (EPMDocumentMasterIdentity) icp.getIdentificationObject();
        //设置编号
        iden.setNumber(newNumber);
        //设置名称
        iden.setName(newName);
        IdentityHelper.service.changeIdentity(icp, iden);
        PersistenceHelper.manager.refresh(epm);

        //修改CADName 文件名
        EPMDocumentMaster epmdocumentmaster = (EPMDocumentMaster) epm.getMaster();
        WTKeyedMap map = new WTKeyedHashMap(1);
        map.put(epmdocumentmaster, newCADName);
        //修改文件名
        EPMDocumentHelper.service.changeCADName(map);
    }


    /**
     * 根据编号获取对象
     *
     * @param number
     * @param queryClass
     * @return Object
     */
    @SuppressWarnings("deprecation")
    public static Object getObjByNumber(String number, Class queryClass) {
        try {
            if (number.isEmpty()) {
                return null;
            }
            QuerySpec qs = new QuerySpec(queryClass);
            qs.appendWhere(new SearchCondition(queryClass, "master>number", SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                return qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }




    //获取.前的数据
    public static String removeExtension(String fileName) {
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1) {
            return fileName; // 如果没有找到点号，直接返回原始文件名
        } else {
            return fileName.substring(0, lastDotIndex); // 截取点号之前的部分
        }
    }

    // 方法：获取文件后缀名
    public static String getFileExtension(String fileName) {
        if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
            return fileName.substring(fileName.lastIndexOf(".") + 1);
        } else {
            return "";
        }
    }

    /**
     *
     * @param number 新的文件名编号
     * @param suffix 旧文件名后缀
     * @return
     */
    public static String getNewSuffixFileName(String number , String suffix){
        return removeExtension(number) + "."  + getFileExtension(suffix);
    }

}
