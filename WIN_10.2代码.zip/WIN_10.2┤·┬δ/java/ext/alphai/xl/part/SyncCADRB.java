package ext.alphai.xl.part;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;


@RBUUID("ext.alphai.xl.part.SyncCADRB")
public class SyncCADRB extends WTListResourceBundle {

    @RBEntry("同步CAD信息")
    public static final String PRIVATE_CONSTANT_10 = "SyncCAD.updateCADInfo.description";
    @RBEntry("同步CAD信息")
    public static final String PRIVATE_CONSTANT_11 = "SyncCAD.updateCADInfo.tooltip";
    @RBEntry("edit_properties.gif")
    public static final String PRIVATE_CONSTANT_12 = "SyncCAD.updateCADInfo.icon";

}
