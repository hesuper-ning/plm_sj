package ext.alphai.xl.disposalOldProducts;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;


@RBUUID("ext.alphai.xl.disposalOldProducts.DisposalOldProductsRB")
public class DisposalOldProductsRB extends WTListResourceBundle {


    @RBEntry("旧品处置方案")
    public static final String CHANGE_CONTENT = "旧品处置方案";


    @RBEntry("旧品处置方案")
    public static final String PRIVATE_CONSTANT_1 = "DisposalOldProducts.disposalOldProducts.description";
    @RBEntry("旧品处置方案")
    public static final String PRIVATE_CONSTANT_2 = "DisposalOldProducts.disposalOldProducts.tooltip";

    @RBEntry("新增旧品处置方案")
    public static final String PRIVATE_CONSTANT_3 = "DisposalOldProducts.addItem.description";
    @RBEntry("新增旧品处置方案")
    public static final String PRIVATE_CONSTANT_4 = "DisposalOldProducts.addItem.tooltip";
    @RBEntry("add16x16.gif")
    public static final String PRIVATE_CONSTANT_5 = "DisposalOldProducts.addItem.icon";

    @RBEntry("修改子项")
    public static final String PRIVATE_CONSTANT_10 = "DisposalOldProducts.updateItem.description";
    @RBEntry("修改子项")
    public static final String PRIVATE_CONSTANT_11 = "DisposalOldProducts.updateItem.tooltip";
    @RBEntry("edit_properties.gif")
    public static final String PRIVATE_CONSTANT_12 = "DisposalOldProducts.updateItem.icon";

    @RBEntry("删除子项")
    public static final String PRIVATE_CONSTANT_7 = "DisposalOldProducts.deleteItem.description";
    @RBEntry("删除子项")
    public static final String PRIVATE_CONSTANT_8 = "DisposalOldProducts.deleteItem.tooltip";
    @RBEntry("delete.gif")
    public static final String PRIVATE_CONSTANT_9 = "DisposalOldProducts.deleteItem.icon";
}
