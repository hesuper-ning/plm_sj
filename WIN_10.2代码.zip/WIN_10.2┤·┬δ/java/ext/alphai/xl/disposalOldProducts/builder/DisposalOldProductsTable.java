package ext.alphai.xl.disposalOldProducts.builder;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.xl.disposalOldProducts.DisposalOldProducts;
import ext.alphai.xl.disposalOldProducts.DisposalOldProductsRB;
import ext.alphai.xl.disposalOldProducts.service.DisposalOldProductService;
import ext.alphai.xl.disposalOldProducts.utils.PersistenceUtil;
import wt.change2.WTChangeRequest2;
import wt.util.WTException;


@ComponentBuilder("ext.alphai.xl.disposalOldProducts.builder.DisposalOldProductsTable")
public class DisposalOldProductsTable extends AbstractComponentBuilder {
    private ClientMessageSource msgSource;


    @Override
    public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig config = factory.newTableConfig();


        config.setType(DisposalOldProducts.class.getName());
        config.setLabel(DisposalOldProductsRB.CHANGE_CONTENT);//table标题
        config.setSelectable(true);
        config.setShowCount(true);
        config.setShowCustomViewLink(true);

        //设置上面按钮model
        config.setActionModel("disposalOldProducts");


        //报表最前面圆圈
        ColumnConfig oidColumn = factory.newColumnConfig("oid", true);
        config.addComponent(oidColumn);
        oidColumn.setHidden(true);
        oidColumn.setSortable(true);

        //报表每列第二列name
        ColumnConfig partName = factory.newColumnConfig("partNumber", "零部件名称", true);
        partName.setDataUtilityId("disposalOldProducts_Utility");
        config.addComponent(partName);

        //报表每列第三列name
        ColumnConfig partNumber = factory.newColumnConfig("partName", "零部件编号", true);
        partNumber.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(partNumber);


        //报表每列第三列name
        ColumnConfig partOldVersion = factory.newColumnConfig("partOldVersion", "旧版", true);
        partOldVersion.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(partOldVersion);


        ColumnConfig customerArtifact = factory.newColumnConfig("CustomerArtifact", "顾客成品", true);
        customerArtifact.setDataUtilityId("disposalOldProducts_Utility");
        config.addComponent(customerArtifact);

        //报表每列第三列name
        ColumnConfig xlArtifact = factory.newColumnConfig("XLArtifact", "西菱成品", true);
        xlArtifact.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(xlArtifact);


        ColumnConfig inMaking = factory.newColumnConfig("InMaking", "在制品", true);
        inMaking.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(inMaking);

        ColumnConfig inOrdering = factory.newColumnConfig("InOrdering", "在订品", true);
        inOrdering.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(inOrdering);

        ColumnConfig frock = factory.newColumnConfig("Frock", "工装", true);
        frock.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(frock);

        ColumnConfig mold = factory.newColumnConfig("Mold", "模具", true);
        mold.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(mold);

        ColumnConfig cuttingTool = factory.newColumnConfig("CuttingTool", "刀具", true);
        cuttingTool.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(cuttingTool);

        ColumnConfig fixtures = factory.newColumnConfig("Fixtures", "检具", true);
        fixtures.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(fixtures);

        ColumnConfig inTheLibrary = factory.newColumnConfig("InTheLibrary", "在库存", true);
        inTheLibrary.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(inTheLibrary);

        ColumnConfig inOrder = factory.newColumnConfig("InOrder", "在订", true);
        inOrder.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(inOrder);

        ColumnConfig wip = factory.newColumnConfig("Wip", "WIP", true);
        wip.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(wip);

        ColumnConfig otherNotes = factory.newColumnConfig("OtherNotes", "其他项说明", true);
        otherNotes.setDataUtilityId("disposalOldProducts_Utility");
        //对应数据库的列名称
        config.addComponent(otherNotes);


        return config;
    }


    //table数据
    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        JcaComponentParams jca_params = (JcaComponentParams) componentParams;
        NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
        NmOid primaryOid2 = cb.getPrimaryOid();
        WTChangeRequest2 change = null;
        if (primaryOid2 == null)
            return null;
        Object content = primaryOid2.getRef();
        if (content instanceof WTChangeRequest2) {
            change = (WTChangeRequest2) content;
        }
        String changeOID = PersistenceUtil.object2Oid(change);
        return DisposalOldProductService.getDisposalOldProductChangeOid(changeOID);
    }


    private void initTableColumns(ComponentConfigFactory factory, TableConfig config) {


    }
}
