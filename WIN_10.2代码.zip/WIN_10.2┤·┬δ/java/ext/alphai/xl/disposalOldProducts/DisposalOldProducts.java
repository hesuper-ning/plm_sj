package ext.alphai.xl.disposalOldProducts;

import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;
import wt.content.ContentHolder;
import wt.fc.WTObject;
import wt.util.WTException;
/**
 * 部件使用关系变更项建模
 * WTChangeORDER2OR 变更请求OID
 * PartName 部件名称
 * PartNumber 编号
 * PartOldVersion 部件旧版本
 * CustomerArtifact 顾客成品
 * XLArtifact   西菱成品
 * InMaking   在制品
 * InOrdering 在订品
 * Frock    工装
 * Mold     模具
 * CuttingTool  刀具
 * Fixtures 检具
 * InTheLibrary 在库存
 * InOrder 在订
 * Wip   WIP
 * otherNotes   otherNotes
 */

@GenAsPersistable(superClass = WTObject.class,interfaces = {ContentHolder.class},
        properties = {
                @GeneratedProperty(name="WTChangeORDER2OR", type=String.class,
                        constraints=@PropertyConstraints(required=true)),
                @GeneratedProperty(name="PartOID", type= String.class),
                @GeneratedProperty(name="PartName", type= String.class),
                @GeneratedProperty(name="PartNumber", type= String.class),
                @GeneratedProperty(name="PartOldVersion", type= String.class),
                @GeneratedProperty(name="CustomerArtifact", type= String.class),
                @GeneratedProperty(name="XLArtifact", type= String.class),
                @GeneratedProperty(name="InMaking", type= String.class),
                @GeneratedProperty(name="InOrdering", type= String.class),
                @GeneratedProperty(name="Frock", type= String.class),
                @GeneratedProperty(name="Mold", type= String.class),
                @GeneratedProperty(name="CuttingTool", type= String.class),
                @GeneratedProperty(name="Fixtures", type= String.class),
                @GeneratedProperty(name="InTheLibrary", type= String.class),
                @GeneratedProperty(name="InOrder", type= String.class),
                @GeneratedProperty(name="Wip", type= String.class),
                @GeneratedProperty(name="OtherNotes", type= String.class)
        })
public class DisposalOldProducts extends _DisposalOldProducts {


    static final long serialVersionUID = 1;

    public static DisposalOldProducts newDisposalOldProducts() throws WTException {
        final DisposalOldProducts instance = new DisposalOldProducts();
        instance.initialize();
        return instance;
    }
}
