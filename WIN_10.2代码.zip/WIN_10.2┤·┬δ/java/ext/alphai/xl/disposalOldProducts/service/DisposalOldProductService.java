package ext.alphai.xl.disposalOldProducts.service;

import ext.alphai.xl.disposalOldProducts.utils.CommonUtil;
import ext.alphai.xl.disposalOldProducts.DisposalOldProducts;
import ext.alphai.xl.disposalOldProducts.controller.vo.ChangeRequestVO;
import ext.alphai.xl.disposalOldProducts.utils.PersistenceUtil;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeRequest2;
import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class DisposalOldProductService {
    /**
     * 通过变更Oid获取变更内容
     *
     * @param oid
     * @return
     */
    public static List<DisposalOldProducts> getDisposalOldProductChangeOid(String oid) {
        Vector<DisposalOldProducts> vector = null;
        try {
            QuerySpec qs = new QuerySpec(DisposalOldProducts.class);
            SearchCondition sc = new SearchCondition(DisposalOldProducts.class, DisposalOldProducts.WTCHANGE_ORDER2_OR, SearchCondition.EQUAL, oid);
            qs.appendWhere(sc);

            QueryResult qr = PersistenceHelper.manager.find(qs);
            vector = qr.getObjectVectorIfc().getVector();
            return vector;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vector;
    }



    /**
     * 从更改请求oid中获取受影响对象 oid=VR:wt.change2.WTChangeRequest2:1050532
     *
     * @param changeOid
     * @return 返回受影响对象集合  （不完善，只返回WTPart   EPMDocument  pdmLinkProduct）
     */
    public static List<WTObject> getAffectObjectByChangeOid(String changeOid) {
        List<WTObject> objs = new ArrayList<>();
        try {
            WTChangeRequest2 order2 = (WTChangeRequest2) PersistenceUtil.oid2Object(changeOid);
            QueryResult changeAbles = ChangeHelper2.service.getChangeables(order2);
            while (changeAbles.hasMoreElements()) {
                Object obj = changeAbles.nextElement();
                if (obj instanceof WTPart) {
                    WTPart part = (WTPart) obj;
                    objs.add(part);
                    System.out.println(part.getName());
                } else if (obj instanceof EPMDocument) {
                    EPMDocument epm = (EPMDocument) obj;
                    objs.add(epm);
                    System.out.println(epm.getName());
                } else if (obj instanceof PDMLinkProduct) {
                    PDMLinkProduct pdmLinkProduct = (PDMLinkProduct) obj;
                    objs.add(pdmLinkProduct);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return objs;

    }

    /**
     *  添加旧品处置方案 显示的受影响对象，若数据库中已存在就不展示
     * @param changeRequestOid
     * @return
     */
    public static List<ChangeRequestVO> getAddAffectObjList (String changeRequestOid ) {
        //通过变更请求Oid获取受影响的部件集合
        List<WTObject> affectObjs= getAffectObjectByChangeOid(changeRequestOid);

        List<ChangeRequestVO> changeRequestVOs = new ArrayList<>();

        //数据库存在当前变更请求的受影响对象，不存入VO集合中
        for (WTObject affectObj : affectObjs) {
            String name = "";
            String number = "";
            String version = "";
            String partOid = "";

            //若是WTPart
            if (affectObj instanceof WTPart){
                WTPart affectPart =  (WTPart)affectObj;
                //判断数据库是否存在当前部件  ，不存在展示
                if (!isExistPartByChangeRequestOid(changeRequestOid,affectPart)){
                    ChangeRequestVO vo = new ChangeRequestVO();
                    name = affectPart.getName();
                    number = affectPart.getNumber();
                    version = affectPart.getVersionIdentifier().getValue();
                    partOid=PersistenceUtil.object2Oid(affectPart);

                    //存入vo中
                    vo.setPartName(name);
                    vo.setPartNumber(number);
                    vo.setPartOldVersion(version);
                    vo.setPartOid(partOid);
                    vo.setChangeRequestOID(changeRequestOid);
                    //存入展示vo集合中
                    changeRequestVOs.add(vo);
                }
            }

            //添加其他对象


        }

        return changeRequestVOs;
    }


    /**
     * 插入
     *
     * @param item
     */
    public static void insertOneRequest(DisposalOldProducts item) {
        System.out.println("进入插入数据库方法当前插入的变更OR" + item.getWTChangeORDER2OR());
        try {
            PersistenceHelper.manager.save(item);
        } catch (WTException e) {
            e.getMessage();
        }
    }

    public static int updateChangeRequestItem(String idA2A, ChangeRequestVO vo) {
        String sql = "UPDATE DisposalOldProducts SET CustomerArtifact=?,CuttingTool=?,Fixtures=?,Frock=?,InMaking=?,InOrder=?" +
                ",InOrdering=?,InTheLibrary=?,Mold=?,OtherNotes=?,PartName=?,PartNumber=?,PartOID=?,PartOldVersion=?,Wip=?,XLArtifact=?" +
                ",updateCountA2=updateCountA2+1 WHERE idA2A2 = " + idA2A;
        System.out.println("打印传入的vo" + vo.toString());
        String[] params = {
                vo.getCustomerArtifact(),
                vo.getCuttingTool(),
                vo.getFixtures(),
                vo.getFrock(),
                vo.getInMaking(),
                vo.getInOrder(),
                vo.getInOrdering(),
                vo.getInTheLibrary(),
                vo.getMold(),
                vo.getOtherNotes(),
                vo.getPartName(),
                vo.getPartNumber(),
                vo.getPartOid(),
                vo.getPartOldVersion(),
                vo.getWip(),
                vo.getXlArtifact(),
        };
        int i = CommonUtil.excuteUpdate(sql, params);

        return i;
    }

    /**
     * 判断数据库是否存在当前部件
     * @param changeRequestOid   更改请求OID
     * @param part                 受影响part对象
     * @return  存在返回 true   否则 false
     */
    public static boolean isExistPartByChangeRequestOid(String changeRequestOid, WTPart part) {
        boolean flag = false;
        List<DisposalOldProducts> disposalOldProducts = getDisposalOldProductChangeOid(changeRequestOid);

        //遍历数据库部件数据
        for (DisposalOldProducts disposalOldProduct : disposalOldProducts) {
            String partNumber = disposalOldProduct.getPartNumber();
            if (partNumber.equals(part.getNumber())) {
                flag = true;
            }
        }
        return flag;
    }

}
