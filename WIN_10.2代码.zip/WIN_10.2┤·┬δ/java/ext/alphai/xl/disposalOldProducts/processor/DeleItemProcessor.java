package ext.alphai.xl.disposalOldProducts.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContext;
import ext.alphai.xl.disposalOldProducts.DisposalOldProducts;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;

public class DeleItemProcessor extends DefaultObjectFormProcessor {
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> paramList) throws WTException {

        ArrayList<NmContext> selected = nmCommandBean.getSelected();
        for (NmContext context : selected) {
            NmOid nmOid = context.getTargetOid();
            Object object = nmOid.getRef();
            if (object instanceof DisposalOldProducts)
                PersistenceHelper.manager.delete((Persistable)object);
        }
        return null;
    }
}
