package ext.alphai.xl.disposalOldProducts.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.forms.FormResultAction;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.xl.disposalOldProducts.DisposalOldProducts;
import ext.alphai.xl.disposalOldProducts.controller.vo.ChangeRequestVO;
import ext.alphai.xl.disposalOldProducts.service.DisposalOldProductService;
import ext.alphai.xl.disposalOldProducts.utils.PersistenceUtil;
import wt.change2.WTChangeRequest2;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.session.SessionHelper;
import wt.util.HTMLEncoder;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import java.util.*;


public class UpdateItemProcessor extends DefaultObjectFormProcessor {

    private static final ReferenceFactory refefence = new ReferenceFactory();


    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {

        System.out.println("进入修改");
        StringBuffer msg = new StringBuffer();

//        NmOid primaryOid = nmCommandBean.getPrimaryOid();
//        WTChangeRequest2 changeRequest2 = (WTChangeRequest2)primaryOid.getRef();
//        String changeRequestOR = PersistenceUtil.object2Oid(changeRequest2);

        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();

        String[] IDA2A = new String[]{};
        String[] partOid = new String[]{};
        String[] partName = new String[]{};
        String[] partNumber = new String[]{};
        String[] partOldVersion = new String[]{};

        String[] customerArtifact = new String[]{};
        String[] xlArtifact = new String[]{};
        String[] inMaking = new String[]{};
        String[] inOrdering = new String[]{};
        String[] frock = new String[]{};
        String[] mold = new String[]{};
        String[] cuttingTool = new String[]{};
        String[] fixtures = new String[]{};

        String[] inTheLibrary = new String[]{};
        String[] inOrder = new String[]{};
        String[] wip = new String[]{};
        String[] otherNotes = new String[]{};
        for (String key : parameterMap.keySet()) {
            Object value = parameterMap.get(key);

            String[] values = (String[]) value;
            for (String a : values) {
                System.out.println("key=" + key + "value=" + a);
            }
            if ("IDA2A".equals(key)) {
                IDA2A = (String[]) value;
            }
            if ("partOid".equals(key)) {
                partOid = (String[]) value;
            }
            if ("partName".equals(key)) {
                partName = (String[]) value;
            }
            if ("partNumber".equals(key)) {
                partNumber = (String[]) value;
            }
            if ("partOldVersion".equals(key)) {
                partOldVersion = (String[]) value;
            }

            if ("customerArtifact".equals(key)) {
                customerArtifact = (String[]) value;
            }
            if ("xlArtifact".equals(key)) {
                xlArtifact = (String[]) value;
            }
            if ("inMaking".equals(key)) {
                inMaking = (String[]) value;
            }
            if ("inOrdering".equals(key)) {
                inOrdering = (String[]) value;
            }
            if ("frock".equals(key)) {
                frock = (String[]) value;
            }
            if ("mold".equals(key)) {
                mold = (String[]) value;
            }
            if ("cuttingTool".equals(key)) {
                cuttingTool = (String[]) value;
            }
            if ("fixtures".equals(key)) {
                fixtures = (String[]) value;
            }
            if ("inTheLibrary".equals(key)) {
                inTheLibrary = (String[]) value;
            }
            if ("inOrder".equals(key)) {
                inOrder = (String[]) value;
            }
            if ("wip".equals(key)) {
                wip = (String[]) value;
            }
            if ("otherNotes".equals(key)) {
                otherNotes = (String[]) value;
            }
        }


        for (int i = 0; i < partNumber.length; i++) {
            ChangeRequestVO item = new ChangeRequestVO();
//            DisposalOldProducts item = (DisposalOldProducts)PersistenceUtil.oid2Object(itemOR[i]);
//            System.out.println("打印请求项名称："+item.getPartName());

                item.setCustomerArtifact(customerArtifact[i]);
                item.setCuttingTool(cuttingTool[i]);
                item.setFixtures(fixtures[i]);
                item.setFrock(frock[i]);
                item.setInMaking(inMaking[i]);
                item.setInOrder(inOrder[i]);
                item.setInOrdering(inOrdering[i]);
                item.setInTheLibrary(inTheLibrary[i]);
                item.setMold(mold[i]);
                item.setOtherNotes(otherNotes[i]);
                item.setPartName(partName[i]);
                item.setPartNumber(partNumber[i]);
                item.setPartOid(partOid[i]);
                item.setPartOldVersion(partOldVersion[i]);
                item.setWip(wip[i]);
                item.setXlArtifact(xlArtifact[i]);
                item.setIDA2A(IDA2A[i]);

            int i1 = DisposalOldProductService.updateChangeRequestItem(item.getIDA2A(), item);
            if (i1<=0){
                FormResult result = new FormResult(FormProcessingStatus.FAILURE);
                result.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), (String)null, (ArrayList)null, new String[]{"修改失败：" }));
                return result;
            }





        }

        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        String refreshAction = "window.opener.PTC.jca.table.Utils.reload('ext.alphai.xl.disposalOldProducts.builder.DisposalOldProductsTable');";//xxx 为 table id

        refreshAction = HTMLEncoder.encodeForJavascript(refreshAction);

        String jString = "window.close();" + refreshAction;

        result.setNextAction(FormResultAction.JAVASCRIPT);

        result.setJavascript(jString);
        result.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null, null, new String[] { "修改旧品处置方案成功!" }));
        result.setSkipPageRefresh(true);



        return result;
    }

}
