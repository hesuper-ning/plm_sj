package ext.alphai.xl.disposalOldProducts.controller.vo;

public class ChangeRequestVO {
    private String changeRequestOID;      // 变更请求OID
    private String partName;             // 部件名称
    private String partNumber;           // 编号
    private String partOldVersion;       // 部件旧版本
    private String customerArtifact;     // 顾客成品
    private String xlArtifact;           // 西菱成品
    private String inMaking;             // 在制品
    private String inOrdering;           // 在订品
    private String frock;                // 工装
    private String mold;                 // 模具
    private String cuttingTool;          // 刀具
    private String fixtures;             // 检具
    private String inTheLibrary;         // 在库存
    private String inOrder;              // 在订
    private String wip;                  // WIP
    private String otherNotes;           // 其他备注
    private String partOid;           // 受影响对象的oid

    private String IDA2A;  //修改项的idA2A

    @Override
    public String toString() {
        return "ChangeRequestVO{" +
                "changeRequestOID='" + changeRequestOID + '\'' +
                ", partName='" + partName + '\'' +
                ", partNumber='" + partNumber + '\'' +
                ", partOldVersion='" + partOldVersion + '\'' +
                ", customerArtifact='" + customerArtifact + '\'' +
                ", xlArtifact='" + xlArtifact + '\'' +
                ", inMaking='" + inMaking + '\'' +
                ", inOrdering='" + inOrdering + '\'' +
                ", frock='" + frock + '\'' +
                ", mold='" + mold + '\'' +
                ", cuttingTool='" + cuttingTool + '\'' +
                ", fixtures='" + fixtures + '\'' +
                ", inTheLibrary='" + inTheLibrary + '\'' +
                ", inOrder='" + inOrder + '\'' +
                ", wip='" + wip + '\'' +
                ", otherNotes='" + otherNotes + '\'' +
                ", partOid='" + partOid + '\'' +
                ", IDA2A='" + IDA2A + '\'' +
                '}';
    }

    public String getIDA2A() {
        return IDA2A;
    }

    public void setIDA2A(String IDA2A) {
        this.IDA2A = IDA2A;
    }

    public String getPartOid() {
        return partOid;
    }

    public void setPartOid(String partOid) {
        this.partOid = partOid;
    }





    public String getChangeRequestOID() {
        return changeRequestOID;
    }

    public void setChangeRequestOID(String changeRequestOID) {
        this.changeRequestOID = changeRequestOID;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartOldVersion() {
        return partOldVersion;
    }

    public void setPartOldVersion(String partOldVersion) {
        this.partOldVersion = partOldVersion;
    }

    public String getCustomerArtifact() {
        return customerArtifact;
    }

    public void setCustomerArtifact(String customerArtifact) {
        this.customerArtifact = customerArtifact;
    }

    public String getXlArtifact() {
        return xlArtifact;
    }

    public void setXlArtifact(String xlArtifact) {
        this.xlArtifact = xlArtifact;
    }

    public String getInMaking() {
        return inMaking;
    }

    public void setInMaking(String inMaking) {
        this.inMaking = inMaking;
    }

    public String getInOrdering() {
        return inOrdering;
    }

    public void setInOrdering(String inOrdering) {
        this.inOrdering = inOrdering;
    }

    public String getFrock() {
        return frock;
    }

    public void setFrock(String frock) {
        this.frock = frock;
    }

    public String getMold() {
        return mold;
    }

    public void setMold(String mold) {
        this.mold = mold;
    }

    public String getCuttingTool() {
        return cuttingTool;
    }

    public void setCuttingTool(String cuttingTool) {
        this.cuttingTool = cuttingTool;
    }

    public String getFixtures() {
        return fixtures;
    }

    public void setFixtures(String fixtures) {
        this.fixtures = fixtures;
    }

    public String getInTheLibrary() {
        return inTheLibrary;
    }

    public void setInTheLibrary(String inTheLibrary) {
        this.inTheLibrary = inTheLibrary;
    }

    public String getInOrder() {
        return inOrder;
    }

    public void setInOrder(String inOrder) {
        this.inOrder = inOrder;
    }

    public String getWip() {
        return wip;
    }

    public void setWip(String wip) {
        this.wip = wip;
    }

    public String getOtherNotes() {
        return otherNotes;
    }

    public void setOtherNotes(String otherNotes) {
        this.otherNotes = otherNotes;
    }
}
