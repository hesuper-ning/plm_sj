package ext.alphai.xl.disposalOldProducts.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import ext.alphai.partAttributeChange.utils.PersistenceUtil;
import ext.alphai.xl.disposalOldProducts.DisposalOldProducts;
import wt.part.WTPart;
import wt.util.WTException;

public class OldProductUtility extends AbstractDataUtility {
    /**
     * 部件使用关系变更项建模
     * WTChangeORDER2OR 变更请求OID
     * PartName 部件名称
     * PartNumber 编号
     * PartOldVersion 部件旧版本
     * <p>
     * CustomerArtifact 顾客成品
     * XLArtifact   西菱成品
     * InMaking   在制品
     * InOrdering 在订品
     * Frock    工装
     * Mold     模具
     * CuttingTool  刀具
     * Fixtures 检具
     * <p>
     * InTheLibrary 在库存
     * InOrder 在订
     * Wip   WIP
     */

    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        DisposalOldProducts item = (DisposalOldProducts) o;

        System.out.println("进入dataUtilty");
        //获取IDA2A2  可能是IBA2A2
        String itemOR = PersistenceUtil.object2Oid(item);
        System.out.println(itemOR);

        String partName = item.getPartName();
        String partNumber = item.getPartNumber();
        String partOldVersion = item.getPartOldVersion();

        String customerArtifact = item.getCustomerArtifact();
        String xlArtifact = item.getXLArtifact();
        String inMaking = item.getInMaking();
        String inOrdering = item.getInOrdering();
        String frock = item.getFrock();
        String mold = item.getMold();
        String cuttingTool = item.getCuttingTool();
        String fixtures = item.getFixtures();

        String inTheLibrary = item.getInTheLibrary();
        String inOrder = item.getInOrder();
        String wip = item.getWip();
        String otherNotes = item.getOtherNotes();


        switch (s) {
            case "partNumber":
                System.out.println("部件编号" + partNumber);
                return partNumber;
            case "partName":
                System.out.println("部件名称" + partName);
                return partName;
            case "partOldVersion":
                System.out.println("旧版本" + partOldVersion);
                return partOldVersion;

            case "CustomerArtifact":
                return customerArtifact;
            case "XLArtifact":
                return xlArtifact;
            case "InMaking":
                return inMaking;
            case "InOrdering":
                return inOrdering;
            case "Frock":
                return frock;
            case "Mold":
                return mold;
            case "CuttingTool":
                return cuttingTool;
            case "Fixtures":
                return fixtures;

            case "InTheLibrary":
                return inTheLibrary;
            case "InOrder":
                return inOrder;
            case "Wip":
                return wip;
                case "OtherNotes":
                return otherNotes;
        }
        return null;
    }
    /**
     * 传入一个父部件返回在table上可以点击的物料编号连接
     *
     * @param part
     * @return
     * @throws WTException
     */
    public static UrlDisplayComponent getPartUrlByPartNumber(WTPart part) throws WTException {
        NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();

        urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);

        NmOid contentOid = NmOid.newNmOid(part.getPersistInfo().getObjectIdentifier());

        String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null, true);

        UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent("", part.getNumber(), link);
        return urlDisplayComponent;
    }
}
