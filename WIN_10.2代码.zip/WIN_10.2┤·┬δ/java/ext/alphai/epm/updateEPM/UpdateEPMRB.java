package ext.alphai.epm.updateEPM;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID( "ext.alphai.epm.updateEPM.UpdateEPMRB" )
public class UpdateEPMRB extends WTListResourceBundle {

    @RBEntry("excel导出EPM属性")
    public static final String PRIVATE_CONSTANT_1 = "EpmDocument.downLoadEPM.description";

    @RBEntry("excel导出EPM属性")
    public static final String PRIVATE_CONSTANT_2 = "EpmDocument.downLoadEPM.title";

    @RBEntry("excel导出EPM属性")
    public static final String PRIVATE_CONSTANT_3 = "EpmDocument.downLoadEPM.tooltip";



    @RBEntry("上传excel修改EPM属性")
    public static final String PRIVATE_CONSTANT_4 = "EpmDocument.upLoadEPM.description";

    @RBEntry("上传excel修改EPM属性")
    public static final String PRIVATE_CONSTANT_5 = "EpmDocument.upLoadEPM.title";

    @RBEntry("上传excel修改EPM属性")
    public static final String PRIVATE_CONSTANT_6 = "EpmDocument.upLoadEPM.tooltip";
}
