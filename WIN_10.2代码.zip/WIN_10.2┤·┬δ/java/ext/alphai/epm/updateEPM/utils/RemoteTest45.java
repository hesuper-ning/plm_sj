package ext.alphai.epm.updateEPM.utils;
import wt.content.*;
import wt.epm.EPMDocument;
import wt.fc.Identified;
import wt.fc.PersistenceServerHelper;
import wt.lifecycle.State;
import wt.method.MethodContext;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.pom.WTConnection;
import wt.util.WTException;
import wt.util.WTRuntimeException;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.PreparedStatement;


/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 */
public class RemoteTest45 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;

    public static void main(String[] args) throws WTRuntimeException, WTException {
//		ReferenceFactory rf = new ReferenceFactory();
//		WTDocument doc = (WTDocument) rf.getReference("OR:wt.doc.WTDocument:1796110").getObject();
//		WTPart part = (WTPart) rf.getReference("OR:wt.part.WTPart:1939296").getObject();
//		EPMDocument epm = (EPMDocument) rf.getReference("OR:wt.epm.EPMDocument:1833683").getObject();
//		WTChangeRequest2 ecr = (WTChangeRequest2) rf.getReference("OR:wt.change2.WTChangeRequest2:2113629").getObject();
//		WorkItem wi = (WorkItem) rf.getReference("OR:wt.workflow.work.WorkItem:2538761").getObject();
//		PlanActivity planActivity = (PlanActivity) rf
//				.getReference("OR:com.ptc.projectmanagement.plan.PlanActivity:849396").getObject();
        String str = (String) invoke("process", RemoteTest45.class.getName(), null, new Class[]{}, new Object[]{});
    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String process() {
        try {


            //用文件名获取对象
            EPMDocument epm = (EPMDocument)EPMUtils.getObjByCADName("t908101.asm", EPMDocument.class);
            System.out.println(epm.getCADName());




            String lifeCycleState = epm.getLifeCycleState().toString();

            System.out.println(lifeCycleState);


            //修改编号
//            EPMUtils.updateEPMNumber(epm,epm.getNumber());


            //修改名称
//            EPMUtils.updateEPMName(epm,epm.getName());


            //修改文件名
//            updateEPMFileNameAndNumber(epm,"908101.asm");




        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 更改CAD部件文件名,注意cadName必须含有后缀asm,或者prt
     * @param epm
     * @param newCADName
     * @throws WTException
     */
    public static void updateEPMFileNameAndNumber(EPMDocument epm , String newCADName) throws Exception {

        //先获取ApplicationData对象

        ContentHolder contentHolder = ContentHelper.service.getContents((ContentHolder) epm);
        ContentItem contentitem = ContentHelper.getPrimary((FormatContentHolder) contentHolder);
        ApplicationData applicationdata = (ApplicationData) contentitem;

        if (applicationdata!=null){
            System.out.println("修改文件名称");
            applicationdata.setFileName(newCADName);
            PersistenceServerHelper.manager.update(applicationdata);//更新文件名



            Identified identified = (Identified) epm.getMaster();
            MethodContext methodContext = MethodContext.getContext();
            WTConnection connection = (WTConnection)methodContext.getConnection();
            PreparedStatement prepareStatement = connection.prepareStatement("update EPMDocumentMaster set CADName=?,documentnumber=? where ida2a2="+identified.getPersistInfo().getObjectIdentifier().getId());
            prepareStatement.setString(1,newCADName);//更新CADName
            prepareStatement.setString(2,newCADName.toUpperCase());//更新number
            prepareStatement.execute();
            System.out.println("001-Filename has been setted by new name:"+newCADName +",success!!!");
        }

    }

}
