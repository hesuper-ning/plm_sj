package ext.alphai.epm.updateEPM.utils;


import wt.content.*;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentHelper;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentMasterIdentity;
import wt.epm.structure.EPMMemberLink;
import wt.epm.structure.EPMReferenceLink;
import wt.epm.structure.EPMStructureHelper;
import wt.fc.*;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.lifecycle.State;
import wt.method.MethodContext;
import wt.org.WTPrincipal;
import wt.pom.WTConnection;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EPMUtils {

    public static List<EPMDocument> getAllChildByEpm(EPMDocument epm) {
        List<EPMDocument> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        EPMDocument epmDoc = null;
        QueryResult qr2 = null;
        try {
            QueryResult qc = EPMStructureHelper.service.navigateUses(epm, null, false);
            while (qc.hasMoreElements()) {
                EPMMemberLink link = (EPMMemberLink) qc.nextElement();
                //epm连接获取epm对象
                qr2 = VersionControlHelper.service.allVersionsOf(link.getUses());
                if (qr2.hasMoreElements()) {

                    epmDoc = (EPMDocument) qr2.nextElement();
                    localList.add(epmDoc);

                    // 递归调用，将结果合并到局部列表
                    localList.addAll(getAllChildByEpm(epmDoc));
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }

    /**
     * 根据编号获取对象
     *
     * @param number
     * @param queryClass
     * @return Object
     */
    @SuppressWarnings("deprecation")
    public static Object getObjByNumber(String number, Class queryClass) {
        try {
            if (number.isEmpty()) {
                return null;
            }
            QuerySpec qs = new QuerySpec(queryClass);
            qs.appendWhere(new SearchCondition(queryClass, "master>number", SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                return qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 根据CADName获取对象
     *
     * @param cadName
     * @param queryClass
     * @return Object
     */
    @SuppressWarnings("deprecation")
    public static Object getObjByCADName(String cadName, Class queryClass) {
        try {
            if (cadName.isEmpty()) {
                return null;
            }
            QuerySpec qs = new QuerySpec(queryClass);
            qs.appendWhere(new SearchCondition(queryClass, "master>CADName", SearchCondition.EQUAL, cadName.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                return qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }




    /**
     * 通过父epm编号获取 epm结构树(含父epm)
     * @param number
     * @return
     */
    public static List<EPMDocument> getAllEPMByNumber(String number) {
        List<EPMDocument> allEPM = new ArrayList<>();
        EPMDocument fatherEPM = (EPMDocument) getObjByNumber(number, EPMDocument.class);

        allEPM.add(fatherEPM);

        List<EPMDocument> allChildByEpm = getAllChildByEpm(fatherEPM);
        for (EPMDocument childEOM : allChildByEpm) {
            allEPM.add(childEOM);
        }

        return allEPM;

    }

        /**
         * 修改EPM生命周期状态
         *
         * @param  epm
         * @param     state
         * @return String
         * @throws WTPropertyVetoException
         * @throws WTException
         */
    public static String changEPMState(EPMDocument epm, String state) throws WTPropertyVetoException, WTException {
        String message = "";
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();

            epm = (EPMDocument) wt.lifecycle.LifeCycleHelper.service.setLifeCycleState((wt.lifecycle.LifeCycleManaged) epm,
                    State.toState(state));

            PersistenceHelper.manager.refresh(epm);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return message;
    }


    /**
     *  通过3D获取2D
     * @param epm3D
     * @return
     * @throws WTException
     */
    public static List<EPMDocument> get2DBy3D(EPMDocument epm3D) throws WTException {
        List<EPMDocument> epm2Ds = new ArrayList<>();

        EPMDocumentMaster dm = (EPMDocumentMaster) epm3D.getMaster();
        QueryResult qr = EPMStructureHelper.service.navigateReferencedBy(dm, null, false);
        while (qr.hasMoreElements()) {
            EPMReferenceLink rl = (EPMReferenceLink) qr.nextElement();
            if (rl.getDepType() == com.ptc.wpcfg.pdmabstr.PROEDependency.DEP_T_DRAW) {
                EPMDocument epm2D = rl.getReferencedBy();
                epm2Ds.add(epm2D);
            }
        }
        return epm2Ds;
    }


    //获取.前的数据
    public static String removeExtension(String fileName) {
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1) {
            return fileName; // 如果没有找到点号，直接返回原始文件名
        } else {
            return fileName.substring(0, lastDotIndex); // 截取点号之前的部分
        }
    }

    // 方法：获取文件后缀名
    public static String getFileExtension(String fileName) {
        if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
            return fileName.substring(fileName.lastIndexOf(".") + 1);
        } else {
            return "";
        }
    }

    /**
     *
     * @param number 新的文件名编号
     * @param suffix 旧文件名后缀
     * @return
     */
    public static String getNewSuffixFileName(String number , String suffix){
        return removeExtension(number) + "."  + getFileExtension(suffix);
    }


    /**
     * 更改CAD部件编号
     * @param epm
     * @param newNumber
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPMNumber(EPMDocument epm , String newNumber) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified)epm.getMaster();
        EPMDocumentMasterIdentity iden=(EPMDocumentMasterIdentity)icp.getIdentificationObject();
        iden.setNumber(newNumber);
        IdentityHelper.service.changeIdentity(icp,iden);
        PersistenceHelper.manager.refresh(epm);
    }

    /**
     * 修改EPM名称
     * @param epm
     * @param newName
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPMName(EPMDocument epm , String newName) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified)epm.getMaster();
        EPMDocumentMasterIdentity iden=(EPMDocumentMasterIdentity)icp.getIdentificationObject();
        iden.setName(newName);
        IdentityHelper.service.changeIdentity(icp,iden);
        PersistenceHelper.manager.refresh(epm);
    }


    /**
     * 更改CAD部件文件名,注意cadName必须含有后缀asm,或者prt
     * @param epm
     * @param newCADName
     * @throws WTException
     */
    public static void updateEPMFileName(EPMDocument epm , String newCADName) throws WTException {
        EPMDocumentMaster epmdocumentmaster = (EPMDocumentMaster) epm.getMaster();
        WTKeyedMap map = new WTKeyedHashMap(1);
        map.put(epmdocumentmaster, newCADName);
        EPMDocumentHelper.service.changeCADName(map);
    }

    /**
     * 修改cad部件的编号,名称,文件名
     * @param epm
     * @param newNumber
     * @param newName
     * @param newCADName
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void updateEPM(EPMDocument epm,String newNumber , String newName , String newCADName) throws WTException, WTPropertyVetoException {
        Identified icp = (Identified)epm.getMaster();
        EPMDocumentMasterIdentity iden=(EPMDocumentMasterIdentity)icp.getIdentificationObject();
        //设置编号
        if (newNumber!=null) {
            iden.setNumber(newNumber);
        }
        //设置名称
        //
        if (newName!=null){
            iden.setName(newName);
        }
        IdentityHelper.service.changeIdentity(icp,iden);
        PersistenceHelper.manager.refresh(epm);

        //修改CADName 文件名
        if (newCADName!=null) {
            EPMDocumentMaster epmdocumentmaster = (EPMDocumentMaster) epm.getMaster();
            WTKeyedMap map = new WTKeyedHashMap(1);
            map.put(epmdocumentmaster, newCADName);
            //修改文件名
            EPMDocumentHelper.service.changeCADName(map);
        }
    }


    /**
     * 更改CAD部件文件名与编号同时修改了对应的applicationDate文件名
     * @param epm
     * @param newCADName
     * @throws WTException
     */
    public static void updateEPMFileNameAndNumber(EPMDocument epm , String newCADName) throws Exception {

        //先获取ApplicationData对象

        ContentHolder contentHolder = ContentHelper.service.getContents((ContentHolder) epm);
        ContentItem contentitem = ContentHelper.getPrimary((FormatContentHolder) contentHolder);
        ApplicationData applicationdata = (ApplicationData) contentitem;

        if (applicationdata!=null){
            System.out.println("修改文件名称");
            applicationdata.setFileName(newCADName);
            PersistenceServerHelper.manager.update(applicationdata);//更新文件名



//            Identified identified = (Identified) epm.getMaster();
//            MethodContext methodContext = MethodContext.getContext();
//            WTConnection connection = (WTConnection)methodContext.getConnection();
//            PreparedStatement prepareStatement = connection.prepareStatement("update EPMDocumentMaster set CADName=?,documentnumber=? where ida2a2="+identified.getPersistInfo().getObjectIdentifier().getId());
//            prepareStatement.setString(1,newCADName);//更新CADName
//            prepareStatement.setString(2,newCADName.toUpperCase());//更新number
//            prepareStatement.execute();

        }
        updateEPMFileName(epm,newCADName);
        updateEPMNumber(epm,newCADName.toUpperCase());
        System.out.println("001-Filename has been setted by new name:"+newCADName +",success!!!");

    }
}
