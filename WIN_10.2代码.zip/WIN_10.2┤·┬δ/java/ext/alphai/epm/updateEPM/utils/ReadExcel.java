package ext.alphai.epm.updateEPM.utils;

import ext.alphai.epm.updateEPM.controller.VO.EpmVO;
import ext.replacePart.controller.WTPartSubstituteLinkVo;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ReadExcel {

    private static final int START_ROW = 2;


    private static final int START_CELL = 0;

    private static final int END_CELL = 5;

    public static String PDF_TEMP = "";


    /**
     * 写入Bom变更页
     *
     * @param
     * @return
     */
    public static Workbook writeToExcel(Workbook workbook, List<EpmVO> epmVOS) {
        System.out.println("进入插入EPM sheet的集合长度" + epmVOS.size());

        Sheet sheet = workbook.getSheetAt(0); // 获取第一个工作表

        int lastRowNum = sheet.getLastRowNum();
        int startRow = lastRowNum + 1;

        int count = 1;
        for (int i = startRow; i < startRow + epmVOS.size(); i++) {
            EpmVO vo = epmVOS.get(i - startRow);
            Row row = sheet.createRow(i);
            row.createCell(0).setCellValue(count++);
            row.createCell(1).setCellValue(vo.getOldFileName());//旧文件名
            row.createCell(2).setCellValue("");//文件名
            row.createCell(3).setCellValue(vo.getName());//名称
            row.createCell(4).setCellValue(vo.getItemNumber());//物料名称
            row.createCell(5).setCellValue(vo.getMaterial());//材料
        }

        return workbook;
    }

    public static List<EpmVO> getExcelModel(InputStream inputStream) throws IOException, InvalidFormatException {
        Workbook workbook = WorkbookFactory.create(inputStream);

        // 获取要读取的工作表
        Sheet sheet = workbook.getSheetAt(0); // 例如，这里选择第一个工作表
       return readExcel(sheet);

    }

    /**
     * 读取
     *
     * @param sheet
     * @return
     */
    public static List<EpmVO> readExcel(Sheet sheet) {
        List<EpmVO> res = new ArrayList<>();
        List<List<String>> data = new ArrayList<>();
        int lastRowNum = sheet.getLastRowNum();
        System.out.println("最后一行减1为：" + lastRowNum);
        try {
            for (int i = START_ROW; i <= lastRowNum; i++) {
                Row row = sheet.getRow(i);
                List<String> rowData = new ArrayList<>();

                for (int j = START_CELL; j <= END_CELL; j++) {
                    Cell cell = row.getCell(j);

                    if (cell != null) {
                        if (3 == cell.getCellType()) {
                            rowData.add("");
                        } else if (1 == cell.getCellType()) {
                            System.out.println("01 " + cell.getStringCellValue());
                            rowData.add(cell.getStringCellValue());
                        } else if (0 == cell.getCellType()) {
                            System.out.println("02 " + cell.getNumericCellValue());
                            rowData.add(String.valueOf(cell.getNumericCellValue()));
                        }
                    }else{
                        rowData.add("");
                    }
                }

                data.add(rowData);
            }
            // 拼接返回参数值
            for (int i = 0; i < data.size(); i++) {
                EpmVO model = new EpmVO();
                List<String> strings = data.get(i);
                for (int j = 0; j < strings.size(); j++) {
                    String s = strings.get(j);
//注意cad部件文件名需要变为小写
                    switch (j) {
                        case 1:
                            model.setOldFileName(s);
                            break;
                        case 2:
                            model.setFileName(s);
                            break;
                        case 3:
                            model.setName(s);
                            break;
                        case 4:
                            model.setItemNumber(s);
                            break;
                        case 5:
                            model.setMaterial(s);
                            break;
                    }
                }
                if (model.getOldFileName() != null) {
                    res.add(model);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }
}
