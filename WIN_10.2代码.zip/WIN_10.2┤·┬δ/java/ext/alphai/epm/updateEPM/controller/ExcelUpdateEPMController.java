package ext.alphai.epm.updateEPM.controller;



import ext.alphai.epm.updateEPM.controller.VO.EpmVO;
import ext.alphai.epm.updateEPM.utils.IBAUtil;
import ext.alphai.epm.updateEPM.utils.PropertiesUtil;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.json.JSONObject;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import wt.epm.EPMDocument;
import wt.pom.Transaction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import static ext.alphai.epm.updateEPM.utils.EPMUtils.*;
import static ext.alphai.epm.updateEPM.utils.ReadExcel.getExcelModel;

public class ExcelUpdateEPMController implements Controller {

    @Override
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 设置响应内容类型
        response.setContentType("text/html;charset=UTF-8");

        System.out.println("进入上传excel");

        String errMsg = "";


        //获取excel
        InputStream is = getFileInputStream(request, null);
        if (is != null) {
            //excel数据
            List<EpmVO> excelModel = getExcelModel(is);

            //获取传入的所有epm旧文件名
            HashSet<String> epmNumberList = new HashSet<>();
            for (EpmVO epmVO : excelModel) {
                epmNumberList.add(epmVO.getOldFileName());
            }

            String noEPM = checkEPMByNumber(epmNumberList);
            if (noEPM.isEmpty()) {
                updateEPM(excelModel);
            } else {
                errMsg = "不存在文件名为：" + noEPM + "的cad部件";
            }

        }

        if (errMsg.isEmpty()) {
            errMsg = "修改成功！";
        }
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(errMsg);
        out.flush();


        return null;
    }

    public static String checkEPMByNumber(HashSet<String> epmNumberList) {
        StringBuffer msg = new StringBuffer();

        for (String epmFileName : epmNumberList) {
            EPMDocument epm = (EPMDocument) getObjByCADName(epmFileName, EPMDocument.class);// 文件名转为大写形成cad编号，对应找到部件
            if (epm == null) {
                msg.append(epmFileName).append("  ");
            }
        }

        return msg.toString();

    }

    private static InputStream getFileInputStream(HttpServletRequest request, List<String> fileList) throws FileUploadException, IOException {
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);
        if (isMultipart) {
            FileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            Iterator<FileItem> items = upload.parseRequest(request).iterator();// 解析表单中提交的所有文件内容
            while (items.hasNext()) {
                FileItem item = (FileItem) items.next();
                if (!item.isFormField()) {
                    String fileName = item.getName();
                    if (fileList != null) {
                        fileList.add(fileName);
                    }
                    return item.getInputStream();
                }
            }
        }
        return null;
    }


    public static void updateEPM(List<EpmVO> excelEPMData) throws Exception {
        System.out.println("excel数据长度" + excelEPMData.size());
        System.out.println("数据为" + new JSONObject(excelEPMData).toString());

        //结构树
        Transaction trx = null;
        try {
            trx = new Transaction();
            trx.start();

            for (EpmVO excelEPMDatum : excelEPMData) {
                //获取修改的CAD部件
                EPMDocument epm = (EPMDocument) getObjByCADName(excelEPMDatum.getOldFileName() , EPMDocument.class);// 修改的CAD部件
                setEPMAttribute(epm, excelEPMDatum);

                //获取2d的CAD部件  最新需求  不再需要改3D对应2d，由客户输入
//                for (EPMDocument epm2d : get2DBy3D(epm)) {
//                    setEPMAttribute(epm2d, excelEPMDatum);
//                }
            }
            trx.commit();
            trx = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (trx != null) {
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    /**
     * 根据传入数据，修改epm部件的属性（3d和2d的属性修改一致），
     *
     * @param epm           传入的epm（传入3d或者2d）
     * @param excelEPMDatum （2d的属性与3d一致，直接传入excel的内容）
     * @throws Exception
     */
    public static void setEPMAttribute(EPMDocument epm, EpmVO excelEPMDatum) throws Exception {
        String oldFileName = epm.getCADName();

        //excel传入的修改数据
        String newFileName = excelEPMDatum.getFileName().toLowerCase();//文件名 属性   注意我填入的新文件名都要变小写
        String newName = excelEPMDatum.getName();//名称 属性
        String itemNumber = excelEPMDatum.getItemNumber();//物料编号IBA
        String material = excelEPMDatum.getMaterial();//材料IBA

        IBAUtil ibaUtil = new IBAUtil(epm);
        //修改IBA属性
        //传入的物料编号不为空，修改物料编号
        if (!itemNumber.isEmpty()) {
            ibaUtil.setIBAAttribute4AllType(epm, PropertiesUtil.getValueByKey("ext.alphai.ccode"), itemNumber);
        }

        //传入的材料不为空,修改材料
        if (!material.isEmpty()) {
            ibaUtil.setIBAAttribute4AllType(epm, PropertiesUtil.getValueByKey("ext.alphai.camt"), material);
        }

        // 先获取旧文档编号
        String oldCADNUmber = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("ext.alphai.old_cad_number"));
        //旧文档编号为空才修改
        if (oldCADNUmber.isEmpty()) {
            //将旧文件名写入旧文档编号
            ibaUtil.setIBAAttribute4AllType(epm, PropertiesUtil.getValueByKey("ext.alphai.old_cad_number"), oldFileName);
        }

        //修改属性
        //传入的文件名不为空，修改文件名
        if (!newFileName.isEmpty()) {
            //会改相应的2d  所有要获取旧文件名+excel填入的除后缀部分生成新文件名
            String newEMPFileName = getNewSuffixFileName(newFileName, oldFileName).toLowerCase();//新文件名编号+旧文件名后缀

            updateEPMFileNameAndNumber(epm,newEMPFileName);
//            updateEPMFileName(epm, newEMPFileName);
//
//
//            //编号修改成改后文件名一样
//            String newCadNumber =newEMPFileName.toUpperCase();//获取新的文件名 变成大写
//            updateEPMNumber(epm, newCadNumber);//修改CAD部件编号
        }

        //传入的名称不为空，修改名称
        if (!newName.isEmpty()) {
            //修改名称  获取文件名修改
            updateEPMName(epm, newName);
        }
    }

}
