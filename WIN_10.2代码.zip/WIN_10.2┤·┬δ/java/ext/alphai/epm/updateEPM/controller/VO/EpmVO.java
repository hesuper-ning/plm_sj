package ext.alphai.epm.updateEPM.controller.VO;

public class EpmVO {
    public String oldFileName;//文件名
    public String fileName;//文件名
    public String name;//名称
    public String itemNumber;//物料编号
    public String material;//材料

    @Override
    public String toString() {
        return "EpmVO{" +
                "oldFileName='" + oldFileName + '\'' +
                ", fileName='" + fileName + '\'' +
                ", name='" + name + '\'' +
                ", itemNumber='" + itemNumber + '\'' +
                ", material='" + material + '\'' +
                '}';
    }

    public EpmVO(String oldFileName, String fileName, String name, String itemNumber, String material) {
        this.oldFileName = oldFileName;
        this.fileName = fileName;
        this.name = name;
        this.itemNumber = itemNumber;
        this.material = material;
    }

    public String getOldFileName() {
        return oldFileName;
    }

    public void setOldFileName(String oldFileName) {
        this.oldFileName = oldFileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public EpmVO() {
    }
}
