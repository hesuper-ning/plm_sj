package ext.alphai.epm.updateEPM.processor;


import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.epm.updateEPM.controller.VO.EpmVO;
import ext.alphai.epm.updateEPM.utils.EPMUtils;
import ext.alphai.epm.updateEPM.utils.IBAUtil;
import ext.alphai.epm.updateEPM.utils.PropertiesUtil;
import ext.alphai.epm.updateEPM.utils.ReadExcel;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import wt.epm.EPMDocument;
import wt.util.WTException;
import wt.util.WTProperties;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.*;


public class exportEPMProcessor extends DefaultObjectFormProcessor {

    public static final  List<String> EXPORT_EPM_STATE_LIST =  new ArrayList(Arrays.asList(PropertiesUtil.getValueByKey("ext.aplhai.exportEPMState").split(",")));

    private static String excelName;

    public static String PDF_TEMP = "";

    static {
        String wtHome = null;
        try {
            WTProperties props = WTProperties.getLocalProperties();
            wtHome = props.getProperty("wt.temp");
            System.out.println("wtHome:" + wtHome);
            PDF_TEMP = wtHome + File.separator + "excel";
            File pdfFolder = new File(PDF_TEMP);
            if (!pdfFolder.exists()) {
                pdfFolder.mkdir();
            }
            System.out.println("PDF Temp Folder: " + PDF_TEMP);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("进入导出epm属性excel");

        NmOid primaryOid2 = nmCommandBean.getPrimaryOid();
        Object content = primaryOid2.getRef();
        HttpServletResponse response = nmCommandBean.getResponse();
        try {
            if (content instanceof EPMDocument) {
                EPMDocument FatherEPM = (EPMDocument) content;
                //去掉.和之后
                String fileName = EPMUtils.removeExtension(FatherEPM.getCADName());
                String epmName = FatherEPM.getName();
                //导出的文件名
                excelName = fileName+"_"+epmName+".xlsx";
                System.out.println("excel名"+excelName);
                //导出的excel包含父项 父项2d , 子项  子项2d   且状态为 设计，原型
                LinkedHashSet<EPMDocument> allEPM = allDPStateEPMByFEPM(FatherEPM);

                if (allEPM.isEmpty()){
                    throw new WTException("当前部件及其子项状态不为“设计”、“原型”。只有状态为“设计”、“原型”允许导出");
                }

//                allEPM.add(Fatherepm);//添加父EPM
//                allEPM.addAll(getAllChildByEpm(Fatherepm));//添加子项EPM

                List<EpmVO> epmVOS = new ArrayList<>();
                for (EPMDocument epmDocument : allEPM) {
                    IBAUtil ibaUtil = new IBAUtil(epmDocument);
                    String oldFilename = epmDocument.getCADName();//旧文件名
                    String filename = epmDocument.getCADName();//文件名
                    String name = epmDocument.getName();
                    String itemNumber = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("ext.alphai.ccode"));
                    String material = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("ext.alphai.camt"));
                    EpmVO epmVO = new EpmVO(oldFilename,filename, name, itemNumber, material);

                    epmVOS.add(epmVO);
                }

                //本地路劲获取模板
                String excelFilePath = PropertiesUtil.getValueByKey("ext.alphai.excelModel"); // 本地Excel文件的路径
                //获取模板
                FileInputStream is = new FileInputStream(excelFilePath);
                Workbook workbook = WorkbookFactory.create(is);
                workbook = ReadExcel.writeToExcel(workbook, epmVOS);

                //保存到临时目录
                saveExcelToTempFolder(workbook);

                response.reset();
                // 将Excel文件写入响应流
                response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//                response.setHeader("Content-Disposition", "attachment; filename=\"" + excelName + "\"");
                response.setHeader("Content-Disposition", "attachment; filename=\"" +
                        URLEncoder.encode(excelName, "UTF-8") + "\"");
                response.setCharacterEncoding("UTF-8");
                //从临时文件导出
                writeExcelToResponse(response);

                workbook.close();
                response.flushBuffer();
            }

        } catch (InvalidFormatException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return super.doOperation(nmCommandBean, list);
    }

    private void saveExcelToTempFolder(Workbook workbook) throws IOException {
        File file = new File(PDF_TEMP + File.separator + excelName);
        try (OutputStream outputStream = new FileOutputStream(file)) {
            workbook.write(outputStream);
        }
    }


    private void writeExcelToResponse(HttpServletResponse response) throws IOException {
        File file = new File(PDF_TEMP + File.separator + excelName);
        FileInputStream fileInputStream = new FileInputStream(file);
        OutputStream outputStream = response.getOutputStream();
        try {
            byte[] buffer = new byte[4096];
            int bytesRead = -1;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } finally {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            // 删除临时文件
            file.delete();
        }
    }

    //获取全部epm设计和原型状态结构树  包含2d    prototype  design   且  2d部件去重
    public static LinkedHashSet<EPMDocument>  allDPStateEPMByFEPM(EPMDocument fatherEPM) throws WTException {

        //由于2d图关联多个3d  需要去重

        //获取全部的epm结构树  包含2d
        ArrayList<EPMDocument> allEPM = new ArrayList<>();
        allEPM.add(fatherEPM);
        //获取父部件2d部件
        List<EPMDocument> epm2dBy3D = EPMUtils.get2DBy3D(fatherEPM);
        if (!epm2dBy3D.isEmpty()) {
            allEPM.addAll(epm2dBy3D);
        }

        //获取asm结尾的子项
        for (EPMDocument childEPM :  EPMUtils.getAllChildByEpm(fatherEPM)) {
            allEPM.add(childEPM);
            //插入子项的2d图纸
            if (!EPMUtils.get2DBy3D(childEPM).isEmpty()) {
                allEPM.addAll(EPMUtils.get2DBy3D(childEPM));
            }
        }


        //全部设计  原型状态的epm  并且去重
        LinkedHashSet<EPMDocument> allDPStateEPM = new LinkedHashSet<>();
        //校验状态
        for (EPMDocument epmDocument : allEPM) {
            String state = epmDocument.getLifeCycleState().toString();
            if (EXPORT_EPM_STATE_LIST.contains(state)){
                allDPStateEPM.add(epmDocument);
            }
        }

        return allDPStateEPM;

    }





}
