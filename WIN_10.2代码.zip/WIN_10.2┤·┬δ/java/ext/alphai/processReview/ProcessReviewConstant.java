package ext.alphai.processReview;
public class ProcessReviewConstant {

    // ECR部门评估变量
    public static final String ECRProductDev = "ECRProductDev"; // 产品
    public static final String ECRApplicationDep = "ECRApplicationDep"; // 应用
    public static final String ECRProcurementDep = "ECRProcurementDep"; //采购部
    public static final String ECRProcessDep = "ECRProcessDep"; // //工艺部
    public static final String ECRQualityDep = "ECRQualityDep"; // //质量部
    public static final String ECRProduceDep = "ECRProduceDep"; // //生产部
    public static final String ECRProjectDep = "ECRProjectDep"; // 项目部

    // DCR部门评估变量
    public static final String DCRProductDev = "DCRProductDev"; // 产品
    public static final String DCRApplicationDep = "DCRApplicationDep"; // 应用
    public static final String DCRProcurementDep = "DCRProcurementDep"; //采购部
    public static final String DCRProjectDep = "DCRProjectDep"; // 项目部



}
