package ext.alphai.processReview.utils;

import wt.change2.VersionableChangeItem;
import wt.enterprise.RevisionControlled;
import wt.fc.*;
import wt.maturity.PromotionNotice;
import wt.method.RemoteAccess;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.workflow.engine.*;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

/**
 * 操作流程变量的util
 */
public class WorkflowUtil implements RemoteAccess {

//    /**
//     * 设置流程变量
//     * @param tableType 流程变量名
//     * @param changeRequest2 当前变更请求
//     * @param json 表单数据的json格式
//     */
//    public static void setFlowVariable(String tableType, WTObject obj  , String json) throws WTException {
//
////        WfProcess process = null;
////        WfActivity activity = (WfActivity) work.getSource().getObject();
////        WfContainer wfcont = (WfContainer) activity.getParentProcessRef().getObject();
////
////        if (wfcont instanceof WfBlock) {
////            process = null;
////        }
////        process = (WfProcess) wfcont;
//
//        WfProcess process = getProcess(obj);
//
//
//        WfExecutionObject wfExecutionObject = (WfExecutionObject)PersistenceHelper.manager.refresh(process);
//
//        ProcessData data = wfExecutionObject.getContext();
//        data.setValue(tableType, json);
//
//        System.out.println("设置流程变量当前变量为=="+tableType+"json值是=="+json);
//    }


    /**
     * 通过任务获取流程实例
     *
     * @param wi
     * @return
     */
    public static WfProcess getProcess(WorkItem wi) {
        WfProcess process = null;
        WfActivity activity = (WfActivity) wi.getSource().getObject();
        WfContainer wfcont = (WfContainer) activity.getParentProcessRef().getObject();

        if (wfcont instanceof WfBlock) {
            process = null;
        }
        process = (WfProcess) wfcont;
        return process;
    }


    /**
     * 保存任务变量变量  写成事务   修改会导致并发更新问题
     *
     * @param self
     * @param key
     * @param value
     * @throws WTException
     */
    public static void setWorkItemValue(WorkItem self, String key, Object value) throws WTException {
        Transaction trx = new Transaction();
        try {
            trx.start();
            //获取任务的上下文
            WfActivity activity = (WfActivity) self.getSource().getObject();//转为WfActivity
            ProcessData context = activity.getContext();

            //设置
            WfVariable[] variableList = context.getVariableList();
            for (WfVariable wfVariable : variableList) {
                if (wfVariable.getName().equals(key)) {
                    wfVariable.setValue(value);
                }
            }

            context.setVariables(variableList);
            //获取最新的activity
            activity = (WfActivity)PersistenceHelper.manager.refresh(activity);
            activity.setContext(context);

            PersistenceHelper.manager.modify(activity);
            PersistenceHelper.manager.refresh(activity);


            String newValue =(String) context.getValue(key);
            System.out.println("打印修改后的数据："+newValue);


            trx.commit();
            trx=null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        }finally {
            if (trx != null) {
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }

    }


    /**
     * 保存流程变量
     *
     * @param self
     * @param key
     * @param value
     * @throws WTException
     */
    public static void setProcessValue(WorkItem self, String key, Object value) throws WTException {
        try {
            WfProcess process = getProcess(self);
            WfExecutionObject wfObject = (WfExecutionObject) PersistenceHelper.manager.refresh(process);
            ProcessData data = wfObject.getContext();
            data.setValue(key, value);
            PersistenceHelper.manager.modify(wfObject);
            PersistenceHelper.manager.refresh(wfObject);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        }

    }


    /***
     * 获取流程中所有变量
     *
     * @description @param ObjectReference @param
     *              primaryBusinessObject @return @throws
     */
    public static String getReview(WfProcess wfprocess , String key) {
        try {
            String reviewer = (String)wfprocess.getContext().getValue(key);
            System.out.println("Reviewer info:" + reviewer);
            return reviewer != null ? reviewer: "{}";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }





    /**
     * 通过workitem获取pbo
     *
     * @param workItem
     * @return pbo
     */
    public static WTObject getPBOByWorkItem(WorkItem workItem) {
        WTObject pbo = null;
        boolean origEnforce = false;
        try {
            origEnforce = SessionServerHelper.manager.setAccessEnforced(false);
            pbo = (WTObject) workItem.getPrimaryBusinessObject().getObject();
        } catch (NullPointerException nex) {
            pbo = null;
        } finally {
            SessionServerHelper.manager.setAccessEnforced(origEnforce);
        }
        return pbo;
    }





    /**
     * 根据评审对象（PBO）获取WfProcess对象
     *
     * @param obj
     * @return WfProcess
     */
    @SuppressWarnings("deprecation")
    public static WfProcess getProcessByPbo(WTObject obj) {
        WfProcess process = null;
        try {
            String pboId = "";
            if (obj instanceof VersionableChangeItem) {
                pboId = "VR:" + obj.getClass().getName() + ":"
                        + ((VersionableChangeItem) obj).getIterationInfo().getBranchId();
            } else if (obj instanceof RevisionControlled) {
                pboId = "VR:" + obj.getClass().getName() + ":"
                        + ((RevisionControlled) obj).getIterationInfo().getBranchId();
            } else if (obj instanceof PromotionNotice) {
                PromotionNotice pn = (PromotionNotice) obj;
                pboId = "OR:" + obj.getClass().getName() + ":" + pn.getPersistInfo().getObjectIdentifier().getId();
            }

            else {
                return null;
            }
            QuerySpec qs = new QuerySpec(WfProcess.class);
            qs.appendWhere(new SearchCondition(WfProcess.class, WfProcess.BUSINESS_OBJ_REFERENCE, SearchCondition.EQUAL,
                    pboId));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            while (qr != null && qr.hasMoreElements()) {
                WfProcess tmpProcess = (WfProcess) qr.nextElement();
                if (process == null) {
                    process = tmpProcess;
                } else {
                    if (tmpProcess.getStartTime().after(process.getStartTime())) {
                        process = tmpProcess;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return process;
    }
}
