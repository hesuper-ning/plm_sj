package ext.alphai.processReview.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import ext.alphai.processReview.ProcessReviewConstant;
import ext.alphai.processReview.controller.vo.AssessmentVo;
import ext.alphai.processReview.utils.PersistenceUtil;
import ext.alphai.processReview.utils.WorkflowUtil;
import org.apache.commons.lang3.StringUtils;
import wt.fc.PersistenceHelper;
import wt.util.WTException;
import wt.workflow.engine.ProcessData;
import wt.workflow.engine.WfActivity;
import wt.workflow.engine.WfExecutionObject;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WorkItem;

import java.util.*;

public class CommonService {



    /**
     * 将流程变量的json转为list对象
     *
     * @param departmentVar 流程变量值json
     * @return
     */
    public static List<AssessmentVo> getAssessmentList(String departmentVar) {

        List<AssessmentVo> assessments = new ArrayList<>();// 应用
        if (!StringUtils.isEmpty(departmentVar)) {
            ObjectMapper objectMapper = new ObjectMapper();
            //转为Java对象
            try{
            assessments = objectMapper.readValue(departmentVar, new TypeReference<List<AssessmentVo>>() {});
            } catch (JsonProcessingException e) {
                e.printStackTrace(); // 或者其他错误处理逻辑
            }

            for (AssessmentVo assessment : assessments) {
                System.out.println("项为：" + assessment.getAssessmentItems());
            }

        }
        return assessments;
    }
    /**
     *  获取任务变量   注意workItem获取getContext是null  需要转为WfActivity 再去获取getContext
     * @param workflowVarName
     * @param workItemOid
     * @return
     * @throws WTException
     */
    public static String getWorkItemVarByWorkItemOID(String workflowVarName ,  String workItemOid) throws WTException {
        WorkItem workItem =(WorkItem) PersistenceUtil.oid2Object(workItemOid);
        WfActivity activity = (WfActivity) workItem.getSource().getObject();//转为WfActivity

        ProcessData data = activity.getContext();
        String value =(String) data.getValue(workflowVarName);

        System.out.println("打印从任务变量"+workflowVarName+"中得到"+value);

        return value;
    }


    /**
     *  获取流程变量
     * @param WorkflowVarName
     * @param workItemOid
     * @return
     * @throws WTException
     */
    public static String getFlowVarByWorkItemOID(String WorkflowVarName ,  String workItemOid) throws WTException {
        WorkItem workItem =(WorkItem) PersistenceUtil.oid2Object(workItemOid);
        WfProcess process = WorkflowUtil.getProcess(workItem);
        WfExecutionObject wfExecutionObject = (WfExecutionObject) PersistenceHelper.manager.refresh(process);
        ProcessData data = wfExecutionObject.getContext();
        return (String) data.getValue(WorkflowVarName);

    }

    /**
     * 生成流程变量所有部门变量集合
     * @param templateType  ECR/DCR
     * @return
     */
    public static  ArrayList<String> getDepList(String templateType){

        ArrayList<String> deps = new ArrayList<>();

        switch (templateType){
            case "ECR":
                deps.add(0, ProcessReviewConstant.ECRProductDev);// 生产开发
                deps.add(1, ProcessReviewConstant.ECRApplicationDep);// 应用
                deps.add(2, ProcessReviewConstant.ECRProcurementDep);// 采购
                deps.add(3, ProcessReviewConstant.ECRProcessDep);// 项目
                deps.add(4, ProcessReviewConstant.ECRQualityDep);//质量部
                deps.add(5, ProcessReviewConstant.ECRProduceDep);//生产部
                deps.add(6, ProcessReviewConstant.ECRProjectDep);// 项目
                break;
            case "DCR":
                deps.add(0, ProcessReviewConstant.DCRProductDev);// 生产开发
                deps.add(1, ProcessReviewConstant.DCRApplicationDep);// 应用
                deps.add(2, ProcessReviewConstant.DCRProcurementDep);// 采购
                deps.add(3, ProcessReviewConstant.DCRProjectDep);// 项目
                break;
        }
        return deps;

    }

    /**
     * 获取所有任务变量评估表---获取流程变量中的
     * @param oid
     * @return
     */
    public static Map<String, List<AssessmentVo>> getAssessmentMapByOid( String oid , List<String> deps) throws WTException {
        Map<String, List<AssessmentVo>> assessmentMap = new LinkedHashMap<>();
        //获取所有部门变量名
        for (String depName : deps) {
            String depAssessmentJson = CommonService.getFlowVarByWorkItemOID(depName, oid); //  获取到对应的流程变量
            List<AssessmentVo> assessmentList = CommonService.getAssessmentList(depAssessmentJson);  //将对应的任务变量json转为list
            // list存储到map中 key为任务变量名
            assessmentMap.put(depName,assessmentList);//
        }
        return assessmentMap;
    }

    /**
     *
     * @param templateType   ECR/DCR
     * @param VarName        对应流程变量名生生对应的展示表题
     * @return
     */
    public static String getTitleByVarName(String templateType,String VarName){
        String title = "";
        if ("ECR".equals(templateType)){
            switch (VarName) {
                case  ProcessReviewConstant.ECRProductDev:
                    title = "2.1产品开发部评审";
                    break;

                case ProcessReviewConstant.ECRApplicationDep:
                    title = "2.2应用部评审";
                    break;

                case ProcessReviewConstant.ECRProcurementDep:
                    title = "2.3采购中心评审";
                    break;

                case ProcessReviewConstant.ECRProcessDep:
                    title = "2.5工艺部评审";
                    break;

                case ProcessReviewConstant.ECRQualityDep:
                    title = "2.6生产部评审";
                    break;

                case ProcessReviewConstant.ECRProduceDep:
                    title = "2.7应用部评审";
                    break;

                case ProcessReviewConstant.ECRProjectDep:
                    title = "2.8项目部评审";
                    break;
            }
        }

        if ("DCR".equals(templateType)){
            switch (VarName) {
                case ProcessReviewConstant.DCRProjectDep:
                    title = "2.8项目部评审";
                    break;
                case ProcessReviewConstant.DCRProductDev:
                    title = "2.1产品开发部评审";
                    break;
                case ProcessReviewConstant.DCRProcurementDep:
                    title = "2.4采购中心评审";
                    break;
                case ProcessReviewConstant.DCRApplicationDep:
                    title = "2.2应用部评审";
                    break;
            }
        }
        return title;
    }

    /**
     * 获取对应部门的评估表
     * @param oid
     * @param deps   节点中对应的任务变量名（各个部门节点单独定义的）
     * @return
     * @throws WTException
     */
    public static List<AssessmentVo>  getAssessmentListByOidAndVarName(String oid, String deps) throws WTException {
        List<AssessmentVo> assessments = new ArrayList<>();
        String depAssessmentJson = CommonService.getWorkItemVarByWorkItemOID(deps, oid);
        if (!StringUtils.isEmpty(depAssessmentJson)) {
            assessments =  CommonService.getAssessmentList(depAssessmentJson);
        }
        return assessments;
    }


}
