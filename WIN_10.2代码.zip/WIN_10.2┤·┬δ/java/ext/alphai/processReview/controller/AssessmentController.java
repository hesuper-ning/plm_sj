package ext.alphai.processReview.controller;
import ext.alphai.processReview.ProcessReviewConstant;
import ext.alphai.processReview.controller.vo.AssessmentVo;
import ext.alphai.processReview.controller.vo.DCRData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import ext.alphai.processReview.controller.vo.ECRData;
import ext.alphai.processReview.utils.PersistenceUtil;
import ext.alphai.processReview.utils.WorkflowUtil;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.util.WTException;
import wt.workflow.work.WorkItem;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping({ "/alphai" })
public class AssessmentController {
    public static ObjectMapper objectMapper = new ObjectMapper();


    @RequestMapping(value = "/DCR/assessmentTable", method = RequestMethod.POST)
    public void ecrAssessmentTable(@RequestBody String json, HttpServletRequest request, HttpServletResponse response) throws IOException, WTException {
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        // 读取请求体中的JSON数据
        System.out.println(">---进入DCR任务表单填写接口---<：" + json);
        DCRData dcrData = objectMapper.readValue(json, DCRData.class);


        List<AssessmentVo> dcrProductDev = dcrData.getDCRProductDev();
        List<AssessmentVo> dcrApplicationDep = dcrData.getDCRApplicationDep();
        List<AssessmentVo> dcrProcurementDep = dcrData.getDCRProcurementDep();
        List<AssessmentVo> dcrProjectDep = dcrData.getDCRProjectDep();


        //获取流程中的工作对象
        String oid = dcrData.getOid();
        WorkItem workItem =(WorkItem) PersistenceUtil.oid2Object(oid);


        // 进行存储操作
        if (dcrProductDev.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.DCRProductDev,workItem,dcrProductDev);
        }
        if (dcrApplicationDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.DCRApplicationDep,workItem,dcrApplicationDep);
        }
        if (dcrProcurementDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.DCRProcurementDep,workItem,dcrProcurementDep);
        }
        if (dcrProjectDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.DCRProjectDep,workItem, dcrProjectDep);
        }

    }

    @RequestMapping(value = "/ECR/assessmentTable", method = RequestMethod.POST)
    public void dcrAssessmentTable(@RequestBody String json, HttpServletRequest request, HttpServletResponse response) throws IOException, WTException {
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        // 读取请求体中的JSON数据
        System.out.println(">---进入ECR任务表单填写接口---<：" + json);
        ECRData ecrData = objectMapper.readValue(json, ECRData.class);

        List<AssessmentVo> ecrProductDev = ecrData.getECRProductDev();// 产品开发部
        List<AssessmentVo> ecrApplicationDep = ecrData.getECRApplicationDep();
        List<AssessmentVo> ecrProcurementDep = ecrData.getECRProcurementDep();
        List<AssessmentVo> ecrCraftDep = ecrData.getECRProcessDep();
        List<AssessmentVo> ecrProjectDep = ecrData.getECRProjectDep();
        List<AssessmentVo> ecrQualityDep = ecrData.getECRQualityDep();
        List<AssessmentVo> ecrProduceDep = ecrData.getECRProduceDep();


        //获取流程中的工作对象
        String oid = ecrData.getOid();
        WorkItem workItem =(WorkItem) PersistenceUtil.oid2Object(oid);


        // 进行存储操作
        if (ecrProductDev.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.ECRProductDev,workItem,ecrProductDev);
        }
        if (ecrApplicationDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.ECRApplicationDep,workItem,ecrApplicationDep);
        }
        if (ecrProcurementDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.ECRProcurementDep,workItem,ecrProcurementDep);
        }
        if (ecrCraftDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.ECRProcessDep,workItem,ecrCraftDep);
        }
        if (ecrProjectDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.ECRProjectDep,workItem,ecrProjectDep);
        }
        if (ecrQualityDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.ECRQualityDep,workItem,ecrQualityDep);
        }
        if (ecrProduceDep.size() > 0 ) {
            setFlowValue(ProcessReviewConstant.ECRProduceDep,workItem,ecrProduceDep);
        }


    }


    /**
     *   将前端评估表json存储对应部门任务变量中
     * @param depVarName  任务变量名（各部门单独定义）
     * @param work
     * @param table
     * @throws WTException
     */
    public static void  setFlowValue(  String  depVarName , WorkItem work,List<AssessmentVo> table) throws WTException {
        // 处理或存储
        try {
            String tableJson = objectMapper.writeValueAsString(table);
            WorkflowUtil.setWorkItemValue(work,depVarName,tableJson);
        } catch (JsonProcessingException e) {
            e.printStackTrace(); // 或者其他错误处理逻辑
        }

    }





}
