package ext.alphai.processReview.controller.vo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
public class AssessmentVo {
    @JsonProperty("assessmentItems")
    private String assessmentItems;//评估项
    @JsonProperty("yesOrNo")
    private String yesOrNo;//是否
    @JsonProperty("comments")
    private String comments;//评审意见

    @JsonProperty("commentsPla")
    private String commentsPla;//评审意见提示

    @JsonProperty("fileOrSupport")
    private String fileOrSupport;//文件或记录支持

    @JsonProperty("fileOrSupportPla")
    private String fileOrSupportPla;//文件或记录支持提示

    public String getAssessmentItems() {
        return assessmentItems;
    }

    public void setAssessmentItems(String assessmentItems) {
        this.assessmentItems = assessmentItems;
    }

    public String getYesOrNo() {
        return yesOrNo;
    }

    public void setYesOrNo(String yesOrNo) {
        this.yesOrNo = yesOrNo;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getCommentsPla() {
        return commentsPla;
    }

    public void setCommentsPla(String commentsPla) {
        this.commentsPla = commentsPla;
    }

    public String getFileOrSupport() {
        return fileOrSupport;
    }

    public void setFileOrSupport(String fileOrSupport) {
        this.fileOrSupport = fileOrSupport;
    }

    public String getFileOrSupportPla() {
        return fileOrSupportPla;
    }

    public void setFileOrSupportPla(String fileOrSupportPla) {
        this.fileOrSupportPla = fileOrSupportPla;
    }
}
