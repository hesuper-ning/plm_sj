package ext.alphai.processReview.controller.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import ext.alphai.processReview.ProcessReviewConstant;

import java.util.List;

public class ECRData {
    private String oid;
    @JsonProperty(ProcessReviewConstant.ECRProductDev)
    private List<AssessmentVo> ECRProductDev;  //产品开发

    @JsonProperty(ProcessReviewConstant.ECRApplicationDep)
    private List<AssessmentVo> ECRApplicationDep; //应用部

    @JsonProperty(ProcessReviewConstant.ECRProcurementDep)
    private List<AssessmentVo> ECRProcurementDep; //采购部

    @JsonProperty(ProcessReviewConstant.ECRProcessDep)
    private List<AssessmentVo> ECRProcessDep; //工艺部

    @JsonProperty(ProcessReviewConstant.ECRProduceDep)
    private List<AssessmentVo> ECRProduceDep; //生产部

    @JsonProperty(ProcessReviewConstant.ECRQualityDep)
    private List<AssessmentVo> ECRQualityDep; //质量部

    @JsonProperty(ProcessReviewConstant.ECRProjectDep)
    private List<AssessmentVo> ECRProjectDep; //项目部

    public List<AssessmentVo> getECRProcessDep() {
        return ECRProcessDep;
    }

    public void setECRProcessDep(List<AssessmentVo> ECRProcessDep) {
        this.ECRProcessDep = ECRProcessDep;
    }

    public List<AssessmentVo> getECRProjectDep() {
        return ECRProjectDep;
    }

    public void setECRProjectDep(List<AssessmentVo> ECRProjectDep) {
        this.ECRProjectDep = ECRProjectDep;
    }

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public List<AssessmentVo> getECRProductDev() {
        return ECRProductDev;
    }

    public void setECRProductDev(List<AssessmentVo> ECRProductDev) {
        this.ECRProductDev = ECRProductDev;
    }

    public List<AssessmentVo> getECRApplicationDep() {
        return ECRApplicationDep;
    }

    public void setECRApplicationDep(List<AssessmentVo> ECRApplicationDep) {
        this.ECRApplicationDep = ECRApplicationDep;
    }

    public List<AssessmentVo> getECRProcurementDep() {
        return ECRProcurementDep;
    }

    public void setECRProcurementDep(List<AssessmentVo> ECRProcurementDep) {
        this.ECRProcurementDep = ECRProcurementDep;
    }

    public List<AssessmentVo> getECRProduceDep() {
        return ECRProduceDep;
    }

    public void setECRProduceDep(List<AssessmentVo> ECRProduceDep) {
        this.ECRProduceDep = ECRProduceDep;
    }

    public List<AssessmentVo> getECRQualityDep() {
        return ECRQualityDep;
    }

    public void setECRQualityDep(List<AssessmentVo> ECRQualityDep) {
        this.ECRQualityDep = ECRQualityDep;
    }


}
