package ext.alphai.processReview.controller.vo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import ext.alphai.processReview.ProcessReviewConstant;

public class DCRData {
    private String oid;
    @JsonProperty(ProcessReviewConstant.DCRProductDev)
    private List<AssessmentVo> DCRProductDev;//产品
    @JsonProperty(ProcessReviewConstant.DCRApplicationDep)
    private List<AssessmentVo> DCRApplicationDep;//应用
    @JsonProperty(ProcessReviewConstant.DCRProcurementDep)
    private List<AssessmentVo> DCRProcurementDep;//采购
    @JsonProperty(ProcessReviewConstant.DCRProjectDep)
    private List<AssessmentVo> DCRProjectDep;//项目

    public List<AssessmentVo> getDCRProjectDep() {
        return DCRProjectDep;
    }

    public void setDCRProjectDep(List<AssessmentVo> DCRProjectDep) {
        this.DCRProjectDep = DCRProjectDep;
    }

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public List<AssessmentVo> getDCRProductDev() {
        return DCRProductDev;
    }

    public void setDCRProductDev(List<AssessmentVo> DCRProductDev) {
        this.DCRProductDev = DCRProductDev;
    }

    public List<AssessmentVo> getDCRApplicationDep() {
        return DCRApplicationDep;
    }

    public void setDCRApplicationDep(List<AssessmentVo> DCRApplicationDep) {
        this.DCRApplicationDep = DCRApplicationDep;
    }

    public List<AssessmentVo> getDCRProcurementDep() {
        return DCRProcurementDep;
    }

    public void setDCRProcurementDep(List<AssessmentVo> DCRProcurementDep) {
        this.DCRProcurementDep = DCRProcurementDep;
    }


}
