package ext.alphai.partAttributeChange.builder;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.partAttributeChange.ChangeAttributeRB;
import ext.alphai.partAttributeChange.ChangePartAttribute;
import ext.alphai.partAttributeChange.service.UpdateAttributeService;
import ext.alphai.partAttributeChange.utils.PersistenceUtil;
import wt.change2.WTChangeOrder2;
import wt.util.WTException;
import wt.util.WTMessage;

import java.util.List;


@ComponentBuilder("ext.alphai.partAttributeChange.builder.UpdateAttributeTable")
public class UpdateAttributeTable extends AbstractComponentBuilder {
    static final String RESOURCE = ChangeAttributeRB.class.getName();

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
        final ComponentConfigFactory factory = getComponentConfigFactory();
        final TableConfig table;{
            table = factory.newTableConfig();
            table.setType(ChangePartAttribute.class.getName());
            table.setLabel(WTMessage.getLocalizedMessage(RESOURCE, ChangeAttributeRB.CHANGE_CONTENT,null));
            table.setSelectable(true);
            table.setConfigurable(false);
            table.setShowCount(true);
            table.setShowCustomViewLink(true);

            table.setActionModel("changePartAttribute");
            //报表最前面圆圈
            ColumnConfig oidColumn = factory.newColumnConfig("oid", true);
            table.addComponent(oidColumn);
            oidColumn.setHidden(true);
            oidColumn.setSortable(true);

            ColumnConfig parentNum = factory.newColumnConfig("partNumber", "部件编号",true);
            parentNum.setDataUtilityId("ChangeAttribute_Utility");
            table.addComponent(parentNum);

            ColumnConfig partName = factory.newColumnConfig("partName", "部件名称",true);
            partName.setDataUtilityId("ChangeAttribute_Utility");
            table.addComponent(partName);

            ColumnConfig updateAttributeClassify = factory.newColumnConfig("attributeClassify", "分类",true);
            updateAttributeClassify.setDataUtilityId("ChangeAttribute_Utility");
            table.addComponent(updateAttributeClassify);


            ColumnConfig itemDesc = factory.newColumnConfig("itemDesc", "物料描述",true);
            itemDesc.setDataUtilityId("ChangeAttribute_Utility");
            table.addComponent(itemDesc);

            ColumnConfig specificationsModel = factory.newColumnConfig("specificationsModel", "规格型号",true);
            specificationsModel.setDataUtilityId("ChangeAttribute_Utility");
            table.addComponent(specificationsModel);


            ColumnConfig detail = factory.newColumnConfig("option", "操作",true);
            detail.setDataUtilityId("ChangeAttribute_Utility");
            table.addComponent(detail);
        }

        return table;
    }


    @Override
    public Object buildComponentData(ComponentConfig arg0, ComponentParams params) throws Exception {
        JcaComponentParams jca_params = (JcaComponentParams) params;
        NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
        NmOid primaryOid2 = cb.getPrimaryOid();
        WTChangeOrder2 change = null;
        if (primaryOid2 == null)
            return null;
        Object content = primaryOid2.getRef();
        if (content instanceof WTChangeOrder2) {
            change = (WTChangeOrder2) content;
        }
        //根据Change对象获取OID  查询到指定的修改属性内容
        String changeOID = PersistenceUtil.object2Oid(change);
        List<ChangePartAttribute> changePartAttributeByChangeOid = UpdateAttributeService.getChangePartAttributeByChangeOid(changeOID);

        for (ChangePartAttribute changePartAttribute : changePartAttributeByChangeOid) {
            System.out.println(changePartAttribute.getWTChangeORDER2OR());
        }

        return changePartAttributeByChangeOid;
    }





}
