package ext.alphai.partAttributeChange.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContext;
import ext.alphai.partAttributeChange.ChangePartAttribute;
import ext.alphai.partAttributeChange.utils.ChangeOrder2Util;
import wt.change2.WTChangeOrder2;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;

public class DeleItemProcessor extends DefaultObjectFormProcessor {
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> paramList) throws WTException {
        NmOid primaryOid = nmCommandBean.getPrimaryOid();
        WTChangeOrder2 changeOrder2 = (WTChangeOrder2)primaryOid.getRef();

        //只有编制，修改节点才可以删除
        String emsg = ChangeOrder2Util.checkOperationInLegalNode(changeOrder2, ChangeOrder2Util.PERMISSION_NODE);
        if(emsg !=null){
            throw new WTException(emsg);
        }

        ArrayList<NmContext> selected = nmCommandBean.getSelected();
        for (NmContext context : selected) {
            NmOid nmOid = context.getTargetOid();
            Object object = nmOid.getRef();
            if (object instanceof ChangePartAttribute)
                PersistenceHelper.manager.delete((Persistable)object);
        }
        return null;
    }
}
