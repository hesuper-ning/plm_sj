package ext.alphai.partAttributeChange.datatutility;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.PushButton;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import ext.alphai.partAttributeChange.ChangePartAttribute;
import ext.alphai.partAttributeChange.service.UpdateAttributeService;
import ext.alphai.partAttributeChange.utils.IBAUtil;
import ext.alphai.partAttributeChange.utils.PersistenceUtil;
import ext.alphai.wf.util.PropertiesUtil;
import wt.part.WTPart;
import wt.util.WTException;

import java.awt.*;
import java.io.IOException;


public class ChangeAttributeUtility extends AbstractDataUtility {
    // 规格型号内部值
    public static final String SpecificationsModel = "SpecificationsModel";
    //物料描述
    public static final String ItemDesc = "ItemDesc";

    public ChangeAttributeUtility() {
    }

    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        ChangePartAttribute item=  (ChangePartAttribute)o;

        System.out.println("进入dataUtilty");
        //获取IDA2A2  可能是IBA2A2

        String itemOR = PersistenceUtil.object2Oid(item);
        System.out.println(itemOR);




        System.out.println("打印id"+item.getIdentity());
        //获取部件编号
        WTPart part =(WTPart) PersistenceUtil.oid2Object(item.getPartOID());

        System.out.println("部件为空》》》》"+part==null);

        //编号
        String partNumber = part.getNumber();
        //名字
        String partName = part.getName();


        //分类
        String updateAttributeClassify = item.getUpdateAttributeClassify();

        IBAUtil ibaUtil = new IBAUtil(part);
        //规格型号
        String specificationsModel = ibaUtil.getIBAValue(SpecificationsModel);

        //物料描述
        String itemDesc = ibaUtil.getIBAValue(ItemDesc);


        GUIComponentArray componentArray = new GUIComponentArray();

        PushButton showDetail = new PushButton("展示详细");
        showDetail.setButtonType(PushButton.ButtonType.BUTTON);
        showDetail.addJsAction("onclick","showDetail('"+itemOR+"','"+partNumber+"')");


        PushButton UpdateAttribute = new PushButton("修改");
        UpdateAttribute.setButtonType(PushButton.ButtonType.BUTTON);
        UpdateAttribute.addJsAction("onclick","updateAttribute('"+itemOR+"','"+partNumber+"')");

        componentArray.addGUIComponent(showDetail);
        componentArray.addGUIComponent(UpdateAttribute);


        switch (s) {
            case "partNumber":
                System.out.println("部件编号"+partNumber);
                UrlDisplayComponent partUrlByPartNumber = getPartUrlByPartNumber(part);
                //返回可点击的编号
                return partUrlByPartNumber;
            case "partName":
                System.out.println("部件名称"+partName);
                return partName;
            case "attributeClassify":
                System.out.println("分类"+updateAttributeClassify);
                return updateAttributeClassify;
            case "itemDesc":
                return itemDesc;
            case "specificationsModel":
                return specificationsModel;
            case "option":
                return componentArray;
        }
        return null;
    }



    /**
     * 传入一个父部件返回在table上可以点击的物料编号连接
     * @param part
     * @return
     * @throws WTException
     */
    public static UrlDisplayComponent getPartUrlByPartNumber(WTPart part) throws WTException {
        NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();

        urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);

        NmOid contentOid = NmOid.newNmOid(part.getPersistInfo().getObjectIdentifier());

        String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null, true);

        UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent("", part.getNumber(), link);
        return urlDisplayComponent;
    }
}
