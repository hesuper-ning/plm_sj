package ext.alphai.partAttributeChange.service;

import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import ext.alphai.partAttributeChange.ChangePartAttribute;

import ext.alphai.partAttributeChange.utils.*;
import ext.kingdeeERP.changeBOM.WTPartUsageLinkChangeItem; // 注意导了变更BOM的包
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import wt.change2.WTChangeOrder2;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypeDefinitionReference;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.wip.WorkInProgressHelper;

import java.io.*;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static wt.part._Source.toSource;

public class UpdateAttributeService {

    public static ObjectMapper objectMapper = new ObjectMapper();

    //获取的clsConstraint/utils/下配置文件
    public static final List<String> MBA_LIST = new ArrayList<>(Arrays.asList(PropertiesUtil.getValueByKey("MBA").split(",")));

    public static final String SUPPLY = "Suppliers";
    public static final String SUPPLIER_NUM = "SupplierNum";//供应商编码
    public static final String SUPPLIER_ACCT_NO = "SupplierAcctNo"; //供应商所属账套
    public static String SupplierAcctNo = "002";//账套固定为200


    public static String[] NO_CREATE_STATE_ECN_Name = {"开启", "正在审阅", "重新工作"};//账套固定为200

    public static List<String> NO_CREATE_STATE_ECN = new ArrayList<>(Arrays.asList(NO_CREATE_STATE_ECN_Name));
    private static String excelName;

    public static String PDF_TEMP = "";


    /**
     * 插入
     *
     * @param item
     */
    public static void insertOneChange(ChangePartAttribute item) {
        System.out.println("进入插入数据库方法当前插入的变更OR" + item.getWTChangeORDER2OR());
        try {
            PersistenceHelper.manager.save(item);
        } catch (WTException e) {
            e.getMessage();
        }
    }


    /**
     * 通过变更Oid获取变更内容
     *
     * @param oid
     * @return
     */
    public static List<ChangePartAttribute> getChangePartAttributeByChangeOid(String oid) {
        Vector<ChangePartAttribute> vector = null;
        try {
            QuerySpec qs = new QuerySpec(ChangePartAttribute.class);
            SearchCondition sc = new SearchCondition(ChangePartAttribute.class, ChangePartAttribute.WTCHANGE_ORDER2_OR, SearchCondition.EQUAL, oid);
            qs.appendWhere(sc);

            QueryResult qr = PersistenceHelper.manager.find(qs);
            vector = qr.getObjectVectorIfc().getVector();
            return vector;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vector;
    }

    public static List<ChangePartAttribute> getAllChangePartAttribute() {

        Vector<ChangePartAttribute> vector = null;
        QuerySpec qs = null;
        try {
            qs = new QuerySpec(ChangePartAttribute.class);
            QueryResult qr = PersistenceHelper.manager.find(qs);
            vector = qr.getObjectVectorIfc().getVector();
        } catch (QueryException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return vector;

    }


    /**
     * 解析json拼接字符串
     *
     * @param updateJson
     * @return
     * @throws IOException
     */
    public static String showUpdateData(String updateJson) throws IOException {
        StringBuffer result = new StringBuffer();


        JsonNode jsonNode = objectMapper.readTree(updateJson);

        //改前数据的内部名与值
        JsonNode oldData = jsonNode.path("displayAttribute");
        //改前数据的内部名与值
        JsonNode newData = jsonNode.path("updateAttribute");
        //展示的属性的内部值与显示值
        JsonNode showData = jsonNode.path("KeyAttributeRules");

        //枚举值
        //展示的属性的内部值与显示值
        JsonNode enum_Values = jsonNode.path("Enum_Values");

        // 遍历 KeyAttributeRules 并找到对应的属性值
        Iterator<String> fieldNames = showData.getFieldNames();
        while (fieldNames.hasNext()) {
            String fieldName = fieldNames.next();

            // 属性名 中文
            String displayValue = showData.path(fieldName).asText();

            //将改前无数据去掉
            String oldValue = "无".equals(oldData.path(fieldName).asText()) ? "" : oldData.path(fieldName).asText();
            oldValue = getDisplayValueByInName(fieldName, oldValue, enum_Values);

            String newValue = newData.path(fieldName).asText();
            newValue = getDisplayValueByInName(fieldName, newValue, enum_Values);

            String msg = displayValue + " 改前：" + oldValue + " 改后： " + newValue;

            result.append(msg).append("  ");
        }
        return result.toString();
    }

    public static String isExistPartInECN(String partNumber) {
        System.out.println("传入的部件比编号" + partNumber);
        StringBuffer sb = new StringBuffer();
        //获取变更属性所有内容
        List<ChangePartAttribute> allChangePartAttribute = getAllChangePartAttribute();

        for (ChangePartAttribute changePartAttribute : allChangePartAttribute) {
            //获取ecn
            String wtChangeORDER2OR = changePartAttribute.getWTChangeORDER2OR();
            WTChangeOrder2 changeOrder2 = (WTChangeOrder2) PersistenceUtil.oid2Object(wtChangeORDER2OR);

            String changeOrderState = changeOrder2.getLifeCycleState().getDisplay();
            String ecnNumber = changeOrder2.getNumber();
            System.out.println("数据库ECN状态" + changeOrderState);
            System.out.println("数据库ECN编号" + ecnNumber);

            //获取ecn下的编号
            String partOID = changePartAttribute.getPartOID();
            WTPart part = (WTPart) PersistenceUtil.oid2Object(partOID);
            String partNumberInECN = part.getNumber();
            System.out.println("数据库物料编号" + partNumberInECN);

            if (NO_CREATE_STATE_ECN.contains(changeOrderState) && partNumber.equals(partNumberInECN)) {
                //说明"开启","正在审阅","重新工作"的ECN下存在这个物料
                sb.append(changeOrderState + "状态的" + ecnNumber + "下存在物料" + partNumber);
            }
        }
        return sb.toString();

    }


    /**
     * 判断首是否枚举，且根据属性名的内部值，以及值的内部名名获取值的显示值
     *
     * @param interiorName 属性名的内部值
     * @param displayValue 值的内部名
     * @param enum_Values  枚举
     * @return
     */
    public static String getDisplayValueByInName(String interiorName, String displayValue, JsonNode enum_Values) {
        String result = displayValue; // 默认值


        if (!displayValue.isEmpty() && !"无".equals(displayValue)) {
            for (Iterator<String> fieldNames = enum_Values.getFieldNames(); fieldNames.hasNext(); ) {
                String fileName = fieldNames.next();
                String inName = removeString(fileName);
                if (inName.equals(interiorName)) {
                    String enumJson = enum_Values.path(fileName).asText();
                    try {
                        List<Map<String, String>> enumValue = objectMapper.readValue(enumJson, new TypeReference<List<Map<String, String>>>() {
                        });
                        for (Map<String, String> enumMap : enumValue) {
                            if (enumMap.containsKey(displayValue)) {
                                result = enumMap.get(displayValue);
                                break; // 如果找到匹配项，可以提前退出循环
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break; // 如果找到匹配项，可以提前退出循环
                }
            }
        }

        return result; // 返回最终的结果
    }


    /**
     * 移除json第一个_和之前的数据
     *
     * @param input
     * @return
     */
    public static String removeString(String input) {
        int underscoreIndex = input.indexOf('_');
        // 检查是否存在下划线
        if (underscoreIndex != -1) {
            // 获取下划线之后的部分
            String result = input.substring(underscoreIndex + 1);
            return result;
        } else {
            return input;
        }
    }


    //修改部件属性方法

    /**
     * 获取变更项中的BOM编号
     *
     * @param changeItems
     * @return
     */
    public static List<String> getBOMList(List<WTPartUsageLinkChangeItem> changeItems) {

        ArrayList<String> bomNumList = new ArrayList<>();
        if (changeItems.size() > 0) {
            for (WTPartUsageLinkChangeItem changeItem : changeItems) {
                String parentOID = changeItem.getParentOID();

                WTPart bom = (WTPart) PersistenceUtil.oid2Object(parentOID);

                bomNumList.add(bom.getNumber());
            }
        }


        return bomNumList;
    }

    /**
     * 修改属性，并且根据变更项BOM判断是否修订大版本
     *
     * @param bomList
     * @param updateAttributeJson
     * @return 返回最新版本的部件
     * @throws Exception
     */
    public static WTPart updateAttributeAndRevise(WTChangeOrder2 order2, List<String> bomList, String updateAttributeJson) throws Exception {

        JsonNode jsonNode = objectMapper.readTree(updateAttributeJson);


        //获取部件编号
        String number = jsonNode.path("number").asText();
        //修改的数据集
        JsonNode newData = jsonNode.path("updateAttribute");
        String updateData = jsonNode.path("updateAttribute").asText();

        System.out.println("打印修改的数据" + updateData);
        WTPart part = PartUtil.getWTPartByNumber(number);


        //判断修改属性的物料==BOM    不含有，修订大版本
        if (!bomList.contains(number)) {
            //修订的大版本
            part = PersistenceUtil.reviseWTPartByNumber(part);
        }
        //检出
        //是否检出
        if (!WorkInProgressHelper.isCheckedOut(part)) {//检入
            part = (WTPart) WorkInProgressHelper.service.checkout(part, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
        }
        //修改属性
        updateAttribute(newData, part);

        //检入  获取最新版本的part
        part = (WTPart) WorkInProgressHelper.service.checkin(part, "分类属性修改" + order2.getNumber() + "修改");
        return part;
    }

    /**
     * 修改部件分类属性（检出才能修改）
     *
     * @param newData
     * @param part_work
     */
    public static void updateAttribute(JsonNode newData, WTPart part_work) throws Exception {

        Iterator<String> typeInternalNames = newData.getFieldNames();
        while (typeInternalNames.hasNext()) {
            //内部值
            String typeInternalName = typeInternalNames.next();
            System.out.println("修改的属性内部名：" + typeInternalName);

            // 对应的值
            String value = newData.path(typeInternalName).asText();

            System.out.println("改前打印内部名" + typeInternalName + "对应的值：" + value);
            //IBA值
            if (PartUtil.isIBA(part_work, typeInternalName)) {
                IBAUtil ibaUtil = new IBAUtil(part_work);
                //MBA属性修改
                if (MBA_LIST.contains(typeInternalName)) {
                    System.out.println(typeInternalName + "--是MBA属性");
                    setMBA(part_work, typeInternalName, value);
                    continue;
                }
                //特殊值供应商的处理
                if (SUPPLY.equals(typeInternalName) && !StringUtils.isEmpty(typeInternalName)) {
                    //数据库获取编码
                    String SupplierNum = getSupplyCode(value);//更具供应商中文名查编码
                    System.out.println("获取到的供应商编码" + SupplierNum);
                    ibaUtil.setIBAAttribute4AllType(part_work, typeInternalName, value);
                    ibaUtil.setIBAAttribute4AllType(part_work, SUPPLIER_NUM, SupplierNum);  //供应商编码
                    ibaUtil.setIBAAttribute4AllType(part_work, SUPPLIER_ACCT_NO, SupplierAcctNo);  //修改账套  固定200
                    continue;
                }
                System.out.println(typeInternalName + "--是IBA属性");
                //修改
                ibaUtil.setIBAAttribute4AllType(part_work, typeInternalName, value);
            }
            //分类属性值
            else {
                PartUtil.setClsValue(part_work, typeInternalName, value);
            }
        }


    }


    /**
     * 获取
     *
     * @param changePartAttributes
     * @return
     * @throws WTException
     */
    public static String getCheckOutParts(List<ChangePartAttribute> changePartAttributes) throws IOException {
        StringBuffer sb = new StringBuffer();
        for (ChangePartAttribute changePartAttribute : changePartAttributes) {

            String updateAttributeJson = changePartAttribute.getUpdateAttributeJson();
            JsonNode jsonNode = objectMapper.readTree(updateAttributeJson);
            //获取部件编号
            String number = jsonNode.path("number").asText();


            WTPart part = PartUtil.getWTPartByNumber(number);

            try {
                //是否检出
                if (WorkInProgressHelper.isCheckedOut(part)) {
                    //整理 检出的部件编号
                    sb.append(part.getNumber()).append(" ");
                }
            } catch (WTException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public static void setMBA(WTPart part, String interName, String value) throws WTException {

        switch (interName) {
            case "name":
                //修改名称
                PartUtil.changePartName(part, value);
                break;
            case "source":
                //修改源
                part.setSource(toSource(value));
                PersistenceHelper.manager.save(part);
                break;
        }
    }


    // 流程修改部件状态方法

    /**
     * @param order2
     * @return String
     * @throws WTException
     * @description 得到对象的自定义/显示名称 如:com.ptc.ElectricalPart
     */
    public static String getTypeInternalName(WTChangeOrder2 order2) {
        String InternalName = null;
        TypeDefinitionReference ref = (order2).getTypeDefinitionReference();
        try {
            @SuppressWarnings("deprecation")
            TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities.getTypeDefinition(ref);
            WTTypeDefinition definition = (WTTypeDefinition) PersistenceHelper.manager.refresh(view.getObjectID());
            InternalName = definition.getName();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return InternalName;
    }


    /**
     * 批量修改部件状态
     *
     * @param changePartAttributeByChangeOid
     * @param state
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static void UpdatePartState(List<ChangePartAttribute> changePartAttributeByChangeOid, String state) throws WTException, WTPropertyVetoException, IOException {
        for (ChangePartAttribute changePartAttribute : changePartAttributeByChangeOid) {
            //有风险  用OR   检出再检入后会消失   还是用number直接找
//            String partOID = changePartAttribute.getPartOID();
//            WTPart part = (WTPart) PersistenceUtil.oid2Object(partOID);//获取的OR  不能获取最新版本   ，获取传入的版本
            //获取编号
            String partNumber = objectMapper.readTree(changePartAttribute.getUpdateAttributeJson()).path("number").asText();

            //获取最新版本的部件  (通过编号获取最新版本)
            WTPart part = PartUtil.getWTPartByNumber(partNumber);
            //修改状态
            PartUtil.changePartState(part, state);
        }
    }


    /*存到文件夹*/
    public static void saveJsonToFile(String jsonData, String folderPath, String fileName) throws IOException {
        String filePath = Paths.get(folderPath, fileName + ".json").toString();
        try (OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(filePath), "UTF-8")) {
            writer.write(jsonData);
        }
    }

    /*读取json*/
    public static String readJsonFromFile(String filePath) throws IOException {
        StringBuilder jsonData = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                jsonData.append(line);
            }
        }
        return jsonData.toString();
    }

    //查询供应商名称
    public static HashSet<String> getSupplyName(String searchName) {
        HashSet<String> result = new HashSet<>();
        if (!searchName.isEmpty()) {
            //Oracle的sql语句不要;
            String sql = "SELECT FNAME FROM PDM_ERP_SUPPLIER WHERE  FACCTNO = '002' and FDELETED = '0' and FNAME like CONCAT(CONCAT('%', ?), '%')";

//            String sql ="SELECT FNAME FROM PDM_ERP_SUPPLIER WHERE FACCTNO = '002' AND FDELETED = '0' AND FNAME LIKE '%' || ? || '%'";


            ResultSet resultSet = CommonUtil.excuteSelect(sql, searchName);
            try {
                while (resultSet.next()) {
                    String supplierName = resultSet.getString("FNAME");
                    result.add(supplierName);
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return result;
    }


    public static HashSet<String> getAllSupplyName() {
        HashSet<String> result = new HashSet<>();
        //Oracle的sql语句不要;
        String sql = "SELECT FNAME FROM PDM_ERP_SUPPLIER WHERE  FACCTNO = '002' and FDELETED = '0'";
        ResultSet resultSet = CommonUtil.excuteSelect(sql);
        try {
            while (resultSet.next()) {
                String supplierName = resultSet.getString("FNAME");
                result.add(supplierName);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }


    //查询供应商编号
    public static String getSupplyCode(String SupplyName) {
        String result = "";
        if (!SupplyName.isEmpty()) {
            String sql = "SELECT FNUMBER FROM PDM_ERP_SUPPLIER WHERE FACCTNO = '002' and FDELETED = '0' and FNAME=? ";


            ResultSet resultSet = CommonUtil.excuteSelect(sql, SupplyName);
            try {
                if (resultSet.next()) {
                    result = resultSet.getString("FNUMBER");
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return result;
    }

}
