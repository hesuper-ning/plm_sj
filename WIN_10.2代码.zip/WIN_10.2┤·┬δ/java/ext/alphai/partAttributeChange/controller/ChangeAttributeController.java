package ext.alphai.partAttributeChange.controller;
import ext.alphai.partAttributeChange.ChangePartAttribute;
import ext.alphai.partAttributeChange.controller.Vo.ResponseVo;
import ext.alphai.partAttributeChange.service.UpdateAttributeService;
import ext.alphai.partAttributeChange.utils.ChangeOrder2Util;
import ext.alphai.partAttributeChange.utils.PartUtil;
import ext.alphai.partAttributeChange.utils.PersistenceUtil;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import wt.change2.WTChangeOrder2;
import wt.fc.PersistenceHelper;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;

import static ext.alphai.partAttributeChange.utils.PersistenceUtil.object2Oid;

@Controller
@RequestMapping({ "/Change" })
public class ChangeAttributeController {

    // 创建 ObjectMapper 实例
    ObjectMapper objectMapper = new ObjectMapper();


    @RequestMapping(value = "/createAttribute", method = RequestMethod.POST)
    public void maintainSource(@RequestBody String sendJson, HttpServletRequest request,
                               HttpServletResponse response) throws IOException {
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("修改属性接口");
        System.out.println(sendJson);

        SessionServerHelper.manager.setAccessEnforced(false);

        String resultJson = "";

        //获取json中的数据
        JsonNode jsonNode = objectMapper.readTree(sendJson);

        // 提取 oid 字段 变更通告VR  ---转为OR存到数据库
        String oid = jsonNode.path("oid").asText();
        String number = jsonNode.path("number").asText();
        System.out.println(oid);
        WTChangeOrder2 changeOrder2 =(WTChangeOrder2) PersistenceUtil.oid2Object(oid);




        String existPartInECN = UpdateAttributeService.isExistPartInECN(number);
        System.out.println("校验ecn是否含有同一个物料："+existPartInECN);
        if (!StringUtils.isEmpty(existPartInECN)) {
            ResponseVo existPartInECNVo = new ResponseVo();
            existPartInECNVo.code="406";// "开启","正在审阅","重新工作"的ecn存在同一个物料
            existPartInECNVo.msg=existPartInECN;
            resultJson = objectMapper.writeValueAsString(existPartInECNVo);
            outResponse(response ,resultJson);
            SessionServerHelper.manager.setAccessEnforced(true);
            return ;
        }

        String emsg = ChangeOrder2Util.checkOperationInLegalNode(changeOrder2, ChangeOrder2Util.PERMISSION_NODE);
        if(emsg !=null){
            ResponseVo responseVo = new ResponseVo();
            responseVo.code="405";
            responseVo.msg=emsg;
            resultJson = objectMapper.writeValueAsString(responseVo);
            outResponse(response ,resultJson);
            SessionServerHelper.manager.setAccessEnforced(true);
            return ;
        }

        String changeOR = PersistenceUtil.object2Oid(changeOrder2);

        //获取部件的编号----在转为OR
        String partNumber = jsonNode.path("number").asText();
        System.out.println(partNumber);
        WTPart part = PartUtil.getWTPartByNumber(partNumber);
        String partOid = object2Oid(part);

        //获取分类
        String classify = jsonNode.path("classify").asText();



        try {
            System.out.println("创建建模对象");
            ChangePartAttribute item = ChangePartAttribute.newChangePartAttribute();
            item.setWTChangeORDER2OR(changeOR);//变更OR
            item.setPartOID(partOid);//部件OR
            item.setUpdateAttributeClassify(classify);//分类
            item.setUpdateAttributeJson(sendJson);//存储的json路径



            //插入数据库
            UpdateAttributeService.insertOneChange(item);

        } catch (WTException | WTPropertyVetoException e) {
            e.printStackTrace();
        }


        ResponseVo responseVo = new ResponseVo();
        responseVo.code="200"; // 插入数据库成功
        responseVo.msg="新建成功";

        SessionServerHelper.manager.setAccessEnforced(true);

        resultJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response ,resultJson);

    }


    @RequestMapping(value = "/updateAttribute", method = RequestMethod.POST)
    public void update(@RequestBody String sendJson, HttpServletRequest request,
                                 HttpServletResponse response) throws IOException {


        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("修改属性接口");
        System.out.println(sendJson);

        String resultJson = "";
        //获取json中的数据
        JsonNode jsonNode = objectMapper.readTree(sendJson);

        // 提取 oid 字段 变更通告VR  ---转为OR存到数据库
        String oid = jsonNode.path("oid").asText();

        WTChangeOrder2 changeOrder2 =(WTChangeOrder2) PersistenceUtil.oid2Object(oid);
        String emsg = ChangeOrder2Util.checkOperationInLegalNode(changeOrder2, ChangeOrder2Util.PERMISSION_NODE);

        if(emsg !=null){
            ResponseVo responseVo = new ResponseVo();
            responseVo.code="405"; // 插入数据库成功
            responseVo.msg=emsg;
            resultJson = objectMapper.writeValueAsString(responseVo);

            outResponse(response ,resultJson);
            return ;
        }

        System.out.println(oid);

        //获取itemOR
        String itemOR = jsonNode.path("itemOR").asText();

        // 修改json字段
        ChangePartAttribute item = (ChangePartAttribute)PersistenceUtil.oid2Object(itemOR);
        try {
            item.setUpdateAttributeJson(sendJson);
            PersistenceHelper.manager.save(item);
        } catch (WTPropertyVetoException | WTException e) {
            e.printStackTrace();
        }


        ResponseVo responseVo = new ResponseVo();
        responseVo.code="200"; // 插入数据库成功
        responseVo.msg="修改成功";

        resultJson = objectMapper.writeValueAsString(responseVo);
        outResponse(response ,resultJson);


    }


    //展示
    @RequestMapping(value = "/updateDetail", method = RequestMethod.GET )
    public void getDetailData(@RequestParam String itemOR,@RequestParam String option,@RequestParam String oid, HttpServletRequest request,
                                HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("进入详细接口");
        System.out.println(itemOR);
        ResponseVo responseVo = new ResponseVo();
        String resultJson ;
        WTChangeOrder2 changeOrder2 =(WTChangeOrder2) PersistenceUtil.oid2Object(oid);
        String emsg = ChangeOrder2Util.checkOperationInLegalNode(changeOrder2, ChangeOrder2Util.PERMISSION_NODE);

        //修改  判断否编制 修改节点
        if(emsg !=null && "update".equals(option)){
            responseVo.code="405"; // 插入数据库成功
            responseVo.msg=emsg;
             resultJson = objectMapper.writeValueAsString(responseVo);
            outResponse(response ,resultJson);
            return ;

        }


        ChangePartAttribute item = (ChangePartAttribute)PersistenceUtil.oid2Object(itemOR);

        String updateAttributeJson = item.getUpdateAttributeJson();

        responseVo.code="200"; // 插入数据库成功
        responseVo.msg=emsg;
        responseVo.data = updateAttributeJson;
        resultJson = objectMapper.writeValueAsString(responseVo);

        System.out.println(resultJson);
        outResponse(response ,resultJson);


    }


    //模糊搜索供应商名称
    @RequestMapping(value = "/getSupplyName", method = RequestMethod.GET )
    public void getSupplyName(@RequestParam String searchKey, HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        System.out.println("查询供应商"+searchKey);
        //数据库查询
        HashSet<String> supplyName = UpdateAttributeService.getSupplyName(searchKey);


        //转为json
        ObjectMapper objectMapper = new ObjectMapper();
        String resultJson = objectMapper.writeValueAsString(supplyName);
        outResponse(response ,resultJson);

    }



    //查全部供应商
    @RequestMapping(value = "/getALlSupplyName", method = RequestMethod.GET )
    public void getAllSupplyName( HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        //数据库查询
        HashSet<String> supplyName = UpdateAttributeService.getAllSupplyName();


        //转为json
        ObjectMapper objectMapper = new ObjectMapper();
        String resultJson = objectMapper.writeValueAsString(supplyName);
        outResponse(response ,resultJson);

    }


    //模糊搜索供应商编码
    @RequestMapping(value = "/getSupplyCode", method = RequestMethod.GET )
    public void getSupplyCode(@RequestParam String supplyName, HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");

        System.out.println("查询供应商"+supplyName);
        //数据库查询
        String supplyCode = UpdateAttributeService.getSupplyCode(supplyName);


        //转为json
        ObjectMapper objectMapper = new ObjectMapper();
        String resultJson = objectMapper.writeValueAsString(supplyCode);
        outResponse(response ,resultJson);

    }

    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }
}
