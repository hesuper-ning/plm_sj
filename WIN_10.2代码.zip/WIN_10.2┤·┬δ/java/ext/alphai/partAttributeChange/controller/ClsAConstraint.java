package ext.alphai.partAttributeChange.controller;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.view.*;
import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.core.meta.common.impl.TypeIdentifierUtilityHelper;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import ext.alphai.partAttributeChange.controller.Vo.ClsAResponseVo;
import ext.alphai.partAttributeChange.utils.ChangeOrder2Util;
import ext.alphai.partAttributeChange.utils.IBAUtil;
import ext.alphai.partAttributeChange.utils.PersistenceUtil;
import ext.alphai.partAttributeChange.utils.PropertiesUtil;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import wt.change2.WTChangeOrder2;
import wt.enterprise.Master;
import wt.fc.*;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.AbstractValue;
import wt.iba.value.IBAHolder;
import wt.iba.value.StringValue;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.Typed;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.util.*;


@Controller
@RequestMapping({"/ClsAConstraint"})
public class ClsAConstraint {

    //从配置文件获取状态
    public final static String displayPartState[] = {"试制", "已发布"};
    public static final List<String> DISPLAY_Part_STATE_LIST = new ArrayList<>(Arrays.asList(displayPartState));


    public static final List<String> MBA_LIST = new ArrayList<>(Arrays.asList(PropertiesUtil.getValueByKey("MBA").split(",")));


    private static final long serialVersionUID = 1L;
    private ObjectMapper objectMapper = new ObjectMapper();

    @RequestMapping(value = "/cls", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    protected void processRequest(@RequestParam String number, @RequestParam String oid, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        System.out.println("打印编号" + number);
        System.out.println("打印变更oid" + oid);

        WTChangeOrder2 changeOrder2 = (WTChangeOrder2) PersistenceUtil.oid2Object(oid);
        String emsg = ChangeOrder2Util.checkOperationInLegalNode(changeOrder2, ChangeOrder2Util.PERMISSION_NODE);

        if (emsg != null) {
            ClsAResponseVo responseVo = new ClsAResponseVo();
            responseVo.setCode("405");
            responseVo.setMsg(emsg);
            JSONObject errNum = new JSONObject(responseVo);
            PrintWriter out = response.getWriter();
            out.print(errNum.toString());
            out.flush();
            return;
        }

//        String number = request.getParameter("number");
        Persistable persistable = queryPart(number);

        if (persistable == null) {
            ClsAResponseVo responseVo = new ClsAResponseVo();
            responseVo.setCode("401");
            responseVo.setMsg("你输入的编号" + number + "有误，请重新搜索！");

            JSONObject errNum = new JSONObject(responseVo);
            PrintWriter out = response.getWriter();
            out.print(errNum.toString());
            out.flush();
            return;
        }

//        JSONObject result = new JSONObject(new LinkedHashMap());

        Map result = new HashMap();
        //保存合法值列表的map
        HashMap<String, String> Legal_Values = new HashMap<>();
        //保存枚举值列表的map
        HashMap<String, HashMap<String, String>> Enum_Values = new HashMap<>();
        HashMap<String, String> infoMap = new LinkedHashMap<>();
        if (persistable != null) {
            WTPart part = (WTPart) persistable;
            IBAUtil ibaUtil1 = new IBAUtil(part);
            // 获取生命周期显示值
            String partState = part.getLifeCycleState().getDisplay();
            if (!DISPLAY_Part_STATE_LIST.contains(partState)) {
                //不含就不展示 直接return 打印信息
                ClsAResponseVo responseVo = new ClsAResponseVo();
                responseVo.setCode("402");
                responseVo.setMsg(number + "部件，状态为" + partState + "。请搜索试制，已发布部件");
                JSONObject errState = new JSONObject(responseVo);
                PrintWriter out = response.getWriter();
                out.print(errState.toString());
                out.flush();
                return;
            }


            //part内部名称
            String typeInternalName = getTypeInternalName(part);
            System.out.println("typeInternalName的值" + typeInternalName);
            String cls = queryInfo(getIBAValue(part, "Classification"));//获取当前部件分类内部值
            IBAUtil ibaUtil = new IBAUtil(part);
            System.out.println("打印分类内部值" + cls);
//            if (!isExistCls(cls)) {
//                ClsAResponseVo errCls = new ClsAResponseVo();
//                errCls.setCode("403");
//                errCls.setMsg(number + "部件，未找到分类属性！");
//                JSONObject errState = new JSONObject(errCls);
//                PrintWriter out = response.getWriter();
//                out.print(errState.toString());
//                out.flush();
//                return;
//            }
            //当前分类的合法值列表
            String ibaInterName = PropertiesUtil.getValueByKey(typeInternalName);//iba属性
            String ibaRequired = PropertiesUtil.getValueByKey(typeInternalName + "_required");

            String legalValueList = ibaInterName;//显示的内部值列表
            String clsInterName = "";//分类属性
            String clsRequired = "";//分类属性必填
            if (!StringUtils.isEmpty(cls)) {
                clsInterName = PropertiesUtil.getValueByKey(cls);
                clsRequired = PropertiesUtil.getValueByKey(cls + "_required");
            }


            //分类列表不为空才拼接
            if (!StringUtils.isEmpty(clsInterName)) {
                legalValueList = legalValueList + "," + clsInterName;
            }

            //拼接必填属性
            String requiredAttribute = ibaRequired;
            //必填拼接
            if (!StringUtils.isEmpty(clsRequired)) {
                requiredAttribute = requiredAttribute + "," + clsRequired;
            }
            System.out.println("合法值列表" + legalValueList);
            result.put("number", number);
            result.put("classify", cls);
            result.put("code", 200);//传入分类和编号
            result.put("requiredAttribute", requiredAttribute);//传入分类和编号
            result.put("partTypeInternalName", typeInternalName);//部件类型内部值
            System.out.println("分类固定合法值列表属性：" + legalValueList);
            typeInternalName = cls;
            if (legalValueList.contains(",")) {
                legalValueList = legalValueList.replace("[", "").replace("]", "");

                //*************这里将所有属性分开************
                List<String> list = new ArrayList<>(Arrays.asList(legalValueList.split(",")));//

                HashMap<String, String> map = new LinkedHashMap<>();
                for (String info : list) {
                    String displayName = getDisplayName(part, info);
                    System.out.println("显示名称值：" + displayName);
                    map.put(info, displayName);
                }
                System.out.println("生成的map是：" + map);

//                JSONObject mapJson = new JSONObject(map);


                result.put("KeyAttributeRules", map);
                for (String iba : list) {
                    String displayName = getDisplayName(part, iba);
                    //iba属性查询为空，查询是否是分类属性
                    if (!isIBA(part, iba)) {
                        if (!isClsValue(typeInternalName, iba)) {
                            map.remove(iba);//    KeyAttributeRules列表去掉
//                            infoMap.remove(iba);//  displayAttribute列表去掉
                            result.remove("KeyAttributeRules");
                            result.put("KeyAttributeRules", map);
                            continue;
                        }


                        //是否sdk  这是个布尔类型的IBA
                        if ("IsSKDPart".equals(iba)) {
                            infoMap.put(iba, StringUtils.isNotEmpty(ibaUtil.getIBAValue(iba)) ? ibaUtil.getIBAValue(iba) : "无");
                        } else {
                            //MBA属性需要这么获取
                            infoMap.put(iba, StringUtils.isNotEmpty(getClsValue(part, iba)) ? getClsValue(part, iba) : "无");
                        }
                        System.out.println("属性" + displayName + "的值为" + getClsValue(part, iba));
                        //当前属性显示名称
                        displayName = "CLS_" + iba;
                        System.out.println("信息1：" + displayName + ":::" + typeInternalName + "===" + iba);

                        //获取分类属性对应的枚举值列表，枚举值列表格式为：   属性显示名称：[枚举值显示名称：枚举值内部名称]组成的map集合
                        HashMap<String, String> classifyEnumerationList = getEnumerationList(typeInternalName, iba);
                        //枚举值列表为空则获取合法值列表
                        if (classifyEnumerationList.size() < 1) {
                            //分类属性对应的合法值列表
                            String classifyLegalList = getLegalList(typeInternalName, iba, getClsValue(part, iba));
                            System.out.println(displayName + "合法值列表" + classifyLegalList);
                            Legal_Values.put(displayName, classifyLegalList);
                        } else {
                            System.out.println(displayName + "枚举值列表数量：" + classifyEnumerationList.size());
                            Enum_Values.put(displayName, classifyEnumerationList);
                        }
                    } else {
                        //是否sdk  这是个布尔类型的IBA
                        if ("IsSKDPart".equals(iba)) {
                            infoMap.put(iba, StringUtils.isNotEmpty(ibaUtil.getIBAValue(iba)) ? ibaUtil.getIBAValue(iba) : "无");
                        } else {
                            //MBA属性需要这么获取
                            infoMap.put(iba, StringUtils.isNotEmpty(getClsValue(part, iba)) ? getClsValue(part, iba) : "无");
                        }
                        System.out.println("属性 " + displayName + " 的值为  " + getIBAValue(part, iba));
                        displayName = "IBA_" + iba;
                        System.out.println("信息2：" + displayName + ":::" + typeInternalName + "===" + iba);
                        HashMap<String, String> ibaEnumerationList = getIBAList(part, iba);
                        if (ibaEnumerationList.size() < 1) {
                            String ibaLegalList = getIBALegalList(part, iba, getIBAValue(part, iba));
                            Legal_Values.put(displayName, ibaLegalList);
                        } else {
                            Enum_Values.put(displayName, ibaEnumerationList);
                        }
                    }
                }
            } else {
                result.put("KeyAttributeRules", legalValueList);
            }
//            JSONObject legalValuesJson = new JSONObject(Legal_Values);
////            for (Map.Entry<String, String> entry : Legal_Values.entrySet()) {
////                legalValuesJson.put(entry.getKey(), entry.getValue());
////            }
            result.put("Legal_Values", Legal_Values);

//            JSONObject infoJson = new JSONObject(infoMap);
//            for (Map.Entry<String, String> entry : infoMap.entrySet()) {
//                infoJson.put(entry.getKey(), entry.getValue());
//                System.out.println("map中内部名" + entry.getKey());
//            }
            result.put("displayAttribute", infoMap);

//            JSONObject enumValuesJson = new JSONObject(Enum_Values);
//            for (Map.Entry<String, HashMap<String, String>> entry : Enum_Values.entrySet()) {
//                JSONArray enumArray = new JSONArray();
//                for (Map.Entry<String, String> subEntry : entry.getValue().entrySet()) {
//                    JSONObject enumObject = new JSONObject();
//                    enumObject.put(subEntry.getKey(), subEntry.getValue());
//                    enumArray.put(enumObject);
//                }
//                enumValuesJson.put(entry.getKey(), enumArray);
//            }
//            result.put("Enum_Values", Enum_Values);

            HashMap<String, ArrayList<Map<String, String>>> enumValuesJson = new HashMap<>();
            for (Map.Entry<String, HashMap<String, String>> entry : Enum_Values.entrySet()) {
                ArrayList<Map<String, String>> enumArray = new ArrayList<>();
                for (Map.Entry<String, String> subEntry : entry.getValue().entrySet()) {
                    Map<String, String> enumObject = new HashMap<>();
                    enumObject.put(subEntry.getKey(), subEntry.getValue());
                    enumArray.add(enumObject);
                }
                enumValuesJson.put(entry.getKey(), enumArray);
            }
            result.put("Enum_Values", enumValuesJson);
        }


        System.out.println("返回结果值：" + result);
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String json = gson.toJson(result);
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }


    @RequestMapping(value = "/getEnumAndCls", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    protected void getEnumAndCls(@RequestParam String number, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了

//        String number = request.getParameter("number");
        Persistable persistable = queryPart(number);
        //返回的数据
        JSONObject result = new JSONObject(new LinkedHashMap());
        //保存合法值列表的map
        HashMap<String, String> Legal_Values = new HashMap<>();

        //保存枚举值列表的map
        HashMap<String, HashMap<String, String>> Enum_Values = new HashMap<>();
        if (persistable != null) {
            WTPart part = (WTPart) persistable;
            //获取内部名
            String typeInternalName = getTypeInternalName(part);
            System.out.println("typeInternalName的值" + typeInternalName);
            String cls = queryInfo(getIBAValue(part, "Classification"));//获取当前部件分类内部值

            String ibaInterName = PropertiesUtil.getValueByKey(typeInternalName);
            String clsInterName = PropertiesUtil.getValueByKey(cls);
            String legalValueList = ibaInterName;
            //分类列表不为空才拼接
            if (!StringUtils.isEmpty(clsInterName)) {
                legalValueList = legalValueList + "," + clsInterName;
            }

            System.out.println("分类固定合法值列表属性：" + legalValueList);
            if (legalValueList.contains(",")) {
                legalValueList = legalValueList.replace("[", "").replace("]", "");
                List<String> list = new ArrayList<>(Arrays.asList(legalValueList.split(",")));


                for (String iba : list) {
                    System.out.println("当前属性内部名" + iba);
                    if (!isIBA(part, iba)) {
                        if (!isClsValue(cls, iba)) {
                            continue;
                        }
                        //获取分类属性对应的枚举值列表，枚举值列表格式为：   属性显示名称：[枚举值显示名称：枚举值内部名称]组成的map集合
                        HashMap<String, String> classifyEnumerationList = getEnumerationList(cls, iba);
                        //枚举值列表为空则获取合法值列表
                        if (classifyEnumerationList.size() < 1) {
                            //分类属性对应的合法值列表
                            String classifyLegalList = getLegalList(cls, iba, getClsValue(part, iba));
                            System.out.println(iba + "合法值列表" + classifyLegalList);
                            Legal_Values.put(iba, classifyLegalList);
                        } else {
                            System.out.println(iba + "枚举值列表数量：" + classifyEnumerationList.size());
                            Enum_Values.put(iba, classifyEnumerationList);
                        }
                    } else {
                        HashMap<String, String> ibaEnumerationList = getIBAList(part, iba);
                        if (ibaEnumerationList.size() < 1) {
                            String ibaLegalList = getIBALegalList(part, iba, getIBAValue(part, iba));
                            Legal_Values.put(iba, ibaLegalList);
                        } else {
                            Enum_Values.put(iba, ibaEnumerationList);
                        }
                    }
                }

                JSONObject legalValuesJson = new JSONObject();
                for (Map.Entry<String, String> entry : Legal_Values.entrySet()) {
                    legalValuesJson.put(entry.getKey(), entry.getValue());
                }
                result.put("Legal_Values", legalValuesJson);


                JSONObject enumValuesJson = new JSONObject();

                for (Map.Entry<String, HashMap<String, String>> entry : Enum_Values.entrySet()) {
                    JSONArray enumArray = new JSONArray();
                    for (Map.Entry<String, String> subEntry : entry.getValue().entrySet()) {
                        JSONObject enumObject = new JSONObject();
                        enumObject.put(subEntry.getKey(), subEntry.getValue());
                        enumArray.put(enumObject);
                    }
                    enumValuesJson.put(entry.getKey(), enumArray);
                }
                result.put("Enum_Values", enumValuesJson);


            }
        }


        System.out.println("返回结果值：" + result);
        PrintWriter out = response.getWriter();
        out.print(result.toString());
        out.flush();


    }

    public static String queryInfo(String info) {
        if (StringUtils.isEmpty(info))
            return "属性缺失";
        return info;
    }

    //根据编码获取部件
    public static Persistable queryPart(String number) throws WTException {
        if (number.isEmpty()) {
            throw new WTException("number为空！");
        }
        QuerySpec qs = new QuerySpec(WTPart.class);
        qs.setAdvancedQueryEnabled(true);
        SearchCondition sc = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, number);
        qs.appendWhere(sc);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        while (qr.hasMoreElements()) {
            WTPart wtPart = (WTPart) qr.nextElement();
            return getLatestPartByMaster((Master) wtPart.getMaster());
        }
        return null;
    }

    public static WTPart getLatestPartByMaster(Master master) throws WTException {
        if (master != null) {
            QueryResult qr = VersionControlHelper.service.allVersionsOf(master);
            if (qr.hasMoreElements()) {
                WTPart wtPart = (WTPart) qr.nextElement();
                return wtPart;
            }
        }
        return null;
    }

    //获取IBA属性
    public static String getIBAValue(IBAHolder holder, String ibaName) throws WTException {


        //MB属性
        if (MBA_LIST.contains(ibaName)) {
            return getMBADisplayName((WTPart) holder, ibaName);
        }

        AttributeDefDefaultView addv = null;
        try {
            addv = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
        } catch (RemoteException e) {
            throw new WTException(e);
        }
        if (addv == null) {
            throw new WTException("undefined iba name :" + ibaName);
        }
        long ibaDefId = addv.getObjectID().getId();

        QuerySpec qs = new QuerySpec(StringValue.class);
        qs.appendWhere(new SearchCondition(StringValue.class,
                AbstractValue.IBAHOLDER_REFERENCE + "." + ObjectReference.KEY + "." + ObjectIdentifier.ID,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier((Persistable) holder).getId()), new int[]{0});
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(StringValue.class, StringValue.DEFINITION_REFERENCE + "."
                + ObjectReference.KEY
                + "." + ObjectIdentifier.ID, SearchCondition.EQUAL, ibaDefId), new int[]{0});

        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
        StringValue sv = null;
        if (qr.hasMoreElements()) {
            sv = (StringValue) qr.nextElement();
        }
        return sv == null ? null : sv.getValue();
    }

    //获取分类下的固定合法值列表值
    public static String getList(String typeInternalName) throws Exception {
        TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
                "com.ptc.csm.default_clf_namespace", typeInternalName);
        System.out.println("AAA2:" + clfNodeView);
        AttributeDefinitionReadView adrv = clfNodeView.getAttributeByName("SerialNumberManagement");
        Collection<ConstraintDefinitionReadView> a = adrv.getAllConstraints();
        List<ConstraintDefinitionReadView> collect = collectionToList(a);
        for (ConstraintDefinitionReadView cv : collect) {
            if (cv.getRuleData() != null) {
                String s = cv.getRuleData().toString();
                if (!s.contains(",")) {
                    return cv.getRuleData().toString();
                }
            }
        }
        return null;
    }

    //typeInternalName 部件内部名称，propertyName 属性内部名称
    //获取分类合法值列表方法
    public static String getLegalList(String typeInternalName, String propertyName, String info) throws Exception {
        TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
                "com.ptc.csm.default_clf_namespace", typeInternalName);
        System.out.println("AAA3" + clfNodeView);
        AttributeDefinitionReadView adrv = clfNodeView.getAttributeByName(propertyName);
        Collection<ConstraintDefinitionReadView> a = adrv.getAllConstraints();
        List<ConstraintDefinitionReadView> collect = collectionToList(a);
        for (ConstraintDefinitionReadView cv : collect) {
            if (cv.getRuleData() != null) {
                String s = cv.getRuleData().toString();
                System.out.println("当前合法值列表是：" + s);
                if (StringUtils.isNotEmpty(info) && s.contains(info)) {
                    return cv.getRuleData().toString().replace("[", "").replace("]", "");
                }
            }
        }
        return null;
    }

    //获取内部名称
    public static String getTypeInternalName(Typed typed_object) throws WTException {
        String name = null;
        try {
            TypeIdentifier type = TypeIdentifierUtilityHelper.service.getTypeIdentifier(typed_object);
            TypeDefinitionReadView trv = TypeDefinitionServiceHelper.service.getTypeDefView(type);
            name = trv.getName();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        }
        return name;
    }

    //获取分类约束的枚举值列表，返回值为map,传入数据为部件类型的内部名称（classify），部件当前属性的内部名称（partInternalName）
    public static HashMap<String, String> getEnumerationList(String classify, String partInternalName) throws Exception {
        TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
                "com.ptc.csm.default_clf_namespace", classify);
        AttributeDefinitionReadView adrv = clfNodeView.getAttributeByName(partInternalName);
        Collection<ConstraintDefinitionReadView> a = adrv.getAllConstraints();
        List<ConstraintDefinitionReadView> collect = collectionToList(a);
        System.out.println(collect.size());
        HashMap<String, String> map = new HashMap<>();
        for (ConstraintDefinitionReadView cv : collect) {
            ConstraintDefinitionReadView.RuleDataObject rdo = cv.getRuleDataObj();
            if (rdo != null) {
                if (rdo.getEnumDef() == null)
                    continue;
                Collection<EnumerationEntryReadView> coll = rdo.getEnumDef().getAllEnumerationEntries().values();
                Iterator<EnumerationEntryReadView> iterator = coll.iterator();
                while (iterator.hasNext()) {
                    EnumerationEntryReadView next = iterator.next();
                    //内部名称
                    String internalName = next.getName();
                    System.out.println("当前枚举的内部名称：" + internalName);
                    PropertyValueReadView pv = next.getAllProperties().iterator().next();
                    String displayName = pv.getValueAsString();
                    System.out.println("当前枚举的显示名称：" + displayName);
                    map.put(internalName, displayName);
                }
            }
        }
        System.out.println("getEnumerationList执行完成。。。");
        return map;
    }

    // 获取内部名称对应的显示名称
    public static String getDisplayName(Persistable part, String internalName) throws WTException {
        TypeIdentifier serialNumberManagement = TypeIdentifierUtility.getTypeIdentifier(internalName);
        String typename = serialNumberManagement.getTypename();
        Locale locale = Locale.getDefault();
        LWCNormalizedObject obj = new LWCNormalizedObject(part, null, locale, null);
        obj.load(internalName);
        return obj.getAttributeDescriptor(internalName).getLabel();
    }

    //获取IBA属性枚举值列表
    public static HashMap<String, String> getIBAList(Persistable part, String typeInternalName) throws Exception {
        ArrayList<String> strings = new ArrayList<>();
        String s = TypeIdentifierUtilityHelper.service.getTypeIdentifier(part).toString();
        TypeIdentifier ti = TypedUtility.getTypeIdentifier(s);
        TypeDefinitionReadView tv = TypeDefinitionServiceHelper.service.getTypeDefView(ti);
        AttributeDefinitionReadView av = tv.getAttributeByName(typeInternalName);
        HashMap<String, String> map = new HashMap<>();
        if (av != null) {
            Collection<ConstraintDefinitionReadView> constraints = av.getAllConstraints();
            for (ConstraintDefinitionReadView cdrv : constraints) {
                ConstraintDefinitionReadView.RuleDataObject rdo = cdrv.getRuleDataObj();
                if (rdo != null) {
                    if (rdo.getEnumDef() == null)
                        continue;
                    System.out.println("rdo::::" + rdo.toString());
                    Collection<EnumerationEntryReadView> values = rdo.getEnumDef().getAllEnumerationEntries().values();
                    Iterator<EnumerationEntryReadView> iterator = values.iterator();
                    while (iterator.hasNext()) {
                        EnumerationEntryReadView next = iterator.next();
                        String name = next.getName();
                        String displayName = "";
                        if (next.getPropertyValueByName("displayName") != null) {
                            displayName = next.getPropertyValueByName("displayName").getValue().toString();
                        } else if (next.getPropertyValueByName("产线") != null) {
                            displayName = next.getPropertyValueByName("产线").getValue().toString();
                        }
                        map.put(name, displayName);
                        strings.add(name);
                    }
                }
            }
        } else {
            System.out.println("方法失败");
        }
        System.out.println("=============>");
        System.out.println("完成方法：" + strings.toString());
        return map;
    }

    //获取iba属性的合法值列表
    public static String getIBALegalList(Persistable part, String typeInternalName, String info) throws Exception {
        String s = TypeIdentifierUtilityHelper.service.getTypeIdentifier(part).toString();
        TypeIdentifier ti = TypedUtility.getTypeIdentifier(s);
        TypeDefinitionReadView tv = TypeDefinitionServiceHelper.service.getTypeDefView(ti);
        AttributeDefinitionReadView av = tv.getAttributeByName(typeInternalName);
        Collection<ConstraintDefinitionReadView> a = av.getAllConstraints();
        List<ConstraintDefinitionReadView> collect = collectionToList(a);
        for (ConstraintDefinitionReadView cv : collect) {
            if (cv.getRuleData() != null) {
                String s2 = cv.getRuleData().toString();
                if (StringUtils.isNotEmpty(info) && s2.contains(info)) {
                    return cv.getRuleData().toString().replace("[", "").replace("]", "");
                }
            }
        }
        return null;
    }

    public static boolean isIBA(Persistable part, String typeInternalName) throws WTException, RemoteException {

        String s = TypeIdentifierUtilityHelper.service.getTypeIdentifier(part).toString();
        System.out.println("isIBA里打印什么" + s);
        TypeIdentifier ti = TypedUtility.getTypeIdentifier(s);
        TypeDefinitionReadView tv = TypeDefinitionServiceHelper.service.getTypeDefView(ti);
        AttributeDefinitionReadView av = tv.getAttributeByName(typeInternalName);
        return av == null ? false : true;
    }

    public static List<ConstraintDefinitionReadView> collectionToList(Collection<ConstraintDefinitionReadView> collections) throws Exception {
        if (collections == null)
            return new ArrayList<ConstraintDefinitionReadView>();
        List<ConstraintDefinitionReadView> list = new ArrayList<>(collections.size());
        for (ConstraintDefinitionReadView view : collections) {
            list.add(view);
        }
        return list;
    }

    public static Map<String, String> readProperties() {
        Properties properties = new Properties();
        InputStream input = null;
        Map<String, String> map = new HashMap<>();
        try {
            // 相对路径指向ClsProperties.properties文件
            String propertiesFilePath = "src/ext/properties/ClsProperties.properties";
            input = new FileInputStream(propertiesFilePath);
            properties.load(input);
            for (String key : properties.stringPropertyNames()) {
                String value = properties.getProperty(key);
                map.put(key, value);
            }
            // 可以继续读取其他属性
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return map;
    }

    public static String getClsValue(Persistable persistable, String typeName) throws WTException {
        PersistableAdapter obj = new PersistableAdapter(persistable, null, SessionHelper.getLocale(), new UpdateOperationIdentifier());
        obj.load(typeName);
        Object result = obj.get(typeName);
        return result == null ? "" : result.toString();
    }

    public static boolean isClsValue(Persistable persistable, String typeName) throws WTException {
        PersistableAdapter obj = new PersistableAdapter(persistable, null, SessionHelper.getLocale(), new UpdateOperationIdentifier());
        obj.load(typeName);
        Object result = obj.get(typeName);
        return result == null ? false : true;
    }


    public static boolean isClsValue(String classify, String partInternalName) throws Exception {
        TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
                "com.ptc.csm.default_clf_namespace", classify);
        AttributeDefinitionReadView adrv = clfNodeView.getAttributeByName(partInternalName);
        return adrv == null ? false : true;
    }

    //获取分类下的固定合法值列表值
    public static boolean isExistCls(String typeInternalName) throws Exception {
        TypeDefinitionReadView clfNodeView = TypeDefinitionServiceHelper.service.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT,
                "com.ptc.csm.default_clf_namespace", typeInternalName);
        return clfNodeView == null ? false : true;
    }

    /**
     * 获取MBA内部值  暂时就名称和源  且  要先判断是否为MBA
     *
     * @param part
     * @param interName
     * @return
     */
    public static String getMBADisplayName(WTPart part, String interName) {
        switch (interName) {
            case "name":
                return part.getName();
            case "source":
                return part.getSource().getDisplay();
        }

        return null;
    }
}
