package ext.alphai.partAttributeChange.errInfo.entity;

import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;

public class ErrTableData {

    private UrlDisplayComponent partNumber;
    private String partName;
    private String errInfo;


    public UrlDisplayComponent getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(UrlDisplayComponent partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getErrInfo() {
        return errInfo;
    }

    public void setErrInfo(String errInfo) {
        this.errInfo = errInfo;
    }
}
