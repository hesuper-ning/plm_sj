package ext.alphai.partAttributeChange.errInfo.builder;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.alphai.partAttributeChange.errInfo.entity.ErrTableData;
import ext.alphai.partAttributeChange.utils.PartUtil;
import wt.part.WTPart;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import java.util.ArrayList;
import java.util.List;

@ComponentBuilder("ext.alphai.partAttributeChange.errInfo.builder.UpdateAttributeErrTable")
public class UpdateAttributeErrTable extends AbstractComponentBuilder {


    //展示表
    @Override
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {

        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig table = factory.newTableConfig();
        table.setSelectable(true);//可选
        table.setLabel("ECN修改属性错误信息");
        table.setConfigurable(true);

        ColumnConfig partNumber = factory.newColumnConfig("partNumber", "部件编号", true);
        partNumber.setDataUtilityId("UpdateAttributeErrTable_Utility");
        table.addComponent(partNumber);

        ColumnConfig partName = factory.newColumnConfig("partName", "部件名称", true);
        partName.setDataUtilityId("UpdateAttributeErrTable_Utility");
        table.addComponent(partName);


        ColumnConfig errInfo = factory.newColumnConfig("errInfo", "错误信息", true);
        errInfo.setDataUtilityId("UpdateAttributeErrTable_Utility");
        table.addComponent(errInfo);


        return table;
    }


    //展示数据
    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        JcaComponentParams jca_params = (JcaComponentParams) componentParams;
        NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
        NmOid primaryOid2 = cb.getPrimaryOid();
        List<ErrTableData> result = new ArrayList<>();
        if (primaryOid2 != null) {
            Object content = primaryOid2.getRef();
            if (content instanceof WorkItem) {
                WorkItem wi = (WorkItem) content;
                System.out.println("wi:" + wi);
                WfAssignedActivity wfAssignedActivity = (WfAssignedActivity) wi.getSource().getObject();
                WfProcess wfProcess = wfAssignedActivity.getParentProcess();
                System.out.println("wfProcess:" + wfProcess);
                String errInto = (String) wfProcess.getContext().getValue("AI_checkOutParts");
                System.out.println("错误的json为:" + errInto);
                // 拆解json
                result = analysisStr(errInto);
            }
        }
        return result;
    }


    public static List<ErrTableData> analysisStr(String var) throws WTException {
        List<ErrTableData> result = new ArrayList<>();


        String[] partNumber = var.split(" ");
        for (String s : partNumber) {
            if (!s.isEmpty()){
                ErrTableData errTableData = new ErrTableData();

                //获取part对象
                WTPart part = PartUtil.getWTPartByNumber(s);
                errTableData.setPartNumber(PartUtil.getPartUrlByPartNumber(part));
                errTableData.setPartName(part.getName());
                errTableData.setErrInfo("当前部件已经检出！请检入后重新提交！");

                result.add(errTableData);


            }
        }


        return result;
    }
}
