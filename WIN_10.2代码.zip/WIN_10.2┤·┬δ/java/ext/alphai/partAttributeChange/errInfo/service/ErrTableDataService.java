package ext.alphai.partAttributeChange.errInfo.service;

public class ErrTableDataService {
}
