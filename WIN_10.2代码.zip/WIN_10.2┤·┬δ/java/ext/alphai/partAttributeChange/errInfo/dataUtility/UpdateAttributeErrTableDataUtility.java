package ext.alphai.partAttributeChange.errInfo.dataUtility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import ext.alphai.partAttributeChange.errInfo.entity.ErrTableData;
import wt.util.WTException;

public class UpdateAttributeErrTableDataUtility extends AbstractDataUtility {
    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        ErrTableData errTableData= (ErrTableData)o;

        if (errTableData==null) {
            return null;
        }

        UrlDisplayComponent partNumber = errTableData.getPartNumber();
        String partName = errTableData.getPartName();
        String errInfo = errTableData.getErrInfo();

        switch (s) {
            case "partNumber":
                System.out.println("部件编号"+partNumber);
                //返回可点击的编号
                return partNumber;
            case "partName":
                System.out.println("部件名称"+partName);
                return partName;
            case "errInfo":
                System.out.println("错误信息"+errInfo);
                return errInfo;
        }
        return null;
    }
}
