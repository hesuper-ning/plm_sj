package ext.alphai.partAttributeChange.work;
import ext.alphai.partAttributeChange.ChangePartAttribute;
import ext.alphai.partAttributeChange.service.UpdateAttributeService;
import ext.alphai.partAttributeChange.utils.PartUtil;
import ext.alphai.partAttributeChange.utils.PersistenceUtil;
import ext.kingdeeERP.masterData.Controller;
import wt.change2.WTChangeOrder2;
import wt.fc.WTObject;
import wt.part.WTPart;

import java.util.List;


public class ChangeAttributeWorkSendPart {

    /**
     * 流程表达式执行修改分类及IBA属性方法
     *
     * @param pbo
     */
    public static void work(WTObject pbo) {

        if (pbo instanceof WTChangeOrder2) {
            System.out.println("执行修改物料的分类和IBA属性流程表达式");
            WTChangeOrder2 order2 = (WTChangeOrder2) pbo;
            String changeOid = PersistenceUtil.object2Oid(order2);
            // 执行真正的变更BOM
            try {
                List<ChangePartAttribute> ChangePartAttributeList = UpdateAttributeService.getChangePartAttributeByChangeOid(changeOid);
                if (ChangePartAttributeList.size() > 0) {
                    for (ChangePartAttribute changePartAttribute : ChangePartAttributeList) {
                        String partOID = changePartAttribute.getPartOID();
                        WTPart part = (WTPart)PersistenceUtil.oid2Object(partOID);//只是当前物料
                        //最新物料
                        part = PartUtil.getWTPartByNumber(part.getNumber());
                        System.out.println("打印这个部件最新的源"+part.getSource().getDisplay());
                        //同步物料
                        String flag = "";
                        Controller.sendParts2ERP(part);
                    }
                }

            } catch (Exception e) {
                e.getMessage();
            }

        }
    }


}
