package ext.alphai.partAttributeChange.work;
import ext.alphai.partAttributeChange.ChangePartAttribute;
import ext.alphai.partAttributeChange.service.UpdateAttributeService;
import ext.alphai.partAttributeChange.utils.PersistenceUtil;
import ext.kingdeeERP.changeBOM.WTPartUsageLinkChangeItem;
import ext.kingdeeERP.changeBOM.server.PartUsageChangeServer;
import wt.change2.WTChangeOrder2;
import wt.fc.WTObject;
import wt.pom.PersistenceException;
import wt.pom.Transaction;

import java.util.List;


public class ChangeAttributeWork {
    /**
     * 流程表达式执行修改分类及IBA属性方法
     *
     * @param pbo
     */
    public static String work(WTObject pbo) {

        String errMsg = "";

        //判断是否含有未检出的部件

        if (pbo instanceof WTChangeOrder2) {
            System.out.println("执行修改物料的分类和IBA属性流程表达式");
            WTChangeOrder2 order2 = (WTChangeOrder2) pbo;
            String changeOid = PersistenceUtil.object2Oid(order2);
            // 执行真正的变更BOM
                List<ChangePartAttribute> ChangePartAttributeList = UpdateAttributeService.getChangePartAttributeByChangeOid(changeOid);
                // 判断BOM有没有重复,获取变更项id
                List<WTPartUsageLinkChangeItem> changeItem = PartUsageChangeServer.getChangeItemByChangeOid(changeOid);

                //发现有检出的部件直接return错误信息
                String checkOutParts = UpdateAttributeService.getCheckOutParts(ChangePartAttributeList);
                if (checkOutParts.length()>0) {
                    errMsg = checkOutParts;
                    return errMsg;
                }

             // 正式执行修改
            if (ChangePartAttributeList.size() > 0) {
                    //获取BOM编号集合
                    List<String> bomList = UpdateAttributeService.getBOMList(changeItem);
                    //获取当前变更通告内部名
                    String typeInternalName = UpdateAttributeService.getTypeInternalName(order2);

                    // 执行事务
                    Transaction trx  = new Transaction();
                    try {
                        trx.start();
                        for (ChangePartAttribute changePartAttribute : ChangePartAttributeList) {

                            String updateAttributeJson = changePartAttribute.getUpdateAttributeJson();
                            //判断修改的部件是否在BOM中，是就改小版本，不是就修订大版本
                            System.out.println(updateAttributeJson);
                            //返回最新版本的部件  修改版本
                            UpdateAttributeService.updateAttributeAndRevise(order2,bomList, updateAttributeJson);
                        }
                        trx.commit();
                        trx = null;
                    } catch (PersistenceException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        if (trx != null) {
                            try {
                                trx.rollback();
                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }
                        }
                    }


                }



        }

        return errMsg;
    }


}
