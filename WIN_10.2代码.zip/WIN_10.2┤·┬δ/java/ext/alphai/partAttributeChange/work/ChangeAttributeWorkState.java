package ext.alphai.partAttributeChange.work;

import ext.alphai.partAttributeChange.ChangePartAttribute;
import ext.alphai.partAttributeChange.service.UpdateAttributeService;
import ext.alphai.partAttributeChange.utils.PartUtil;
import ext.alphai.partAttributeChange.utils.PersistenceUtil;
import wt.change2.WTChangeOrder2;
import wt.fc.WTObject;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ChangeAttributeWorkState {
    // 量产变更单key
    private static final String[] MASS_PRODUCTION = {"com.sprocomm.FullECN", "com.sprocomm.FastECN"};
    public static final List<String> MASS_PRODUCTION_LIST = new ArrayList<>(Arrays.asList(MASS_PRODUCTION));

    //已发布
    public static final String PUBLISHED = "已发布";

    // 已发布的key值
    public static final String Published_Key = "RELEASED";

    // 试产变更单key
    private static final String[] TRIAL_PRODUCTION = {"com.sprocomm.MODEL_STAGE_ECN_SZ", "com.sprocomm.MODEL_STAGE_ECN"};
    public static final List<String> TRIAL_PRODUCTION_LIST = new ArrayList<>(Arrays.asList(TRIAL_PRODUCTION));

    public static final String TRIAL = "试制";
    // 试制的key
    public static final String TRIAL_Key = "MODEL_STAGE";


    /**
     * 流程表达式执行修改分类及IBA属性方法
     *
     * @param pbo
     */
    public static void work(WTObject pbo) throws WTException, WTPropertyVetoException {

        if (pbo instanceof WTChangeOrder2) {
            System.out.println("执行修改物料的分类和IBA属性流程表达式");
            WTChangeOrder2 order2 = (WTChangeOrder2) pbo;
            String changeOid = PersistenceUtil.object2Oid(order2);

            List<ChangePartAttribute> changePartAttributeByChangeOid = UpdateAttributeService.getChangePartAttributeByChangeOid(changeOid);

            if (changePartAttributeByChangeOid.size() > 0) {

                Transaction trx = new Transaction();
                try {

                    trx.start();
                    //获取当前变更通告内部名
                    String typeInternalName = UpdateAttributeService.getTypeInternalName(order2);
                    // 量产   ---- 已发布
                    if (MASS_PRODUCTION_LIST.contains(typeInternalName)) {
                        UpdateAttributeService.UpdatePartState(changePartAttributeByChangeOid, Published_Key);
                    }

                    if (TRIAL_PRODUCTION_LIST.contains(typeInternalName)) {
                        //试量   ---- 试制
                        UpdateAttributeService.UpdatePartState(changePartAttributeByChangeOid, TRIAL_Key);
                    }

                    trx.commit();
                    trx = null;
                }catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (trx != null) {
                        try {
                            trx.rollback();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                }



            }

        }
    }


}
