package ext.alphai.partAttributeChange;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.alphai.partAttributeChange.ChangeAttributeRB_zh_CN")
public class ChangeAttributeRB_zh_CN extends WTListResourceBundle{

    @RBEntry("更改内容")
    public static final String CHANGE_CONTENT = "change_content";


    @RBEntry("物料属性更改内容")
    public static final String PRIVATE_CONSTANT_10 = "BatchAttribute.batchAttribute.description";
    @RBEntry("物料属性更改内容")
    public static final String PRIVATE_CONSTANT_11 = "BatchAttribute.batchAttribute.tooltip";
    @RBEntry("edit_properties.gif")
    public static final String PRIVATE_CONSTANT_12 = "BatchAttribute.batchAttribute.icon";

    @RBEntry("删除变更")
    public static final String PRIVATE_CONSTANT_29 = "BatchAttribute.deleteItem.description";
    @RBEntry("删除变更")
    public static final String PRIVATE_CONSTANT_30 = "BatchAttribute.deleteItem.tooltip";
    @RBEntry("delete.png")
    public static final String PRIVATE_CONSTANT_31 = "BatchAttribute.deleteItem.icon";

    @RBEntry("ECN修改物料属性返回信息")
    public static final String PRIVATE_CONSTANT_50 = "BatchAttribute.updateAttErrTable.description";
    @RBEntry("ECN修改物料属性返回信息")
    public static final String PRIVATE_CONSTANT_49 = "BatchAttribute.updateAttErrTable.tooltip";



}
