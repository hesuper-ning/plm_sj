package ext.alphai.partAttributeChange.utils;

import org.apache.commons.lang.StringUtils;
import wt.change2.*;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.method.MethodContext;
import wt.method.RemoteAccess;
import wt.org.OrganizationServicesHelper;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.ownership.Ownership;
import wt.pom.WTConnection;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import java.lang.reflect.Field;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import static wt.org.WTPrincipalReference.newWTPrincipalReference;

public class CommonUtil implements RemoteAccess {
    /**
     * 转换中文格式，避免中文乱码
     *
     * @param value
     * @return
     * @throws WTException
     */
    public static String formatString(String value) throws WTException {
        try {
            if (value != null && value.trim().length() > 0) {
                byte[] tembyte = value.getBytes("gb2312");
                return new String(tembyte);
            } else {
                return value;
            }
        } catch (Exception e) {
            throw new WTException(e);
        }
    }



    /**
     * 将一个实体类中的所有字段转换为Map
     *
     * @param entity 实体类
     * @return 输出的Map
     */
    public static <T> Map<String, Object> entityToMap(T entity) {
        Map<String, Object> resultMap = new HashMap<>();

        // 使用反射获取类的所有字段
        Field[] fields = entity.getClass().getDeclaredFields();

        try {
            for (Field field : fields) {
                // 设置字段为可访问，以便获取私有字段的值
                field.setAccessible(true);

                // 将字段名和字段值添加到Map中
                resultMap.put(field.getName(), field.get(entity));
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        return resultMap;
    }





    /**
     * 根据用户名称/用户全名获取用户对象
     *
     * @param
     * @param
     * @return WTUser
     */
    @SuppressWarnings("deprecation")
    public static WTUser getUserByName(String name, boolean IsFull) {
        String parm = IsFull ? WTUser.FULL_NAME : WTUser.NAME;
        if (StringUtils.isBlank(name)) {
            return null;
        }
        try {
            Enumeration enumUser = OrganizationServicesHelper.manager.findUser(parm, name.trim());
            while (enumUser.hasMoreElements()) {
                return (WTUser) enumUser.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
     * 从QueryResult中获取需要类型的对象数据
     *
     * @param <T>   泛型对象
     * @param qr
     * @param clazz
     * @return
     */
    public static <T> ArrayList<T> getListFromQR(QueryResult qr, Class<T> clazz) {
        ArrayList<T> list = new ArrayList<T>();
        while (qr.hasMoreElements()) {
            Object obj = qr.nextElement();
            if (clazz.isInstance(obj)) {
                T castedObj = clazz.cast(obj);
                list.add(castedObj);
            }
        }
        return list;
    }

    /**
     * 连接Windchill数据库来运行自定义sql
     *
     * @return WTConnection 数据库连接
     * @throws Exception
     */
    public static WTConnection getWTConnection() {
        WTConnection wtconnection = null;
        try {
            MethodContext methodcontext = MethodContext.getContext();
            wtconnection = (WTConnection) methodcontext.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wtconnection;
    }

    /**
     * 执行查询的SQL语句并返回结果 SQL示例：SELECT WTPARTNUMBER FROM WTPARTMASTER WHERE
     * WTPARTNUMBER LIKE ?
     *
     * @param sql    SQL语句
     * @param params 参数集
     * @return ResultSet 返回结果集
     */
    public static ResultSet excuteSelect(String sql, String... params) {
        try {
            WTConnection connection = CommonUtil.getWTConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                statement.setString(i + 1, params[i]);
            }

            // 输出当前执行查询操作的SQL语句
            String fullSql = sql;
            for (String param : params) {
                param = param.length() > 250 ? "此属性太长，不显示内容" : param;
                fullSql = fullSql.replaceFirst("\\?", "'" + param + "'");
            }
            System.out.println("--------当前执行查询操作的SQL语句为--------");
            System.out.println(fullSql);

            ResultSet resultSet = statement.executeQuery();
            return resultSet;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
     * 将传入的PBO解析为方便处理的List<T>
     *
     * @param <T>        泛型
     * @param obj        PBO
     * @param targetType 结果的类型
     * @return
     */
    public static <T> List<T> getListFromPBO(WTObject obj, Class<T> targetType) {
        List<T> list = new ArrayList<>();
        try {
            if (targetType.isInstance(obj)) {
                list.add(targetType.cast(obj));
            } else if (obj instanceof PromotionNotice) {
                PromotionNotice pn = (PromotionNotice) obj;
                QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeOrder2) {
                WTChangeOrder2 co = (WTChangeOrder2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeablesAfter(co);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeActivity2) {
                WTChangeActivity2 eca = (WTChangeActivity2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else if (obj instanceof WTChangeRequest2) {
                WTChangeRequest2 ecr = (WTChangeRequest2) obj;
                QueryResult qr = ChangeHelper2.service.getChangeables((ChangeRequestIfc) ecr);
                list = CommonUtil.getListFromQR(qr, targetType);
            } else {
                System.out.println("数据不正确!");
            }
        } catch (ChangeException2 e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }
    /**
     * 通过WTUser name获取Ownership
     * @param name
     * @return
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    public static Ownership getOwnershipByName(String name) throws WTException, WTPropertyVetoException {
        WTUser user = getUserByName(name);
        WTPrincipalReference principalReference = newWTPrincipalReference(user);
        Ownership ownership = new Ownership();
        ownership.setOwner(principalReference);
        return ownership;
    }


    /**
     * 通过WTUser name获取wtuser对象
     * @param name
     * @return
     */
    public static WTUser getUserByName(String name){
        WTUser user = null;
        try {
            QuerySpec qs = new QuerySpec(WTUser.class);
            SearchCondition sc = new SearchCondition(WTUser.class,WTUser.NAME, SearchCondition.EQUAL, name, false);
            qs.appendSearchCondition(sc);

            QueryResult qr = PersistenceHelper.manager.find(qs);
            if (qr.hasMoreElements()){
                user = (WTUser)qr.nextElement();
            }

            if(user == null)
                user = OrganizationServicesHelper.manager.getUser(name);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    public static boolean isNumeric(String str) {
        // 使用正则表达式判断是否为数字，允许负号和正号开头，以及小数点
        return str.matches("-?\\d+(\\.\\d+)?");
    }

}

