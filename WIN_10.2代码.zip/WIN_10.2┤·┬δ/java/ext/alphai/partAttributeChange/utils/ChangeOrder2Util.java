package ext.alphai.partAttributeChange.utils;

import wt.change2.WTChangeOrder2;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ChangeOrder2Util {
    // ECN流程编制节点

    // 量产变更单key
    private static final String[] ORGANIZATION_UPDATE_NODE = {"编制", "修改"};
    public static final List<String> PERMISSION_NODE = new ArrayList<>(Arrays.asList(ORGANIZATION_UPDATE_NODE));


    /**
     * 检查当前ECN是否在对应的节点
     * @return
     */
    public static String checkOperationInLegalNode(WTChangeOrder2 order2, List<String> nodeName){

        String msg = null;
        List<String> actionNames = new ArrayList<>();
        try {
            WfProcess wfProcess = WorkflowUtil.getRelatedProcess(order2);
            System.out.println("wfProcess:"+wfProcess);
            ArrayList<WfAssignedActivity> wfAssignedActivityList =WorkflowUtil.getWfAssignedActivitys(wfProcess);
            for (WfAssignedActivity wfAssignedActivity : wfAssignedActivityList) {
                System.out.println("流程中活动的名称"+wfAssignedActivity.getName());
                System.out.println("是否完成："+wfAssignedActivity.isComplete());
                //获取未完成任务，
                if (!wfAssignedActivity.isComplete()) {
                    actionNames.add(wfAssignedActivity.getName());
                }
            }
        } catch (Exception e) {
            e.getMessage();
        }

        boolean flag = false;//默认没有


        //判断是未完成活动否含有  编制 或者  修改
        for (String s : nodeName) {
            System.out.println("节点状态"+s);
            if (actionNames.contains(s)) {
                flag = true;
                break;
            }

        }

        if(flag){
        }else {
            msg = "当前流程节点不为"+nodeName+"无法进行操作";
        }
        return msg;
    }
}
