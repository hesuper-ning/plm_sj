package ext.alphai.partAttributeChange.utils;

import wt.enterprise.RevisionControlled;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.util.WTException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;

public class VersionUtil implements RemoteAccess {

    /**
     * 获取最新版本的对象
     *
     * @param master
     * @return RevisionControlled
     * @throws WTException
     */
    public static RevisionControlled getLatestObjectByMaster(Mastered master) throws WTException {
        if (master == null) {
            return null;
        } else {
            QueryResult queryResult = VersionControlHelper.service.allVersionsOf(master);
            return queryResult.hasMoreElements() ? (RevisionControlled) queryResult.nextElement() : null;
        }
    }


}
