package ext.alphai.partAttributeChange;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;
import wt.content.ContentHolder;
import wt.fc.WTObject;
import wt.util.WTException;
/**
 * 部件使用关系变更项建模
 * WTChangeORDER2OR 变更通告OID
 * ParentNumber 部件编号
 * Classify 分类
 * updateAttributejson 行号
 * updateAttributejson 存改前 改后属性的数据，以及枚举，合法值列表的数据
 */

@GenAsPersistable(superClass = WTObject.class,interfaces = {ContentHolder.class},
        properties = {
                @GeneratedProperty(name="WTChangeORDER2OR", type=String.class,
                        constraints=@PropertyConstraints(required=true)),
                @GeneratedProperty(name="PartOID", type= String.class),
                @GeneratedProperty(name="UpdateAttributeClassify", type= String.class),
                @GeneratedProperty(name="UpdateAttributeJson", type= String.class,constraints = @PropertyConstraints(upperLimit = 50000))
        })
public class ChangePartAttribute extends _ChangePartAttribute {


    static final long serialVersionUID = 1;

    public static ChangePartAttribute newChangePartAttribute() throws WTException {
        final ChangePartAttribute instance = new ChangePartAttribute();
        instance.initialize();
        return instance;
    }
}
