package ext.alphai.wf.listener;


import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import ext.alphai.wf.util.PropertiesUtil;
import wt.epm.EPMDocument;
import wt.events.KeyedEventListener;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlServiceEvent;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class EPMListenerService extends StandardManager implements EPMListener, Serializable {
    private static final String[] clear_state = {"PRODUCTIONCHANGE", "DESIGN"};
    private static final List<String> clear_state_list = new ArrayList<>(Arrays.asList(clear_state));
    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = EPMListenerService.class.getName();
    private KeyedEventListener listener;
    public static EPMDocument epm = null;

    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public EPMListenerService() {
    }

    public static EPMListenerService newEPMListenerService() throws WTException {
        EPMListenerService instance = new EPMListenerService();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new WCListenerEventListener(getConceptualClassname());
        //版本控制的检入监听事件
        getManagerService().addEventListener(listener,
                VersionControlServiceEvent.generateEventKey(VersionControlServiceEvent.NEW_VERSION));//新版本

    }

    // 内部类里面进行监听的逻辑操作
    class WCListenerEventListener extends ServiceEventListenerAdapter {
        public WCListenerEventListener(String manager_name) {
            super(manager_name);
        }

        @Override
        public void notifyVetoableEvent(Object event) throws Exception {
            System.out.println("准备监听cad部件修订");
            if (!(event instanceof VersionControlServiceEvent)) {

                return;
            }
            System.out.println("开始监听cad部件修订");
//

            VersionControlServiceEvent pmEvent = (VersionControlServiceEvent) event;
            Object target = pmEvent.getEventTarget();


//            如果返回 TRUE 则表示对象是升小版本因为它需要一个检入操作
//            如果返回 FALSE 则表示对象是升大版本因为它不需要一个检出-检入操作

            //监听EPM对象升级大版本
            if (target instanceof EPMDocument) {
                epm = (EPMDocument) target;
                String EPMState = epm.getLifeCycleState().toString();
                String version = epm.getVersionIdentifier().getValue();
                System.out.println("cad状态为:" + EPMState);


                //如果状态为生产变更  设计变更 清空一些IBA属性
                if (target instanceof EPMDocument && !WorkInProgressHelper.isCheckedOut((Workable) target)  ){

                    if (clear_state_list.contains(EPMState)) {
                        System.out.println("开始清空指定属性");
                        System.out.println("epm新版为:" + epm.getVersionIdentifier().getValue());
                        System.out.println("epm新版编号为:" + epm.getNumber());

                        setIBA(epm, PropertiesUtil.getValueByKey("ext.alphai.check_by"), ""); // 审批人
                        setIBA(epm, PropertiesUtil.getValueByKey("ext.alphai.check_date"), ""); // 审批时间
                        setIBA(epm, PropertiesUtil.getValueByKey("ext.alphai.approved_by"), ""); // 批准人
                        setIBA(epm, PropertiesUtil.getValueByKey("ext.alphai.approved_date"), "");//批准时间
                        setIBA(epm, PropertiesUtil.getValueByKey("ext.alphai.cdrawn_by"), ""); // 设计人
                        setIBA(epm, PropertiesUtil.getValueByKey("ext.alphai.cdrawn_date"), ""); // 设计时间
                        System.out.println("清空指定属性end");
                    }

                    if ("RELEASED".equals(EPMState) && "00".equals(version)) {
                        System.out.println("监听到00已发布状态");
                        //设置状态
                        changEPMState(epm,EPMState);
                    }



                }
            }
            System.out.println("监听cad部件修订end");

        }
    }


    public static void setIBA(Persistable persistable, String ibaName, String value) throws WTException {
        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        normalizedObject.set(ibaName, value);
        persistable = normalizedObject.apply();
        PersistenceHelper.manager.modify(persistable);
    }

    public static String getIBA(Persistable persistable, String ibaName) throws WTException {
        Locale locale = Locale.getDefault();
        LWCNormalizedObject normalizedObject = new LWCNormalizedObject(persistable, null, locale, new UpdateOperationIdentifier());
        normalizedObject.load(ibaName);
        return normalizedObject.get(ibaName) == null ? null : normalizedObject.get(ibaName).toString();
    }
    /**
     * 修改EPM生命周期状态
     *
     * @param   epm
     * @param   state
     * @return String
     * @throws WTPropertyVetoException
     * @throws WTException
     */
    public static String changEPMState(EPMDocument epm, String state) throws WTPropertyVetoException, WTException {
        String message = "";
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();

            epm = (EPMDocument) wt.lifecycle.LifeCycleHelper.service.setLifeCycleState((wt.lifecycle.LifeCycleManaged) epm,
                    State.toState(state));


            PersistenceHelper.manager.refresh(epm);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return message;
    }
}
