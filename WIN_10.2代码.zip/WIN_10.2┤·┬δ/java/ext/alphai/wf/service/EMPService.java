package ext.alphai.wf.service;
import wt.content.*;
import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;

/**
 * ClassName: EMPService <br/>
 * Description: <br/>
 * date: 2024/7/12 13:39<br/>
 *
 * @author lenovo<br />
 * @since JDK 1.8
 */
public class EMPService {


    /**
     * 根据编号获取对象
     *
     * @param number
     * @param queryClass
     * @return Object
     */
    @SuppressWarnings("deprecation")
    public static Object getObjByNumber(String number, Class queryClass) {
        try {
            if (number.isEmpty()) {
                return null;
            }
            QuerySpec qs = new QuerySpec(queryClass);
            qs.appendWhere(new SearchCondition(queryClass, "master>number", SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                return qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 根据EPMDocument对象获取ApplicationData
     * @param EPMDoc
     * @return
     * @throws WTException
     * @throws PropertyVetoException
     */
    public static ApplicationData findPrimary(EPMDocument EPMDoc) throws WTException, PropertyVetoException
    {
        System.out.println("Starting findPrimary");
        System.out.println("==========");
        ApplicationData primaryNotFound = null;
        FormatContentHolder documentWithContents= (EPMDocument) ContentHelper.service.getContents(EPMDoc);
        @SuppressWarnings("unchecked")
        Vector<ContentItem> vector = ContentHelper.getContentList(documentWithContents);
        vector.addElement(ContentHelper.getPrimary(documentWithContents));
        for (int i=0; i<vector.size(); i++)
        {
            if (vector.elementAt(i) instanceof ApplicationData)
            {
                ApplicationData appData = (ApplicationData)vector.elementAt(i);
                if(appData.getFileName().equals("{$CAD_NAME}")) {
                    System.out.println("found primary content");
                    appData.setFileName(EPMDoc.getCADName());
                    System.out.println("Renamed file: " + appData.getFileName());
                    System.out.println("pass back to createZipList");
                    return appData;
                }
            }
        }
        return primaryNotFound;
    }

    /**
     * 检查是否存在同名的旧文件
     * @param file
     * @return
     */
    public static void checkExcelExists(File file, ApplicationData data) throws Exception {
        if (file.isFile()) {
            file.deleteOnExit();
        }
        // 输入流
        InputStream is = ContentServerHelper.service.findContentStream(data);
        // 输出流到文件
        OutputStream os = new FileOutputStream(file);
        byte[] buffer = new byte[1024];
        int length;

        while ((length = is.read(buffer)) > 0) {
            os.write(buffer, 0, length);
        }
        // 关闭流
        os.close();
        is.close();
    }

}
