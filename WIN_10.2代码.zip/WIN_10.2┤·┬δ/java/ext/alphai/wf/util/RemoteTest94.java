package ext.alphai.wf.util;

import wt.epm.EPMDocument;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.util.WTException;
import wt.util.WTRuntimeException;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

import static ext.alphai.wf.service.EMPService.getObjByNumber;

/**
 * 由于Windchill系统重启过慢，所以这个类是用来进行远程方法调用的类 这个方法所调用
 * 这里在main方法中调用反射方法，然后调用windchill的RemoteMethodServer来执行反射中的方法
 * <p>
 * 使用前提：被调用的方法必须实现 wt.method.RemoteAccess, java.io.Serializable这两个接口
 * <p>
 * 如何调用其他方法： 这里调用了同级目录下VersionUtil类中的方法getVersion 这个方法是用来获取部件的版本
 * 对于入参这里使用ReferenceFactory来获取系统中真实存在的部件对象
 * <p>
 * invoke方法是用来调用远程方法的真正执行方法， 这里有5个参数 分别为
 * <p>
 * MethodName 被调用方法的方法名, className 被调用方法的类名称 instance 执行方法的对象这里为null cla
 * 传入反射方法变量的类（这里的类型必须是所调用方法对应的类型，不能是任何子类已实现接口等） obj 传入反射方法变量的对象
 *
 * @author dz
 */
public class RemoteTest94 implements RemoteAccess, Serializable {

    private static final long serialVersionUID = 1L;

    public static void main(String[] args) throws WTRuntimeException, WTException {
//		ReferenceFactory rf = new ReferenceFactory();
//		WTDocument doc = (WTDocument) rf.getReference("OR:wt.doc.WTDocument:1796110").getObject();
//		WTPart part = (WTPart) rf.getReference("OR:wt.part.WTPart:1939296").getObject();
//		EPMDocument epm = (EPMDocument) rf.getReference("OR:wt.epm.EPMDocument:1833683").getObject();
//		WTChangeRequest2 ecr = (WTChangeRequest2) rf.getReference("OR:wt.change2.WTChangeRequest2:2113629").getObject();
//		WorkItem wi = (WorkItem) rf.getReference("OR:wt.workflow.work.WorkItem:2538761").getObject();
//		PlanActivity planActivity = (PlanActivity) rf
//				.getReference("OR:com.ptc.projectmanagement.plan.PlanActivity:849396").getObject();
        String str = (String) invoke("process", RemoteTest94.class.getName(), null, new Class[]{}, new Object[]{});


    }

    public static Object invoke(String methodName, String className, Object instance, Class[] cla, Object[] obj) {
        RemoteMethodServer rms = RemoteMethodServer.getDefault();
        rms.setUserName("wcadmin");
        rms.setPassword("wcadmin");
        try {
            return rms.invoke(methodName, className, instance, cla, obj);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String process() {
        try {

//            //被升级对象

//            System.out.println(epm.getCADName());
//            IBAUtil ibaUtil = new IBAUtil(epm);
//            System.out.println("改前审阅者"+ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("ext.alphai.check_by")));
//            ibaUtil.setIBAAttribute4AllType(epm,PropertiesUtil.getValueByKey("ext.alphai.check_by"),"test2");
////            ibaUtil.setIBAValue(PropertiesUtil.getValueByKey("ext.alphai.check_by"),"test1");
//            System.out.println("改后审阅者"+ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("ext.alphai.check_by")));

//            String json = "{\"审阅\":[[\"will\",\"2024.07.29\",\"will\",\" \"]],\"批准\":[[\"will\",\"2024.07.29\",\"will\",\" \"]]}";

//            LifeCycleState state = epm.getState();
//            System.out.println("生命周期="+state.getConceptualClassname());
//            System.out.println("生命周期英文="+state.getState().getDisplay(Locale.ENGLISH));
//            System.out.println("生命周期中文="+state.getState().getDisplay(Locale.CHINA));
//            System.out.println("生命周期="+state.getLifeCycleId());
//
//
//            String englishState = epm.getLifeCycleState().getDisplay(Locale.ENGLISH);
//            System.out.println("生命周期中文="+englishState);


//            getOrderEpm(epm.getNumber(),)

            String number = "0000000028";
            EPMDocument epm = (EPMDocument)getObjByNumber(number, EPMDocument.class);
            System.out.println("cad"+epm.getIterationDisplayIdentifier().toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


}
