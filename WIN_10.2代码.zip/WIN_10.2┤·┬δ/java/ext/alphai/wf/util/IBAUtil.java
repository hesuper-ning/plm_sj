/*
 * Copyright (c) 2006-2009 JW Innovation Software(Shen Zhen) Ltd..
 * Nanshan, ShenZhen, China
 * All rights reserved.
 *
 * @IBAUtil.java
 *
 * This software is the confidential and proprietary information of JWIS. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with JWIS.
 */
package ext.alphai.wf.util;

import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.PropertyHolderHelper;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.sun.xml.registry.uddi.bindings_v2_2.BusinessEntity;
import org.apache.commons.lang.StringUtils;
import org.jboss.resteasy.logging.Logger;
import wt.fc.*;
import wt.iba.constraint.ConstraintGroup;
import wt.iba.constraint.IBAConstraintException;
import wt.iba.definition.*;
import wt.iba.definition.litedefinition.*;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.*;
import wt.iba.value.litevalue.*;
import wt.iba.value.service.IBAValueDBService;
import wt.iba.value.service.IBAValueHelper;
import wt.iba.value.service.LoadValue;
import wt.iba.value.service.StandardIBAValueService;
import wt.lite.AbstractLiteObject;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.pom.PersistenceException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.session.SessionHelper;
import wt.units.service.QuantityOfMeasureDefaultView;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.wip.NonLatestCheckoutException;
import wt.vc.wip.WorkInProgressException;
import wt.vc.wip.WorkInProgressHelper;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.*;

/**
 * IBA Utility Class
 * 
 * @author wide @version：2020-10-23
 */
public class  IBAUtil {

	/**
	 * @Description LOG:Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(IBAUtil.class);

	/**
	 * @Description ibaContainer:Hashtable
	 */
	Hashtable ibaContainer;

	/**
	 * @Description ibaOrigContainer:Hashtable
	 */
	Hashtable ibaOrigContainer;

	Persistable persistable;
	/**
	 * @Description UNITS:String
	 */
	final static String UNITS = "SI";

	/**
	 * @Description VERBOSE:boolean
	 */
	boolean VERBOSE = false;

	/**
	 * Can not be called directly by the end user
	 */
	public IBAUtil() {
		ibaContainer = new Hashtable();
	}

	/**
	 * The only constrator can be called by the end user
	 * 
	 * @param ibaHolder IBAHolder
	 * @throws WTException
	 */
	public IBAUtil(IBAHolder ibaHolder) throws WTException {
		super();
		try {
			initializeIBAValue(ibaHolder);
			persistable = (Persistable) ibaHolder;
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 *
	 * @description
	 * @date 2009-4-13 上午10:51:21
	 * @return Enumeration
	 */
	public Enumeration getAttributeDefinitions() {
		return ibaContainer.keys();
	}

	/**
	 *
	 * @description
	 * @date 2009-4-13 上午10:51:29
	 * @throws WTException
	 * @throws WTPropertyVetoException
	 */
	public void removeAllAttributes() throws WTException, WTPropertyVetoException {
		ibaContainer.clear();
	}

	/**
	 *
	 * @description
	 * @date 2009-4-13 上午10:52:30
	 * @param name String
	 * @throws WTException
	 * @throws WTPropertyVetoException
	 */
	public void removeAttribute(String name) throws WTException, WTPropertyVetoException {
		ibaContainer.remove(name);
	}

	/**
	 * return single IBA value
	 *
	 * @param name String
	 * @return String
	 */
	public String getIBAValue(String name) {
		String value = "";
		try {
			if (ibaContainer.get(name) != null) {
				AbstractValueView theValue = (AbstractValueView) ((Object[]) ibaContainer.get(name))[1];
				value = (IBAValueUtility.getLocalizedIBAValueDisplayString(theValue,
						SessionHelper.manager.getLocale()));
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * return multiple IBA values
	 *
	 * @param name String
	 * @return Vector
	 */
	public Vector getIBAValues(String name) {
		Vector vector = new Vector();
		try {
			if (ibaContainer.get(name) != null) {
				Object[] objs = (Object[]) ibaContainer.get(name);
				for (int i = 1; i < objs.length; i++) {
					AbstractValueView theValue = (AbstractValueView) objs[i];
					vector.addElement(IBAValueUtility.getLocalizedIBAValueDisplayString(theValue,
							SessionHelper.manager.getLocale()));
				}
			}
		} catch (WTException e) {
			LOGGER.info("get iba  values error:" + e);
		}
		return vector;
	}

	/**
	 * return ALL IBA values
	 *
	 * @return Hashtable
	 */
	public Hashtable getAllIBAValues() {
		return ibaContainer;
	}





	/**
	 *
	 * @description
	 * @date 2009-4-13 上午11:35:15
	 * @param name     String
	 * @param ibaValue AbstractValueView
	 * @return AbstractValueView
	 * @throws IBAValueException
	 */
	private AbstractValueView getOriginalReferenceValue(String name, AbstractValueView ibaValue)
			throws IBAValueException {
		Object[] objs = (Object[]) ibaOrigContainer.get(name);
		if (objs != null && (ibaValue instanceof ReferenceValueDefaultView)) {
			int businessvaluepos = 1;
			for (businessvaluepos = 1; businessvaluepos < objs.length; businessvaluepos++) {
				if (((AbstractValueView) objs[businessvaluepos]).compareTo(ibaValue) == 0) {
					ibaValue = (AbstractValueView) objs[businessvaluepos];
					break;
				}
			}
		}
		return ibaValue;
	}

	/**
	 * @author wide
	 * @description
	 * @date 2009-4-13 上午11:35:54
	 * @param name String
	 * @return AttributeDefDefaultView
	 * @throws WTException
	 */
	public AttributeDefDefaultView getDefDefaultView(String name) throws WTException {
		AttributeDefDefaultView theDef = null;
		Object[] obj = (Object[]) ibaContainer.get(name);
		if (obj != null) {
			theDef = (AttributeDefDefaultView) obj[0];
		} else {
			theDef = getAttributeDefinition(name);
		}
		if (theDef == null) {
			LOGGER.info("IBA name:" + name + " is illegal. Add IBA value failed!!");
			throw new WTException("Trace.. name = " + name + " not existed.");
		}
		return theDef;
	}









	/**
	 *
	 * @description
	 * @date 2009-4-13 上午11:36:48
	 * @param sourceDef     AttributeDefDefaultView
	 * @param sourceValue   AbstractValueView
	 * @param businessDef   AttributeDefDefaultView
	 * @param businessValue AbstractValueView
	 * @return AbstractValueView
	 * @throws WTPropertyVetoException
	 * @throws WTException
	 */
	private AbstractValueView setDependency(AttributeDefDefaultView sourceDef, AbstractValueView sourceValue,
			AttributeDefDefaultView businessDef, AbstractValueView businessValue)
			throws WTPropertyVetoException, WTException {
		String sourcename = sourceDef.getName();
		String businessname = businessDef.getName();

		if (businessValue == null) {
			throw new WTException("This Business Entity:" + businessname + " value doesn't exist in System Business "
					+ "Entity. Add IBA dependancy failed!!");
		}
		Object[] businessobj = (Object[]) ibaContainer.get(businessname);
		if (businessobj == null) {
			throw new WTException("Part IBA:" + businessname + " Value is null. Add IBA dependancy failed!!");
		}
		int businessvaluepos = 1;
		for (businessvaluepos = 1; businessvaluepos < businessobj.length; businessvaluepos++) {
			if (((AbstractValueView) businessobj[businessvaluepos]).compareTo(businessValue) == 0) {
				businessValue = (AbstractValueView) businessobj[businessvaluepos];
				break;
			}
		}
		if (businessvaluepos == businessobj.length) {
			throw new WTException(
					"This Business Entity:" + businessname + " value:" + businessValue.getLocalizedDisplayString()
							+ " is not existed in Part IBA values. " + "Add IBA dependancy failed!!");
		}

		if (!(businessValue instanceof ReferenceValueDefaultView)) {
			throw new WTException(
					"This Business Entity:" + businessname + " value:" + businessValue.getLocalizedDisplayString()
							+ " is not a ReferenceValueDefaultView. " + "Add IBA dependancy failed!!");
		}
		((AbstractContextualValueDefaultView) sourceValue)
				.setReferenceValueDefaultView((ReferenceValueDefaultView) businessValue);
		if (VERBOSE)
			LOGGER.info("ref obj=" + ((AbstractContextualValueDefaultView) sourceValue).getReferenceValueDefaultView()
					.getLocalizedDisplayString());
		if (VERBOSE)
			LOGGER.info("ref key="
					+ ((AbstractContextualValueDefaultView) sourceValue).getReferenceValueDefaultView().getKey());
		if (VERBOSE)
			LOGGER.info("This IBA:" + sourcename + " value:" + sourceValue.getLocalizedDisplayString()
					+ " add dependancy with Business Entity:" + businessname + " value:"
					+ businessValue.getLocalizedDisplayString() + " successfully with state=" + sourceValue.getState()
					+ " !!");
		return sourceValue;
	}

	/**
	 * initializePart() with this signature is designed to pre-populate values from
	 * an existing IBA holder.
	 * 
	 * @description
	 * @date 2009-4-13 上午11:39:44
	 * @param ibaHolder ibaHolder
	 * @throws WTException
	 * @throws RemoteException
	 */
	private void initializeIBAValue(IBAHolder ibaHolder) throws WTException, RemoteException {
		ibaContainer = new Hashtable();
		ibaOrigContainer = new Hashtable();
		ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null, SessionHelper.manager.getLocale(),
				null);
		DefaultAttributeContainer theContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (theContainer != null) {
			AttributeDefDefaultView[] theAtts = theContainer.getAttributeDefinitions();
			for (int i = 0; i < theAtts.length; i++) {
				AbstractValueView[] theValues = theContainer.getAttributeValues(theAtts[i]);
				if (theValues != null) {
					// Add by Somesh
					Object[] temp = new Object[theValues.length + 1];
					temp[0] = theAtts[i];
					for (int j = 1; j <= theValues.length; j++) {
						temp[j] = theValues[j - 1];
					}
					// End Add by Somesh
					ibaContainer.put(theAtts[i].getName(), temp);
					ibaOrigContainer.put(theAtts[i].getName(), temp);
				}
			}
		}
		// LOG.info("initializeIBAValue : ibaContainer = " +
		// ibaContainer);
		// LOG.info("initializeIBAValue : ibaOrigContainer = " +
		// ibaOrigContainer);
	}


	/**
	 *
	 * @description
	 * @date 2009-4-13 上午11:41:26
	 * @param attributecontainer DefaultAttributeContainer
	 * @return DefaultAttributeContainer
	 */
	private DefaultAttributeContainer removeCSMConstraint(DefaultAttributeContainer attributecontainer) {
		Object obj = attributecontainer.getConstraintParameter();
		if (obj == null) {
			obj = new String("CSM");
		} else if (obj instanceof Vector) {
			((Vector) obj).addElement(new String("CSM"));
		} else {
			Vector vector1 = new Vector();
			vector1.addElement(obj);
			obj = vector1;
			((Vector) obj).addElement(new String("CSM"));
		}
		try {
			attributecontainer.setConstraintParameter(obj);
		} catch (WTPropertyVetoException wtpropertyvetoexception) {
			wtpropertyvetoexception.printStackTrace();

		}
		return attributecontainer;
	}






	/**
	 *
	 * @description For dependency used.
	 * @date 2009-4-13 上午11:45:05
	 * @param abstractvalueview  AbstractValueView
	 * @param abstractvalueview1 AbstractValueView
	 * @return AbstractValueView
	 * @throws IBAValueException
	 */
	AbstractValueView cloneReferenceValueDefaultView(AbstractValueView abstractvalueview,
			AbstractValueView abstractvalueview1) throws IBAValueException {
		if (abstractvalueview instanceof AbstractContextualValueDefaultView) {
			if (VERBOSE) {
				LOGGER.info(abstractvalueview1.getLocalizedDisplayString() + ":"
						+ abstractvalueview.getLocalizedDisplayString());
				if (((AbstractContextualValueDefaultView) abstractvalueview1).getReferenceValueDefaultView() != null)
					System.out.println("Key before set=" + ((AbstractContextualValueDefaultView) abstractvalueview1)
							.getReferenceValueDefaultView().getKey());
			}

			try {
				((AbstractContextualValueDefaultView) abstractvalueview1).setReferenceValueDefaultView(
						((AbstractContextualValueDefaultView) abstractvalueview).getReferenceValueDefaultView());
			} catch (WTPropertyVetoException wtpropertyvetoexception) {
				throw new IBAValueException("can't get ReferenceValueDefaultView from the Part in the database");
			}
			if (VERBOSE) {
				if (((AbstractContextualValueDefaultView) abstractvalueview1).getReferenceValueDefaultView() != null)
					System.out.println("Key after set=" + ((AbstractContextualValueDefaultView) abstractvalueview1)
							.getReferenceValueDefaultView().getKey());
			}

		}
		return abstractvalueview1;
	}



	/**
	 * This method is a "black-box": pass in a string, like "Electrical/Resistance/
	 * ResistanceRating" and get back a IBA definition object.
	 *
	 * @param ibaPath String
	 * @return AttributeDefDefaultView
	 */
	public AttributeDefDefaultView getAttributeDefinition(String ibaPath) {

		AttributeDefDefaultView ibaDef = null;
		try {
			ibaDef = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaPath);
			if (ibaDef == null) {
				AbstractAttributeDefinizerView ibaNodeView = DefinitionLoader.getAttributeDefinition(ibaPath);
				if (ibaNodeView != null)
					ibaDef = IBADefinitionHelper.service.getAttributeDefDefaultView((AttributeDefNodeView) ibaNodeView);
			}
		} catch (Exception wte) {
			wte.printStackTrace();
		}

		return ibaDef;
	}

	/**
	 *
	 * @description
	 * @date 2009-4-13 上午11:46:00
	 * @param unitdefview UnitDefView
	 * @return String
	 */
	public static String getDisplayUnits(UnitDefView unitdefview) {
		return getDisplayUnits(unitdefview, UNITS);
	}

	/**
	 *
	 * @description
	 * @date 2009-4-13 上午11:46:10
	 * @param unitdefview UnitDefView
	 * @param s           String
	 * @return String
	 */
	public static String getDisplayUnits(UnitDefView unitdefview, String s) {
		QuantityOfMeasureDefaultView quantityofmeasuredefaultview = unitdefview.getQuantityOfMeasureDefaultView();
		String s1 = quantityofmeasuredefaultview.getBaseUnit();
		if (s != null) {
			String s2 = unitdefview.getDisplayUnitString(s);
			if (s2 == null)
				s2 = quantityofmeasuredefaultview.getDisplayUnitString(s);
			if (s2 == null)
				s2 = quantityofmeasuredefaultview.getDefaultDisplayUnitString(s);
			if (s2 != null)
				s1 = s2;
		}
		if (s1 == null)
			return "";
		else
			return s1;
	}



	/**
	 * Please refer to the method "getIBAHolderClassName" of class
	 * "wt.csm.constraint.CSMConstraintFactory"
	 *
	 * @param ibaholder IBAHolder
	 * @return String
	 */
	private static String getIBAHolderClassName(IBAHolder ibaholder) {
		String s = null;
		if (ibaholder instanceof AbstractLiteObject)
			s = ((AbstractLiteObject) ibaholder).getHeavyObjectClassname();
		else
			s = ibaholder.getClass().getName();
		return s;
	}



	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 * 
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static StringDefinition findStringDefinition(String attributeName) throws WTException {
		StringDefinition sDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(StringDefinition.class, true);
		WhereExpression where = new SearchCondition(StringDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof StringDefinition) {
					sDef = (StringDefinition) obj;
				}
			}
		}
		return sDef;
	}

	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 * 
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static FloatDefinition findFloatDefinition(String attributeName) throws WTException {
		FloatDefinition fDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(FloatDefinition.class, true);
		WhereExpression where = new SearchCondition(FloatDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof FloatDefinition) {
					fDef = (FloatDefinition) obj;
				}
			}
		}
		return fDef;
	}

	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 * 
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static TimestampDefinition findTimestampDefinition(String attributeName) throws WTException {
		TimestampDefinition fDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(TimestampDefinition.class, true);
		WhereExpression where = new SearchCondition(TimestampDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof TimestampDefinition) {
					fDef = (TimestampDefinition) obj;
				}
			}
		}
		return fDef;
	}

	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 * 
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static UnitDefinition findUnitDefinition(String attributeName) throws WTException {
		UnitDefinition fDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(UnitDefinition.class, true);
		WhereExpression where = new SearchCondition(UnitDefinition.class, "name", SearchCondition.EQUAL, attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof UnitDefinition) {
					fDef = (UnitDefinition) obj;
				}
			}
		}
		return fDef;
	}

	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 * 
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static URLDefinition findURLDefinition(String attributeName) throws WTException {
		URLDefinition fDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(URLDefinition.class, true);
		WhereExpression where = new SearchCondition(URLDefinition.class, "name", SearchCondition.EQUAL, attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof URLDefinition) {
					fDef = (URLDefinition) obj;
				}
			}
		}
		return fDef;
	}

	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 * 
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static IntegerDefinition findIntDefinition(String attributeName) throws WTException {
		IntegerDefinition sDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(IntegerDefinition.class, true);
		WhereExpression where = new SearchCondition(IntegerDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof IntegerDefinition) {
					sDef = (IntegerDefinition) obj;
				}
			}
		}
		return sDef;
	}

	/**
	 * 根据属性名称获取其软属性对象 by Wide
	 * 
	 * @param Attribute Name
	 * @return BooleanDefinition
	 * @throws WTException
	 */
	public static BooleanDefinition findBooleanDefinition(String attributeName) throws WTException {
		BooleanDefinition sDef = null;
		QueryResult result = null;
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		int index = qs.addClassList(BooleanDefinition.class, true);
		WhereExpression where = new SearchCondition(BooleanDefinition.class, "name", SearchCondition.EQUAL,
				attributeName);
		qs.appendWhere(where, new int[] { index });
		result = PersistenceHelper.manager.find((StatementSpec) qs);
		while (result != null && result.hasMoreElements()) {
			Object[] objs = (Object[]) result.nextElement();
			for (Object obj : objs) {
				if (obj instanceof BooleanDefinition) {
					sDef = (BooleanDefinition) obj;
				}
			}
		}
		return sDef;
	}

	/**
	 * 获取软属性对象
	 * 
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public StringValue getStringValueByName(String attributeName) throws WTException {
		StringValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			StringValueDefaultView stringvaluedefaultview = (StringValueDefaultView) view;
			ObjectIdentifier objectidentifier = stringvaluedefaultview.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (StringValue) persistable;
		}
		return value;
	}

	private Persistable getValueByName(String attributeName) throws WTException {
		Persistable value = null;
		try {
			Object[] objs = (Object[]) ibaContainer.get(attributeName);
			if (objs != null && objs.length > 0) {

				AbstractValueView view = (AbstractValueView) objs[1];
				view.getObjectID();
				ObjectIdentifier objectidentifier = (ObjectIdentifier) view.getObjectID();
				value = ObjectReference.newObjectReference(objectidentifier).getObject();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new WTException(e);
		}
		return value;
	}

	/**
	 * 获取软属性对象
	 * 
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public FloatValue getFloatValueByName(String attributeName) throws WTException {
		FloatValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			FloatValueDefaultView floatvaluedefaultview = (FloatValueDefaultView) view;

			ObjectIdentifier objectidentifier = floatvaluedefaultview.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (FloatValue) persistable;
		}
		return value;
	}

	/**
	 * 获取时间格式的数据
	 * 
	 * @param attributeName
	 * @return
	 * @throws WTException
	 */
	public TimestampValue getTimestampValue(String attributeName) throws WTException {
		TimestampValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {
			AbstractValueView view = (AbstractValueView) objs[1];
			if (view instanceof TimestampValueDefaultView) {
				TimestampValueDefaultView tsvaluedefaultview = (TimestampValueDefaultView) view;
				ObjectIdentifier objectidentifier = tsvaluedefaultview.getObjectID();
				Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
				if (persistable instanceof TimestampValue) {
					value = (TimestampValue) persistable;
				}
			}
		}
		return value;
	}

	/**
	 * 获取软属性对象
	 * 
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public URLValue getURLValueByName(String attributeName) throws WTException {
		URLValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			URLValueDefaultView urlValuedefaultview = (URLValueDefaultView) view;

			ObjectIdentifier objectidentifier = urlValuedefaultview.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (URLValue) persistable;

		}
		return value;
	}

	/**
	 * 获取软属性对象
	 * 
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public IntegerValue getIntValueByName(String attributeName) throws WTException {
		IntegerValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			IntegerValueDefaultView intvalue = (IntegerValueDefaultView) view;

			ObjectIdentifier objectidentifier = intvalue.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (IntegerValue) persistable;
		}
		return value;
	}

	/**
	 * 获取软属性对象
	 * 
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public BooleanValue getBooleanValueByName(String attributeName) throws WTException {
		BooleanValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			BooleanValueDefaultView intvalue = (BooleanValueDefaultView) view;

			ObjectIdentifier objectidentifier = intvalue.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (BooleanValue) persistable;
		}
		return value;
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBATimeAttribute(IBAHolder holder, String typeName, Object value) throws WTException {
		try {
			if (value instanceof Timestamp) {
				Timestamp ts = (Timestamp) value;
				IBAUtil util = new IBAUtil(holder);
				TimestampDefinition sd = findTimestampDefinition(typeName);
				if (sd != null) {
					TimestampValue sv = util.getTimestampValue(typeName);
					if (sv != null) {
						LOGGER.debug("对象[" + holder.toString() + "]属性[" + sd.getName() + "]旧值为[" + sv.getValue() + "]");
						if (value == null) {
							PersistenceHelper.manager.delete(sv);
						} else {
							sv.setValue(ts);
							PersistenceServerHelper.manager.update(sv);
						}
					} else {
						sv = TimestampValue.newTimestampValue(sd, holder, ts);
						PersistenceServerHelper.manager.insert(sv);
					}
				}

			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAUnitAttribute(IBAHolder holder, String typeName, Object value) throws WTException {
		try {
			if (value instanceof Double) {
				double f = (double) value;
				IBAUtil util = new IBAUtil(holder);
				UnitDefinition sd = findUnitDefinition(typeName);
				if (sd != null) {
					UnitValue sv = util.getUnitFloatValueByName(typeName);
					if (sv != null) {
						LOGGER.debug("对象[" + holder.toString() + "]属性[" + sd.getName() + "]旧值为[" + sv.getValue() + "]");
						if (value == null) {
							PersistenceHelper.manager.delete(sv);
						} else {
							sv.setValue(f);
							PersistenceServerHelper.manager.update(sv);
						}
					} else {
						int paramInt = 0;
						String t = Double.toString(f);
						if (t.indexOf(".") > -1) {
							t = t.substring(t.indexOf(".") + 1, t.length());
							while (t.startsWith("0")) {
								t = t.replaceFirst("0", "");
							}
							paramInt = t.length();
						} else {
							// 没有小数点，则保留0位
							paramInt = 0;
						}
						sv = UnitValue.newUnitValue(sd, holder, f, paramInt);
						PersistenceServerHelper.manager.insert(sv);
					}
				}

			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 获取软属性对象
	 * 
	 * @return
	 * @throws WTException
	 * @throws WTRuntimeException
	 */
	public UnitValue getUnitFloatValueByName(String attributeName) throws WTException {
		UnitValue value = null;
		Object[] objs = (Object[]) ibaContainer.get(attributeName);
		if (objs != null && objs.length > 0) {

			AbstractValueView view = (AbstractValueView) objs[1];
			UnitValueDefaultView unitfloatvaluedefaultview = (UnitValueDefaultView) view;

			ObjectIdentifier objectidentifier = unitfloatvaluedefaultview.getObjectID();
			Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
			value = (UnitValue) persistable;
		}
		return value;
	}

	public static void setIBATimestampValue(IBAHolder obj, String ibaName, Timestamp newValue) throws WTException {
		String ibaClass = "wt.iba.definition.TimestampDefinition";
		try {
			IBAHolder ibaHolder = (IBAHolder) obj;
			DefaultAttributeContainer defaultattributecontainer = getContainer(ibaHolder);
			if (defaultattributecontainer == null) {
				defaultattributecontainer = new DefaultAttributeContainer();
				ibaHolder.setAttributeContainer(defaultattributecontainer);
			}
			TimestampValueDefaultView abstractvaluedefaultview = (TimestampValueDefaultView) getIBAValueView(
					defaultattributecontainer, ibaName, ibaClass);
			if (abstractvaluedefaultview != null) {
				abstractvaluedefaultview.setValue(newValue);

				defaultattributecontainer.updateAttributeValue(abstractvaluedefaultview);
			} else {
				AttributeDefDefaultView attributedefdefaultview = getAttributeDefinition(ibaName, false);
				TimestampValueDefaultView abstractvaluedefaultview1 = new TimestampValueDefaultView(
						(TimestampDefView) attributedefdefaultview, newValue);
				defaultattributecontainer.addAttributeValue(abstractvaluedefaultview1);
			}
			ibaHolder.setAttributeContainer(defaultattributecontainer);
			StandardIBAValueService.theIBAValueDBService.updateAttributeContainer(ibaHolder, null, null, null);
			ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, "CSM", null, null);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public static DefaultAttributeContainer getContainer(IBAHolder ibaHolder) throws WTException, RemoteException {
		ibaHolder = IBAValueHelper.service.refreshAttributeContainerWithoutConstraints(ibaHolder);
		DefaultAttributeContainer defaultattributecontainer = (DefaultAttributeContainer) ibaHolder
				.getAttributeContainer();
		return defaultattributecontainer;
	}

	public static AttributeDefDefaultView getAttributeDefinition(String s, boolean flag1) {
		AttributeDefDefaultView attributedefdefaultview = null;
		try {
			attributedefdefaultview = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(s);
			if (attributedefdefaultview == null) {
				AbstractAttributeDefinizerView abstractattributedefinizerview = DefinitionLoader
						.getAttributeDefinition(s);
				if (abstractattributedefinizerview != null)
					attributedefdefaultview = IBADefinitionHelper.service
							.getAttributeDefDefaultView((AttributeDefNodeView) abstractattributedefinizerview);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return attributedefdefaultview;
	}

	public static AbstractValueView getIBAValueView(DefaultAttributeContainer dac, String ibaName, String ibaClass)
			throws WTException {
		AbstractValueView aabstractvalueview[] = null;
		AbstractValueView avv = null;
		aabstractvalueview = dac.getAttributeValues();
		for (int j = 0; j < aabstractvalueview.length; j++) {
			String thisIBAName = aabstractvalueview[j].getDefinition().getName();
			String thisIBAValue = IBAValueUtility.getLocalizedIBAValueDisplayString(aabstractvalueview[j],
					Locale.CHINA);
			String thisIBAClass = (aabstractvalueview[j].getDefinition()).getAttributeDefinitionClassName();
			if (thisIBAName.equals(ibaName) && thisIBAClass.equals(ibaClass)) {
				avv = aabstractvalueview[j];
				break;
			}
		}
		return avv;
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAAttribute(IBAHolder holder, String typeName, String value) throws WTException {
		try {
			IBAUtil util = new IBAUtil(holder);
			StringDefinition sd = findStringDefinition(typeName);
			if (sd != null) {
				StringValue sv = util.getStringValueByName(typeName);
				if (sv != null) {
//					LOGGER.debug("对象["+holder.toString()+"]属性["+sd.getName()+"]旧值为["+sv.getValue()+"]");
					if (value == null || value.trim().length() == 0) {
						PersistenceHelper.manager.delete(sv);
					} else {
						sv.setValue(value);
						PersistenceServerHelper.manager.update(sv);
					}
				} else {
					sv = StringValue.newStringValue(sd, holder, value);
					PersistenceServerHelper.manager.insert(sv);
				}
			} else {
				LOGGER.error("属性[" + typeName + "]不存在");
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAAttributeNoUpdate(IBAHolder holder, String typeName, String value) throws WTException {
		try {
			IBAUtil util = new IBAUtil(holder);
			StringDefinition sd = findStringDefinition(typeName);
			if (sd != null) {
				StringValue sv = StringValue.newStringValue(sd, holder, value);
				PersistenceServerHelper.manager.insert(sv);
			} else {
				LOGGER.error("属性[" + typeName + "]不存在");
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	public static void deleteIBAAttribute(IBAHolder holder, String typeName) throws WTException {
		LOGGER.debug("删除对象[" + holder.toString() + "]属性[" + typeName + "]");
		StringDefinition sd = findStringDefinition(typeName);
		IBAUtil util = new IBAUtil(holder);
		if (sd != null) {
			StringValue sv = util.getStringValueByName(typeName);
			if (sv != null) {
				LOGGER.debug("对象[" + holder.toString() + "]属性[" + sd.getName() + "]旧值为[" + sv.getValue() + "]");
				PersistenceHelper.manager.delete(sv);
			}
		}
	}

	/**
	 * 记录多值的字符串软属性
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAAttributes(IBAHolder holder, String typeName, ArrayList<String> values)
			throws WTException {
		IBAUtil util = new IBAUtil(holder);
		/**
		 * 先删除所有的值
		 */
		Object[] objs = (Object[]) util.ibaContainer.get(typeName);
		if (objs != null && objs.length > 0) {
			for (int i = 1; i < objs.length; i++) {
				AbstractValueView view = (AbstractValueView) objs[i];
				StringValueDefaultView stringvaluedefaultview = (StringValueDefaultView) view;
				ObjectIdentifier objectidentifier = stringvaluedefaultview.getObjectID();
				Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
				StringValue theValue = (StringValue) persistable;
				PersistenceHelper.manager.delete(theValue);
			}
		}
		StringDefinition sd = findStringDefinition(typeName);
		/**
		 * 再增加传入的值，如果没有值，则清空软属性
		 */
		for (String value : values) {
			StringValue sv = StringValue.newStringValue(sd, holder, value);
			PersistenceServerHelper.manager.insert(sv);
		}
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAFloatAttribute(IBAHolder holder, String typeName, double value) throws WTException {
		try {
			LOGGER.debug("newIBAFloatAttribute type --->" + typeName + " value --->" + value);
			IBAUtil util = new IBAUtil(holder);
			FloatDefinition fd = findFloatDefinition(typeName);
			if (fd != null) {
				// 默认保留三位小数
				int paramInt = 3;
				if (value == 0 || value == 1) {
					paramInt = 0;
				} else {
					String t = Double.toString(value);
					if (t.indexOf(".") > -1) {
						t = t.substring(t.indexOf(".") + 1, t.length());
						while (t.startsWith("0")) {
							t = t.replaceFirst("0", "");
						}
						paramInt = t.length();
					} else {
						// 没有小数点，则保留0位
						paramInt = 0;
					}
				}
				FloatValue fv = util.getFloatValueByName(typeName);
				if (fv != null) {
					fv.setValue(value);
					fv.setPrecision(paramInt);
					PersistenceServerHelper.manager.update(fv);
					// PersistenceHelper.manager.save(sv);
				} else {
					fv = FloatValue.newFloatValue(fd, holder, value, paramInt);
					PersistenceServerHelper.manager.insert(fv);
				}
			} else {
				LOGGER.error("属性[" + typeName + "]不存在");
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAFloatAttribute(IBAHolder holder, String typeName, float value) throws WTException {
		try {
			LOGGER.debug("newIBAFloatAttribute type --->" + typeName + " value --->" + value);
			IBAUtil util = new IBAUtil(holder);
			FloatDefinition fd = findFloatDefinition(typeName);
			if (fd != null) {
				// 默认保留三位小数
				int paramInt = 3;
				if (value == 0 || value == 1) {
					paramInt = 0;
				} else {
					String t = Float.toString(value);
					if (t.indexOf(".") > -1) {
						t = t.substring(t.indexOf(".") + 1, t.length());
						while (t.startsWith("0")) {
							t = t.replaceFirst("0", "");
						}
						paramInt = t.length();
					} else {
						// 没有小数点，则保留0位
						paramInt = 0;
					}
				}
				FloatValue fv = util.getFloatValueByName(typeName);
				if (fv != null) {
					fv.setValue(value);
					fv.setPrecision(paramInt);
					PersistenceServerHelper.manager.update(fv);
				} else {
					fv = FloatValue.newFloatValue(fd, holder, value, paramInt);
					PersistenceServerHelper.manager.insert(fv);
				}
			} else {
				LOGGER.error("属性[" + typeName + "]不存在");
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @param des      : 连接描述
	 * @throws WTException
	 */
	public static void newIBAURLAttribute(IBAHolder holder, String typeName, String value, String des)
			throws WTException {
		try {
			LOGGER.debug("newIBAFloatAttribute type --->" + typeName + " value --->" + value);
			IBAUtil util = new IBAUtil(holder);
			URLDefinition fd = findURLDefinition(typeName);

			if (fd != null) {
				URLValue fv = util.getURLValueByName(typeName);
				if (fv != null) {
					if (value == null || value.trim().length() == 0) {
						PersistenceHelper.manager.delete(fv);
					} else {
						fv.setValue(value);
						PersistenceServerHelper.manager.update(fv);
					}
				} else {
					fv = URLValue.newURLValue(fd, holder, value, des);
					PersistenceServerHelper.manager.insert(fv);
				}
			} else {
				LOGGER.error("属性[" + typeName + "]不存在");
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBAIntAttribute(IBAHolder holder, String typeName, long value) throws WTException {
		try {
			LOGGER.debug("newIBAFloatAttribute type --->" + typeName + " value --->" + value);
			IBAUtil util = new IBAUtil(holder);
			IntegerDefinition fd = findIntDefinition(typeName);
			LOGGER.debug("获取到的属性类型为--->" + fd.getDisplayName());
			if (fd != null) {
				IntegerValue iv = util.getIntValueByName(typeName);
				if (iv != null) {
					iv.setValue(value);
					PersistenceServerHelper.manager.update(iv);
					// PersistenceHelper.manager.save(sv);
				} else {
					iv = IntegerValue.newIntegerValue(fd, holder, value);
					PersistenceServerHelper.manager.insert(iv);
				}
			} else {
				LOGGER.error("Can't find IntegerDefinition by name --->" + typeName);
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 设置对象软属性的值，但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void newIBABooleanAttribute(IBAHolder holder, String typeName, boolean value) throws WTException {
		try {
			LOGGER.debug("newIBAFloatAttribute type --->" + typeName + " value --->" + value);
			IBAUtil util = new IBAUtil(holder);
			BooleanDefinition fd = findBooleanDefinition(typeName);
			LOGGER.debug("获取到的属性类型为--->" + fd.getDisplayName());
			if (fd != null) {
				BooleanValue iv = util.getBooleanValueByName(typeName);
				if (iv != null) {
					iv.setValue(value);
					PersistenceServerHelper.manager.update(iv);
					// PersistenceHelper.manager.save(sv);
				} else {
					iv = BooleanValue.newBooleanValue(fd, holder, value);
					PersistenceServerHelper.manager.insert(iv);
				}
			} else {
				LOGGER.error("Can't find IntegerDefinition by name --->" + typeName);
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	/**
	 * 设置对象软属性的值（当值不存在时才写入，如果原来有，则保留原来的值），但不检出对象
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws WTException
	 */
	public static void insertIBAAttribute(IBAHolder holder, String typeName, String value) throws WTException {
		try {
			IBAUtil util = new IBAUtil(holder);
			StringDefinition sd = findStringDefinition(typeName);
			if (sd != null) {
				StringValue sv = util.getStringValueByName(typeName);
				if (sv == null) {
					sv = StringValue.newStringValue(sd, holder, value);
					PersistenceServerHelper.manager.insert(sv);
				}
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
	}

	public ArrayList<String> getStringValues(String key) throws WTException {
		ArrayList<String> list = new ArrayList<String>();
		String value = "";
		try {
			if (ibaContainer.get(key) != null) {
				Object[] objs = (Object[]) ibaContainer.get(key);
				for (int i = 1; i < objs.length; i++) {
					AbstractValueView theValue = (AbstractValueView) ((Object[]) ibaContainer.get(key))[i];
					value = (IBAValueUtility.getLocalizedIBAValueDisplayString(theValue,
							SessionHelper.manager.getLocale()));
					list.add(value);
				}

			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<StringValue> getAllStringValues(String key) throws WTException {
		ArrayList<StringValue> list = new ArrayList<StringValue>();
		try {
			if (ibaContainer.get(key) != null) {
				Object[] objs = (Object[]) ibaContainer.get(key);
				for (int i = 1; i < objs.length; i++) {
					AbstractValueView theValue = (AbstractValueView) ((Object[]) ibaContainer.get(key))[i];
					StringValueDefaultView stringvaluedefaultview = (StringValueDefaultView) theValue;
					ObjectIdentifier objectidentifier = stringvaluedefaultview.getObjectID();
					Persistable persistable = ObjectReference.newObjectReference(objectidentifier).getObject();
					StringValue value = (StringValue) persistable;
					list.add(value);
				}

			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 查询某个软属性值为指定值的所有对象(需过滤掉非最新小版本)
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	public static HashMap<String, IBAHolder> getIBAHolder(String key, String value) {
		HashMap<String, IBAHolder> holdMap = new HashMap<String, IBAHolder>();
		try {
			StringDefinition sd = findStringDefinition(key);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return holdMap;
	}

	/***
	 * 不检出修改IBA属性，且无需指定类型
	 * 
	 * @param holder
	 * @param typeName
	 * @param value
	 * @throws Exception
	 */
	public void setIBAAttribute4AllType(IBAHolder holder, String typeName, Object value) throws Exception {

		AttributeDefDefaultView view = getAttributeDefinition(typeName);
		if (view == null) {
			LOGGER.error("属性[" + typeName + "]不存在，不设置该IBA属性");
//			throw new Exception("属性[" + typeName + "]不存在");
			return;
		}
		LOGGER.debug("当前需设置的IBA内部名称为=>" + typeName + " 软属性类型为=>[" + view.getClass().getName() + "]" + " 值为=>[" + value
				+ "]");
		if (view instanceof FloatDefView) {
			if (value != null) {
				if (value instanceof Double) {
					IBAUtil.newIBAFloatAttribute(holder, typeName, (double) value);
				} else {
					double d = Double.parseDouble(value.toString());
					IBAUtil.newIBAFloatAttribute(holder, typeName, d);
				}
			}
		} else if (view instanceof StringDefView) {
			if (value != null) {
				if (value instanceof String) {
					IBAUtil.newIBAAttribute(holder, typeName, (String) value);
				} else {
					IBAUtil.newIBAAttribute(holder, typeName, value.toString());
				}
			}
		} else if (view instanceof URLDefView) {
			if (value != null) {
				IBAUtil.newIBAURLAttribute(holder, typeName, value.toString(), value.toString());
			} else {
				IBAUtil.newIBAURLAttribute(holder, typeName, "", "");
			}
		} else if (view instanceof IntegerDefView) {
			if (value != null) {
				if (value instanceof Integer) {
					IBAUtil.newIBAIntAttribute(holder, typeName, (Integer) value);
				} else {
					int it = Integer.parseInt(value.toString());
					IBAUtil.newIBAIntAttribute(holder, typeName, it);
				}
			}
		} else if (view instanceof TimestampDefView) {
			if (value != null) {
				if (value instanceof Date) {
					Date date = (Date) value;
					Timestamp ts = new Timestamp(date.getTime());
					IBAUtil.newIBATimeAttribute(holder, typeName, ts);
				} else {
					LOGGER.error("待导入的数据类型不是日期格式");
				}
			}
		} else if (view instanceof BooleanDefView) {
			if (value != null) {
				if (value instanceof Boolean) {
					IBAUtil.newIBABooleanAttribute(holder, typeName, (Boolean) value);
				} else {
					IBAUtil.newIBABooleanAttribute(holder, typeName, Boolean.parseBoolean((String) value));
				}
			}
		} else {
			LOGGER.error("失败，不支持的软属性类型");
		}
	}

	/***
	 * 检出，修改部件对象IBA值，检入
	 * 
	 * @param part
	 * @param dataMap
	 * @throws WTException
	 * @throws PersistenceException
	 * @throws WTPropertyVetoException
	 * @throws WorkInProgressException
	 * @throws NonLatestCheckoutException
	 */
	public void checkAndSetIBAValues(WTPart part, Map<String, String> dataMap) throws Exception {
		WTPart part_work = (WTPart) WorkInProgressHelper.service
				.checkout(part, WorkInProgressHelper.service.getCheckoutFolder(), null).getWorkingCopy();

		for (String key : dataMap.keySet()) {
			AttributeDefDefaultView view = getAttributeDefinition(key);
			if (view == null) {
				LOGGER.error("属性[" + key + "]不存在，不设置该IBA属性");
				continue;
			}

			if (dataMap.get(key) != null) {
				LOGGER.debug("Begin set IBA key " + key + " ====> " + dataMap.get(key));
				setIBAAttribute4AllType(part_work, key, dataMap.get(key));
			}
		}
		WorkInProgressHelper.service.checkin(part_work, null);
	}

	/***
	 * 获取全局属性在类型上的显示名称
	 * 
	 * @param ibaName
	 * @return
	 * @throws Exception
	 */
	public String getInternalDisplayName(String ibaName) throws Exception {
		String displayName = "";
		TypeIdentifier typeIden = TypeIdentifierUtility.getTypeIdentifier(persistable); // unsupported API
		TypeDefinitionReadView tdrv = TypeDefinitionServiceHelper.service.getTypeDefView(typeIden);
		if (tdrv != null) {
			AttributeDefinitionReadView attView = tdrv.getAttributeByName(ibaName); // att1 is attribute name
			if (attView != null) {
				displayName = PropertyHolderHelper.getDisplayName(attView, SessionHelper.manager.getLocale());
//				LOGGER.debug("display Name:" + displayName);
//				LOGGER.debug("attView Name:" + attView.getName());
			}
		}
		return displayName;
	}

	// 获取枚举值显示名称
	public static String getEnumDisplayValue(WTObject obj, String key) {
		String value = "";
		if (obj == null || StringUtils.isBlank(key)) {
			return value;
		}
		try {
			Locale locale = SessionHelper.manager.getLocale();
			com.ptc.core.lwc.server.PersistableAdapter pbo = new com.ptc.core.lwc.server.PersistableAdapter(obj, null,
					locale, new com.ptc.core.meta.common.DisplayOperationIdentifier());
			pbo.load(key);
			String codeOfAccountsValue = (String) pbo.get(key);
			com.ptc.core.meta.container.common.AttributeTypeSummary ats = pbo.getAttributeDescriptor(key);
			value = com.ptc.core.components.util.AttributeHelper.getEnumeratedEntryDisplayValue(codeOfAccountsValue,
					ats, locale);
//				System.out.println(codeOfAccountsValue+"<<<<"+key+"--3------->"+value);
		} catch (Exception e) {
//				e.printStackTrace();
		}
		return value;
	}

}