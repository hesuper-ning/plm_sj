package ext.alphai.wf;

import wt.fc.WTObject;
import wt.maturity.PromotionNotice;
import wt.util.WTException;

import java.util.Locale;

public class PNTarget {

    public static String decidePNStateRoute(WTObject primaryBusinessObject) throws WTException {
        PromotionNotice pn =  null;
        if(primaryBusinessObject instanceof PromotionNotice){
            pn = (PromotionNotice) primaryBusinessObject;
        }

        String displayState = pn.getMaturityState().getDisplay(Locale.CHINESE);

        if ("PROTOTYPE".equals(displayState)){
            return "原型";
        }else{
            return "已发布";
        }

    }

    public static String decidePNStateValue(WTObject primaryBusinessObject) throws WTException {
        PromotionNotice pn =  null;
        if(primaryBusinessObject instanceof PromotionNotice){
            pn = (PromotionNotice) primaryBusinessObject;
        }
        return pn.getMaturityState().getDisplay(Locale.CHINESE);
    }
}
