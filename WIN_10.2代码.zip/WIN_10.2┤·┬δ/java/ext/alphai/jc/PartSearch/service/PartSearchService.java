package ext.alphai.jc.PartSearch.service;

import ext.alphai.jc.PartSearch.controller.vo.ResponseInputVO;

import java.util.ArrayList;
import java.util.List;

public class PartSearchService {


    public static List<ResponseInputVO> getParamsInput(String classNodeName){

         List<ResponseInputVO> responseInputVOS = new ArrayList<>();






         return responseInputVOS;

    }
}
