package ext.alphai.jc.PartSearch.controller.vo;

import ext.alphai.jc.PartSearch.controller.Option;

import java.util.ArrayList;
import java.util.List;

public class ResponseInputVO {
    public String displayName;
    public String interName;
    public String type = "input";//默认是输入框
    public List<Option> option = new ArrayList<>();
}
