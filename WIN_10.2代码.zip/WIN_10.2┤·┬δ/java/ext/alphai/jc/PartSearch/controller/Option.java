package ext.alphai.jc.PartSearch.controller;

public class Option {
    public String displayName;
    public String interName;
}
