package ext.kingdeeERP.catl.part;


import ext.kingdeeERP.catl.part.util.PropertiesUtil;
import wt.part.WTPart;

public class Config {

    private static PropertiesUtil properties = PropertiesUtil.getInstance("config.properties");
    public static String getValue(String key) {
        return properties.getValueByKey(key);
    }

    public static String getClassification(WTPart part) {
        return properties.getValueByKey(part, "part.ibt.classification");
    }

    public static String getSupply(WTPart part) {
        return properties.getValueByKey(part, "part.iba.supply");
    }
}
