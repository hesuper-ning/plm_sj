package ext.kingdeeERP.catl.part.filter;

import com.ptc.core.components.forms.EditWorkableFormProcessor;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.meta.type.mgmt.common.TypeDefinitionDefaultView;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.netmarkets.util.beans.NmCommandBean;


import ext.exportBom.util.PropertiesUtil;
import ext.kingdeeERP.util.IBAUtil;
import wt.epm.util.EPMSoftTypeServerUtilities;
import wt.fc.PersistenceHelper;
import wt.part.Source;
import wt.part.WTPart;
import wt.type.TypeDefinitionReference;
import wt.util.WTException;

import java.util.List;
public class CucEditWorkableFormProcessor extends EditWorkableFormProcessor {
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("开始执行Processor");
//        WTPart wtPart = (list.size() > 0) ? (list.get(0).getObject() instanceof WTPart ?
//                (WTPart) list.get(0).getObject() : null)
//                : null;
        if (!list.isEmpty()) {
            for (ObjectBean objectBean : list) {
                Object object = objectBean.getObject();
                if (object instanceof WTPart) {
                    WTPart part = (WTPart) object;
                    IBAUtil ibaUtil = new IBAUtil(part);
                    String supply = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("part.iba.supply")); //打印供应商
                    Source source = part.getSource();    //源
                    String Classificaton = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("part.ibt.classification"));    //分类
                    String typeDisplayName = null;  //获取    电子部件
                    TypeDefinitionReference ref = (part).getTypeDefinitionReference();
                    //获取part二级值
                    try {
                        @SuppressWarnings("deprecation")
                        TypeDefinitionDefaultView view = EPMSoftTypeServerUtilities.getTypeDefinition(ref);
                        WTTypeDefinition definition = (WTTypeDefinition) PersistenceHelper.manager.refresh(view.getObjectID());
                        typeDisplayName = definition.getDisplayNameKey();
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    System.out.println("打印电子部件" + typeDisplayName);
                    System.out.println("打印源" + part.getSource());
                    System.out.println("打印分类" + Classificaton);
                    System.out.println("打印供应商" + supply);
                    boolean equals = "com.ptc.ElectricalPart".equals(typeDisplayName);
                    System.out.println("当前部件的子类型是否为ElectricalPart" + equals);

                    if ("com.ptc.ElectricalPart".equals(typeDisplayName) && "buy".equals(source.toString())) //是电子部件  且   源为WG
                    {
                        if (Classificaton.contains(".") && supply.isEmpty()) { //分类含有"."
                            throw new WTException("供应商需要填写！");
                        }

                    }

                }
            }
        }
        FormResult formResult = new FormResult(FormProcessingStatus.SUCCESS);
        return formResult;
    }
}
