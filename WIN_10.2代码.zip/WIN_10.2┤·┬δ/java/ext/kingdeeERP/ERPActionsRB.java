package ext.kingdeeERP;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.kingdeeERP.ERPActionsRB")
public class ERPActionsRB extends WTListResourceBundle {
	
	@RBEntry("sendPart2ERP")
	public static final String PRIVATE_CONSTANT_0 = "ERPWizard.sendPart2ERP.description";
	@RBEntry("sendPart2ERP")
	public static final String PRIVATE_CONSTANT_1 = "ERPWizard.sendPart2ERP.tooltip";
	@RBEntry("object_exclude.gif")
	public static final String PRIVATE_CONSTANT_3 = "ERPWizard.sendPart2ERP.icon";
	@RBEntry("sendBOM2ERP")
	public static final String PRIVATE_CONSTANT_4 = "ERPWizard.sendBOM2ERP.description";
	@RBEntry("sendBOM2ERP")
	public static final String PRIVATE_CONSTANT_5 = "ERPWizard.sendBOM2ERP.tooltip";
	@RBEntry("object_exclude.gif")
	public static final String PRIVATE_CONSTANT_6 = "ERPWizard.sendBOM2ERP.icon";
	
	@RBEntry("ERP Result Table")
	public static final String PRIVATE_CONSTANT_29 = "SAPWizard.masterDataResult.title";
	@RBEntry("ERP Result Table")
	public static final String PRIVATE_CONSTANT_30 = "SAPWizard.masterDataResult.description";
	@RBEntry("ERP Result Table")
	public static final String PRIVATE_CONSTANT_31 = "SAPWizard.masterDataResult.tooltip";
	
	@RBEntry("ERP BOM Result Table")
	public static final String PRIVATE_CONSTANT_35 = "SAPWizard.BOMResult.title";
	@RBEntry("ERP BOM Result Table")
	public static final String PRIVATE_CONSTANT_36 = "SAPWizard.BOMResult.description";
	@RBEntry("ERP BOM Result Table")
	public static final String PRIVATE_CONSTANT_37 = "SAPWizard.BOMResult.tooltip";
	
}
