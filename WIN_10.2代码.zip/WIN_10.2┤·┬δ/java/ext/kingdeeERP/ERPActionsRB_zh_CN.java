package ext.kingdeeERP;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.kingdeeERP.ERPActionsRB_zh_CN")
public class ERPActionsRB_zh_CN extends WTListResourceBundle {
	
	@RBEntry("发送部件到ERP")
	public static final String PRIVATE_CONSTANT_0 = "ERPWizard.sendPart2ERP.description";
	@RBEntry("发送部件到ERP")
	public static final String PRIVATE_CONSTANT_1 = "ERPWizard.sendPart2ERP.tooltip";
	@RBEntry("object_exclude.gif")
	public static final String PRIVATE_CONSTANT_3 = "ERPWizard.sendPart2ERP.icon";
	@RBEntry("发送BOM到ERP")
	public static final String PRIVATE_CONSTANT_4 = "ERPWizard.sendBOM2ERP.description";
	@RBEntry("发送BOM到ERP")
	public static final String PRIVATE_CONSTANT_5 = "ERPWizard.sendBOM2ERP.tooltip";
	@RBEntry("object_exclude.gif")
	public static final String PRIVATE_CONSTANT_6 = "ERPWizard.sendBOM2ERP.icon";
	
	@RBEntry("ERP返回的结果信息表格")
	public static final String PRIVATE_CONSTANT_29 = "SAPWizard.masterDataResult.title";
	@RBEntry("ERP返回的结果信息表格")
	public static final String PRIVATE_CONSTANT_30 = "SAPWizard.masterDataResult.description";
	@RBEntry("ERP返回的结果信息表格")
	public static final String PRIVATE_CONSTANT_31 = "SAPWizard.masterDataResult.tooltip";
	
	@RBEntry("ERP与BOM集成结果信息表格")
	public static final String PRIVATE_CONSTANT_35 = "SAPWizard.BOMResult.title";
	@RBEntry("ERP与BOM集成结果信息表格")
	public static final String PRIVATE_CONSTANT_36 = "SAPWizard.BOMResult.description";
	@RBEntry("ERP与BOM集成结果信息表格")
	public static final String PRIVATE_CONSTANT_37 = "SAPWizard.BOMResult.tooltip";
}
