package ext.kingdeeERP.BOM;

import ext.generic.reviewObject.model.ProcessReviewObjectLink;
import ext.generic.reviewObject.model.ProcessReviewObjectLinkHelper;
import ext.kingdeeERP.BOM.entity.Entity;
import ext.kingdeeERP.BOM.service.Service;
import ext.kingdeeERP.Config;
import ext.kingdeeERP.util.CommonUtil;
import ext.kingdeeERP.util.PersistenceUtil;
import ext.kingdeeERP.util.WorkFlowUtil;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Controller {
	
	static Logger logger = LogManager.getLogger(Controller.class);
	
	/**
	 * 发送部件给ERP
	 *
	 * @param ref 部件对象
	 * @return {@link String} 返回错误信息
	 */
	public static String sendBOM2ERP(WTObject ref) throws IOException {
		WTPart part = (WTPart) ref;
		// 获取token
		ext.kingdeeERP.token.Service.process();
		// 必须检入状态才能发送
		if (PersistenceUtil.isCheckOut(part)) {
			return part.getNumber() + " 该BOM的最上层部件是检出状态!请先检入该部件后操作!";
		}
		// 发送到ERP
		return Service.sendSingleBOM2ERP(part);
	}
	
	/**
	 * 在工作流中将BOM发送到ERP
	 *
	 * @param ref PBO对象
	 * @return {@link String}
	 */
	public static String sendParts2ERPInProgress(WTObject ref) throws IOException, WTException {
		StringBuilder errMsg = new StringBuilder();
		
		String resultJson = null;
		ext.kingdeeERP.token.Service.process();
		
		StringBuilder erpMsg = new StringBuilder();
		WfProcess wfProcess = WorkFlowUtil.getProcessByPbo(ref);
		String str = WorkFlowUtil.getReview(wfProcess);
		// 去除开头和结尾的方括号
		str = str.substring(1, str.length() - 1);
		
		// 按逗号分割字符串
		String[] parts = str.split(", ");
		
		// 遍历每个部分,获取 WTPart 对象
		List<WTPart> list = WorkFlowUtil.getListFromPBO(ref, WTPart.class);
		HashSet<WTPart> hashSet = new HashSet<>(list);
		for (String part : parts) {
			ReferenceFactory factory = new ReferenceFactory();
			WTPart wtPart = (WTPart) (WTObject) factory.getReference("OR:" + part).getObject();
			hashSet.add(wtPart);
		}
		
		for (WTPart part : hashSet) {
			System.out.println("BOM==part:" + part.getNumber());
			List<WTPartUsageLink> link = getLinksByPart(part);
			if (!link.isEmpty()) {
				Entity entity = Service.getEntity(part);
				String json = CommonUtil.parseJson(entity);
				// System.out.println(json);
				resultJson = CommonUtil.requestInterface(Config.BOMUrl(), "", "", json, "POST", null);
				// 对接口请求结果中的错误信息处理后返回错误信息
				String resultMsg = CommonUtil.processResult(resultJson);
				if (resultMsg != null && resultMsg.equals("IsSuccess")) {
					resultMsg = part.getNumber() + ";发送到ERP成功:" + resultMsg;
				} else {
					resultMsg = part.getNumber() + ";发送到ERP失败!原因:" + resultMsg;
				}
				errMsg.append(resultMsg).append("\n");
			}
		}
		list.addAll(getProcessReviewObj(ref));
		
		System.out.println("errMsg:" + errMsg.toString());
		return errMsg.toString();
		
	}
	
	
	public static List<WTPart> getProcessReviewObj(WTObject ref) {
		List<WTPart> list = new ArrayList<>();
		try {
			WfProcess wfprocess = WorkFlowUtil.getProcessByPbo(ref);
			if (wfprocess != null) {
				QueryResult queryresult = ProcessReviewObjectLinkHelper.service
						.getProcessReviewObjectLinkByRoleA(wfprocess);
				while (queryresult != null && queryresult.hasMoreElements()) {
					ProcessReviewObjectLink link = (ProcessReviewObjectLink) queryresult.nextElement();
					WTObject obj = (WTObject) link.getRoleBObject();
					if (obj instanceof WTPart) {
						list.add((WTPart) obj);
					}
				}
			}
		} catch (WTException e) {
			logger.error("从PBO对象钟获取部件对象时出错", e);
		}
		return list;
	}
	
	/**
	 * 获取部件与其所有子部件间的关联关系
	 *
	 * @param fatherPart
	 * @return List<WTPartUsageLink>
	 */
	public static List<WTPartUsageLink> getLinksByPart(WTPart fatherPart) {
		System.out.println("getNumber" + fatherPart.getNumber());
		List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
		try {
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
			while (qr.hasMoreElements()) {
				WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
				list.add(link);
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		System.out.println("listsize" + list.size());
		return list;
	}
	
	/**
	 * 校验ERP给出的信息中是否存在错误信息
	 *
	 * @param res
	 * @return error/ok
	 */
	public static String checkERPRes(String res) {
		System.out.println("BOM==res:" + res);
//		String resultMsg = CommonUtil.processResult(res);
//		System.out.println("resultMsg:" + resultMsg);
		if (res != null && res.contains("失败")) {
			return "Fail";
		}
		return "Success";
	}
}
