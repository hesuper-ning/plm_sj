package ext.kingdeeERP.BOM.service;

import ext.kingdeeERP.BOM.entity.Entity;
import ext.kingdeeERP.BOM.entity.SubPartEntity;
import ext.kingdeeERP.Config;
import ext.kingdeeERP.util.CommonUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import wt.fc.QueryResult;
import wt.part.*;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

import java.io.IOException;
import java.util.*;

public class Service {
	
	final static Logger logger = LogManager.getLogger(Service.class);
	private static StringBuffer allErrorMsg = new StringBuffer();
	
	/**
	 * 发送单个BOM
	 *
	 * @param part 部件
	 * @return {@link String} 错误信息
	 */
	public static String sendSingleBOM2ERP(WTPart part) throws IOException {
		allErrorMsg = new StringBuffer();
		Entity entity = getEntity(part);
		String json = CommonUtil.parseJson(entity);
		// System.out.println(json);
		String resultJson = CommonUtil.requestInterface(Config.BOMUrl(), "", "", json, "POST", null);
		// 对接口请求结果中的错误信息处理后返回错误信息
		String erpMsg = CommonUtil.processResult(resultJson);
		System.out.println("BOM==erpMsg:" + erpMsg);
		if (StringUtils.isNotBlank(erpMsg)) {
			if (erpMsg.equals("IsSuccess")) {
				erpMsg = "";
			} else {
				erpMsg = part.getNumber() + " 发送BOM到ERP失败!原因:" + erpMsg;
			}
			return erpMsg + allErrorMsg;
		} else {
			return null;
		}
	}
	
	/**
	 * 将部件转换为实体类
	 *
	 * @param part 部件
	 * @return {@link Entity} 实体类
	 */
	public static Entity getEntity(WTPart part) throws IOException {
		Entity entity = new Entity();
		Object[] parameters = new Object[2];
		parameters[0] = "ENG_BOM";
		parameters[1] = getSubEntity(part);
		entity.setParameters(parameters);
		return entity;
	}
	
	private static Entity.SubEntity getSubEntity(WTPart part) throws IOException {
		String materialId = ext.kingdeeERP.viewBOM.Service.process(part);
		materialId = materialId == null ? "0" : materialId;
		String IsAutoSubmitAndAudit = materialId.equals("0") ? "true" : "false";
		System.out.println("materialId:" + materialId);
		
		Entity.SubEntity entity = new Entity.SubEntity();
		entity.setIsAutoSubmitAndAudit(IsAutoSubmitAndAudit);
		entity.setIsDeleteEntry("true");
		entity.setSubSystemId("");
		entity.setIsVerifyBaseDataField("true");
		entity.setIsEntryBatchFill("true");
		entity.setValidateFlag("true");
		entity.setNumberSearch("true");
		entity.setIsAutoAdjustField("false");
		entity.setInterationFlags("");
		entity.setIgnoreInterationFlag("");
		entity.setIsControlPrecision("false");
		entity.setValidateRepeatJson("false");
		entity.setNeedReturnFields(new ArrayList<>());
		entity.setNeedUpDateFields(new ArrayList<>());
		
		// 填充 Model 对象的属性
		Entity.SubEntity.Model model = new Entity.SubEntity.Model();
		model.setfID(materialId);
		model.setFCreateOrgId(fillFCreateOrgIdEntity());
		model.setFUseOrgId(fillFUseOrgIdEntity());
//		model.setFNumber(part.getNumber() + "_" + part.getVersionInfo().getIdentifier().getValue());
//		model.setFName(part.getName());
		model.setfBillType(fillFBillTypeEntity());
		model.setfBomCategory(Config.BomCategory());
		model.setfMaterialId(fillFMaterialIdEntity(part));
		model.setfNote(Config.Note(part));
		model.setfTreeEntity(fillSubPartEntity(part));
		entity.setModel(model);
		return entity;
	}
	
	/**
	 * 获取BOM子件 部件对象所映射的实体类对象
	 *
	 * @param part BOM父组件
	 * @return {@link Object[]}
	 */
	private static Object[] fillSubPartEntity(WTPart part) {
		List<SubPartEntity> subPartEntities = new ArrayList<>();
//		List<WTPart> subParts = CommonUtil.getBomByPart(part);
//		// 发送BOM之前先发送BOM头到ERP中
//		sendPart2ERP(part);
//		for (int i = 0; i < subParts.size(); i++) {
//			// 发送BOM之前先发送BOM中的所有物料到ERP中
//			sendPart2ERP(subParts.get(i));
//			subPartEntities.addAll(fillSingleSubPartEntity(part, subParts.get(i), i + 1));
//		}
		
		// 发送BOM之前先发送BOM头到ERP中
		sendPart2ERP(part);
		List<Object[]> childBOM = getChildBOM(part);
		if (childBOM.size() > 0) {
			for (int i = 0; i < childBOM.size(); i++) {
				sendPart2ERP((WTPart) childBOM.get(i)[1]);
				subPartEntities.addAll(fillSingleSubPartEntity(part, (WTPart) childBOM.get(i)[1], i + 1));
			}
		}
		
		return subPartEntities.toArray();
	}
	
	/**
	 * 获取子阶列表，按物料编码排序
	 *
	 * @param rootPart
	 * @return
	 */
	private static List<Object[]> getChildBOM(WTPart rootPart) {
		List<Object[]> list = new ArrayList<Object[]>();
		QueryResult qr2 = null;
		try {
			QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(rootPart);
			while (qr.hasMoreElements()) {
				Object[] obj = new Object[2];
				WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
				obj[0] = usageLink;
				qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
				LatestConfigSpec cfg = new LatestConfigSpec();
				qr2 = cfg.process(qr2);
				if (qr2.hasMoreElements()) {
					WTPart sPart = (WTPart) qr2.nextElement();
					obj[1] = sPart;
				}
				list.add(obj);
			}
			//排序
			Collections.sort(list, new Comparator<Object[]>() {
				public int compare(Object[] obj1, Object[] obj2) {
					WTPart part1 = (WTPart) obj1[1];
					WTPart part2 = (WTPart) obj2[1];
					return part1.getNumber().compareTo(part2.getNumber());
				}
			});
		} catch (WTException e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	private static HashSet<SubPartEntity> fillSingleSubPartEntity(WTPart part, WTPart subPart, int replaceGroup) {
		HashSet<SubPartEntity> subPartEntities = new HashSet<>();
		// 获取主料内容
		WTPartUsageLink link = CommonUtil.getLinkByPart(part, subPart);
		String[] fraction = SubPartEntityService.getFraction(link);
		SubPartEntity masterPartEntity = SubPartEntityService.getMasterPartEntity(subPart, link);
		System.out.println("001=" + subPart.getNumber());
		subPartEntities.add(masterPartEntity);
		
		
		// 获取替代料内容
		List<WTPartSubstituteLink> substituteLinks = CommonUtil.getSubstituteLinks(link);
		if (substituteLinks != null && !substituteLinks.isEmpty()) {
			for (int i = 0; i < substituteLinks.size(); i++) {
				// 获取替代料关联关系
				WTPartSubstituteLink wtPartSubstituteLink = substituteLinks.get(i);
				// 获取替代部件
				WTPart substitutePart = CommonUtil.getWTPartByMaster((WTPartMaster) wtPartSubstituteLink.getRoleBObject());
				System.out.println("003=" + substitutePart.getNumber());
				// 发送BOM之前先发送替代料到ERP中
				sendPart2ERP(substitutePart);
				SubPartEntity substitutePartEntity = SubPartEntityService.getSubstitutePartEntity(substitutePart, wtPartSubstituteLink);
				substitutePartEntity.setfReplaceGroup(String.valueOf(replaceGroup));
				substitutePartEntity.setfReplacePriority(String.valueOf(i + 1));
				substitutePartEntity.setfMRPPriority(String.valueOf(i + 1));
				substitutePartEntity.setfNumberator(fraction[0]);
				substitutePartEntity.setfDenominator(fraction[1]);
				subPartEntities.add(substitutePartEntity);
			}
		} else {
			masterPartEntity.setfReplacePriority("");
			masterPartEntity.setfMRPPriority("");
			masterPartEntity.setfReplaceType("");
			masterPartEntity.setfReplacePolicy("");
			masterPartEntity.setfIskeyItem("false");
		}
		
		masterPartEntity.setfNumberator(fraction[0]);
		masterPartEntity.setfDenominator(fraction[1]);
		masterPartEntity.setfReplaceGroup(String.valueOf(replaceGroup));
		subPartEntities.add(masterPartEntity);
		
		return subPartEntities;
	}
	
	private static Entity.SubEntity.Model.FCreateOrgId fillFCreateOrgIdEntity() {
		Entity.SubEntity.Model.FCreateOrgId fCreateOrgId = new Entity.SubEntity.Model.FCreateOrgId();
		fCreateOrgId.setFNumber("100");
		return fCreateOrgId;
	}
	
	private static Entity.SubEntity.Model.FUseOrgId fillFUseOrgIdEntity() {
		Entity.SubEntity.Model.FUseOrgId fUseOrgId = new Entity.SubEntity.Model.FUseOrgId();
		fUseOrgId.setFNumber("100");
		return fUseOrgId;
	}
	
	private static Entity.SubEntity.Model.FBILLTYPE fillFBillTypeEntity() {
		Entity.SubEntity.Model.FBILLTYPE fBilltype = new Entity.SubEntity.Model.FBILLTYPE();
		fBilltype.setFNumber(Config.BillType());
		return fBilltype;
	}
	
	private static Entity.SubEntity.Model.FMATERIALID fillFMaterialIdEntity(WTPart part) {
		Entity.SubEntity.Model.FMATERIALID fMaterialId = new Entity.SubEntity.Model.FMATERIALID();
		fMaterialId.setFNumber(part.getNumber());
		return fMaterialId;
	}
	
	/**
	 * 发送部件到ERP并处理已经处理的json中的信息来
	 *
	 * @param part 部件对象
	 */
	private static void sendPart2ERP(WTPart part) {
		String errorMsg = ext.kingdeeERP.masterData.Controller.sendParts2ERPNoToken(part);
		if (StringUtils.isNotBlank(errorMsg)) {
			allErrorMsg.append(errorMsg).append("\n");
		}
	}
}
