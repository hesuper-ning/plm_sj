package ext.kingdeeERP.BOM.mvc;

public class Result {
	private String number;
	private String name;
	private String materialType;
	private String msg;
	private String time;
	private String status;
	
	public Result() {
		super();
	}
	
	public Result(String number, String name, String materialType, String msg, String time, String status) {
		super();
		this.number = number;
		this.name = name;
		this.materialType = materialType;
		this.msg = msg;
		this.time = time;
		this.status = status;
	}
	
	public String getNumber() {
		return number;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getMaterialType() {
		return materialType;
	}
	
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "Result [number=" + number + ", name=" + name + ", materialType=" + materialType + ", msg=" + msg + ", time=" + time
				+ ", status=" + status + "]";
	}
	
}