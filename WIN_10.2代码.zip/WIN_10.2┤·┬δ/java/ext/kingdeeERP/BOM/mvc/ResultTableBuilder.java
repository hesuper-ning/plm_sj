package ext.kingdeeERP.BOM.mvc;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.kingdeeERP.Config;
import ext.kingdeeERP.util.PersistenceUtil;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@ComponentBuilder(value = {"erp.bomResult.list"}, type = ComponentBuilderType.CONFIG_AND_DATA)
public class ResultTableBuilder extends AbstractComponentBuilder {
	@Override
	public Object buildComponentData(ComponentConfig config, ComponentParams params) throws Exception {
		System.out.println("start====");
		Result result = new Result();
		List<Result> resultList = new ArrayList<>();
		JcaComponentParams jca_params = (JcaComponentParams) params;
		NmCommandBean cb = jca_params.getHelperBean().getNmCommandBean();
		NmOid primaryOid2 = cb.getPrimaryOid();
		if (primaryOid2 != null) {
			Object content = primaryOid2.getRef();
			if (content instanceof WorkItem) {
				WorkItem wi = (WorkItem) content;
				System.out.println("wi:" + wi);
				WfAssignedActivity wfAssignedActivity = (WfAssignedActivity) wi.getSource().getObject();
				WfProcess wfProcess = wfAssignedActivity.getParentProcess();
				System.out.println("wfProcess:" + wfProcess);
				String msg = (String) wfProcess.getContext().getValue(Config.getBOMJsonVar());
				System.out.println("msg:" + msg);
				HashMap<String, String> map = extractValuesFromString(msg);
				System.out.println("map:" + map);
				Set<String> keys = map.keySet();
				for (String key : keys) {
					String value = map.get(key);
					System.out.println("Key: " + key + ", Value: " + value);
					WTPart wtpart = getWTPartByNumber(key);
					result.setName(wtpart.getName());
					result.setNumber(wtpart.getNumber());
					String internalName = PersistenceUtil.getPartTypeInternalName(wtpart);
					System.out.println("internalName:" + internalName);
					String MaterialType = null;
					switch (internalName) {
						case "com.sprocomm.SKDPart":
							MaterialType = "SKD&CKD部件";
							break;
						case "com.ptc.ElectricalPart":
							MaterialType = "电子部件";
							break;
						case "com.sprocomm.SecondaryPart":
							MaterialType = "二级部件";
							break;
						case "com.sprocomm.ProjectPart":
							MaterialType = "项目部件";
							break;
						case "com.sprocomm.MachinePart":
							MaterialType = "整机部件";
							break;
					}
					result.setMaterialType(MaterialType);
					if (value.equals("IsSuccess")) {
						result.setStatus("Success");
						result.setMsg("BOM成功发送到ERP");
					} else {
						result.setStatus("Error");
						result.setMsg("BOM发送到ERP失败ERP!原因:" + value);
					}
					Date day = new Date();
					SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					df.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai")); // 设置为上海时区
					System.out.println(df.format(day));
					result.setTime(df.format(day));
					
					resultList.add(result);
					
					// 创建一个新的 result 对象
					result = new Result();
				}
			}
		}
		System.out.println("resultList:" + resultList);
		return resultList;
	}
	
	public static HashMap<String, String> extractValuesFromString(String rawMsg) {
		// 定义一个列表保存提取的值
		List<String> values = new ArrayList<>();
		// 预处理字符串：去掉日志信息，只保留包含关键字的有效行
		StringBuilder msgBuilder = new StringBuilder();
		String[] lines = rawMsg.split("\n");
		for (String line : lines) {
			if (line.contains("发送到ERP")) {
				msgBuilder.append(line.trim()).append("\n");
			}
		}
		String msg = msgBuilder.toString();
		
		// 输出预处理后的字符串
		System.out.println("msg:" + msg);
		
		// 正则表达式，匹配格式为编号开头并以状态结尾的格式
		// 更新正则表达式以包含分号的消息格式
		String regex = "(\\S+);发送到ERP(\\S+?):(\\S+)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(msg);
		
		HashMap<String, String> map = new HashMap<String, String>();
		
		// 遍历所有匹配项并添加到列表中
		while (matcher.find()) {
			// 提取匹配的编号和状态
			String number = matcher.group(1);
			String status = matcher.group(3);
			
			map.put(number, status);
		}
		
		return map;
	}
	
	/**
	 * 根据编号查询part
	 *
	 * @param number
	 * @return WTPart
	 */
	@SuppressWarnings("deprecation")
	public static WTPart getWTPartByNumber(String number) {
		WTPart result = null;
		QueryResult qr = null;
		try {
			QuerySpec qs = new QuerySpec(WTPart.class);
			SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
					number.toUpperCase());
			qs.appendSearchCondition(scnumber);
			qs.appendAnd();
			SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
			qs.appendSearchCondition(sclatest);
			qr = PersistenceHelper.manager.find(qs);
			LatestConfigSpec cfg = new LatestConfigSpec();
			QueryResult qr1 = cfg.process(qr);
			if (qr1 != null && qr1.hasMoreElements()) {
				result = (WTPart) qr1.nextElement();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	public ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
		ComponentConfigFactory configFactory = getComponentConfigFactory();
		TableConfig tableConfig = configFactory.newTableConfig();
		tableConfig.setSelectable(true);// 显示表格前面的选择框
		tableConfig.setLabel("ERP与BOM集成结果信息表格");
		tableConfig.setConfigurable(true);
		
		ColumnConfig sourceConfig = configFactory.newColumnConfig("number", true);
		sourceConfig.setLabel("物料编码");
		tableConfig.addComponent(sourceConfig);
		
		ColumnConfig endItemConfig = configFactory.newColumnConfig("name", true);
		endItemConfig.setLabel("物料描述");
		tableConfig.addComponent(endItemConfig);
		
		ColumnConfig SAPMarkConfig = configFactory.newColumnConfig("materialType", true);
		SAPMarkConfig.setLabel("物料类型");
		tableConfig.addComponent(SAPMarkConfig);
		
		ColumnConfig phantomConfig = configFactory.newColumnConfig("status", true);
		phantomConfig.setLabel("发布状态");
		tableConfig.addComponent(phantomConfig);
		
		ColumnConfig sapMaterialGroupConfig = configFactory.newColumnConfig("msg", true);
		sapMaterialGroupConfig.setLabel("物料集成返回信息");
		tableConfig.addComponent(sapMaterialGroupConfig);
		
		ColumnConfig SourceChildPartConfig = configFactory.newColumnConfig("time", true);
		SourceChildPartConfig.setLabel("集成时间");
		tableConfig.addComponent(SourceChildPartConfig);
		
		return tableConfig;
	}
	
	
}
