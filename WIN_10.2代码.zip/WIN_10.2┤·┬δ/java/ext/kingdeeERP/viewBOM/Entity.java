package ext.kingdeeERP.viewBOM;


import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

public class Entity {
    @JsonProperty("parameters")
    private Object[] parameters;
    
    @JsonIgnore
    public Object[] getParameters() {
        return parameters;
    }
    
    @JsonIgnore
    public void setParameters(Object[] parameters) {
        this.parameters = parameters;
    }
    
    public static class SubEntity {
        
        @JsonProperty("FormId")
        private String formId;
        @JsonProperty("FieldKeys")
        private String fieldKeys;
        @JsonProperty("OrderString")
        private String orderString;
        @JsonProperty("TopRowCount")
        private String topRowCount;
        @JsonProperty("StartRow")
        private String startRow;
        @JsonProperty("Limit")
        private String limit;
        @JsonProperty("SubSystemId")
        private String subSystemId;
      
        @JsonProperty("FilterString")
        private Object[]  filterString;
        
        
        @JsonIgnore
        public String getFormId() {
            return formId;
        }
        
        @JsonIgnore
        public void setFormId(String formId) {
            this.formId = formId;
        }
        
        @JsonIgnore
        public String getFieldKeys() {
            return fieldKeys;
        }
        
        @JsonIgnore
        public void setFieldKeys(String fieldKeys) {
            this.fieldKeys = fieldKeys;
        }
        
        @JsonIgnore
        public String getOrderString() {
            return orderString;
        }
        
        @JsonIgnore
        public void setOrderString(String orderString) {
            this.orderString = orderString;
        }
        
        @JsonIgnore
        public String getTopRowCount() {
            return topRowCount;
        }
        
        @JsonIgnore
        public void setTopRowCount(String topRowCount) {
            this.topRowCount = topRowCount;
        }
        
        @JsonIgnore
        public String getStartRow() {
            return startRow;
        }
        
        @JsonIgnore
        public void setStartRow(String startRow) {
            this.startRow = startRow;
        }
        
        @JsonIgnore
        public String getLimit() {
            return limit;
        }
        
        @JsonIgnore
        public void setLimit(String limit) {
            this.limit = limit;
        }
        
        @JsonIgnore
        public String getSubSystemId() {
            return subSystemId;
        }
        
        @JsonIgnore
        public void setSubSystemId(String subSystemId) {
            this.subSystemId = subSystemId;
        }
        
        
        @JsonIgnore
        public  Object[]  getFilterString() {
            return filterString;
        }
        
        @JsonIgnore
        public void setFilterString (Object[] filterString) {
            this.filterString = filterString;
        }
        
   
    }
}