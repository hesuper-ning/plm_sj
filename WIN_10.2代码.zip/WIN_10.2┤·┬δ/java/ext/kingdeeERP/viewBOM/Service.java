package ext.kingdeeERP.viewBOM;

import ext.kingdeeERP.Config;
import ext.kingdeeERP.util.CommonUtil;
import ext.kingdeeERP.viewMaterial.Entity;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import wt.part.WTPart;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Service {
	
	static Logger logger = Logger.getLogger(Service.class);
	
	/**
	 * 获取BOM在ERP系统中的ID并判断是否存在部件，如果存在则返回ID
	 *
	 * @param part 部件对象
	 * @return {@link String}
	 */
	public static String process(WTPart part) throws IOException {
		Entity entity = getEntity(part);
		String json = CommonUtil.parseJson(entity);
		System.out.println(json);
		// 获取token
		ext.kingdeeERP.token.Service.process();
		String resultJson = CommonUtil.requestInterface(Config.viewBOM(), "", "", json, "POST", null);
		if (StringUtils.isBlank(resultJson)) {
			return null;
		} else {
			ObjectMapper objectMapper = new ObjectMapper();
			List jsonString = objectMapper.readValue(resultJson, List.class);
			
			if (!jsonString.isEmpty()) {
				String firstValue = String.valueOf(((List<?>) jsonString.get(0)).get(0));
				System.out.println("firstValue:" + firstValue);
				return firstValue;
			} else {
				System.out.println("resultJson is an empty array.");
				return null;
			}
			
		}
		
	}
	
	public static Entity getEntity(WTPart part) {
		Entity entity = new Entity();
		Object[] parameters = new Object[1];
		parameters[0] = getSubEntity(part);
		entity.setParameters(parameters);
		return entity;
	}
	
	public static ext.kingdeeERP.viewBOM.Entity.SubEntity getSubEntity(WTPart part) {
		ext.kingdeeERP.viewBOM.Entity.SubEntity subEntity = new ext.kingdeeERP.viewBOM.Entity.SubEntity();
		subEntity.setFieldKeys("FID");
		subEntity.setFormId("ENG_BOM");
		subEntity.setOrderString("");
		subEntity.setTopRowCount("0");
		subEntity.setStartRow("0");
		subEntity.setLimit("2000");
		subEntity.setSubSystemId("");
		System.out.println("FieldKeys:" + subEntity.getFieldKeys());
		
		ext.kingdeeERP.viewBOM.SubPartEntity subPartEntity = new ext.kingdeeERP.viewBOM.SubPartEntity();
		List<ext.kingdeeERP.viewBOM.SubPartEntity> subPartEntities = new ArrayList<>();
		
		subPartEntity.setfieldName("FMATERIALID.FNumber");
		subPartEntity.setcompare("17");
		subPartEntity.setleft("");
		subPartEntity.setright("");
		subPartEntity.setlogic("0");
		subPartEntity.setvalue(part.getNumber());
		
		subPartEntities.add(subPartEntity);
		Object[] o = subPartEntities.toArray();
		
		subEntity.setFilterString(o);
		return subEntity;
	}
	
	/**
	 * 解析ERP返回的json内容，判断是否查询到了物料，并返回查询得到的物料ID
	 *
	 * @param resultJson ERP JSON
	 * @return {@link String}
	 */
	private static String processJson(String resultJson) {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode rootNode = objectMapper.readTree(resultJson);
			JsonNode isSuccessNode = rootNode.path("Result").path("ResponseStatus").path("IsSuccess");
			if (isSuccessNode.asBoolean()) {
				JsonNode idListNode = rootNode.path("Result").path("Result").path("Id");
				StringBuilder sb = new StringBuilder();
				for (JsonNode idNode : idListNode) {
					if (sb.length() > 0) {
						sb.append(",");
					}
					sb.append(idNode.asText());
				}
				System.out.println("sb:" + sb);
				return sb.toString();
			} else {
				return null;
			}
		} catch (Exception e) {
			logger.error("处理查询ERP中物料id接口返回的json时出错", e);
		}
		return null;
	}
}