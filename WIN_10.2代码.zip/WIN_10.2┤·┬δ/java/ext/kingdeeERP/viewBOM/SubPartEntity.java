package ext.kingdeeERP.viewBOM;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

public class SubPartEntity {
    
    @JsonProperty("FieldName")
    private String fieldName;
    @JsonProperty("Compare")
    private String compare;
    @JsonProperty("Value")
    private String value;
    @JsonProperty("Left")
    private String left;
    @JsonProperty("Right")
    private String right;
    @JsonProperty("Logic")
    private String logic;
    
    @JsonIgnore
    public String getffieldName() {
        return fieldName;
    }
    
    @JsonIgnore
    public void setfieldName(String fieldName) {
        this.fieldName = fieldName;
    }
    
    @JsonIgnore
    public String getcompare() {
        return compare;
    }
    
    @JsonIgnore
    public void setcompare(String compare) {
        this.compare = compare;
    }
    
    @JsonIgnore
    public String getvalue() {
        return value;
    }
    
    @JsonIgnore
    public void setvalue(String value) {
        this.value = value;
    }
    
    @JsonIgnore
    public String getleft() {
        return left;
    }
    
    @JsonIgnore
    public void setleft(String left) {
        this.left = left;
    }
    
    @JsonIgnore
    public String getright() {
        return right;
    }
    
    @JsonIgnore
    public void setright(String right) {
        this.right = right;
    }
    
    @JsonIgnore
    public String getlogic() {
        return logic;
    }
    
    @JsonIgnore
    public void setlogic(String logic) {
        this.logic = logic;
    }
}
