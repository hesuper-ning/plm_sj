package ext.kingdeeERP.masterData;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.wip.CheckinMultipleObjectsFormProcessor;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.List;

public class CusCheckinMultipleObjectsFormProcessor extends CheckinMultipleObjectsFormProcessor {
    static Logger logger = Logger.getLogger(CusCheckinMultipleObjectsFormProcessor.class.getName());

    @Override
    public FormResult postTransactionProcess(NmCommandBean var1, List<ObjectBean> var2) throws WTException {
        WTObject ref = (WTObject) var1.getPrimaryOid().getRef();
//        WTPart part = (var2.size() > 0)
//                ? (var2.get(0).getObject() instanceof WTPart ? (WTPart) var2.get(0).getObject() : null)
//                : null;
        FormResult formresult = null;
        String msg;
        String state =((WTPart) ref).getLifeCycleState().getDisplay();//状态显示值
        System.out.println("状态为：" + state);
        if ("正在工作".equals(state) || "试制".equals(state) || "已发布".equals(state)) {
            try {
                msg = CusCheckController.sendParts2ERP(ref);
            } catch (Exception e) {
                formresult = new FormResult(FormProcessingStatus.FAILURE);
                formresult.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null,
                        null, "发送物料主数据失败！", e.getMessage()));
                logger.error("发送物料主数据失败", e);
                return formresult;
            }

            if (StringUtils.isNotBlank(msg)) {
                formresult = new FormResult(FormProcessingStatus.FAILURE);
                formresult.addFeedbackMessage(
                        new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null, null, msg));
            } else {
                formresult = new FormResult(FormProcessingStatus.SUCCESS);
                formresult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null,
                        null, "物料发送到ERP成功!"));
            }
            return formresult;
        } else {
            formresult = new FormResult(FormProcessingStatus.FAILURE);
            formresult.addFeedbackMessage(
                    new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
                            "只有正在工作/试制/已发布才可以发送物料"));
            return formresult;
        }

    }

}
