package ext.kingdeeERP.masterData.processor;

import java.util.List;

import com.ptc.cat.ui.client.action.ActionDefinition;
import com.ptc.cat.ui.client.action.JCAAction;
import wt.util.WTMessage;
import com.ptc.cat.ui.client.action.EditCommonAtributesAction;
import com.google.gwt.gen2.logging.shared.Log;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.ptc.cat.entity.client.ConstraintDescriptorManager;
import com.ptc.cat.entity.client.attribute.Attribute;
import com.ptc.cat.entity.client.attribute.ModelLoader;
import com.ptc.cat.entity.client.descriptor.TypeDescriptor;
import com.ptc.cat.entity.client.structure.StructureModel;
import com.ptc.cat.gxt.client.AbstractEntryPoint;
import com.ptc.cat.gxt.client.GXTMessages;
import com.ptc.cat.gxt.client.util.Util;
import com.ptc.cat.gxt.client.widget.MessageDialog;
import com.ptc.cat.ui.client.internal.action.DefaultActionDefinition;

public class CusEditCommonAtributesAction extends EditCommonAtributesAction {

    public CusEditCommonAtributesAction(ActionDefinition definition) {
        super(definition);
    }

    @Override
    protected void populateActionDefinition(ActionDefinition action_definition) {
        DefaultActionDefinition actionDefinition = (DefaultActionDefinition) action_definition;

        String ajaxType = "row";
        String actionMethod = "execute";
        String windowType = "popup";
        String url = "/ptc1/part/editPartCommonAttrsWizard";
        String formProcessorClass = "ext.kingdeeERP.masterData.processor.CusEditPartCommonAttrsFormProcessor";

        actionDefinition.setAjaxType(ajaxType);
        actionDefinition.setFormProcessorClass(formProcessorClass);
        actionDefinition.setUrl(url);
        actionDefinition.setWindowType(windowType);
        actionDefinition.setActionMethod(actionMethod);
    }


}
