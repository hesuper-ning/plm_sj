package ext.kingdeeERP.masterData.processor;


import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.part.forms.EditPartCommonAttrsFormProcessor;
import ext.kingdeeERP.masterData.CusCheckController;
import ext.kingdeeERP.masterData.CusCheckinMultipleObjectsFormProcessor;
import ext.kingdeeERP.util.PersistenceUtil;
import ext.kingdeeERP.util.PropertiesUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.List;

public class CusEditPartCommonAttrsFormProcessor extends EditPartCommonAttrsFormProcessor {
    private final String ITEM_TYPE = "CN.CREOLIVE.ProjectPart";
    private final String STATUS = "正在工作";
    static Logger logger = Logger.getLogger(CusEditPartCommonAttrsFormProcessor.class.getName());
    @Override
    public FormResult doOperation(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        super.doOperation(nmCommandBean, list);
        WTPart part = (list.size() > 0)
                ? (list.get(0).getObject() instanceof WTPart ? (WTPart) list.get(0).getObject() : null)
                : null;
        FormResult formresult = null;
        String msg;

        String state = part.getLifeCycleState().getDisplay();//状态显示值
        String partTypeInternalName = PersistenceUtil.getPartTypeInternalName(part);//类型内部值

        System.out.println("状态为：" + state);
        System.out.println("类型为：" + partTypeInternalName);
        //是部件且不是不是项目部件，状态为正在工作才发送
        if (part != null && !partTypeInternalName.equals(ITEM_TYPE)  && STATUS.equals(state)) {
            try {
                msg = CusCheckController.sendParts2ERP(part);
            } catch (Exception e) {
//                formresult = new FormResult(FormProcessingStatus.FAILURE);
//                formresult.addFeedbackMessage(new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null,
//                        null, "发送物料主数据失败！", e.getMessage()));
                System.out.println("发送物料主数据失败！");
                logger.error("发送物料主数据失败", e);
                return formresult;
            }

            if (StringUtils.isNotBlank(msg)) {
//                formresult = new FormResult(FormProcessingStatus.FAILURE);
//                formresult.addFeedbackMessage(
//                        new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null, null, msg));

            } else {
                formresult = new FormResult(FormProcessingStatus.SUCCESS);
                formresult.addFeedbackMessage(new FeedbackMessage(FeedbackType.SUCCESS, SessionHelper.getLocale(), null,
                        null, "物料发送到ERP成功!"));
            }
            return formresult;
        } else {
//            formresult = new FormResult(FormProcessingStatus.FAILURE);
//            formresult.addFeedbackMessage(
//                    new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null, null,
//                            "该部件状态为:"+state+"类型为:"+partTypeInternalName+",只有正在工作的非项目部件的部件才发送物料给ERP"));
            System.out.println("该部件状态为:"+state+"类型为:"+partTypeInternalName+",只有正在工作的非项目部件的部件才发送物料给ERP");
            return formresult;
        }
    }
}
