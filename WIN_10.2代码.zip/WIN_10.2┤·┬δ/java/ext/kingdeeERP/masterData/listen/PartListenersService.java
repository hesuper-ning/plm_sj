package ext.kingdeeERP.masterData.listen;


import ext.exportBom.util.PersistenceUtil;
import ext.exportBom.util.PropertiesUtil;
import ext.kingdeeERP.Config;
import ext.kingdeeERP.masterData.CusCheckController;
import ext.kingdeeERP.util.IBAUtil;
import org.apache.commons.lang.StringUtils;
import wt.events.KeyedEvent;
import wt.events.KeyedEventListener;
import wt.fc.PersistenceManagerEvent;
import wt.part.WTPart;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.vc.VersionControlServiceEvent;
import java.io.Serializable;


public class PartListenersService extends StandardManager implements PartListeners, Serializable {
    private static final long serialVersionUID = 1L;
    private static final String CLASSNAME = PartListenersService.class.getName();
    private KeyedEventListener listener;

    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public PartListenersService() {
    }

    public static PartListenersService newPartListenersService() throws WTException {
        PartListenersService instance = new PartListenersService();
        instance.initialize();
        return instance;
    }

    @Override
    protected void performStartupProcess() throws ManagerException {
        this.listener = new WCListenerEventListener(getConceptualClassname());

        //版本控制的检入监听事件
        getManagerService().addEventListener(listener,
                VersionControlServiceEvent.generateEventKey(VersionControlServiceEvent.POST_SUPERSEDE));//检入


//        getManagerService().addEventListener(listener,
//                PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.UPDATE));//内容修改


        //修改公用值属性
//        PersistenceManagerEvent)持久化对象持久化后
//        getManagerService().addEventListener(listener,
//                VersionControlServiceEvent.generateEventKey( PersistenceManagerEvent.POST_STORE));//检入
//        PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_STORE));
    }

    // 内部类里面进行监听的逻辑操作
    class WCListenerEventListener extends ServiceEventListenerAdapter {
        public WCListenerEventListener(String manager_name) {
            super(manager_name);
        }

        @Override
        public void notifyVetoableEvent(Object event) throws Exception {

            if (!(event instanceof KeyedEvent)) {
                return;
            }
            Object eventTarget = ((KeyedEvent) event).getEventTarget();
            String eventType = ((KeyedEvent) event).getEventType();

            //是部件且不是项目部件
            if (eventTarget instanceof WTPart &&
                    !(PersistenceUtil.getPartTypeInternalName((WTPart) eventTarget)).equals("CN.CREOLIVE.ProjectPart") )  {

                System.out.println("开始监听部件");
                WTPart part = (WTPart) eventTarget;
                System.out.println("打印听事件" + eventType);

                String partName = part.getName();
                String partNum = part.getNumber();
                String state = part.getLifeCycleState().getDisplay();//状态显示值
                String version = part.getIterationIdentifier().getValue();//版本
                System.out.println("部件编号 = " + partNum);
                System.out.println("部件名字 = " + partName);
                System.out.println("部件状态显示值 = " + state);
                System.out.println("版本 = " + version);

                IBAUtil ibaUtil = new IBAUtil(part);
                String itemDesc = ibaUtil.getIBAValue(PropertiesUtil.getValueByKey("part.iba.ItemDesc"));
                System.out.println("物料描述"+itemDesc);

                String executeState = Config.getValue("material.state");
                String msg = null;
                System.out.println("是否是正在工作|试制|已发布:"+executeState.contains(state));

                //正在工作发送物料
                if ("正在工作".equals(state)) {
                    try {
                        msg = CusCheckController.sendParts2ERP(part);
                    } catch (Exception e) {
                        System.out.println("发送物料主数据失败");
                    }
                    if (StringUtils.isNotBlank(msg)) {
                        System.out.println("发送物料主数据失败！");
                    } else {
                        System.out.println("发送物料主数据成功！");
                    }
                } else {
                    System.out.println(("只有正在工作可以发送物料"));
                }
            }else{
                System.out.println("不是部件或是项目部件，不发送物料");
            }


        }
    }
}
