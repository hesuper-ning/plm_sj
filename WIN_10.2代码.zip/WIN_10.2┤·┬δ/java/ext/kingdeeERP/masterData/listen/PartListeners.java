package ext.kingdeeERP.masterData.listen;

public interface PartListeners {
}
