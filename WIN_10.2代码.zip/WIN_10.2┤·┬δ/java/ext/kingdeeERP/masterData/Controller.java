package ext.kingdeeERP.masterData;

import ext.kingdeeERP.Config;
import ext.kingdeeERP.util.CommonUtil;
import ext.kingdeeERP.util.PersistenceUtil;
import ext.kingdeeERP.util.WorkFlowUtil;
import org.apache.log4j.Logger;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Controller {
	
	static Logger logger = Logger.getLogger(Controller.class);
	
	/**
	 * 发送部件给ERP
	 *
	 * @param ref 部件对象
	 * @return {@link String} 返回错误信息
	 */
	public static String sendParts2ERP(WTObject ref) {
		WTPart part = (WTPart) ref;
		// 获取token
		ext.kingdeeERP.token.Service.process();
		return sendParts2ERPNoToken(part);
	}
	
	public static String sendParts2ERPNoToken(WTPart part) {
		// 必须检入状态才能发送
		if (PersistenceUtil.isCheckOut(part)) {
			return part.getNumber() + " 该部件是检出状态!请先检入该部件后操作!";
		}
		// 发送到ERP
		String resultJson = Service.sendSinglePart2ERP(part);
		// 对接口请求结果中的错误信息处理后返回错误信息
		String resultMsg = CommonUtil.processResult(resultJson);
		if (resultMsg != null && resultMsg.equals("IsSuccess")) {
			Config.setPart2ERPStatus(part, "物料已成功发送到ERP");
			Config.setERPErrorMsg(part, "");
			return null;
		} else {
			Config.setPart2ERPStatus(part, "物料发送到ERP失败");
			Config.setERPErrorMsg(part, resultMsg);
			resultMsg = part.getNumber() + " 发送到ERP失败!原因:" + resultMsg;
			return resultMsg;
		}
	}
	
	/**
	 * 非项目部件，正在工作状态时，修改时检入自动将部件发送到ERP
	 *
	 * @param part 部件对象
	 */
	public static void sendParts2ERPCheckIn(WTPart part) {
		if (part != null && checkPart(part)) {
			// 发送部件到ERP
			String msg = sendParts2ERP(part);
			if (msg != null && !msg.equals("IsSuccess")) {
				logger.error("当部件为非项目部件，且正在工作状态时，发送部件到ERP出错:" + msg);
			}
		}
	}
	
	/**
	 * 校验部件是否需要发送到ERP
	 *
	 * @param part 部件对象
	 * @return boolean 是否发送到ERP
	 */
	private static boolean checkPart(WTPart part) {
		// 部件子类型为项目部件时不发送
		String partTypeInternalName = PersistenceUtil.getPartTypeInternalName(part);
		String noPermissionInternalName = Config.InternalName();
		if (partTypeInternalName.equals(noPermissionInternalName)) {
			return false;
		}
		// 部件状态为正在工作时发送
		String partState = part.getState().toString();
		Set<String> permissionPartStates = Config.PermissionPartState();
		return permissionPartStates.contains(partState);
	}
	
	/**
	 * 在工作流中将部件等内容发送到ERP
	 *
	 * @param ref PBO对象
	 * @return {@link String}
	 */
	public static String sendParts2ERPInProgress(WTObject ref) throws WTException {
		StringBuilder errMsg = new StringBuilder();
		String resultJson = null;
		// 获取token
		ext.kingdeeERP.token.Service.process();
		WfProcess wfProcess = WorkFlowUtil.getProcessByPbo(ref);
		String str = WorkFlowUtil.getReview(wfProcess);
		// 去除开头和结尾的方括号
		str = str.substring(1, str.length() - 1);
		
		// 按逗号分割字符串
		String[] parts = str.split(", ");
		
		// 遍历每个部分,获取 WTPart 对象
		List<WTPart> list = WorkFlowUtil.getListFromPBO(ref, WTPart.class);
		HashSet<WTPart> hashSet = new HashSet<>(list);
		for (String part : parts) {
			ReferenceFactory factory = new ReferenceFactory();
			WTPart wtPart = (WTPart) (WTObject) factory.getReference("OR:" + part).getObject();
			hashSet.add(wtPart);
		}
		for (WTPart part : hashSet) {
			part = (WTPart) PersistenceUtil.getLatestObj(part.getMaster());
//			errMsg.append(sendParts2ERPNoToken(part)).append("\n");
			// 必须检入状态才能发送
			if (PersistenceUtil.isCheckOut(part)) {
				return part.getNumber() + " 该部件是检出状态!请先检入该部件后操作!";
			}
			// 发送到ERP
			resultJson = Service.sendSinglePart2ERP(part);
			// 对接口请求结果中的错误信息处理后返回错误信息
			String resultMsg = CommonUtil.processResult(resultJson);
			if (resultMsg != null && resultMsg.equals("IsSuccess")) {
				Config.setPart2ERPStatus(part, "物料已成功发送到ERP");
				Config.setERPErrorMsg(part, "");
				resultMsg = part.getNumber() + ";发送到ERP成功:" + resultMsg;
			} else {
				Config.setPart2ERPStatus(part, "物料发送到ERP失败");
				Config.setERPErrorMsg(part, resultMsg);
				resultMsg = part.getNumber() + ";发送到ERP失败!原因:" + resultMsg;
			}
			
			errMsg.append(resultMsg).append("\n");
		}
		
		System.out.println("errMsg:" + errMsg.toString());
		return errMsg.toString();
	}
	
	
	/**
	 * 校验ERP给出的信息中是否存在错误信息
	 *
	 * @param res
	 * @return error/ok
	 */
	public static String checkERPRes(String res) {
		if (res != null && res.contains("失败")) {
			return "Fail";
		}
		return "Success";
	}
	
}
