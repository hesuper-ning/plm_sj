package ext.kingdeeERP.masterData.mvc;

public class Result {
	private String number;
	private String name;
	private String MaterialType;
	private String msg;
	private String time;
	private String status;
	
	public Result() {
		super();
	}
	
	public Result(String number, String name, String MaterialType, String msg, String time, String status) {
		super();
		this.number = number;
		this.name = name;
		this.MaterialType = MaterialType;
		this.msg = msg;
		this.time = time;
		this.status = status;
	}
	
	public String getNumber() {
		return number;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getMaterialType() {
		return MaterialType;
	}
	
	public void setMaterialType(String MaterialType) {
		this.MaterialType = MaterialType;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "Result [number=" + number + ", name=" + name + ", MaterialType=" + MaterialType + ", msg=" + msg + ", time=" + time
				+ ", status=" + status + "]";
	}
	
}