package ext.kingdeeERP.changeBOM;

import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;
import wt.content.ContentHolder;
import wt.fc.WTObject;
import wt.util.WTException;

/**
 * 供应链填写相关
 */
@GenAsPersistable(superClass = WTObject.class,interfaces = {ContentHolder.class},
        properties = {
                @GeneratedProperty(name="ChangeTermOR", type=String.class,
                        constraints=@PropertyConstraints(required=true)),
                @GeneratedProperty(name="ConsumeInOtherProjectsName", type= String.class),
                @GeneratedProperty(name="ConsumeInOtherProjectsNumber", type= String.class),
                @GeneratedProperty(name="LifelessPartInventory", type= String.class),
                @GeneratedProperty(name="LifelessPartPO", type= String.class),
                @GeneratedProperty(name="LifelessPartInProduction", type= String.class)
        })
public class WTPartChangeItemSupply extends _WTPartChangeItemSupply{

    static final long serialVersionUID = 1;

    public static WTPartChangeItemSupply newWTPartChangeItemSupply() throws WTException {
        final WTPartChangeItemSupply instance = new WTPartChangeItemSupply();
        instance.initialize();
        return instance;
    }
}
