package ext.kingdeeERP.changeBOM;

public enum ResponseEnum {

    OK(200, "操作成功"),

    ;

    private final int code;
    private final String msg;

    ResponseEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }


}
