package ext.kingdeeERP.changeBOM;

public enum ChangeTypeEnum {

    addSonPart("addSonPart", "添加子项"),
    UPDATE("UPDATE", "修改"),
    deleteSonPart("deleteSonPart", "移除子项"),

    addReplacePart("addReplacePart", "添加替代料"),
    deleteReplacePart("deleteReplacePart", "删除替代料"),

    REPLACE("REPLACE", "替换");

    private final String key;
    private final String value;

    ChangeTypeEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    // 根据key获取对应的value
    public static String getValueByKey(String key) {
        for (ChangeTypeEnum enumItem : ChangeTypeEnum.values()) {
            if (enumItem.key.equals(key)) {
                return enumItem.value;
            }
        }
        return null; // 或者抛出异常或特定的默认值，视需求而定
    }


    public static ChangeTypeEnum getObjectByKey(String key) {
        for (ChangeTypeEnum enumItem : ChangeTypeEnum.values()) {
            if (enumItem.key.equals(key)) {
                return enumItem;
            }
        }
        return null; // 或者抛出异常或特定的默认值，视需求而定
    }

    // 根据value获取对应的key
    public static String getKeyByValue(String value) {
        for (ChangeTypeEnum enumItem : ChangeTypeEnum.values()) {
            if (enumItem.value.equals(value)) {
                return enumItem.key;
            }
        }
        return null; // 或者抛出异常或特定的默认值，视需求而定
    }


    /**
     * 根据value获得枚举对象
     * @param value
     * @return
     */
    public static ChangeTypeEnum getObjectByValue(String value) {
        for (ChangeTypeEnum enumItem : ChangeTypeEnum.values()) {
            if (enumItem.value.equals(value)) {
                return enumItem;
            }
        }
        return null; // 或者抛出异常或特定的默认值，视需求而定
    }

}
