package ext.kingdeeERP.changeBOM;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;

import wt.content.ContentHolder;
import wt.fc.WTObject;
import wt.util.WTException;

/**
 * 部件使用关系变更项建模
 * WTChangeORDER2OR 变更通告OID
 * ChangeType 变更类型
 * ParentOID 父物料OID
 * BeforeChildMasterOR 改前子项部件主数据OID
 *  * AfterChildMasterOR 改后子项部件主数据OID
 *  * ReplaceChildMasterOR 替代料部件主数据OID
 * BeforeAMountA7 改前用量
 * BeforeTagNumber 改前位号
 *  NewAMountA7 改后用量
 * NewAMountA7TagNumber 改后位号
 * NewChildNumber 改后子项编号
 * NewChildName 改后子项名称
 *
 * Link相关IBA属性
 * IsByCust 是否客供料
 * IsCustomerService 是否售后料
 * ItemNote 物料行备注
 * BOMSkip 跳层
 * lineNumber 行号
 * SwitchMode 切换模式 两值 立即变更，用完旧料
 *
 * 2024.7.23新增字段
 * Inventory 库存
 * PO
 * InProduction 在制
 * BOMReplacePartInventory BOM替代料库存
 * BOMReplacePartInProduction BOM替代料在制
 *
 *
 * LifelessPartHandMet 呆滞料处理方式下拉选择
 * ChangeRemarks 变更备注
 * ConsumeInOtherProjectsName 消耗用于其他项目名称
 * ConsumeInOtherProjectsNumber 消耗用于其他项目数量
 * LifelessPartInventory 最终呆滞库存
 * LifelessPartPO 最终呆滞PO
 * LifelessPartInProduction 最终呆滞在制
 */

@GenAsPersistable(superClass = WTObject.class,interfaces = {ContentHolder.class},
        properties = {
                @GeneratedProperty(name="WTChangeORDER2OR", type=String.class,
                        constraints=@PropertyConstraints(required=true)),
                @GeneratedProperty(name="ChangeType", type= String.class, constraints=@PropertyConstraints(required = true)),
                @GeneratedProperty(name="ParentOID", type= String.class),
                @GeneratedProperty(name="BeforeChildMasterOR", type= String.class),
                @GeneratedProperty(name="AfterChildMasterOR", type= String.class),
                @GeneratedProperty(name="ReplaceChildMasterOR", type= String.class),
                @GeneratedProperty(name="BeforeAMountA7", type= String.class),
                @GeneratedProperty(name="BeforeTagNumber", type= String.class ,constraints = @PropertyConstraints(upperLimit = 3000)),
                @GeneratedProperty(name="NewAMountA7", type= String.class),
                @GeneratedProperty(name="NewAMountA7TagNumber", type= String.class,constraints = @PropertyConstraints(upperLimit = 3000)),
                @GeneratedProperty(name="NewChildNumber", type= String.class),
                @GeneratedProperty(name="NewChildName", type= String.class),

                @GeneratedProperty(name="IsByCust", type= String.class),
                @GeneratedProperty(name="IsCustomerService", type= String.class),
                @GeneratedProperty(name="ItemNote", type= String.class),
                @GeneratedProperty(name="BOMSkip", type= String.class),
                @GeneratedProperty(name="lineNumber", type= long.class),
                @GeneratedProperty(name="SwitchMode", type= String.class),


                @GeneratedProperty(name="Inventory", type= String.class),
                @GeneratedProperty(name="changePO", type= String.class),
                @GeneratedProperty(name="InProduction", type= String.class),
                @GeneratedProperty(name="BOMReplacePartInventory", type= String.class),
                @GeneratedProperty(name="BOMReplacePartInProduction", type= String.class),

                @GeneratedProperty(name="WTUserLinkOR", type= String.class)


        })
public class WTPartUsageLinkChangeItem extends _WTPartUsageLinkChangeItem {


    static final long serialVersionUID = 1;

    public static WTPartUsageLinkChangeItem newWTPartUsageLinkChangeItem() throws WTException {
        final WTPartUsageLinkChangeItem instance = new WTPartUsageLinkChangeItem();
        instance.initialize();
        return instance;
    }
}
