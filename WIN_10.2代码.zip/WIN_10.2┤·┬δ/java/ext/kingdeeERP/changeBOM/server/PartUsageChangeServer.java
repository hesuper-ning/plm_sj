package ext.kingdeeERP.changeBOM.server;


import ext.kingdeeERP.changeBOM.WTPartUsageLinkChangeItem;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;

import wt.query.QuerySpec;
import wt.query.SearchCondition;

import java.util.*;

public class PartUsageChangeServer {

    private static final String[] PARENT_PART_STATUS = {"试制", "已发布","已发布变更中"};

    public static final List<String> PARENT_PART_STATUS_LIST = new ArrayList<>(Arrays.asList(PARENT_PART_STATUS));


    private static final String[] CHANGE_ORDER2_STATUS = {"已解决"};

    public static final List<String> CHANGE_ORDER2_STATUS_LIST = new ArrayList<>(Arrays.asList(CHANGE_ORDER2_STATUS));



    /**
     * 通过变更Oid获取变更内容
     * @param oid
     * @return
     */
    public static List<WTPartUsageLinkChangeItem> getChangeItemByChangeOid(String oid) {
        Vector<WTPartUsageLinkChangeItem> vector = null;
        try {
            QuerySpec qs = new QuerySpec(WTPartUsageLinkChangeItem.class);
            SearchCondition sc = new SearchCondition(WTPartUsageLinkChangeItem.class,WTPartUsageLinkChangeItem.WTCHANGE_ORDER2_OR, SearchCondition.EQUAL, oid);
            qs.appendWhere(sc);

            QueryResult qr = PersistenceHelper.manager.find(qs);
            vector = qr.getObjectVectorIfc().getVector();
            return vector;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vector;
    }






}
