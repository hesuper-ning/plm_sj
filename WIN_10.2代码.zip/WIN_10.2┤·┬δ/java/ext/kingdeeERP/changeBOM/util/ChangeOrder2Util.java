package ext.kingdeeERP.changeBOM.util;

import wt.change2.WTChangeOrder2;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.CollationKeyFactory;
import wt.util.SortedEnumeration;
import wt.vc.config.LatestConfigSpec;
import wt.workflow.engine.WfEngineHelper;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

public class ChangeOrder2Util implements RemoteAccess {


    /**
     * 根据变更通告的VR查找到OR
     *
     * @param VR VR:wt.change2.WTChangeOrder2:2406173
     * @return OR OR:wt.change2.WTChangeOrder2:2406172
     */
    public static String getORbyVR(String VR) {
        VR = VR.split(":")[2];
        String sql = "SELECT IDA2A2 FROM WTCHANGEORDER2 WHERE BRANCHIDITERATIONINFO = ?";
        String OR = "";
        try {
            ResultSet resultSet = CommonUtil.excuteSelect(sql, VR);
            while (resultSet.next()) {
                OR = "OR:wt.change2.WTChangeOrder2:" + resultSet.getString("IDA2A2");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return OR;
    }


    /**
     * 根据编号获取对象
     *
     * @param String
     * @param Class
     * @return Object
     */
    @SuppressWarnings("deprecation")
    public static Object getObjByNumber(String number, Class queryClass) {
        try {
            if (number.isEmpty()) {
                return null;
            }
            QuerySpec qs = new QuerySpec(queryClass);
            qs.appendWhere(new SearchCondition(queryClass, "master>number", SearchCondition.EQUAL, number.trim()));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            qr = new LatestConfigSpec().process(qr);
            if (qr.hasMoreElements()) {
                return qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }







    /**
     * 根据持久化对象获取相关联的流程
     *
     * @param changeOrder2
     * @return WfProcess
     * @throws Exception
     */
    public static WfProcess getRelatedProcess(WTChangeOrder2 changeOrder2) throws Exception {
        System.out.println("变更单编号："+changeOrder2.getNumber());
        WfProcess process = null;
        QueryResult qrProcs = null;
        qrProcs = WfEngineHelper.service.getAssociatedProcesses(changeOrder2, null, null);
        System.out.println("qrProcs:"+qrProcs.hasMoreElements());
        // 按时间排序,取最新一个流程实例
        CollationKeyFactory timeKeyFact = new CollationKeyFactory() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

            public String getCollationString(Object o) {
                if (!(o instanceof Persistable) || !PersistenceHelper.isPersistent(o))
                    return "";
                return sdf.format(PersistenceHelper.getModifyStamp((Persistable) o));
            }
        };
        Enumeration enProcs = new SortedEnumeration(qrProcs, timeKeyFact, SortedEnumeration.DESCENDING);
        while (enProcs.hasMoreElements()) {
            process = (WfProcess) enProcs.nextElement();
            System.out.println("ECN关联的流程："+process.getName());
            // 最新的非子进程（子进程的名称带有$符号
            if (process.getName().indexOf("$") == -1) {
                break;
            }
        }
        return process;
    }

    /**
     * 获取流程中的所有活动
     *
     * @param process
     * @return ArrayList<WfAssignedActivity>
     */
    public static ArrayList<WfAssignedActivity> getWfAssignedActivitys(WfProcess process) {
        ArrayList<WfAssignedActivity> list = new ArrayList<WfAssignedActivity>();
        try {
            QuerySpec qs = new QuerySpec(WfAssignedActivity.class);
            qs.appendWhere(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key.id",
                    SearchCondition.EQUAL, process.getPersistInfo().getObjectIdentifier().getId()), new int[] { 0 });
            QueryResult qr = PersistenceHelper.manager.find(qs);
            while (qr.hasMoreElements()) {
                WfAssignedActivity act = (WfAssignedActivity) qr.nextElement();
                list.add(act);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 检查当前ECN是否在对应的节点
     * @return
     */
    public static String checkOperationInLegalNode(WTChangeOrder2 order2, String nodeName){
        String msg = null;
        List<String> actionNames = new ArrayList<>();
        try {
            WfProcess wfProcess = getRelatedProcess(order2);
            System.out.println("wfProcess:"+wfProcess);
            ArrayList<WfAssignedActivity> wfAssignedActivityList = getWfAssignedActivitys(wfProcess);
            for (WfAssignedActivity wfAssignedActivity : wfAssignedActivityList) {
                System.out.println("流程中活动的名称"+wfAssignedActivity.getName());

                actionNames.add(wfAssignedActivity.getName());
            }
        } catch (Exception e) {
            e.getMessage();
        }

        if(actionNames.contains(nodeName)){
        }else {
            msg = "当前流程节点不为"+nodeName+"无法进行操作";
        }
        return msg;
    }

}
