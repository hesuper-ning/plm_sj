package ext.kingdeeERP.changeBOM.util;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.WTObject;
import wt.method.RemoteAccess;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Enumeration;

import wt.change2.ChangeException2;
import wt.change2.ChangeHelper2;

import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.QueryResult;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.util.CollationKeyFactory;
import wt.util.SortedEnumeration;
import wt.util.WTException;
import wt.workflow.engine.WfEngineHelper;
import wt.workflow.engine.WfProcess;

public class WorkflowUtil implements RemoteAccess {

    /***
     * 获取审阅/变更目标对象
     *
     * @param <T>
     * @param WTObject 流程的primaryBusinessObject
     * @param String   GetTargerObjectUtil.AffectedObjects受影响对象/GetTargerObjectUtil.ResultingObjects产生的对象
     * @param clazz    WTPart.class/WTDocument.class
     * @return ArrayList<T>
     */
    public static <T> ArrayList<T> getTargerObject(WTObject primaryBusinessObject, String type, Class<T> clazz) {
        ArrayList<T> list = new ArrayList<T>();

        if (!type.equals("AffectedObjects") && !type.equals("ResultingObjects")) {
            System.out.println("获取审阅/变更目标对象失败，只能指定为受影响对象或产生的对象");
            return list;
        }

        try {
            if (primaryBusinessObject instanceof PromotionNotice) {

                PromotionNotice pn = (PromotionNotice) primaryBusinessObject;
                QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
                list = CommonUtil.getListFromQR(qr, clazz);

            } else if (primaryBusinessObject instanceof WTChangeOrder2) {

                if (type.equals("AffectedObjects")) {
                    WTChangeOrder2 eco = (WTChangeOrder2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesBefore(eco);
                    list = CommonUtil.getListFromQR(qr, clazz);
                } else if (type.equals("ResultingObjects")) {
                    WTChangeOrder2 eco = (WTChangeOrder2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eco);
                    list = CommonUtil.getListFromQR(qr, clazz);
                }

            } else if (primaryBusinessObject instanceof WTChangeActivity2) {

                if (type.equals("AffectedObjects")) {
                    WTChangeActivity2 eca = (WTChangeActivity2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesBefore(eca);
                    list = CommonUtil.getListFromQR(qr, clazz);
                } else if (type.equals("ResultingObjects")) {
                    WTChangeActivity2 eca = (WTChangeActivity2) primaryBusinessObject;
                    QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
                    list = CommonUtil.getListFromQR(qr, clazz);
                }

            }
        } catch (ChangeException2 e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }



}
