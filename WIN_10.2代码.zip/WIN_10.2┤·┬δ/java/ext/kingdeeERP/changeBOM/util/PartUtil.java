package ext.kingdeeERP.changeBOM.util;


import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import ext.kingdeeERP.changeBOM.ChangeBomConstant;
import ext.kingdeeERP.changeBOM.WTPartUsageLinkChangeItem;
import org.apache.commons.lang.StringUtils;
import wt.configuration.TraceCode;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.fc.Identified;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.CabinetBased;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.State;
import wt.method.RemoteAccess;
import wt.org.WTPrincipal;
import wt.part.*;
import wt.pds.StatementSpec;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.series.MultilevelSeries;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.sql.ResultSet;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PartUtil implements RemoteAccess {

    /**
     * 取得所有子部件的关联
     *
     * @param WTPart
     * @return Vector<WTPartUsageLink>
     */
    @SuppressWarnings("unchecked")
    public static Vector<WTPartUsageLink> getSubPartUsagelinks(WTPart parentPart) throws WTException {
        Vector<WTPartUsageLink> partlist = new Vector<>();
        QueryResult subParts = WTPartHelper.service.getUsesWTPartMasters(parentPart);
        while (subParts.hasMoreElements()) {
            WTPartUsageLink usagelink = (WTPartUsageLink) subParts.nextElement();
            partlist.addElement(usagelink);
        }
        return partlist;
    }

    /**
     * 根据编号查询part
     *
     * @param String
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static WTPart getWTPartByNumber(String number) {
        WTPart result = null;
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            LatestConfigSpec cfg = new LatestConfigSpec();
            QueryResult qr1 = cfg.process(qr);
            if (qr1 != null && qr1.hasMoreElements()) {
                result = (WTPart) qr1.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 根据编号查询List
     *
     * @param String
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static List<WTPart> getWTPartListByNumber(String number) {
        List<WTPart> result = new ArrayList<WTPart>();
        QueryResult qr = null;
        try {
            QuerySpec qs = new QuerySpec(WTPart.class);
            SearchCondition scnumber = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
                    number.toUpperCase());
            qs.appendSearchCondition(scnumber);
            qs.appendAnd();
            SearchCondition sclatest = VersionControlHelper.getSearchCondition(WTPart.class, true);
            qs.appendSearchCondition(sclatest);
            qr = PersistenceHelper.manager.find(qs);
            while (qr != null && qr.hasMoreElements()) {
                result.add((WTPart) qr.nextElement());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 不递归获取部件所有的子部件
     *
     * @param WTPart
     * @return List<WTPart>
     */
    public static List<WTPart> getBomByPart(WTPart ProductPart) {
        WTPart sPart = null;
        QueryResult qr2 = null;
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(ProductPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    list.add(sPart);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 递归获取部件的所有子部件
     *
     * @param WTPart
     * @return List<WTPart>
     */
    public static List<WTPart> getAllBomByPart(WTPart part) {
        List<WTPart> localList = new ArrayList<>(); // 局部列表用于递归操作的累积结果

        WTPart sPart = null;
        QueryResult qr2 = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(part);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    localList.add(sPart);

                    // 递归调用，将结果合并到局部列表
                    localList.addAll(getAllBomByPart(sPart));
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return localList; // 返回局部列表
    }

    /**
     * 修改部件编号
     *
     * @param WTPart
     * @param String
     */
    public static void changePartNumber(WTPart part, String newPartNumber) {
        try {
            part = (WTPart) PersistenceHelper.manager.refresh(part);
            Identified identified = (Identified) part.getMaster();
            WTPartMasterIdentity partIdentity = (WTPartMasterIdentity) identified.getIdentificationObject();
            partIdentity.setNumber(newPartNumber);
            identified = wt.fc.IdentityHelper.service.changeIdentity(identified, partIdentity);
            part = (WTPart) PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 修改部件名称
     *
     * @param WTPart
     * @param String
     */
    public static void changePartName(WTPart part, String newName) {
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();
            part = (WTPart) PersistenceHelper.manager.refresh(part);
            Identified identified = (Identified) part.getMaster();
            WTPartMasterIdentity partIdentity = (WTPartMasterIdentity) identified.getIdentificationObject();
            partIdentity.setName(newName);
            identified = wt.fc.IdentityHelper.service.changeIdentity(identified, partIdentity);
            part = (WTPart) PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (currentUser != null) {
                try {
                    SessionHelper.manager.setPrincipal(currentUser.getName());
                } catch (WTException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 获取原样位号
     *
     * @param WTPartUsageLink
     * @return String
     * @throws WTException
     */
    @SuppressWarnings({ "unchecked", "deprecation" })
    public static String getPartUsesOccurrence(WTPartUsageLink useagelink) {
        String occurrenceStr = "";
        List listWTPart2 = new ArrayList();
        long linkid = PersistenceHelper.getObjectIdentifier(useagelink).getId();
        try {
            QuerySpec qs = new QuerySpec(PartUsesOccurrence.class);
            qs.appendWhere(new SearchCondition(PartUsesOccurrence.class, "linkReference.key.id", SearchCondition.EQUAL,
                    linkid));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            while (qr.hasMoreElements()) {
                PartUsesOccurrence occurrence = (PartUsesOccurrence) qr.nextElement();
                listWTPart2.add(occurrence.getName());
            }
            for (int i = 0; i < listWTPart2.size(); i++) {
                if (listWTPart2.get(i) != null) {
                    String ocName = listWTPart2.get(i).toString();
                    if (i == 0) {
                        occurrenceStr = ocName;
                    } else {
                        occurrenceStr = occurrenceStr + "," + ocName;
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return sortPlaceNumber(occurrenceStr);
    }

    // 对位号排序
    public static String sortPlaceNumber(String numberStr) {
        TreeMap<String, String> tm = new TreeMap<>();
        String[] s = numberStr.split(",");
        for (int i = 0; i < s.length; i++) {
            tm.put(s[i], s[i]);
        }
        Iterator it = tm.keySet().iterator();
        String number = "";
        int a = 0;
        while (it.hasNext()) {
            if (a == 0) {
                number = (String) it.next();
            } else {
                number = number + "," + (String) it.next();
            }
            a++;
        }
        return number;
    }


    /**
     * 修改部件生命周期状态
     *
     * @param WTPart
     * @param String
     * @return String
     * @throws WTPropertyVetoException
     * @throws WTException
     */
    public static String changePartState(WTPart part, String state) throws WTPropertyVetoException, WTException {
        String message = "";
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();

            part = (WTPart) wt.lifecycle.LifeCycleHelper.service.setLifeCycleState((wt.lifecycle.LifeCycleManaged) part,
                    State.toState(state));

            PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return message;
    }

    /**
     * 修改部件状态（直接使用State进行修改）
     *
     * @param WTPart
     * @param State
     * @return String
     * @throws WTPropertyVetoException
     * @throws WTException
     */
    public static String changePartState(WTPart part, State state) throws WTPropertyVetoException, WTException {
        String message = "";
        WTPrincipal currentUser = null;
        try {
            currentUser = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setAdministrator();

            part = (WTPart) wt.lifecycle.LifeCycleHelper.service.setLifeCycleState((wt.lifecycle.LifeCycleManaged) part,
                    state);

            PersistenceHelper.manager.refresh(part);
        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            if (currentUser != null) {
                SessionHelper.manager.setPrincipal(currentUser.getName());
            }
        }
        return message;
    }

    /**
     * 通过说明文档找到部件
     *
     * @param WTDocument
     * @return List<WTPart>
     */
    public static List<WTPart> getPartByDescribesDoc(WTDocument doc) {
        QueryResult qr = null;
        WTPart part = null;
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            qr = WTPartHelper.service.getDescribesWTParts(doc);// 说明文档
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTPart) {
                    part = (WTPart) obj;
                    System.out.println("通过文档找到的部件名称为="+part.getName());
                    list.add(part);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 获取参考文档关联的部件
     *
     * @param WTDocument
     * @return List<WTPart>
     */
    public static List<WTPart> getPartByRefrenceDoc(WTDocument doc) {
        QueryResult qr = null;
        WTPart part = null;
        List<WTPart> list = new ArrayList<WTPart>();
        try {
            qr = StructHelper.service.navigateReferencedBy(doc.getMaster());// 参考关系
            while (qr.hasMoreElements()) {
                Object obj = qr.nextElement();
                if (obj instanceof WTPart) {
                    part = (WTPart) obj;
                    list.add(part);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 获取部件间的关联关系
     *
     * @param WTPart
     * @param WTPart
     * @return WTPartUsageLink
     */
    public static WTPartUsageLink getLinkByPart(WTPart fatherPart, WTPart sonPart) {
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                WTPart part = getBomPartBylink(link);
                if (part.getNumber().equals(sonPart.getNumber())) {
                    return link;
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 根据部件间的关联关系获取子部件
     *
     * @param WTPartUsageLink
     * @return WTPart
     */
    public static WTPart getBomPartBylink(WTPartUsageLink link) {
        try {
            QueryResult qr = VersionControlHelper.service.allVersionsOf(link.getUses());
            if (qr.hasMoreElements()) {
                WTPart part = (WTPart) qr.nextElement();
                return part;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取部件与其所有子部件间的关联关系
     *
     * @param WTPart
     * @return List<WTPartUsageLink>
     */
    public static List<WTPartUsageLink> getLinksByPart(WTPart fatherPart) {
        System.out.println("getNumber" + fatherPart.getNumber());
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink link = (WTPartUsageLink) qr.nextElement();
                list.add(link);
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        System.out.println("listsize" + list.size());
        return list;
    }

    /**
     * 获取部件的子部件和数量关系
     *
     * @param WTPart
     * @param List<Object[]>
     * @return List<Object[]>
     */
    public static List<Object[]> getAllBomByParentPart(WTPart parentPart, List<Object[]> list) {
        WTPart sPart = null;
        QueryResult qr2 = null;
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(parentPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                qr2 = VersionControlHelper.service.allVersionsOf(usageLink.getUses());
                if (qr2.hasMoreElements()) {
                    sPart = (WTPart) qr2.nextElement();
                    boolean found = false;
                    for (Object[] old : list) {
                        WTPart object = (WTPart) old[0];
                        String number = object.getNumber();
                        if (sPart.getNumber().equalsIgnoreCase(number)) {
                            old[1] = (Double) old[1] + usageLink.getQuantity().getAmount();
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        list.add(new Object[] { sPart, usageLink.getQuantity().getAmount() });
                    }
                    getAllBomByParentPart(sPart, list);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 检入部件
     *
     * @param WTPart
     * @param String
     * @return WTPart
     * @throws WTException
     */
    public static WTPart checkinPart(WTPart partParentPrevious, String comment) throws WTException {
        WTPart part = null;
        if (partParentPrevious != null) {
            try {
                WTPrincipal wtprincipal = SessionHelper.manager.getPrincipal();
                if (WorkInProgressHelper.isCheckedOut((Workable) partParentPrevious, wtprincipal)) {
                    if (!WorkInProgressHelper.isWorkingCopy((Workable) partParentPrevious)) {
                        partParentPrevious = (WTPart) WorkInProgressHelper.service
                                .workingCopyOf((Workable) partParentPrevious);
                    }
                    part = (WTPart) WorkInProgressHelper.service.checkin((Workable) partParentPrevious, comment);
                }
            } catch (WTPropertyVetoException ex) {
                ex.printStackTrace();
            }
        }
        return part;
    }


    /**
     * 根据子部件获取所有父部件之间的关联
     *
     * @param WTPart
     * @return List<WTPartUsageLink>
     */
    @SuppressWarnings("deprecation")
    public static List<WTPartUsageLink> getBomLinkByChildPart(WTPart childPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 通过父部件和子部件获取部件之间使用关系
     *
     * @param fatherPart
     * @param childPart
     * @return
     */
    public static List<WTPartUsageLink> getWtPartUsageLink(WTPart fatherPart, WTPart childPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            if (childPart != null) {
                QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier(fatherPart)));
                queryspec.appendAnd();
                queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                        PersistenceHelper.getObjectIdentifier((WTPartMaster) childPart.getMaster())));
                QueryResult qr = PersistenceHelper.manager.find((StatementSpec) queryspec);
                while (qr.hasMoreElements()) {
                    WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                    list.add(usageLink);
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 复制一个新部件（名称与编号不同）
     *
     * @param WTPart
     * @param String
     * @return WTPart
     */
    @SuppressWarnings("deprecation")
    public static WTPart copyPart(WTPart part, String partName) {
        WTPart newPart = null;
        try {
            String number = part.getNumber();
            LifeCycleState state = part.getState();
            Source source = part.getSource();
            PartType partType = part.getPartType(); // 装配模式
            boolean endItem = part.isEndItem(); // 成品
            QuantityUnit defaultUnit = part.getDefaultUnit();// 单位
            boolean hidePartInStructure = part.getHidePartInStructure();// 收集部件
            TraceCode defaultTraceCode = part.getDefaultTraceCode(); // 默认追踪代码
            String location = FolderHelper.getLocation((CabinetBased) part);
            WTContainer container2 = WTContainerHelper.getContainer((WTContained) part);
            WTContainerRef containerRef = WTContainerRef.newWTContainerRef(container2);

            String newNumber = number.substring(0, number.length() - 1);
            String suffix = number.substring(number.length() - 1);

            if ("0".equals(suffix)) {
                newNumber += "1";
            } else if ("1".equals(suffix)) {
                newNumber += "0";
            }

            newPart = WTPart.newWTPart();
            newPart.setName(partName);
            newPart.setNumber(newNumber);
            newPart.setState(state);
            newPart.setSource(source);
            newPart.setPartType(partType);
            newPart.setEndItem(endItem);
            newPart.setHidePartInStructure(hidePartInStructure);
            newPart.setDefaultUnit(defaultUnit);
            newPart.setDefaultTraceCode(defaultTraceCode);
            newPart.setView(part.getView());
            FolderHelper.assignLocation((FolderEntry) newPart, location, containerRef);
            PersistenceHelper.manager.save(newPart);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return newPart;
    }


    /**
     * 根据url获取对应的wtpart对象
     * http://plmtest.sinoboom.com.cn/Windchill/app/#ptc1/tcomp/infoPage?u8=1&oid=OR%3Awt.part.WTPart%3A804374507
     * http://plmtest.sinoboom.com.cn/Windchill/app/#ptc1/tcomp/infoPage?oid=OR:wt.part.WTPart:1099247509
     *
     * @param String
     * @return WTPart
     */
    public static WTPart getPartFromURL(String url) {
        try {
            Pattern pattern = Pattern.compile("(?<=WTPart)(%3A|:)([0-9]+)");
            String oid = "";
            Matcher matcher = pattern.matcher(url);
            if (matcher.find()) {
                oid = matcher.group(2);
            }
            WTPart part = (WTPart) PersistenceUtil.oid2Object(oid);
            return part;
        } catch (Exception e) {
            System.out.println("系统未找到url指定的部件");
            return null;
        }
    }


    /**
     * 根据部件的VR查找到部件的OR
     *
     * @param VR VR:wt.part.WTPart:569305
     * @return OR OR:wt.part.WTPart:569306
     */
    public static String getORbyVR(String VR) {
        VR = VR.split(":")[2];
        String sql = "SELECT IDA2A2 FROM WTPART WHERE BRANCHIDITERATIONINFO = ?";
        String OR = "";
        try {
            ResultSet resultSet = CommonUtil.excuteSelect(sql, VR);
            while (resultSet.next()) {
                OR = "OR:wt.part.WTPart:" + resultSet.getString("IDA2A2");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return OR;
    }



    /**
     * 通过部件编号修订到下一个大版本
     * @param number
     * @return
     */
    public static WTPart reviseWTPartByNumber(WTPart partByNumber) throws WTException, WTPropertyVetoException {
        // 修订后的部件对象
        WTPart afterReviseWTPart = null;
        // 获取当前版本
        RevisionControlled latestObjectByMaster = VersionUtil.getLatestObjectByMaster(partByNumber.getMaster());

        String bigVersion = latestObjectByMaster.getVersionIdentifier().getValue();
        System.out.println("当前部件的大版本为="+bigVersion);

        char c = bigVersion.charAt(0);
        String nextLetter = getNextLetter(c);
        System.out.println("获得到下一大版本="+nextLetter);

        // 修订
        // 大版本设定
        MultilevelSeries mls = MultilevelSeries.newMultilevelSeries ("wt.vc.VersionIdentifier", nextLetter);

        // 小版本设定
        VersionIdentifier vid = VersionIdentifier.newVersionIdentifier(mls);
        IterationIdentifier iid = IterationIdentifier.newIterationIdentifier("1");

        afterReviseWTPart = (WTPart) VersionControlHelper.service.newVersion(partByNumber,vid,iid);
        afterReviseWTPart=(WTPart) PersistenceHelper.manager.save(afterReviseWTPart);

        return afterReviseWTPart;
    }


    /**
     * 传入一个版本字母 如A 返回下一版本如B
     * @param letter
     * @return
     */
    public static String getNextLetter(char letter) {

        char nextChar = (char) (letter + 1);

        return String.valueOf(nextChar);
    }



    /**
     * 根据part得到其子部件link
     *
     * @param productPart
     * @return
     */
    public static List<WTPartUsageLink> getBomLinkByPart(WTPart productPart) {
        List<WTPartUsageLink> list = new ArrayList<WTPartUsageLink>();
        try {
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(productPart);
            while (qr.hasMoreElements()) {
                WTPartUsageLink usageLink = (WTPartUsageLink) qr.nextElement();
                list.add(usageLink);
            }
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 创建父子部件的连接关系
     * @param parentPart
     * @param sonPart
     * @param qty
     * tarNum 工号
     * @return
     * @throws WTException
     */
    public static WTPartUsageLink newUsgeLink(WTPart parentPart,WTPartMaster sonPart,String qty,String tarNum,String isByCust,String IsCustomerService,String ItemNote,Long lineNumber,String BOMSkip) throws Exception {
        WTPartUsageLink part_UsageLink = WTPartUsageLink.newWTPartUsageLink( parentPart ,sonPart );
        String unit = "ea";//bom单位默认ea  (自定义)
        QuantityUnit qu = null;
        qu = QuantityUnit.toQuantityUnit( unit );

        qty = qty==null?"0":qty;
        Quantity qa = Quantity.newQuantity( Double.parseDouble( qty ) , qu );// 设置数量

        if(lineNumber ==0){

        }else {
            part_UsageLink.setLineNumber(LineNumber.newLineNumber(lineNumber));
        }
        part_UsageLink.setQuantity( qa );

        // 修改工号IBA属性
        part_UsageLink = (WTPartUsageLink)PersistenceHelper.manager.save( part_UsageLink );
        IBAUtil ibaUtil = new IBAUtil(part_UsageLink);
        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.TAG_NUMBER, tarNum);

        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.IS_BY_CUST, isByCust);
        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.IS_CUSTOMER_SERVICE, IsCustomerService);
        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.ITEM_NOTE, ItemNote);
        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.BOM_SKIP, BOMSkip);
        ibaUtil.setIBAAttribute4AllType(part_UsageLink, ChangeBomConstant.Level_CJ, "*");

        return part_UsageLink;
    }


    /**
     * 创建父子部件的连接关系替换时使用
     * @param parentPart
     * @param sonPart
     * @param beforeChildLinkQuantity
     * tarNum 工号
     * @return
     * @throws WTException
     */
    public static WTPartUsageLink newUsgeLink(WTPart parentPart,WTPartMaster sonPart,Quantity beforeChildLinkQuantity,WTPartUsageLink beforeChildLink, String afterTarNum) throws Exception {
        WTPartUsageLink part_UsageLink = WTPartUsageLink.newWTPartUsageLink( parentPart ,sonPart );

        // 获取旧有连接的工号
        IBAUtil beforeLinkIBA = new IBAUtil(beforeChildLink);
        Quantity qa = Quantity.newQuantity( beforeChildLinkQuantity.getAmount() , beforeChildLinkQuantity.getUnit() );// 设置数量
        part_UsageLink.setQuantity( qa );
        part_UsageLink.setLineNumber(beforeChildLink.getLineNumber());

        // 获取旧连接的自定义IBA属性
        String isByCust = beforeLinkIBA.getIBAValue(ChangeBomConstant.IS_BY_CUST);
        String isCustomService = beforeLinkIBA.getIBAValue(ChangeBomConstant.IS_CUSTOMER_SERVICE);
        String itemNote = beforeLinkIBA.getIBAValue(ChangeBomConstant.ITEM_NOTE);
        String BomSkip = beforeLinkIBA.getIBAValue(ChangeBomConstant.BOM_SKIP);

        // 修改工号IBA属性
        part_UsageLink = (WTPartUsageLink)PersistenceHelper.manager.save( part_UsageLink );
        IBAUtil ibaUtil = new IBAUtil(part_UsageLink);
        ibaUtil.setIBAValue(ChangeBomConstant.TAG_NUMBER, afterTarNum);

        ibaUtil.setIBAValue(ChangeBomConstant.IS_BY_CUST, isByCust);
        ibaUtil.setIBAValue(ChangeBomConstant.IS_CUSTOMER_SERVICE, isCustomService);
        ibaUtil.setIBAValue(ChangeBomConstant.ITEM_NOTE, itemNote);
        ibaUtil.setIBAValue(ChangeBomConstant.BOM_SKIP, BomSkip);


        return part_UsageLink;
    }

    //02.零件号  返回 WTPartMaster 对象
    public static WTPartMaster getWTPartMasterByNumber(String paramString)
            throws WTException
    {
        WTPartMaster localWTPartMaster = null;
        QuerySpec localQuerySpec = null;
        QueryResult localQueryResult = null;
        localQuerySpec = new QuerySpec(WTPartMaster.class);

        SearchCondition localSearchCondition = new SearchCondition(WTPartMaster.class, "number", "LIKE", paramString);
        localQuerySpec.appendSearchCondition(localSearchCondition);
        localQueryResult = PersistenceHelper.manager.find(localQuerySpec);
        if (localQueryResult.hasMoreElements())
        {
            localWTPartMaster = (WTPartMaster)localQueryResult.nextElement();
        }

        return localWTPartMaster;
    }

    /**
     * 获取父子部件的连接
     * @param part
     * @param subMaster
     * @return
     */
    public static WTPartUsageLink findWTPartUsageLink(WTPart part, WTPartMaster subMaster) {
        WTPartUsageLink link = null;
        if (part == null || subMaster == null) {
            return link;
        }
        try {
            QuerySpec queryspec = new QuerySpec(WTPartUsageLink.class);
            queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleAObjectRef.key", "=",
                    PersistenceHelper.getObjectIdentifier(part)), new int[] {});
            queryspec.appendAnd();
            queryspec.appendWhere(new SearchCondition(WTPartUsageLink.class, "roleBObjectRef.key", "=",
                    PersistenceHelper.getObjectIdentifier(subMaster)), new int[] {});
            QueryResult qr = PersistenceHelper.manager.find(queryspec);
            if (qr != null && qr.hasMoreElements()) {
                link = (WTPartUsageLink) qr.nextElement();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return link;
    }


    /**
     * 根据部件于获取局部替代料的关联关系
     *
     * @param WTPart part
     * @return List<WTPartSubstituteLink>
     */
    public static List<WTPartSubstituteLink> getWTPartSubstituteLinks(WTPartUsageLink usageLink) {
        if (usageLink == null) {
            return null;
        }
        List<WTPartSubstituteLink> list = new ArrayList<WTPartSubstituteLink>();
        long masterId = PersistenceHelper.getObjectIdentifier(usageLink).getId();
        int[] index = { 0 };
        try {
            QuerySpec qs = new QuerySpec(WTPartSubstituteLink.class);
            qs.appendWhere(new SearchCondition(WTPartSubstituteLink.class, "roleAObjectRef.key.id",
                    SearchCondition.EQUAL, masterId), index);
            QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
            while (qr.hasMoreElements()) {
                WTPartSubstituteLink sLink = (WTPartSubstituteLink) qr.nextElement();
                list.add(sLink);
            }
        } catch (QueryException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**
     * 用于可能出现多个子项的BOM 通过工位精准查询到
     * @param parent
     * @param tarNum
     * @return
     */
    public static WTPartUsageLink getLinkByParentAndTarNum(WTPart parent, WTPartMaster partMaster ,String tarNum) throws WTException {
        WTPartUsageLink wtPartUsageLink = null;
        List<WTPartUsageLink> linkByPart = getBomLinkByPart(parent);
        HashMap<String,WTPartUsageLink> linkMap = new HashMap<>();
        for (WTPartUsageLink link : linkByPart){
            WTPartMaster linkUsesMaster = link.getUses();
            if(linkUsesMaster.equals(partMaster)){
                IBAUtil ibaUtil = new IBAUtil(link);
                String tar = ibaUtil.getIBAValue(ChangeBomConstant.TAG_NUMBER);
                linkMap.put(tar,link);
            }
        }
        Set<Map.Entry<String, WTPartUsageLink>> entries = linkMap.entrySet();
        if (linkMap.size() == 1) {
            // 如果HashMap的长度为1，获取唯一的value赋值给wtPartUsageLink
            for (Map.Entry<String, WTPartUsageLink> entry : entries) {
                wtPartUsageLink = entry.getValue();
                return wtPartUsageLink;
            }
        }



        if(linkMap.size() > 1){
            System.out.println("传入的改前工位是="+tarNum);
            if(tarNum ==null){
                tarNum = "";
            }
            System.out.println("得到的相同Master的Link个数为="+linkMap.size());
            for(Map.Entry<String, WTPartUsageLink> entry:entries){
                String key = entry.getKey();
                System.out.println("得到的相同Master的Link个的工位有="+key);
                if(key.equals(tarNum)){
                    wtPartUsageLink = entry.getValue();
                    break;
                }
            }
        }
        return wtPartUsageLink;
    }


    /**
     * 由于未检出前的usageLink不能直接做删除 所以检出前的link只能作为一个找到Link的工具
     * @param oldLink
     * @param parent
     * @return
     */
    public static WTPartUsageLink getLinkByOldUsageLink(WTPartUsageLink oldLink,WTPart parent) throws WTException {
        WTPartUsageLink wtPartUsageLink = null;
        List<WTPartUsageLink> linkByPart = getBomLinkByPart(parent);
        WTPartMaster oldLinkMaster = oldLink.getUses();
        IBAUtil oldLinkIBA = new IBAUtil(oldLink);
        String oldTarNum = oldLinkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
        System.out.println("旧连接的工位为："+oldTarNum);
        HashMap<String,WTPartUsageLink> linkMap = new HashMap<>();

        for (WTPartUsageLink link : linkByPart){
            WTPartMaster linkUses = link.getUses();
            IBAUtil linkIBA = new IBAUtil(link);
            String tarNum = linkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
            if(linkUses.equals(oldLinkMaster)){
                System.out.println("当前查到的改前子项部件的编号为："+linkUses.getNumber()+"工位为"+tarNum);
                linkMap.put(tarNum,link);
            }

        }
        Set<Map.Entry<String, WTPartUsageLink>> entries = linkMap.entrySet();
        if(linkMap.size() ==1){
            for (Map.Entry<String, WTPartUsageLink> entry : entries) {
                wtPartUsageLink = entry.getValue();
                return wtPartUsageLink;
            }
        }else {
            for(Map.Entry<String, WTPartUsageLink> entry:entries){
                String key = entry.getKey();
                if(key.equals(oldTarNum)){
                    wtPartUsageLink = entry.getValue();
                }
            }
        }
        return wtPartUsageLink;
    }


    /**
     * 检查传入的改后工位在BOM中是否存在重复
     * @param afterTarNum
     * @param parentPart
     * @param oldLink
     * @return
     */
    public static String checkTarNumberInBOM(String afterTarNum,WTPart parentPart, WTPartUsageLink oldLink,List<String> itemAfterTarList, WTPartMaster sonMaster, List<WTPartUsageLinkChangeItem> items) throws WTException {
        StringBuffer msg = new StringBuffer();
        String[] afterTarNumArray = afterTarNum.trim().split("\\s+");
        List<String> afterTarNumList = new ArrayList<>(Arrays.asList(afterTarNumArray));

        List<String> allBomTarNum = new ArrayList<>(itemAfterTarList);

        List<WTPartUsageLink> linksByPart = PartUtil.getLinksByPart(parentPart);
        for(WTPartUsageLink link: linksByPart){
            IBAUtil linkIBA = new IBAUtil(link);
            String ibaTarNum = linkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
            if(!ibaTarNum.isEmpty()){
                String[] ibaTarNumArray = ibaTarNum.trim().split("\\s+");
                // 将数组ibaTarNumArray里的数据放入allBomTarNum集合中null值除外
                for (String num : ibaTarNumArray) {
                    if (num != null && !num.isEmpty()) {
                        allBomTarNum.add(num);
                    }
                }
            }
        }

        // 传入的工位和旧有BOM中工位的重复值集合
        Set<String> commonValues = new HashSet<>();

        // 相同子项下的工位
        Set<String> sameNumPartTar = new HashSet<>();

        if(oldLink == null){
            if(itemAfterTarList.size() == allBomTarNum.size()){
                // 说明是BOM中不存在的料
            }else {
                // 说明是添加子项的 只需要比对传入的
                for (String tarNum : afterTarNumList) {
                    if (allBomTarNum.contains(tarNum)) {
                        commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
                    }
                }
                for(WTPartUsageLink link: linksByPart){
                    if(link.getUses().equals(sonMaster)){
                        IBAUtil linkIBA = new IBAUtil(link);
                        String ibaTarNum = linkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
                        if(!ibaTarNum.isEmpty()){
                            String[] ibaTarNumArray = ibaTarNum.trim().split("\\s+");
                            for (String num : ibaTarNumArray) {
                                if (num != null) {
                                    sameNumPartTar.add(num);
                                }
                            }
                        }else {
                            sameNumPartTar.add(ibaTarNum);
                        }
                    }
                }

                // 如果变更项中相同改后子项的空工位情况
                for (WTPartUsageLinkChangeItem item:items){
                    String afterChildMasterOR = item.getAfterChildMasterOR();
                    if(afterChildMasterOR !=null){
                        WTPartMaster afterMaster = (WTPartMaster) PersistenceUtil.oid2Object(afterChildMasterOR);
                        if(afterMaster.equals(sonMaster)){
                            String tagNumber = item.getNewAMountA7TagNumber();
                            if(tagNumber == null){
                                sameNumPartTar.add("");
                            }else {
                                String[] ibaTarNumArray = tagNumber.trim().split("\\s+");
                                sameNumPartTar.addAll(Arrays.asList(ibaTarNumArray));
                            }
                        }
                    }
                }

            }



        }else {
            // 修改替换 需要排除旧连接的工位
            IBAUtil oldLinkIBAutil = new IBAUtil(oldLink);
            String oldTarNum = oldLinkIBAutil.getIBAValue(ChangeBomConstant.TAG_NUMBER);
            if(oldTarNum != null){
                String[] oldTarNumArray = oldTarNum.trim().split("\\s+");
                // 排除掉旧链接里的工位
                for (String old : oldTarNumArray){
                    allBomTarNum.remove(old);
                }
            }

            for (String tarNum : afterTarNumList) {
                if (allBomTarNum.contains(tarNum)) {
                    System.out.println("进入替换、修改的判定为重复工位中当前重复的工位为="+tarNum+"字符串长度为"+tarNum.length());
                    commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
                }
            }

            // 如果变更项中相同改后子项的空工位情况
            for (WTPartUsageLinkChangeItem item:items){
                String afterChildMasterOR = item.getAfterChildMasterOR();
                if(afterChildMasterOR !=null){
                    WTPartMaster afterMaster = (WTPartMaster) PersistenceUtil.oid2Object(afterChildMasterOR);
                    if(afterMaster.equals(sonMaster)){
                        String tagNumber = item.getNewAMountA7TagNumber();
                        if(tagNumber == null){
                            sameNumPartTar.add("");
                        }else {
                            String[] ibaTarNumArray = tagNumber.trim().split("\\s+");
                            sameNumPartTar.addAll(Arrays.asList(ibaTarNumArray));
                        }
                    }
                }
            }


            // 找BOM中的相同子料并排除开旧连接中的工位
            for(WTPartUsageLink link: linksByPart){
                if(link.getUses().equals(sonMaster)){
                    if(link.equals(oldLink)){
                        continue;
                    }else {
                        IBAUtil ibaUtil = new IBAUtil(link);
                        String ibaValue = ibaUtil.getIBAValue(ChangeBomConstant.TAG_NUMBER);
                        sameNumPartTar.addAll(Arrays.asList(ibaValue.split("\\s+")));
                    }
                }
            }
        }


        for (String tarNum : afterTarNumList) {
            if (sameNumPartTar.contains(tarNum)) {
                commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
            }
        }


        // 判断重复工位集合是否为空 如果为空说明没有重复工位 反之需要报异常
        if(commonValues.isEmpty()){
            return null;
        }else {
            msg.append("以下工位在原BOM中已经存在重复请检查：");
            for (String commonValue :commonValues){
                msg.append(commonValue).append("、");
            }
            return msg.toString();
        }

    }




    /**
     * 检查传入的改后工位在BOM中是否存在重复 PCBA专用
     * @param afterTarNum
     * @param parentPart
     * @param oldLink
     * @return
     */
    public static String checkTarNumberInBOM(String afterTarNum,WTPart parentPart, WTPartUsageLink oldLink,List<String> itemAfterTarList,List<WTPartUsageLinkChangeItem> items) throws WTException {
        StringBuffer msg = new StringBuffer();
        String[] afterTarNumArray = afterTarNum.trim().split("\\s+");
        List<String> afterTarNumList = new ArrayList<>(Arrays.asList(afterTarNumArray));

        List<String> allBomTarNum = new ArrayList<>(itemAfterTarList);

        List<WTPartUsageLink> linksByPart = PartUtil.getLinksByPart(parentPart);
        for(WTPartUsageLink link: linksByPart){
            IBAUtil linkIBA = new IBAUtil(link);
            String ibaTarNum = linkIBA.getIBAValue(ChangeBomConstant.TAG_NUMBER);
            if(!ibaTarNum.isEmpty()){
                String[] ibaTarNumArray = ibaTarNum.trim().split("\\s+");
                // 将数组ibaTarNumArray里的数据放入allBomTarNum集合中null值除外
                for (String num : ibaTarNumArray) {
                    if (num != null && !num.isEmpty()) {
                        allBomTarNum.add(num);
                    }
                }
            }
        }

        // 传入的工位和旧有BOM中工位的重复值集合
        Set<String> commonValues = new HashSet<>();



        if(oldLink == null){
            if(itemAfterTarList.size() == allBomTarNum.size()){
                // 说明是BOM中不存在的料
            }else {
                // 说明是添加子项的 只需要比对传入的
                for (String tarNum : afterTarNumList) {
                    if (allBomTarNum.contains(tarNum)) {
                        commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
                    }
                }
            }
        }else {
            // 修改替换 需要排除旧连接的工位
            IBAUtil oldLinkIBAutil = new IBAUtil(oldLink);
            String oldTarNum = oldLinkIBAutil.getIBAValue(ChangeBomConstant.TAG_NUMBER);
            if(oldTarNum != null){
                String[] oldTarNumArray = oldTarNum.trim().split("\\s+");
                // 排除掉旧链接里的工位
                for (String old : oldTarNumArray){
                    allBomTarNum.remove(old);
                }
            }

            for (String tarNum : afterTarNumList) {
                if (allBomTarNum.contains(tarNum)) {
                    commonValues.add(tarNum); // 将相同的值添加到commonValues集合中
                }
            }
        }

        // 判断重复工位集合是否为空 如果为空说明没有重复工位 反之需要报异常
        if(commonValues.isEmpty()){
            return null;
        }else {
            msg.append("以下工位在原BOM中已经存在重复请检查：");
            for (String commonValue :commonValues){
                msg.append(commonValue).append("、");
            }
            return msg.toString();
        }

    }





















    /**
     * 传入一个父部件返回在table上可以点击的物料编号连接
     * @param part
     * @return
     * @throws WTException
     */
    public static UrlDisplayComponent getPartUrlByPartNumber(WTPart part) throws WTException {
        NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();

        urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);

        NmOid contentOid = NmOid.newNmOid(part.getPersistInfo().getObjectIdentifier());

        String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null, true);

        UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent("", part.getNumber(), link);
        return urlDisplayComponent;
    }








//    public static WTPart getLastPartByVersion(WTPart part, String version) throws WTException {
//        WTPart currentPart = null;
//        QueryResult qr = VersionControlHelper.service.allVersionsOf(part);
//        while (qr.hasMoreElements()) {
//            if (qr.nextElement() instanceof WTPart) {
//                if (StringUtils.equals(currentPart.getVersionIdentifier().getValue(), version))
//                    currentPart = (WTPart) qr.nextElement();
//            }
//        }
//        return currentPart;
//    }

    /**
     * 获取指定版本的最新小版本
     */
    public static WTPart getLastPartByVersion(WTPart epm, String version) throws WTException {
        System.out.println("查询的版本"+version);
        WTPart currentPart = null;
        QueryResult qr = VersionControlHelper.service.allVersionsOf(epm);
        while (qr != null && qr.hasMoreElements()) {
            WTPart epmLast = (WTPart) qr.nextElement();
            if (epmLast.getVersionIdentifier().getValue().equals(version))
                currentPart = epmLast;
        }
        return currentPart;
    }

}

