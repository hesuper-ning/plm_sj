package ext.kingdeeERP.changeBOM;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;
@RBUUID("ext.kingdeeERP.changeBOM.CustomRB")
public class CustomRB extends WTListResourceBundle {


    @RBEntry("change content")
    public static final String CHANGE_CONTENT = "change_content";

    @RBEntry("change content")
    public static final String PRIVATE_CONSTANT_7 = "changeNotBom.changeBom.description";
    @RBEntry("change content")
    public static final String PRIVATE_CONSTANT_8 = "changeNotBom.changeBom.tooltip";


    @RBEntry("add")
    public static final String PRIVATE_CONSTANT_9 = "changeNotBom.addWizard.description";
    @RBEntry("add")
    public static final String PRIVATE_CONSTANT_10 = "changeNotBom.addWizard.tooltip";

    @RBEntry("add16x16.gif")
    public static final String PRIVATE_CONSTANT_11 = "changeNotBom.addWizard.icon";



    @RBEntry("update")
    public static final String PRIVATE_CONSTANT_12 = "changeNotBom.updateWizard.description";
    @RBEntry("update")
    public static final String PRIVATE_CONSTANT_13 = "changeNotBom.updateWizard.tooltip";

    @RBEntry("multi_update.gif")
    public static final String PRIVATE_CONSTANT_14 = "changeNotBom.updateWizard.icon";


    @RBEntry("delete")
    public static final String PRIVATE_CONSTANT_15 = "changeNotBom.deleteWizard.description";
    @RBEntry("delete")
    public static final String PRIVATE_CONSTANT_16 = "changeNotBom.deleteWizard.tooltip";

    @RBEntry("create_purge.gif")
    public static final String PRIVATE_CONSTANT_17 = "changeNotBom.deleteWizard.icon";



    @RBEntry("replace")
    public static final String PRIVATE_CONSTANT_18 = "changeNotBom.replaceWizard.description";
    @RBEntry("replace")
    public static final String PRIVATE_CONSTANT_19 = "changeNotBom.replaceWizard.tooltip";

    @RBEntry("replace9x9.gif")
    public static final String PRIVATE_CONSTANT_20 = "changeNotBom.replaceWizard.icon";



    @RBEntry("add replace part")
    public static final String PRIVATE_CONSTANT_21 = "changeNotBom.addReplacePartWizard.description";
    @RBEntry("add replace part")
    public static final String PRIVATE_CONSTANT_22 = "changeNotBom.addReplacePartWizard.tooltip";

    @RBEntry("preferences.png")
    public static final String PRIVATE_CONSTANT_23 = "changeNotBom.addReplacePartWizard.icon";


    @RBEntry("delete replace part")
    public static final String PRIVATE_CONSTANT_24 = "changeNotBom.delReplacePartWizard.description";
    @RBEntry("delete replace part")
    public static final String PRIVATE_CONSTANT_25 = "changeNotBom.delReplacePartWizard.tooltip";

    @RBEntry("pref_delete.gif")
    public static final String PRIVATE_CONSTANT_26 = "changeNotBom.delReplacePartWizard.icon";



    @RBEntry("excel添加替代料")
    public static final String PRIVATE_CONSTANT_4 = "ReplacePartWizard.excelSetreplace.description";
    @RBEntry("excel添加替代料")
    public static final String PRIVATE_CONSTANT_5 = "ReplacePartWizard.excelSetreplace.tooltip";



    @RBEntry("Excel导入")
    public static final String PRIVATE_CONSTANT_27 = "changeNotBom.uploadChangeExcel.description";
    @RBEntry("Excel导入")
    public static final String PRIVATE_CONSTANT_28 = "changeNotBom.uploadChangeExcel.tooltip";


    @RBEntry("删除变更")
    public static final String PRIVATE_CONSTANT_29 = "changeNotBom.deleteItem.description";
    @RBEntry("删除变更")
    public static final String PRIVATE_CONSTANT_30 = "changeNotBom.deleteItem.tooltip";
    @RBEntry("delete.png")
    public static final String PRIVATE_CONSTANT_31 = "changeNotBom.deleteItem.icon";


    @RBEntry("修改变更")
    public static final String PRIVATE_CONSTANT_32 = "changeNotBom.updateItemWizard.description";
    @RBEntry("修改变更")
    public static final String PRIVATE_CONSTANT_33 = "changeNotBom.updateItemWizard.tooltip";
    @RBEntry("edit_properties.gif")
    public static final String PRIVATE_CONSTANT_34 = "changeNotBom.updateItemWizard.icon";

    @RBEntry("Supply Chain")
    public static final String Supply_Chain = "Supply_Chain";

    @RBEntry("Supply Chain")
    public static final String PRIVATE_CONSTANT_35 = "changeNotBom.supplyChain.description";
    @RBEntry("Supply Chain")
    public static final String PRIVATE_CONSTANT_36 = "changeNotBom.supplyChain.tooltip";




    // 供应链集成
    @RBEntry("维护呆滞料处理方式")
    public static final String PRIVATE_CONSTANT_43 = "changeNotBom.rbUpdateWizard.description";
    @RBEntry("维护呆滞料处理方式")
    public static final String PRIVATE_CONSTANT_44 = "changeNotBom.rbUpdateWizard.tooltip";

    @RBEntry("administerLC.gif")
    public static final String PRIVATE_CONSTANT_45 = "changeNotBom.rbUpdateWizard.icon";


    @RBEntry("维护信息")
    public static final String PRIVATE_CONSTANT_46 = "changeNotBom.supplyUpdateWizard.description";
    @RBEntry("维护信息")
    public static final String PRIVATE_CONSTANT_47 = "changeNotBom.supplyUpdateWizard.tooltip";

    @RBEntry("preferences.png")
    public static final String PRIVATE_CONSTANT_48 = "changeNotBom.supplyUpdateWizard.icon";


    @RBEntry("ECN发送到ERP错误信息")
    public static final String PRIVATE_CONSTANT_50 = "changeNotBom.sendECNErrTable.description";
    @RBEntry("ECN发送到ERP错误信息")
    public static final String PRIVATE_CONSTANT_49 = "changeNotBom.sendECNErrTable.tooltip";

}
