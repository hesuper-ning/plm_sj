package ext.kingdeeERP.changeBOM;

/**
 * 呆滞料处理方式枚举
 */
public enum LifelessPartHandMetEnum {


    RESERVE("保留"),
    NORMAL_CONSUMPTION("正常消耗"),
    SCRAP("报废"),
    USED_FOR_OTHER_PROJECTS("消耗用于其他项目"),
    ;
    private final String HandMet;


    LifelessPartHandMetEnum(String handMet) {
        HandMet = handMet;
    }

}
