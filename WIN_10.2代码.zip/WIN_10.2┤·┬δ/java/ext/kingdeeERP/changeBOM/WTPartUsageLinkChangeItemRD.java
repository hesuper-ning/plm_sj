package ext.kingdeeERP.changeBOM;

import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;
import wt.content.ContentHolder;
import wt.fc.WTObject;
import wt.util.WTException;

/**
 * 研发填写的数据呆滞料相关
 */
@GenAsPersistable(superClass = WTObject.class,interfaces = {ContentHolder.class},
        properties = {
                @GeneratedProperty(name="ChangeTermOR", type=String.class,
                        constraints=@PropertyConstraints(required=true)),
                @GeneratedProperty(name="LifelessPartHandMet", type= String.class),
                @GeneratedProperty(name="ChangeRemarks", type= String.class),
        })
public class WTPartUsageLinkChangeItemRD extends _WTPartUsageLinkChangeItemRD{

    static final long serialVersionUID = 1;

    public static WTPartUsageLinkChangeItemRD newWTPartUsageLinkChangeItemRD() throws WTException {
        final WTPartUsageLinkChangeItemRD instance = new WTPartUsageLinkChangeItemRD();
        instance.initialize();
        return instance;
    }

}
