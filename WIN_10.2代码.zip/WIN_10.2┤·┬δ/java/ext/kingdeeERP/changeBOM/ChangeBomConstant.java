package ext.kingdeeERP.changeBOM;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 变更常用常量
 */
public class ChangeBomConstant {
    // 规格型号内部值
    public static final String SpecificationsModel = "SpecificationsModel";



    // 物料描述内部值
    public static final String ITEMDESC = "ItemDesc";

    // WTUserLink 内部IBA属性
    // 工号的内部值
    public static final String TAG_NUMBER = "MachinePos";
    // 是否客供料
    public static final String IS_BY_CUST = "IsByCust";

    // 是否售后料
    public static final String IS_CUSTOMER_SERVICE = "IsCustomerService";
    // 物料行备注
    public static final String ITEM_NOTE = "ItemNote";
    // 跳层
    public static final String BOM_SKIP = "BOMSkip";


    // 层级
    public static final String Level_CJ = "Level_CJ";

    // 制成板
    public static final String Made_into_boards = "03.01";
    // OEM主板
    public static final String OEM_motherboard = "03.09";
    // 电路板
    public static final String Circuit_board = "03.06";
    // 副板
    public static final String Auxiliary_board = "03.05";
    // 成品板
    public static final String Finished_board = "03.02";
    // 机模主板
    public static final String Machine_model_motherboard = "03.07";




    // 变更项目名
    public static final String CHANGE_ORDER2_ProjectName = "ProjectName";


    // 变更紧急程度
    public static final String CHANGE_ORDER2_Urgency = "EngineeringChangeUrgency";

    // 部件分类IBA内部名称
    public static final String Part_Classification = "Classification";

    private static final String [] PCBAClass={Made_into_boards,OEM_motherboard,Circuit_board,Auxiliary_board,Finished_board,Machine_model_motherboard};

    // PCBA类型集合
    public static final List<String> PCBAClassList = new ArrayList<>(Arrays.asList(PCBAClass));

    // 添加和替换子件的时候子件必须是已发布 试制 正在工作
    private static final String [] ADD_AND_REPLACE_CHILD_PART_STATE={"已发布","试制","正在工作","已发布变更中"};
    public static final List<String> ADD_AND_REPLACE_CHILD_PART_STATE_LIST = new ArrayList<>(Arrays.asList(ADD_AND_REPLACE_CHILD_PART_STATE));

    public static final String Change_Immediately = "立即切换";
    public static final String Use_Up_Old_Materials ="自然切换";
    public static final String Natural_Use_Up_Old_Materials ="配套自然切换";

    // 切换模式
    private static final String[] SWITCH_MODE = {Change_Immediately, Use_Up_Old_Materials,Natural_Use_Up_Old_Materials};

    public static final List<String> SWITCH_MODE_LIST = new ArrayList<>(Arrays.asList(SWITCH_MODE));
    // 校验子项部件生命周期状态不能是一下一种
    private static final String [] CHILD_PART_LIFT_NOT_IN={"正在审阅","重新工作","废弃","新建物料"};
    public static final List<String> CHILD_PART_LIFT_NOT_IN_LIST = new ArrayList<>(Arrays.asList(CHILD_PART_LIFT_NOT_IN));


    // ECN流程编制节点
    public static final String ORGANIZATION = "编制";

    // ECN流程确认库存影响节点
    public static final String CHECK = "确认库存影响";

}
