package ext.kingdeeERP.batchOption.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import ext.kingdeeERP.batchOption.utils.IBAUtil;
import wt.doc.WTDocument;
import wt.part.WTPart;
import wt.util.WTException;

public class MaintenanceHoursUtility extends AbstractDataUtility {

    @Override
    public Object getDataValue(String s, Object o, ModelContext modelContext) throws WTException {
        WTPart part = (WTPart) o;

        String state = part.getLifeCycleState().getDisplay();//状态显示值
        String version = part.getVersionIdentifier().getValue() + "." + part.getIterationIdentifier().getValue();  //版本前置.版本后置

        switch (s) {
            case "number":
                return part.getNumber();
            case "name":
                return part.getName();
            case "ItemDesc":
                IBAUtil ibaUtil = new IBAUtil(part);
                return ibaUtil.getIBAValue("ItemDesc");
            case "version":
                return version;
            case "state":
                return state;
        }
        return null;
    }
}