package ext.kingdeeERP.batchOption.controller;

import ext.kingdeeERP.batchOption.controller.VO.ResponseVo;
import ext.kingdeeERP.batchOption.utils.PartUtil;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.part.WTPart;
import wt.util.WTException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class BOMSearchController {
    final ObjectMapper objectMapper = new ObjectMapper();

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.HEAD})
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, WTException {
        System.out.println("进入查询BOM搜索");

        ResponseVo responseVo = new ResponseVo();
        String itemName = request.getParameter("itemName");
        //传入的部件oid
        String bomName = request.getParameter("bomName");


        if (itemName == null && itemName == "") {
            responseVo.setCode(400);
            responseVo.setMsg("您输入的项目名称为空");

        } else {
            //获取项目部件
            WTPart wtPartByName = PartUtil.getEQUALWTPartByName(itemName);
            if (wtPartByName == null) {
                responseVo.setCode(400);
                responseVo.setMsg("您输入的项目名" + itemName + "不存在");
            } else {
                //获取所有子项
                List<WTPart> allBomByPart = PartUtil.getAllBomByPart(wtPartByName);

                List<WTPart> resultList = new ArrayList<>();
                //bom名称
                if (bomName == null && bomName == "") {
                    responseVo.setCode(400);
                    responseVo.setMsg("您输入的BOM名" + bomName + "不存在");
                } else {
                    for (WTPart part : allBomByPart) {
                        //对应要查的BOM
                        if (bomName.equals(part.getName())) {
                            resultList.add(part);
                        }
                    }
                    if (resultList.size()==0){
                        responseVo.setCode(400);
                        responseVo.setMsg(itemName+"下" + bomName + "不存在");
                    }
                    responseVo.setCode(200);
                    responseVo.setData(resultList);
                }
            }

        }


        String resultJson = objectMapper.writeValueAsString(responseVo);
        System.out.println(resultJson);
        outResponse(response,resultJson);
    }

    public void outResponse(HttpServletResponse response, String josn) throws IOException {
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(josn);
        out.flush();
    }
}


