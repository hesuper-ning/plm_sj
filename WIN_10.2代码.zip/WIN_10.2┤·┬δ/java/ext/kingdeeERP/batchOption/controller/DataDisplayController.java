package ext.kingdeeERP.batchOption.controller;
import ext.kingdeeERP.batchOption.controller.entity.EchoReqVo;
import ext.kingdeeERP.batchOption.controller.entity.EchoResponseVo;
import ext.kingdeeERP.batchOption.controller.entity.ResponseVo;
import ext.kingdeeERP.batchOption.utils.IBAUtil;
import ext.kingdeeERP.batchOption.utils.PartUtil;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.part.*;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import static ext.kingdeeERP.batchOption.utils.PartUtil.*;


public class DataDisplayController {
    // 规格型号内部值
    public static final String SpecificationsModel = "SpecificationsModel";
    // 工号的内部值
    public static final String TAG_NUMBER = "MachinePos";

    // 是否客供料
    public static final String IS_BY_CUST = "IsByCust";

    // 是否售后料
    public static final String IS_CUSTOMER_SERVICE = "IsCustomerService";

    // 跳层
    public static final String BOM_SKIP = "BOMSkip";
    public static final String ITEM_NOTE = "ItemNote";

    public static final String ADD = "ADD";
    public static final String UPDATE = "UPDATE";
    public static final String DELETE = "DELETE";
    public static final String REPLACE = "REPLACE";


    final ObjectMapper objectMapper = new ObjectMapper();
    private static final long serialVersionUID = 1L;

    @RequestMapping(method = {RequestMethod.POST, RequestMethod.HEAD})
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        System.out.println("DataDisplayController详细连接接口----->");
        // 设置请求和响应的内容类型为JSON
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");

        // 读取请求体中的JSON数据
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        String jsonStr = sb.toString();
        System.out.println("打印post数据：" + jsonStr);


        EchoReqVo object = objectMapper.readValue(jsonStr, EchoReqVo.class);
        ResponseVo responseVo = checkInputParam(object);
        String faPartJson = objectMapper.writeValueAsString(responseVo);
        System.out.println(faPartJson);
        //数组转为json
        // 设置响应内容类型为 JSON
        response.reset();
        response.setContentType("application/json;charset=utf-8");
        response.setContentType("text/html;charset=UTF-8");  //这句太重要了
        PrintWriter out = response.getWriter();
        out.print(faPartJson);
        out.flush();
    }


    /**
     * 检查参数是否有效
     * add
     *
     * @param objects
     * @return
     */
    public static ResponseVo checkInputParam(EchoReqVo objects) throws Exception {
        ResponseVo responseVo = new ResponseVo();
        String optionType = objects.getOptionType();
        List<String> bomPartNumber = objects.getBOMPartNumber();
        String beforePartNumber =null;
        if(objects.getBeforePartNumber() !=null){
            beforePartNumber = objects.getBeforePartNumber();
        }
        String afterPartNumber = null;
        if (objects.getAfterPartNumber()!=null) {
            afterPartNumber = objects.getAfterPartNumber();
        }


        String replacePartNumber = objects.getReplacePartNumber();


        if (ADD.equals(optionType)) {
            responseVo = addChildPart(afterPartNumber);
        } else if (DELETE.equals(optionType)) {
            responseVo = deleteChildPart(bomPartNumber, beforePartNumber);
        } else if (UPDATE.equals(optionType)) {
            responseVo = getChildPart(bomPartNumber, beforePartNumber);
        } else if (REPLACE.equals(optionType)) {
            //改后是空
            if (afterPartNumber == null || afterPartNumber.isEmpty()) {
                responseVo = getChildPart(bomPartNumber, beforePartNumber);
            } else {
                responseVo = getChildData(bomPartNumber, afterPartNumber);
            }


        }
        return responseVo;

    }

    private static ResponseVo getChildData(List<String> bomPartNumber, String afterPartNumber) throws WTException {
        ResponseVo responseVo = new ResponseVo();
        WTPart afterPart = getWTPartByNumber(afterPartNumber);

        if (afterPart == null) {
            responseVo.setCode(400);
            responseVo.setMsg("编号" + afterPartNumber + "的部件不存在");
        } else {
            responseVo.setCode(200);
            responseVo.setMsg("操作成功");
            IBAUtil partIBA = new IBAUtil(afterPart);
            List<EchoResponseVo> vos = new ArrayList<>();
            EchoResponseVo vo = new EchoResponseVo();
            String spec = partIBA.getIBAValue(SpecificationsModel);
            vo.setAfterPartNumber(afterPartNumber);
            vo.setAfterPartName(afterPart.getName());
            vo.setAfterSpecificationsModel(spec);
            vos.add(vo);
            //添加返回数据
            responseVo.setData(vos);
        }
        return responseVo;

    }


    /**
     * 添加回显
     *
     * @param afterPartNumber
     * @return
     */
    private static ResponseVo addChildPart(String afterPartNumber) throws WTException {
        ResponseVo responseVo = new ResponseVo();
        WTPart afterPart = getWTPartByNumber(afterPartNumber);

        if (afterPart == null) {
            responseVo.setCode(400);
            responseVo.setMsg("编号" + afterPartNumber + "的部件不存在");
        } else {
            responseVo.setCode(200);
            responseVo.setMsg("操作成功");
            IBAUtil partIBA = new IBAUtil(afterPart);
            List<EchoResponseVo> vos = new ArrayList<>();
            EchoResponseVo vo = new EchoResponseVo();
            String spec = partIBA.getIBAValue(SpecificationsModel);
            vo.setAfterPartNumber(afterPartNumber);
            vo.setAfterPartName(afterPart.getName());
            vo.setAfterSpecificationsModel(spec);
            vos.add(vo);
            //添加返回数据
            responseVo.setData(vos);
        }
        return responseVo;
    }


    /**
     * 删除
     *
     * @param bomPartNumber
     * @param beforePartNumber
     * @return
     */
    private static ResponseVo deleteChildPart(List<String> bomPartNumber, String beforePartNumber) throws WTException {
        ResponseVo responseVo = new ResponseVo();
        WTPart beforePart = getWTPartByNumber(beforePartNumber);
        List<WTPart> parentParts = new ArrayList<>();
        List<EchoResponseVo> vos = new ArrayList<>();
        if (beforePart == null) {
            responseVo.setCode(400);
            responseVo.setMsg("编号" + beforePartNumber + "的部件不存在");
        } else {
            for (String parentNum : bomPartNumber) {
                WTPart parentPart = getWTPartByNumber(parentNum);
                parentParts.add(parentPart);
            }
            WTPartMaster beforeMaster = PartUtil.getWTPartMasterByNumber(beforePartNumber);


            List<WTPartUsageLink> wtPartUsageLinksByBOMAndChildMaster = new ArrayList<>();


            for (WTPart parent : parentParts) {
                List<WTPartUsageLink> linksByPart = PartUtil.getLinksByPart(parent);
                for (WTPartUsageLink link : linksByPart) {
                    WTPartMaster linkUses = link.getUses();
                    if (beforeMaster.equals(linkUses)) {
                        IBAUtil linkIBA = new IBAUtil(link);
                        EchoResponseVo vo = new EchoResponseVo();
                        String linkStr = link.toString();
                        vo.setBeforePartName(beforeMaster.getName());
                        vo.setBeforePartNumber(beforePartNumber);
                        vo.setWtUserLink(linkStr);
                        vo.setBeforeSpecificationsModel(linkIBA.getIBAValue(SpecificationsModel));
                        vo.setBeforeNumber(String.valueOf(link.getQuantity().getAmount()));
                        vo.setBeforeTagNumber(linkIBA.getIBAValue(TAG_NUMBER));

                        vo.setBOMPartName(parent.getName());
                        vo.setBOMPartNumber(parent.getNumber());

                        LineNumber lineNumber = link.getLineNumber();
                        if (lineNumber == null) {
                            vo.setLineNumber("");
                        } else {
                            vo.setLineNumber(lineNumber.toString());
                        }
                        vos.add(vo);
                        wtPartUsageLinksByBOMAndChildMaster.add(link);
                    }
                }
            }
            if (wtPartUsageLinksByBOMAndChildMaster.isEmpty()) {
                responseVo.setCode(400);
                responseVo.setMsg("BOM下没有编号为：" + beforeMaster.getNumber() + "的子料");
                return responseVo;
            } else {
                responseVo.setCode(200);
                responseVo.setData(vos);
                return responseVo;
            }
        }
        return responseVo;
    }


    /**
     * 获取子部件
     *
     * @param bomPartNumber
     * @param beforePartNumber
     * @return
     */
    private static ResponseVo getChildPart(List<String> bomPartNumber, String beforePartNumber) throws WTException {
        ResponseVo responseVo = new ResponseVo();
        WTPart beforePart = getWTPartByNumber(beforePartNumber);
        List<WTPart> parentParts = new ArrayList<>();
        List<EchoResponseVo> vos = new ArrayList<>();
        if (beforePart == null) {
            responseVo.setCode(400);
            responseVo.setMsg("编号" + beforePartNumber + "的部件不存在");
        } else {
            for (String parentNum : bomPartNumber) {
                WTPart parentPart = getWTPartByNumber(parentNum);
                parentParts.add(parentPart);
            }
            WTPartMaster beforeMaster = PartUtil.getWTPartMasterByNumber(beforePartNumber);


            List<WTPartUsageLink> wtPartUsageLinksByBOMAndChildMaster = new ArrayList<>();


            for (WTPart parent : parentParts) {
                List<WTPartUsageLink> linksByPart = PartUtil.getLinksByPart(parent);
                for (WTPartUsageLink link : linksByPart) {
                    WTPartMaster linkUses = link.getUses();
                    if (beforeMaster.equals(linkUses)) {
                        IBAUtil linkIBA = new IBAUtil(link);
                        EchoResponseVo vo = new EchoResponseVo();
                        String linkStr = link.toString();
                        vo.setBeforePartName(beforeMaster.getName());
                        vo.setBeforePartNumber(beforePartNumber);
                        vo.setWtUserLink(linkStr);
                        vo.setBeforeSpecificationsModel(linkIBA.getIBAValue(SpecificationsModel));
                        vo.setBeforeNumber(String.valueOf(link.getQuantity().getAmount()));
                        vo.setBeforeTagNumber(linkIBA.getIBAValue(TAG_NUMBER));
                        vo.setIsByCust(linkIBA.getIBAValue(IS_BY_CUST));//是否客供
                        vo.setIsCustomerService(linkIBA.getIBAValue(IS_CUSTOMER_SERVICE));//是否售后
                        vo.setBOMSkip(linkIBA.getIBAValue(BOM_SKIP));//是否跳层
                        vo.setItemNote(linkIBA.getIBAValue(ITEM_NOTE));//物料备注
                        LineNumber lineNumber = link.getLineNumber();
                        vo.setBOMPartName(parent.getName());
                        vo.setBOMPartNumber(parent.getNumber());

                        if (lineNumber == null) {
                            vo.setLineNumber("");
                        } else {
                            vo.setLineNumber(lineNumber.toString());
                        }
                        vos.add(vo);
                        wtPartUsageLinksByBOMAndChildMaster.add(link);
                    }
                }
            }
            if (wtPartUsageLinksByBOMAndChildMaster.isEmpty()) {
                responseVo.setCode(400);
                responseVo.setMsg("BOM下没有编号为：" + beforeMaster.getNumber() + "的子料");
                return responseVo;
            } else {
                responseVo.setCode(200);
                responseVo.setData(vos);
                return responseVo;
            }
        }
        return responseVo;
    }


    /**
     *
     * @param parentParts
     * @param childMaster
     * @return
     */
//    private static List<WTPartUsageLink> getWTPartUsageLinksByBOMAndChildMaster(List<WTPart> parentParts, WTPartMaster childMaster){
//        List<WTPartUsageLink> lists = new ArrayList<>();
//        for (WTPart parent: parentParts){
//            List<WTPartUsageLink> linksByPart = PartUtil.getLinksByPart(parent);
//            for (WTPartUsageLink link:linksByPart){
//                WTPartMaster linkUses = link.getUses();
//                if(linkUses.equals(childMaster)){
//                    lists.add(link);
//                }
//            }
//        }
//        return lists;
//    }
}
