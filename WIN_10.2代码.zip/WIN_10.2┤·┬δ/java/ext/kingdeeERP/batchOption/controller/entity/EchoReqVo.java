package ext.kingdeeERP.batchOption.controller.entity;

import java.util.List;

/**
 * 回显请求参数
 */
public class EchoReqVo {

    public String optionType;

    public List<String> BOMPartNumber;


    public String beforePartNumber;

    public String afterPartNumber;


    public String replacePartNumber;


    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public List<String> getBOMPartNumber() {
        return BOMPartNumber;
    }

    public void setBOMPartNumber(List<String> BOMPartNumber) {
        this.BOMPartNumber = BOMPartNumber;
    }

    public String getBeforePartNumber() {
        return beforePartNumber;
    }

    public void setBeforePartNumber(String beforePartNumber) {
        this.beforePartNumber = beforePartNumber;
    }

    public String getAfterPartNumber() {
        return afterPartNumber;
    }

    public void setAfterPartNumber(String afterPartNumber) {
        this.afterPartNumber = afterPartNumber;
    }

    public String getReplacePartNumber() {
        return replacePartNumber;
    }

    public void setReplacePartNumber(String replacePartNumber) {
        this.replacePartNumber = replacePartNumber;
    }
}
