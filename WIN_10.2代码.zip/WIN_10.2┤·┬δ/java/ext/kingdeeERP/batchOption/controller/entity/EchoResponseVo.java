package ext.kingdeeERP.batchOption.controller.entity;

/**
 * 页面回显参数
 */
public class EchoResponseVo {

    public String BOMPartNumber;

    public String BOMPartName;

    public String beforePartNumber;

    public String beforePartName;

    public String afterPartNumber;

    public String afterPartName;


    public String replacePartNumber;

    public String replacePartName;

    public String beforeNumber;

    public String beforeTagNumber;

    public String lineNumber;

    public String IsByCust;
    public String IsCustomerService;
    public String ItemNote;
    public String BOMSkip;



    public String wtUserLink;

    // 改前规格型号
    public String beforeSpecificationsModel;
    // 改后规格型号
    public String afterSpecificationsModel;


    public String getBOMPartNumber() {
        return BOMPartNumber;
    }

    public void setBOMPartNumber(String BOMPartNumber) {
        this.BOMPartNumber = BOMPartNumber;
    }

    public String getBOMPartName() {
        return BOMPartName;
    }

    public void setBOMPartName(String BOMPartName) {
        this.BOMPartName = BOMPartName;
    }

    public String getBeforePartNumber() {
        return beforePartNumber;
    }

    public void setBeforePartNumber(String beforePartNumber) {
        this.beforePartNumber = beforePartNumber;
    }

    public String getBeforePartName() {
        return beforePartName;
    }

    public void setBeforePartName(String beforePartName) {
        this.beforePartName = beforePartName;
    }

    public String getAfterPartNumber() {
        return afterPartNumber;
    }

    public void setAfterPartNumber(String afterPartNumber) {
        this.afterPartNumber = afterPartNumber;
    }

    public String getAfterPartName() {
        return afterPartName;
    }

    public void setAfterPartName(String afterPartName) {
        this.afterPartName = afterPartName;
    }

    public String getReplacePartNumber() {
        return replacePartNumber;
    }

    public void setReplacePartNumber(String replacePartNumber) {
        this.replacePartNumber = replacePartNumber;
    }

    public String getReplacePartName() {
        return replacePartName;
    }

    public void setReplacePartName(String replacePartName) {
        this.replacePartName = replacePartName;
    }

    public String getBeforeNumber() {
        return beforeNumber;
    }

    public void setBeforeNumber(String beforeNumber) {
        this.beforeNumber = beforeNumber;
    }

    public String getBeforeTagNumber() {
        return beforeTagNumber;
    }

    public void setBeforeTagNumber(String beforeTagNumber) {
        this.beforeTagNumber = beforeTagNumber;
    }

    public String getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getIsByCust() {
        return IsByCust;
    }

    public void setIsByCust(String isByCust) {
        IsByCust = isByCust;
    }

    public String getIsCustomerService() {
        return IsCustomerService;
    }

    public void setIsCustomerService(String isCustomerService) {
        IsCustomerService = isCustomerService;
    }

    public String getItemNote() {
        return ItemNote;
    }

    public void setItemNote(String itemNote) {
        ItemNote = itemNote;
    }

    public String getBOMSkip() {
        return BOMSkip;
    }

    public void setBOMSkip(String BOMSkip) {
        this.BOMSkip = BOMSkip;
    }

    public String getWtUserLink() {
        return wtUserLink;
    }

    public void setWtUserLink(String wtUserLink) {
        this.wtUserLink = wtUserLink;
    }

    public String getBeforeSpecificationsModel() {
        return beforeSpecificationsModel;
    }

    public void setBeforeSpecificationsModel(String beforeSpecificationsModel) {
        this.beforeSpecificationsModel = beforeSpecificationsModel;
    }

    public String getAfterSpecificationsModel() {
        return afterSpecificationsModel;
    }

    public void setAfterSpecificationsModel(String afterSpecificationsModel) {
        this.afterSpecificationsModel = afterSpecificationsModel;
    }
}
