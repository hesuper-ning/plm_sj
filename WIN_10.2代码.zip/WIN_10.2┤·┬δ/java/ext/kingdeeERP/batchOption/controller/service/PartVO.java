package ext.kingdeeERP.batchOption.controller.service;

public class PartVO {
    private String number;
    private String name;
    private String  itemDesc;
    private String  version;
    private String  state;
}
