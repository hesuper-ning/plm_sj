package ext.kingdeeERP.batchOption.controller.VO;

/**
 * 删除BOM的VO类
 */
public class UpdateOptionVo {

    public String wtUserLink;

    public String parentNumbers;

    public String parentName;


    public String beforeChildNumber;
    public String beforeNumber;
    public String beforeTagNumber;

    public String afterChildNumber;
    public String afterNumber;
    public String afterTagNumber;

    public Long lineNumber;
    public String isByCust;
    public String isCustomerService;
    public String BOMSkip;
    public String itemNote;

    @Override
    public String toString() {
        return "UpdateOptionVo{" +
                "wtUserLink='" + wtUserLink + '\'' +
                ", parentNumbers='" + parentNumbers + '\'' +
                ", parentName='" + parentName + '\'' +
                ", beforeChildNumber='" + beforeChildNumber + '\'' +
                ", beforeNumber='" + beforeNumber + '\'' +
                ", beforeTagNumber='" + beforeTagNumber + '\'' +
                ", afterChildNumber='" + afterChildNumber + '\'' +
                ", afterNumber='" + afterNumber + '\'' +
                ", afterTagNumber='" + afterTagNumber + '\'' +
                ", lineNumber=" + lineNumber +
                ", isByCust='" + isByCust + '\'' +
                ", isCustomerService='" + isCustomerService + '\'' +
                ", BOMSkip='" + BOMSkip + '\'' +
                ", itemNote='" + itemNote + '\'' +
                '}';
    }

    public UpdateOptionVo(String wtUserLink, String parentNumbers, String parentName, String beforeChildNumber, String beforeNumber, String beforeTagNumber, String afterChildNumber, String afterNumber, String afterTagNumber, Long lineNumber, String isByCust, String isCustomerService, String BOMSkip, String itemNote) {
        this.wtUserLink = wtUserLink;
        this.parentNumbers = parentNumbers;
        this.parentName = parentName;
        this.beforeChildNumber = beforeChildNumber;
        this.beforeNumber = beforeNumber;
        this.beforeTagNumber = beforeTagNumber;
        this.afterChildNumber = afterChildNumber;
        this.afterNumber = afterNumber;
        this.afterTagNumber = afterTagNumber;
        this.lineNumber = lineNumber;
        this.isByCust = isByCust;
        this.isCustomerService = isCustomerService;
        this.BOMSkip = BOMSkip;
        this.itemNote = itemNote;
    }

    public String getItemNote() {
        return itemNote;
    }

    public void setItemNote(String itemNote) {
        this.itemNote = itemNote;
    }

    public void setWtUserLink(String wtUserLink) {
        this.wtUserLink = wtUserLink;
    }



    public String getWtUserLink() {
        return wtUserLink;
    }

    public UpdateOptionVo(String wtUserLink, String parentNumbers, String parentName, String beforeChildNumber, String beforeNumber, String beforeTagNumber, String afterChildNumber, String afterNumber, String afterTagNumber, Long lineNumber, String isByCust, String isCustomerService, String BOMSkip) {
        this.wtUserLink = wtUserLink;
        this.parentNumbers = parentNumbers;
        this.parentName = parentName;
        this.beforeChildNumber = beforeChildNumber;
        this.beforeNumber = beforeNumber;
        this.beforeTagNumber = beforeTagNumber;
        this.afterChildNumber = afterChildNumber;
        this.afterNumber = afterNumber;
        this.afterTagNumber = afterTagNumber;
        this.lineNumber = lineNumber;
        this.isByCust = isByCust;
        this.isCustomerService = isCustomerService;
        this.BOMSkip = BOMSkip;
    }

    public UpdateOptionVo(String parentNumbers, String parentName, String beforeChildNumber, String beforeNumber, String beforeTagNumber, String afterChildNumber, String afterNumber, String afterTagNumber, Long lineNumber, String isByCust, String isCustomerService, String BOMSkip) {
        this.parentNumbers = parentNumbers;
        this.parentName = parentName;
        this.beforeChildNumber = beforeChildNumber;
        this.beforeNumber = beforeNumber;
        this.beforeTagNumber = beforeTagNumber;
        this.afterChildNumber = afterChildNumber;
        this.afterNumber = afterNumber;
        this.afterTagNumber = afterTagNumber;
        this.lineNumber = lineNumber;
        this.isByCust = isByCust;
        this.isCustomerService = isCustomerService;
        this.BOMSkip = BOMSkip;
    }

    public String getParentNumbers() {
        return parentNumbers;
    }

    public void setParentNumbers(String parentNumbers) {
        this.parentNumbers = parentNumbers;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getBeforeChildNumber() {
        return beforeChildNumber;
    }

    public void setBeforeChildNumber(String beforeChildNumber) {
        this.beforeChildNumber = beforeChildNumber;
    }

    public String getBeforeNumber() {
        return beforeNumber;
    }

    public void setBeforeNumber(String beforeNumber) {
        this.beforeNumber = beforeNumber;
    }

    public String getBeforeTagNumber() {
        return beforeTagNumber;
    }

    public void setBeforeTagNumber(String beforeTagNumber) {
        this.beforeTagNumber = beforeTagNumber;
    }

    public String getAfterChildNumber() {
        return afterChildNumber;
    }

    public void setAfterChildNumber(String afterChildNumber) {
        this.afterChildNumber = afterChildNumber;
    }

    public String getAfterNumber() {
        return afterNumber;
    }

    public void setAfterNumber(String afterNumber) {
        this.afterNumber = afterNumber;
    }

    public String getAfterTagNumber() {
        return afterTagNumber;
    }

    public void setAfterTagNumber(String afterTagNumber) {
        this.afterTagNumber = afterTagNumber;
    }

    public Long getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(Long lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getIsByCust() {
        return isByCust;
    }

    public void setIsByCust(String isByCust) {
        this.isByCust = isByCust;
    }

    public String getIsCustomerService() {
        return isCustomerService;
    }

    public void setIsCustomerService(String isCustomerService) {
        this.isCustomerService = isCustomerService;
    }

    public String getBOMSkip() {
        return BOMSkip;
    }

    public void setBOMSkip(String BOMSkip) {
        this.BOMSkip = BOMSkip;
    }

    public UpdateOptionVo() {
    }
}