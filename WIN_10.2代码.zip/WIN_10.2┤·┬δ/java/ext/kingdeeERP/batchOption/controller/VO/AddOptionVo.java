package ext.kingdeeERP.batchOption.controller.VO;

import wt.change2.WTChangeOrder2;

/**
 * 删除BOM的VO类
 */
public class AddOptionVo {

    public String parentNumbers;

    public String parentName;


    public String beforeChildNumbers;


    public String beforeNumbers;
    public String beforeTagNumbers;


    public String isByCust;

    public String IsCustomerService;


    public Long lineNumber;

    public String BOMSkip;
    public String itemNote;

    @Override
    public String toString() {
        return "AddOptionVo{" +
                "parentNumbers='" + parentNumbers + '\'' +
                ", parentName='" + parentName + '\'' +
                ", beforeChildNumbers='" + beforeChildNumbers + '\'' +
                ", beforeNumbers='" + beforeNumbers + '\'' +
                ", beforeTagNumbers='" + beforeTagNumbers + '\'' +
                ", isByCust='" + isByCust + '\'' +
                ", IsCustomerService='" + IsCustomerService + '\'' +
                ", lineNumber=" + lineNumber +
                ", BOMSkip='" + BOMSkip + '\'' +
                ", itemNote='" + itemNote + '\'' +
                '}';
    }

    public String getItemNote() {
        return itemNote;
    }

    public void setItemNote(String itemNote) {
        this.itemNote = itemNote;
    }


    public String getParentNumbers() {
        return parentNumbers;
    }

    public void setParentNumbers(String parentNumbers) {
        this.parentNumbers = parentNumbers;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getBeforeChildNumbers() {
        return beforeChildNumbers;
    }

    public void setBeforeChildNumbers(String beforeChildNumbers) {
        this.beforeChildNumbers = beforeChildNumbers;
    }

    public String getBeforeNumbers() {
        return beforeNumbers;
    }

    public void setBeforeNumbers(String beforeNumbers) {
        this.beforeNumbers = beforeNumbers;
    }

    public String getBeforeTagNumbers() {
        return beforeTagNumbers;
    }

    public void setBeforeTagNumbers(String beforeTagNumbers) {
        this.beforeTagNumbers = beforeTagNumbers;
    }

    public String getIsByCust() {
        return isByCust;
    }

    public void setIsByCust(String isByCust) {
        this.isByCust = isByCust;
    }

    public String getIsCustomerService() {
        return IsCustomerService;
    }

    public void setIsCustomerService(String isCustomerService) {
        IsCustomerService = isCustomerService;
    }

    public Long getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(Long lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getBOMSkip() {
        return BOMSkip;
    }

    public void setBOMSkip(String BOMSkip) {
        this.BOMSkip = BOMSkip;
    }

    public AddOptionVo() {
    }

    public AddOptionVo(String parentNumbers, String parentName, String beforeChildNumbers, String beforeNumbers, String beforeTagNumbers, String isByCust, String isCustomerService, Long lineNumber, String BOMSkip) {
        this.parentNumbers = parentNumbers;
        this.parentName = parentName;
        this.beforeChildNumbers = beforeChildNumbers;
        this.beforeNumbers = beforeNumbers;
        this.beforeTagNumbers = beforeTagNumbers;
        this.isByCust = isByCust;
        IsCustomerService = isCustomerService;
        this.lineNumber = lineNumber;
        this.BOMSkip = BOMSkip;
    }
}