package ext.kingdeeERP.batchOption.processor;

import ext.kingdeeERP.batchOption.utils.PersistenceUtil;
import org.apache.commons.lang.StringUtils;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.kingdeeERP.batchOption.BomConstant;
import ext.kingdeeERP.batchOption.controller.VO.DeleteOptionVo;
import ext.kingdeeERP.batchOption.utils.IBAUtil;
import ext.kingdeeERP.batchOption.utils.PartUtil;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.part.*;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;

import java.util.*;

public class DeletePartProcessor extends DefaultObjectFormProcessor {
    private static final ReferenceFactory refefence = new ReferenceFactory();
    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("进入删除子项");
        StringBuffer msg = new StringBuffer();
        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();

        String[] parentNumbers = new String[]{};
        String[] parentNames = new String[]{};
        String[] beforeTagNumber = new String[]{};
        String[] lineNumber = new String[]{};
        String[] wtUserLink = new String[]{};

        String beforeChildNumber = nmCommandBean.getTextParameter("beforeChildNumber");

        String beforeSpecificationsModel = nmCommandBean.getTextParameter("beforeSpecificationsModel");



//        String beforeTagNumber = nmCommandBean.getTextParameter("beforeTagNumber");
//
//        String isByCust = nmCommandBean.getTextParameter("isByCust");
//        String isCustomerService = nmCommandBean.getTextParameter("isCustomerService");
//        String BOMSkip = nmCommandBean.getTextParameter("BOMSkip");

        //添加到Vo中

//        deleteOptionVo.setIsByCust(isByCust);
//        deleteOptionVo.setIsCustomerService(isCustomerService);
//        deleteOptionVo.setBOMSkip(BOMSkip);

        for (String key : parameterMap.keySet()) {
            Object value = parameterMap.get(key);

            String[] values = (String[]) value;
            for (String a : values) {
                System.out.println("key=" + key + "value=" + a);
            }
            if ("parentPartNumber".equals(key)) {
                parentNumbers = (String[]) value;
            }
            if ("beforeTagNumber".equals(key)) {
                beforeTagNumber = (String[]) value;
            }
            if ("lineNumber".equals(key)) {
                lineNumber = (String[]) value;
            }

            if ("wtUserLink".equals(key)) {
                wtUserLink = (String[]) value;
            }
        }

        // 以父部件编号为key 每一行数据为value
        Map<String, List<DeleteOptionVo>> vos = new HashMap<>();

        for (int i = 0; i < parentNumbers.length; i++) {

            DeleteOptionVo deleteOptionVo = new DeleteOptionVo();
            deleteOptionVo.setBeforeChildNumbers(beforeChildNumber);
            deleteOptionVo.setBeforeTagNumbers(beforeTagNumber[i]);
            deleteOptionVo.setWtUserLink(wtUserLink[i]);
            //不为空添加行号
            Long addLong = null;
            System.out.println("添加行号不填时值为" + lineNumber);
            //行号不为空转为数字，存入VO
            if (!lineNumber[i].isEmpty()) {
                addLong = Long.parseLong(lineNumber[i]);
                deleteOptionVo.setLineNumber(addLong);
            }

            List<DeleteOptionVo> deleteOptionVos = vos.get(parentNumbers[i]);

            if (deleteOptionVos == null) {
                List<DeleteOptionVo> deleteOptionVos1 = new ArrayList<>();
                deleteOptionVos1.add(deleteOptionVo);

                vos.put(parentNumbers[i], deleteOptionVos1);
            } else {
                deleteOptionVos.add(deleteOptionVo);
            }


        }


        System.out.println("打印子部件编号：" + beforeChildNumber);
        WTPart beforeChildPart = PartUtil.getWTPartByNumber(beforeChildNumber);
        if (beforeChildPart == null) {
            throw new WTException("子部件编号" + beforeChildPart + "不存在");

        }
        Set<Map.Entry<String, List<DeleteOptionVo>>> entries = vos.entrySet();

        Transaction trx = null;
        try {
            trx = new Transaction();
            trx.start();
            //根据BOM遍历
            String ErrMsg = "";
            for (Map.Entry<String, List<DeleteOptionVo>> pr1 : entries) {
                //备注的子项编号
                StringBuffer remarkChildPart = new StringBuffer();
                //插入子项编号到备注
                remarkChildPart.append(pr1.getValue().get(0).getBeforeChildNumbers());

                WTPart parentPart = PartUtil.getWTPartByNumber(pr1.getKey());


                //检出
                WTPart checkOutPart = (WTPart) WorkInProgressHelper.service.checkout(parentPart,WorkInProgressHelper.service.getCheckoutFolder(),"").getWorkingCopy();
                //根据父部件获取全部的连接
                List<WTPartUsageLink> linkByPart =PartUtil.getBomLinkByPart(checkOutPart);
                for (DeleteOptionVo deleteOptionVo : pr1.getValue()) {
//                    //插入子项编号到备注
//                    if (deleteOptionVo.getLineNumber()==null){
//                        remarkChildPart.append("编号："+deleteOptionVo.beforeChildNumbers+",行号："+" ").append(",");
//
//                    }else{
//                        remarkChildPart.append("编号："+deleteOptionVo.beforeChildNumbers+",行号："+deleteOptionVo.getLineNumber()).append(",");
//                    }
                    WTPartMaster beforeChildPartMaster = PartUtil.getWTPartMasterByNumber(deleteOptionVo.getBeforeChildNumbers());
                    //根据工位删除
                    delHandler(deleteOptionVo.beforeChildNumbers,beforeChildPartMaster, linkByPart, deleteOptionVo.getBeforeTagNumbers(),deleteOptionVo.getWtUserLink());

                }
                //检入
                WorkInProgressHelper.service.checkin(checkOutPart ,"批量删除，物料"+remarkChildPart);
            }

            trx.commit();
            trx = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (trx != null) {
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
        return super.postProcess(nmCommandBean, list);

    }
    /**
     * 删除关联
     * @param childPartNum
     * @return
     */
    private static void delHandler(String childPartNum, WTPartMaster beforeChildPart, List<WTPartUsageLink> links, String tarNumber ,String paramLink ) throws WTException {
        System.out.println("进入了删除子件的方法");
        WTPartUsageLink oldLink = (WTPartUsageLink) PersistenceUtil.oid2Object(paramLink);
        WTPartMaster oldLinkUses = oldLink.getUses();
        Map<String, WTPartUsageLink> sameNumLinkMap = new HashMap<>();
        WTPartUsageLink waitDelLink = null;

        for (WTPartUsageLink link:links){
            if(link.getUses().equals(oldLinkUses)){
                IBAUtil linkIBA = new IBAUtil(link);
                String tarNum = linkIBA.getIBAValue(BomConstant.TAG_NUMBER);
                sameNumLinkMap.put(tarNum, link);
            }
        }
        if(sameNumLinkMap.size() == 1){
            for (Map.Entry<String, WTPartUsageLink> stringWTPartUsageLinkEntry : sameNumLinkMap.entrySet()) {
                System.out.println("该部件编号找到了唯一的使用关系");
                waitDelLink =stringWTPartUsageLinkEntry.getValue();
            }
        }else if(sameNumLinkMap.size()>1) {
            IBAUtil oldIBA = new IBAUtil(oldLink);
            String oldLinkTarNum = oldIBA.getIBAValue(BomConstant.TAG_NUMBER);
            for (Map.Entry<String, WTPartUsageLink> stringWTPartUsageLinkEntry : sameNumLinkMap.entrySet()) {
                String key = stringWTPartUsageLinkEntry.getKey();
                if(oldLinkTarNum.equals(key)){
                    System.out.println("有多个相同编号的使用关系并找到准确的一个");
                    waitDelLink = stringWTPartUsageLinkEntry.getValue();
                }
            }


        }


        if(waitDelLink == null){
            System.out.println("没有匹配到准确的待删除使用关系");
        }

        PersistenceHelper.manager.delete(waitDelLink);

//        for (WTPartUsageLink link : links) {
//            WTPartMaster wtPartMaster = link.getUses();
//            if(wtPartMaster.equals(beforeChildPart)){
//                IBAUtil ibaUtil = new IBAUtil(link);
//                String ibaValue = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
//                boolean isAccuratePart = isAccuratePart(paramLink, link);
//                if(tarNumber !=null && isAccuratePart){
//                    if(ibaValue.equals(tarNumber)){
//                        PersistenceHelper.manager.delete(link);
//                    }
//                }else {
//                    if("".equals(ibaValue)){
//                        PersistenceHelper.manager.delete(link);
//                    }
//                }
//            }
//        }
        System.out.println("删除子部件对的关联子部件编号为="+childPartNum+"工位为="+tarNumber);
    }

    /**
     *
     * @param paramLinkStr 传入的部件链接，获取当前part
     * @param bomLink 根据父部件获取到的link
     * @return 对比编号，工位，数量，行号找到正确的part
     * @throws WTException
     */
    public static boolean isAccuratePart(String paramLinkStr ,  WTPartUsageLink bomLink) throws WTException {
        boolean flag = false;
        //传入的链接传为part
        WTPartUsageLink paramLink = (WTPartUsageLink)PersistenceUtil.oid2Object(paramLinkStr);
        IBAUtil paramIBA = new IBAUtil(paramLink);

        String paramTarNumber =  paramIBA.getIBAValue(BomConstant.TAG_NUMBER);//工位
        String paramPartNumber = paramLink.getUses().getNumber();//编号
        LineNumber paramLineNumber = paramLink.getLineNumber();
        Quantity paramQuantity = paramLink.getQuantity();//数量
        //bom
        IBAUtil ibaUtil = new IBAUtil(bomLink);
        String bomTarNumber = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);//工位
        String bomNumber = bomLink.getUses().getNumber();//编号
        LineNumber bomLineNumber = bomLink.getLineNumber();
        Quantity quantity = bomLink.getQuantity();//数量


        if (paramTarNumber.equals(bomTarNumber) && paramPartNumber.equals(bomNumber) && quantity.equals(paramQuantity)  ) {
            if (paramLineNumber!=null && bomLineNumber!=null) {
                long paramLineNumberValue = paramLineNumber.getValue();
                long bomLineNumberValue = bomLineNumber.getValue();
                if (paramLineNumberValue==bomLineNumberValue){
                    flag = true;
                }
            }
            //都为空也是true
            if (paramLineNumber==null && bomLineNumber==null){
                flag = true;
            }
        }
        return flag;
    }

}
