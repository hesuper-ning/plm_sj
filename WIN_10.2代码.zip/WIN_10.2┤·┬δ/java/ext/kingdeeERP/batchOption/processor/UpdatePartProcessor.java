package ext.kingdeeERP.batchOption.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.kingdeeERP.batchOption.controller.VO.AddOptionVo;
import ext.kingdeeERP.batchOption.controller.VO.ReplaceOptionVo;
import ext.kingdeeERP.batchOption.controller.VO.UpdateOptionVo;
import ext.kingdeeERP.batchOption.BomConstant;
import ext.kingdeeERP.batchOption.utils.IBAUtil;
import ext.kingdeeERP.batchOption.utils.PartUtil;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.part.*;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.util.*;

import static ext.kingdeeERP.batchOption.utils.PartUtil.*;
import static ext.kingdeeERP.batchOption.utils.PartUtil.getBomLinkByPart;

public class UpdatePartProcessor extends DefaultObjectFormProcessor {

    private static final ReferenceFactory refefence = new ReferenceFactory();


    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {

        System.out.println("进入删除子项");
        StringBuffer msg = new StringBuffer();
        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();

        String[] parentNumbers = new String[]{};
        String[] parentNames = new String[]{};
        String[] itemNote = new String[]{};


        String[] afterNumber = new String[]{};//改后数量
        String[] afterTagNumber = new String[]{};//改后工位
        String[] lineNumber = new String[]{};//行号
        String[] isByCust = new String[]{};//是否客供
        String[] isCustomerService = new String[]{};//是否售后;
        String[] BOMSkip = new String[]{};//时候跳层
        String[] wtUserLink = new String[]{};//连接

        String[] beforeNumber = new String[]{};//改前数量
        String[] beforeTagNumber = new String[]{};//改前工位


        String beforeChildPartNumber = nmCommandBean.getTextParameter("beforeChildPartNumber");


        for (String key : parameterMap.keySet()) {
            Object value = parameterMap.get(key);

            String[] values = (String[]) value;
            for (String a : values) {
                System.out.println("key=" + key + "value=" + a);
            }
            if ("parentPartNumber".equals(key)) {
                parentNumbers = (String[]) value;
            }
            if ("itemNote".equals(key)) {
                itemNote = (String[]) value;
            }
            if ("afterNumber".equals(key)) {
                afterNumber = (String[]) value;
            }
            if ("afterTagNumber".equals(key)) {
                afterTagNumber = (String[]) value;
            }

            if ("lineNumber".equals(key)) {
                lineNumber = (String[]) value;
            }
            if ("isByCust".equals(key)) {
                isByCust = (String[]) value;
            }

            if ("isCustomerService".equals(key)) {
                isCustomerService = (String[]) value;
            }
            if ("BOMSkip".equals(key)) {
                BOMSkip = (String[]) value;
            }
            if ("wtUserLink".equals(key)) {
                wtUserLink = (String[]) value;
            }

            if ("beforeNumber".equals(key)) {
                beforeNumber = (String[]) value;
            }
            if ("beforeTagNumber".equals(key)) {
                beforeTagNumber = (String[]) value;
            }

        }

        //获取所有旧工位集合
//        getOldTagNumber(parentNumbers);

        System.out.println("打印改前子部件编号：" + beforeChildPartNumber);
        WTPart beforeChildPart = PartUtil.getWTPartByNumber(beforeChildPartNumber);
        if (beforeChildPart == null) {
            throw new WTException("子部件编号" + beforeChildPart + "不存在");
        }

        // 以父部件编号为key 每一行数据为value
        Map<String, List<UpdateOptionVo>> vos = new HashMap<>();

        //根据父部件遍历数据,
        for (int i = 0; i < parentNumbers.length; i++) {
            UpdateOptionVo vo = new UpdateOptionVo();

            vo.setParentNumbers(parentNumbers[i]);
            vo.setBeforeChildNumber(beforeChildPartNumber);//子部件编号
            vo.setBeforeNumber(beforeNumber[i]);//改前数量
            vo.setBeforeTagNumber(beforeTagNumber[i]);//改前工位
            vo.setWtUserLink(wtUserLink[i]);//旧的使用关系

            vo.setAfterNumber(afterNumber[i]);//改后数量
            vo.setAfterTagNumber(afterTagNumber[i]);//改后工位

            vo.setIsByCust(isByCust[i]);//改后是否客供
            vo.setIsCustomerService(isCustomerService[i]);//是否售后
            vo.setBOMSkip(BOMSkip[i]);//是否跳层
            vo.setItemNote(itemNote[i]);//物料备注

            //不为空添加行号
            Long addLong = null;
            System.out.println("添加行号不填时值为" + lineNumber);
            //行号不为空转为数字，存入VO
            if (!lineNumber[i].isEmpty()) {
                addLong = Long.parseLong(lineNumber[i]);
                vo.setLineNumber(addLong);
            }


            List<UpdateOptionVo> updateOptionVos = vos.get(parentNumbers[i]);
            if (updateOptionVos == null) {
                List<UpdateOptionVo> updateOptionVos1 = new ArrayList<>();
                updateOptionVos1.add(vo);
                vos.put(parentNumbers[i], updateOptionVos1);
            } else {
                updateOptionVos.add(vo);
            }

        }

        Set<Map.Entry<String, List<UpdateOptionVo>>> entries = vos.entrySet();

        checkPartAttribute(entries);



        Transaction trx = null;
        try {
            trx = new Transaction();
            trx.start();
            //根据BOM遍历
            String ErrMsg = "";
            //根据BOM遍历

            for (Map.Entry<String, List<UpdateOptionVo>> pr1 : entries) {
                //备注的子项编号
                StringBuffer remarkChildPart = new StringBuffer();
                //插入子项编号到备注
                remarkChildPart.append(pr1.getValue().get(0).beforeChildNumber);


                WTPart parentPart = PartUtil.getWTPartByNumber(pr1.getKey());
                //检出
                WTPart checkOutPart = (WTPart) WorkInProgressHelper.service.checkout(parentPart, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
                //根据副本父部件获取全部的副本连接
                List<WTPartUsageLink> linkByPart = PartUtil.getBomLinkByPart(checkOutPart);

                List<UpdateOptionVo> values = pr1.getValue();
                for (UpdateOptionVo vo : values) {

//                    if (vo.getLineNumber()==null){
//                        remarkChildPart.append("编号："+vo.beforeChildNumber+",行号："+" ").append(",");
//
//                    }else{
//                        remarkChildPart.append("编号："+vo.beforeChildNumber+",行号："+vo.getLineNumber()).append(",");
//
//                    }
                    WTPartMaster beforeChildPartMaster = PartUtil.getWTPartMasterByNumber(vo.beforeChildNumber);
                    //根据工位
                    updateHandler(checkOutPart, beforeChildPartMaster, vo, linkByPart);
                }
                //检入
                WorkInProgressHelper.service.checkin(checkOutPart, "批量修改，物料"+remarkChildPart);


            }
            trx.commit();
            trx = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (trx != null) {
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
        return super.postProcess(nmCommandBean, list);
    }




    /**
     * 修改
     *
     * @param parent
     * @return
     */
    private static void updateHandler(WTPart parent, WTPartMaster beforeChildPart, UpdateOptionVo item, List<WTPartUsageLink> links) throws Exception {
        System.out.println("进入修改方法");


        System.out.println("传入的数据VO" + item.toString());
        System.out.println("传入的连接长度" + links.size());

        // 如果改前子部件和改后的对象相同就只修改IBA属性

        System.out.println("修改前后子部件相同");
        // 拿到旧有的连接
        for (WTPartUsageLink link : links) {
            WTPartMaster wtPartMaster = link.getUses();
            IBAUtil ibaUtil = new IBAUtil(link);

            String tagNumber = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
            System.out.println("遍历的工位:" + tagNumber);
            System.out.println("旧的工位:" + item.getBeforeTagNumber());
            //对比编号,工位
            if (wtPartMaster.equals(beforeChildPart) && tagNumber.equals(item.getBeforeTagNumber())) {
                // 修改属性
                Quantity quantity = link.getQuantity();
                quantity.setAmount(Double.parseDouble(item.getAfterNumber()));//修改数量
                //行号不一致设置行号

                LineNumber ln = link.getLineNumber();
                //改前行号为空,设置为0
                long oldLineNumber = 0L;//初始化0
                if (ln != null) {
                    oldLineNumber =  ln.getValue();//连接换取旧行号
                }

                Long newlineNumber = item.getLineNumber();
                System.out.println("原本的行号" + oldLineNumber);
                System.out.println("修改的行号" + newlineNumber);


                //改后的为空
                if (newlineNumber == null) {
                    link.setLineNumber(null);//修改行号
                } else {
                    if (oldLineNumber != newlineNumber) {
                        link.setLineNumber(LineNumber.newLineNumber(item.getLineNumber()));//修改行号
                    }
                }

                ibaUtil.setIBAAttribute4AllType(link, BomConstant.TAG_NUMBER, item.getAfterTagNumber());//工位
                ibaUtil.setIBAAttribute4AllType(link, BomConstant.IS_BY_CUST, item.getIsByCust());//修改是否客供
                ibaUtil.setIBAAttribute4AllType(link, BomConstant.IS_CUSTOMER_SERVICE, item.getIsCustomerService());//修改是否售后
                ibaUtil.setIBAAttribute4AllType(link, BomConstant.BOM_SKIP, item.getBOMSkip());//修改是否跳层
                ibaUtil.setIBAAttribute4AllType(link, BomConstant.ITEM_NOTE, item.getItemNote());//修改物料行备注
                PersistenceHelper.manager.save(link);
            }
        }
    }

    public static String checkTagNumber(String parentPartNum, List<UpdateOptionVo> vos) throws WTException {
        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);
        HashSet<String> commonValues  = new HashSet<>();
        //获取BOM所有工位
        Set<String> tarNumLists = new HashSet<>();
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);
        for (WTPartUsageLink link : bomLinkByPart) {
            IBAUtil ibaUtil = new IBAUtil(link);
            String ibaValue = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
            if (ibaValue.isEmpty()) {

            } else {
                tarNumLists.addAll(Arrays.asList(ibaValue.split("\\s+")));
            }
        }

        for (UpdateOptionVo vo : vos) {
            //去掉旧的
            tarNumLists.removeAll(Arrays.asList(vo.getBeforeTagNumber().split("\\s+")));

            String afterTagNumber = vo.getAfterTagNumber();
            String[] afterTarNum = afterTagNumber.split("\\s+");
            for (String tar : afterTarNum) {
                if (tarNumLists.contains(tar)) {
                    // 重复了,插入工位
                    commonValues.add(tar);
//                    msg.append(tar).append("、");
                    continue;
                }
            }
            tarNumLists.addAll(Arrays.asList(afterTarNum));
        }

        Set<String> entityTarNumLists = new HashSet<>();
        //1.获取传入全部工位含空
        for (UpdateOptionVo vo : vos) {
            String[] paramTarNums = vo.getAfterTagNumber().split("\\s+");
            Set<String> paramTarNumList = new HashSet<>(Arrays.asList(paramTarNums));

            paramTarNumList.removeAll(Arrays.asList(vo.getBeforeTagNumber().split("\\s+")));


            //2.获取BOM下  相同编号 工位 包含空工位情况
            for (WTPartUsageLink link : bomLinkByPart) {
                WTPartMaster wtPartMaster = link.getUses();
                IBAUtil ibaUtil = new IBAUtil(link);
                String ibaTarNum = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);

                if (wtPartMaster.getNumber().equals(vo.getBeforeChildNumber())) {
                    entityTarNumLists.addAll(Arrays.asList(ibaTarNum.split("\\s+")));
                }
            }
            //bom中去掉改前工位
            entityTarNumLists.removeAll(Arrays.asList(vo.getBeforeTagNumber().split("\\s+")));
            for (String paramTarNum : paramTarNumList) {
                for (String entityTarNumList : entityTarNumLists) {
                    if (entityTarNumList.equals(paramTarNum)){
                        commonValues.add(paramTarNum);
//                        msg.append(paramTarNum).append("、");
                    }
                }
            }
            //将改后工位添加
            entityTarNumLists.addAll(paramTarNumList);
        }

        // 错误信息处理
        for (String commonValue : commonValues) {
            msg.append(commonValue).append("、");
        }
        return msg.toString();
    }

    public static String checkLineNumber(String parentPartNum, List<UpdateOptionVo> vos) throws WTException {

        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);

        //获取BOM所有行号
        Set<Long> lineNumberLists = new HashSet<>();
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);
        for (WTPartUsageLink link : bomLinkByPart) {
            LineNumber ln = link.getLineNumber();
            if (ln == null) {

            } else {
                long linkLineNumber = ln.getValue();
                lineNumberLists.add(linkLineNumber);
            }
        }


        for (UpdateOptionVo vo : vos) {

            //通过链接获取旧行号
            String wtUserLink = vo.getWtUserLink();
            WTPartUsageLink useLink = (WTPartUsageLink) refefence.getReference(wtUserLink).getObject();
            LineNumber oln = useLink.getLineNumber();
            if (oln != null) {
                long oldLineNumber = oln.getValue();
                lineNumberLists.remove(oldLineNumber);
            }

            Long lineNumber = vo.getLineNumber();
            if (lineNumber != null && lineNumberLists.contains(lineNumber)) {
                // 重复了,插入工位
                msg.append(lineNumber).append("、");
                continue;
            }
            lineNumberLists.add(lineNumber);
        }

        return msg.toString();

    }

    private static String isCheckOutBom(String key) {
        StringBuffer msg = new StringBuffer();

        WTPart bom = getWTPartByNumber(key);
        if (isCheckOut(bom)) {
            msg.append(bom.getNumber()).append("、");
        }

        return msg.toString();
    }

    public static String checkEmptyTagNumber(String parentPartNum, List<UpdateOptionVo> vos) throws WTException {
        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);

        Set<String> tarNumLists = new HashSet<>();

        //获取BOM所有工位

        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);

        //去调相同物料重复空工位
        //前端传入的参数表，相同编号物料，只能一个空工位
        //BOM下相同编号物料，只能一个空工位
        int countVo = 0;
        for (UpdateOptionVo vo : vos) {
            int countBOM = 0;
            for (WTPartUsageLink link : bomLinkByPart) {
                WTPartMaster wtPartMaster = link.getUses();
                IBAUtil ibaUtil = new IBAUtil(link);
                String ibaTagNumber = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
                //相同编号，BOM存在空工位
                if (wtPartMaster.getNumber().equals(vo.getAfterChildNumber()) && "".equals(ibaTagNumber)) {
                    countBOM++;
                }

            }
            //相同编号，传入存在空工位
            if ("".equals(vo.getAfterTagNumber())) {
                countVo++;
            }
            //说明BOM中存在当前物料存在空工位，校验传入参数有俩个空工位
            if (countBOM >= 1) {
                for (WTPartUsageLink link : bomLinkByPart) {
                    WTPartMaster wtPartMaster = link.getUses();
                    IBAUtil ibaUtil = new IBAUtil(link);
                    String ibaTagNumber = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
                    //相同编号，BOM存在空工位
                    if (wtPartMaster.getNumber().equals(vo.getAfterChildNumber()) && "".equals(vo.getAfterTagNumber())) {
                        countVo++;
                    }
                }
            }

            if (countVo >= 2) {
                tarNumLists.add(vo.getBeforeChildNumber());
                countVo = 0;
            }
        }

        for (String tarNumList : tarNumLists) {
            msg.append(tarNumList).append("、");
        }

        return msg.toString();
    }

    /**
     * 判断对象是否处于检出状态
     *
     * @param
     * @return boolean
     */
    public static boolean isCheckOut(Workable workable) {
        try {
            return WorkInProgressHelper.isCheckedOut(workable);
        } catch (WTException e) {

        }
        return false;
    }

    /**
     * 校验行号，工位，是否检出
     * @param entries
     * @throws WTException
     */
    public static void  checkPartAttribute(Set<Map.Entry<String, List<UpdateOptionVo>>> entries) throws WTException {

        for (Map.Entry<String, List<UpdateOptionVo>> pr1 : entries) {
            List<UpdateOptionVo> values = pr1.getValue();

            //判断是否检出
            String isCheckOut = isCheckOutBom(pr1.getKey());
            if (!isCheckOut.isEmpty()) {
                throw new WTException("BOM编号："+ isCheckOut + "已检出，请检入再执行此操作！" );
            }
            // 做工位 校验
            String isExistTagNumber = checkTagNumber(pr1.getKey(), values);
            if (!isExistTagNumber.isEmpty()) {
                throw new WTException("BOM编号：" + pr1.getKey() + "下已存在工位：" + isExistTagNumber);
            }
            //做行号校验
            String isExistLineNumber = checkLineNumber(pr1.getKey(), values);
            if (!isExistLineNumber.isEmpty()) {
                throw new WTException("BOM编号：" + pr1.getKey() + "下已存在行号：" + isExistLineNumber);
            }


        }
    }



}
