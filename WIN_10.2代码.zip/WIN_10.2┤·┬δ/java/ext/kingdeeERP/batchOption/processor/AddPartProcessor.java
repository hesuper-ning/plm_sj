package ext.kingdeeERP.batchOption.processor;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.kingdeeERP.batchOption.BomConstant;
import ext.kingdeeERP.batchOption.controller.VO.AddOptionVo;
import ext.kingdeeERP.batchOption.utils.IBAUtil;
import ext.kingdeeERP.batchOption.utils.PartUtil;
import ext.kingdeeERP.batchOption.utils.CommonUtil;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.part.*;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.util.*;

import static ext.kingdeeERP.batchOption.utils.PartUtil.*;

public class AddPartProcessor extends DefaultObjectFormProcessor {
    private static final ReferenceFactory refefence = new ReferenceFactory();

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {
        System.out.println("进入添加子项");
        StringBuffer msg = new StringBuffer();
        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();

        String[] parentNumbers = new String[]{};
        String[] parentNames = new String[]{};
        String[] itemNote = new String[]{};

        String[] beforeChildNumber = new String[]{};
        String[] beforeNumber = new String[]{};
        String[] beforeTagNumber = new String[]{};
        String[] lineNumber = new String[]{};

        String[] isByCust = new String[]{};
        String[] isCustomerService = new String[]{};
        String[] BOMSkip = new String[]{};


//        String beforeChildNumber = nmCommandBean.getTextParameter("beforeChildNumber");
//        String beforeNumber = nmCommandBean.getTextParameter("beforeNumber");
//        String beforeTagNumber = nmCommandBean.getTextParameter("beforeTagNumber");
//        String lineNumber = nmCommandBean.getTextParameter("lineNumber");
//
//
//        String isByCust = nmCommandBean.getTextParameter("isByCust");
//        String isCustomerService = nmCommandBean.getTextParameter("isCustomerService");
//        String BOMSkip = nmCommandBean.getTextParameter("BOMSkip");


        for (String key : parameterMap.keySet()) {
            Object value = parameterMap.get(key);

            String[] values = (String[]) value;
            for (String a : values) {
                System.out.println("key=" + key + "value=" + a);
            }
            if ("parentPartNumber".equals(key)) {
                parentNumbers = (String[]) value;
            }
            if ("beforeChildNumber".equals(key)) {
                beforeChildNumber = (String[]) value;
            } if ("itemNote".equals(key)) {
                itemNote = (String[]) value;
            }
            if ("beforeNumber".equals(key)) {
                beforeNumber = (String[]) value;
            }
            if ("beforeTagNumber".equals(key)) {
                beforeTagNumber = (String[]) value;
            }
            if ("lineNumber".equals(key)) {
                lineNumber = (String[]) value;
            }
            if ("isByCust".equals(key)) {
                isByCust = (String[]) value;
            }
            if ("isCustomerService".equals(key)) {
                isCustomerService = (String[]) value;
            }
            if ("BOMSkip".equals(key)) {
                BOMSkip = (String[]) value;
            }
        }


        // 以父部件编号为key 每一行数据为value
        Map<String, List<AddOptionVo>> vos = new HashMap<>();


        for (int i = 0; i < parentNumbers.length; i++) {

            System.out.println("打印子部件编号：" + beforeChildNumber[i]);
            WTPart beforeChildPart = getWTPartByNumber(beforeChildNumber[i]);
            if (beforeChildPart == null) {
                throw new WTException("编号:" + beforeChildNumber[i] + "的部件不存在");

            }
            if (!CommonUtil.isNumeric(beforeNumber[i])) {
                throw new WTException("子项数量为必填项且为数字");
            }

            //添加到Vo中
            AddOptionVo addOptionVo = new AddOptionVo();
            addOptionVo.setParentNumbers(parentNumbers[i]);//BOM
            addOptionVo.setBeforeChildNumbers(beforeChildNumber[i]);//子项编号
            addOptionVo.setBeforeNumbers(beforeNumber[i]);//数量
            addOptionVo.setBeforeTagNumbers(beforeTagNumber[i]);//工位
            addOptionVo.setIsByCust(isByCust[i]);//是否客供
            addOptionVo.setIsCustomerService(isCustomerService[i]);//是否售后
            addOptionVo.setBOMSkip(BOMSkip[i]);//是否跳层
            addOptionVo.setItemNote(itemNote[i]);//物料备注行

            //不为空添加行号
            Long addLong = null;
            System.out.println("添加行号不填时值为" + lineNumber[i]);
            //行号不为空转为数字，存入VO
            if (!lineNumber[i].isEmpty()) {
                addLong = Long.parseLong(lineNumber[i]);
                addOptionVo.setLineNumber(addLong);
            }


            List<AddOptionVo> updateOptionVos = vos.get(parentNumbers[i]);
            if (updateOptionVos == null) {
                List<AddOptionVo> updateOptionVos1 = new ArrayList<>();
                updateOptionVos1.add(addOptionVo);
                vos.put(parentNumbers[i], updateOptionVos1);
            } else {
                updateOptionVos.add(addOptionVo);
            }


//            vos.add(addOptionVo);
        }


        Set<Map.Entry<String, List<AddOptionVo>>> entries = vos.entrySet();

        //校验
        checkPartAttribute(entries);

        Transaction trx = null;
        try {
            trx = new Transaction();
            trx.start();

            for (Map.Entry<String, List<AddOptionVo>> pr1 : entries) {

                //备注的子项编号
                StringBuffer remarkChildPart = new StringBuffer();
                //获取父部件
                WTPart parentPart = getWTPartByNumber(pr1.getKey());
                //检出
                WTPart checkOutPart = (WTPart) WorkInProgressHelper.service.checkout(parentPart, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
                for (AddOptionVo vo : pr1.getValue()) {
                    //获取子部件
                    WTPartMaster beforeChildPartMaster = getWTPartMasterByNumber(vo.getBeforeChildNumbers());
                    //插入子项编号到备注
                    remarkChildPart.append(vo.getBeforeChildNumbers()).append(" ");
                    try {
                        addHandler(checkOutPart, beforeChildPartMaster, vo);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                //检入
                WorkInProgressHelper.service.checkin(checkOutPart, "批量添加，物料：" + remarkChildPart);
            }
            trx.commit();
            trx = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (trx != null) {
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
        return super.postProcess(nmCommandBean, list);

    }

    private static WTPartUsageLink addHandler(WTPart parent, WTPartMaster afterChildPart, AddOptionVo item) throws Exception {
        System.out.println("进入添加子件功能");
        WTPartUsageLink addBomLink = PartUtil.newUsageLink(parent, afterChildPart, item.getBeforeNumbers(), item.getBeforeTagNumbers(), item.getIsByCust(), item.getIsCustomerService(), item.getLineNumber(), item.getBOMSkip(),item.getItemNote());
        System.out.println("添加部件的编号名称为=" + afterChildPart.getNumber() + "-" + afterChildPart.getName() + "数量是=" + Double.parseDouble(item.getBeforeNumbers()) + "工号是=" + item.getBeforeTagNumbers());
        return addBomLink;
    }

    public static void checkTagNumber(String parentNumber, String childNumber, String tagNumber) throws WTException {

        WTPart parent = getWTPartByNumber(parentNumber);


        //获取当前BOM所有连接
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parent);
        for (WTPartUsageLink usageLink : bomLinkByPart) {
            WTPartMaster wtPartMaster = usageLink.getUses();//获取当前子项
            IBAUtil ibaUtil = new IBAUtil(usageLink);

            String linkTagNumber = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
            System.out.println("校验工位" + linkTagNumber + "长度未" + linkTagNumber.length());
            if (!linkTagNumber.isEmpty()) {
                //对比工位
                if (linkTagNumber.equals(tagNumber)) {
                    throw new WTException("BOM编号：" + parent.getNumber() + "下已存在工位：" + tagNumber);
                }
            }
        }


    }

    public static void checkLineNumber(String parentNumber, String childNumber, long lineNumber) throws WTException {

        WTPart parent = getWTPartByNumber(parentNumber);
        WTPartMaster childMaster = getWTPartMasterByNumber(childNumber);

        //获取BOM下全部行号
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parent);
        List<Long> getBOMALLLineNUmber = new ArrayList<>();
        for (WTPartUsageLink usageLink : bomLinkByPart) {
            LineNumber ln = usageLink.getLineNumber();
            if (ln != null) {
                long linkLineNumber = ln.getValue();
                getBOMALLLineNUmber.add(linkLineNumber);
            }
        }
        // 添加
        if (getBOMALLLineNUmber.contains(lineNumber)) {
            throw new WTException("BOM编号：" + parent.getNumber() + "下已存在行号：" + lineNumber);
        }

    }


    public static List<Long> getBOMLineNumberList(String parentNumber) {
        WTPart parent = getWTPartByNumber(parentNumber);

        //获取BOM下全部行号
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parent);
        List<Long> getBOMALLLineNumber = new ArrayList<>();
        for (WTPartUsageLink usageLink : bomLinkByPart) {
            LineNumber ln = usageLink.getLineNumber();
            if (ln != null) {
                long linkLineNumber = ln.getValue();
                getBOMALLLineNumber.add(linkLineNumber);
            }
        }
        return getBOMALLLineNumber;
    }

    public static List<Long> getBOMLineTagNumberList(String parentNumber) throws WTException {
        WTPart parent = getWTPartByNumber(parentNumber);

        //获取BOM下全部行号
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parent);
        List<Long> getBOMALLLineNumber = new ArrayList<>();
        for (WTPartUsageLink usageLink : bomLinkByPart) {
            IBAUtil ibaUtil = new IBAUtil(usageLink);
        }
        return getBOMALLLineNumber;
    }


    public static String checkTagNumber(String parentPartNum, List<AddOptionVo> vos) throws WTException {
        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);

        HashSet<String> commonValues  = new HashSet<>();


        //获取BOM所有工位
        Set<String> tarNumLists = new HashSet<>();
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);
        for (WTPartUsageLink link : bomLinkByPart) {

            IBAUtil ibaUtil = new IBAUtil(link);
            String ibaTarNum = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
            if (ibaTarNum.isEmpty()) {

            } else {
                tarNumLists.addAll(Arrays.asList(ibaTarNum.split("\\s+")));
            }
        }

        for (AddOptionVo vo : vos) {
            //去掉旧的
//            tarNumLists.removeAll(Arrays.asList(vo.getBeforeTagNumbers().split(" ")));

            String afterTagNumber = vo.getBeforeTagNumbers();
            String[] afterTarNum = afterTagNumber.split(" \\s+");
            for (String tar : afterTarNum) {
                if (tarNumLists.contains(tar)) {
                    // 重复了,插入工位
                    commonValues.add(tar);
//                    msg.append(tar).append("、");
                    continue;
                }
            }
            tarNumLists.addAll(Arrays.asList(afterTarNum));
        }

        //1.获取传入全部工位含空
        for (AddOptionVo vo : vos) {
            String[] paramTarNums = vo.getBeforeTagNumbers().split("\\s+");

            Set<String> paramTarNumList = new HashSet<>(Arrays.asList(paramTarNums));

            Set<String> entityTarNumLists = new HashSet<>();
            //2.获取BOM下  相同编号 工位 包含空工位情况
            for (WTPartUsageLink link : bomLinkByPart) {
                WTPartMaster wtPartMaster = link.getUses();
                IBAUtil ibaUtil = new IBAUtil(link);
                String ibaTarNum = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
                if (wtPartMaster.getNumber().equals(vo.getBeforeChildNumbers())) {
                    entityTarNumLists.addAll(Arrays.asList(ibaTarNum.split("\\s+")));
                }
            }

            for (String paramTarNum : paramTarNumList) {
                for (String entityTarNumList : entityTarNumLists) {
                    if (entityTarNumList.equals(paramTarNum)){
                        commonValues.add(paramTarNum);
//                        msg.append(paramTarNum).append("、");
                    }
                }
            }

        }


        // 错误信息处理
        for (String commonValue : commonValues) {
            msg.append(commonValue).append("、");
        }




        return msg.toString();
    }

    public static String checkLineNumber(String parentPartNum, List<AddOptionVo> vos) throws WTException {

        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);


        //获取BOM所有行号
        Set<Long> lineNumberLists = new HashSet<>();
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);
        for (WTPartUsageLink link : bomLinkByPart) {
            LineNumber ln = link.getLineNumber();
            if (ln == null) {

            } else {
                long linkLineNumber = ln.getValue();
                lineNumberLists.add(linkLineNumber);
            }
        }


        for (AddOptionVo vo : vos) {
            Long lineNumber = vo.getLineNumber();
            if (lineNumber != null && lineNumberLists.contains(lineNumber)) {
                // 重复了,插入工位
                msg.append(lineNumber).append("、");
                continue;
            }
            lineNumberLists.add(lineNumber);
        }

        return msg.toString();

    }

    private static String isCheckOutBom(String key) {
        StringBuffer msg = new StringBuffer();

        WTPart bom = getWTPartByNumber(key);
        if (isCheckOut(bom)) {
            msg.append(bom.getNumber()).append("、");
        }

        return msg.toString();
    }

    /**
     * 判断对象是否处于检出状态
     *
     * @param
     * @return boolean
     */
    public static boolean isCheckOut(Workable workable) {
        try {
            return WorkInProgressHelper.isCheckedOut(workable);
        } catch (WTException e) {

        }
        return false;
    }

    /**
     * 校验行号，工位，是否检出
     *
     * @param entries
     * @throws WTException
     */
    public static void checkPartAttribute(Set<Map.Entry<String, List<AddOptionVo>>> entries) throws WTException {
        for (Map.Entry<String, List<AddOptionVo>> pr1 : entries) {
            List<AddOptionVo> values = pr1.getValue();

            //判断是否检出
            String isCheckOut = isCheckOutBom(pr1.getKey());
            if (!isCheckOut.isEmpty()) {
                throw new WTException("BOM编号：" + isCheckOut + "已检出，请检入再执行此操作！");
            }

            // 做工位 校验
            String isExistTagNumber = checkTagNumber(pr1.getKey(), values);
            if (!isExistTagNumber.isEmpty()) {
                throw new WTException("BOM编号：" + pr1.getKey() + "下已存在工位：" + isExistTagNumber);
            }

            //做行号校验
            String isExistLineNumber = checkLineNumber(pr1.getKey(), values);
            if (!isExistLineNumber.isEmpty()) {
                throw new WTException("BOM编号：" + pr1.getKey() + "下已存在行号：" + isExistLineNumber);
            }
        }
    }
}