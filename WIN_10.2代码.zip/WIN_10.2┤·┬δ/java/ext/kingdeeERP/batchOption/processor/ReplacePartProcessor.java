package ext.kingdeeERP.batchOption.processor;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.kingdeeERP.batchOption.BomConstant;
import ext.kingdeeERP.batchOption.controller.VO.ReplaceOptionVo;
import ext.kingdeeERP.batchOption.utils.IBAUtil;
import ext.kingdeeERP.batchOption.utils.PartUtil;
import ext.kingdeeERP.batchOption.utils.PersistenceUtil;
import org.apache.commons.lang.StringUtils;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.part.*;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.util.*;

import static ext.kingdeeERP.batchOption.utils.PartUtil.*;
import static ext.kingdeeERP.batchOption.utils.PartUtil.getBomLinkByPart;

public class ReplacePartProcessor extends DefaultObjectFormProcessor {

    private static final ReferenceFactory refefence = new ReferenceFactory();

    @Override
    public FormResult postProcess(NmCommandBean nmCommandBean, List<ObjectBean> list) throws WTException {

        System.out.println("进入删除子项");
        StringBuffer msg = new StringBuffer();
        HashMap<String, Object> parameterMap = nmCommandBean.getParameterMap();

        String[] parentNumbers = new String[]{};
        String[] parentNames = new String[]{};
        String[] itemNote = new String[]{};

        String[] afterNumber = new String[]{};//改后数量
        String[] afterTagNumber = new String[]{};//改后工位
        String[] lineNumber = new String[]{};//行号
        String[] isByCust = new String[]{};//是否客供
        String[] isCustomerService = new String[]{};//是否售后;
        String[] BOMSkip = new String[]{};//时候跳层
        String[] wtUserLink = new String[]{};//连接

        String[] beforeNumber = new String[]{};//改前数量
        String[] beforeTagNumber = new String[]{};//改前工位

        String[] afterChildPartNumber = new String[]{};//改前工位


        String beforeChildPartNumber = nmCommandBean.getTextParameter("beforeChildPartNumber");


        for (String key : parameterMap.keySet()) {
            Object value = parameterMap.get(key);

            String[] values = (String[]) value;
            for (String a : values) {
                System.out.println("key=" + key + "value=" + a);
            }
            if ("parentPartNumber".equals(key)) {
                parentNumbers = (String[]) value;
            }
            if ("afterNumber".equals(key)) {
                afterNumber = (String[]) value;
            }
            if ("itemNote".equals(key)) {
                itemNote = (String[]) value;
            }
            if ("afterTagNumber".equals(key)) {
                afterTagNumber = (String[]) value;
            }

            if ("lineNumber".equals(key)) {
                lineNumber = (String[]) value;
            }
            if ("isByCust".equals(key)) {
                isByCust = (String[]) value;
            }

            if ("isCustomerService".equals(key)) {
                isCustomerService = (String[]) value;
            }
            if ("BOMSkip".equals(key)) {
                BOMSkip = (String[]) value;
            }
            if ("wtUserLink".equals(key)) {
                wtUserLink = (String[]) value;
            }

            if ("beforeNumber".equals(key)) {
                beforeNumber = (String[]) value;
            }
            if ("beforeTagNumber".equals(key)) {
                beforeTagNumber = (String[]) value;
            }

            if ("afterChildPartNumber".equals(key)) {
                afterChildPartNumber = (String[]) value;
            }


        }

        System.out.println("打印改前子部件编号：" + beforeChildPartNumber);
        WTPart beforeChildPart = PartUtil.getWTPartByNumber(beforeChildPartNumber);
        if (beforeChildPart == null) {
            throw new WTException("子部件编号" + beforeChildPartNumber + "不存在");
        }


        //校验改后子部件是否存在
        for (String afterPartNumber : afterChildPartNumber) {
            System.out.println("打印改后子部件编号：" + afterPartNumber);
            WTPart afterPart = PartUtil.getWTPartByNumber(afterPartNumber);
            if (afterPart == null) {
                throw new WTException("改后子部件编号" + afterPartNumber + "不存在");
            }
        }

        // 以父部件编号为key 每一行数据为value
        Map<String, List<ReplaceOptionVo>> vos = new HashMap<>();

//        List<ReplaceOptionVo> vos = new ArrayList<>();
        //根据父部件遍历数据,
        for (int i = 0; i < parentNumbers.length; i++) {
            ReplaceOptionVo vo = new ReplaceOptionVo();

            vo.setParentNumbers(parentNumbers[i]);
            vo.setBeforeChildNumber(beforeChildPartNumber);//改前子部件编号
            vo.setBeforeNumber(beforeNumber[i]);//改前数量
            vo.setBeforeTagNumber(beforeTagNumber[i]);//改前工位
            vo.setWtUserLink(wtUserLink[i]);//旧的使用关系

            vo.setAfterChildNumber(afterChildPartNumber[i]);//改后子部件编号
            vo.setAfterNumber(afterNumber[i]);//改后数量
            vo.setAfterTagNumber(afterTagNumber[i]);//改后工位

            vo.setIsByCust(isByCust[i]);//改后是否客供
            vo.setIsCustomerService(isCustomerService[i]);//是否售后
            vo.setBOMSkip(BOMSkip[i]);//是否跳层
            vo.setItemNote(itemNote[i]);//是否跳层

            //不为空添加行号
            Long addLong = null;
            System.out.println("添加行号不填时值为" + lineNumber);
            //行号不为空转为数字，存入VO
            if (!lineNumber[i].isEmpty()) {
                addLong = Long.parseLong(lineNumber[i]);
                vo.setLineNumber(addLong);
            }

//            //校验工位
//            if (vo.getAfterTagNumber() != null || vo.getAfterTagNumber().isEmpty()) {
//                checkTagNumber(vo.getParentNumbers(), vo.getAfterChildNumber(), vo.getAfterTagNumber());
//            }
//            //校验行号
//            if (vo.getLineNumber() != null) {
//                checkLineNumber(vo.getParentNumbers(), vo.getAfterChildNumber(), vo.getLineNumber());
//            }

            List<ReplaceOptionVo> replaceOptionVos = vos.get(parentNumbers[i]);
            if (replaceOptionVos == null) {
                List<ReplaceOptionVo> replaceOptionVos1 = new ArrayList<>();
                replaceOptionVos1.add(vo);
                vos.put(parentNumbers[i], replaceOptionVos1);
            } else {
                replaceOptionVos.add(vo);
            }

//            vos.add(vo);

        }

        Set<Map.Entry<String, List<ReplaceOptionVo>>> entries = vos.entrySet();

        //校验
        checkPartAttribute(entries);


        Transaction trx = null;
        try {
            trx = new Transaction();
            trx.start();
            //根据BOM遍历
            String ErrMsg = "";
            //根据BOM遍历
            for (Map.Entry<String, List<ReplaceOptionVo>> pr1 : entries) {
                //备注的子项编号
                StringBuffer remarkChildPart = new StringBuffer();
                //插入子项编号到备注
                remarkChildPart.append(pr1.getValue().get(0).getBeforeChildNumber());
                WTPart parentPart = PartUtil.getWTPartByNumber(pr1.getKey());
                //检出
                WTPart checkOutPart = (WTPart) WorkInProgressHelper.service.checkout(parentPart, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
                //根据副本父部件获取全部的副本连接
                List<WTPartUsageLink> linkByPart = PartUtil.getBomLinkByPart(checkOutPart);

                for (ReplaceOptionVo vo : pr1.getValue()) {


                    WTPartMaster beforeChildPartMaster = PartUtil.getWTPartMasterByNumber(vo.beforeChildNumber);
                    WTPartMaster afterChildNumberMaster = PartUtil.getWTPartMasterByNumber(vo.afterChildNumber);
                    //根据工位
                    replaceHandler(checkOutPart, beforeChildPartMaster, afterChildNumberMaster, vo, linkByPart);
                }
                //检入
                WorkInProgressHelper.service.checkin(checkOutPart, "批量替换，物料"+remarkChildPart);

            }
            trx.commit();
            trx = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (trx != null) {
                try {
                    trx.rollback();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
        return super.postProcess(nmCommandBean, list);
    }



    /**
     * 修改
     *
     * @param parent
     * @return
     */
    private static void replaceHandler(WTPart parent, WTPartMaster beforeChildPart, WTPartMaster afterChildPart, ReplaceOptionVo item, List<WTPartUsageLink> links) throws Exception {
        System.out.println("进入替换方法");


        System.out.println("传入的数据VO" + item.toString());
        System.out.println("传入的连接长度" + links.size());

        // 如果改前子部件和改后的对象相同就只修改IBA属性
        for (WTPartUsageLink link : links) {
            WTPartMaster wtPartMaster = link.getUses();
            IBAUtil ibaUtil = new IBAUtil(link);

            String tagNumber = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
            System.out.println("遍历link的工位:" + tagNumber);
            System.out.println("旧的工位:" + item.getBeforeTagNumber());


            boolean isAccuratePart = isAccuratePart(item.getWtUserLink(), link);
            //对比编号,工位
            if (wtPartMaster.equals(beforeChildPart) && tagNumber.equals(item.getBeforeTagNumber()) && isAccuratePart ) {
                //删除旧连接
                PersistenceHelper.manager.delete(link);

                System.out.println("删除完旧链接");
                // 然后执行添加新的连接的方法
                WTPartUsageLink addBomLink = PartUtil.newUsageLink(parent, afterChildPart, item.getAfterNumber(), item.getAfterTagNumber(), item.getIsByCust(), item.getIsCustomerService(),  item.getLineNumber(), item.getBOMSkip(),item.getItemNote());
                PersistenceHelper.manager.save(addBomLink);
                System.out.println("替换成功");
                break;
            }
        }
    }





    public static String checkTagNumber(String parentPartNum, List<ReplaceOptionVo> vos) throws WTException {
        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);
        HashSet<String> commonValues  = new HashSet<>();
        //获取BOM所有工位
        Set<String> tarNumLists = new HashSet<>();
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);
        for (WTPartUsageLink link : bomLinkByPart) {
            IBAUtil ibaUtil = new IBAUtil(link);
            String ibaValue = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
            if (ibaValue.isEmpty()) {

            } else {
                tarNumLists.addAll(Arrays.asList(ibaValue.split("\\s+")));
            }
        }


        Set<String> entityTarNumLists = new HashSet<>();
        for (ReplaceOptionVo vo : vos) {
            //去掉旧的
            tarNumLists.removeAll(Arrays.asList(vo.getBeforeTagNumber().split("\\s+")));

            String afterTagNumber = vo.getAfterTagNumber();
            String[] afterTarNum = afterTagNumber.split("\\s+");
            for (String tar : afterTarNum) {
                if (tarNumLists.contains(tar)) {
                    // 重复了,插入工位
                    commonValues.add(tar);
//                    msg.append(tar).append("、");
                    continue;
                }
            }
            tarNumLists.addAll(Arrays.asList(afterTarNum));
        }


        //1.获取传入全部工位含空
        for (ReplaceOptionVo vo : vos) {
            String[] paramTarNums = vo.getAfterTagNumber().split("\\s+");

            List<String> paramTarNumList = Arrays.asList(paramTarNums);


            //2.获取BOM下  相同编号 工位 包含空工位情况
            for (WTPartUsageLink link : bomLinkByPart) {
                WTPartMaster wtPartMaster = link.getUses();
                IBAUtil ibaUtil = new IBAUtil(link);
                String ibaTarNum = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);

                if (wtPartMaster.getNumber().equals(vo.getAfterTagNumber())) {
                    entityTarNumLists.addAll(Arrays.asList(ibaTarNum.split("\\s+")));
                }
            }

            //bom中去掉改前工位
            entityTarNumLists.removeAll(Arrays.asList(vo.getBeforeTagNumber().split("\\s+")));

            for (String paramTarNum : paramTarNumList) {
                for (String entityTarNumList : entityTarNumLists) {
                    if (entityTarNumList.equals(paramTarNum)){
                        commonValues.add(paramTarNum);
//                        msg.append(paramTarNum).append("、");
                    }
                }
            }
            //将改后工位添加
            entityTarNumLists.addAll(paramTarNumList);

        }


        // 错误信息处理
        for (String commonValue : commonValues) {
            msg.append(commonValue).append("、");
        }

        return msg.toString();
    }

    public static String checkLineNumber(String parentPartNum, List<ReplaceOptionVo> vos) throws WTException {

        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);

        //获取BOM所有行号
        Set<Long> lineNumberLists = new HashSet<>();
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);
        for (WTPartUsageLink link : bomLinkByPart) {
            LineNumber ln = link.getLineNumber();
            if (ln == null) {

            } else {
                long linkLineNumber = ln.getValue();
                lineNumberLists.add(linkLineNumber);
            }
        }


        for (ReplaceOptionVo vo : vos) {

            //通过链接获取旧行号
            String wtUserLink = vo.getWtUserLink();
            WTPartUsageLink useLink = (WTPartUsageLink) refefence.getReference(wtUserLink).getObject();
            LineNumber oln = useLink.getLineNumber();
            if (oln != null) {
                long oldLineNumber = oln.getValue();
                lineNumberLists.remove(oldLineNumber);
            }

            Long lineNumber = vo.getLineNumber();
            if (lineNumber != null && lineNumberLists.contains(lineNumber)) {
                // 重复了,插入工位
                msg.append(lineNumber).append("、");
                continue;
            }
            lineNumberLists.add(lineNumber);
        }

        return msg.toString();

    }

    private static String isCheckOutBom(String key) {
        StringBuffer msg = new StringBuffer();

        WTPart bom = getWTPartByNumber(key);

        if (isCheckOut(bom)) {
            msg.append(bom.getNumber()).append("、");
        }

        return msg.toString();

    }

    /**
     * 判断对象是否处于检出状态
     *
     * @param
     * @return boolean
     */
    public static boolean isCheckOut(Workable workable) {
        try {
            return WorkInProgressHelper.isCheckedOut(workable);
        } catch (WTException e) {

        }
        return false;
    }

    /**
     * 校验行号，工位，是否检出
     * @param entries
     * @throws WTException
     */
    public static void  checkPartAttribute(Set<Map.Entry<String, List<ReplaceOptionVo>>> entries) throws WTException {

        for (Map.Entry<String, List<ReplaceOptionVo>> pr1 : entries) {
            List<ReplaceOptionVo> values = pr1.getValue();


            //判断是否检出
            String isCheckOut = isCheckOutBom(pr1.getKey());
            if (!isCheckOut.isEmpty()) {
                throw new WTException("BOM编号："+ isCheckOut + "已检出，请检入再执行此操作！" );
            }

            // 做工位 校验
            String isExistTagNumber = checkTagNumber(pr1.getKey(), values);
            if (!isExistTagNumber.isEmpty()) {
                throw new WTException("BOM编号：" + pr1.getKey() + "下已存在工位：" + isExistTagNumber);
            }

            String isExistLineNumber = checkLineNumber(pr1.getKey(), values);
            if (!isExistLineNumber.isEmpty()) {
                throw new WTException("BOM编号：" + pr1.getKey() + "下已存在行号：" + isExistLineNumber);
            }

        }
    }

    /**
     *
     * @param paramLinkStr 传入的部件链接，获取当前part
     * @param bomLink 根据父部件获取到的link
     * @return 对比编号，工位，数量，行号找到正确的part
     * @throws WTException
     */
    public static boolean isAccuratePart(String paramLinkStr ,  WTPartUsageLink bomLink) throws WTException {
        boolean flag = false;
        //传入的链接传为part
        WTPartUsageLink paramLink = (WTPartUsageLink)PersistenceUtil.oid2Object(paramLinkStr);
        IBAUtil paramIBA = new IBAUtil(paramLink);

        String paramTarNumber =  paramIBA.getIBAValue(BomConstant.TAG_NUMBER);//工位
        String paramPartNumber = paramLink.getUses().getNumber();//编号
        LineNumber paramLineNumber = paramLink.getLineNumber();
        Quantity paramQuantity = paramLink.getQuantity();//数量
        //bom
        IBAUtil ibaUtil = new IBAUtil(bomLink);
        String bomTarNumber = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);//工位
        String bomNumber = bomLink.getUses().getNumber();//编号
        LineNumber bomLineNumber = bomLink.getLineNumber();
        Quantity quantity = bomLink.getQuantity();//数量


        if (paramTarNumber.equals(bomTarNumber) && paramPartNumber.equals(bomNumber) && quantity.equals(paramQuantity)  ) {
            if (paramLineNumber!=null && bomLineNumber!=null) {
                long paramLineNumberValue = paramLineNumber.getValue();
                long bomLineNumberValue = bomLineNumber.getValue();
                if (paramLineNumberValue==bomLineNumberValue){
                    flag = true;
                }
            }
            //都为空也是true
            if (paramLineNumber==null && bomLineNumber==null){
                flag = true;
            }
        }
        return flag;
    }


}
