package ext.kingdeeERP.batchOption.builder;

import com.ptc.mvc.components.*;
import com.ptc.mvc.util.ClientMessageSource;
import ext.kingdeeERP.batchOption.utils.PartUtil;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.query.ClassAttribute;
import wt.query.ConstantExpression;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ComponentBuilder("ext.kingdeeERP.batchOption.builder.PartListSearchTable")
public class PartListSearchTable extends AbstractComponentBuilder {
    private static final String[] ShowPartStatus = {"新建物料", "正在工作", "重新工作"};

    public static final List<String> ShowPartStatusList = new ArrayList<>(Arrays.asList(ShowPartStatus));

    private ClientMessageSource msgSource;

    @Override
    public Object buildComponentData(ComponentConfig arg0, ComponentParams params) throws Exception {
        //
        List<WTPart> resultList = new ArrayList<>();

        List<WTPart> allChildBOM = new ArrayList<>();
        System.out.println("进入table");
        //获取前端的数据，或者地址栏传的数据
        String itemName = (String) params.getParameter("itemName");
        String bomName = (String) params.getParameter("bomName");
        if (bomName != null && bomName != "") {
            System.out.println("打印BOM名称" + bomName);
        }

        if (itemName != null && itemName != "") {
            //项目名为精准查询
            WTPart wtPartByName = PartUtil.getEQUALWTPartByName(itemName);
            if (wtPartByName == null) {
                throw new WTException("您输入的项目名称有误！");
            }

            allChildBOM = PartUtil.getAllBomByPart(wtPartByName);
            if (!allChildBOM.isEmpty()) {


                for (WTPart part : allChildBOM) {
                    if (bomName != null && bomName != "") {
                        //对应要查的BOM且状态为 "新建物料", "正在工作", "重新工作"，含有查询的名称就返回
                        if (part.getName().contains(bomName) && ShowPartStatusList.contains(part.getLifeCycleState().getDisplay())) {
                            resultList.add(part);
                        }
                    }

                }
            }else{
                throw new WTException("未找到状态为：新建物料, 正在工作, 重新工作，请检查搜索的BOM状态！");
            }
            System.out.println("打印table数据集");
            for (WTPart part : resultList) {
                System.out.println(part.getNumber());
            }
            System.out.println("end");


        } else {
            //报表中无参查询
            throw new WTException("请输入项目名称！");
        }
        //将数据封装，返回给前端的。
        return resultList;
    }

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig config = factory.newTableConfig();


        config.setType("wt.fc.WTObject");
        config.setLabel("搜索项目下的BOM");
        config.setSelectable(true);
        config.setShowCount(true);
        config.setShowCustomViewLink(true);

        config.setActionModel("batchOptionOperate");


        //报表最前面圆圈
        ColumnConfig oidColumn = factory.newColumnConfig("oid", true);
        config.addComponent(oidColumn);
        oidColumn.setHidden(true);
        oidColumn.setSortable(true);

        //报表每列第二列name
        ColumnConfig numberColumn = factory.newColumnConfig("number", "编号", true);
        numberColumn.setDataUtilityId("SearchPartList");
        config.addComponent(numberColumn);

        //报表每列第三列name
        ColumnConfig nameColumn = factory.newColumnConfig("name", "名称", true);
        numberColumn.setDataUtilityId("SearchPartList");
        //对应数据库的列名称
        config.addComponent(nameColumn);


        //报表每列第三列name
        ColumnConfig itemDescColumn = factory.newColumnConfig("ItemDesc", "描述", true);
        itemDescColumn.setDataUtilityId("SearchPartList");
        //对应数据库的列名称
        config.addComponent(itemDescColumn);


        ColumnConfig versionColumn = factory.newColumnConfig("version", "版本", true);
        versionColumn.setDataUtilityId("SearchPartList");
        config.addComponent(versionColumn);

        //报表每列第三列name
        ColumnConfig lifeColumn = factory.newColumnConfig("state", "状态", true);
        lifeColumn.setDataUtilityId("SearchPartList");
        //对应数据库的列名称
        config.addComponent(lifeColumn);


        return config;
    }


    private void initTableColumns(ComponentConfigFactory factory, TableConfig config) {


    }


}

