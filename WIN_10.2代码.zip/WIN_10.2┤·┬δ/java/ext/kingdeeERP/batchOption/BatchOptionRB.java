package ext.kingdeeERP.batchOption;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.kingdeeERP.batchOption.BatchOptionRB")
public class BatchOptionRB extends WTListResourceBundle{

    @RBEntry("批量操作")
    public static final String PRIVATE_CONSTANT_0 = "BatchOption.batchOption.description";
    @RBEntry("批量操作")
    public static final String PRIVATE_CONSTANT_1 = "BatchOption.batchOption.tooltip";
    @RBEntry("add16x16.gif")
    public static final String PRIVATE_CONSTANT_3 = "BatchOption.batchOption.icon";



    @RBEntry("添加子项")
    public static final String PRIVATE_CONSTANT_4 = "batchOptionNotBom.addWizard.description";
    @RBEntry("添加子项")
    public static final String PRIVATE_CONSTANT_5 = "batchOptionNotBom.addWizard.tooltip";
    @RBEntry("add16x16.gif")
    public static final String PRIVATE_CONSTANT_6 = "batchOptionNotBom.addWizard.icon";

    @RBEntry("删除子项")
    public static final String PRIVATE_CONSTANT_7 = "batchOptionNotBom.deleteWizard.description";
    @RBEntry("删除子项")
    public static final String PRIVATE_CONSTANT_8 = "batchOptionNotBom.deleteWizard.tooltip";
    @RBEntry("delete.gif")
    public static final String PRIVATE_CONSTANT_9 = "batchOptionNotBom.deleteWizard.icon";

    @RBEntry("修改子项")
    public static final String PRIVATE_CONSTANT_10 = "batchOptionNotBom.updateWizard.description";
    @RBEntry("修改子项")
    public static final String PRIVATE_CONSTANT_11 = "batchOptionNotBom.updateWizard.tooltip";
    @RBEntry("edit_properties.gif")
    public static final String PRIVATE_CONSTANT_12 = "batchOptionNotBom.updateWizard.icon";


    @RBEntry("替换子项")
    public static final String PRIVATE_CONSTANT_13 = "batchOptionNotBom.replaceWizard.description";
    @RBEntry("替换子项")
    public static final String PRIVATE_CONSTANT_14 = "batchOptionNotBom.replaceWizard.tooltip";
    @RBEntry("replace9x9.gif")
    public static final String PRIVATE_CONSTANT_15 = "batchOptionNotBom.replaceWizard.icon";


}
