package ext.kingdeeERP.batchOption.service;

import ext.kingdeeERP.batchOption.BomConstant;
import ext.kingdeeERP.batchOption.controller.VO.UpdateOptionVo;
import ext.kingdeeERP.batchOption.utils.IBAUtil;
import wt.fc.ReferenceFactory;
import wt.part.LineNumber;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.util.*;

import static ext.kingdeeERP.batchOption.utils.PartUtil.getBomLinkByPart;
import static ext.kingdeeERP.batchOption.utils.PartUtil.getWTPartByNumber;

public class BatchOptionService {
    private static final ReferenceFactory refefence = new ReferenceFactory();
    public static String checkTagNumber(String parentPartNum, List<UpdateOptionVo> vos) throws WTException {
        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);

        //获取BOM所有工位
        Set<String> tarNumLists = new HashSet<>();
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);
        for (WTPartUsageLink link : bomLinkByPart) {
            IBAUtil ibaUtil = new IBAUtil(link);
            String ibaValue = ibaUtil.getIBAValue(BomConstant.TAG_NUMBER);
            if (ibaValue.isEmpty()) {

            } else {
                tarNumLists.addAll(Arrays.asList(ibaValue.split(" ")));
            }
        }


        for (UpdateOptionVo vo : vos) {
            //去掉旧的
            tarNumLists.removeAll(Arrays.asList(vo.getBeforeTagNumber().split(" ")));

            String afterTagNumber = vo.getAfterTagNumber();
            String[] afterTarNum = afterTagNumber.split(" ");
            for (String tar : afterTarNum) {
                if (tarNumLists.contains(tar)) {
                    // 重复了,插入工位
                    msg.append(tar).append("、");
                    continue;
                }
            }
            tarNumLists.addAll(Arrays.asList(afterTarNum));
        }
        return msg.toString();
    }

    public static String checkLineNumber(String parentPartNum, List<UpdateOptionVo> vos) throws WTException {

        StringBuilder msg = new StringBuilder();

        WTPart parentPart = getWTPartByNumber(parentPartNum);

        //获取BOM所有行号
        Set<Long> lineNumberLists = new HashSet<>();
        List<WTPartUsageLink> bomLinkByPart = getBomLinkByPart(parentPart);
        for (WTPartUsageLink link : bomLinkByPart) {
            LineNumber ln = link.getLineNumber();
            if (ln == null) {

            } else {
                long linkLineNumber = ln.getValue();
                lineNumberLists.add(linkLineNumber);
            }
        }


        for (UpdateOptionVo vo : vos) {

            //通过链接获取旧行号
            String wtUserLink = vo.getWtUserLink();
            WTPartUsageLink useLink = (WTPartUsageLink) refefence.getReference(wtUserLink).getObject();
            LineNumber oln = useLink.getLineNumber();
            if (oln != null) {
                long oldLineNumber = oln.getValue();
                lineNumberLists.remove(oldLineNumber);
            }

            Long lineNumber = vo.getLineNumber();
            if (lineNumber != null && lineNumberLists.contains(lineNumber)) {
                // 重复了,插入工位
                msg.append(lineNumber).append("、");
                continue;
            }
            lineNumberLists.add(lineNumber);
        }

        return msg.toString();

    }

    private static String isCheckOutBom(String key) {
        StringBuffer msg = new StringBuffer();

        WTPart bom = getWTPartByNumber(key);
        if (isCheckOut(bom)) {
            msg.append(bom.getNumber()).append("、");
        }

        return msg.toString();
    }

    /**
     * 判断对象是否处于检出状态
     *
     * @param
     * @return boolean
     */
    public static boolean isCheckOut(Workable workable) {
        try {
            return WorkInProgressHelper.isCheckedOut(workable);
        } catch (WTException e) {

        }
        return false;
    }

    /**
     * 校验行号，工位，是否检出
     * @param entries
     * @throws WTException
     */
    public static void  checkPartAttribute(Set<Map.Entry<String, List<UpdateOptionVo>>> entries) throws WTException {

        for (Map.Entry<String, List<UpdateOptionVo>> pr1 : entries) {
            List<UpdateOptionVo> values = pr1.getValue();

            //判断是否检出
            String isCheckOut = isCheckOutBom(pr1.getKey());
            if (!isCheckOut.isEmpty()) {
                throw new WTException("BOM编号："+ isCheckOut + "已检出，请检入再执行此操作！" );
            }
            // 做工位 校验
            String isExistTagNumber = checkTagNumber(pr1.getKey(), values);
            if (!isExistTagNumber.isEmpty()) {
                throw new WTException("BOM编号：" + pr1.getKey() + "下已存在工位：" + isExistTagNumber);
            }
            //做行号校验
            String isExistLineNumber = checkLineNumber(pr1.getKey(), values);
            if (!isExistLineNumber.isEmpty()) {
                throw new WTException("BOM编号：" + pr1.getKey() + "下已存在行号：" + isExistLineNumber);
            }

        }
    }
}
