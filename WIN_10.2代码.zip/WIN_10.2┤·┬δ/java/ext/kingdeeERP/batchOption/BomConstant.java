package ext.kingdeeERP.batchOption;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 常用常量
 */
public class BomConstant {
    // 规格型号内部值
    public static final String SpecificationsModel = "SpecificationsModel";

    // WTUserLink 内部IBA属性
    // 层级的内部值
    public static final String LEVEL_CJ = "Level_CJ";
    // 工号的内部值
    public static final String TAG_NUMBER = "MachinePos";
    // 是否客供料
    public static final String IS_BY_CUST = "IsByCust";

    // 是否售后料
    public static final String IS_CUSTOMER_SERVICE = "IsCustomerService";
    // 物料行备注
    public static final String ITEM_NOTE = "ItemNote";
    // 跳层
    public static final String BOM_SKIP = "BOMSkip";

    // 制成板
    public static final String Made_into_boards = "03.01";
    // OEM主板
    public static final String OEM_motherboard = "03.09";
    // 电路板
    public static final String Circuit_board = "03.06";
    // 副板
    public static final String Auxiliary_board = "03.05";
    // 成品板
    public static final String Finished_board = "03.02";
    // 机模主板
    public static final String Machine_model_motherboard = "03.07";


    // 变更紧急程度
    public static final String CHANGE_ORDER2_Urgency = "EngineeringChangeUrgency";

    // 部件分类IBA内部名称
    public static final String Part_Classification = "Classification";

    private static final String [] PCBAClass={Made_into_boards,OEM_motherboard,Circuit_board,Auxiliary_board,Finished_board,Machine_model_motherboard};

    // PCBA类型集合
    public static final List<String> PCBAClassList = new ArrayList<>(Arrays.asList(PCBAClass));

    // 添加和替换子件的时候子件必须是已发布 试制 正在工作
    private static final String [] ADD_AND_REPLACE_CHILD_PART_STATE={"已发布","试制","正在工作"};
    public static final List<String> ADD_AND_REPLACE_CHILD_PART_STATE_LIST = new ArrayList<>(Arrays.asList(ADD_AND_REPLACE_CHILD_PART_STATE));

    public static final String Change_Immediately = "立即变更";
    public static final String Use_Up_Old_Materials ="用完旧料";

    // 切换模式
    private static final String[] SWITCH_MODE = {Change_Immediately, Use_Up_Old_Materials};

    public static final List<String> SWITCH_MODE_LIST = new ArrayList<>(Arrays.asList(SWITCH_MODE));
}
